/*
** Automatically generated from `optimize.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module optimize. */
/* :- implementation. */

#include "optimize.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "attrs.h"
#include "mercury.benchmarking.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "input.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "mercury.tree234.h"
#include "mercury.varset.h"



#line 289 "optimize.m"
struct optimize__gen_open_8_p_0_env_0_s {
#line 289 "optimize.m"
  MR_Word optimize__gen_open_8_p_0_env_0__HeadVar__1_1;
#line 289 "optimize.m"
  MR_Word optimize__gen_open_8_p_0_env_0__HeadVar__2_2;
#line 289 "optimize.m"
  MR_Word optimize__gen_open_8_p_0_env_0__HeadVar__3_3;
#line 289 "optimize.m"
  MR_Word * optimize__gen_open_8_p_0_env_0__HeadVar__4_4;
#line 289 "optimize.m"
  MR_Integer optimize__gen_open_8_p_0_env_0__HeadVar__5_5;
#line 289 "optimize.m"
  MR_Integer * optimize__gen_open_8_p_0_env_0__HeadVar__6_6;
#line 289 "optimize.m"
  MR_Word optimize__gen_open_8_p_0_env_0__HeadVar__7_7;
#line 289 "optimize.m"
  MR_Word * optimize__gen_open_8_p_0_env_0__HeadVar__8_8;
#line 289 "optimize.m"
  MR_Cont optimize__gen_open_8_p_0_env_0__cont;
#line 289 "optimize.m"
  void * optimize__gen_open_8_p_0_env_0__cont_env_ptr;
#line 299 "optimize.m"
  bool optimize__gen_open_8_p_0_env_0__succeeded;
  MR_Word optimize__gen_open_8_p_0_env_0__Tag_17;
  MR_Word optimize__gen_open_8_p_0_env_0__As1_18;
  MR_Word optimize__gen_open_8_p_0_env_0__Stk1_19;
  MR_Integer optimize__gen_open_8_p_0_env_0__N1_20;
  MR_Word optimize__gen_open_8_p_0_env_0__Ts1_21;
#line 289 "optimize.m"
};

#line 195 "optimize.m"
struct optimize__gen_n_10_p_0_env_0_s {
#line 195 "optimize.m"
  MR_Integer optimize__gen_n_10_p_0_env_0__HeadVar__1_1;
#line 195 "optimize.m"
  MR_Integer optimize__gen_n_10_p_0_env_0__HeadVar__2_2;
#line 195 "optimize.m"
  MR_Array optimize__gen_n_10_p_0_env_0__HeadVar__4_4;
#line 195 "optimize.m"
  MR_Word * optimize__gen_n_10_p_0_env_0__HeadVar__6_6;
#line 195 "optimize.m"
  MR_Integer * optimize__gen_n_10_p_0_env_0__HeadVar__8_8;
#line 195 "optimize.m"
  MR_Word optimize__gen_n_10_p_0_env_0__HeadVar__9_9;
#line 195 "optimize.m"
  MR_Word * optimize__gen_n_10_p_0_env_0__HeadVar__10_10;
#line 195 "optimize.m"
  MR_Cont optimize__gen_n_10_p_0_env_0__cont;
#line 195 "optimize.m"
  void * optimize__gen_n_10_p_0_env_0__cont_env_ptr;
  MR_Word optimize__gen_n_10_p_0_env_0__AsI_21;
  MR_Word optimize__gen_n_10_p_0_env_0__Stk1_22;
  MR_Integer optimize__gen_n_10_p_0_env_0__N1_23;
  MR_Word optimize__gen_n_10_p_0_env_0__Ts0_24;
  MR_Word optimize__gen_n_10_p_0_env_0__Ts_25;
  MR_Integer optimize__gen_n_10_p_0_env_0__V_26_26;
  MR_Word optimize__gen_n_10_p_0_env_0__V_27_27;
  MR_Integer optimize__gen_n_10_p_0_env_0__V_28_28;
  MR_Word optimize__gen_n_10_p_0_env_0__TypeInfo_31_31;
  MR_Word optimize__gen_n_10_p_0_env_0__V_5_42;
#line 195 "optimize.m"
};

#line 181 "optimize.m"
struct optimize__gen_n_cc_9_p_0_env_0_s {
#line 181 "optimize.m"
  MR_Integer optimize__gen_n_cc_9_p_0_env_0__HeadVar__1_1;
#line 181 "optimize.m"
  MR_Integer optimize__gen_n_cc_9_p_0_env_0__HeadVar__2_2;
#line 181 "optimize.m"
  MR_Integer optimize__gen_n_cc_9_p_0_env_0__HeadVar__3_3;
#line 181 "optimize.m"
  MR_Word optimize__gen_n_cc_9_p_0_env_0__HeadVar__4_4;
#line 181 "optimize.m"
  MR_Array optimize__gen_n_cc_9_p_0_env_0__HeadVar__5_5;
#line 181 "optimize.m"
  MR_Word optimize__gen_n_cc_9_p_0_env_0__HeadVar__6_6;
#line 181 "optimize.m"
  MR_Word optimize__gen_n_cc_9_p_0_env_0__HeadVar__8_8;
#line 186 "optimize.m"
  bool optimize__gen_n_cc_9_p_0_env_0__succeeded;
#line 186 "optimize.m"
  MR_Word optimize__gen_n_cc_9_p_0_env_0__Stk1_19;
#line 186 "optimize.m"
  MR_Word optimize__gen_n_cc_9_p_0_env_0__Tss1_21;
#line 184 "optimize.m"
  jmp_buf optimize__gen_n_cc_9_p_0_env_0__commit_1;
#line 181 "optimize.m"
};

static const MR_HO_PseudoTypeInfo_Struct2 optimize____ho_type_info_tuple_2__type0_12_input__tag_0__type0_14_attrs__attrs_0;
static const MR_FO_PseudoTypeInfo_Struct1 optimize__list__type_info_list_1__ho_type_9___tuple_0_2__type0_12_input__tag_0__type0_14_attrs__attrs_0;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
static void MR_CALL optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_p_0(
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word optimize__HeadVar__8_8,
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_String optimize__V_7_76);
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL optimize__map__ho4__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word optimize__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * optimize__HeadVar__3_3);
#line 155 "optimize.m"
static void MR_CALL optimize__write_tokenss__ua0_9_p_0(
#line 155 "optimize.m"
  MR_String optimize__HeadVar__1_1,
#line 155 "optimize.m"
  MR_Array optimize__HeadVar__3_3,
#line 155 "optimize.m"
  MR_Integer optimize__HeadVar__4_4,
#line 155 "optimize.m"
  MR_Integer optimize__HeadVar__5_5,
#line 155 "optimize.m"
  MR_Integer * optimize__HeadVar__6_6,
#line 155 "optimize.m"
  MR_Word optimize__HeadVar__7_7);
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
static void MR_CALL optimize__write_list__ho2_5_p_in__io_0(
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
  MR_Word optimize__HeadVar__1_1,
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
  MR_String optimize__HeadVar__2_2);
static /* final */ const MR_Box optimize__const_1091_0_1_TypeInfo_8_8[4];
static /* final */ const MR_Box optimize__const_1090_0_1_TypeInfo_7_7[4];
#line 314 "optimize.m"
static /* final */ const MR_Box optimize__const_12_0_1_Tag_17[1];
static void MR_CALL optimize__gen_open_8_p_0_1(
  void * optimize__env_ptr_arg);
#line 289 "optimize.m"
static void MR_CALL optimize__gen_open_8_p_0(
#line 289 "optimize.m"
  MR_Word optimize__HeadVar__1_1,
#line 289 "optimize.m"
  MR_Word optimize__HeadVar__2_2,
#line 289 "optimize.m"
  MR_Word optimize__HeadVar__3_3,
#line 289 "optimize.m"
  MR_Word * optimize__HeadVar__4_4,
#line 289 "optimize.m"
  MR_Integer optimize__HeadVar__5_5,
#line 289 "optimize.m"
  MR_Integer * optimize__HeadVar__6_6,
#line 289 "optimize.m"
  MR_Word optimize__HeadVar__7_7,
#line 289 "optimize.m"
  MR_Word * optimize__HeadVar__8_8,
#line 289 "optimize.m"
  MR_Cont optimize__cont,
#line 289 "optimize.m"
  void * optimize__cont_env_ptr);
#line 270 "optimize.m"
static bool MR_CALL optimize__open_tag_9_p_0(
#line 270 "optimize.m"
  MR_Word optimize__HeadVar__1_1,
#line 270 "optimize.m"
  MR_Word optimize__HeadVar__2_2,
#line 270 "optimize.m"
  MR_Word * optimize__HeadVar__3_3,
#line 270 "optimize.m"
  MR_Word optimize__HeadVar__4_4,
#line 270 "optimize.m"
  MR_Word * optimize__HeadVar__5_5,
#line 270 "optimize.m"
  MR_Integer optimize__HeadVar__6_6,
#line 270 "optimize.m"
  MR_Integer * optimize__HeadVar__7_7,
#line 270 "optimize.m"
  MR_Word optimize__HeadVar__8_8,
#line 270 "optimize.m"
  MR_Word * optimize__HeadVar__9_9);
#line 217 "optimize.m"
static void MR_CALL optimize__gen_8_p_0(
#line 217 "optimize.m"
  MR_Word optimize__HeadVar__1_1,
#line 217 "optimize.m"
  MR_Word optimize__HeadVar__2_2,
#line 217 "optimize.m"
  MR_Word optimize__HeadVar__3_3,
#line 217 "optimize.m"
  MR_Word * optimize__HeadVar__4_4,
#line 217 "optimize.m"
  MR_Integer optimize__HeadVar__5_5,
#line 217 "optimize.m"
  MR_Integer * optimize__HeadVar__6_6,
#line 217 "optimize.m"
  MR_Word optimize__HeadVar__7_7,
#line 217 "optimize.m"
  MR_Word * optimize__HeadVar__8_8,
#line 217 "optimize.m"
  MR_Cont optimize__cont,
#line 217 "optimize.m"
  void * optimize__cont_env_ptr);
static void MR_CALL optimize__gen_n_10_p_0_1(
  void * optimize__env_ptr_arg);
#line 195 "optimize.m"
static void MR_CALL optimize__gen_n_10_p_0(
#line 195 "optimize.m"
  MR_Integer optimize__HeadVar__1_1,
#line 195 "optimize.m"
  MR_Integer optimize__HeadVar__2_2,
#line 195 "optimize.m"
  MR_Word optimize__HeadVar__3_3,
#line 195 "optimize.m"
  MR_Array optimize__HeadVar__4_4,
#line 195 "optimize.m"
  MR_Word optimize__HeadVar__5_5,
#line 195 "optimize.m"
  MR_Word * optimize__HeadVar__6_6,
#line 195 "optimize.m"
  MR_Integer optimize__HeadVar__7_7,
#line 195 "optimize.m"
  MR_Integer * optimize__HeadVar__8_8,
#line 195 "optimize.m"
  MR_Word optimize__HeadVar__9_9,
#line 195 "optimize.m"
  MR_Word * optimize__HeadVar__10_10,
#line 195 "optimize.m"
  MR_Cont optimize__cont,
#line 195 "optimize.m"
  void * optimize__cont_env_ptr);
static /* final */ const MR_Box optimize__const_5_0_1_TypeInfo_26_26[2];
#line 184 "optimize.m"
static void MR_CALL optimize__gen_n_cc_9_p_0_1(
#line 184 "optimize.m"
  void * optimize__env_ptr_arg);
#line 184 "optimize.m"
static void MR_CALL optimize__gen_n_cc_9_p_0_2(
#line 184 "optimize.m"
  void * optimize__env_ptr_arg);
#line 181 "optimize.m"
static void MR_CALL optimize__gen_n_cc_9_p_0(
#line 181 "optimize.m"
  MR_Integer optimize__HeadVar__1_1,
#line 181 "optimize.m"
  MR_Integer optimize__HeadVar__2_2,
#line 181 "optimize.m"
  MR_Integer optimize__HeadVar__3_3,
#line 181 "optimize.m"
  MR_Word optimize__HeadVar__4_4,
#line 181 "optimize.m"
  MR_Array optimize__HeadVar__5_5,
#line 181 "optimize.m"
  MR_Word optimize__HeadVar__6_6,
#line 181 "optimize.m"
  MR_Word * optimize__HeadVar__7_7,
#line 181 "optimize.m"
  MR_Word optimize__HeadVar__8_8,
#line 181 "optimize.m"
  MR_Word * optimize__HeadVar__9_9);
#line 127 "optimize.m"
static void MR_CALL optimize__write_optimized_2_10_p_0(
#line 127 "optimize.m"
  MR_String optimize__HeadVar__1_1,
#line 127 "optimize.m"
  MR_Array optimize__HeadVar__2_2,
#line 127 "optimize.m"
  MR_Array optimize__HeadVar__3_3,
#line 127 "optimize.m"
  MR_Integer optimize__HeadVar__4_4,
#line 127 "optimize.m"
  MR_Integer optimize__HeadVar__5_5,
#line 127 "optimize.m"
  MR_Integer optimize__HeadVar__6_6,
#line 127 "optimize.m"
  MR_Integer optimize__HeadVar__7_7,
#line 127 "optimize.m"
  MR_Word optimize__HeadVar__8_8);



const MR_TypeCtorInfo_Struct optimize__optimize__type_ctor_info_tas_0 = {
		(MR_Integer) 0,
		((MR_Box) (optimize____Unify____tas_0_0)),
		((MR_Box) (optimize____Unify____tas_0_0)),
		((MR_Box) (optimize____Compare____tas_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "optimize",
		(MR_String) "tas",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&optimize__list__type_info_list_1__ho_type_9___tuple_0_2__type0_12_input__tag_0__type0_14_attrs__attrs_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
static const MR_HO_PseudoTypeInfo_Struct2 optimize____ho_type_info_tuple_2__type0_12_input__tag_0__type0_14_attrs__attrs_0 = {
		(&mercury__builtin____type_ctor_info_tuple_0),
		(MR_Integer) 2,
		{
		(MR_PseudoTypeInfo) (&input__input__type_ctor_info_tag_0),
		(MR_PseudoTypeInfo) (&attrs__attrs__type_ctor_info_attrs_0)}};
static const MR_FO_PseudoTypeInfo_Struct1 optimize__list__type_info_list_1__ho_type_9___tuple_0_2__type0_12_input__tag_0__type0_14_attrs__attrs_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&optimize____ho_type_info_tuple_2__type0_12_input__tag_0__type0_14_attrs__attrs_0)}};

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
static void MR_CALL optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_p_0(
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word optimize__HeadVar__8_8,
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_String optimize__V_7_76)
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
{
  {
    bool optimize__succeeded;

    if ((optimize__HeadVar__8_8 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      {
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      }
    else
      {
        MR_Tuple optimize__H0_6_96 = ((MR_Tuple) (MR_hl_field(MR_mktag(1), optimize__HeadVar__8_8, (MR_Integer) 0)));
        MR_Word optimize__T0_7_97 = ((MR_Word) (MR_hl_field(MR_mktag(1), optimize__HeadVar__8_8, (MR_Integer) 1)));
        MR_Word optimize__H_8_98;
        MR_Word optimize__T_9_99;
        MR_Word optimize__Tag_137 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__H0_6_96, (MR_Integer) 0)));
#line 146 "optimize.m"
        MR_Word optimize___As_136 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__H0_6_96, (MR_Integer) 1)));

#line 146 "optimize.m"
        {
#line 146 "optimize.m"
          optimize__H_8_98 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "close"));
#line 146 "optimize.m"
          MR_hl_field(MR_mktag(1), optimize__H_8_98, 0) = ((MR_Box) (optimize__Tag_137));
#line 146 "optimize.m"
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          optimize__map__ho4__ua0_3_p_in__list_0(optimize__T0_7_97, &optimize__T_9_99);
        }
#line 351 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        {
#line 351 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          input__write_token_3_p_0(optimize__H_8_98);
        }
#line 355 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        if ((optimize__T_9_99 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 354 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          {
#line 354 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          }
#line 355 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        else
#line 355 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          {
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_p_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
optimize__V_7_76
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 355 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          }
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        {
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          optimize__write_list__ho2_5_p_in__io_0(optimize__T_9_99, optimize__V_7_76);
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          return;
        }
      }
  }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
}

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL optimize__map__ho4__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word optimize__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * optimize__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool optimize__succeeded;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((optimize__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *optimize__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
        MR_Tuple optimize__H0_6_6 = ((MR_Tuple) (MR_hl_field(MR_mktag(1), optimize__HeadVar__2_2, (MR_Integer) 0)));
        MR_Word optimize__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), optimize__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word optimize__H_8_8;
        MR_Word optimize__T_9_9;
        MR_Word optimize__Tag_51 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__H0_6_6, (MR_Integer) 0)));
#line 146 "optimize.m"
        MR_Word optimize___As_50 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__H0_6_6, (MR_Integer) 1)));

#line 146 "optimize.m"
        {
#line 146 "optimize.m"
          optimize__H_8_8 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "close"));
#line 146 "optimize.m"
          MR_hl_field(MR_mktag(1), optimize__H_8_8, 0) = ((MR_Box) (optimize__Tag_51));
#line 146 "optimize.m"
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          optimize__map__ho4__ua0_3_p_in__list_0(optimize__T0_7_7, &optimize__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *optimize__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *optimize__HeadVar__3_3, 0) = ((MR_Box) (optimize__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *optimize__HeadVar__3_3, 1) = ((MR_Box) (optimize__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 155 "optimize.m"
static void MR_CALL optimize__write_tokenss__ua0_9_p_0(
#line 155 "optimize.m"
  MR_String optimize__HeadVar__1_1,
#line 155 "optimize.m"
  MR_Array optimize__HeadVar__3_3,
#line 155 "optimize.m"
  MR_Integer optimize__HeadVar__4_4,
#line 155 "optimize.m"
  MR_Integer optimize__HeadVar__5_5,
#line 155 "optimize.m"
  MR_Integer * optimize__HeadVar__6_6,
#line 155 "optimize.m"
  MR_Word optimize__HeadVar__7_7)
#line 155 "optimize.m"
{
#line 157 "optimize.m"
  {
#line 157 "optimize.m"
    /* tailcall optimized into a loop */
#line 157 "optimize.m"
  loop_top:;
#line 157 "optimize.m"
    {
#line 157 "optimize.m"
      bool optimize__succeeded;

#line 157 "optimize.m"
      if ((optimize__HeadVar__7_7 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 157 "optimize.m"
        *optimize__HeadVar__6_6 = optimize__HeadVar__5_5;
#line 157 "optimize.m"
      else
#line 157 "optimize.m"
        {
          MR_Word optimize__Ts_23 = ((MR_Word) (MR_hl_field(MR_mktag(1), optimize__HeadVar__7_7, (MR_Integer) 0)));
          MR_Word optimize__Tss_24 = ((MR_Word) (MR_hl_field(MR_mktag(1), optimize__HeadVar__7_7, (MR_Integer) 1)));
          MR_Integer optimize__Ext0_25;
          MR_Integer optimize__V_30_30;
          MR_Integer optimize__V_31_31;
          MR_Integer optimize__V_32_32;
          MR_String optimize__V_33_33;
          MR_Word optimize__TypeInfo_34_34;
          MR_String optimize__V_7_38 = (MR_String) "";
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          MR_Box optimize__conv1_Ext0_25;

#line 13 "input.opt"
          {
#line 13 "input.opt"
            optimize__write_list__ho2_5_p_in__io_0(optimize__Ts_23, optimize__V_7_38);
          }
          optimize__TypeInfo_34_34 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            mercury__array__lookup_3_p_1(optimize__TypeInfo_34_34, (MR_Array) optimize__HeadVar__3_3, optimize__HeadVar__4_4, &optimize__conv1_Ext0_25);
          }
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          optimize__Ext0_25 = ((MR_Integer) optimize__conv1_Ext0_25);
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL optimize__write_tokenss__ua0_9_p_0
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Integer Start;
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Integer Count;
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String SubString;
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Str = 
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
optimize__HeadVar__1_1
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Start = 
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
optimize__HeadVar__5_5
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Count = 
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
optimize__Ext0_25
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Integer len;
	MR_Word tmp;
	if (Start < 0) Start = 0;
	if (Count <= 0) {
		MR_make_aligned_string(
			MR_LVALUE_CAST(MR_ConstString, SubString),
			"");
	} else {
		len = strlen(Str);
		if (Start > len) Start = len;
		if (Count > len - Start) Count = len - Start;
		MR_allocate_aligned_string_msg(SubString, Count, MR_PROC_LABEL);
		memcpy(SubString, Str + Start, Count);
		SubString[Count] = '\0';
	}
}
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
optimize__V_33_33
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = SubString;
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL optimize__write_tokenss__ua0_9_p_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
optimize__V_33_33
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 173 "optimize.m"
          optimize__V_32_32 = (MR_Integer) 1;
#line 173 "optimize.m"
          optimize__V_30_30 = (optimize__HeadVar__4_4 + optimize__V_32_32);
#line 173 "optimize.m"
          optimize__V_31_31 = (optimize__HeadVar__5_5 + optimize__Ext0_25);
#line 173 "optimize.m"
          {
#line 173 "optimize.m"
            /* direct tailcall eliminated */
#line 173 "optimize.m"
            {
#line 173 "optimize.m"
              MR_Integer optimize__HeadVar__4__tmp_copy_4 = optimize__V_30_30;
#line 173 "optimize.m"
              MR_Integer optimize__HeadVar__5__tmp_copy_5 = optimize__V_31_31;
#line 173 "optimize.m"
              MR_Word optimize__HeadVar__7__tmp_copy_7 = optimize__Tss_24;

#line 173 "optimize.m"
              optimize__HeadVar__4_4 = optimize__HeadVar__4__tmp_copy_4;
#line 173 "optimize.m"
              optimize__HeadVar__5_5 = optimize__HeadVar__5__tmp_copy_5;
#line 173 "optimize.m"
              optimize__HeadVar__7_7 = optimize__HeadVar__7__tmp_copy_7;
#line 173 "optimize.m"
            }
#line 173 "optimize.m"
            goto loop_top;
#line 173 "optimize.m"
          }
#line 157 "optimize.m"
        }
#line 157 "optimize.m"
    }
#line 157 "optimize.m"
  }
#line 155 "optimize.m"
}

#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
static void MR_CALL optimize__write_list__ho2_5_p_in__io_0(
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
  MR_Word optimize__HeadVar__1_1,
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
  MR_String optimize__HeadVar__2_2)
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
{
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
  {
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    /* tailcall optimized into a loop */
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
  loop_top:;
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    {
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      bool optimize__succeeded;
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      MR_Word optimize__E_10_10;
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      MR_Word optimize__Es_11_11;

#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      if ((optimize__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        {
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        }
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      else
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        {
#line 350 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          optimize__E_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), optimize__HeadVar__1_1, (MR_Integer) 0)));
#line 350 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          optimize__Es_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), optimize__HeadVar__1_1, (MR_Integer) 1)));
#line 351 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          {
#line 351 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            input__write_token_3_p_0(optimize__E_10_10);
          }
#line 355 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          if ((optimize__Es_11_11 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 354 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            {
#line 354 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            }
#line 355 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          else
#line 355 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            {
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL optimize__write_list__ho2_5_p_in__io_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
optimize__HeadVar__2_2
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 355 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            }
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          {
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            /* direct tailcall eliminated */
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            {
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
              MR_Word optimize__HeadVar__1__tmp_copy_1 = optimize__Es_11_11;

#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
              optimize__HeadVar__1_1 = optimize__HeadVar__1__tmp_copy_1;
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            }
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            goto loop_top;
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          }
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        }
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    }
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
  }
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
}
static /* final */ const MR_Box optimize__const_1091_0_1_TypeInfo_8_8[4] = {
		((MR_Box) ((&mercury__builtin__builtin__type_ctor_info_tuple_0))),
		((MR_Box) ((MR_Integer) 2)),
		((MR_Box) ((&input__input__type_ctor_info_tag_0))),
		((MR_Box) ((&attrs__attrs__type_ctor_info_attrs_0)))};

#line 89 "optimize.m"
void MR_CALL optimize____Compare____tas_0_0(
#line 89 "optimize.m"
  MR_Word * optimize__HeadVar__1_1,
#line 89 "optimize.m"
  MR_Word optimize__HeadVar__2_2,
#line 89 "optimize.m"
  MR_Word optimize__HeadVar__3_3)
#line 89 "optimize.m"
{
  {
    bool optimize__succeeded;
    MR_Word optimize__conv1_HeadVar__2_2 = (MR_Word) optimize__HeadVar__2_2;
    MR_Word optimize__conv2_HeadVar__3_3 = (MR_Word) optimize__HeadVar__3_3;
    MR_Word optimize__TypeInfo_4_4 = (MR_Word) (&input__input__type_ctor_info_tag_0);
    MR_Word optimize__TypeInfo_5_5 = (MR_Word) (&attrs__attrs__type_ctor_info_attrs_0);
    MR_Word optimize__TypeInfo_6_6 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_tuple_0);
    MR_Integer optimize__TypeArity_7 = (MR_Integer) 2;
    MR_Word optimize__TypeInfo_8_8 = (MR_Word) &optimize__const_1091_0_1_TypeInfo_8_8;

#line 89 "optimize.m"
    {
#line 89 "optimize.m"
      mercury__list____Compare____list_1_0(optimize__TypeInfo_8_8, optimize__HeadVar__1_1, optimize__conv1_HeadVar__2_2, optimize__conv2_HeadVar__3_3);
#line 89 "optimize.m"
      return;
    }
  }
#line 89 "optimize.m"
}
static /* final */ const MR_Box optimize__const_1090_0_1_TypeInfo_7_7[4] = {
		((MR_Box) ((&mercury__builtin__builtin__type_ctor_info_tuple_0))),
		((MR_Box) ((MR_Integer) 2)),
		((MR_Box) ((&input__input__type_ctor_info_tag_0))),
		((MR_Box) ((&attrs__attrs__type_ctor_info_attrs_0)))};

#line 89 "optimize.m"
bool MR_CALL optimize____Unify____tas_0_0(
#line 89 "optimize.m"
  MR_Word optimize__HeadVar__1_1,
#line 89 "optimize.m"
  MR_Word optimize__HeadVar__2_2)
#line 89 "optimize.m"
{
  {
    bool optimize__succeeded;
    MR_Word optimize__conv1_HeadVar__1_1 = (MR_Word) optimize__HeadVar__1_1;
    MR_Word optimize__conv2_HeadVar__2_2 = (MR_Word) optimize__HeadVar__2_2;
    MR_Word optimize__TypeInfo_3_3 = (MR_Word) (&input__input__type_ctor_info_tag_0);
    MR_Word optimize__TypeInfo_4_4 = (MR_Word) (&attrs__attrs__type_ctor_info_attrs_0);
    MR_Word optimize__TypeInfo_5_5 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_tuple_0);
    MR_Integer optimize__TypeArity_6 = (MR_Integer) 2;
    MR_Word optimize__TypeInfo_7_7 = (MR_Word) &optimize__const_1090_0_1_TypeInfo_7_7;

#line 89 "optimize.m"
    {
#line 89 "optimize.m"
      optimize__succeeded = mercury__list____Unify____list_1_0(optimize__TypeInfo_7_7, optimize__conv1_HeadVar__1_1, optimize__conv2_HeadVar__2_2);
    }
    if (optimize__succeeded)
      optimize__succeeded = TRUE;
    return optimize__succeeded;
  }
#line 89 "optimize.m"
}
#line 314 "optimize.m"
static /* final */ const MR_Box optimize__const_12_0_1_Tag_17[1] = {
		((MR_Box) ((MR_Integer) 0))};

static void MR_CALL optimize__gen_open_8_p_0_1(
  void * optimize__env_ptr_arg)
{
  {
    struct optimize__gen_open_8_p_0_env_0_s * optimize__env_ptr = (struct optimize__gen_open_8_p_0_env_0_s *) optimize__env_ptr_arg;

    {
#line 326 "optimize.m"
      {
#line 326 "optimize.m"
        (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = optimize__open_tag_9_p_0((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Tag_17, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, &(optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__As1_18, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__3_3, &(optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Stk1_19, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__5_5, &(optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__N1_20, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__7_7, &(optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Ts1_21);
      }
      if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
#line 327 "optimize.m"
        {
#line 327 "optimize.m"
          optimize__gen_open_8_p_0((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__As1_18, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Stk1_19, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__4_4, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__N1_20, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__6_6, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Ts1_21, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__8_8, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__cont, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__cont_env_ptr);
#line 327 "optimize.m"
          return;
        }
    }
  }
}

#line 289 "optimize.m"
static void MR_CALL optimize__gen_open_8_p_0(
#line 289 "optimize.m"
  MR_Word optimize__HeadVar__1_1,
#line 289 "optimize.m"
  MR_Word optimize__HeadVar__2_2,
#line 289 "optimize.m"
  MR_Word optimize__HeadVar__3_3,
#line 289 "optimize.m"
  MR_Word * optimize__HeadVar__4_4,
#line 289 "optimize.m"
  MR_Integer optimize__HeadVar__5_5,
#line 289 "optimize.m"
  MR_Integer * optimize__HeadVar__6_6,
#line 289 "optimize.m"
  MR_Word optimize__HeadVar__7_7,
#line 289 "optimize.m"
  MR_Word * optimize__HeadVar__8_8,
#line 289 "optimize.m"
  MR_Cont optimize__cont,
#line 289 "optimize.m"
  void * optimize__cont_env_ptr)
#line 289 "optimize.m"
{
#line 289 "optimize.m"
  {
#line 289 "optimize.m"
    struct optimize__gen_open_8_p_0_env_0_s optimize__env;
#line 289 "optimize.m"
    struct optimize__gen_open_8_p_0_env_0_s * optimize__env_ptr = &optimize__env;

#line 289 "optimize.m"
    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1 = optimize__HeadVar__1_1;
#line 289 "optimize.m"
    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2 = optimize__HeadVar__2_2;
#line 289 "optimize.m"
    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__3_3 = optimize__HeadVar__3_3;
#line 289 "optimize.m"
    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__4_4 = optimize__HeadVar__4_4;
#line 289 "optimize.m"
    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__5_5 = optimize__HeadVar__5_5;
#line 289 "optimize.m"
    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__6_6 = optimize__HeadVar__6_6;
#line 289 "optimize.m"
    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__7_7 = optimize__HeadVar__7_7;
#line 289 "optimize.m"
    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__8_8 = optimize__HeadVar__8_8;
#line 289 "optimize.m"
    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__cont = optimize__cont;
#line 289 "optimize.m"
    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__cont_env_ptr = optimize__cont_env_ptr;
#line 299 "optimize.m"
    {
#line 293 "optimize.m"
      {
#line 293 "optimize.m"
        (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = attrs__equivalent_2_p_0((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2);
      }
#line 299 "optimize.m"
      if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
        {
#line 295 "optimize.m"
          *((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__4_4) = (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__3_3;
#line 296 "optimize.m"
          *((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__6_6) = (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__5_5;
#line 297 "optimize.m"
          *((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__8_8) = (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__7_7;
          {
            ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__cont)((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__cont_env_ptr);
            return;
          }
        }
#line 299 "optimize.m"
      else
        {
#line 303 "optimize.m"
          {
            MR_Word optimize__V_50_50;
            MR_Word optimize__V_51_51 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 7)));
            MR_Word optimize__V_262_262 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 7)));
#line 302 "optimize.m"
            MR_Integer optimize__V_52_52 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 6)));
#line 302 "optimize.m"
            MR_Integer optimize__V_53_53 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 5)));
#line 302 "optimize.m"
            MR_Word optimize__V_54_54 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 4)));
#line 302 "optimize.m"
            MR_Word optimize__V_55_55 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 3)));
#line 302 "optimize.m"
            MR_Word optimize__V_56_56 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 2)));
#line 302 "optimize.m"
            MR_Word optimize__V_57_57 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 1)));
#line 302 "optimize.m"
            MR_Word optimize__V_58_58 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 0)));
#line 302 "optimize.m"
            MR_Integer optimize__V_59_59 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 6)));
#line 302 "optimize.m"
            MR_Integer optimize__V_60_60 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 5)));
#line 302 "optimize.m"
            MR_Word optimize__V_61_61 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 4)));
#line 302 "optimize.m"
            MR_Word optimize__V_62_62 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 3)));
#line 302 "optimize.m"
            MR_Word optimize__V_63_63 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 2)));
#line 302 "optimize.m"
            MR_Word optimize__V_64_64 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 1)));
#line 302 "optimize.m"
            MR_Word optimize__V_65_65 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 0)));
#line 302 "optimize.m"
            MR_Integer optimize__V_66_66;
#line 302 "optimize.m"
            MR_Integer optimize__V_67_67;
#line 302 "optimize.m"
            MR_Word optimize__V_68_68;
#line 302 "optimize.m"
            MR_Word optimize__V_69_69;
#line 302 "optimize.m"
            MR_Word optimize__V_70_70;
#line 302 "optimize.m"
            MR_Word optimize__V_71_71;
#line 302 "optimize.m"
            MR_Word optimize__V_72_72;

#line 302 "optimize.m"
            (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_51_51 == optimize__V_262_262);
#line 302 "optimize.m"
            (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = !((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded);
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
#line 302 "optimize.m"
                optimize__V_72_72 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 0)));
#line 302 "optimize.m"
                optimize__V_71_71 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 1)));
#line 302 "optimize.m"
                optimize__V_70_70 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 2)));
#line 302 "optimize.m"
                optimize__V_69_69 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 3)));
#line 302 "optimize.m"
                optimize__V_68_68 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 4)));
#line 302 "optimize.m"
                optimize__V_67_67 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 5)));
#line 302 "optimize.m"
                optimize__V_66_66 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 6)));
#line 302 "optimize.m"
                optimize__V_50_50 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 7)));
#line 302 "optimize.m"
                {
#line 302 "optimize.m"
                  (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Tag_17 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "colour"));
#line 302 "optimize.m"
                  MR_hl_field(MR_mktag(3), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Tag_17, 0) = ((MR_Box) (optimize__V_50_50));
#line 302 "optimize.m"
                }
#line 302 "optimize.m"
                (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = TRUE;
              }
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
                optimize__gen_open_8_p_0_1(optimize__env_ptr);
              }
#line 303 "optimize.m"
          }
#line 303 "optimize.m"
          {
            MR_Word optimize__V_48_48;
            MR_Word optimize__V_49_49 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 0)));
#line 304 "optimize.m"
            MR_Word optimize__V_73_73 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 7)));
#line 304 "optimize.m"
            MR_Integer optimize__V_74_74 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 6)));
#line 304 "optimize.m"
            MR_Integer optimize__V_75_75 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 5)));
#line 304 "optimize.m"
            MR_Word optimize__V_76_76 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 4)));
#line 304 "optimize.m"
            MR_Word optimize__V_77_77 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 3)));
#line 304 "optimize.m"
            MR_Word optimize__V_78_78 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 2)));
#line 304 "optimize.m"
            MR_Word optimize__V_79_79 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 1)));
#line 304 "optimize.m"
            MR_Word optimize__V_80_80;
#line 304 "optimize.m"
            MR_Integer optimize__V_81_81;
#line 304 "optimize.m"
            MR_Integer optimize__V_82_82;
#line 304 "optimize.m"
            MR_Word optimize__V_83_83;
#line 304 "optimize.m"
            MR_Word optimize__V_84_84;
#line 304 "optimize.m"
            MR_Word optimize__V_85_85;
#line 304 "optimize.m"
            MR_Word optimize__V_86_86;

#line 304 "optimize.m"
            (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_49_49 == (MR_Integer) 0);
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
#line 304 "optimize.m"
                optimize__V_48_48 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 0)));
#line 304 "optimize.m"
                optimize__V_86_86 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 1)));
#line 304 "optimize.m"
                optimize__V_85_85 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 2)));
#line 304 "optimize.m"
                optimize__V_84_84 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 3)));
#line 304 "optimize.m"
                optimize__V_83_83 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 4)));
#line 304 "optimize.m"
                optimize__V_82_82 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 5)));
#line 304 "optimize.m"
                optimize__V_81_81 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 6)));
#line 304 "optimize.m"
                optimize__V_80_80 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 7)));
#line 304 "optimize.m"
                (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_48_48 == (MR_Integer) 1);
                if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
                  {
#line 304 "optimize.m"
                    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Tag_17 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 304 "optimize.m"
                    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = TRUE;
                  }
              }
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
                optimize__gen_open_8_p_0_1(optimize__env_ptr);
              }
#line 303 "optimize.m"
          }
#line 303 "optimize.m"
          {
            MR_Word optimize__V_46_46;
            MR_Word optimize__V_47_47 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 2)));
#line 306 "optimize.m"
            MR_Word optimize__V_87_87 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 1)));
#line 306 "optimize.m"
            MR_Word optimize__V_88_88 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 0)));
#line 306 "optimize.m"
            MR_Word optimize__V_89_89 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 7)));
#line 306 "optimize.m"
            MR_Integer optimize__V_90_90 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 6)));
#line 306 "optimize.m"
            MR_Integer optimize__V_91_91 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 5)));
#line 306 "optimize.m"
            MR_Word optimize__V_92_92 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 4)));
#line 306 "optimize.m"
            MR_Word optimize__V_93_93 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 3)));
#line 306 "optimize.m"
            MR_Word optimize__V_94_94;
#line 306 "optimize.m"
            MR_Word optimize__V_95_95;
#line 306 "optimize.m"
            MR_Word optimize__V_96_96;
#line 306 "optimize.m"
            MR_Integer optimize__V_97_97;
#line 306 "optimize.m"
            MR_Integer optimize__V_98_98;
#line 306 "optimize.m"
            MR_Word optimize__V_99_99;
#line 306 "optimize.m"
            MR_Word optimize__V_100_100;

#line 306 "optimize.m"
            (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_47_47 == (MR_Integer) 0);
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
#line 306 "optimize.m"
                optimize__V_95_95 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 0)));
#line 306 "optimize.m"
                optimize__V_94_94 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 1)));
#line 306 "optimize.m"
                optimize__V_46_46 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 2)));
#line 306 "optimize.m"
                optimize__V_100_100 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 3)));
#line 306 "optimize.m"
                optimize__V_99_99 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 4)));
#line 306 "optimize.m"
                optimize__V_98_98 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 5)));
#line 306 "optimize.m"
                optimize__V_97_97 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 6)));
#line 306 "optimize.m"
                optimize__V_96_96 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 7)));
#line 306 "optimize.m"
                (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_46_46 == (MR_Integer) 1);
                if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
                  {
#line 306 "optimize.m"
                    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Tag_17 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 2));
#line 306 "optimize.m"
                    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = TRUE;
                  }
              }
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
                optimize__gen_open_8_p_0_1(optimize__env_ptr);
              }
#line 303 "optimize.m"
          }
#line 303 "optimize.m"
          {
            MR_Word optimize__V_44_44;
            MR_Word optimize__V_45_45 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 4)));
#line 308 "optimize.m"
            MR_Word optimize__V_101_101 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 3)));
#line 308 "optimize.m"
            MR_Word optimize__V_102_102 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 2)));
#line 308 "optimize.m"
            MR_Word optimize__V_103_103 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 1)));
#line 308 "optimize.m"
            MR_Word optimize__V_104_104 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 0)));
#line 308 "optimize.m"
            MR_Word optimize__V_105_105 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 7)));
#line 308 "optimize.m"
            MR_Integer optimize__V_106_106 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 6)));
#line 308 "optimize.m"
            MR_Integer optimize__V_107_107 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 5)));
#line 308 "optimize.m"
            MR_Word optimize__V_108_108;
#line 308 "optimize.m"
            MR_Word optimize__V_109_109;
#line 308 "optimize.m"
            MR_Word optimize__V_110_110;
#line 308 "optimize.m"
            MR_Word optimize__V_111_111;
#line 308 "optimize.m"
            MR_Word optimize__V_112_112;
#line 308 "optimize.m"
            MR_Integer optimize__V_113_113;
#line 308 "optimize.m"
            MR_Integer optimize__V_114_114;

#line 308 "optimize.m"
            (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_45_45 == (MR_Integer) 0);
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
#line 308 "optimize.m"
                optimize__V_111_111 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 0)));
#line 308 "optimize.m"
                optimize__V_110_110 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 1)));
#line 308 "optimize.m"
                optimize__V_109_109 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 2)));
#line 308 "optimize.m"
                optimize__V_108_108 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 3)));
#line 308 "optimize.m"
                optimize__V_44_44 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 4)));
#line 308 "optimize.m"
                optimize__V_114_114 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 5)));
#line 308 "optimize.m"
                optimize__V_113_113 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 6)));
#line 308 "optimize.m"
                optimize__V_112_112 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 7)));
#line 308 "optimize.m"
                (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_44_44 == (MR_Integer) 1);
                if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
                  {
#line 308 "optimize.m"
                    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Tag_17 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 5));
#line 308 "optimize.m"
                    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = TRUE;
                  }
              }
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
                optimize__gen_open_8_p_0_1(optimize__env_ptr);
              }
#line 303 "optimize.m"
          }
#line 303 "optimize.m"
          {
            MR_Word optimize__V_43_43 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 1)));
            MR_Word optimize__V_263_263 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 1)));
#line 310 "optimize.m"
            MR_Word optimize__V_115_115 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 0)));
#line 310 "optimize.m"
            MR_Word optimize__V_116_116 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 7)));
#line 310 "optimize.m"
            MR_Integer optimize__V_117_117 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 6)));
#line 310 "optimize.m"
            MR_Integer optimize__V_118_118 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 5)));
#line 310 "optimize.m"
            MR_Word optimize__V_119_119 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 4)));
#line 310 "optimize.m"
            MR_Word optimize__V_120_120 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 3)));
#line 310 "optimize.m"
            MR_Word optimize__V_121_121 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 2)));
#line 310 "optimize.m"
            MR_Word optimize__V_122_122 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 0)));
#line 310 "optimize.m"
            MR_Word optimize__V_123_123 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 7)));
#line 310 "optimize.m"
            MR_Integer optimize__V_124_124 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 6)));
#line 310 "optimize.m"
            MR_Integer optimize__V_125_125 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 5)));
#line 310 "optimize.m"
            MR_Word optimize__V_126_126 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 4)));
#line 310 "optimize.m"
            MR_Word optimize__V_127_127 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 3)));
#line 310 "optimize.m"
            MR_Word optimize__V_128_128 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 2)));

#line 310 "optimize.m"
            (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_43_43 == optimize__V_263_263);
#line 310 "optimize.m"
            (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = !((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded);
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
#line 310 "optimize.m"
                (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Tag_17 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 1));
#line 310 "optimize.m"
                (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = TRUE;
              }
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
                optimize__gen_open_8_p_0_1(optimize__env_ptr);
              }
#line 303 "optimize.m"
          }
#line 303 "optimize.m"
          {
            MR_Word optimize__V_41_41;
            MR_Word optimize__V_42_42 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 3)));
#line 312 "optimize.m"
            MR_Word optimize__V_129_129 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 2)));
#line 312 "optimize.m"
            MR_Word optimize__V_130_130 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 1)));
#line 312 "optimize.m"
            MR_Word optimize__V_131_131 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 0)));
#line 312 "optimize.m"
            MR_Word optimize__V_132_132 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 7)));
#line 312 "optimize.m"
            MR_Integer optimize__V_133_133 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 6)));
#line 312 "optimize.m"
            MR_Integer optimize__V_134_134 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 5)));
#line 312 "optimize.m"
            MR_Word optimize__V_135_135 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 4)));
#line 312 "optimize.m"
            MR_Word optimize__V_136_136;
#line 312 "optimize.m"
            MR_Word optimize__V_137_137;
#line 312 "optimize.m"
            MR_Word optimize__V_138_138;
#line 312 "optimize.m"
            MR_Word optimize__V_139_139;
#line 312 "optimize.m"
            MR_Integer optimize__V_140_140;
#line 312 "optimize.m"
            MR_Integer optimize__V_141_141;
#line 312 "optimize.m"
            MR_Word optimize__V_142_142;

#line 312 "optimize.m"
            (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_42_42 == (MR_Integer) 0);
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
#line 312 "optimize.m"
                optimize__V_138_138 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 0)));
#line 312 "optimize.m"
                optimize__V_137_137 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 1)));
#line 312 "optimize.m"
                optimize__V_136_136 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 2)));
#line 312 "optimize.m"
                optimize__V_41_41 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 3)));
#line 312 "optimize.m"
                optimize__V_142_142 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 4)));
#line 312 "optimize.m"
                optimize__V_141_141 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 5)));
#line 312 "optimize.m"
                optimize__V_140_140 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 6)));
#line 312 "optimize.m"
                optimize__V_139_139 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 7)));
#line 312 "optimize.m"
                (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_41_41 == (MR_Integer) 1);
                if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
                  {
#line 312 "optimize.m"
                    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Tag_17 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 4));
#line 312 "optimize.m"
                    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = TRUE;
                  }
              }
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
                optimize__gen_open_8_p_0_1(optimize__env_ptr);
              }
#line 303 "optimize.m"
          }
#line 303 "optimize.m"
          {
            MR_Integer optimize__V_36_36;
            MR_Integer optimize__V_39_39 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 5)));
            MR_Integer optimize__V_40_40;
            MR_Integer optimize__V_281_281 = (MR_Integer) 3;
#line 314 "optimize.m"
            MR_Word optimize__V_143_143 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 4)));
#line 314 "optimize.m"
            MR_Word optimize__V_144_144 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 3)));
#line 314 "optimize.m"
            MR_Word optimize__V_145_145 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 2)));
#line 314 "optimize.m"
            MR_Word optimize__V_146_146 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 1)));
#line 314 "optimize.m"
            MR_Word optimize__V_147_147 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 0)));
#line 314 "optimize.m"
            MR_Word optimize__V_148_148 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 7)));
#line 314 "optimize.m"
            MR_Integer optimize__V_149_149 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 6)));
#line 314 "optimize.m"
            MR_Word optimize__V_150_150;
#line 314 "optimize.m"
            MR_Word optimize__V_151_151;
#line 314 "optimize.m"
            MR_Word optimize__V_152_152;
#line 314 "optimize.m"
            MR_Word optimize__V_153_153;
#line 314 "optimize.m"
            MR_Word optimize__V_154_154;
#line 314 "optimize.m"
            MR_Word optimize__V_155_155;
#line 314 "optimize.m"
            MR_Integer optimize__V_156_156;

#line 314 "optimize.m"
            (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_39_39 < optimize__V_281_281);
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
#line 314 "optimize.m"
                optimize__V_154_154 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 0)));
#line 314 "optimize.m"
                optimize__V_153_153 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 1)));
#line 314 "optimize.m"
                optimize__V_152_152 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 2)));
#line 314 "optimize.m"
                optimize__V_151_151 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 3)));
#line 314 "optimize.m"
                optimize__V_150_150 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 4)));
#line 314 "optimize.m"
                optimize__V_40_40 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 5)));
#line 314 "optimize.m"
                optimize__V_156_156 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 6)));
#line 314 "optimize.m"
                optimize__V_155_155 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 7)));
#line 314 "optimize.m"
                (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_39_39 < optimize__V_40_40);
                if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
                  {
#line 314 "optimize.m"
                    optimize__V_36_36 = (MR_Integer) 0;
#line 314 "optimize.m"
                    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Tag_17 = (MR_Word) MR_mkword(MR_mktag(1), &optimize__const_12_0_1_Tag_17);
#line 314 "optimize.m"
                    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = TRUE;
                  }
              }
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
                optimize__gen_open_8_p_0_1(optimize__env_ptr);
              }
#line 303 "optimize.m"
          }
#line 303 "optimize.m"
          {
            MR_Integer optimize__V_34_34;
            MR_Integer optimize__V_35_35 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 6)));
            MR_Integer optimize__V_264_264 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 6)));
#line 316 "optimize.m"
            MR_Integer optimize__V_164_164 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 5)));
#line 316 "optimize.m"
            MR_Word optimize__V_165_165 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 4)));
#line 316 "optimize.m"
            MR_Word optimize__V_166_166 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 3)));
#line 316 "optimize.m"
            MR_Word optimize__V_167_167 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 2)));
#line 316 "optimize.m"
            MR_Word optimize__V_168_168 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 1)));
#line 316 "optimize.m"
            MR_Word optimize__V_169_169 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 0)));
#line 316 "optimize.m"
            MR_Word optimize__V_170_170 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 7)));
#line 316 "optimize.m"
            MR_Integer optimize__V_171_171 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 5)));
#line 316 "optimize.m"
            MR_Word optimize__V_172_172 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 4)));
#line 316 "optimize.m"
            MR_Word optimize__V_173_173 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 3)));
#line 316 "optimize.m"
            MR_Word optimize__V_174_174 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 2)));
#line 316 "optimize.m"
            MR_Word optimize__V_175_175 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 1)));
#line 316 "optimize.m"
            MR_Word optimize__V_176_176 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 0)));
#line 316 "optimize.m"
            MR_Word optimize__V_177_177 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 7)));
#line 316 "optimize.m"
            MR_Integer optimize__V_178_178;
#line 316 "optimize.m"
            MR_Word optimize__V_179_179;
#line 316 "optimize.m"
            MR_Word optimize__V_180_180;
#line 316 "optimize.m"
            MR_Word optimize__V_181_181;
#line 316 "optimize.m"
            MR_Word optimize__V_182_182;
#line 316 "optimize.m"
            MR_Word optimize__V_183_183;
#line 316 "optimize.m"
            MR_Word optimize__V_184_184;

#line 316 "optimize.m"
            (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_35_35 == optimize__V_264_264);
#line 316 "optimize.m"
            (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = !((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded);
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
#line 316 "optimize.m"
                optimize__V_183_183 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 0)));
#line 316 "optimize.m"
                optimize__V_182_182 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 1)));
#line 316 "optimize.m"
                optimize__V_181_181 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 2)));
#line 316 "optimize.m"
                optimize__V_180_180 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 3)));
#line 316 "optimize.m"
                optimize__V_179_179 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 4)));
#line 316 "optimize.m"
                optimize__V_178_178 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 5)));
#line 316 "optimize.m"
                optimize__V_34_34 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 6)));
#line 316 "optimize.m"
                optimize__V_184_184 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 7)));
#line 316 "optimize.m"
                {
#line 316 "optimize.m"
                  (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Tag_17 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "size"));
#line 316 "optimize.m"
                  MR_hl_field(MR_mktag(2), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Tag_17, 0) = ((MR_Box) (optimize__V_34_34));
#line 316 "optimize.m"
                }
#line 316 "optimize.m"
                (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = TRUE;
              }
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
                optimize__gen_open_8_p_0_1(optimize__env_ptr);
              }
#line 303 "optimize.m"
          }
#line 303 "optimize.m"
          {
            MR_Integer optimize__V_267_267 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 5)));
            MR_Word optimize__V_268_268 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 4)));
            MR_Word optimize__V_270_270 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 2)));
            MR_Word optimize__V_271_271 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 1)));
            MR_Word optimize__V_272_272 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 0)));
            MR_Integer optimize__V_275_275 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 5)));
            MR_Word optimize__V_276_276 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 4)));
            MR_Word optimize__V_278_278 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 2)));
            MR_Word optimize__V_280_280 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 0)));
#line 318 "optimize.m"
            MR_Word optimize__V_265_265 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 7)));
#line 318 "optimize.m"
            MR_Integer optimize__V_266_266 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 6)));
#line 318 "optimize.m"
            MR_Word optimize__V_269_269 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__1_1, (MR_Integer) 3)));
#line 318 "optimize.m"
            MR_Word optimize__V_273_273 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 7)));
#line 318 "optimize.m"
            MR_Integer optimize__V_274_274 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 6)));
#line 318 "optimize.m"
            MR_Word optimize__V_277_277 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 3)));
#line 318 "optimize.m"
            MR_Word optimize__V_279_279 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 1)));

#line 318 "optimize.m"
            (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_272_272 == (MR_Integer) 1);
#line 318 "optimize.m"
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
#line 318 "optimize.m"
              (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_280_280 == (MR_Integer) 0);
#line 319 "optimize.m"
            if (!((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded))
#line 319 "optimize.m"
              {
#line 319 "optimize.m"
                (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_270_270 == (MR_Integer) 1);
#line 319 "optimize.m"
                if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
#line 319 "optimize.m"
                  (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_278_278 == (MR_Integer) 0);
#line 319 "optimize.m"
                if (!((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded))
#line 319 "optimize.m"
                  {
#line 320 "optimize.m"
                    (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_268_268 == (MR_Integer) 1);
#line 320 "optimize.m"
                    if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
#line 320 "optimize.m"
                      (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_276_276 == (MR_Integer) 0);
#line 319 "optimize.m"
                    if (!((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded))
#line 319 "optimize.m"
                      {
#line 321 "optimize.m"
                        (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_271_271 == (MR_Integer) 1);
#line 321 "optimize.m"
                        if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
#line 321 "optimize.m"
                          (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_276_276 == (MR_Integer) 0);
#line 319 "optimize.m"
                        if (!((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded))
#line 319 "optimize.m"
                          {
#line 322 "optimize.m"
                            MR_Integer optimize__V_22_22;
#line 322 "optimize.m"
                            MR_Integer optimize__V_23_23;
#line 322 "optimize.m"
                            MR_Word optimize__V_255_255;
#line 322 "optimize.m"
                            MR_Word optimize__V_256_256;
#line 322 "optimize.m"
                            MR_Word optimize__V_257_257;
#line 322 "optimize.m"
                            MR_Word optimize__V_258_258;
#line 322 "optimize.m"
                            MR_Word optimize__V_259_259;
#line 322 "optimize.m"
                            MR_Word optimize__V_260_260;
#line 322 "optimize.m"
                            MR_Integer optimize__V_261_261;

#line 322 "optimize.m"
                            (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_267_267 > optimize__V_275_275);
#line 322 "optimize.m"
                            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
#line 322 "optimize.m"
                              {
#line 322 "optimize.m"
                                optimize__V_259_259 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 0)));
#line 322 "optimize.m"
                                optimize__V_258_258 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 1)));
#line 322 "optimize.m"
                                optimize__V_257_257 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 2)));
#line 322 "optimize.m"
                                optimize__V_256_256 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 3)));
#line 322 "optimize.m"
                                optimize__V_255_255 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 4)));
#line 322 "optimize.m"
                                optimize__V_22_22 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 5)));
#line 322 "optimize.m"
                                optimize__V_261_261 = ((MR_Integer) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 6)));
#line 322 "optimize.m"
                                optimize__V_260_260 = ((MR_Word) (MR_hl_field(MR_mktag(0), (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__HeadVar__2_2, (MR_Integer) 7)));
#line 322 "optimize.m"
                                optimize__V_23_23 = (MR_Integer) 3;
#line 322 "optimize.m"
                                (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = (optimize__V_22_22 < optimize__V_23_23);
#line 322 "optimize.m"
                              }
#line 319 "optimize.m"
                          }
#line 319 "optimize.m"
                      }
#line 319 "optimize.m"
                  }
#line 319 "optimize.m"
              }
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
#line 324 "optimize.m"
                (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__Tag_17 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 3));
#line 324 "optimize.m"
                (optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded = TRUE;
              }
            if ((optimize__env_ptr)->optimize__gen_open_8_p_0_env_0__succeeded)
              {
                optimize__gen_open_8_p_0_1(optimize__env_ptr);
                return;
              }
#line 303 "optimize.m"
          }
        }
#line 299 "optimize.m"
    }
#line 289 "optimize.m"
  }
#line 289 "optimize.m"
}

#line 270 "optimize.m"
static bool MR_CALL optimize__open_tag_9_p_0(
#line 270 "optimize.m"
  MR_Word optimize__HeadVar__1_1,
#line 270 "optimize.m"
  MR_Word optimize__HeadVar__2_2,
#line 270 "optimize.m"
  MR_Word * optimize__HeadVar__3_3,
#line 270 "optimize.m"
  MR_Word optimize__HeadVar__4_4,
#line 270 "optimize.m"
  MR_Word * optimize__HeadVar__5_5,
#line 270 "optimize.m"
  MR_Integer optimize__HeadVar__6_6,
#line 270 "optimize.m"
  MR_Integer * optimize__HeadVar__7_7,
#line 270 "optimize.m"
  MR_Word optimize__HeadVar__8_8,
#line 270 "optimize.m"
  MR_Word * optimize__HeadVar__9_9)
#line 270 "optimize.m"
{
  {
    bool optimize__succeeded;
    MR_Integer optimize__V_18_18;
    MR_Integer optimize__V_19_19 = (MR_Integer) 1;
    MR_Integer optimize__V_20_20;
    MR_Tuple optimize__V_21_21;
    MR_Word optimize__V_22_22;
    MR_Integer optimize__V_24_24;

#line 272 "optimize.m"
    {
#line 272 "optimize.m"
      optimize__V_21_21 = (MR_Tuple) MR_new_object(MR_Tuple, ((MR_Integer) 2 * sizeof(MR_Word)), "{}/2");
#line 272 "optimize.m"
      MR_hl_field(MR_mktag(0), optimize__V_21_21, 0) = ((MR_Box) (optimize__HeadVar__1_1));
#line 272 "optimize.m"
      MR_hl_field(MR_mktag(0), optimize__V_21_21, 1) = ((MR_Box) (optimize__HeadVar__2_2));
#line 272 "optimize.m"
    }
#line 272 "optimize.m"
    {
#line 272 "optimize.m"
      *optimize__HeadVar__5_5 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 272 "optimize.m"
      MR_hl_field(MR_mktag(1), *optimize__HeadVar__5_5, 0) = ((MR_Box) (optimize__V_21_21));
#line 272 "optimize.m"
      MR_hl_field(MR_mktag(1), *optimize__HeadVar__5_5, 1) = ((MR_Box) (optimize__HeadVar__4_4));
#line 272 "optimize.m"
    }
#line 272 "optimize.m"
    {
#line 272 "optimize.m"
      optimize__V_22_22 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "open");
#line 272 "optimize.m"
      MR_hl_field(MR_mktag(0), optimize__V_22_22, 0) = ((MR_Box) (optimize__HeadVar__1_1));
#line 272 "optimize.m"
    }
#line 272 "optimize.m"
    {
#line 272 "optimize.m"
      *optimize__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 272 "optimize.m"
      MR_hl_field(MR_mktag(1), *optimize__HeadVar__9_9, 0) = ((MR_Box) (optimize__V_22_22));
#line 272 "optimize.m"
      MR_hl_field(MR_mktag(1), *optimize__HeadVar__9_9, 1) = ((MR_Box) (optimize__HeadVar__8_8));
#line 272 "optimize.m"
    }
#line 281 "optimize.m"
    if ((optimize__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 1))))
      optimize__succeeded = TRUE;
#line 281 "optimize.m"
    else
#line 281 "optimize.m"
      if ((optimize__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 3))))
        optimize__succeeded = TRUE;
#line 281 "optimize.m"
      else
#line 281 "optimize.m"
        optimize__succeeded = FALSE;
#line 281 "optimize.m"
    if (optimize__succeeded)
#line 281 "optimize.m"
      optimize__V_20_20 = (MR_Integer) 2;
#line 281 "optimize.m"
    else
#line 281 "optimize.m"
      optimize__V_20_20 = (MR_Integer) 1;
#line 273 "optimize.m"
    optimize__V_18_18 = (optimize__V_19_19 + optimize__V_20_20);
#line 273 "optimize.m"
    *optimize__HeadVar__7_7 = (optimize__HeadVar__6_6 - optimize__V_18_18);
#line 274 "optimize.m"
    optimize__V_24_24 = (MR_Integer) 0;
#line 274 "optimize.m"
    optimize__succeeded = (*optimize__HeadVar__7_7 >= optimize__V_24_24);
    if (optimize__succeeded)
      {
#line 275 "optimize.m"
        {
#line 275 "optimize.m"
          *optimize__HeadVar__3_3 = input__apply_tag_3_f_0(optimize__HeadVar__1_1, optimize__HeadVar__2_2);
        }
#line 275 "optimize.m"
        optimize__succeeded = TRUE;
      }
    return optimize__succeeded;
  }
#line 270 "optimize.m"
}

#line 217 "optimize.m"
static void MR_CALL optimize__gen_8_p_0(
#line 217 "optimize.m"
  MR_Word optimize__HeadVar__1_1,
#line 217 "optimize.m"
  MR_Word optimize__HeadVar__2_2,
#line 217 "optimize.m"
  MR_Word optimize__HeadVar__3_3,
#line 217 "optimize.m"
  MR_Word * optimize__HeadVar__4_4,
#line 217 "optimize.m"
  MR_Integer optimize__HeadVar__5_5,
#line 217 "optimize.m"
  MR_Integer * optimize__HeadVar__6_6,
#line 217 "optimize.m"
  MR_Word optimize__HeadVar__7_7,
#line 217 "optimize.m"
  MR_Word * optimize__HeadVar__8_8,
#line 217 "optimize.m"
  MR_Cont optimize__cont,
#line 217 "optimize.m"
  void * optimize__cont_env_ptr)
#line 217 "optimize.m"
{
#line 227 "optimize.m"
  {
#line 227 "optimize.m"
    /* tailcall optimized into a loop */
#line 227 "optimize.m"
  loop_top:;
#line 227 "optimize.m"
    {
#line 227 "optimize.m"
      bool optimize__succeeded;

#line 221 "optimize.m"
      {
#line 221 "optimize.m"
        optimize__succeeded = attrs__equivalent_2_p_0(optimize__HeadVar__1_1, optimize__HeadVar__2_2);
      }
#line 227 "optimize.m"
      if (optimize__succeeded)
        {
#line 223 "optimize.m"
          *optimize__HeadVar__4_4 = optimize__HeadVar__3_3;
#line 224 "optimize.m"
          *optimize__HeadVar__6_6 = optimize__HeadVar__5_5;
#line 225 "optimize.m"
          *optimize__HeadVar__8_8 = optimize__HeadVar__7_7;
          {
            optimize__cont(optimize__cont_env_ptr);
            return;
          }
        }
#line 227 "optimize.m"
      else
#line 232 "optimize.m"
        {
          MR_Word optimize__V_33_33;
          MR_Word optimize__V_34_34 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 7)));
#line 249 "optimize.m"
          MR_Integer optimize__V_35_35 = ((MR_Integer) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 6)));
#line 249 "optimize.m"
          MR_Integer optimize__V_36_36 = ((MR_Integer) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 5)));
#line 249 "optimize.m"
          MR_Word optimize__V_37_37 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 4)));
#line 249 "optimize.m"
          MR_Word optimize__V_38_38 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 3)));
#line 249 "optimize.m"
          MR_Word optimize__V_39_39 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 2)));
#line 249 "optimize.m"
          MR_Word optimize__V_40_40 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 1)));
#line 249 "optimize.m"
          MR_Word optimize__V_41_41 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 0)));
#line 249 "optimize.m"
          MR_Integer optimize__V_42_42;
#line 249 "optimize.m"
          MR_Integer optimize__V_43_43;
#line 249 "optimize.m"
          MR_Word optimize__V_44_44;
#line 249 "optimize.m"
          MR_Word optimize__V_45_45;
#line 249 "optimize.m"
          MR_Word optimize__V_46_46;
#line 249 "optimize.m"
          MR_Word optimize__V_47_47;
#line 249 "optimize.m"
          MR_Word optimize__V_48_48;

#line 249 "optimize.m"
          optimize__succeeded = (optimize__V_34_34 == (MR_Integer) 8);
#line 249 "optimize.m"
          optimize__succeeded = !(optimize__succeeded);
          if (optimize__succeeded)
            {
#line 249 "optimize.m"
              optimize__V_48_48 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 0)));
#line 249 "optimize.m"
              optimize__V_47_47 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 1)));
#line 249 "optimize.m"
              optimize__V_46_46 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 2)));
#line 249 "optimize.m"
              optimize__V_45_45 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 3)));
#line 249 "optimize.m"
              optimize__V_44_44 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 4)));
#line 249 "optimize.m"
              optimize__V_43_43 = ((MR_Integer) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 5)));
#line 249 "optimize.m"
              optimize__V_42_42 = ((MR_Integer) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 6)));
#line 249 "optimize.m"
              optimize__V_33_33 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 7)));
#line 249 "optimize.m"
              optimize__succeeded = (optimize__V_33_33 == (MR_Integer) 8);
            }
#line 250 "optimize.m"
          if (!(optimize__succeeded))
#line 250 "optimize.m"
            {
              MR_Integer optimize__V_31_31;
              MR_Integer optimize__V_87_87;
              MR_Integer optimize__V_32_32 = ((MR_Integer) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 6)));
              MR_Integer optimize__V_88_88 = (MR_Integer) -1;
#line 251 "optimize.m"
              MR_Integer optimize__V_49_49 = ((MR_Integer) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 5)));
#line 251 "optimize.m"
              MR_Word optimize__V_50_50 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 4)));
#line 251 "optimize.m"
              MR_Word optimize__V_51_51 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 3)));
#line 251 "optimize.m"
              MR_Word optimize__V_52_52 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 2)));
#line 251 "optimize.m"
              MR_Word optimize__V_53_53 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 1)));
#line 251 "optimize.m"
              MR_Word optimize__V_54_54 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 0)));
#line 251 "optimize.m"
              MR_Word optimize__V_55_55 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__1_1, (MR_Integer) 7)));
#line 251 "optimize.m"
              MR_Integer optimize__V_56_56;
#line 251 "optimize.m"
              MR_Word optimize__V_57_57;
#line 251 "optimize.m"
              MR_Word optimize__V_58_58;
#line 251 "optimize.m"
              MR_Word optimize__V_59_59;
#line 251 "optimize.m"
              MR_Word optimize__V_60_60;
#line 251 "optimize.m"
              MR_Word optimize__V_61_61;
#line 251 "optimize.m"
              MR_Word optimize__V_62_62;

#line 251 "optimize.m"
              optimize__succeeded = (optimize__V_32_32 == optimize__V_88_88);
#line 251 "optimize.m"
              optimize__succeeded = !(optimize__succeeded);
              if (optimize__succeeded)
                {
#line 251 "optimize.m"
                  optimize__V_61_61 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 0)));
#line 251 "optimize.m"
                  optimize__V_60_60 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 1)));
#line 251 "optimize.m"
                  optimize__V_59_59 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 2)));
#line 251 "optimize.m"
                  optimize__V_58_58 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 3)));
#line 251 "optimize.m"
                  optimize__V_57_57 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 4)));
#line 251 "optimize.m"
                  optimize__V_56_56 = ((MR_Integer) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 5)));
#line 251 "optimize.m"
                  optimize__V_31_31 = ((MR_Integer) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 6)));
#line 251 "optimize.m"
                  optimize__V_62_62 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__HeadVar__2_2, (MR_Integer) 7)));
#line 3 "attrs.opt"
                  optimize__V_87_87 = (MR_Integer) -1;
#line 251 "optimize.m"
                  optimize__succeeded = (optimize__V_31_31 == optimize__V_87_87);
                }
#line 250 "optimize.m"
            }
#line 232 "optimize.m"
          if (optimize__succeeded)
            {
              MR_Word optimize__Stk1_17;
              MR_Integer optimize__N1_18;
              MR_Word optimize__Ts1_19;
              MR_Word optimize__As1_20;
              MR_Word optimize__Tag_65;
              MR_Integer optimize__V_72_72;
              MR_Tuple optimize__V_73_73;
              MR_Word optimize__V_74_74;
              MR_Integer optimize__V_89_89;

#line 261 "optimize.m"
              optimize__succeeded = (MR_tag((MR_Word) optimize__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 261 "optimize.m"
              if ((MR_tag((MR_Word) optimize__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 261 "optimize.m"
                {
#line 261 "optimize.m"
                  optimize__V_73_73 = ((MR_Tuple) (MR_hl_field(MR_mktag(1), optimize__HeadVar__3_3, (MR_Integer) 0)));
#line 261 "optimize.m"
                  optimize__Stk1_17 = ((MR_Word) (MR_hl_field(MR_mktag(1), optimize__HeadVar__3_3, (MR_Integer) 1)));
#line 261 "optimize.m"
                }
              if (optimize__succeeded)
                {
#line 261 "optimize.m"
                  optimize__Tag_65 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__V_73_73, (MR_Integer) 0)));
#line 261 "optimize.m"
                  optimize__As1_20 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__V_73_73, (MR_Integer) 1)));
#line 261 "optimize.m"
                  {
#line 261 "optimize.m"
                    optimize__V_74_74 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "close"));
#line 261 "optimize.m"
                    MR_hl_field(MR_mktag(1), optimize__V_74_74, 0) = ((MR_Box) (optimize__Tag_65));
#line 261 "optimize.m"
                  }
#line 261 "optimize.m"
                  {
#line 261 "optimize.m"
                    optimize__Ts1_19 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 261 "optimize.m"
                    MR_hl_field(MR_mktag(1), optimize__Ts1_19, 0) = ((MR_Box) (optimize__V_74_74));
#line 261 "optimize.m"
                    MR_hl_field(MR_mktag(1), optimize__Ts1_19, 1) = ((MR_Box) (optimize__HeadVar__7_7));
#line 261 "optimize.m"
                  }
#line 281 "optimize.m"
                  if ((optimize__Tag_65 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 1))))
                    optimize__succeeded = TRUE;
#line 281 "optimize.m"
                  else
#line 281 "optimize.m"
                    if ((optimize__Tag_65 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 3))))
                      optimize__succeeded = TRUE;
#line 281 "optimize.m"
                    else
#line 281 "optimize.m"
                      optimize__succeeded = FALSE;
#line 281 "optimize.m"
                  if (optimize__succeeded)
#line 281 "optimize.m"
                    optimize__V_72_72 = (MR_Integer) 2;
#line 281 "optimize.m"
                  else
#line 281 "optimize.m"
                    optimize__V_72_72 = (MR_Integer) 1;
#line 262 "optimize.m"
                  optimize__N1_18 = (optimize__HeadVar__5_5 - optimize__V_72_72);
#line 263 "optimize.m"
                  optimize__V_89_89 = (MR_Integer) 0;
#line 263 "optimize.m"
                  optimize__succeeded = (optimize__N1_18 >= optimize__V_89_89);
                  if (optimize__succeeded)
#line 230 "optimize.m"
                    {
#line 230 "optimize.m"
                      /* direct tailcall eliminated */
#line 230 "optimize.m"
                      {
#line 230 "optimize.m"
                        MR_Word optimize__HeadVar__1__tmp_copy_1 = optimize__As1_20;
#line 230 "optimize.m"
                        MR_Word optimize__HeadVar__3__tmp_copy_3 = optimize__Stk1_17;
#line 230 "optimize.m"
                        MR_Integer optimize__HeadVar__5__tmp_copy_5 = optimize__N1_18;
#line 230 "optimize.m"
                        MR_Word optimize__HeadVar__7__tmp_copy_7 = optimize__Ts1_19;

#line 230 "optimize.m"
                        optimize__HeadVar__1_1 = optimize__HeadVar__1__tmp_copy_1;
#line 230 "optimize.m"
                        optimize__HeadVar__3_3 = optimize__HeadVar__3__tmp_copy_3;
#line 230 "optimize.m"
                        optimize__HeadVar__5_5 = optimize__HeadVar__5__tmp_copy_5;
#line 230 "optimize.m"
                        optimize__HeadVar__7_7 = optimize__HeadVar__7__tmp_copy_7;
#line 230 "optimize.m"
                      }
#line 230 "optimize.m"
                      goto loop_top;
#line 230 "optimize.m"
                    }
                }
            }
#line 232 "optimize.m"
          else
#line 237 "optimize.m"
            {
#line 237 "optimize.m"
              {
                MR_Word optimize__Stk1_21;
                MR_Integer optimize__N1_22;
                MR_Word optimize__Ts1_23;
                MR_Word optimize__As1_24;
                MR_Word optimize__Tag_76;
                MR_Integer optimize__V_83_83;
                MR_Tuple optimize__V_84_84;
                MR_Word optimize__V_85_85;
                MR_Integer optimize__V_90_90;

#line 261 "optimize.m"
                optimize__succeeded = (MR_tag((MR_Word) optimize__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 261 "optimize.m"
                if ((MR_tag((MR_Word) optimize__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 261 "optimize.m"
                  {
#line 261 "optimize.m"
                    optimize__V_84_84 = ((MR_Tuple) (MR_hl_field(MR_mktag(1), optimize__HeadVar__3_3, (MR_Integer) 0)));
#line 261 "optimize.m"
                    optimize__Stk1_21 = ((MR_Word) (MR_hl_field(MR_mktag(1), optimize__HeadVar__3_3, (MR_Integer) 1)));
#line 261 "optimize.m"
                  }
                if (optimize__succeeded)
                  {
#line 261 "optimize.m"
                    optimize__Tag_76 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__V_84_84, (MR_Integer) 0)));
#line 261 "optimize.m"
                    optimize__As1_24 = ((MR_Word) (MR_hl_field(MR_mktag(0), optimize__V_84_84, (MR_Integer) 1)));
#line 261 "optimize.m"
                    {
#line 261 "optimize.m"
                      optimize__V_85_85 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "close"));
#line 261 "optimize.m"
                      MR_hl_field(MR_mktag(1), optimize__V_85_85, 0) = ((MR_Box) (optimize__Tag_76));
#line 261 "optimize.m"
                    }
#line 261 "optimize.m"
                    {
#line 261 "optimize.m"
                      optimize__Ts1_23 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 261 "optimize.m"
                      MR_hl_field(MR_mktag(1), optimize__Ts1_23, 0) = ((MR_Box) (optimize__V_85_85));
#line 261 "optimize.m"
                      MR_hl_field(MR_mktag(1), optimize__Ts1_23, 1) = ((MR_Box) (optimize__HeadVar__7_7));
#line 261 "optimize.m"
                    }
#line 281 "optimize.m"
                    if ((optimize__Tag_76 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 1))))
                      optimize__succeeded = TRUE;
#line 281 "optimize.m"
                    else
#line 281 "optimize.m"
                      if ((optimize__Tag_76 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 3))))
                        optimize__succeeded = TRUE;
#line 281 "optimize.m"
                      else
#line 281 "optimize.m"
                        optimize__succeeded = FALSE;
#line 281 "optimize.m"
                    if (optimize__succeeded)
#line 281 "optimize.m"
                      optimize__V_83_83 = (MR_Integer) 2;
#line 281 "optimize.m"
                    else
#line 281 "optimize.m"
                      optimize__V_83_83 = (MR_Integer) 1;
#line 262 "optimize.m"
                    optimize__N1_22 = (optimize__HeadVar__5_5 - optimize__V_83_83);
#line 263 "optimize.m"
                    optimize__V_90_90 = (MR_Integer) 0;
#line 263 "optimize.m"
                    optimize__succeeded = (optimize__N1_22 >= optimize__V_90_90);
                    if (optimize__succeeded)
#line 236 "optimize.m"
                      {
#line 236 "optimize.m"
                        optimize__gen_8_p_0(optimize__As1_24, optimize__HeadVar__2_2, optimize__Stk1_21, optimize__HeadVar__4_4, optimize__N1_22, optimize__HeadVar__6_6, optimize__Ts1_23, optimize__HeadVar__8_8, optimize__cont, optimize__cont_env_ptr);
                      }
                  }
#line 237 "optimize.m"
              }
#line 238 "optimize.m"
              {
#line 238 "optimize.m"
                optimize__gen_open_8_p_0(optimize__HeadVar__1_1, optimize__HeadVar__2_2, optimize__HeadVar__3_3, optimize__HeadVar__4_4, optimize__HeadVar__5_5, optimize__HeadVar__6_6, optimize__HeadVar__7_7, optimize__HeadVar__8_8, optimize__cont, optimize__cont_env_ptr);
#line 238 "optimize.m"
                return;
              }
#line 237 "optimize.m"
            }
#line 232 "optimize.m"
        }
#line 227 "optimize.m"
    }
#line 227 "optimize.m"
  }
#line 217 "optimize.m"
}

static void MR_CALL optimize__gen_n_10_p_0_1(
  void * optimize__env_ptr_arg)
{
  {
    struct optimize__gen_n_10_p_0_env_0_s * optimize__env_ptr = (struct optimize__gen_n_10_p_0_env_0_s *) optimize__env_ptr_arg;

    {
      (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__TypeInfo_31_31 = (MR_Word) (&input__input__type_ctor_info_token_0);
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__V_5_42 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        mercury__list__reverse_2_3_p_0((optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__TypeInfo_31_31, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__Ts0_24, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__V_5_42, &(optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__Ts_25);
      }
#line 206 "optimize.m"
      (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__V_28_28 = (MR_Integer) 1;
#line 206 "optimize.m"
      (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__V_26_26 = ((optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__1_1 + (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__V_28_28);
#line 206 "optimize.m"
      {
#line 206 "optimize.m"
        (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__V_27_27 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 206 "optimize.m"
        MR_hl_field(MR_mktag(1), (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__V_27_27, 0) = ((MR_Box) ((optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__Ts_25));
#line 206 "optimize.m"
        MR_hl_field(MR_mktag(1), (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__V_27_27, 1) = ((MR_Box) ((optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__9_9));
#line 206 "optimize.m"
      }
#line 206 "optimize.m"
      {
#line 206 "optimize.m"
        optimize__gen_n_10_p_0((optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__V_26_26, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__2_2, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__AsI_21, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__4_4, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__Stk1_22, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__6_6, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__N1_23, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__8_8, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__V_27_27, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__10_10, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__cont, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__cont_env_ptr);
#line 206 "optimize.m"
        return;
      }
    }
  }
}

#line 195 "optimize.m"
static void MR_CALL optimize__gen_n_10_p_0(
#line 195 "optimize.m"
  MR_Integer optimize__HeadVar__1_1,
#line 195 "optimize.m"
  MR_Integer optimize__HeadVar__2_2,
#line 195 "optimize.m"
  MR_Word optimize__HeadVar__3_3,
#line 195 "optimize.m"
  MR_Array optimize__HeadVar__4_4,
#line 195 "optimize.m"
  MR_Word optimize__HeadVar__5_5,
#line 195 "optimize.m"
  MR_Word * optimize__HeadVar__6_6,
#line 195 "optimize.m"
  MR_Integer optimize__HeadVar__7_7,
#line 195 "optimize.m"
  MR_Integer * optimize__HeadVar__8_8,
#line 195 "optimize.m"
  MR_Word optimize__HeadVar__9_9,
#line 195 "optimize.m"
  MR_Word * optimize__HeadVar__10_10,
#line 195 "optimize.m"
  MR_Cont optimize__cont,
#line 195 "optimize.m"
  void * optimize__cont_env_ptr)
#line 195 "optimize.m"
{
#line 195 "optimize.m"
  {
#line 195 "optimize.m"
    struct optimize__gen_n_10_p_0_env_0_s optimize__env;
#line 195 "optimize.m"
    struct optimize__gen_n_10_p_0_env_0_s * optimize__env_ptr = &optimize__env;

#line 195 "optimize.m"
    (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__1_1 = optimize__HeadVar__1_1;
#line 195 "optimize.m"
    (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__2_2 = optimize__HeadVar__2_2;
#line 195 "optimize.m"
    (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__4_4 = optimize__HeadVar__4_4;
#line 195 "optimize.m"
    (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__6_6 = optimize__HeadVar__6_6;
#line 195 "optimize.m"
    (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__8_8 = optimize__HeadVar__8_8;
#line 195 "optimize.m"
    (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__9_9 = optimize__HeadVar__9_9;
#line 195 "optimize.m"
    (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__10_10 = optimize__HeadVar__10_10;
#line 195 "optimize.m"
    (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__cont = optimize__cont;
#line 195 "optimize.m"
    (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__cont_env_ptr = optimize__cont_env_ptr;
#line 202 "optimize.m"
    {
#line 202 "optimize.m"
      bool optimize__succeeded = ((optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__1_1 > (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__2_2);

#line 202 "optimize.m"
      if (optimize__succeeded)
        {
#line 199 "optimize.m"
          *((optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__6_6) = optimize__HeadVar__5_5;
#line 200 "optimize.m"
          *((optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__8_8) = optimize__HeadVar__7_7;
#line 201 "optimize.m"
          *((optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__10_10) = (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__9_9;
          {
            ((optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__cont)((optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__cont_env_ptr);
            return;
          }
        }
#line 202 "optimize.m"
      else
        {
          MR_Word optimize__V_29_29;
          MR_Word optimize__TypeInfo_30_30 = (MR_Word) (&attrs__attrs__type_ctor_info_attrs_0);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          MR_Box optimize__conv1_AsI_21;

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            mercury__array__lookup_3_p_1(optimize__TypeInfo_30_30, (MR_Array) (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__4_4, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__HeadVar__1_1, &optimize__conv1_AsI_21);
          }
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__AsI_21 = ((MR_Word) optimize__conv1_AsI_21);
#line 204 "optimize.m"
          optimize__V_29_29 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 204 "optimize.m"
          {
#line 204 "optimize.m"
            optimize__gen_8_p_0(optimize__HeadVar__3_3, (optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__AsI_21, optimize__HeadVar__5_5, &(optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__Stk1_22, optimize__HeadVar__7_7, &(optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__N1_23, optimize__V_29_29, &(optimize__env_ptr)->optimize__gen_n_10_p_0_env_0__Ts0_24, optimize__gen_n_10_p_0_1, optimize__env_ptr);
          }
        }
#line 202 "optimize.m"
    }
#line 195 "optimize.m"
  }
#line 195 "optimize.m"
}
static /* final */ const MR_Box optimize__const_5_0_1_TypeInfo_26_26[2] = {
		((MR_Box) ((&mercury__list__list__type_ctor_info_list_1))),
		((MR_Box) ((&input__input__type_ctor_info_token_0)))};

#line 184 "optimize.m"
static void MR_CALL optimize__gen_n_cc_9_p_0_1(
#line 184 "optimize.m"
  void * optimize__env_ptr_arg)
#line 184 "optimize.m"
{
#line 184 "optimize.m"
  {
#line 184 "optimize.m"
    struct optimize__gen_n_cc_9_p_0_env_0_s * optimize__env_ptr = (struct optimize__gen_n_cc_9_p_0_env_0_s *) optimize__env_ptr_arg;

#line 184 "optimize.m"
    MR_builtin_longjmp((optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__commit_1, 1);
#line 184 "optimize.m"
  }
#line 184 "optimize.m"
}

#line 184 "optimize.m"
static void MR_CALL optimize__gen_n_cc_9_p_0_2(
#line 184 "optimize.m"
  void * optimize__env_ptr_arg)
#line 184 "optimize.m"
{
#line 184 "optimize.m"
  {
#line 184 "optimize.m"
    struct optimize__gen_n_cc_9_p_0_env_0_s * optimize__env_ptr = (struct optimize__gen_n_cc_9_p_0_env_0_s *) optimize__env_ptr_arg;

#line 184 "optimize.m"
    {
#line 184 "optimize.m"
      if (MR_builtin_setjmp((optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__commit_1) == 0)
#line 184 "optimize.m"
        {
#line 184 "optimize.m"
          {
#line 184 "optimize.m"
            MR_Integer optimize__V_20_20;

#line 184 "optimize.m"
            {
#line 184 "optimize.m"
              optimize__gen_n_10_p_0((optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__2_2, (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__3_3, (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__4_4, (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__5_5, (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__6_6, &(optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__Stk1_19, (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__1_1, &optimize__V_20_20, (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__8_8, &(optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__Tss1_21, optimize__gen_n_cc_9_p_0_1, optimize__env_ptr);
            }
#line 184 "optimize.m"
          }
#line 184 "optimize.m"
          (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__succeeded = FALSE;
#line 184 "optimize.m"
        }
#line 184 "optimize.m"
      else
#line 184 "optimize.m"
        (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__succeeded = TRUE;
#line 184 "optimize.m"
    }
#line 184 "optimize.m"
  }
#line 184 "optimize.m"
}

#line 181 "optimize.m"
static void MR_CALL optimize__gen_n_cc_9_p_0(
#line 181 "optimize.m"
  MR_Integer optimize__HeadVar__1_1,
#line 181 "optimize.m"
  MR_Integer optimize__HeadVar__2_2,
#line 181 "optimize.m"
  MR_Integer optimize__HeadVar__3_3,
#line 181 "optimize.m"
  MR_Word optimize__HeadVar__4_4,
#line 181 "optimize.m"
  MR_Array optimize__HeadVar__5_5,
#line 181 "optimize.m"
  MR_Word optimize__HeadVar__6_6,
#line 181 "optimize.m"
  MR_Word * optimize__HeadVar__7_7,
#line 181 "optimize.m"
  MR_Word optimize__HeadVar__8_8,
#line 181 "optimize.m"
  MR_Word * optimize__HeadVar__9_9)
#line 181 "optimize.m"
{
#line 181 "optimize.m"
  {
#line 181 "optimize.m"
    /* tailcall optimized into a loop */
#line 181 "optimize.m"
  loop_top:;
#line 181 "optimize.m"
    {
#line 181 "optimize.m"
      struct optimize__gen_n_cc_9_p_0_env_0_s optimize__env;
#line 181 "optimize.m"
      struct optimize__gen_n_cc_9_p_0_env_0_s * optimize__env_ptr = &optimize__env;

#line 181 "optimize.m"
      (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__1_1 = optimize__HeadVar__1_1;
#line 181 "optimize.m"
      (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__2_2 = optimize__HeadVar__2_2;
#line 181 "optimize.m"
      (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__3_3 = optimize__HeadVar__3_3;
#line 181 "optimize.m"
      (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__4_4 = optimize__HeadVar__4_4;
#line 181 "optimize.m"
      (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__5_5 = optimize__HeadVar__5_5;
#line 181 "optimize.m"
      (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__6_6 = optimize__HeadVar__6_6;
#line 181 "optimize.m"
      (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__8_8 = optimize__HeadVar__8_8;
#line 186 "optimize.m"
      {
#line 184 "optimize.m"
        {
#line 184 "optimize.m"
          optimize__gen_n_cc_9_p_0_2(optimize__env_ptr);
        }
#line 186 "optimize.m"
        if ((optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__succeeded)
          {
            MR_Word optimize__TypeInfo_24_24;
            MR_Word optimize__TypeInfo_25_25;
            MR_Word optimize__TypeInfo_26_26;
            MR_Word optimize__V_5_31;

#line 185 "optimize.m"
            *optimize__HeadVar__7_7 = (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__Stk1_19;
            optimize__TypeInfo_25_25 = (MR_Word) (&mercury__list__list__type_ctor_info_list_1);
            optimize__TypeInfo_24_24 = (MR_Word) (&input__input__type_ctor_info_token_0);
            optimize__TypeInfo_26_26 = (MR_Word) &optimize__const_5_0_1_TypeInfo_26_26;
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            optimize__V_5_31 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              mercury__list__reverse_2_3_p_0(optimize__TypeInfo_26_26, (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__Tss1_21, optimize__V_5_31, optimize__HeadVar__9_9);
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              return;
            }
          }
#line 186 "optimize.m"
        else
          {
            MR_Integer optimize__V_22_22;
            MR_Integer optimize__V_23_23 = (MR_Integer) 1;

#line 186 "optimize.m"
            optimize__V_22_22 = ((optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__1_1 + optimize__V_23_23);
#line 186 "optimize.m"
            {
#line 186 "optimize.m"
              /* direct tailcall eliminated */
#line 186 "optimize.m"
              {
#line 186 "optimize.m"
                MR_Integer optimize__HeadVar__1__tmp_copy_1 = optimize__V_22_22;
#line 186 "optimize.m"
                MR_Integer optimize__HeadVar__2__tmp_copy_2 = (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__2_2;
#line 186 "optimize.m"
                MR_Integer optimize__HeadVar__3__tmp_copy_3 = (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__3_3;
#line 186 "optimize.m"
                MR_Word optimize__HeadVar__4__tmp_copy_4 = (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__4_4;
#line 186 "optimize.m"
                MR_Array optimize__HeadVar__5__tmp_copy_5 = (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__5_5;
#line 186 "optimize.m"
                MR_Word optimize__HeadVar__6__tmp_copy_6 = (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__6_6;
#line 186 "optimize.m"
                MR_Word optimize__HeadVar__8__tmp_copy_8 = (optimize__env_ptr)->optimize__gen_n_cc_9_p_0_env_0__HeadVar__8_8;

#line 186 "optimize.m"
                optimize__HeadVar__1_1 = optimize__HeadVar__1__tmp_copy_1;
#line 186 "optimize.m"
                optimize__HeadVar__2_2 = optimize__HeadVar__2__tmp_copy_2;
#line 186 "optimize.m"
                optimize__HeadVar__3_3 = optimize__HeadVar__3__tmp_copy_3;
#line 186 "optimize.m"
                optimize__HeadVar__4_4 = optimize__HeadVar__4__tmp_copy_4;
#line 186 "optimize.m"
                optimize__HeadVar__5_5 = optimize__HeadVar__5__tmp_copy_5;
#line 186 "optimize.m"
                optimize__HeadVar__6_6 = optimize__HeadVar__6__tmp_copy_6;
#line 186 "optimize.m"
                optimize__HeadVar__8_8 = optimize__HeadVar__8__tmp_copy_8;
#line 186 "optimize.m"
              }
#line 186 "optimize.m"
              goto loop_top;
#line 186 "optimize.m"
            }
          }
#line 186 "optimize.m"
      }
#line 181 "optimize.m"
    }
#line 181 "optimize.m"
  }
#line 181 "optimize.m"
}

#line 127 "optimize.m"
static void MR_CALL optimize__write_optimized_2_10_p_0(
#line 127 "optimize.m"
  MR_String optimize__HeadVar__1_1,
#line 127 "optimize.m"
  MR_Array optimize__HeadVar__2_2,
#line 127 "optimize.m"
  MR_Array optimize__HeadVar__3_3,
#line 127 "optimize.m"
  MR_Integer optimize__HeadVar__4_4,
#line 127 "optimize.m"
  MR_Integer optimize__HeadVar__5_5,
#line 127 "optimize.m"
  MR_Integer optimize__HeadVar__6_6,
#line 127 "optimize.m"
  MR_Integer optimize__HeadVar__7_7,
#line 127 "optimize.m"
  MR_Word optimize__HeadVar__8_8)
#line 127 "optimize.m"
{
#line 130 "optimize.m"
  {
#line 130 "optimize.m"
    /* tailcall optimized into a loop */
#line 130 "optimize.m"
  loop_top:;
#line 130 "optimize.m"
    {
#line 130 "optimize.m"
      bool optimize__succeeded = (optimize__HeadVar__5_5 > optimize__HeadVar__6_6);

#line 130 "optimize.m"
      if (optimize__succeeded)
        {
          MR_String optimize__V_7_76 = (MR_String) "";

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_p_0(optimize__HeadVar__8_8, optimize__V_7_76);
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            return;
          }
        }
#line 130 "optimize.m"
      else
        {
          MR_Word optimize__As_19;
          MR_Integer optimize__I_20;
          MR_Word optimize__Stk_21;
          MR_Word optimize__Tss_22;
          MR_Integer optimize__Off_23;
          MR_Integer optimize__V_28_28;
          MR_Integer optimize__V_29_29;
          MR_Integer optimize__V_30_30;
          MR_Word optimize__V_31_31;
          MR_Integer optimize__V_32_32;
          MR_Integer optimize__V_33_33;
          MR_Integer optimize__V_34_34;
          MR_Integer optimize__V_35_35;
          MR_Integer optimize__V_36_36 = (MR_Integer) 1;
          MR_Word optimize__TypeInfo_37_37;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          MR_Box optimize__conv1_As_19;

#line 133 "optimize.m"
          optimize__V_35_35 = (optimize__HeadVar__5_5 - optimize__V_36_36);
          optimize__TypeInfo_37_37 = (MR_Word) (&attrs__attrs__type_ctor_info_attrs_0);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            mercury__array__lookup_3_p_1(optimize__TypeInfo_37_37, (MR_Array) optimize__HeadVar__2_2, optimize__V_35_35, &optimize__conv1_As_19);
          }
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          optimize__As_19 = ((MR_Word) optimize__conv1_As_19);
#line 134 "optimize.m"
          optimize__V_33_33 = (optimize__HeadVar__5_5 + optimize__HeadVar__4_4);
#line 134 "optimize.m"
          optimize__V_34_34 = (MR_Integer) 1;
#line 134 "optimize.m"
          optimize__V_32_32 = (optimize__V_33_33 - optimize__V_34_34);
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
          optimize__succeeded = (optimize__V_32_32 < optimize__HeadVar__6_6);
#line 40 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
          if (optimize__succeeded)
#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
            optimize__I_20 = optimize__V_32_32;
#line 40 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
          else
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
            optimize__I_20 = optimize__HeadVar__6_6;
#line 135 "optimize.m"
          optimize__V_30_30 = (MR_Integer) 0;
#line 135 "optimize.m"
          optimize__V_31_31 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 135 "optimize.m"
          {
#line 135 "optimize.m"
            optimize__gen_n_cc_9_p_0(optimize__V_30_30, optimize__HeadVar__5_5, optimize__I_20, optimize__As_19, optimize__HeadVar__2_2, optimize__HeadVar__8_8, &optimize__Stk_21, optimize__V_31_31, &optimize__Tss_22);
          }
#line 136 "optimize.m"
          {
#line 136 "optimize.m"
            optimize__write_tokenss__ua0_9_p_0(optimize__HeadVar__1_1, optimize__HeadVar__3_3, optimize__HeadVar__5_5, optimize__HeadVar__7_7, &optimize__Off_23, optimize__Tss_22);
          }
#line 137 "optimize.m"
          optimize__V_29_29 = (MR_Integer) 1;
#line 137 "optimize.m"
          optimize__V_28_28 = (optimize__I_20 + optimize__V_29_29);
#line 137 "optimize.m"
          {
#line 137 "optimize.m"
            /* direct tailcall eliminated */
#line 137 "optimize.m"
            {
#line 137 "optimize.m"
              MR_Integer optimize__HeadVar__5__tmp_copy_5 = optimize__V_28_28;
#line 137 "optimize.m"
              MR_Integer optimize__HeadVar__7__tmp_copy_7 = optimize__Off_23;
#line 137 "optimize.m"
              MR_Word optimize__HeadVar__8__tmp_copy_8 = optimize__Stk_21;

#line 137 "optimize.m"
              optimize__HeadVar__5_5 = optimize__HeadVar__5__tmp_copy_5;
#line 137 "optimize.m"
              optimize__HeadVar__7_7 = optimize__HeadVar__7__tmp_copy_7;
#line 137 "optimize.m"
              optimize__HeadVar__8_8 = optimize__HeadVar__8__tmp_copy_8;
#line 137 "optimize.m"
            }
#line 137 "optimize.m"
            goto loop_top;
#line 137 "optimize.m"
          }
        }
#line 130 "optimize.m"
    }
#line 130 "optimize.m"
  }
#line 127 "optimize.m"
}

#line 78 "optimize.m"
void MR_CALL optimize__write_optimized_files_7_p_0(
#line 78 "optimize.m"
  MR_String optimize__HeadVar__1_1,
#line 78 "optimize.m"
  MR_String optimize__HeadVar__2_2,
#line 78 "optimize.m"
  MR_Array optimize__HeadVar__3_3,
#line 78 "optimize.m"
  MR_Array optimize__HeadVar__4_4,
#line 78 "optimize.m"
  MR_Integer optimize__HeadVar__5_5)
#line 78 "optimize.m"
{
  {
    bool optimize__succeeded;
    MR_String optimize__SMLNG_13;
    MR_String optimize__Done_14;
    MR_Word optimize__Res1_15;
    MR_Word optimize__Res2_17;
    MR_String optimize__V_26_26;
    MR_Integer optimize__V_35_35;
    MR_Integer optimize__V_36_36;
    MR_Integer optimize__V_37_37;
    MR_Word optimize__V_38_38;
    MR_Word optimize__TypeInfo_17_39;
    MR_Word optimize__Stdout_3_48;
    MR_Word optimize__OldStream_4_50;
    MR_Word optimize__StreamNames0_5_66;
    MR_Integer optimize__V_10_68;
    MR_Word optimize__StreamNames_6_69;
    MR_Word optimize__TypeInfo_11_70;
    MR_Word optimize__TypeInfo_12_71;
#line 102 "optimize.m"
    MR_Word optimize__V_16_16;
#line 107 "optimize.m"
    MR_Word optimize__V_18_18;

#line 99 "optimize.m"
    {
#line 99 "optimize.m"
      input__file_names_4_p_0(optimize__HeadVar__1_1, optimize__HeadVar__5_5, &optimize__SMLNG_13, &optimize__Done_14);
    }
#line 101 "optimize.m"
    {
#line 101 "optimize.m"
      mercury__io__tell_4_p_0(optimize__SMLNG_13, &optimize__Res1_15);
    }
#line 102 "optimize.m"
    optimize__succeeded = (MR_tag((MR_Word) optimize__Res1_15) == MR_mktag((MR_Integer) 1));
#line 102 "optimize.m"
    if ((MR_tag((MR_Word) optimize__Res1_15) == MR_mktag((MR_Integer) 1)))
#line 102 "optimize.m"
      optimize__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(1), optimize__Res1_15, (MR_Integer) 0)));
#line 102 "optimize.m"
    if (optimize__succeeded)
      {
        MR_Word optimize__TypeInfo_27_27 = (MR_Word) (&mercury__io__io__type_ctor_info_res_0);

#line 102 "optimize.m"
        {
#line 102 "optimize.m"
          mercury__exception__throw_1_p_0(optimize__TypeInfo_27_27, ((MR_Box) (optimize__Res1_15)));
        }
      }
#line 102 "optimize.m"
    else
      {
      }
#line 121 "optimize.m"
    optimize__V_35_35 = (MR_Integer) 1;
    optimize__TypeInfo_17_39 = (MR_Word) (&attrs__attrs__type_ctor_info_attrs_0);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
#define MR_PROC_LABEL optimize__write_optimized_files_7_p_0
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
	MR_Word TypeInfo_for__T;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
	MR_Word Array;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
	MR_Integer Max;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
	TypeInfo_for__T = 
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
optimize__TypeInfo_17_39
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
	Array = 
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
(MR_Array) optimize__HeadVar__3_3
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
		{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

	Max = ((MR_ArrayType *)Array)->size - 1;

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

		;}
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
#undef MR_PROC_LABEL
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
	
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
optimize__V_36_36
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
 = Max;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
}
#line 121 "optimize.m"
    optimize__V_37_37 = (MR_Integer) 0;
#line 121 "optimize.m"
    optimize__V_38_38 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 121 "optimize.m"
    {
#line 121 "optimize.m"
      optimize__write_optimized_2_10_p_0(optimize__HeadVar__2_2, optimize__HeadVar__3_3, optimize__HeadVar__4_4, optimize__HeadVar__5_5, optimize__V_35_35, optimize__V_36_36, optimize__V_37_37, optimize__V_38_38);
    }
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL optimize__write_optimized_files_7_p_0
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) &mercury_stdout;
	update_io(IO0, IO);

#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
optimize__Stdout_3_48
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL optimize__write_optimized_files_7_p_0
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word NewStream;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word OutStream;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	NewStream = 
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
optimize__Stdout_3_48
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	OutStream = (MR_Word) mercury_current_text_output;
	mercury_current_text_output = (MercuryFile *) NewStream;
	update_io(IO0, IO);

#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
optimize__OldStream_4_50
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = OutStream;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL optimize__write_optimized_files_7_p_0
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word StreamNames;
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	StreamNames = ML_io_stream_names;
	update_io(IO0, IO);

#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
optimize__StreamNames0_5_66
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = StreamNames;
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL optimize__write_optimized_files_7_p_0
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer Id;
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Stream = 
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
optimize__OldStream_4_50
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	/* 
	** Most of the time, we can just use the pointer to the stream
	** as a unique identifier.
	*/
	
	Id = (MR_Word) Stream;

#ifdef NATIVE_GC
	/* 
	** XXX for accurate GC we should embed an ID in the MercuryFile
	** and retrieve it here.
	*/
	MR_fatal_error("not implemented -- stream ids in native GC grades");
#endif

#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
optimize__V_10_68
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Id;
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
    optimize__TypeInfo_11_70 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
    optimize__TypeInfo_12_71 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
#line 753 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    {
#line 753 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      mercury__map__delete_3_p_1(optimize__TypeInfo_11_70, optimize__TypeInfo_12_71, optimize__StreamNames0_5_66, ((MR_Box) (optimize__V_10_68)), &optimize__StreamNames_6_69);
    }
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL optimize__write_optimized_files_7_p_0
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word StreamNames;
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	StreamNames = 
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
optimize__StreamNames_6_69
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	ML_io_stream_names = StreamNames;
	update_io(IO0, IO);

#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL optimize__write_optimized_files_7_p_0
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Stream = 
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
optimize__OldStream_4_50
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_close((MercuryFile *) Stream);
	update_io(IO0, IO);

#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 106 "optimize.m"
    {
#line 106 "optimize.m"
      mercury__io__tell_4_p_0(optimize__Done_14, &optimize__Res2_17);
    }
#line 107 "optimize.m"
    optimize__succeeded = (MR_tag((MR_Word) optimize__Res2_17) == MR_mktag((MR_Integer) 1));
#line 107 "optimize.m"
    if ((MR_tag((MR_Word) optimize__Res2_17) == MR_mktag((MR_Integer) 1)))
#line 107 "optimize.m"
      optimize__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(1), optimize__Res2_17, (MR_Integer) 0)));
#line 107 "optimize.m"
    if (optimize__succeeded)
      {
        MR_Word optimize__TypeInfo_28_28 = (MR_Word) (&mercury__io__io__type_ctor_info_res_0);

#line 107 "optimize.m"
        {
#line 107 "optimize.m"
          mercury__exception__throw_1_p_0(optimize__TypeInfo_28_28, ((MR_Box) (optimize__Res2_17)));
        }
      }
#line 107 "optimize.m"
    else
      {
      }
#line 108 "optimize.m"
    optimize__V_26_26 = (MR_String) "\n";
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL optimize__write_optimized_files_7_p_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
optimize__V_26_26
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 109 "optimize.m"
    {
#line 109 "optimize.m"
      mercury__io__told_2_p_0();
#line 109 "optimize.m"
      return;
    }
  }
#line 78 "optimize.m"
}

void mercury__optimize__init(void)
{
}

void mercury__optimize__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&optimize__optimize__type_ctor_info_tas_0);
}

void mercury__optimize__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module optimize. */
