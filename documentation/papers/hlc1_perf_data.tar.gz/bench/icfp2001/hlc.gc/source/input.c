/*
** Automatically generated from `input.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module input. */
/* :- implementation. */

#include "input.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "attrs.h"
#include "mercury.benchmarking.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "mercury.tree234.h"
#include "mercury.varset.h"



static const MR_FO_PseudoTypeInfo_Struct1 input__list__type_info_list_1__type0_14_input__token_0;
static const MR_DuFunctorDescPtr input__input__du_name_ordered_token_0[4];
static const MR_DuFunctorDesc input__input__du_functor_desc_token_0_0;
static const MR_PseudoTypeInfo input__input__field_types_token_0_0[1];
static const MR_DuFunctorDesc input__input__du_functor_desc_token_0_1;
static const MR_PseudoTypeInfo input__input__field_types_token_0_1[1];
static const MR_DuFunctorDesc input__input__du_functor_desc_token_0_2;
static const MR_PseudoTypeInfo input__input__field_types_token_0_2[1];
static const MR_DuFunctorDesc input__input__du_functor_desc_token_0_3;
static const MR_PseudoTypeInfo input__input__field_types_token_0_3[1];
static const MR_DuPtagLayout input__input__du_ptag_ordered_token_0[4];
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_token_0_0[1];
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_token_0_1[1];
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_token_0_2[1];
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_token_0_3[1];
static const MR_FO_PseudoTypeInfo_Struct1 input__list__type_info_list_1__type0_12_input__tag_0;
static const MR_DuFunctorDescPtr input__input__du_name_ordered_tag_0[9];
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_0;
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_1;
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_2;
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_3;
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_4;
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_5;
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_6;
static const MR_PseudoTypeInfo input__input__field_types_tag_0_6[1];
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_7;
static const MR_PseudoTypeInfo input__input__field_types_tag_0_7[1];
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_8;
static const MR_PseudoTypeInfo input__input__field_types_tag_0_8[1];
static const MR_DuPtagLayout input__input__du_ptag_ordered_tag_0[4];
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_tag_0_0[6];
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_tag_0_1[1];
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_tag_0_2[1];
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_tag_0_3[1];
static const MR_DuFunctorDescPtr input__input__du_name_ordered_st_0[3];
static const MR_DuFunctorDesc input__input__du_functor_desc_st_0_0;
static const MR_PseudoTypeInfo input__input__field_types_st_0_0[1];
static const MR_FO_PseudoTypeInfo_Struct1 input__list__type_info_list_1__type0_13___character_0;
static const MR_DuFunctorDesc input__input__du_functor_desc_st_0_1;
static const MR_PseudoTypeInfo input__input__field_types_st_0_1[1];
static const MR_DuFunctorDesc input__input__du_functor_desc_st_0_2;
static const MR_PseudoTypeInfo input__input__field_types_st_0_2[1];
static const MR_DuPtagLayout input__input__du_ptag_ordered_st_0[3];
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_st_0_0[1];
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_st_0_1[1];
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_st_0_2[1];
static const MR_FO_PseudoTypeInfo_Struct1 input__array__type_info_array_1__type0_7___int_0;
static const MR_FO_PseudoTypeInfo_Struct1 input__array__type_info_array_1__type0_14_attrs__attrs_0;
static const MR_FO_PseudoTypeInfo_Struct2 input__std_util__type_info_pair_2__type0_14_attrs__attrs_0__type0_7___int_0;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
static void MR_CALL input__DeforestationIn__pred__attrss_extents__128__0_3_p_0(
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word input__AEs_7,
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word * input__V_10_10,
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word * input__V_14_14);
#line 221 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
static bool MR_CALL input__IntroducedFrom__pred__filter_map__221__4__ho12_5_p_0(
#line 221 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word input__V_13_13,
#line 221 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_String * input__V_12_12);
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL input__map__ho9_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word input__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * input__HeadVar__3_3);
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL input__map__ho8_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word input__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * input__HeadVar__3_3);
#line 187 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL input__filter_map__ho7_3_p_in__list_0(
#line 187 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word input__HeadVar__2_2,
#line 187 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * input__HeadVar__3_3);
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
static void MR_CALL input__write_list__ho6_5_p_in__io_0(
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
  MR_Word input__HeadVar__1_1,
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
  MR_String input__HeadVar__2_2);
#line 383 "input.m"
static MR_Word MR_CALL input__finish_aes_3_f_0(
#line 383 "input.m"
  MR_Word input__HeadVar__1_1,
#line 383 "input.m"
  MR_Word input__HeadVar__2_2);
static /* final */ const MR_Box input__const_20_0_1_TypeInfo_61_61[3];
static /* final */ const MR_Box input__const_20_0_2_TypeInfo_63_63[2];
#line 361 "input.m"
static MR_Word MR_CALL input__aes_6_f_0(
#line 361 "input.m"
  MR_Word input__HeadVar__1_1,
#line 361 "input.m"
  MR_Word input__HeadVar__2_2,
#line 361 "input.m"
  MR_Integer input__HeadVar__3_3,
#line 361 "input.m"
  MR_Word input__HeadVar__4_4,
#line 361 "input.m"
  MR_Word input__HeadVar__5_5);
#line 352 "input.m"
static void MR_CALL input__attrss_extents_3_p_0(
#line 352 "input.m"
  MR_Word input__HeadVar__1_1,
#line 352 "input.m"
  MR_Array * input__HeadVar__2_2,
#line 352 "input.m"
  MR_Array * input__HeadVar__3_3);
#line 324 "input.m"
static void MR_CALL input__write_tokens_to_file_4_p_0(
#line 324 "input.m"
  MR_String input__HeadVar__1_1,
#line 324 "input.m"
  MR_Word input__HeadVar__2_2);
#line 228 "input.m"
static MR_Word MR_CALL input__pds_6_f_0(
#line 228 "input.m"
  MR_Word input__HeadVar__1_1,
#line 228 "input.m"
  MR_Word input__HeadVar__2_2,
#line 228 "input.m"
  MR_Word input__HeadVar__3_3,
#line 228 "input.m"
  MR_Word input__HeadVar__4_4,
#line 228 "input.m"
  MR_Word input__HeadVar__5_5);
#line 195 "input.m"
static bool MR_CALL input__is_wspc_1_p_0(
#line 195 "input.m"
  MR_Char input__HeadVar__1_1);
#line 179 "input.m"
static /* final */ const int input__const_7_0_20_next_slots_table[64];
#line 179 "input.m"
static /* final */ const MR_String input__const_7_0_21_string_table[64];
#line 184 "input.m"
static /* final */ const MR_Box input__const_7_0_1_T_4[1];
#line 186 "input.m"
static /* final */ const MR_Box input__const_7_0_2_T_4[1];
#line 186 "input.m"
static /* final */ const MR_Box input__const_7_0_3_T_4[1];
#line 181 "input.m"
static /* final */ const MR_Box input__const_7_0_4_T_4[1];
#line 189 "input.m"
static /* final */ const MR_Box input__const_7_0_5_T_4[1];
#line 188 "input.m"
static /* final */ const MR_Box input__const_7_0_6_T_4[1];
#line 188 "input.m"
static /* final */ const MR_Box input__const_7_0_7_T_4[1];
#line 190 "input.m"
static /* final */ const MR_Box input__const_7_0_8_T_4[1];
#line 189 "input.m"
static /* final */ const MR_Box input__const_7_0_9_T_4[1];
#line 184 "input.m"
static /* final */ const MR_Box input__const_7_0_10_T_4[1];
#line 183 "input.m"
static /* final */ const MR_Box input__const_7_0_11_T_4[1];
#line 184 "input.m"
static /* final */ const MR_Box input__const_7_0_12_T_4[1];
#line 188 "input.m"
static /* final */ const MR_Box input__const_7_0_13_T_4[1];
#line 185 "input.m"
static /* final */ const MR_Box input__const_7_0_14_T_4[1];
#line 185 "input.m"
static /* final */ const MR_Box input__const_7_0_15_T_4[1];
#line 190 "input.m"
static /* final */ const MR_Box input__const_7_0_16_T_4[1];
#line 185 "input.m"
static /* final */ const MR_Box input__const_7_0_17_T_4[1];
#line 189 "input.m"
static /* final */ const MR_Box input__const_7_0_18_T_4[1];
#line 186 "input.m"
static /* final */ const MR_Box input__const_7_0_19_T_4[1];
#line 167 "input.m"
static MR_Word MR_CALL input__string_to_tag_2_f_0(
#line 167 "input.m"
  MR_String input__HeadVar__1_1);
#line 122 "input.m"
static /* final */ const MR_Box input__const_6_0_1_V_20_20[1];
#line 134 "input.m"
static /* final */ const MR_Box input__const_6_0_2_V_39_39[1];
#line 150 "input.m"
static /* final */ const MR_Box input__const_6_0_3_V_62_62[1];
#line 159 "input.m"
static /* final */ const MR_Box input__const_6_0_4_V_70_70[1];
#line 114 "input.m"
static void MR_CALL input__parse_char_7_p_0(
#line 114 "input.m"
  MR_Char input__HeadVar__1_1,
#line 114 "input.m"
  MR_Word input__HeadVar__2_2,
#line 114 "input.m"
  MR_Word input__HeadVar__3_3,
#line 114 "input.m"
  MR_Word input__HeadVar__4_4,
#line 114 "input.m"
  MR_Word * input__HeadVar__5_5);
static /* final */ const MR_Box input__const_5_0_1_TypeInfo_25_72[2];
static /* final */ const MR_Box input__const_5_0_2_TypeInfo_29_76[2];
static /* final */ const MR_Box input__const_5_0_3_TypeInfo_33_80[2];
static /* final */ const MR_Box input__const_5_0_4_TypeInfo_19_19[2];
#line 99 "input.m"
static void MR_CALL input__parse_chars_6_p_0(
#line 99 "input.m"
  MR_Word input__HeadVar__1_1,
#line 99 "input.m"
  MR_Word input__HeadVar__2_2,
#line 99 "input.m"
  MR_Word input__HeadVar__3_3,
#line 99 "input.m"
  MR_Word * input__HeadVar__4_4);
#line 414 "input.m"
static /* final */ const MR_Box input__const_1_0_1_V_13_13[1];
#line 414 "input.m"
static /* final */ const MR_Box input__const_1_0_2_V_12_12[2];
#line 415 "input.m"
static /* final */ const MR_Box input__const_1_0_3_V_22_22[1];
#line 415 "input.m"
static /* final */ const MR_Box input__const_1_0_4_V_21_21[2];
#line 94 "input.m"
static /* final */ const MR_Box input__const_0_0_1_V_28_28[1];



const MR_TypeCtorInfo_Struct input__input__type_ctor_info_tokens_0 = {
		(MR_Integer) 0,
		((MR_Box) (input____Unify____tokens_0_0)),
		((MR_Box) (input____Unify____tokens_0_0)),
		((MR_Box) (input____Compare____tokens_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "input",
		(MR_String) "tokens",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&input__list__type_info_list_1__type0_14_input__token_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct input__input__type_ctor_info_token_0 = {
		(MR_Integer) 0,
		((MR_Box) (input____Unify____token_0_0)),
		((MR_Box) (input____Unify____token_0_0)),
		((MR_Box) (input____Compare____token_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "input",
		(MR_String) "token",
		(MR_Integer) 4,
		{
		(MR_Box) input__input__du_name_ordered_token_0},
		{
		(MR_Box) input__input__du_ptag_ordered_token_0},
		(MR_Integer) 4,
		(MR_Integer) 4};
const MR_TypeCtorInfo_Struct input__input__type_ctor_info_tags_0 = {
		(MR_Integer) 0,
		((MR_Box) (input____Unify____tags_0_0)),
		((MR_Box) (input____Unify____tags_0_0)),
		((MR_Box) (input____Compare____tags_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "input",
		(MR_String) "tags",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&input__list__type_info_list_1__type0_12_input__tag_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct input__input__type_ctor_info_tag_0 = {
		(MR_Integer) 0,
		((MR_Box) (input____Unify____tag_0_0)),
		((MR_Box) (input____Unify____tag_0_0)),
		((MR_Box) (input____Compare____tag_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "input",
		(MR_String) "tag",
		(MR_Integer) 4,
		{
		(MR_Box) input__input__du_name_ordered_tag_0},
		{
		(MR_Box) input__input__du_ptag_ordered_tag_0},
		(MR_Integer) 9,
		(MR_Integer) 4};
const MR_TypeCtorInfo_Struct input__input__type_ctor_info_st_0 = {
		(MR_Integer) 0,
		((MR_Box) (input____Unify____st_0_0)),
		((MR_Box) (input____Unify____st_0_0)),
		((MR_Box) (input____Compare____st_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "input",
		(MR_String) "st",
		(MR_Integer) 4,
		{
		(MR_Box) input__input__du_name_ordered_st_0},
		{
		(MR_Box) input__input__du_ptag_ordered_st_0},
		(MR_Integer) 3,
		(MR_Integer) 3};
const MR_TypeCtorInfo_Struct input__input__type_ctor_info_extents_0 = {
		(MR_Integer) 0,
		((MR_Box) (input____Unify____extents_0_0)),
		((MR_Box) (input____Unify____extents_0_0)),
		((MR_Box) (input____Compare____extents_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "input",
		(MR_String) "extents",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&input__array__type_info_array_1__type0_7___int_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct input__input__type_ctor_info_attrss_0 = {
		(MR_Integer) 0,
		((MR_Box) (input____Unify____attrss_0_0)),
		((MR_Box) (input____Unify____attrss_0_0)),
		((MR_Box) (input____Compare____attrss_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "input",
		(MR_String) "attrss",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&input__array__type_info_array_1__type0_14_attrs__attrs_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct input__input__type_ctor_info_ae_0 = {
		(MR_Integer) 0,
		((MR_Box) (input____Unify____ae_0_0)),
		((MR_Box) (input____Unify____ae_0_0)),
		((MR_Box) (input____Compare____ae_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "input",
		(MR_String) "ae",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&input__std_util__type_info_pair_2__type0_14_attrs__attrs_0__type0_7___int_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
static const MR_FO_PseudoTypeInfo_Struct1 input__list__type_info_list_1__type0_14_input__token_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&input__input__type_ctor_info_token_0)}};
static const MR_DuFunctorDescPtr input__input__du_name_ordered_token_0[4] = {
		(&input__input__du_functor_desc_token_0_1),
		(&input__input__du_functor_desc_token_0_0),
		(&input__input__du_functor_desc_token_0_2),
		(&input__input__du_functor_desc_token_0_3)};
static const MR_DuFunctorDesc input__input__du_functor_desc_token_0_0 = {
		(MR_String) "open",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		input__input__field_types_token_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo input__input__field_types_token_0_0[1] = {
		(MR_PseudoTypeInfo) (&input__input__type_ctor_info_tag_0)};
static const MR_DuFunctorDesc input__input__du_functor_desc_token_0_1 = {
		(MR_String) "close",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		input__input__field_types_token_0_1,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo input__input__field_types_token_0_1[1] = {
		(MR_PseudoTypeInfo) (&input__input__type_ctor_info_tag_0)};
static const MR_DuFunctorDesc input__input__du_functor_desc_token_0_2 = {
		(MR_String) "spc",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 2,
		(MR_Integer) 0,
		(MR_Integer) 2,
		input__input__field_types_token_0_2,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo input__input__field_types_token_0_2[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_character_0)};
static const MR_DuFunctorDesc input__input__du_functor_desc_token_0_3 = {
		(MR_String) "text",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 3,
		(MR_Integer) 0,
		(MR_Integer) 3,
		input__input__field_types_token_0_3,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo input__input__field_types_token_0_3[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0)};
static const MR_DuPtagLayout input__input__du_ptag_ordered_token_0[4] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		input__input__du_stag_ordered_token_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		input__input__du_stag_ordered_token_0_1},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		input__input__du_stag_ordered_token_0_2},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		input__input__du_stag_ordered_token_0_3}};
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_token_0_0[1] = {
		(&input__input__du_functor_desc_token_0_0)};
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_token_0_1[1] = {
		(&input__input__du_functor_desc_token_0_1)};
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_token_0_2[1] = {
		(&input__input__du_functor_desc_token_0_2)};
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_token_0_3[1] = {
		(&input__input__du_functor_desc_token_0_3)};
static const MR_FO_PseudoTypeInfo_Struct1 input__list__type_info_list_1__type0_12_input__tag_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&input__input__type_ctor_info_tag_0)}};
static const MR_DuFunctorDescPtr input__input__du_name_ordered_tag_0[9] = {
		(&input__input__du_functor_desc_tag_0_0),
		(&input__input__du_functor_desc_tag_0_8),
		(&input__input__du_functor_desc_tag_0_1),
		(&input__input__du_functor_desc_tag_0_2),
		(&input__input__du_functor_desc_tag_0_3),
		(&input__input__du_functor_desc_tag_0_4),
		(&input__input__du_functor_desc_tag_0_7),
		(&input__input__du_functor_desc_tag_0_5),
		(&input__input__du_functor_desc_tag_0_6)};
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_0 = {
		(MR_String) "b",
		(MR_Integer) 0,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_1 = {
		(MR_String) "em",
		(MR_Integer) 0,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		(MR_Integer) 0,
		(MR_Integer) 1,
		(MR_Integer) 1,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_2 = {
		(MR_String) "i",
		(MR_Integer) 0,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		(MR_Integer) 0,
		(MR_Integer) 2,
		(MR_Integer) 2,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_3 = {
		(MR_String) "pl",
		(MR_Integer) 0,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		(MR_Integer) 0,
		(MR_Integer) 3,
		(MR_Integer) 3,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_4 = {
		(MR_String) "s",
		(MR_Integer) 0,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		(MR_Integer) 0,
		(MR_Integer) 4,
		(MR_Integer) 4,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_5 = {
		(MR_String) "tt",
		(MR_Integer) 0,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		(MR_Integer) 0,
		(MR_Integer) 5,
		(MR_Integer) 5,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_6 = {
		(MR_String) "u",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 6,
		input__input__field_types_tag_0_6,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo input__input__field_types_tag_0_6[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0)};
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_7 = {
		(MR_String) "size",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 2,
		(MR_Integer) 0,
		(MR_Integer) 7,
		input__input__field_types_tag_0_7,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo input__input__field_types_tag_0_7[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0)};
static const MR_DuFunctorDesc input__input__du_functor_desc_tag_0_8 = {
		(MR_String) "colour",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 3,
		(MR_Integer) 0,
		(MR_Integer) 8,
		input__input__field_types_tag_0_8,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo input__input__field_types_tag_0_8[1] = {
		(MR_PseudoTypeInfo) (&attrs__attrs__type_ctor_info_colour_0)};
static const MR_DuPtagLayout input__input__du_ptag_ordered_tag_0[4] = {
		{
		(MR_Integer) 6,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		input__input__du_stag_ordered_tag_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		input__input__du_stag_ordered_tag_0_1},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		input__input__du_stag_ordered_tag_0_2},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		input__input__du_stag_ordered_tag_0_3}};
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_tag_0_0[6] = {
		(&input__input__du_functor_desc_tag_0_0),
		(&input__input__du_functor_desc_tag_0_1),
		(&input__input__du_functor_desc_tag_0_2),
		(&input__input__du_functor_desc_tag_0_3),
		(&input__input__du_functor_desc_tag_0_4),
		(&input__input__du_functor_desc_tag_0_5)};
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_tag_0_1[1] = {
		(&input__input__du_functor_desc_tag_0_6)};
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_tag_0_2[1] = {
		(&input__input__du_functor_desc_tag_0_7)};
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_tag_0_3[1] = {
		(&input__input__du_functor_desc_tag_0_8)};
static const MR_DuFunctorDescPtr input__input__du_name_ordered_st_0[3] = {
		(&input__input__du_functor_desc_st_0_1),
		(&input__input__du_functor_desc_st_0_0),
		(&input__input__du_functor_desc_st_0_2)};
static const MR_DuFunctorDesc input__input__du_functor_desc_st_0_0 = {
		(MR_String) "reading_open_tag",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		input__input__field_types_st_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo input__input__field_types_st_0_0[1] = {
		(MR_PseudoTypeInfo) (&input__list__type_info_list_1__type0_13___character_0)};
static const MR_FO_PseudoTypeInfo_Struct1 input__list__type_info_list_1__type0_13___character_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_character_0)}};
static const MR_DuFunctorDesc input__input__du_functor_desc_st_0_1 = {
		(MR_String) "reading_close_tag",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		input__input__field_types_st_0_1,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo input__input__field_types_st_0_1[1] = {
		(MR_PseudoTypeInfo) (&input__list__type_info_list_1__type0_13___character_0)};
static const MR_DuFunctorDesc input__input__du_functor_desc_st_0_2 = {
		(MR_String) "reading_text",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 2,
		(MR_Integer) 0,
		(MR_Integer) 2,
		input__input__field_types_st_0_2,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo input__input__field_types_st_0_2[1] = {
		(MR_PseudoTypeInfo) (&input__list__type_info_list_1__type0_13___character_0)};
static const MR_DuPtagLayout input__input__du_ptag_ordered_st_0[3] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		input__input__du_stag_ordered_st_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		input__input__du_stag_ordered_st_0_1},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		input__input__du_stag_ordered_st_0_2}};
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_st_0_0[1] = {
		(&input__input__du_functor_desc_st_0_0)};
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_st_0_1[1] = {
		(&input__input__du_functor_desc_st_0_1)};
static const MR_DuFunctorDescPtr input__input__du_stag_ordered_st_0_2[1] = {
		(&input__input__du_functor_desc_st_0_2)};
static const MR_FO_PseudoTypeInfo_Struct1 input__array__type_info_array_1__type0_7___int_0 = {
		(&mercury__array__array__type_ctor_info_array_1),
		{
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0)}};
static const MR_FO_PseudoTypeInfo_Struct1 input__array__type_info_array_1__type0_14_attrs__attrs_0 = {
		(&mercury__array__array__type_ctor_info_array_1),
		{
		(MR_PseudoTypeInfo) (&attrs__attrs__type_ctor_info_attrs_0)}};
static const MR_FO_PseudoTypeInfo_Struct2 input__std_util__type_info_pair_2__type0_14_attrs__attrs_0__type0_7___int_0 = {
		(&mercury__std_util__std_util__type_ctor_info_pair_2),
		{
		(MR_PseudoTypeInfo) (&attrs__attrs__type_ctor_info_attrs_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0)}};

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
static void MR_CALL input__DeforestationIn__pred__attrss_extents__128__0_3_p_0(
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word input__AEs_7,
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word * input__V_10_10,
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word * input__V_14_14)
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
{
  {
    bool input__succeeded;

    if ((input__AEs_7 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
      {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        *input__V_14_14 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        *input__V_10_10 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
      }
    else
      {
        MR_Word input__H0_6_83 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__AEs_7, (MR_Integer) 0)));
        MR_Word input__T0_7_84 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__AEs_7, (MR_Integer) 1)));
        MR_Word input__H_8_85 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__H0_6_83, (MR_Integer) 0)));
        MR_Word input__T_9_86;
#line 333 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
        MR_Integer input___Y_4_156 = ((MR_Integer) (MR_hl_field(MR_mktag(0), input__H0_6_83, (MR_Integer) 1)));

#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          input__map__ho8_3_p_in__list_0(input__T0_7_84, &input__T_9_86);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *input__V_14_14 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *input__V_14_14, 0) = ((MR_Box) (input__H_8_85));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *input__V_14_14, 1) = ((MR_Box) (input__T_9_86));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          input__map__ho9_3_p_in__list_0(input__AEs_7, input__V_10_10);
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          return;
        }
      }
  }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
}

#line 221 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
static bool MR_CALL input__IntroducedFrom__pred__filter_map__221__4__ho12_5_p_0(
#line 221 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word input__V_13_13,
#line 221 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_String * input__V_12_12)
#line 221 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
{
#line 293 "input.m"
  {
#line 293 "input.m"
    bool input__succeeded;

#line 293 "input.m"
    if ((MR_tag((MR_Word) input__V_13_13) == MR_mktag((MR_Integer) 2)))
      {
        MR_Char input__S_19 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(2), input__V_13_13, (MR_Integer) 0)));
        MR_Word input__V_6_24;
        MR_Integer input__Code_5_25;
        MR_Word input__V_7_26 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));

#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
{
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#define MR_PROC_LABEL input__IntroducedFrom__pred__filter_map__221__4__ho12_5_p_0
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	MR_Char Character;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	MR_Integer Int;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	Character = 
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
input__S_19
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
		{
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

	Int = (MR_UnsignedChar) Character;

#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

		;}
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#undef MR_PROC_LABEL
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
input__Code_5_25
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
 = Int;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
}
#line 89 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
        {
#line 89 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
          input__V_6_24 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 89 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
          MR_hl_field(MR_mktag(1), input__V_6_24, 0) = ((MR_Box) (input__Code_5_25));
#line 89 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
          MR_hl_field(MR_mktag(1), input__V_6_24, 1) = ((MR_Box) (input__V_7_26));
#line 89 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
        }
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL input__IntroducedFrom__pred__filter_map__221__4__ho12_5_p_0
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word IntList;
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	IntList = 
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
input__V_6_24
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
		/* mode (out, in) is det */
	MR_Word int_list_ptr;
	size_t size;
	MR_Word str_ptr;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `int_list_ptr'
*/
	size = sizeof(MR_Word);
	int_list_ptr = IntList;
	while (! MR_list_is_empty(int_list_ptr)) {
		size++;
		int_list_ptr = MR_list_tail(int_list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** loop to copy the characters from the int_list to the string
*/
	size = 0;
	int_list_ptr = IntList;
	while (! MR_list_is_empty(int_list_ptr)) {
		Str[size++] = MR_list_head(int_list_ptr);
		int_list_ptr = MR_list_tail(int_list_ptr);
	}
/*
** null terminate the string
*/
	Str[size] = '\0';
}
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
*input__V_12_12
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 524 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
        input__succeeded = TRUE;
      }
#line 293 "input.m"
    else
#line 293 "input.m"
      if ((MR_tag((MR_Word) input__V_13_13) == MR_mktag((MR_Integer) 3)))
#line 293 "input.m"
        {
#line 293 "input.m"
          *input__V_12_12 = ((MR_String) (MR_hl_field(MR_mktag(3), input__V_13_13, (MR_Integer) 0)));
#line 293 "input.m"
          input__succeeded = TRUE;
#line 293 "input.m"
        }
#line 293 "input.m"
      else
#line 293 "input.m"
        input__succeeded = FALSE;
#line 293 "input.m"
    return input__succeeded;
#line 293 "input.m"
  }
#line 221 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
}

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL input__map__ho9_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word input__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * input__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool input__succeeded;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word input__H0_6_6;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word input__T0_7_7;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Integer input__H_8_8;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word input__T_9_9;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((input__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *input__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
#line 336 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
        MR_Word input___X_3_78;

#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        input__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__2_2, (MR_Integer) 0)));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        input__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__2_2, (MR_Integer) 1)));
#line 336 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
        input___X_3_78 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__H0_6_6, (MR_Integer) 0)));
#line 336 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
        input__H_8_8 = ((MR_Integer) (MR_hl_field(MR_mktag(0), input__H0_6_6, (MR_Integer) 1)));
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          input__map__ho9_3_p_in__list_0(input__T0_7_7, &input__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *input__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *input__HeadVar__3_3, 0) = ((MR_Box) (input__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *input__HeadVar__3_3, 1) = ((MR_Box) (input__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL input__map__ho8_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word input__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * input__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool input__succeeded;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word input__H0_6_6;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word input__T0_7_7;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word input__H_8_8;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word input__T_9_9;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((input__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *input__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
#line 333 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
        MR_Integer input___Y_4_79;

#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        input__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__2_2, (MR_Integer) 0)));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        input__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__2_2, (MR_Integer) 1)));
#line 333 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
        input__H_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__H0_6_6, (MR_Integer) 0)));
#line 333 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
        input___Y_4_79 = ((MR_Integer) (MR_hl_field(MR_mktag(0), input__H0_6_6, (MR_Integer) 1)));
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          input__map__ho8_3_p_in__list_0(input__T0_7_7, &input__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *input__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *input__HeadVar__3_3, 0) = ((MR_Box) (input__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *input__HeadVar__3_3, 1) = ((MR_Box) (input__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 187 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL input__filter_map__ho7_3_p_in__list_0(
#line 187 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word input__HeadVar__2_2,
#line 187 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * input__HeadVar__3_3)
#line 187 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 206 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 206 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool input__succeeded;
#line 206 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word input__H0_6_6;
#line 206 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word input__T0_7_7;
#line 206 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word input__L1_10_10;

#line 206 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((input__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 206 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *input__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 206 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 206 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
#line 212 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        MR_String input__H_9_9;

#line 207 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        input__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__2_2, (MR_Integer) 0)));
#line 207 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        input__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__2_2, (MR_Integer) 1)));
#line 215 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 215 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          input__filter_map__ho7_3_p_in__list_0(input__T0_7_7, &input__L1_10_10);
        }
#line 209 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 209 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          input__succeeded = input__IntroducedFrom__pred__filter_map__221__4__ho12_5_p_0(input__H0_6_6, &input__H_9_9);
        }
#line 212 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        if (input__succeeded)
#line 211 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          {
#line 211 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            *input__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 211 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            MR_hl_field(MR_mktag(1), *input__HeadVar__3_3, 0) = ((MR_Box) (input__H_9_9));
#line 211 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            MR_hl_field(MR_mktag(1), *input__HeadVar__3_3, 1) = ((MR_Box) (input__L1_10_10));
#line 211 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          }
#line 212 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        else
#line 213 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *input__HeadVar__3_3 = input__L1_10_10;
#line 206 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 206 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 187 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
static void MR_CALL input__write_list__ho6_5_p_in__io_0(
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
  MR_Word input__HeadVar__1_1,
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
  MR_String input__HeadVar__2_2)
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
{
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
  {
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    /* tailcall optimized into a loop */
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
  loop_top:;
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    {
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      bool input__succeeded;
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      MR_Word input__E_10_10;
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      MR_Word input__Es_11_11;

#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      if ((input__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        {
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        }
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      else
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        {
#line 350 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          input__E_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__1_1, (MR_Integer) 0)));
#line 350 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          input__Es_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__1_1, (MR_Integer) 1)));
#line 351 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          {
#line 351 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            input__write_token_3_p_0(input__E_10_10);
          }
#line 355 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          if ((input__Es_11_11 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 354 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            {
#line 354 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            }
#line 355 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          else
#line 355 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            {
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL input__write_list__ho6_5_p_in__io_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__HeadVar__2_2
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 355 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            }
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          {
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            /* direct tailcall eliminated */
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            {
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
              MR_Word input__HeadVar__1__tmp_copy_1 = input__Es_11_11;

#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
              input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            }
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            goto loop_top;
#line 359 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          }
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        }
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    }
#line 348 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
  }
#line 116 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.int"
}

#line 349 "input.m"
void MR_CALL input____Compare____ae_0_0(
#line 349 "input.m"
  MR_Word * input__HeadVar__1_1,
#line 349 "input.m"
  MR_Word input__HeadVar__2_2,
#line 349 "input.m"
  MR_Word input__HeadVar__3_3)
#line 349 "input.m"
{
  {
    bool input__succeeded;
    MR_Word input__conv1_HeadVar__2_2 = (MR_Word) input__HeadVar__2_2;
    MR_Word input__conv2_HeadVar__3_3 = (MR_Word) input__HeadVar__3_3;
    MR_Word input__TypeInfo_4_4 = (MR_Word) (&attrs__attrs__type_ctor_info_attrs_0);
    MR_Word input__TypeInfo_5_5 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);

#line 349 "input.m"
    {
#line 349 "input.m"
      mercury__std_util____Compare____pair_2_0(input__TypeInfo_4_4, input__TypeInfo_5_5, input__HeadVar__1_1, input__conv1_HeadVar__2_2, input__conv2_HeadVar__3_3);
#line 349 "input.m"
      return;
    }
  }
#line 349 "input.m"
}

#line 349 "input.m"
bool MR_CALL input____Unify____ae_0_0(
#line 349 "input.m"
  MR_Word input__HeadVar__1_1,
#line 349 "input.m"
  MR_Word input__HeadVar__2_2)
#line 349 "input.m"
{
  {
    bool input__succeeded;
    MR_Word input__conv1_HeadVar__1_1 = (MR_Word) input__HeadVar__1_1;
    MR_Word input__conv2_HeadVar__2_2 = (MR_Word) input__HeadVar__2_2;
    MR_Word input__TypeInfo_3_3 = (MR_Word) (&attrs__attrs__type_ctor_info_attrs_0);
    MR_Word input__TypeInfo_4_4 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);

#line 349 "input.m"
    {
#line 349 "input.m"
      input__succeeded = mercury__std_util____Unify____pair_2_0(input__TypeInfo_3_3, input__TypeInfo_4_4, input__conv1_HeadVar__1_1, input__conv2_HeadVar__2_2);
    }
    if (input__succeeded)
      input__succeeded = TRUE;
    return input__succeeded;
  }
#line 349 "input.m"
}

#line 83 "input.m"
void MR_CALL input____Compare____st_0_0(
#line 83 "input.m"
  MR_Word * input__HeadVar__1_1,
#line 83 "input.m"
  MR_Word input__HeadVar__2_2,
#line 83 "input.m"
  MR_Word input__HeadVar__3_3)
#line 83 "input.m"
{
#line 83 "input.m"
  {
#line 83 "input.m"
    bool input__succeeded;

#line 83 "input.m"
#line 83 "input.m"
    switch (MR_tag((MR_Word) input__HeadVar__2_2)) {
#line 83 "input.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 83 "input.m"
      case (MR_Integer) 0:
        {
          MR_Word input__V_32_32 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 0)));

#line 83 "input.m"
#line 83 "input.m"
          switch (MR_tag((MR_Word) input__HeadVar__3_3)) {
#line 83 "input.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 83 "input.m"
            case (MR_Integer) 0:
              {
                MR_Word input__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__3_3, (MR_Integer) 0)));
                MR_Word input__TypeInfo_22_22 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_character_0);

#line 83 "input.m"
                {
#line 83 "input.m"
                  mercury__list____Compare____list_1_0(input__TypeInfo_22_22, input__HeadVar__1_1, input__V_32_32, input__V_5_5);
#line 83 "input.m"
                  return;
                }
              }
#line 83 "input.m"
              break;
#line 83 "input.m"
            case (MR_Integer) 1:
#line 83 "input.m"
              *input__HeadVar__1_1 = (MR_Integer) 1;
#line 83 "input.m"
              break;
#line 83 "input.m"
            case (MR_Integer) 2:
#line 83 "input.m"
              *input__HeadVar__1_1 = (MR_Integer) 1;
#line 83 "input.m"
              break;
#line 83 "input.m"
          }
        }
#line 83 "input.m"
        break;
#line 83 "input.m"
      case (MR_Integer) 1:
        {
          MR_Word input__V_31_31 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__2_2, (MR_Integer) 0)));

#line 83 "input.m"
#line 83 "input.m"
          switch (MR_tag((MR_Word) input__HeadVar__3_3)) {
#line 83 "input.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 83 "input.m"
            case (MR_Integer) 0:
#line 83 "input.m"
              *input__HeadVar__1_1 = (MR_Integer) 2;
#line 83 "input.m"
              break;
#line 83 "input.m"
            case (MR_Integer) 1:
              {
                MR_Word input__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__3_3, (MR_Integer) 0)));
                MR_Word input__TypeInfo_25_25 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_character_0);

#line 83 "input.m"
                {
#line 83 "input.m"
                  mercury__list____Compare____list_1_0(input__TypeInfo_25_25, input__HeadVar__1_1, input__V_31_31, input__V_7_7);
#line 83 "input.m"
                  return;
                }
              }
#line 83 "input.m"
              break;
#line 83 "input.m"
            case (MR_Integer) 2:
#line 83 "input.m"
              *input__HeadVar__1_1 = (MR_Integer) 1;
#line 83 "input.m"
              break;
#line 83 "input.m"
          }
        }
#line 83 "input.m"
        break;
#line 83 "input.m"
      case (MR_Integer) 2:
        {
          MR_Word input__V_33_33 = ((MR_Word) (MR_hl_field(MR_mktag(2), input__HeadVar__2_2, (MR_Integer) 0)));

#line 83 "input.m"
#line 83 "input.m"
          switch (MR_tag((MR_Word) input__HeadVar__3_3)) {
#line 83 "input.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 83 "input.m"
            case (MR_Integer) 0:
#line 83 "input.m"
              *input__HeadVar__1_1 = (MR_Integer) 2;
#line 83 "input.m"
              break;
#line 83 "input.m"
            case (MR_Integer) 1:
#line 83 "input.m"
              *input__HeadVar__1_1 = (MR_Integer) 2;
#line 83 "input.m"
              break;
#line 83 "input.m"
            case (MR_Integer) 2:
              {
                MR_Word input__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(2), input__HeadVar__3_3, (MR_Integer) 0)));
                MR_Word input__TypeInfo_28_28 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_character_0);

#line 83 "input.m"
                {
#line 83 "input.m"
                  mercury__list____Compare____list_1_0(input__TypeInfo_28_28, input__HeadVar__1_1, input__V_33_33, input__V_9_9);
#line 83 "input.m"
                  return;
                }
              }
#line 83 "input.m"
              break;
#line 83 "input.m"
          }
        }
#line 83 "input.m"
        break;
#line 83 "input.m"
    }
#line 83 "input.m"
  }
#line 83 "input.m"
}

#line 83 "input.m"
bool MR_CALL input____Unify____st_0_0(
#line 83 "input.m"
  MR_Word input__HeadVar__1_1,
#line 83 "input.m"
  MR_Word input__HeadVar__2_2)
#line 83 "input.m"
{
#line 83 "input.m"
  {
#line 83 "input.m"
    bool input__succeeded;

#line 83 "input.m"
#line 83 "input.m"
    switch (MR_tag((MR_Word) input__HeadVar__1_1)) {
#line 83 "input.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 83 "input.m"
      case (MR_Integer) 0:
        {
          MR_Word input__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word input__V_4_4;
          MR_Word input__TypeInfo_12_12;

#line 83 "input.m"
          input__succeeded = (MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
#line 83 "input.m"
          if ((MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 83 "input.m"
            input__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 0)));
          if (input__succeeded)
            {
              input__TypeInfo_12_12 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_character_0);
              {
                return input__succeeded = mercury__list____Unify____list_1_0(input__TypeInfo_12_12, input__V_3_3, input__V_4_4);
              }
            }
        }
#line 83 "input.m"
        break;
#line 83 "input.m"
      case (MR_Integer) 1:
        {
          MR_Word input__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word input__V_6_6;
          MR_Word input__TypeInfo_9_9;

#line 83 "input.m"
          input__succeeded = (MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 83 "input.m"
          if ((MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 83 "input.m"
            input__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__2_2, (MR_Integer) 0)));
          if (input__succeeded)
            {
              input__TypeInfo_9_9 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_character_0);
              {
                return input__succeeded = mercury__list____Unify____list_1_0(input__TypeInfo_9_9, input__V_5_5, input__V_6_6);
              }
            }
        }
#line 83 "input.m"
        break;
#line 83 "input.m"
      case (MR_Integer) 2:
        {
          MR_Word input__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(2), input__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word input__V_8_8;
          MR_Word input__TypeInfo_15_15;

#line 83 "input.m"
          input__succeeded = (MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 2));
#line 83 "input.m"
          if ((MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 2)))
#line 83 "input.m"
            input__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(2), input__HeadVar__2_2, (MR_Integer) 0)));
          if (input__succeeded)
            {
              input__TypeInfo_15_15 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_character_0);
              {
                return input__succeeded = mercury__list____Unify____list_1_0(input__TypeInfo_15_15, input__V_7_7, input__V_8_8);
              }
            }
        }
#line 83 "input.m"
        break;
#line 83 "input.m"
    }
#line 83 "input.m"
    return input__succeeded;
#line 83 "input.m"
  }
#line 83 "input.m"
}

#line 38 "input.m"
void MR_CALL input____Compare____tokens_0_0(
#line 38 "input.m"
  MR_Word * input__HeadVar__1_1,
#line 38 "input.m"
  MR_Word input__HeadVar__2_2,
#line 38 "input.m"
  MR_Word input__HeadVar__3_3)
#line 38 "input.m"
{
  {
    bool input__succeeded;
    MR_Word input__conv1_HeadVar__2_2 = (MR_Word) input__HeadVar__2_2;
    MR_Word input__conv2_HeadVar__3_3 = (MR_Word) input__HeadVar__3_3;
    MR_Word input__TypeInfo_4_4 = (MR_Word) (&input__input__type_ctor_info_token_0);

#line 38 "input.m"
    {
#line 38 "input.m"
      mercury__list____Compare____list_1_0(input__TypeInfo_4_4, input__HeadVar__1_1, input__conv1_HeadVar__2_2, input__conv2_HeadVar__3_3);
#line 38 "input.m"
      return;
    }
  }
#line 38 "input.m"
}

#line 38 "input.m"
bool MR_CALL input____Unify____tokens_0_0(
#line 38 "input.m"
  MR_Word input__HeadVar__1_1,
#line 38 "input.m"
  MR_Word input__HeadVar__2_2)
#line 38 "input.m"
{
  {
    bool input__succeeded;
    MR_Word input__conv1_HeadVar__1_1 = (MR_Word) input__HeadVar__1_1;
    MR_Word input__conv2_HeadVar__2_2 = (MR_Word) input__HeadVar__2_2;
    MR_Word input__TypeInfo_3_3 = (MR_Word) (&input__input__type_ctor_info_token_0);

#line 38 "input.m"
    {
#line 38 "input.m"
      input__succeeded = mercury__list____Unify____list_1_0(input__TypeInfo_3_3, input__conv1_HeadVar__1_1, input__conv2_HeadVar__2_2);
    }
    if (input__succeeded)
      input__succeeded = TRUE;
    return input__succeeded;
  }
#line 38 "input.m"
}

#line 32 "input.m"
void MR_CALL input____Compare____token_0_0(
#line 32 "input.m"
  MR_Word * input__HeadVar__1_1,
#line 32 "input.m"
  MR_Word input__HeadVar__2_2,
#line 32 "input.m"
  MR_Word input__HeadVar__3_3)
#line 32 "input.m"
{
  {
    bool input__succeeded;
    MR_Integer input__V_4_4;
    MR_Integer input__V_5_5;

#line 32 "input.m"
#line 32 "input.m"
    switch (MR_tag((MR_Word) input__HeadVar__2_2)) {
#line 32 "input.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 32 "input.m"
      case (MR_Integer) 0:
#line 32 "input.m"
        input__V_4_4 = (MR_Integer) 0;
#line 32 "input.m"
        break;
#line 32 "input.m"
      case (MR_Integer) 1:
#line 32 "input.m"
        input__V_4_4 = (MR_Integer) 1;
#line 32 "input.m"
        break;
#line 32 "input.m"
      case (MR_Integer) 2:
#line 32 "input.m"
        input__V_4_4 = (MR_Integer) 2;
#line 32 "input.m"
        break;
#line 32 "input.m"
      case (MR_Integer) 3:
#line 32 "input.m"
        input__V_4_4 = (MR_Integer) 3;
#line 32 "input.m"
        break;
#line 32 "input.m"
    }
#line 32 "input.m"
#line 32 "input.m"
    switch (MR_tag((MR_Word) input__HeadVar__3_3)) {
#line 32 "input.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 32 "input.m"
      case (MR_Integer) 0:
#line 32 "input.m"
        input__V_5_5 = (MR_Integer) 0;
#line 32 "input.m"
        break;
#line 32 "input.m"
      case (MR_Integer) 1:
#line 32 "input.m"
        input__V_5_5 = (MR_Integer) 1;
#line 32 "input.m"
        break;
#line 32 "input.m"
      case (MR_Integer) 2:
#line 32 "input.m"
        input__V_5_5 = (MR_Integer) 2;
#line 32 "input.m"
        break;
#line 32 "input.m"
      case (MR_Integer) 3:
#line 32 "input.m"
        input__V_5_5 = (MR_Integer) 3;
#line 32 "input.m"
        break;
#line 32 "input.m"
    }
#line 32 "input.m"
    input__succeeded = (input__V_4_4 < input__V_5_5);
#line 32 "input.m"
    if (input__succeeded)
#line 32 "input.m"
      *input__HeadVar__1_1 = (MR_Integer) 1;
#line 32 "input.m"
    else
#line 32 "input.m"
      {
#line 32 "input.m"
        input__succeeded = (input__V_4_4 > input__V_5_5);
#line 32 "input.m"
        if (input__succeeded)
#line 32 "input.m"
          *input__HeadVar__1_1 = (MR_Integer) 2;
#line 32 "input.m"
        else
#line 32 "input.m"
          {
#line 32 "input.m"
            MR_Word input__V_6_6;

#line 32 "input.m"
#line 32 "input.m"
            switch (MR_tag((MR_Word) input__HeadVar__2_2)) {
#line 32 "input.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 32 "input.m"
              case (MR_Integer) 0:
                {
                  MR_Word input__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Word input__V_8_8;

#line 32 "input.m"
                  input__succeeded = (MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 0));
#line 32 "input.m"
                  if ((MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
#line 32 "input.m"
                    input__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__3_3, (MR_Integer) 0)));
                  if (input__succeeded)
                    {
#line 32 "input.m"
                      {
#line 32 "input.m"
                        input____Compare____tag_0_0(&input__V_6_6, input__V_7_7, input__V_8_8);
                      }
#line 32 "input.m"
                      input__succeeded = TRUE;
                    }
                }
#line 32 "input.m"
                break;
#line 32 "input.m"
              case (MR_Integer) 1:
                {
                  MR_Word input__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Word input__V_10_10;

#line 32 "input.m"
                  input__succeeded = (MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 32 "input.m"
                  if ((MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 32 "input.m"
                    input__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__3_3, (MR_Integer) 0)));
                  if (input__succeeded)
                    {
#line 32 "input.m"
                      {
#line 32 "input.m"
                        input____Compare____tag_0_0(&input__V_6_6, input__V_9_9, input__V_10_10);
                      }
#line 32 "input.m"
                      input__succeeded = TRUE;
                    }
                }
#line 32 "input.m"
                break;
#line 32 "input.m"
              case (MR_Integer) 2:
                {
                  MR_Char input__V_11_11 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(2), input__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Char input__V_12_12;

#line 32 "input.m"
                  input__succeeded = (MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 2));
#line 32 "input.m"
                  if ((MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 2)))
#line 32 "input.m"
                    input__V_12_12 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(2), input__HeadVar__3_3, (MR_Integer) 0)));
                  if (input__succeeded)
                    {
#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      input__succeeded = (input__V_11_11 < input__V_12_12);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (input__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        input__V_6_6 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          input__succeeded = (input__V_11_11 == input__V_12_12);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (input__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            input__V_6_6 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            input__V_6_6 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      input__succeeded = TRUE;
                    }
                }
#line 32 "input.m"
                break;
#line 32 "input.m"
              case (MR_Integer) 3:
                {
                  MR_String input__V_13_13 = ((MR_String) (MR_hl_field(MR_mktag(3), input__HeadVar__2_2, (MR_Integer) 0)));
                  MR_String input__V_14_14;
                  MR_Integer input__Res_7_33;
                  MR_Integer input__V_38_38;

#line 32 "input.m"
                  input__succeeded = (MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 3));
#line 32 "input.m"
                  if ((MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 3)))
#line 32 "input.m"
                    input__V_14_14 = ((MR_String) (MR_hl_field(MR_mktag(3), input__HeadVar__3_3, (MR_Integer) 0)));
                  if (input__succeeded)
                    {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL input____Compare____token_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
input__V_13_13
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
input__V_14_14
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
input__Res_7_33
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      input__V_38_38 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      input__succeeded = (input__Res_7_33 < input__V_38_38);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (input__succeeded)
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        input__V_6_6 = (MR_Integer) 1;
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          input__succeeded = (input__Res_7_33 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (input__succeeded)
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            input__V_6_6 = (MR_Integer) 0;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            input__V_6_6 = (MR_Integer) 2;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      input__succeeded = TRUE;
                    }
                }
#line 32 "input.m"
                break;
#line 32 "input.m"
            }
#line 32 "input.m"
            if (input__succeeded)
#line 32 "input.m"
              *input__HeadVar__1_1 = input__V_6_6;
#line 32 "input.m"
            else
#line 32 "input.m"
              {
#line 32 "input.m"
                mercury__private_builtin__compare_error_0_p_0();
#line 32 "input.m"
                return;
              }
#line 32 "input.m"
          }
#line 32 "input.m"
      }
  }
#line 32 "input.m"
}

#line 32 "input.m"
void MR_CALL input____Index____token_0_0(
#line 32 "input.m"
  MR_Word input__HeadVar__1_1,
#line 32 "input.m"
  MR_Integer * input__HeadVar__2_2)
#line 32 "input.m"
{
#line 32 "input.m"
  {
#line 32 "input.m"
    bool input__succeeded;

#line 32 "input.m"
#line 32 "input.m"
    switch (MR_tag((MR_Word) input__HeadVar__1_1)) {
#line 32 "input.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 32 "input.m"
      case (MR_Integer) 0:
#line 32 "input.m"
        *input__HeadVar__2_2 = (MR_Integer) 0;
#line 32 "input.m"
        break;
#line 32 "input.m"
      case (MR_Integer) 1:
#line 32 "input.m"
        *input__HeadVar__2_2 = (MR_Integer) 1;
#line 32 "input.m"
        break;
#line 32 "input.m"
      case (MR_Integer) 2:
#line 32 "input.m"
        *input__HeadVar__2_2 = (MR_Integer) 2;
#line 32 "input.m"
        break;
#line 32 "input.m"
      case (MR_Integer) 3:
#line 32 "input.m"
        *input__HeadVar__2_2 = (MR_Integer) 3;
#line 32 "input.m"
        break;
#line 32 "input.m"
    }
#line 32 "input.m"
  }
#line 32 "input.m"
}

#line 32 "input.m"
bool MR_CALL input____Unify____token_0_0(
#line 32 "input.m"
  MR_Word input__HeadVar__1_1,
#line 32 "input.m"
  MR_Word input__HeadVar__2_2)
#line 32 "input.m"
{
#line 32 "input.m"
  {
#line 32 "input.m"
    bool input__succeeded;
#line 32 "input.m"
    MR_Word input__V_3_3;
#line 32 "input.m"
    MR_Word input__V_4_4;
#line 32 "input.m"
    MR_Word input__V_5_5;
#line 32 "input.m"
    MR_Word input__V_6_6;
#line 32 "input.m"
    MR_Char input__V_7_7;
#line 32 "input.m"
    MR_Char input__V_8_8;
#line 32 "input.m"
    MR_String input__V_9_9;
#line 32 "input.m"
    MR_String input__V_10_10;

#line 32 "input.m"
#line 32 "input.m"
    switch (MR_tag((MR_Word) input__HeadVar__1_1)) {
#line 32 "input.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 32 "input.m"
      case (MR_Integer) 0:
        {
#line 32 "input.m"
          input__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__1_1, (MR_Integer) 0)));
#line 32 "input.m"
          input__succeeded = (MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
#line 32 "input.m"
          if ((MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 32 "input.m"
            input__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 0)));
          if (input__succeeded)
            {
              return input__succeeded = input____Unify____tag_0_0(input__V_3_3, input__V_4_4);
            }
        }
#line 32 "input.m"
        break;
#line 32 "input.m"
      case (MR_Integer) 1:
        {
#line 32 "input.m"
          input__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__1_1, (MR_Integer) 0)));
#line 32 "input.m"
          input__succeeded = (MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 32 "input.m"
          if ((MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 32 "input.m"
            input__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__2_2, (MR_Integer) 0)));
          if (input__succeeded)
            {
              return input__succeeded = input____Unify____tag_0_0(input__V_5_5, input__V_6_6);
            }
        }
#line 32 "input.m"
        break;
#line 32 "input.m"
      case (MR_Integer) 2:
        {
#line 32 "input.m"
          input__V_7_7 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(2), input__HeadVar__1_1, (MR_Integer) 0)));
#line 32 "input.m"
          input__succeeded = (MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 2));
#line 32 "input.m"
          if ((MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 2)))
#line 32 "input.m"
            input__V_8_8 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(2), input__HeadVar__2_2, (MR_Integer) 0)));
          if (input__succeeded)
            input__succeeded = (input__V_7_7 == input__V_8_8);
        }
#line 32 "input.m"
        break;
#line 32 "input.m"
      case (MR_Integer) 3:
        {
#line 32 "input.m"
          input__V_9_9 = ((MR_String) (MR_hl_field(MR_mktag(3), input__HeadVar__1_1, (MR_Integer) 0)));
#line 32 "input.m"
          input__succeeded = (MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 3));
#line 32 "input.m"
          if ((MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 3)))
#line 32 "input.m"
            input__V_10_10 = ((MR_String) (MR_hl_field(MR_mktag(3), input__HeadVar__2_2, (MR_Integer) 0)));
          if (input__succeeded)
            input__succeeded = (strcmp(input__V_9_9, input__V_10_10) == 0);
        }
#line 32 "input.m"
        break;
#line 32 "input.m"
    }
#line 32 "input.m"
    return input__succeeded;
#line 32 "input.m"
  }
#line 32 "input.m"
}

#line 30 "input.m"
void MR_CALL input____Compare____extents_0_0(
#line 30 "input.m"
  MR_Word * input__HeadVar__1_1,
#line 30 "input.m"
  MR_Word input__HeadVar__2_2,
#line 30 "input.m"
  MR_Word input__HeadVar__3_3)
#line 30 "input.m"
{
  {
    bool input__succeeded;
    MR_Array input__conv1_HeadVar__2_2 = (MR_Array) input__HeadVar__2_2;
    MR_Array input__conv2_HeadVar__3_3 = (MR_Array) input__HeadVar__3_3;
    MR_Word input__TypeInfo_4_4 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);

#line 30 "input.m"
    {
#line 30 "input.m"
      mercury__array____Compare____array_1_0(input__TypeInfo_4_4, input__HeadVar__1_1, (MR_Array) input__conv1_HeadVar__2_2, (MR_Array) input__conv2_HeadVar__3_3);
#line 30 "input.m"
      return;
    }
  }
#line 30 "input.m"
}

#line 30 "input.m"
bool MR_CALL input____Unify____extents_0_0(
#line 30 "input.m"
  MR_Word input__HeadVar__1_1,
#line 30 "input.m"
  MR_Word input__HeadVar__2_2)
#line 30 "input.m"
{
  {
    bool input__succeeded;
    MR_Array input__conv1_HeadVar__1_1 = (MR_Array) input__HeadVar__1_1;
    MR_Array input__conv2_HeadVar__2_2 = (MR_Array) input__HeadVar__2_2;
    MR_Word input__TypeInfo_3_3 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);

#line 30 "input.m"
    {
#line 30 "input.m"
      input__succeeded = mercury__array____Unify____array_1_0(input__TypeInfo_3_3, (MR_Array) input__conv1_HeadVar__1_1, (MR_Array) input__conv2_HeadVar__2_2);
    }
    if (input__succeeded)
      input__succeeded = TRUE;
    return input__succeeded;
  }
#line 30 "input.m"
}

#line 28 "input.m"
void MR_CALL input____Compare____attrss_0_0(
#line 28 "input.m"
  MR_Word * input__HeadVar__1_1,
#line 28 "input.m"
  MR_Word input__HeadVar__2_2,
#line 28 "input.m"
  MR_Word input__HeadVar__3_3)
#line 28 "input.m"
{
  {
    bool input__succeeded;
    MR_Array input__conv1_HeadVar__2_2 = (MR_Array) input__HeadVar__2_2;
    MR_Array input__conv2_HeadVar__3_3 = (MR_Array) input__HeadVar__3_3;
    MR_Word input__TypeInfo_4_4 = (MR_Word) (&attrs__attrs__type_ctor_info_attrs_0);

#line 28 "input.m"
    {
#line 28 "input.m"
      mercury__array____Compare____array_1_0(input__TypeInfo_4_4, input__HeadVar__1_1, (MR_Array) input__conv1_HeadVar__2_2, (MR_Array) input__conv2_HeadVar__3_3);
#line 28 "input.m"
      return;
    }
  }
#line 28 "input.m"
}

#line 28 "input.m"
bool MR_CALL input____Unify____attrss_0_0(
#line 28 "input.m"
  MR_Word input__HeadVar__1_1,
#line 28 "input.m"
  MR_Word input__HeadVar__2_2)
#line 28 "input.m"
{
  {
    bool input__succeeded;
    MR_Array input__conv1_HeadVar__1_1 = (MR_Array) input__HeadVar__1_1;
    MR_Array input__conv2_HeadVar__2_2 = (MR_Array) input__HeadVar__2_2;
    MR_Word input__TypeInfo_3_3 = (MR_Word) (&attrs__attrs__type_ctor_info_attrs_0);

#line 28 "input.m"
    {
#line 28 "input.m"
      input__succeeded = mercury__array____Unify____array_1_0(input__TypeInfo_3_3, (MR_Array) input__conv1_HeadVar__1_1, (MR_Array) input__conv2_HeadVar__2_2);
    }
    if (input__succeeded)
      input__succeeded = TRUE;
    return input__succeeded;
  }
#line 28 "input.m"
}

#line 26 "input.m"
void MR_CALL input____Compare____tags_0_0(
#line 26 "input.m"
  MR_Word * input__HeadVar__1_1,
#line 26 "input.m"
  MR_Word input__HeadVar__2_2,
#line 26 "input.m"
  MR_Word input__HeadVar__3_3)
#line 26 "input.m"
{
  {
    bool input__succeeded;
    MR_Word input__conv1_HeadVar__2_2 = (MR_Word) input__HeadVar__2_2;
    MR_Word input__conv2_HeadVar__3_3 = (MR_Word) input__HeadVar__3_3;
    MR_Word input__TypeInfo_4_4 = (MR_Word) (&input__input__type_ctor_info_tag_0);

#line 26 "input.m"
    {
#line 26 "input.m"
      mercury__list____Compare____list_1_0(input__TypeInfo_4_4, input__HeadVar__1_1, input__conv1_HeadVar__2_2, input__conv2_HeadVar__3_3);
#line 26 "input.m"
      return;
    }
  }
#line 26 "input.m"
}

#line 26 "input.m"
bool MR_CALL input____Unify____tags_0_0(
#line 26 "input.m"
  MR_Word input__HeadVar__1_1,
#line 26 "input.m"
  MR_Word input__HeadVar__2_2)
#line 26 "input.m"
{
  {
    bool input__succeeded;
    MR_Word input__conv1_HeadVar__1_1 = (MR_Word) input__HeadVar__1_1;
    MR_Word input__conv2_HeadVar__2_2 = (MR_Word) input__HeadVar__2_2;
    MR_Word input__TypeInfo_3_3 = (MR_Word) (&input__input__type_ctor_info_tag_0);

#line 26 "input.m"
    {
#line 26 "input.m"
      input__succeeded = mercury__list____Unify____list_1_0(input__TypeInfo_3_3, input__conv1_HeadVar__1_1, input__conv2_HeadVar__2_2);
    }
    if (input__succeeded)
      input__succeeded = TRUE;
    return input__succeeded;
  }
#line 26 "input.m"
}

#line 23 "input.m"
void MR_CALL input____Compare____tag_0_0(
#line 23 "input.m"
  MR_Word * input__HeadVar__1_1,
#line 23 "input.m"
  MR_Word input__HeadVar__2_2,
#line 23 "input.m"
  MR_Word input__HeadVar__3_3)
#line 23 "input.m"
{
  {
    bool input__succeeded;
    MR_Integer input__V_4_4;
    MR_Integer input__V_5_5;

#line 23 "input.m"
    {
#line 23 "input.m"
      input____Index____tag_0_0(input__HeadVar__2_2, &input__V_4_4);
    }
#line 23 "input.m"
    {
#line 23 "input.m"
      input____Index____tag_0_0(input__HeadVar__3_3, &input__V_5_5);
    }
#line 23 "input.m"
    input__succeeded = (input__V_4_4 < input__V_5_5);
#line 23 "input.m"
    if (input__succeeded)
#line 23 "input.m"
      *input__HeadVar__1_1 = (MR_Integer) 1;
#line 23 "input.m"
    else
#line 23 "input.m"
      {
#line 23 "input.m"
        input__succeeded = (input__V_4_4 > input__V_5_5);
#line 23 "input.m"
        if (input__succeeded)
#line 23 "input.m"
          *input__HeadVar__1_1 = (MR_Integer) 2;
#line 23 "input.m"
        else
#line 23 "input.m"
          {
#line 23 "input.m"
            MR_Word input__V_6_6;

#line 23 "input.m"
#line 23 "input.m"
            switch (MR_tag((MR_Word) input__HeadVar__2_2)) {
#line 23 "input.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 23 "input.m"
              case (MR_Integer) 0:
#line 23 "input.m"
#line 23 "input.m"
                switch (MR_unmkbody(input__HeadVar__2_2)) {
#line 23 "input.m"
                  default: /*NOTREACHED*/ MR_assert(0);
#line 23 "input.m"
                  case (MR_Integer) 0:
                    {
#line 23 "input.m"
                      input__succeeded = (input__HeadVar__3_3 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
                      if (input__succeeded)
                        {
#line 23 "input.m"
                          input__V_6_6 = (MR_Integer) 0;
#line 23 "input.m"
                          input__succeeded = TRUE;
                        }
                    }
#line 23 "input.m"
                    break;
#line 23 "input.m"
                  case (MR_Integer) 1:
                    {
#line 23 "input.m"
                      input__succeeded = (input__HeadVar__3_3 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 1)));
                      if (input__succeeded)
                        {
#line 23 "input.m"
                          input__V_6_6 = (MR_Integer) 0;
#line 23 "input.m"
                          input__succeeded = TRUE;
                        }
                    }
#line 23 "input.m"
                    break;
#line 23 "input.m"
                  case (MR_Integer) 2:
                    {
#line 23 "input.m"
                      input__succeeded = (input__HeadVar__3_3 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 2)));
                      if (input__succeeded)
                        {
#line 23 "input.m"
                          input__V_6_6 = (MR_Integer) 0;
#line 23 "input.m"
                          input__succeeded = TRUE;
                        }
                    }
#line 23 "input.m"
                    break;
#line 23 "input.m"
                  case (MR_Integer) 3:
                    {
#line 23 "input.m"
                      input__succeeded = (input__HeadVar__3_3 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 3)));
                      if (input__succeeded)
                        {
#line 23 "input.m"
                          input__V_6_6 = (MR_Integer) 0;
#line 23 "input.m"
                          input__succeeded = TRUE;
                        }
                    }
#line 23 "input.m"
                    break;
#line 23 "input.m"
                  case (MR_Integer) 4:
                    {
#line 23 "input.m"
                      input__succeeded = (input__HeadVar__3_3 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 4)));
                      if (input__succeeded)
                        {
#line 23 "input.m"
                          input__V_6_6 = (MR_Integer) 0;
#line 23 "input.m"
                          input__succeeded = TRUE;
                        }
                    }
#line 23 "input.m"
                    break;
#line 23 "input.m"
                  case (MR_Integer) 5:
                    {
#line 23 "input.m"
                      input__succeeded = (input__HeadVar__3_3 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 5)));
                      if (input__succeeded)
                        {
#line 23 "input.m"
                          input__V_6_6 = (MR_Integer) 0;
#line 23 "input.m"
                          input__succeeded = TRUE;
                        }
                    }
#line 23 "input.m"
                    break;
#line 23 "input.m"
                }
#line 23 "input.m"
                break;
#line 23 "input.m"
              case (MR_Integer) 1:
                {
                  MR_Integer input__V_7_7 = ((MR_Integer) (MR_hl_field(MR_mktag(1), input__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Integer input__V_8_8;

#line 23 "input.m"
                  input__succeeded = (MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 23 "input.m"
                  if ((MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 23 "input.m"
                    input__V_8_8 = ((MR_Integer) (MR_hl_field(MR_mktag(1), input__HeadVar__3_3, (MR_Integer) 0)));
                  if (input__succeeded)
                    {
#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      input__succeeded = (input__V_7_7 < input__V_8_8);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (input__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        input__V_6_6 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          input__succeeded = (input__V_7_7 == input__V_8_8);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (input__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            input__V_6_6 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            input__V_6_6 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      input__succeeded = TRUE;
                    }
                }
#line 23 "input.m"
                break;
#line 23 "input.m"
              case (MR_Integer) 2:
                {
                  MR_Integer input__V_9_9 = ((MR_Integer) (MR_hl_field(MR_mktag(2), input__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Integer input__V_10_10;

#line 23 "input.m"
                  input__succeeded = (MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 2));
#line 23 "input.m"
                  if ((MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 2)))
#line 23 "input.m"
                    input__V_10_10 = ((MR_Integer) (MR_hl_field(MR_mktag(2), input__HeadVar__3_3, (MR_Integer) 0)));
                  if (input__succeeded)
                    {
#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      input__succeeded = (input__V_9_9 < input__V_10_10);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (input__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        input__V_6_6 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          input__succeeded = (input__V_9_9 == input__V_10_10);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (input__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            input__V_6_6 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            input__V_6_6 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      input__succeeded = TRUE;
                    }
                }
#line 23 "input.m"
                break;
#line 23 "input.m"
              case (MR_Integer) 3:
                {
                  MR_Word input__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(3), input__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Word input__V_12_12;
                  MR_Integer input__V_16_16;
                  MR_Integer input__V_17_17;

#line 23 "input.m"
                  input__succeeded = (MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 3));
#line 23 "input.m"
                  if ((MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 3)))
#line 23 "input.m"
                    input__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(3), input__HeadVar__3_3, (MR_Integer) 0)));
                  if (input__succeeded)
                    {
                      input__V_16_16 = (MR_Integer) input__V_11_11;
                      input__V_17_17 = (MR_Integer) input__V_12_12;
#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      input__succeeded = (input__V_16_16 < input__V_17_17);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (input__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        input__V_6_6 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          input__succeeded = (input__V_16_16 == input__V_17_17);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (input__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            input__V_6_6 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            input__V_6_6 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      input__succeeded = TRUE;
                    }
                }
#line 23 "input.m"
                break;
#line 23 "input.m"
            }
#line 23 "input.m"
            if (input__succeeded)
#line 23 "input.m"
              *input__HeadVar__1_1 = input__V_6_6;
#line 23 "input.m"
            else
#line 23 "input.m"
              {
#line 23 "input.m"
                mercury__private_builtin__compare_error_0_p_0();
#line 23 "input.m"
                return;
              }
#line 23 "input.m"
          }
#line 23 "input.m"
      }
  }
#line 23 "input.m"
}

#line 23 "input.m"
void MR_CALL input____Index____tag_0_0(
#line 23 "input.m"
  MR_Word input__HeadVar__1_1,
#line 23 "input.m"
  MR_Integer * input__HeadVar__2_2)
#line 23 "input.m"
{
#line 23 "input.m"
  {
#line 23 "input.m"
    bool input__succeeded;

#line 23 "input.m"
#line 23 "input.m"
    switch (MR_tag((MR_Word) input__HeadVar__1_1)) {
#line 23 "input.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 23 "input.m"
      case (MR_Integer) 0:
#line 23 "input.m"
#line 23 "input.m"
        switch (MR_unmkbody(input__HeadVar__1_1)) {
#line 23 "input.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 23 "input.m"
          case (MR_Integer) 0:
#line 23 "input.m"
            *input__HeadVar__2_2 = (MR_Integer) 0;
#line 23 "input.m"
            break;
#line 23 "input.m"
          case (MR_Integer) 1:
#line 23 "input.m"
            *input__HeadVar__2_2 = (MR_Integer) 1;
#line 23 "input.m"
            break;
#line 23 "input.m"
          case (MR_Integer) 2:
#line 23 "input.m"
            *input__HeadVar__2_2 = (MR_Integer) 2;
#line 23 "input.m"
            break;
#line 23 "input.m"
          case (MR_Integer) 3:
#line 23 "input.m"
            *input__HeadVar__2_2 = (MR_Integer) 3;
#line 23 "input.m"
            break;
#line 23 "input.m"
          case (MR_Integer) 4:
#line 23 "input.m"
            *input__HeadVar__2_2 = (MR_Integer) 4;
#line 23 "input.m"
            break;
#line 23 "input.m"
          case (MR_Integer) 5:
#line 23 "input.m"
            *input__HeadVar__2_2 = (MR_Integer) 5;
#line 23 "input.m"
            break;
#line 23 "input.m"
        }
#line 23 "input.m"
        break;
#line 23 "input.m"
      case (MR_Integer) 1:
#line 23 "input.m"
        *input__HeadVar__2_2 = (MR_Integer) 6;
#line 23 "input.m"
        break;
#line 23 "input.m"
      case (MR_Integer) 2:
#line 23 "input.m"
        *input__HeadVar__2_2 = (MR_Integer) 7;
#line 23 "input.m"
        break;
#line 23 "input.m"
      case (MR_Integer) 3:
#line 23 "input.m"
        *input__HeadVar__2_2 = (MR_Integer) 8;
#line 23 "input.m"
        break;
#line 23 "input.m"
    }
#line 23 "input.m"
  }
#line 23 "input.m"
}

#line 23 "input.m"
bool MR_CALL input____Unify____tag_0_0(
#line 23 "input.m"
  MR_Word input__HeadVar__1_1,
#line 23 "input.m"
  MR_Word input__HeadVar__2_2)
#line 23 "input.m"
{
#line 23 "input.m"
  {
#line 23 "input.m"
    bool input__succeeded;
#line 23 "input.m"
    MR_Integer input__V_3_3;
#line 23 "input.m"
    MR_Integer input__V_4_4;
#line 23 "input.m"
    MR_Integer input__V_5_5;
#line 23 "input.m"
    MR_Integer input__V_6_6;
#line 23 "input.m"
    MR_Word input__V_7_7;
#line 23 "input.m"
    MR_Word input__V_8_8;

#line 23 "input.m"
#line 23 "input.m"
    switch (MR_tag((MR_Word) input__HeadVar__1_1)) {
#line 23 "input.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 23 "input.m"
      case (MR_Integer) 0:
#line 23 "input.m"
#line 23 "input.m"
        switch (MR_unmkbody(input__HeadVar__1_1)) {
#line 23 "input.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 23 "input.m"
          case (MR_Integer) 0:
#line 23 "input.m"
            input__succeeded = (input__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 23 "input.m"
            break;
#line 23 "input.m"
          case (MR_Integer) 1:
#line 23 "input.m"
            input__succeeded = (input__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 1)));
#line 23 "input.m"
            break;
#line 23 "input.m"
          case (MR_Integer) 2:
#line 23 "input.m"
            input__succeeded = (input__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 2)));
#line 23 "input.m"
            break;
#line 23 "input.m"
          case (MR_Integer) 3:
#line 23 "input.m"
            input__succeeded = (input__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 3)));
#line 23 "input.m"
            break;
#line 23 "input.m"
          case (MR_Integer) 4:
#line 23 "input.m"
            input__succeeded = (input__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 4)));
#line 23 "input.m"
            break;
#line 23 "input.m"
          case (MR_Integer) 5:
#line 23 "input.m"
            input__succeeded = (input__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 5)));
#line 23 "input.m"
            break;
#line 23 "input.m"
        }
#line 23 "input.m"
        break;
#line 23 "input.m"
      case (MR_Integer) 1:
        {
#line 23 "input.m"
          input__V_3_3 = ((MR_Integer) (MR_hl_field(MR_mktag(1), input__HeadVar__1_1, (MR_Integer) 0)));
#line 23 "input.m"
          input__succeeded = (MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 23 "input.m"
          if ((MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 23 "input.m"
            input__V_4_4 = ((MR_Integer) (MR_hl_field(MR_mktag(1), input__HeadVar__2_2, (MR_Integer) 0)));
          if (input__succeeded)
            input__succeeded = (input__V_3_3 == input__V_4_4);
        }
#line 23 "input.m"
        break;
#line 23 "input.m"
      case (MR_Integer) 2:
        {
#line 23 "input.m"
          input__V_5_5 = ((MR_Integer) (MR_hl_field(MR_mktag(2), input__HeadVar__1_1, (MR_Integer) 0)));
#line 23 "input.m"
          input__succeeded = (MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 2));
#line 23 "input.m"
          if ((MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 2)))
#line 23 "input.m"
            input__V_6_6 = ((MR_Integer) (MR_hl_field(MR_mktag(2), input__HeadVar__2_2, (MR_Integer) 0)));
          if (input__succeeded)
            input__succeeded = (input__V_5_5 == input__V_6_6);
        }
#line 23 "input.m"
        break;
#line 23 "input.m"
      case (MR_Integer) 3:
        {
#line 23 "input.m"
          input__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(3), input__HeadVar__1_1, (MR_Integer) 0)));
#line 23 "input.m"
          input__succeeded = (MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 3));
#line 23 "input.m"
          if ((MR_tag((MR_Word) input__HeadVar__2_2) == MR_mktag((MR_Integer) 3)))
#line 23 "input.m"
            input__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(3), input__HeadVar__2_2, (MR_Integer) 0)));
          if (input__succeeded)
            input__succeeded = (input__V_7_7 == input__V_8_8);
        }
#line 23 "input.m"
        break;
#line 23 "input.m"
    }
#line 23 "input.m"
    return input__succeeded;
#line 23 "input.m"
  }
#line 23 "input.m"
}

#line 383 "input.m"
static MR_Word MR_CALL input__finish_aes_3_f_0(
#line 383 "input.m"
  MR_Word input__HeadVar__1_1,
#line 383 "input.m"
  MR_Word input__HeadVar__2_2)
#line 383 "input.m"
{
#line 385 "input.m"
  {
#line 385 "input.m"
    /* tailcall optimized into a loop */
#line 385 "input.m"
  loop_top:;
#line 385 "input.m"
    {
#line 385 "input.m"
      bool input__succeeded;
#line 385 "input.m"
      MR_Word input__HeadVar__3_3;
#line 385 "input.m"
      MR_Word input__V_29_29;
#line 385 "input.m"
      MR_Word input__V_30_30;
#line 385 "input.m"
      MR_Integer input__V_31_31;
#line 385 "input.m"
      MR_Word input__V_32_32;

#line 385 "input.m"
      if ((input__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 385 "input.m"
        input__HeadVar__3_3 = input__HeadVar__2_2;
#line 385 "input.m"
      else
#line 385 "input.m"
        {
#line 385 "input.m"
          MR_Word input__As1_13;
#line 385 "input.m"
          MR_Integer input__E1_14;
#line 385 "input.m"
          MR_Word input__AEs0_15;
#line 385 "input.m"
          MR_Word input__V_19_19;

#line 387 "input.m"
          input__V_30_30 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__1_1, (MR_Integer) 0)));
#line 387 "input.m"
          input__V_29_29 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__1_1, (MR_Integer) 1)));
#line 387 "input.m"
          input__V_32_32 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__V_30_30, (MR_Integer) 0)));
#line 387 "input.m"
          input__V_31_31 = ((MR_Integer) (MR_hl_field(MR_mktag(0), input__V_30_30, (MR_Integer) 1)));
#line 385 "input.m"
          if ((input__V_29_29 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 387 "input.m"
            {
#line 388 "input.m"
              input__succeeded = (input__V_31_31 == (MR_Integer) 0);
#line 387 "input.m"
              if (input__succeeded)
#line 387 "input.m"
                input__HeadVar__3_3 = input__HeadVar__2_2;
#line 387 "input.m"
              else
#line 387 "input.m"
                {
#line 387 "input.m"
                  input__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 387 "input.m"
                  MR_hl_field(MR_mktag(1), input__HeadVar__3_3, 0) = ((MR_Box) (input__V_30_30));
#line 387 "input.m"
                  MR_hl_field(MR_mktag(1), input__HeadVar__3_3, 1) = ((MR_Box) (input__HeadVar__2_2));
#line 387 "input.m"
                }
#line 387 "input.m"
            }
#line 385 "input.m"
          else
#line 385 "input.m"
            {
#line 390 "input.m"
              input__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__V_29_29, (MR_Integer) 0)));
#line 390 "input.m"
              input__AEs0_15 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__V_29_29, (MR_Integer) 1)));
#line 390 "input.m"
              input__As1_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__V_19_19, (MR_Integer) 0)));
#line 390 "input.m"
              input__E1_14 = ((MR_Integer) (MR_hl_field(MR_mktag(0), input__V_19_19, (MR_Integer) 1)));
#line 391 "input.m"
              input__succeeded = (input__V_31_31 == (MR_Integer) 0);
#line 390 "input.m"
              if (input__succeeded)
#line 390 "input.m"
                {
#line 390 "input.m"
                  /* direct tailcall eliminated */
#line 390 "input.m"
                  {
#line 390 "input.m"
                    MR_Word input__HeadVar__1__tmp_copy_1 = input__V_29_29;

#line 390 "input.m"
                    input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 390 "input.m"
                  }
#line 390 "input.m"
                  goto loop_top;
#line 390 "input.m"
                }
#line 390 "input.m"
              else
#line 390 "input.m"
                {
#line 390 "input.m"
                  MR_Word input__V_22_22;
#line 390 "input.m"
                  MR_Word input__V_23_23;
#line 390 "input.m"
                  MR_Integer input__V_24_24;
#line 390 "input.m"
                  MR_Word input__V_26_26;

#line 393 "input.m"
                  {
#line 393 "input.m"
                    input__succeeded = attrs__equivalent_2_p_0(input__V_32_32, input__As1_13);
                  }
#line 390 "input.m"
                  if (input__succeeded)
                    {
#line 394 "input.m"
                      input__V_24_24 = (input__V_31_31 + input__E1_14);
#line 394 "input.m"
                      {
#line 394 "input.m"
                        input__V_23_23 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 394 "input.m"
                        MR_hl_field(MR_mktag(0), input__V_23_23, 0) = ((MR_Box) (input__As1_13));
#line 394 "input.m"
                        MR_hl_field(MR_mktag(0), input__V_23_23, 1) = ((MR_Box) (input__V_24_24));
#line 394 "input.m"
                      }
#line 394 "input.m"
                      {
#line 394 "input.m"
                        input__V_22_22 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 394 "input.m"
                        MR_hl_field(MR_mktag(1), input__V_22_22, 0) = ((MR_Box) (input__V_23_23));
#line 394 "input.m"
                        MR_hl_field(MR_mktag(1), input__V_22_22, 1) = ((MR_Box) (input__AEs0_15));
#line 394 "input.m"
                      }
#line 390 "input.m"
                      {
#line 390 "input.m"
                        /* direct tailcall eliminated */
#line 390 "input.m"
                        {
#line 390 "input.m"
                          MR_Word input__HeadVar__1__tmp_copy_1 = input__V_22_22;

#line 390 "input.m"
                          input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 390 "input.m"
                        }
#line 390 "input.m"
                        goto loop_top;
#line 390 "input.m"
                      }
                    }
#line 390 "input.m"
                  else
                    {
#line 395 "input.m"
                      {
#line 395 "input.m"
                        input__V_26_26 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 395 "input.m"
                        MR_hl_field(MR_mktag(1), input__V_26_26, 0) = ((MR_Box) (input__V_30_30));
#line 395 "input.m"
                        MR_hl_field(MR_mktag(1), input__V_26_26, 1) = ((MR_Box) (input__HeadVar__2_2));
#line 395 "input.m"
                      }
#line 390 "input.m"
                      {
#line 390 "input.m"
                        /* direct tailcall eliminated */
#line 390 "input.m"
                        {
#line 390 "input.m"
                          MR_Word input__HeadVar__1__tmp_copy_1 = input__V_29_29;
#line 390 "input.m"
                          MR_Word input__HeadVar__2__tmp_copy_2 = input__V_26_26;

#line 390 "input.m"
                          input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 390 "input.m"
                          input__HeadVar__2_2 = input__HeadVar__2__tmp_copy_2;
#line 390 "input.m"
                        }
#line 390 "input.m"
                        goto loop_top;
#line 390 "input.m"
                      }
                    }
#line 390 "input.m"
                }
#line 385 "input.m"
            }
#line 385 "input.m"
        }
#line 385 "input.m"
      return input__HeadVar__3_3;
#line 385 "input.m"
    }
#line 385 "input.m"
  }
#line 383 "input.m"
}
static /* final */ const MR_Box input__const_20_0_1_TypeInfo_61_61[3] = {
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_pair_2))),
		((MR_Box) ((&attrs__attrs__type_ctor_info_attrs_0))),
		((MR_Box) ((&mercury__builtin__builtin__type_ctor_info_int_0)))};
static /* final */ const MR_Box input__const_20_0_2_TypeInfo_63_63[2] = {
		((MR_Box) ((&mercury__list__list__type_ctor_info_list_1))),
		((MR_Box) (&input__const_20_0_1_TypeInfo_61_61))};

#line 361 "input.m"
static MR_Word MR_CALL input__aes_6_f_0(
#line 361 "input.m"
  MR_Word input__HeadVar__1_1,
#line 361 "input.m"
  MR_Word input__HeadVar__2_2,
#line 361 "input.m"
  MR_Integer input__HeadVar__3_3,
#line 361 "input.m"
  MR_Word input__HeadVar__4_4,
#line 361 "input.m"
  MR_Word input__HeadVar__5_5)
#line 361 "input.m"
{
#line 363 "input.m"
  {
#line 363 "input.m"
    /* tailcall optimized into a loop */
#line 363 "input.m"
  loop_top:;
#line 363 "input.m"
    {
#line 363 "input.m"
      bool input__succeeded;
#line 363 "input.m"
      MR_Word input__HeadVar__6_6;

#line 363 "input.m"
      if ((input__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
        {
          MR_Word input__V_11_11;
          MR_Word input__V_12_12;
          MR_Word input__V_13_13;

#line 364 "input.m"
          {
#line 364 "input.m"
            input__V_13_13 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 364 "input.m"
            MR_hl_field(MR_mktag(0), input__V_13_13, 0) = ((MR_Box) (input__HeadVar__2_2));
#line 364 "input.m"
            MR_hl_field(MR_mktag(0), input__V_13_13, 1) = ((MR_Box) (input__HeadVar__3_3));
#line 364 "input.m"
          }
#line 364 "input.m"
          {
#line 364 "input.m"
            input__V_11_11 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 364 "input.m"
            MR_hl_field(MR_mktag(1), input__V_11_11, 0) = ((MR_Box) (input__V_13_13));
#line 364 "input.m"
            MR_hl_field(MR_mktag(1), input__V_11_11, 1) = ((MR_Box) (input__HeadVar__5_5));
#line 364 "input.m"
          }
#line 364 "input.m"
          input__V_12_12 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 363 "input.m"
          {
#line 363 "input.m"
            return input__HeadVar__6_6 = input__finish_aes_3_f_0(input__V_11_11, input__V_12_12);
          }
        }
#line 363 "input.m"
      else
#line 363 "input.m"
        {
          MR_Word input__V_64_64 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__1_1, (MR_Integer) 1)));
          MR_Word input__V_65_65 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__1_1, (MR_Integer) 0)));

#line 363 "input.m"
#line 363 "input.m"
          switch (MR_tag((MR_Word) input__V_65_65)) {
#line 363 "input.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 363 "input.m"
            case (MR_Integer) 0:
              {
                MR_Word input__Tag_32 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__V_65_65, (MR_Integer) 0)));
                MR_Word input__V_39_39;
                MR_Integer input__V_40_40;
                MR_Word input__V_41_41;
                MR_Word input__V_42_42;
                MR_Word input__V_43_43;

#line 373 "input.m"
                {
#line 373 "input.m"
                  input__V_39_39 = input__apply_tag_3_f_0(input__Tag_32, input__HeadVar__2_2);
                }
#line 373 "input.m"
                input__V_40_40 = (MR_Integer) 0;
#line 373 "input.m"
                {
#line 373 "input.m"
                  input__V_41_41 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 373 "input.m"
                  MR_hl_field(MR_mktag(1), input__V_41_41, 0) = ((MR_Box) (input__HeadVar__2_2));
#line 373 "input.m"
                  MR_hl_field(MR_mktag(1), input__V_41_41, 1) = ((MR_Box) (input__HeadVar__4_4));
#line 373 "input.m"
                }
#line 373 "input.m"
                {
#line 373 "input.m"
                  input__V_43_43 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 373 "input.m"
                  MR_hl_field(MR_mktag(0), input__V_43_43, 0) = ((MR_Box) (input__HeadVar__2_2));
#line 373 "input.m"
                  MR_hl_field(MR_mktag(0), input__V_43_43, 1) = ((MR_Box) (input__HeadVar__3_3));
#line 373 "input.m"
                }
#line 373 "input.m"
                {
#line 373 "input.m"
                  input__V_42_42 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 373 "input.m"
                  MR_hl_field(MR_mktag(1), input__V_42_42, 0) = ((MR_Box) (input__V_43_43));
#line 373 "input.m"
                  MR_hl_field(MR_mktag(1), input__V_42_42, 1) = ((MR_Box) (input__HeadVar__5_5));
#line 373 "input.m"
                }
#line 372 "input.m"
                {
#line 372 "input.m"
                  /* direct tailcall eliminated */
#line 372 "input.m"
                  {
#line 372 "input.m"
                    MR_Word input__HeadVar__1__tmp_copy_1 = input__V_64_64;
#line 372 "input.m"
                    MR_Word input__HeadVar__2__tmp_copy_2 = input__V_39_39;
#line 372 "input.m"
                    MR_Integer input__HeadVar__3__tmp_copy_3 = input__V_40_40;
#line 372 "input.m"
                    MR_Word input__HeadVar__4__tmp_copy_4 = input__V_41_41;
#line 372 "input.m"
                    MR_Word input__HeadVar__5__tmp_copy_5 = input__V_42_42;

#line 372 "input.m"
                    input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 372 "input.m"
                    input__HeadVar__2_2 = input__HeadVar__2__tmp_copy_2;
#line 372 "input.m"
                    input__HeadVar__3_3 = input__HeadVar__3__tmp_copy_3;
#line 372 "input.m"
                    input__HeadVar__4_4 = input__HeadVar__4__tmp_copy_4;
#line 372 "input.m"
                    input__HeadVar__5_5 = input__HeadVar__5__tmp_copy_5;
#line 372 "input.m"
                  }
#line 372 "input.m"
                  goto loop_top;
#line 372 "input.m"
                }
              }
#line 363 "input.m"
              break;
#line 363 "input.m"
            case (MR_Integer) 1:
#line 375 "input.m"
              {
#line 375 "input.m"
                MR_Word input__As_50;
#line 375 "input.m"
                MR_Word input__Stk_51;

#line 376 "input.m"
                input__succeeded = (MR_tag((MR_Word) input__HeadVar__4_4) == MR_mktag((MR_Integer) 1));
#line 376 "input.m"
                if ((MR_tag((MR_Word) input__HeadVar__4_4) == MR_mktag((MR_Integer) 1)))
#line 376 "input.m"
                  {
#line 376 "input.m"
                    input__As_50 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__4_4, (MR_Integer) 0)));
#line 376 "input.m"
                    input__Stk_51 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__4_4, (MR_Integer) 1)));
#line 376 "input.m"
                  }
#line 375 "input.m"
                if (input__succeeded)
                  {
                    MR_Integer input__V_53_53 = (MR_Integer) 0;
                    MR_Word input__V_54_54;
                    MR_Word input__V_55_55;

#line 377 "input.m"
                    {
#line 377 "input.m"
                      input__V_55_55 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 377 "input.m"
                      MR_hl_field(MR_mktag(0), input__V_55_55, 0) = ((MR_Box) (input__HeadVar__2_2));
#line 377 "input.m"
                      MR_hl_field(MR_mktag(0), input__V_55_55, 1) = ((MR_Box) (input__HeadVar__3_3));
#line 377 "input.m"
                    }
#line 377 "input.m"
                    {
#line 377 "input.m"
                      input__V_54_54 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 377 "input.m"
                      MR_hl_field(MR_mktag(1), input__V_54_54, 0) = ((MR_Box) (input__V_55_55));
#line 377 "input.m"
                      MR_hl_field(MR_mktag(1), input__V_54_54, 1) = ((MR_Box) (input__HeadVar__5_5));
#line 377 "input.m"
                    }
#line 375 "input.m"
                    {
#line 375 "input.m"
                      /* direct tailcall eliminated */
#line 375 "input.m"
                      {
#line 375 "input.m"
                        MR_Word input__HeadVar__1__tmp_copy_1 = input__V_64_64;
#line 375 "input.m"
                        MR_Word input__HeadVar__2__tmp_copy_2 = input__As_50;
#line 375 "input.m"
                        MR_Integer input__HeadVar__3__tmp_copy_3 = input__V_53_53;
#line 375 "input.m"
                        MR_Word input__HeadVar__4__tmp_copy_4 = input__Stk_51;
#line 375 "input.m"
                        MR_Word input__HeadVar__5__tmp_copy_5 = input__V_54_54;

#line 375 "input.m"
                        input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 375 "input.m"
                        input__HeadVar__2_2 = input__HeadVar__2__tmp_copy_2;
#line 375 "input.m"
                        input__HeadVar__3_3 = input__HeadVar__3__tmp_copy_3;
#line 375 "input.m"
                        input__HeadVar__4_4 = input__HeadVar__4__tmp_copy_4;
#line 375 "input.m"
                        input__HeadVar__5_5 = input__HeadVar__5__tmp_copy_5;
#line 375 "input.m"
                      }
#line 375 "input.m"
                      goto loop_top;
#line 375 "input.m"
                    }
                  }
#line 375 "input.m"
                else
                  {
                    MR_String input__V_56_56 = (MR_String) "input__aes: glark!";
                    MR_Word input__TypeInfo_57_57 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
                    MR_Word input__TypeInfo_58_58 = (MR_Word) (&attrs__attrs__type_ctor_info_attrs_0);
                    MR_Word input__TypeInfo_59_59 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
                    MR_Word input__TypeInfo_60_60 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_pair_2);
                    MR_Word input__TypeInfo_61_61 = (MR_Word) &input__const_20_0_1_TypeInfo_61_61;
                    MR_Word input__TypeInfo_62_62 = (MR_Word) (&mercury__list__list__type_ctor_info_list_1);
                    MR_Word input__TypeInfo_63_63 = (MR_Word) &input__const_20_0_2_TypeInfo_63_63;
#line 375 "input.m"
                    MR_Box input__conv1_HeadVar__6_6;

#line 375 "input.m"
                    {
#line 375 "input.m"
                      input__conv1_HeadVar__6_6 = mercury__exception__throw_2_f_0(input__TypeInfo_57_57, input__TypeInfo_63_63, ((MR_Box) (input__V_56_56)));
                    }
#line 375 "input.m"
                    input__HeadVar__6_6 = ((MR_Word) input__conv1_HeadVar__6_6);
                  }
#line 375 "input.m"
              }
#line 363 "input.m"
              break;
#line 363 "input.m"
            case (MR_Integer) 2:
              {
                MR_Integer input__V_21_21;
                MR_Integer input__V_22_22 = (MR_Integer) 1;

#line 367 "input.m"
                input__V_21_21 = (input__HeadVar__3_3 + input__V_22_22);
#line 366 "input.m"
                {
#line 366 "input.m"
                  /* direct tailcall eliminated */
#line 366 "input.m"
                  {
#line 366 "input.m"
                    MR_Word input__HeadVar__1__tmp_copy_1 = input__V_64_64;
#line 366 "input.m"
                    MR_Integer input__HeadVar__3__tmp_copy_3 = input__V_21_21;

#line 366 "input.m"
                    input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 366 "input.m"
                    input__HeadVar__3_3 = input__HeadVar__3__tmp_copy_3;
#line 366 "input.m"
                  }
#line 366 "input.m"
                  goto loop_top;
#line 366 "input.m"
                }
              }
#line 363 "input.m"
              break;
#line 363 "input.m"
            case (MR_Integer) 3:
              {
                MR_String input__T_23 = ((MR_String) (MR_hl_field(MR_mktag(3), input__V_65_65, (MR_Integer) 0)));
                MR_Integer input__V_30_30;
                MR_Integer input__V_31_31;

#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL input__aes_6_f_0
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Integer Length;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Str = 
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
input__T_23
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

	Length = strlen(Str);

#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
input__V_31_31
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Length;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 370 "input.m"
                input__V_30_30 = (input__HeadVar__3_3 + input__V_31_31);
#line 369 "input.m"
                {
#line 369 "input.m"
                  /* direct tailcall eliminated */
#line 369 "input.m"
                  {
#line 369 "input.m"
                    MR_Word input__HeadVar__1__tmp_copy_1 = input__V_64_64;
#line 369 "input.m"
                    MR_Integer input__HeadVar__3__tmp_copy_3 = input__V_30_30;

#line 369 "input.m"
                    input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 369 "input.m"
                    input__HeadVar__3_3 = input__HeadVar__3__tmp_copy_3;
#line 369 "input.m"
                  }
#line 369 "input.m"
                  goto loop_top;
#line 369 "input.m"
                }
              }
#line 363 "input.m"
              break;
#line 363 "input.m"
          }
#line 363 "input.m"
        }
#line 363 "input.m"
      return input__HeadVar__6_6;
#line 363 "input.m"
    }
#line 363 "input.m"
  }
#line 361 "input.m"
}

#line 352 "input.m"
static void MR_CALL input__attrss_extents_3_p_0(
#line 352 "input.m"
  MR_Word input__HeadVar__1_1,
#line 352 "input.m"
  MR_Array * input__HeadVar__2_2,
#line 352 "input.m"
  MR_Array * input__HeadVar__3_3)
#line 352 "input.m"
{
  {
    bool input__succeeded;
    MR_Word input__AEs_7;
    MR_Word input__V_8_8;
    MR_Integer input__V_9_9;
    MR_Word input__V_10_10;
    MR_Word input__V_12_12;
    MR_Word input__V_13_13;
    MR_Word input__V_14_14;
    MR_Word input__V_16_16;
    MR_Integer input__V_17_17;
    MR_Word input__V_18_18;
    MR_Word input__V_19_19;
    MR_Word input__TypeInfo_20_20;
    MR_Word input__TypeInfo_30_30;
#line 67 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    MR_Array input__conv1_HeadVar__2_2;
#line 67 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    MR_Array input__conv2_HeadVar__3_3;

#line 355 "input.m"
    {
#line 355 "input.m"
      input__V_16_16 = attrs__root_attrs_1_f_0();
    }
#line 355 "input.m"
    input__V_17_17 = (MR_Integer) 0;
#line 355 "input.m"
    input__V_18_18 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 355 "input.m"
    input__V_19_19 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 355 "input.m"
    {
#line 355 "input.m"
      input__AEs_7 = input__aes_6_f_0(input__HeadVar__1_1, input__V_16_16, input__V_17_17, input__V_18_18, input__V_19_19);
    }
#line 356 "input.m"
    {
#line 356 "input.m"
      input__V_13_13 = attrs__root_attrs_1_f_0();
    }
    input__TypeInfo_20_20 = (MR_Word) (&attrs__attrs__type_ctor_info_attrs_0);
#line 357 "input.m"
    input__V_9_9 = (MR_Integer) 0;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      input__DeforestationIn__pred__attrss_extents__128__0_3_p_0(input__AEs_7, &input__V_10_10, &input__V_14_14);
    }
#line 356 "input.m"
    {
#line 356 "input.m"
      input__V_12_12 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 356 "input.m"
      MR_hl_field(MR_mktag(1), input__V_12_12, 0) = ((MR_Box) (input__V_13_13));
#line 356 "input.m"
      MR_hl_field(MR_mktag(1), input__V_12_12, 1) = ((MR_Box) (input__V_14_14));
#line 356 "input.m"
    }
#line 67 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    {
#line 67 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      mercury__array__from_list_2_p_0(input__TypeInfo_20_20, input__V_12_12, &input__conv1_HeadVar__2_2);
    }
#line 67 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    *input__HeadVar__2_2 = (MR_Array) input__conv1_HeadVar__2_2;
#line 357 "input.m"
    {
#line 357 "input.m"
      input__V_8_8 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 357 "input.m"
      MR_hl_field(MR_mktag(1), input__V_8_8, 0) = ((MR_Box) (input__V_9_9));
#line 357 "input.m"
      MR_hl_field(MR_mktag(1), input__V_8_8, 1) = ((MR_Box) (input__V_10_10));
#line 357 "input.m"
    }
    input__TypeInfo_30_30 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 67 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    {
#line 67 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      mercury__array__from_list_2_p_0(input__TypeInfo_30_30, input__V_8_8, &input__conv2_HeadVar__3_3);
    }
#line 67 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    *input__HeadVar__3_3 = (MR_Array) input__conv2_HeadVar__3_3;
  }
#line 352 "input.m"
}

#line 340 "input.m"
void MR_CALL input__write_token_3_p_0(
#line 340 "input.m"
  MR_Word input__HeadVar__1_1)
#line 340 "input.m"
{
#line 342 "input.m"
  {
#line 342 "input.m"
    bool input__succeeded;

#line 342 "input.m"
#line 342 "input.m"
    switch (MR_tag((MR_Word) input__HeadVar__1_1)) {
#line 342 "input.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 342 "input.m"
      case (MR_Integer) 0:
        {
          MR_Word input__T_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__1_1, (MR_Integer) 0)));
          MR_String input__V_7_7 = (MR_String) "<%s>";
          MR_Word input__V_8_8;
          MR_Word input__V_9_9;
          MR_Word input__V_10_10;
          MR_String input__V_11_11;
#line 173 "input.m"
          MR_String input__S_72;

#line 179 "input.m"
#line 179 "input.m"
          switch (MR_tag((MR_Word) input__T_4)) {
#line 179 "input.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 179 "input.m"
            case (MR_Integer) 0:
#line 179 "input.m"
#line 179 "input.m"
              switch (MR_unmkbody(input__T_4)) {
#line 179 "input.m"
                default: /*NOTREACHED*/ MR_assert(0);
#line 179 "input.m"
                case (MR_Integer) 0:
#line 179 "input.m"
                  {
#line 179 "input.m"
                    input__S_72 = (MR_String) "B";
#line 179 "input.m"
                    input__succeeded = TRUE;
#line 179 "input.m"
                  }
#line 179 "input.m"
                  break;
#line 179 "input.m"
                case (MR_Integer) 1:
#line 179 "input.m"
                  {
#line 179 "input.m"
                    input__S_72 = (MR_String) "EM";
#line 179 "input.m"
                    input__succeeded = TRUE;
#line 179 "input.m"
                  }
#line 179 "input.m"
                  break;
#line 179 "input.m"
                case (MR_Integer) 2:
#line 179 "input.m"
                  {
#line 179 "input.m"
                    input__S_72 = (MR_String) "I";
#line 179 "input.m"
                    input__succeeded = TRUE;
#line 179 "input.m"
                  }
#line 179 "input.m"
                  break;
#line 179 "input.m"
                case (MR_Integer) 3:
#line 180 "input.m"
                  {
#line 180 "input.m"
                    input__S_72 = (MR_String) "PL";
#line 180 "input.m"
                    input__succeeded = TRUE;
#line 180 "input.m"
                  }
#line 179 "input.m"
                  break;
#line 179 "input.m"
                case (MR_Integer) 4:
#line 180 "input.m"
                  {
#line 180 "input.m"
                    input__S_72 = (MR_String) "S";
#line 180 "input.m"
                    input__succeeded = TRUE;
#line 180 "input.m"
                  }
#line 179 "input.m"
                  break;
#line 179 "input.m"
                case (MR_Integer) 5:
#line 180 "input.m"
                  {
#line 180 "input.m"
                    input__S_72 = (MR_String) "TT";
#line 180 "input.m"
                    input__succeeded = TRUE;
#line 180 "input.m"
                  }
#line 179 "input.m"
                  break;
#line 179 "input.m"
              }
#line 179 "input.m"
              break;
#line 179 "input.m"
            case (MR_Integer) 1:
              {
                MR_Integer input__V_76_76;

#line 181 "input.m"
                input__S_72 = (MR_String) "U";
#line 181 "input.m"
                input__V_76_76 = ((MR_Integer) (MR_hl_field(MR_mktag(1), input__T_4, (MR_Integer) 0)));
#line 181 "input.m"
                input__succeeded = (input__V_76_76 == (MR_Integer) 0);
              }
#line 179 "input.m"
              break;
#line 179 "input.m"
            case (MR_Integer) 2:
              {
                MR_Integer input__V_96_96 = ((MR_Integer) (MR_hl_field(MR_mktag(2), input__T_4, (MR_Integer) 0)));

#line 179 "input.m"
#line 179 "input.m"
                switch (input__V_96_96) {
#line 179 "input.m"
                  default:
#line 179 "input.m"
                    input__succeeded = FALSE;
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 0:
#line 183 "input.m"
                    {
#line 183 "input.m"
                      input__S_72 = (MR_String) "0";
#line 183 "input.m"
                      input__succeeded = TRUE;
#line 183 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 1:
#line 184 "input.m"
                    {
#line 184 "input.m"
                      input__S_72 = (MR_String) "1";
#line 184 "input.m"
                      input__succeeded = TRUE;
#line 184 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 2:
#line 184 "input.m"
                    {
#line 184 "input.m"
                      input__S_72 = (MR_String) "2";
#line 184 "input.m"
                      input__succeeded = TRUE;
#line 184 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 3:
#line 184 "input.m"
                    {
#line 184 "input.m"
                      input__S_72 = (MR_String) "3";
#line 184 "input.m"
                      input__succeeded = TRUE;
#line 184 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 4:
#line 185 "input.m"
                    {
#line 185 "input.m"
                      input__S_72 = (MR_String) "4";
#line 185 "input.m"
                      input__succeeded = TRUE;
#line 185 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 5:
#line 185 "input.m"
                    {
#line 185 "input.m"
                      input__S_72 = (MR_String) "5";
#line 185 "input.m"
                      input__succeeded = TRUE;
#line 185 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 6:
#line 185 "input.m"
                    {
#line 185 "input.m"
                      input__S_72 = (MR_String) "6";
#line 185 "input.m"
                      input__succeeded = TRUE;
#line 185 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 7:
#line 186 "input.m"
                    {
#line 186 "input.m"
                      input__S_72 = (MR_String) "7";
#line 186 "input.m"
                      input__succeeded = TRUE;
#line 186 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 8:
#line 186 "input.m"
                    {
#line 186 "input.m"
                      input__S_72 = (MR_String) "8";
#line 186 "input.m"
                      input__succeeded = TRUE;
#line 186 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 9:
#line 186 "input.m"
                    {
#line 186 "input.m"
                      input__S_72 = (MR_String) "9";
#line 186 "input.m"
                      input__succeeded = TRUE;
#line 186 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                }
              }
#line 179 "input.m"
              break;
#line 179 "input.m"
            case (MR_Integer) 3:
              {
                MR_Word input__V_95_95 = ((MR_Word) (MR_hl_field(MR_mktag(3), input__T_4, (MR_Integer) 0)));

#line 179 "input.m"
#line 179 "input.m"
                switch (input__V_95_95) {
#line 179 "input.m"
                  default:
#line 179 "input.m"
                    input__succeeded = FALSE;
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 0:
#line 188 "input.m"
                    {
#line 188 "input.m"
                      input__S_72 = (MR_String) "r";
#line 188 "input.m"
                      input__succeeded = TRUE;
#line 188 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 1:
#line 188 "input.m"
                    {
#line 188 "input.m"
                      input__S_72 = (MR_String) "g";
#line 188 "input.m"
                      input__succeeded = TRUE;
#line 188 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 2:
#line 188 "input.m"
                    {
#line 188 "input.m"
                      input__S_72 = (MR_String) "b";
#line 188 "input.m"
                      input__succeeded = TRUE;
#line 188 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 3:
#line 189 "input.m"
                    {
#line 189 "input.m"
                      input__S_72 = (MR_String) "c";
#line 189 "input.m"
                      input__succeeded = TRUE;
#line 189 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 4:
#line 189 "input.m"
                    {
#line 189 "input.m"
                      input__S_72 = (MR_String) "m";
#line 189 "input.m"
                      input__succeeded = TRUE;
#line 189 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 5:
#line 189 "input.m"
                    {
#line 189 "input.m"
                      input__S_72 = (MR_String) "y";
#line 189 "input.m"
                      input__succeeded = TRUE;
#line 189 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 6:
#line 190 "input.m"
                    {
#line 190 "input.m"
                      input__S_72 = (MR_String) "k";
#line 190 "input.m"
                      input__succeeded = TRUE;
#line 190 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 7:
#line 190 "input.m"
                    {
#line 190 "input.m"
                      input__S_72 = (MR_String) "w";
#line 190 "input.m"
                      input__succeeded = TRUE;
#line 190 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                }
              }
#line 179 "input.m"
              break;
#line 179 "input.m"
          }
#line 173 "input.m"
          if (input__succeeded)
#line 173 "input.m"
            input__V_11_11 = input__S_72;
#line 173 "input.m"
          else
            {
              MR_String input__V_73_73 = (MR_String) "input__tag_to_string: !";
              MR_Word input__TypeInfo_6_74 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
              MR_Word input__TypeInfo_7_75 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
#line 173 "input.m"
              MR_Box input__conv1_V_11_11;

#line 173 "input.m"
              {
#line 173 "input.m"
                input__conv1_V_11_11 = mercury__exception__throw_2_f_0(input__TypeInfo_6_74, input__TypeInfo_7_75, ((MR_Box) (input__V_73_73)));
              }
#line 173 "input.m"
              input__V_11_11 = ((MR_String) input__conv1_V_11_11);
            }
#line 342 "input.m"
          {
#line 342 "input.m"
            input__V_9_9 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "s"));
#line 342 "input.m"
            MR_hl_field(MR_mktag(2), input__V_9_9, 0) = ((MR_Box) (input__V_11_11));
#line 342 "input.m"
          }
#line 342 "input.m"
          input__V_10_10 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 342 "input.m"
          {
#line 342 "input.m"
            input__V_8_8 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 342 "input.m"
            MR_hl_field(MR_mktag(1), input__V_8_8, 0) = ((MR_Box) (input__V_9_9));
#line 342 "input.m"
            MR_hl_field(MR_mktag(1), input__V_8_8, 1) = ((MR_Box) (input__V_10_10));
#line 342 "input.m"
          }
#line 342 "input.m"
          {
#line 342 "input.m"
            mercury__io__format_4_p_0(input__V_7_7, input__V_8_8);
#line 342 "input.m"
            return;
          }
        }
#line 342 "input.m"
        break;
#line 342 "input.m"
      case (MR_Integer) 1:
        {
          MR_Word input__T_12 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__1_1, (MR_Integer) 0)));
          MR_String input__V_15_15 = (MR_String) "</%s>";
          MR_Word input__V_16_16;
          MR_Word input__V_17_17;
          MR_Word input__V_18_18;
          MR_String input__V_19_19;
          MR_Word input__Stream_7_56;
          MR_String input__String_9_66;
#line 173 "input.m"
          MR_String input__S_27;

#line 179 "input.m"
#line 179 "input.m"
          switch (MR_tag((MR_Word) input__T_12)) {
#line 179 "input.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 179 "input.m"
            case (MR_Integer) 0:
#line 179 "input.m"
#line 179 "input.m"
              switch (MR_unmkbody(input__T_12)) {
#line 179 "input.m"
                default: /*NOTREACHED*/ MR_assert(0);
#line 179 "input.m"
                case (MR_Integer) 0:
#line 179 "input.m"
                  {
#line 179 "input.m"
                    input__S_27 = (MR_String) "B";
#line 179 "input.m"
                    input__succeeded = TRUE;
#line 179 "input.m"
                  }
#line 179 "input.m"
                  break;
#line 179 "input.m"
                case (MR_Integer) 1:
#line 179 "input.m"
                  {
#line 179 "input.m"
                    input__S_27 = (MR_String) "EM";
#line 179 "input.m"
                    input__succeeded = TRUE;
#line 179 "input.m"
                  }
#line 179 "input.m"
                  break;
#line 179 "input.m"
                case (MR_Integer) 2:
#line 179 "input.m"
                  {
#line 179 "input.m"
                    input__S_27 = (MR_String) "I";
#line 179 "input.m"
                    input__succeeded = TRUE;
#line 179 "input.m"
                  }
#line 179 "input.m"
                  break;
#line 179 "input.m"
                case (MR_Integer) 3:
#line 180 "input.m"
                  {
#line 180 "input.m"
                    input__S_27 = (MR_String) "PL";
#line 180 "input.m"
                    input__succeeded = TRUE;
#line 180 "input.m"
                  }
#line 179 "input.m"
                  break;
#line 179 "input.m"
                case (MR_Integer) 4:
#line 180 "input.m"
                  {
#line 180 "input.m"
                    input__S_27 = (MR_String) "S";
#line 180 "input.m"
                    input__succeeded = TRUE;
#line 180 "input.m"
                  }
#line 179 "input.m"
                  break;
#line 179 "input.m"
                case (MR_Integer) 5:
#line 180 "input.m"
                  {
#line 180 "input.m"
                    input__S_27 = (MR_String) "TT";
#line 180 "input.m"
                    input__succeeded = TRUE;
#line 180 "input.m"
                  }
#line 179 "input.m"
                  break;
#line 179 "input.m"
              }
#line 179 "input.m"
              break;
#line 179 "input.m"
            case (MR_Integer) 1:
              {
                MR_Integer input__V_31_31;

#line 181 "input.m"
                input__S_27 = (MR_String) "U";
#line 181 "input.m"
                input__V_31_31 = ((MR_Integer) (MR_hl_field(MR_mktag(1), input__T_12, (MR_Integer) 0)));
#line 181 "input.m"
                input__succeeded = (input__V_31_31 == (MR_Integer) 0);
              }
#line 179 "input.m"
              break;
#line 179 "input.m"
            case (MR_Integer) 2:
              {
                MR_Integer input__V_51_51 = ((MR_Integer) (MR_hl_field(MR_mktag(2), input__T_12, (MR_Integer) 0)));

#line 179 "input.m"
#line 179 "input.m"
                switch (input__V_51_51) {
#line 179 "input.m"
                  default:
#line 179 "input.m"
                    input__succeeded = FALSE;
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 0:
#line 183 "input.m"
                    {
#line 183 "input.m"
                      input__S_27 = (MR_String) "0";
#line 183 "input.m"
                      input__succeeded = TRUE;
#line 183 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 1:
#line 184 "input.m"
                    {
#line 184 "input.m"
                      input__S_27 = (MR_String) "1";
#line 184 "input.m"
                      input__succeeded = TRUE;
#line 184 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 2:
#line 184 "input.m"
                    {
#line 184 "input.m"
                      input__S_27 = (MR_String) "2";
#line 184 "input.m"
                      input__succeeded = TRUE;
#line 184 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 3:
#line 184 "input.m"
                    {
#line 184 "input.m"
                      input__S_27 = (MR_String) "3";
#line 184 "input.m"
                      input__succeeded = TRUE;
#line 184 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 4:
#line 185 "input.m"
                    {
#line 185 "input.m"
                      input__S_27 = (MR_String) "4";
#line 185 "input.m"
                      input__succeeded = TRUE;
#line 185 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 5:
#line 185 "input.m"
                    {
#line 185 "input.m"
                      input__S_27 = (MR_String) "5";
#line 185 "input.m"
                      input__succeeded = TRUE;
#line 185 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 6:
#line 185 "input.m"
                    {
#line 185 "input.m"
                      input__S_27 = (MR_String) "6";
#line 185 "input.m"
                      input__succeeded = TRUE;
#line 185 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 7:
#line 186 "input.m"
                    {
#line 186 "input.m"
                      input__S_27 = (MR_String) "7";
#line 186 "input.m"
                      input__succeeded = TRUE;
#line 186 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 8:
#line 186 "input.m"
                    {
#line 186 "input.m"
                      input__S_27 = (MR_String) "8";
#line 186 "input.m"
                      input__succeeded = TRUE;
#line 186 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 9:
#line 186 "input.m"
                    {
#line 186 "input.m"
                      input__S_27 = (MR_String) "9";
#line 186 "input.m"
                      input__succeeded = TRUE;
#line 186 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                }
              }
#line 179 "input.m"
              break;
#line 179 "input.m"
            case (MR_Integer) 3:
              {
                MR_Word input__V_50_50 = ((MR_Word) (MR_hl_field(MR_mktag(3), input__T_12, (MR_Integer) 0)));

#line 179 "input.m"
#line 179 "input.m"
                switch (input__V_50_50) {
#line 179 "input.m"
                  default:
#line 179 "input.m"
                    input__succeeded = FALSE;
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 0:
#line 188 "input.m"
                    {
#line 188 "input.m"
                      input__S_27 = (MR_String) "r";
#line 188 "input.m"
                      input__succeeded = TRUE;
#line 188 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 1:
#line 188 "input.m"
                    {
#line 188 "input.m"
                      input__S_27 = (MR_String) "g";
#line 188 "input.m"
                      input__succeeded = TRUE;
#line 188 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 2:
#line 188 "input.m"
                    {
#line 188 "input.m"
                      input__S_27 = (MR_String) "b";
#line 188 "input.m"
                      input__succeeded = TRUE;
#line 188 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 3:
#line 189 "input.m"
                    {
#line 189 "input.m"
                      input__S_27 = (MR_String) "c";
#line 189 "input.m"
                      input__succeeded = TRUE;
#line 189 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 4:
#line 189 "input.m"
                    {
#line 189 "input.m"
                      input__S_27 = (MR_String) "m";
#line 189 "input.m"
                      input__succeeded = TRUE;
#line 189 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 5:
#line 189 "input.m"
                    {
#line 189 "input.m"
                      input__S_27 = (MR_String) "y";
#line 189 "input.m"
                      input__succeeded = TRUE;
#line 189 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 6:
#line 190 "input.m"
                    {
#line 190 "input.m"
                      input__S_27 = (MR_String) "k";
#line 190 "input.m"
                      input__succeeded = TRUE;
#line 190 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                  case (MR_Integer) 7:
#line 190 "input.m"
                    {
#line 190 "input.m"
                      input__S_27 = (MR_String) "w";
#line 190 "input.m"
                      input__succeeded = TRUE;
#line 190 "input.m"
                    }
#line 179 "input.m"
                    break;
#line 179 "input.m"
                }
              }
#line 179 "input.m"
              break;
#line 179 "input.m"
          }
#line 173 "input.m"
          if (input__succeeded)
#line 173 "input.m"
            input__V_19_19 = input__S_27;
#line 173 "input.m"
          else
            {
              MR_String input__V_28_28 = (MR_String) "input__tag_to_string: !";
              MR_Word input__TypeInfo_6_29 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
              MR_Word input__TypeInfo_7_30 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
#line 173 "input.m"
              MR_Box input__conv2_V_19_19;

#line 173 "input.m"
              {
#line 173 "input.m"
                input__conv2_V_19_19 = mercury__exception__throw_2_f_0(input__TypeInfo_6_29, input__TypeInfo_7_30, ((MR_Box) (input__V_28_28)));
              }
#line 173 "input.m"
              input__V_19_19 = ((MR_String) input__conv2_V_19_19);
            }
#line 343 "input.m"
          {
#line 343 "input.m"
            input__V_17_17 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "s"));
#line 343 "input.m"
            MR_hl_field(MR_mktag(2), input__V_17_17, 0) = ((MR_Box) (input__V_19_19));
#line 343 "input.m"
          }
#line 343 "input.m"
          input__V_18_18 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 343 "input.m"
          {
#line 343 "input.m"
            input__V_16_16 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 343 "input.m"
            MR_hl_field(MR_mktag(1), input__V_16_16, 0) = ((MR_Box) (input__V_17_17));
#line 343 "input.m"
            MR_hl_field(MR_mktag(1), input__V_16_16, 1) = ((MR_Box) (input__V_18_18));
#line 343 "input.m"
          }
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL input__write_token_3_p_0
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_output;
	update_io(IO0, IO);

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__Stream_7_56
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 343 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          {
#line 343 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            mercury__string__format_3_p_0(input__V_15_15, input__V_16_16, &input__String_9_66);
          }
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL input__write_token_3_p_0
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Stream = 
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__Stream_7_56
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__String_9_66
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile *stream = (MercuryFile *) Stream;
	mercury_print_string(stream, Message);
	update_io(IO0, IO);
}
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
        }
#line 342 "input.m"
        break;
#line 342 "input.m"
      case (MR_Integer) 2:
        {
          MR_Char input__S_20 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(2), input__HeadVar__1_1, (MR_Integer) 0)));

#line 344 "input.m"
          {
#line 344 "input.m"
            mercury__io__write_char_3_p_0(input__S_20);
#line 344 "input.m"
            return;
          }
        }
#line 342 "input.m"
        break;
#line 342 "input.m"
      case (MR_Integer) 3:
        {
          MR_String input__T_23 = ((MR_String) (MR_hl_field(MR_mktag(3), input__HeadVar__1_1, (MR_Integer) 0)));

#line 345 "input.m"
          {
#line 345 "input.m"
            mercury__io__write_string_3_p_0(input__T_23);
#line 345 "input.m"
            return;
          }
        }
#line 342 "input.m"
        break;
#line 342 "input.m"
    }
#line 342 "input.m"
  }
#line 340 "input.m"
}

#line 324 "input.m"
static void MR_CALL input__write_tokens_to_file_4_p_0(
#line 324 "input.m"
  MR_String input__HeadVar__1_1,
#line 324 "input.m"
  MR_Word input__HeadVar__2_2)
#line 324 "input.m"
{
  {
    bool input__succeeded;
    MR_Word input__Result_7;
    MR_String input__V_17_17;
    MR_Word input__Stdout_3_25;
    MR_Word input__OldStream_4_27;
    MR_Word input__StreamNames0_5_43;
    MR_Integer input__V_10_45;
    MR_Word input__StreamNames_6_46;
    MR_Word input__TypeInfo_11_47;
    MR_Word input__TypeInfo_12_48;
#line 328 "input.m"
    MR_Word input__V_8_8;

#line 327 "input.m"
    {
#line 327 "input.m"
      mercury__io__tell_4_p_0(input__HeadVar__1_1, &input__Result_7);
    }
#line 328 "input.m"
    input__succeeded = (MR_tag((MR_Word) input__Result_7) == MR_mktag((MR_Integer) 1));
#line 328 "input.m"
    if ((MR_tag((MR_Word) input__Result_7) == MR_mktag((MR_Integer) 1)))
#line 328 "input.m"
      input__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__Result_7, (MR_Integer) 0)));
#line 328 "input.m"
    if (input__succeeded)
      {
        MR_Word input__TypeInfo_13_13 = (MR_Word) (&mercury__io__io__type_ctor_info_res_0);

#line 328 "input.m"
        {
#line 328 "input.m"
          mercury__exception__throw_1_p_0(input__TypeInfo_13_13, ((MR_Box) (input__Result_7)));
        }
      }
#line 328 "input.m"
    else
      {
      }
#line 335 "input.m"
    input__V_17_17 = (MR_String) "";
#line 335 "input.m"
    {
#line 335 "input.m"
      input__write_list__ho6_5_p_in__io_0(input__HeadVar__2_2, input__V_17_17);
    }
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL input__write_tokens_to_file_4_p_0
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) &mercury_stdout;
	update_io(IO0, IO);

#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__Stdout_3_25
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL input__write_tokens_to_file_4_p_0
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word NewStream;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word OutStream;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	NewStream = 
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__Stdout_3_25
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	OutStream = (MR_Word) mercury_current_text_output;
	mercury_current_text_output = (MercuryFile *) NewStream;
	update_io(IO0, IO);

#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__OldStream_4_27
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = OutStream;
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL input__write_tokens_to_file_4_p_0
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word StreamNames;
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	StreamNames = ML_io_stream_names;
	update_io(IO0, IO);

#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__StreamNames0_5_43
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = StreamNames;
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL input__write_tokens_to_file_4_p_0
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer Id;
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Stream = 
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__OldStream_4_27
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	/* 
	** Most of the time, we can just use the pointer to the stream
	** as a unique identifier.
	*/
	
	Id = (MR_Word) Stream;

#ifdef NATIVE_GC
	/* 
	** XXX for accurate GC we should embed an ID in the MercuryFile
	** and retrieve it here.
	*/
	MR_fatal_error("not implemented -- stream ids in native GC grades");
#endif

#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__V_10_45
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Id;
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
    input__TypeInfo_11_47 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
    input__TypeInfo_12_48 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
#line 753 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    {
#line 753 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      mercury__map__delete_3_p_1(input__TypeInfo_11_47, input__TypeInfo_12_48, input__StreamNames0_5_43, ((MR_Box) (input__V_10_45)), &input__StreamNames_6_46);
    }
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL input__write_tokens_to_file_4_p_0
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word StreamNames;
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	StreamNames = 
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__StreamNames_6_46
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	ML_io_stream_names = StreamNames;
	update_io(IO0, IO);

#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL input__write_tokens_to_file_4_p_0
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Stream = 
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__OldStream_4_27
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_close((MercuryFile *) Stream);
	update_io(IO0, IO);

#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
  }
#line 324 "input.m"
}

#line 228 "input.m"
static MR_Word MR_CALL input__pds_6_f_0(
#line 228 "input.m"
  MR_Word input__HeadVar__1_1,
#line 228 "input.m"
  MR_Word input__HeadVar__2_2,
#line 228 "input.m"
  MR_Word input__HeadVar__3_3,
#line 228 "input.m"
  MR_Word input__HeadVar__4_4,
#line 228 "input.m"
  MR_Word input__HeadVar__5_5)
#line 228 "input.m"
{
#line 230 "input.m"
  {
#line 230 "input.m"
    /* tailcall optimized into a loop */
#line 230 "input.m"
  loop_top:;
#line 230 "input.m"
    {
#line 230 "input.m"
      bool input__succeeded;
#line 230 "input.m"
      MR_Word input__HeadVar__6_6;

#line 230 "input.m"
      if ((input__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 230 "input.m"
        input__HeadVar__6_6 = input__HeadVar__5_5;
#line 230 "input.m"
      else
#line 230 "input.m"
        {
          MR_Word input__V_64_64 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__1_1, (MR_Integer) 1)));
          MR_Word input__V_65_65 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__1_1, (MR_Integer) 0)));

#line 230 "input.m"
#line 230 "input.m"
          switch (MR_tag((MR_Word) input__V_65_65)) {
#line 230 "input.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 230 "input.m"
            case (MR_Integer) 0:
              {
                MR_Word input__Tag_41 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__V_65_65, (MR_Integer) 0)));
                MR_Word input__V_48_48;
                MR_Word input__V_49_49;
                MR_Word input__V_50_50;

#line 245 "input.m"
                {
#line 245 "input.m"
                  input__V_48_48 = input__apply_tag_3_f_0(input__Tag_41, input__HeadVar__2_2);
                }
#line 245 "input.m"
                {
#line 245 "input.m"
                  input__V_49_49 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 245 "input.m"
                  MR_hl_field(MR_mktag(1), input__V_49_49, 0) = ((MR_Box) (input__HeadVar__2_2));
#line 245 "input.m"
                  MR_hl_field(MR_mktag(1), input__V_49_49, 1) = ((MR_Box) (input__HeadVar__3_3));
#line 245 "input.m"
                }
#line 245 "input.m"
                {
#line 245 "input.m"
                  input__V_50_50 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 245 "input.m"
                  MR_hl_field(MR_mktag(1), input__V_50_50, 0) = ((MR_Box) (input__V_65_65));
#line 245 "input.m"
                  MR_hl_field(MR_mktag(1), input__V_50_50, 1) = ((MR_Box) (input__HeadVar__5_5));
#line 245 "input.m"
                }
#line 244 "input.m"
                {
#line 244 "input.m"
                  /* direct tailcall eliminated */
#line 244 "input.m"
                  {
#line 244 "input.m"
                    MR_Word input__HeadVar__1__tmp_copy_1 = input__V_64_64;
#line 244 "input.m"
                    MR_Word input__HeadVar__2__tmp_copy_2 = input__V_48_48;
#line 244 "input.m"
                    MR_Word input__HeadVar__3__tmp_copy_3 = input__V_49_49;
#line 244 "input.m"
                    MR_Word input__HeadVar__5__tmp_copy_5 = input__V_50_50;

#line 244 "input.m"
                    input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 244 "input.m"
                    input__HeadVar__2_2 = input__HeadVar__2__tmp_copy_2;
#line 244 "input.m"
                    input__HeadVar__3_3 = input__HeadVar__3__tmp_copy_3;
#line 244 "input.m"
                    input__HeadVar__5_5 = input__HeadVar__5__tmp_copy_5;
#line 244 "input.m"
                  }
#line 244 "input.m"
                  goto loop_top;
#line 244 "input.m"
                }
              }
#line 230 "input.m"
              break;
#line 230 "input.m"
            case (MR_Integer) 1:
              {
                MR_Word input__Attrs_58;
                MR_Word input__Attrss_59;
                MR_Word input__V_61_61;

#line 249 "input.m"
                {
#line 249 "input.m"
                  input__V_61_61 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 249 "input.m"
                  MR_hl_field(MR_mktag(1), input__V_61_61, 0) = ((MR_Box) (input__V_65_65));
#line 249 "input.m"
                  MR_hl_field(MR_mktag(1), input__V_61_61, 1) = ((MR_Box) (input__HeadVar__5_5));
#line 249 "input.m"
                }
#line 258 "input.m"
                if ((input__HeadVar__3_3 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
                  {
                    MR_String input__V_69_69 = (MR_String) "input__hd_tl: aiiiieeeeeeee!";
                    MR_Word input__TypeInfo_10_72 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 258 "input.m"
                    {
#line 258 "input.m"
                      mercury__exception__throw_1_p_0(input__TypeInfo_10_72, ((MR_Box) (input__V_69_69)));
                    }
                  }
#line 258 "input.m"
                else
#line 258 "input.m"
                  {
#line 259 "input.m"
                    input__Attrs_58 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__3_3, (MR_Integer) 0)));
#line 259 "input.m"
                    input__Attrss_59 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__3_3, (MR_Integer) 1)));
#line 258 "input.m"
                  }
#line 250 "input.m"
                {
#line 250 "input.m"
                  /* direct tailcall eliminated */
#line 250 "input.m"
                  {
#line 250 "input.m"
                    MR_Word input__HeadVar__1__tmp_copy_1 = input__V_64_64;
#line 250 "input.m"
                    MR_Word input__HeadVar__2__tmp_copy_2 = input__Attrs_58;
#line 250 "input.m"
                    MR_Word input__HeadVar__3__tmp_copy_3 = input__Attrss_59;
#line 250 "input.m"
                    MR_Word input__HeadVar__5__tmp_copy_5 = input__V_61_61;

#line 250 "input.m"
                    input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 250 "input.m"
                    input__HeadVar__2_2 = input__HeadVar__2__tmp_copy_2;
#line 250 "input.m"
                    input__HeadVar__3_3 = input__HeadVar__3__tmp_copy_3;
#line 250 "input.m"
                    input__HeadVar__5_5 = input__HeadVar__5__tmp_copy_5;
#line 250 "input.m"
                  }
#line 250 "input.m"
                  goto loop_top;
#line 250 "input.m"
                }
              }
#line 230 "input.m"
              break;
#line 230 "input.m"
            case (MR_Integer) 2:
#line 230 "input.m"
              if ((input__HeadVar__4_4 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
                {
                  MR_Word input__V_27_27;
                  MR_Word input__V_28_28;

#line 236 "input.m"
                  {
#line 236 "input.m"
                    input__V_27_27 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "yes"));
#line 236 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_27_27, 0) = ((MR_Box) (input__HeadVar__2_2));
#line 236 "input.m"
                  }
#line 236 "input.m"
                  {
#line 236 "input.m"
                    input__V_28_28 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 236 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_28_28, 0) = ((MR_Box) (input__V_65_65));
#line 236 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_28_28, 1) = ((MR_Box) (input__HeadVar__5_5));
#line 236 "input.m"
                  }
#line 235 "input.m"
                  {
#line 235 "input.m"
                    /* direct tailcall eliminated */
#line 235 "input.m"
                    {
#line 235 "input.m"
                      MR_Word input__HeadVar__1__tmp_copy_1 = input__V_64_64;
#line 235 "input.m"
                      MR_Word input__HeadVar__4__tmp_copy_4 = input__V_27_27;
#line 235 "input.m"
                      MR_Word input__HeadVar__5__tmp_copy_5 = input__V_28_28;

#line 235 "input.m"
                      input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 235 "input.m"
                      input__HeadVar__4_4 = input__HeadVar__4__tmp_copy_4;
#line 235 "input.m"
                      input__HeadVar__5_5 = input__HeadVar__5__tmp_copy_5;
#line 235 "input.m"
                    }
#line 235 "input.m"
                    goto loop_top;
#line 235 "input.m"
                  }
                }
#line 230 "input.m"
              else
#line 230 "input.m"
                {
                  MR_Word input__SpcAttrs_34 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__4_4, (MR_Integer) 0)));

#line 239 "input.m"
                  {
#line 239 "input.m"
                    input__succeeded = attrs__equivalent_for_space_2_p_0(input__HeadVar__2_2, input__SpcAttrs_34);
                  }
#line 238 "input.m"
                  if (input__succeeded)
#line 238 "input.m"
                    {
#line 238 "input.m"
                      /* direct tailcall eliminated */
#line 238 "input.m"
                      {
#line 238 "input.m"
                        MR_Word input__HeadVar__1__tmp_copy_1 = input__V_64_64;

#line 238 "input.m"
                        input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 238 "input.m"
                      }
#line 238 "input.m"
                      goto loop_top;
#line 238 "input.m"
                    }
#line 238 "input.m"
                  else
                    {
                      MR_Word input__V_38_38;
                      MR_Word input__V_39_39;

#line 241 "input.m"
                      {
#line 241 "input.m"
                        input__V_38_38 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "yes"));
#line 241 "input.m"
                        MR_hl_field(MR_mktag(1), input__V_38_38, 0) = ((MR_Box) (input__HeadVar__2_2));
#line 241 "input.m"
                      }
#line 241 "input.m"
                      {
#line 241 "input.m"
                        input__V_39_39 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 241 "input.m"
                        MR_hl_field(MR_mktag(1), input__V_39_39, 0) = ((MR_Box) (input__V_65_65));
#line 241 "input.m"
                        MR_hl_field(MR_mktag(1), input__V_39_39, 1) = ((MR_Box) (input__HeadVar__5_5));
#line 241 "input.m"
                      }
#line 238 "input.m"
                      {
#line 238 "input.m"
                        /* direct tailcall eliminated */
#line 238 "input.m"
                        {
#line 238 "input.m"
                          MR_Word input__HeadVar__1__tmp_copy_1 = input__V_64_64;
#line 238 "input.m"
                          MR_Word input__HeadVar__4__tmp_copy_4 = input__V_38_38;
#line 238 "input.m"
                          MR_Word input__HeadVar__5__tmp_copy_5 = input__V_39_39;

#line 238 "input.m"
                          input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 238 "input.m"
                          input__HeadVar__4_4 = input__HeadVar__4__tmp_copy_4;
#line 238 "input.m"
                          input__HeadVar__5_5 = input__HeadVar__5__tmp_copy_5;
#line 238 "input.m"
                        }
#line 238 "input.m"
                        goto loop_top;
#line 238 "input.m"
                      }
                    }
#line 230 "input.m"
                }
#line 230 "input.m"
              break;
#line 230 "input.m"
            case (MR_Integer) 3:
              {
                MR_Word input__V_18_18 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
                MR_Word input__V_19_19;

#line 233 "input.m"
                {
#line 233 "input.m"
                  input__V_19_19 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 233 "input.m"
                  MR_hl_field(MR_mktag(1), input__V_19_19, 0) = ((MR_Box) (input__V_65_65));
#line 233 "input.m"
                  MR_hl_field(MR_mktag(1), input__V_19_19, 1) = ((MR_Box) (input__HeadVar__5_5));
#line 233 "input.m"
                }
#line 232 "input.m"
                {
#line 232 "input.m"
                  /* direct tailcall eliminated */
#line 232 "input.m"
                  {
#line 232 "input.m"
                    MR_Word input__HeadVar__1__tmp_copy_1 = input__V_64_64;
#line 232 "input.m"
                    MR_Word input__HeadVar__4__tmp_copy_4 = input__V_18_18;
#line 232 "input.m"
                    MR_Word input__HeadVar__5__tmp_copy_5 = input__V_19_19;

#line 232 "input.m"
                    input__HeadVar__1_1 = input__HeadVar__1__tmp_copy_1;
#line 232 "input.m"
                    input__HeadVar__4_4 = input__HeadVar__4__tmp_copy_4;
#line 232 "input.m"
                    input__HeadVar__5_5 = input__HeadVar__5__tmp_copy_5;
#line 232 "input.m"
                  }
#line 232 "input.m"
                  goto loop_top;
#line 232 "input.m"
                }
              }
#line 230 "input.m"
              break;
#line 230 "input.m"
          }
#line 230 "input.m"
        }
#line 230 "input.m"
      return input__HeadVar__6_6;
#line 230 "input.m"
    }
#line 230 "input.m"
  }
#line 228 "input.m"
}

#line 195 "input.m"
static bool MR_CALL input__is_wspc_1_p_0(
#line 195 "input.m"
  MR_Char input__HeadVar__1_1)
#line 195 "input.m"
{
  {
    bool input__succeeded;
    MR_Integer input__N_3;

#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
{
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#define MR_PROC_LABEL input__is_wspc_1_p_0
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	MR_Char Character;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	MR_Integer Int;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	Character = 
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
input__HeadVar__1_1
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
		{
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

	Int = (MR_UnsignedChar) Character;

#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

		;}
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#undef MR_PROC_LABEL
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
input__N_3
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
 = Int;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
}
#line 199 "input.m"
#line 199 "input.m"
    switch (input__N_3) {
#line 199 "input.m"
      default:
#line 199 "input.m"
        input__succeeded = FALSE;
#line 199 "input.m"
        break;
#line 199 "input.m"
      case (MR_Integer) 9:
#line 199 "input.m"
        input__succeeded = TRUE;
#line 199 "input.m"
        break;
#line 199 "input.m"
      case (MR_Integer) 10:
#line 199 "input.m"
        input__succeeded = TRUE;
#line 199 "input.m"
        break;
#line 199 "input.m"
      case (MR_Integer) 13:
#line 199 "input.m"
        input__succeeded = TRUE;
#line 199 "input.m"
        break;
#line 199 "input.m"
      case (MR_Integer) 32:
#line 199 "input.m"
        input__succeeded = TRUE;
#line 199 "input.m"
        break;
#line 199 "input.m"
    }
    return input__succeeded;
  }
#line 195 "input.m"
}
#line 179 "input.m"
static /* final */ const int input__const_7_0_20_next_slots_table[64] = {
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) 1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) 4,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) 5,
		(MR_Integer) -1,
		(MR_Integer) 6,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2};
#line 179 "input.m"
static /* final */ const MR_String input__const_7_0_21_string_table[64] = {
		NULL,
		(MR_String) "EM",
		(MR_String) "TT",
		(MR_String) "B",
		(MR_String) "2",
		(MR_String) "7",
		(MR_String) "9",
		NULL,
		(MR_String) "I",
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		(MR_String) "S",
		NULL,
		(MR_String) "U",
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		(MR_String) "PL",
		NULL,
		NULL,
		NULL,
		(MR_String) "c",
		(MR_String) "b",
		NULL,
		NULL,
		(MR_String) "g",
		NULL,
		NULL,
		NULL,
		(MR_String) "k",
		NULL,
		(MR_String) "m",
		NULL,
		NULL,
		NULL,
		(MR_String) "1",
		(MR_String) "0",
		(MR_String) "3",
		(MR_String) "r",
		(MR_String) "5",
		(MR_String) "4",
		(MR_String) "w",
		(MR_String) "6",
		(MR_String) "y",
		(MR_String) "8",
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL};
#line 184 "input.m"
static /* final */ const MR_Box input__const_7_0_1_T_4[1] = {
		((MR_Box) ((MR_Integer) 2))};
#line 186 "input.m"
static /* final */ const MR_Box input__const_7_0_2_T_4[1] = {
		((MR_Box) ((MR_Integer) 7))};
#line 186 "input.m"
static /* final */ const MR_Box input__const_7_0_3_T_4[1] = {
		((MR_Box) ((MR_Integer) 9))};
#line 181 "input.m"
static /* final */ const MR_Box input__const_7_0_4_T_4[1] = {
		((MR_Box) ((MR_Integer) 0))};
#line 189 "input.m"
static /* final */ const MR_Box input__const_7_0_5_T_4[1] = {
		((MR_Box) ((MR_Integer) 3))};
#line 188 "input.m"
static /* final */ const MR_Box input__const_7_0_6_T_4[1] = {
		((MR_Box) ((MR_Integer) 2))};
#line 188 "input.m"
static /* final */ const MR_Box input__const_7_0_7_T_4[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 190 "input.m"
static /* final */ const MR_Box input__const_7_0_8_T_4[1] = {
		((MR_Box) ((MR_Integer) 6))};
#line 189 "input.m"
static /* final */ const MR_Box input__const_7_0_9_T_4[1] = {
		((MR_Box) ((MR_Integer) 4))};
#line 184 "input.m"
static /* final */ const MR_Box input__const_7_0_10_T_4[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 183 "input.m"
static /* final */ const MR_Box input__const_7_0_11_T_4[1] = {
		((MR_Box) ((MR_Integer) 0))};
#line 184 "input.m"
static /* final */ const MR_Box input__const_7_0_12_T_4[1] = {
		((MR_Box) ((MR_Integer) 3))};
#line 188 "input.m"
static /* final */ const MR_Box input__const_7_0_13_T_4[1] = {
		((MR_Box) ((MR_Integer) 0))};
#line 185 "input.m"
static /* final */ const MR_Box input__const_7_0_14_T_4[1] = {
		((MR_Box) ((MR_Integer) 5))};
#line 185 "input.m"
static /* final */ const MR_Box input__const_7_0_15_T_4[1] = {
		((MR_Box) ((MR_Integer) 4))};
#line 190 "input.m"
static /* final */ const MR_Box input__const_7_0_16_T_4[1] = {
		((MR_Box) ((MR_Integer) 7))};
#line 185 "input.m"
static /* final */ const MR_Box input__const_7_0_17_T_4[1] = {
		((MR_Box) ((MR_Integer) 6))};
#line 189 "input.m"
static /* final */ const MR_Box input__const_7_0_18_T_4[1] = {
		((MR_Box) ((MR_Integer) 5))};
#line 186 "input.m"
static /* final */ const MR_Box input__const_7_0_19_T_4[1] = {
		((MR_Box) ((MR_Integer) 8))};

#line 167 "input.m"
static MR_Word MR_CALL input__string_to_tag_2_f_0(
#line 167 "input.m"
  MR_String input__HeadVar__1_1)
#line 167 "input.m"
{
#line 169 "input.m"
  {
#line 169 "input.m"
    bool input__succeeded;
#line 169 "input.m"
    MR_Word input__HeadVar__2_2;
#line 169 "input.m"
    MR_Word input__T_4;
#line 179 "input.m"
    int input__slot_1;
#line 179 "input.m"
    MR_String input__str_2;

#line 179 "input.m"
    /* hashed string switch */
#line 179 "input.m"
    /* compute the hash value of the input string */
#line 179 "input.m"
    input__slot_1 = (MR_hash_string(input__HeadVar__1_1) & (MR_Integer) 63);
#line 179 "input.m"
    /* hash chain loop */
#line 179 "input.m"
    do
#line 179 "input.m"
      {
#line 179 "input.m"
        /* lookup the string for this hash slot */
#line 179 "input.m"
        input__str_2 = input__const_7_0_21_string_table[input__slot_1];
#line 179 "input.m"
        /* did we find a match? */
#line 179 "input.m"
        if (((input__str_2 != NULL) && (strcmp(input__str_2, input__HeadVar__1_1) == 0)))
#line 179 "input.m"
          {
#line 179 "input.m"
            /* we found a match */
#line 179 "input.m"
            /* dispatch to the corresponding code */
#line 179 "input.m"
#line 179 "input.m"
            switch (input__slot_1) {
#line 179 "input.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 179 "input.m"
              case (MR_Integer) 1:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "EM" */
#line 179 "input.m"
                  {
#line 179 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 1));
#line 179 "input.m"
                    input__succeeded = TRUE;
#line 179 "input.m"
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 2:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "TT" */
#line 180 "input.m"
                  {
#line 180 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 5));
#line 180 "input.m"
                    input__succeeded = TRUE;
#line 180 "input.m"
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 3:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "B" */
#line 179 "input.m"
                  {
#line 179 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 179 "input.m"
                    input__succeeded = TRUE;
#line 179 "input.m"
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 4:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "2" */
                  {
                    MR_Integer input__V_12_12 = (MR_Integer) 2;

#line 184 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_7_0_1_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 5:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "7" */
                  {
                    MR_Integer input__V_17_17 = (MR_Integer) 7;

#line 186 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_7_0_2_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 6:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "9" */
                  {
                    MR_Integer input__V_19_19 = (MR_Integer) 9;

#line 186 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_7_0_3_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 8:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "I" */
#line 179 "input.m"
                  {
#line 179 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 2));
#line 179 "input.m"
                    input__succeeded = TRUE;
#line 179 "input.m"
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 18:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "S" */
#line 180 "input.m"
                  {
#line 180 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 4));
#line 180 "input.m"
                    input__succeeded = TRUE;
#line 180 "input.m"
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 20:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "U" */
                  {
                    MR_Integer input__V_9_9 = (MR_Integer) 0;

#line 181 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(1), &input__const_7_0_4_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 30:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "PL" */
#line 180 "input.m"
                  {
#line 180 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 3));
#line 180 "input.m"
                    input__succeeded = TRUE;
#line 180 "input.m"
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 34:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "c" */
                  {
                    MR_Word input__V_23_23 = (MR_Integer) 3;

#line 189 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(3), &input__const_7_0_5_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 35:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "b" */
                  {
                    MR_Word input__V_22_22 = (MR_Integer) 2;

#line 188 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(3), &input__const_7_0_6_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 38:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "g" */
                  {
                    MR_Word input__V_21_21 = (MR_Integer) 1;

#line 188 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(3), &input__const_7_0_7_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 42:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "k" */
                  {
                    MR_Word input__V_26_26 = (MR_Integer) 6;

#line 190 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(3), &input__const_7_0_8_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 44:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "m" */
                  {
                    MR_Word input__V_24_24 = (MR_Integer) 4;

#line 189 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(3), &input__const_7_0_9_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 48:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "1" */
                  {
                    MR_Integer input__V_11_11 = (MR_Integer) 1;

#line 184 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_7_0_10_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 49:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "0" */
                  {
                    MR_Integer input__V_10_10 = (MR_Integer) 0;

#line 183 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_7_0_11_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 50:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "3" */
                  {
                    MR_Integer input__V_13_13 = (MR_Integer) 3;

#line 184 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_7_0_12_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 51:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "r" */
                  {
                    MR_Word input__V_20_20 = (MR_Integer) 0;

#line 188 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(3), &input__const_7_0_13_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 52:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "5" */
                  {
                    MR_Integer input__V_15_15 = (MR_Integer) 5;

#line 185 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_7_0_14_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 53:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "4" */
                  {
                    MR_Integer input__V_14_14 = (MR_Integer) 4;

#line 185 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_7_0_15_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 54:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "w" */
                  {
                    MR_Word input__V_27_27 = (MR_Integer) 7;

#line 190 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(3), &input__const_7_0_16_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 55:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "6" */
                  {
                    MR_Integer input__V_16_16 = (MR_Integer) 6;

#line 185 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_7_0_17_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 56:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "y" */
                  {
                    MR_Word input__V_25_25 = (MR_Integer) 5;

#line 189 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(3), &input__const_7_0_18_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
              case (MR_Integer) 57:
#line 179 "input.m"
                {
#line 179 "input.m"
                  /* case "8" */
                  {
                    MR_Integer input__V_18_18 = (MR_Integer) 8;

#line 186 "input.m"
                    input__T_4 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_7_0_19_T_4);
                    input__succeeded = TRUE;
                  }
#line 179 "input.m"
                }
#line 179 "input.m"
                break;
#line 179 "input.m"
            }
#line 179 "input.m"
            goto label_1;
#line 179 "input.m"
          }
#line 179 "input.m"
        /* no match yet, so get next slot in hash chain */
#line 179 "input.m"
        input__slot_1 = input__const_7_0_20_next_slots_table[input__slot_1];
#line 179 "input.m"
      }
#line 179 "input.m"
    while ((input__slot_1 >= (MR_Integer) 0));
#line 179 "input.m"
    /* no match, so fail */
#line 179 "input.m"
    input__succeeded = FALSE;
#line 179 "input.m"
  label_1:;
#line 179 "input.m"
    /* end of hashed string switch */
#line 169 "input.m"
    if (input__succeeded)
#line 169 "input.m"
      input__HeadVar__2_2 = input__T_4;
#line 169 "input.m"
    else
      {
        MR_String input__V_5_5;
        MR_String input__V_6_6 = (MR_String) "unkown tag name: ";
        MR_Word input__TypeInfo_7_7;
        MR_Word input__TypeInfo_8_8;
#line 169 "input.m"
        MR_Box input__conv1_HeadVar__2_2;

#line 76 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
        {
#line 76 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
          mercury__string__append_3_p_2(input__V_6_6, input__HeadVar__1_1, &input__V_5_5);
        }
        input__TypeInfo_7_7 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
        input__TypeInfo_8_8 = (MR_Word) (&input__input__type_ctor_info_tag_0);
#line 169 "input.m"
        {
#line 169 "input.m"
          input__conv1_HeadVar__2_2 = mercury__exception__throw_2_f_0(input__TypeInfo_7_7, input__TypeInfo_8_8, ((MR_Box) (input__V_5_5)));
        }
#line 169 "input.m"
        input__HeadVar__2_2 = ((MR_Word) input__conv1_HeadVar__2_2);
      }
#line 169 "input.m"
    return input__HeadVar__2_2;
#line 169 "input.m"
  }
#line 167 "input.m"
}
#line 122 "input.m"
static /* final */ const MR_Box input__const_6_0_1_V_20_20[1] = {
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 134 "input.m"
static /* final */ const MR_Box input__const_6_0_2_V_39_39[1] = {
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 150 "input.m"
static /* final */ const MR_Box input__const_6_0_3_V_62_62[1] = {
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 159 "input.m"
static /* final */ const MR_Box input__const_6_0_4_V_70_70[1] = {
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};

#line 114 "input.m"
static void MR_CALL input__parse_char_7_p_0(
#line 114 "input.m"
  MR_Char input__HeadVar__1_1,
#line 114 "input.m"
  MR_Word input__HeadVar__2_2,
#line 114 "input.m"
  MR_Word input__HeadVar__3_3,
#line 114 "input.m"
  MR_Word input__HeadVar__4_4,
#line 114 "input.m"
  MR_Word * input__HeadVar__5_5)
#line 114 "input.m"
{
#line 116 "input.m"
  {
#line 116 "input.m"
    bool input__succeeded;

#line 116 "input.m"
#line 116 "input.m"
    switch (MR_tag((MR_Word) input__HeadVar__2_2)) {
#line 116 "input.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 116 "input.m"
      case (MR_Integer) 0:
        {
          MR_Word input__Cs_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 0)));

#line 117 "input.m"
          input__succeeded = (input__HeadVar__1_1 == (MR_Integer) 47);
          if (input__succeeded)
#line 117 "input.m"
            input__succeeded = (input__Cs_9 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 117 "input.m"
          if (input__succeeded)
            {
              MR_Word input__V_19_19;

#line 118 "input.m"
              {
#line 118 "input.m"
                input__V_19_19 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "reading_close_tag"));
#line 118 "input.m"
                MR_hl_field(MR_mktag(1), input__V_19_19, 0) = ((MR_Box) (input__Cs_9));
#line 118 "input.m"
              }
#line 118 "input.m"
              {
#line 118 "input.m"
                input__parse_chars_6_p_0(input__V_19_19, input__HeadVar__3_3, input__HeadVar__4_4, input__HeadVar__5_5);
#line 118 "input.m"
                return;
              }
            }
#line 117 "input.m"
          else
#line 119 "input.m"
            {
#line 119 "input.m"
              input__succeeded = (input__HeadVar__1_1 == (MR_Integer) 62);
#line 119 "input.m"
              if (input__succeeded)
                {
                  MR_Word input__Tag_13;
                  MR_Word input__Tok_14;
                  MR_Word input__V_20_20;
                  MR_Word input__V_21_21;
                  MR_Word input__V_22_22;
                  MR_Word input__V_23_23;
                  MR_String input__V_24_24;

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL input__parse_char_7_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
input__Cs_9
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
input__V_24_24
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 120 "input.m"
                  {
#line 120 "input.m"
                    input__Tag_13 = input__string_to_tag_2_f_0(input__V_24_24);
                  }
#line 121 "input.m"
                  {
#line 121 "input.m"
                    input__Tok_14 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "open");
#line 121 "input.m"
                    MR_hl_field(MR_mktag(0), input__Tok_14, 0) = ((MR_Box) (input__Tag_13));
#line 121 "input.m"
                  }
#line 122 "input.m"
                  input__V_23_23 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 122 "input.m"
                  input__V_20_20 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_6_0_1_V_20_20);
#line 122 "input.m"
                  {
#line 122 "input.m"
                    input__V_21_21 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 122 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_21_21, 0) = ((MR_Box) (input__Tag_13));
#line 122 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_21_21, 1) = ((MR_Box) (input__HeadVar__3_3));
#line 122 "input.m"
                  }
#line 122 "input.m"
                  {
#line 122 "input.m"
                    input__V_22_22 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 122 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_22_22, 0) = ((MR_Box) (input__Tok_14));
#line 122 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_22_22, 1) = ((MR_Box) (input__HeadVar__4_4));
#line 122 "input.m"
                  }
#line 122 "input.m"
                  {
#line 122 "input.m"
                    input__parse_chars_6_p_0(input__V_20_20, input__V_21_21, input__V_22_22, input__HeadVar__5_5);
#line 122 "input.m"
                    return;
                  }
                }
#line 119 "input.m"
              else
#line 123 "input.m"
                {
#line 123 "input.m"
                  input__succeeded = (input__HeadVar__1_1 == (MR_Integer) 60);
#line 123 "input.m"
                  if (input__succeeded)
                    {
                      MR_String input__V_25_25 = (MR_String) "`<' in open tag name";
                      MR_Word input__TypeInfo_80_80 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 124 "input.m"
                      {
#line 124 "input.m"
                        mercury__exception__throw_1_p_0(input__TypeInfo_80_80, ((MR_Box) (input__V_25_25)));
#line 124 "input.m"
                        return;
                      }
                    }
#line 123 "input.m"
                  else
                    {
                      MR_Word input__V_26_26;
                      MR_Word input__V_27_27;

#line 126 "input.m"
                      {
#line 126 "input.m"
                        input__V_27_27 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 126 "input.m"
                        MR_hl_field(MR_mktag(1), input__V_27_27, 0) = ((MR_Box) (MR_Word) (input__HeadVar__1_1));
#line 126 "input.m"
                        MR_hl_field(MR_mktag(1), input__V_27_27, 1) = ((MR_Box) (input__Cs_9));
#line 126 "input.m"
                      }
#line 126 "input.m"
                      {
#line 126 "input.m"
                        input__V_26_26 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "reading_open_tag");
#line 126 "input.m"
                        MR_hl_field(MR_mktag(0), input__V_26_26, 0) = ((MR_Box) (input__V_27_27));
#line 126 "input.m"
                      }
#line 126 "input.m"
                      {
#line 126 "input.m"
                        input__parse_chars_6_p_0(input__V_26_26, input__HeadVar__3_3, input__HeadVar__4_4, input__HeadVar__5_5);
#line 126 "input.m"
                        return;
                      }
                    }
#line 123 "input.m"
                }
#line 119 "input.m"
            }
        }
#line 116 "input.m"
        break;
#line 116 "input.m"
      case (MR_Integer) 1:
        {
          MR_Word input__Cs_29 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__2_2, (MR_Integer) 0)));

#line 130 "input.m"
          input__succeeded = (input__HeadVar__1_1 == (MR_Integer) 62);
#line 130 "input.m"
          if (input__succeeded)
            {
              MR_Word input__Tag_33;
              MR_Word input__Tok_34;
              MR_String input__V_43_43;
#line 133 "input.m"
              MR_Word input__OpenTags_35;
              MR_Word input__V_84_84;

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL input__parse_char_7_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
input__Cs_29
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
input__V_43_43
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 131 "input.m"
              {
#line 131 "input.m"
                input__Tag_33 = input__string_to_tag_2_f_0(input__V_43_43);
              }
#line 132 "input.m"
              {
#line 132 "input.m"
                input__Tok_34 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "close"));
#line 132 "input.m"
                MR_hl_field(MR_mktag(1), input__Tok_34, 0) = ((MR_Box) (input__Tag_33));
#line 132 "input.m"
              }
#line 133 "input.m"
              input__succeeded = (MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 133 "input.m"
              if ((MR_tag((MR_Word) input__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 133 "input.m"
                {
#line 133 "input.m"
                  input__V_84_84 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__3_3, (MR_Integer) 0)));
#line 133 "input.m"
                  input__OpenTags_35 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__HeadVar__3_3, (MR_Integer) 1)));
#line 133 "input.m"
                }
              if (input__succeeded)
#line 133 "input.m"
                {
#line 133 "input.m"
                  input__succeeded = input____Unify____tag_0_0(input__Tag_33, input__V_84_84);
                }
#line 133 "input.m"
              if (input__succeeded)
                {
                  MR_Word input__V_39_39 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_6_0_2_V_39_39);
                  MR_Word input__V_40_40;
                  MR_Word input__V_41_41 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));

#line 134 "input.m"
                  {
#line 134 "input.m"
                    input__V_40_40 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 134 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_40_40, 0) = ((MR_Box) (input__Tok_34));
#line 134 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_40_40, 1) = ((MR_Box) (input__HeadVar__4_4));
#line 134 "input.m"
                  }
#line 134 "input.m"
                  {
#line 134 "input.m"
                    input__parse_chars_6_p_0(input__V_39_39, input__OpenTags_35, input__V_40_40, input__HeadVar__5_5);
#line 134 "input.m"
                    return;
                  }
                }
#line 133 "input.m"
              else
                {
                  MR_String input__V_42_42 = (MR_String) "unexpected close tag";
                  MR_Word input__TypeInfo_81_81 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 136 "input.m"
                  {
#line 136 "input.m"
                    mercury__exception__throw_1_p_0(input__TypeInfo_81_81, ((MR_Box) (input__V_42_42)));
#line 136 "input.m"
                    return;
                  }
                }
            }
#line 130 "input.m"
          else
#line 138 "input.m"
            {
#line 138 "input.m"
              input__succeeded = (input__HeadVar__1_1 == (MR_Integer) 60);
#line 138 "input.m"
              if (input__succeeded)
                {
                  MR_String input__V_44_44 = (MR_String) "`<' in close tag name";
                  MR_Word input__TypeInfo_82_82 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 139 "input.m"
                  {
#line 139 "input.m"
                    mercury__exception__throw_1_p_0(input__TypeInfo_82_82, ((MR_Box) (input__V_44_44)));
#line 139 "input.m"
                    return;
                  }
                }
#line 138 "input.m"
              else
                {
                  MR_Word input__V_45_45;
                  MR_Word input__V_46_46;

#line 141 "input.m"
                  {
#line 141 "input.m"
                    input__V_46_46 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 141 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_46_46, 0) = ((MR_Box) (MR_Word) (input__HeadVar__1_1));
#line 141 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_46_46, 1) = ((MR_Box) (input__Cs_29));
#line 141 "input.m"
                  }
#line 141 "input.m"
                  {
#line 141 "input.m"
                    input__V_45_45 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "reading_close_tag"));
#line 141 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_45_45, 0) = ((MR_Box) (input__V_46_46));
#line 141 "input.m"
                  }
#line 141 "input.m"
                  {
#line 141 "input.m"
                    input__parse_chars_6_p_0(input__V_45_45, input__HeadVar__3_3, input__HeadVar__4_4, input__HeadVar__5_5);
#line 141 "input.m"
                    return;
                  }
                }
#line 138 "input.m"
            }
        }
#line 116 "input.m"
        break;
#line 116 "input.m"
      case (MR_Integer) 2:
        {
          MR_Word input__Cs_48 = ((MR_Word) (MR_hl_field(MR_mktag(2), input__HeadVar__2_2, (MR_Integer) 0)));

#line 145 "input.m"
          {
#line 145 "input.m"
            input__succeeded = input__is_wspc_1_p_0(input__HeadVar__1_1);
          }
#line 145 "input.m"
          if (input__succeeded)
#line 146 "input.m"
            {
#line 146 "input.m"
              input__succeeded = (input__Cs_48 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 146 "input.m"
              if (input__succeeded)
                {
                  MR_Word input__V_60_60;
                  MR_Word input__V_61_61;

#line 147 "input.m"
                  {
#line 147 "input.m"
                    input__V_61_61 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "spc"));
#line 147 "input.m"
                    MR_hl_field(MR_mktag(2), input__V_61_61, 0) = ((MR_Box) (MR_Word) (input__HeadVar__1_1));
#line 147 "input.m"
                  }
#line 147 "input.m"
                  {
#line 147 "input.m"
                    input__V_60_60 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 147 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_60_60, 0) = ((MR_Box) (input__V_61_61));
#line 147 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_60_60, 1) = ((MR_Box) (input__HeadVar__4_4));
#line 147 "input.m"
                  }
#line 147 "input.m"
                  {
#line 147 "input.m"
                    input__parse_chars_6_p_0(input__HeadVar__2_2, input__HeadVar__3_3, input__V_60_60, input__HeadVar__5_5);
#line 147 "input.m"
                    return;
                  }
                }
#line 146 "input.m"
              else
                {
                  MR_Word input__Tok_52;
                  MR_Word input__V_62_62;
                  MR_Word input__V_63_63;
                  MR_Word input__V_64_64;
                  MR_Word input__V_65_65;
                  MR_Word input__V_66_66;
                  MR_String input__V_67_67;

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL input__parse_char_7_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
input__Cs_48
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
input__V_67_67
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 149 "input.m"
                  {
#line 149 "input.m"
                    input__Tok_52 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "text"));
#line 149 "input.m"
                    MR_hl_field(MR_mktag(3), input__Tok_52, 0) = ((MR_Box) (input__V_67_67));
#line 149 "input.m"
                  }
#line 150 "input.m"
                  input__V_64_64 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 150 "input.m"
                  input__V_62_62 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_6_0_3_V_62_62);
#line 150 "input.m"
                  {
#line 150 "input.m"
                    input__V_65_65 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "spc"));
#line 150 "input.m"
                    MR_hl_field(MR_mktag(2), input__V_65_65, 0) = ((MR_Box) (MR_Word) (input__HeadVar__1_1));
#line 150 "input.m"
                  }
#line 150 "input.m"
                  {
#line 150 "input.m"
                    input__V_66_66 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 150 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_66_66, 0) = ((MR_Box) (input__Tok_52));
#line 150 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_66_66, 1) = ((MR_Box) (input__HeadVar__4_4));
#line 150 "input.m"
                  }
#line 150 "input.m"
                  {
#line 150 "input.m"
                    input__V_63_63 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 150 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_63_63, 0) = ((MR_Box) (input__V_65_65));
#line 150 "input.m"
                    MR_hl_field(MR_mktag(1), input__V_63_63, 1) = ((MR_Box) (input__V_66_66));
#line 150 "input.m"
                  }
#line 150 "input.m"
                  {
#line 150 "input.m"
                    input__parse_chars_6_p_0(input__V_62_62, input__HeadVar__3_3, input__V_63_63, input__HeadVar__5_5);
#line 150 "input.m"
                    return;
                  }
                }
#line 146 "input.m"
            }
#line 145 "input.m"
          else
#line 152 "input.m"
            {
#line 152 "input.m"
              input__succeeded = (input__HeadVar__1_1 == (MR_Integer) 62);
#line 152 "input.m"
              if (input__succeeded)
                {
                  MR_String input__V_68_68 = (MR_String) "unexpected '>'";
                  MR_Word input__TypeInfo_83_83 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 153 "input.m"
                  {
#line 153 "input.m"
                    mercury__exception__throw_1_p_0(input__TypeInfo_83_83, ((MR_Box) (input__V_68_68)));
#line 153 "input.m"
                    return;
                  }
                }
#line 152 "input.m"
              else
#line 154 "input.m"
                {
#line 154 "input.m"
                  input__succeeded = (input__HeadVar__1_1 == (MR_Integer) 60);
#line 154 "input.m"
                  if (input__succeeded)
#line 155 "input.m"
                    {
#line 155 "input.m"
                      input__succeeded = (input__Cs_48 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 155 "input.m"
                      if (input__succeeded)
                        {
                          MR_Word input__V_69_69;

#line 156 "input.m"
                          {
#line 156 "input.m"
                            input__V_69_69 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "reading_open_tag");
#line 156 "input.m"
                            MR_hl_field(MR_mktag(0), input__V_69_69, 0) = ((MR_Box) (input__Cs_48));
#line 156 "input.m"
                          }
#line 156 "input.m"
                          {
#line 156 "input.m"
                            input__parse_chars_6_p_0(input__V_69_69, input__HeadVar__3_3, input__HeadVar__4_4, input__HeadVar__5_5);
#line 156 "input.m"
                            return;
                          }
                        }
#line 155 "input.m"
                      else
                        {
                          MR_Word input__V_70_70;
                          MR_Word input__V_71_71;
                          MR_Word input__V_72_72;
                          MR_String input__V_73_73;
                          MR_Word input__Tok_76;

#line 158 "input.m"
                          {
#line 158 "input.m"
                            input__V_73_73 = mercury__string__from_rev_char_list_2_f_0(input__Cs_48);
                          }
#line 158 "input.m"
                          {
#line 158 "input.m"
                            input__Tok_76 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "text"));
#line 158 "input.m"
                            MR_hl_field(MR_mktag(3), input__Tok_76, 0) = ((MR_Box) (input__V_73_73));
#line 158 "input.m"
                          }
#line 159 "input.m"
                          input__V_72_72 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 159 "input.m"
                          input__V_70_70 = (MR_Word) &input__const_6_0_4_V_70_70;
#line 159 "input.m"
                          {
#line 159 "input.m"
                            input__V_71_71 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 159 "input.m"
                            MR_hl_field(MR_mktag(1), input__V_71_71, 0) = ((MR_Box) (input__Tok_76));
#line 159 "input.m"
                            MR_hl_field(MR_mktag(1), input__V_71_71, 1) = ((MR_Box) (input__HeadVar__4_4));
#line 159 "input.m"
                          }
#line 159 "input.m"
                          {
#line 159 "input.m"
                            input__parse_chars_6_p_0(input__V_70_70, input__HeadVar__3_3, input__V_71_71, input__HeadVar__5_5);
#line 159 "input.m"
                            return;
                          }
                        }
#line 155 "input.m"
                    }
#line 154 "input.m"
                  else
                    {
                      MR_Word input__V_74_74;
                      MR_Word input__V_75_75;

#line 162 "input.m"
                      {
#line 162 "input.m"
                        input__V_75_75 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 162 "input.m"
                        MR_hl_field(MR_mktag(1), input__V_75_75, 0) = ((MR_Box) (MR_Word) (input__HeadVar__1_1));
#line 162 "input.m"
                        MR_hl_field(MR_mktag(1), input__V_75_75, 1) = ((MR_Box) (input__Cs_48));
#line 162 "input.m"
                      }
#line 162 "input.m"
                      {
#line 162 "input.m"
                        input__V_74_74 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "reading_text"));
#line 162 "input.m"
                        MR_hl_field(MR_mktag(2), input__V_74_74, 0) = ((MR_Box) (input__V_75_75));
#line 162 "input.m"
                      }
#line 162 "input.m"
                      {
#line 162 "input.m"
                        input__parse_chars_6_p_0(input__V_74_74, input__HeadVar__3_3, input__HeadVar__4_4, input__HeadVar__5_5);
#line 162 "input.m"
                        return;
                      }
                    }
#line 154 "input.m"
                }
#line 152 "input.m"
            }
        }
#line 116 "input.m"
        break;
#line 116 "input.m"
    }
#line 116 "input.m"
  }
#line 114 "input.m"
}
static /* final */ const MR_Box input__const_5_0_1_TypeInfo_25_72[2] = {
		((MR_Box) ((&mercury__list__list__type_ctor_info_list_1))),
		((MR_Box) ((&input__input__type_ctor_info_token_0)))};
static /* final */ const MR_Box input__const_5_0_2_TypeInfo_29_76[2] = {
		((MR_Box) ((&mercury__list__list__type_ctor_info_list_1))),
		((MR_Box) ((&input__input__type_ctor_info_token_0)))};
static /* final */ const MR_Box input__const_5_0_3_TypeInfo_33_80[2] = {
		((MR_Box) ((&mercury__list__list__type_ctor_info_list_1))),
		((MR_Box) ((&input__input__type_ctor_info_token_0)))};
static /* final */ const MR_Box input__const_5_0_4_TypeInfo_19_19[2] = {
		((MR_Box) ((&mercury__io__io__type_ctor_info_result_1))),
		((MR_Box) ((&mercury__builtin__builtin__type_ctor_info_character_0)))};

#line 99 "input.m"
static void MR_CALL input__parse_chars_6_p_0(
#line 99 "input.m"
  MR_Word input__HeadVar__1_1,
#line 99 "input.m"
  MR_Word input__HeadVar__2_2,
#line 99 "input.m"
  MR_Word input__HeadVar__3_3,
#line 99 "input.m"
  MR_Word * input__HeadVar__4_4)
#line 99 "input.m"
{
  {
    bool input__succeeded;
    MR_Word input__Stream_5_23;
    MR_Integer input__Code_7_32;

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL input__parse_chars_6_p_0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__Stream_5_23
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL input__parse_chars_6_p_0
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word File;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer CharCode;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	File = 
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__Stream_5_23
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	CharCode = mercury_getc((MercuryFile *) File);
	update_io(IO0, IO);

#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__Code_7_32
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = CharCode;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 219 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    input__succeeded = (input__Code_7_32 == (MR_Integer) -1);
    if (input__succeeded)
#line 205 "input.m"
#line 205 "input.m"
      switch (MR_tag((MR_Word) input__HeadVar__1_1)) {
#line 205 "input.m"
        default: /*NOTREACHED*/ MR_assert(0);
#line 205 "input.m"
        case (MR_Integer) 0:
          {
            MR_String input__V_55_55 = (MR_String) "unfinished open tag in input";
            MR_Word input__TypeInfo_22_69 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
            MR_Word input__TypeInfo_23_70 = (MR_Word) (&input__input__type_ctor_info_token_0);
            MR_Word input__TypeInfo_24_71 = (MR_Word) (&mercury__list__list__type_ctor_info_list_1);
            MR_Word input__TypeInfo_25_72 = (MR_Word) &input__const_5_0_1_TypeInfo_25_72;
#line 205 "input.m"
            MR_Box input__conv1_HeadVar__4_4;

#line 205 "input.m"
            {
#line 205 "input.m"
              input__conv1_HeadVar__4_4 = mercury__exception__throw_2_f_0(input__TypeInfo_22_69, input__TypeInfo_25_72, ((MR_Box) (input__V_55_55)));
            }
#line 205 "input.m"
            *input__HeadVar__4_4 = ((MR_Word) input__conv1_HeadVar__4_4);
          }
#line 205 "input.m"
          break;
#line 205 "input.m"
        case (MR_Integer) 1:
          {
            MR_String input__V_59_59 = (MR_String) "unfinished close tag in input";
            MR_Word input__TypeInfo_26_73 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
            MR_Word input__TypeInfo_27_74 = (MR_Word) (&input__input__type_ctor_info_token_0);
            MR_Word input__TypeInfo_28_75 = (MR_Word) (&mercury__list__list__type_ctor_info_list_1);
            MR_Word input__TypeInfo_29_76 = (MR_Word) &input__const_5_0_2_TypeInfo_29_76;
#line 208 "input.m"
            MR_Box input__conv2_HeadVar__4_4;

#line 208 "input.m"
            {
#line 208 "input.m"
              input__conv2_HeadVar__4_4 = mercury__exception__throw_2_f_0(input__TypeInfo_26_73, input__TypeInfo_29_76, ((MR_Box) (input__V_59_59)));
            }
#line 208 "input.m"
            *input__HeadVar__4_4 = ((MR_Word) input__conv2_HeadVar__4_4);
          }
#line 205 "input.m"
          break;
#line 205 "input.m"
        case (MR_Integer) 2:
          {
            MR_Word input__V_81_81 = ((MR_Word) (MR_hl_field(MR_mktag(2), input__HeadVar__1_1, (MR_Integer) 0)));

#line 205 "input.m"
            if ((input__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 211 "input.m"
              {
#line 212 "input.m"
                input__succeeded = (input__V_81_81 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 211 "input.m"
                if (input__succeeded)
#line 211 "input.m"
                  *input__HeadVar__4_4 = input__HeadVar__3_3;
#line 211 "input.m"
                else
                  {
                    MR_Word input__V_62_62;
                    MR_String input__V_63_63;

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL input__parse_chars_6_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
input__V_81_81
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
input__V_63_63
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 213 "input.m"
                    {
#line 213 "input.m"
                      input__V_62_62 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "text"));
#line 213 "input.m"
                      MR_hl_field(MR_mktag(3), input__V_62_62, 0) = ((MR_Box) (input__V_63_63));
#line 213 "input.m"
                    }
#line 211 "input.m"
                    {
#line 211 "input.m"
                      *input__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 211 "input.m"
                      MR_hl_field(MR_mktag(1), *input__HeadVar__4_4, 0) = ((MR_Box) (input__V_62_62));
#line 211 "input.m"
                      MR_hl_field(MR_mktag(1), *input__HeadVar__4_4, 1) = ((MR_Box) (input__HeadVar__3_3));
#line 211 "input.m"
                    }
                  }
#line 211 "input.m"
              }
#line 205 "input.m"
            else
#line 205 "input.m"
              {
                MR_String input__V_68_68 = (MR_String) "EOF with unclosed tags";
                MR_Word input__TypeInfo_30_77 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
                MR_Word input__TypeInfo_31_78 = (MR_Word) (&input__input__type_ctor_info_token_0);
                MR_Word input__TypeInfo_32_79 = (MR_Word) (&mercury__list__list__type_ctor_info_list_1);
                MR_Word input__TypeInfo_33_80 = (MR_Word) &input__const_5_0_3_TypeInfo_33_80;
#line 216 "input.m"
                MR_Box input__conv3_HeadVar__4_4;

#line 216 "input.m"
                {
#line 216 "input.m"
                  input__conv3_HeadVar__4_4 = mercury__exception__throw_2_f_0(input__TypeInfo_30_77, input__TypeInfo_33_80, ((MR_Box) (input__V_68_68)));
                }
#line 216 "input.m"
                *input__HeadVar__4_4 = ((MR_Word) input__conv3_HeadVar__4_4);
#line 205 "input.m"
              }
          }
#line 205 "input.m"
          break;
#line 205 "input.m"
      }
    else
      {
        MR_Char input__Char_8_34;

#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
{
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#define MR_PROC_LABEL input__parse_chars_6_p_0
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	MR_Char Character;
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	MR_Integer Int;
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	Int = 
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
input__Code_7_32
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
;
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
		{
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

	/*
	** If the integer doesn't fit into a char, then
	** the assignment `Character = Int' below will truncate it.
	** SUCCESS_INDICATOR will be set to true only if
	** the result was not truncated.
	*/
	Character = Int;
	SUCCESS_INDICATOR = ((MR_UnsignedChar) Character == Int);

#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

		;}
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#undef MR_PROC_LABEL
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	if (SUCCESS_INDICATOR) {
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
input__Char_8_34
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
 = Character;
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	}
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
input__succeeded
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
 = SUCCESS_INDICATOR;
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
}
        if (input__succeeded)
#line 105 "input.m"
          {
#line 105 "input.m"
            input__parse_char_7_p_0(input__Char_8_34, input__HeadVar__1_1, input__HeadVar__2_2, input__HeadVar__3_3, input__HeadVar__4_4);
#line 105 "input.m"
            return;
          }
        else
          {
            MR_Word input__TypeInfo_17_17;
            MR_Word input__TypeInfo_18_18;
            MR_Word input__TypeInfo_19_19;
            MR_String input__V_14_35 = (MR_String) "read failed: ";
            MR_String input__Msg_9_36;
            MR_Word input__V_13_37;
            MR_Word input__Result_89;

#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL input__parse_chars_6_p_0
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Msg0;
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Msg;
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Msg0 = 
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__V_14_35
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	ML_maybe_make_err_msg(TRUE, Msg0, MR_PROC_LABEL, Msg);
}
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__Msg_9_36
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Msg;
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 233 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            input__V_13_37 = (MR_Word) input__Msg_9_36;
#line 232 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            {
#line 232 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
              input__Result_89 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "error"));
#line 232 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
              MR_hl_field(MR_mktag(2), input__Result_89, 0) = ((MR_Box) (input__V_13_37));
#line 232 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            }
            input__TypeInfo_18_18 = (MR_Word) (&mercury__io__io__type_ctor_info_result_1);
            input__TypeInfo_17_17 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_character_0);
            input__TypeInfo_19_19 = (MR_Word) &input__const_5_0_4_TypeInfo_19_19;
#line 103 "input.m"
            {
#line 103 "input.m"
              mercury__exception__throw_1_p_0(input__TypeInfo_19_19, ((MR_Box) (input__Result_89)));
#line 103 "input.m"
              return;
            }
          }
      }
  }
#line 99 "input.m"
}

#line 72 "input.m"
MR_Word MR_CALL input__apply_tag_3_f_0(
#line 72 "input.m"
  MR_Word input__HeadVar__1_1,
#line 72 "input.m"
  MR_Word input__HeadVar__2_2)
#line 72 "input.m"
{
  {
    bool input__succeeded;
    MR_Word input__HeadVar__3_3;
    MR_Word input__V_162_162 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 7)));
    MR_Integer input__V_163_163 = ((MR_Integer) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 6)));
    MR_Integer input__V_164_164 = ((MR_Integer) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 5)));
    MR_Word input__V_165_165 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 4)));
    MR_Word input__V_166_166 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 3)));
    MR_Word input__V_167_167 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word input__V_168_168 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word input__V_169_169 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 0)));

#line 263 "input.m"
#line 263 "input.m"
    switch (MR_tag((MR_Word) input__HeadVar__1_1)) {
#line 263 "input.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 263 "input.m"
      case (MR_Integer) 0:
#line 263 "input.m"
#line 263 "input.m"
        switch (MR_unmkbody(input__HeadVar__1_1)) {
#line 263 "input.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 263 "input.m"
          case (MR_Integer) 0:
            {
              MR_Word input__V_5_5 = (MR_Integer) 1;

#line 263 "input.m"
              {
#line 263 "input.m"
                input__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 8 * sizeof(MR_Word)), "attrs");
#line 263 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 0) = ((MR_Box) (input__V_5_5));
#line 263 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 1) = ((MR_Box) (input__V_168_168));
#line 263 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 2) = ((MR_Box) (input__V_167_167));
#line 263 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 3) = ((MR_Box) (input__V_166_166));
#line 263 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 4) = ((MR_Box) (input__V_165_165));
#line 263 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 5) = ((MR_Box) (input__V_164_164));
#line 263 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 6) = ((MR_Box) (input__V_163_163));
#line 263 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 7) = ((MR_Box) (input__V_162_162));
#line 263 "input.m"
              }
            }
#line 263 "input.m"
            break;
#line 263 "input.m"
          case (MR_Integer) 1:
            {
              MR_Word input__V_22_22;
              MR_Word input__V_99_99;
              MR_Word input__V_101_101;
              MR_Integer input__V_102_102;
              MR_Integer input__V_103_103;
              MR_Word input__V_104_104;
              MR_Word input__V_105_105;
              MR_Word input__V_106_106;
#line 270 "input.m"
              MR_Word input__V_100_100;

#line 270 "input.m"
              {
#line 270 "input.m"
                input__V_22_22 = mercury__bool__not_2_f_0(input__V_168_168);
              }
#line 270 "input.m"
              input__V_99_99 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 0)));
#line 270 "input.m"
              input__V_100_100 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 1)));
#line 270 "input.m"
              input__V_106_106 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 2)));
#line 270 "input.m"
              input__V_105_105 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 3)));
#line 270 "input.m"
              input__V_104_104 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 4)));
#line 270 "input.m"
              input__V_103_103 = ((MR_Integer) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 5)));
#line 270 "input.m"
              input__V_102_102 = ((MR_Integer) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 6)));
#line 270 "input.m"
              input__V_101_101 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 7)));
#line 270 "input.m"
              {
#line 270 "input.m"
                input__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 8 * sizeof(MR_Word)), "attrs");
#line 270 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 0) = ((MR_Box) (input__V_99_99));
#line 270 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 1) = ((MR_Box) (input__V_22_22));
#line 270 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 2) = ((MR_Box) (input__V_106_106));
#line 270 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 3) = ((MR_Box) (input__V_105_105));
#line 270 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 4) = ((MR_Box) (input__V_104_104));
#line 270 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 5) = ((MR_Box) (input__V_103_103));
#line 270 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 6) = ((MR_Box) (input__V_102_102));
#line 270 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 7) = ((MR_Box) (input__V_101_101));
#line 270 "input.m"
              }
            }
#line 263 "input.m"
            break;
#line 263 "input.m"
          case (MR_Integer) 2:
            {
              MR_Word input__V_7_7 = (MR_Integer) 1;

#line 264 "input.m"
              {
#line 264 "input.m"
                input__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 8 * sizeof(MR_Word)), "attrs");
#line 264 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 0) = ((MR_Box) (input__V_169_169));
#line 264 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 1) = ((MR_Box) (input__V_168_168));
#line 264 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 2) = ((MR_Box) (input__V_7_7));
#line 264 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 3) = ((MR_Box) (input__V_166_166));
#line 264 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 4) = ((MR_Box) (input__V_165_165));
#line 264 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 5) = ((MR_Box) (input__V_164_164));
#line 264 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 6) = ((MR_Box) (input__V_163_163));
#line 264 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 7) = ((MR_Box) (input__V_162_162));
#line 264 "input.m"
              }
            }
#line 263 "input.m"
            break;
#line 263 "input.m"
          case (MR_Integer) 3:
            {
              MR_Word input__V_26_26 = (MR_Integer) 0;
              MR_Word input__V_28_28 = (MR_Integer) 0;
              MR_Word input__V_30_30 = (MR_Integer) 0;
              MR_Word input__V_32_32 = (MR_Integer) 0;
              MR_Word input__V_34_34 = (MR_Integer) 0;
              MR_Integer input__V_35_35 = (MR_Integer) 0;

#line 271 "input.m"
              {
#line 271 "input.m"
                input__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 8 * sizeof(MR_Word)), "attrs");
#line 271 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 0) = ((MR_Box) (input__V_34_34));
#line 271 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 1) = ((MR_Box) (input__V_32_32));
#line 271 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 2) = ((MR_Box) (input__V_30_30));
#line 271 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 3) = ((MR_Box) (input__V_28_28));
#line 271 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 4) = ((MR_Box) (input__V_26_26));
#line 271 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 5) = ((MR_Box) (input__V_35_35));
#line 271 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 6) = ((MR_Box) (input__V_163_163));
#line 271 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 7) = ((MR_Box) (input__V_162_162));
#line 271 "input.m"
              }
            }
#line 263 "input.m"
            break;
#line 263 "input.m"
          case (MR_Integer) 4:
            {
              MR_Word input__V_20_20 = (MR_Integer) 1;

#line 269 "input.m"
              {
#line 269 "input.m"
                input__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 8 * sizeof(MR_Word)), "attrs");
#line 269 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 0) = ((MR_Box) (input__V_169_169));
#line 269 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 1) = ((MR_Box) (input__V_168_168));
#line 269 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 2) = ((MR_Box) (input__V_167_167));
#line 269 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 3) = ((MR_Box) (input__V_20_20));
#line 269 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 4) = ((MR_Box) (input__V_165_165));
#line 269 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 5) = ((MR_Box) (input__V_164_164));
#line 269 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 6) = ((MR_Box) (input__V_163_163));
#line 269 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 7) = ((MR_Box) (input__V_162_162));
#line 269 "input.m"
              }
            }
#line 263 "input.m"
            break;
#line 263 "input.m"
          case (MR_Integer) 5:
            {
              MR_Word input__V_9_9 = (MR_Integer) 1;

#line 265 "input.m"
              {
#line 265 "input.m"
                input__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 8 * sizeof(MR_Word)), "attrs");
#line 265 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 0) = ((MR_Box) (input__V_169_169));
#line 265 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 1) = ((MR_Box) (input__V_168_168));
#line 265 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 2) = ((MR_Box) (input__V_167_167));
#line 265 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 3) = ((MR_Box) (input__V_166_166));
#line 265 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 4) = ((MR_Box) (input__V_9_9));
#line 265 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 5) = ((MR_Box) (input__V_164_164));
#line 265 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 6) = ((MR_Box) (input__V_163_163));
#line 265 "input.m"
                MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 7) = ((MR_Box) (input__V_162_162));
#line 265 "input.m"
              }
            }
#line 263 "input.m"
            break;
#line 263 "input.m"
        }
#line 263 "input.m"
        break;
#line 263 "input.m"
      case (MR_Integer) 1:
        {
          MR_Integer input__V_12_12;
          MR_Integer input__V_14_14 = (MR_Integer) 1;
          MR_Word input__V_60_60;
          MR_Word input__V_61_61;
          MR_Word input__V_62_62;
          MR_Word input__V_63_63;
          MR_Word input__V_64_64;
          MR_Word input__V_66_66;
          MR_Integer input__V_67_67;
#line 266 "input.m"
          MR_Integer input__V_65_65;

#line 266 "input.m"
          input__V_12_12 = (input__V_164_164 + input__V_14_14);
#line 266 "input.m"
          input__V_64_64 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 0)));
#line 266 "input.m"
          input__V_63_63 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 1)));
#line 266 "input.m"
          input__V_62_62 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 2)));
#line 266 "input.m"
          input__V_61_61 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 3)));
#line 266 "input.m"
          input__V_60_60 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 4)));
#line 266 "input.m"
          input__V_65_65 = ((MR_Integer) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 5)));
#line 266 "input.m"
          input__V_67_67 = ((MR_Integer) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 6)));
#line 266 "input.m"
          input__V_66_66 = ((MR_Word) (MR_hl_field(MR_mktag(0), input__HeadVar__2_2, (MR_Integer) 7)));
#line 266 "input.m"
          {
#line 266 "input.m"
            input__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 8 * sizeof(MR_Word)), "attrs");
#line 266 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 0) = ((MR_Box) (input__V_64_64));
#line 266 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 1) = ((MR_Box) (input__V_63_63));
#line 266 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 2) = ((MR_Box) (input__V_62_62));
#line 266 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 3) = ((MR_Box) (input__V_61_61));
#line 266 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 4) = ((MR_Box) (input__V_60_60));
#line 266 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 5) = ((MR_Box) (input__V_12_12));
#line 266 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 6) = ((MR_Box) (input__V_67_67));
#line 266 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 7) = ((MR_Box) (input__V_66_66));
#line 266 "input.m"
          }
        }
#line 263 "input.m"
        break;
#line 263 "input.m"
      case (MR_Integer) 2:
        {
          MR_Integer input__S_15 = ((MR_Integer) (MR_hl_field(MR_mktag(2), input__HeadVar__1_1, (MR_Integer) 0)));

#line 267 "input.m"
          {
#line 267 "input.m"
            input__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 8 * sizeof(MR_Word)), "attrs");
#line 267 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 0) = ((MR_Box) (input__V_169_169));
#line 267 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 1) = ((MR_Box) (input__V_168_168));
#line 267 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 2) = ((MR_Box) (input__V_167_167));
#line 267 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 3) = ((MR_Box) (input__V_166_166));
#line 267 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 4) = ((MR_Box) (input__V_165_165));
#line 267 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 5) = ((MR_Box) (input__V_164_164));
#line 267 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 6) = ((MR_Box) (input__S_15));
#line 267 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 7) = ((MR_Box) (input__V_162_162));
#line 267 "input.m"
          }
        }
#line 263 "input.m"
        break;
#line 263 "input.m"
      case (MR_Integer) 3:
        {
          MR_Word input__C_17 = ((MR_Word) (MR_hl_field(MR_mktag(3), input__HeadVar__1_1, (MR_Integer) 0)));

#line 268 "input.m"
          {
#line 268 "input.m"
            input__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 8 * sizeof(MR_Word)), "attrs");
#line 268 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 0) = ((MR_Box) (input__V_169_169));
#line 268 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 1) = ((MR_Box) (input__V_168_168));
#line 268 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 2) = ((MR_Box) (input__V_167_167));
#line 268 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 3) = ((MR_Box) (input__V_166_166));
#line 268 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 4) = ((MR_Box) (input__V_165_165));
#line 268 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 5) = ((MR_Box) (input__V_164_164));
#line 268 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 6) = ((MR_Box) (input__V_163_163));
#line 268 "input.m"
            MR_hl_field(MR_mktag(0), input__HeadVar__3_3, 7) = ((MR_Box) (input__C_17));
#line 268 "input.m"
          }
        }
#line 263 "input.m"
        break;
#line 263 "input.m"
    }
    return input__HeadVar__3_3;
  }
#line 72 "input.m"
}

#line 68 "input.m"
void MR_CALL input__write_tokens_3_p_0(
#line 68 "input.m"
  MR_Word input__HeadVar__1_1)
#line 68 "input.m"
{
  {
    bool input__succeeded;
    MR_String input__V_7_7 = (MR_String) "";

#line 335 "input.m"
    {
#line 335 "input.m"
      input__write_list__ho6_5_p_in__io_0(input__HeadVar__1_1, input__V_7_7);
#line 335 "input.m"
      return;
    }
  }
#line 68 "input.m"
}
#line 414 "input.m"
static /* final */ const MR_Box input__const_1_0_1_V_13_13[1] = {
		((MR_Box) ((MR_String) ".smlng"))};
#line 414 "input.m"
static /* final */ const MR_Box input__const_1_0_2_V_12_12[2] = {
		((MR_Box) (MR_mkword(MR_mktag(2), &input__const_1_0_1_V_13_13))),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 415 "input.m"
static /* final */ const MR_Box input__const_1_0_3_V_22_22[1] = {
		((MR_Box) ((MR_String) ".done"))};
#line 415 "input.m"
static /* final */ const MR_Box input__const_1_0_4_V_21_21[2] = {
		((MR_Box) (MR_mkword(MR_mktag(2), &input__const_1_0_3_V_22_22))),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};

#line 63 "input.m"
void MR_CALL input__file_names_4_p_0(
#line 63 "input.m"
  MR_String input__HeadVar__1_1,
#line 63 "input.m"
  MR_Integer input__HeadVar__2_2,
#line 63 "input.m"
  MR_String * input__HeadVar__3_3,
#line 63 "input.m"
  MR_String * input__HeadVar__4_4)
#line 63 "input.m"
{
  {
    bool input__succeeded;
    MR_String input__V_7_7 = (MR_String) "%s-%d%s";
    MR_Word input__V_8_8;
    MR_Word input__V_9_9;
    MR_Word input__V_10_10;
    MR_Word input__V_11_11;
    MR_Word input__V_12_12;
    MR_Word input__V_13_13;
    MR_Word input__V_14_14;
    MR_String input__V_15_15;
    MR_String input__V_16_16;
    MR_Word input__V_17_17;
    MR_Word input__V_19_19;
    MR_Word input__V_21_21;
    MR_Word input__V_22_22;
    MR_Word input__V_23_23;
    MR_String input__V_24_24;

#line 414 "input.m"
    {
#line 414 "input.m"
      input__V_9_9 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "s"));
#line 414 "input.m"
      MR_hl_field(MR_mktag(2), input__V_9_9, 0) = ((MR_Box) (input__HeadVar__1_1));
#line 414 "input.m"
    }
#line 414 "input.m"
    {
#line 414 "input.m"
      input__V_11_11 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "i"));
#line 414 "input.m"
      MR_hl_field(MR_mktag(1), input__V_11_11, 0) = ((MR_Box) (input__HeadVar__2_2));
#line 414 "input.m"
    }
#line 400 "input.m"
    input__V_15_15 = (MR_String) ".smlng";
#line 414 "input.m"
    input__V_13_13 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_1_0_1_V_13_13);
#line 414 "input.m"
    input__V_14_14 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 414 "input.m"
    input__V_12_12 = (MR_Word) MR_mkword(MR_mktag(1), &input__const_1_0_2_V_12_12);
#line 414 "input.m"
    {
#line 414 "input.m"
      input__V_10_10 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 414 "input.m"
      MR_hl_field(MR_mktag(1), input__V_10_10, 0) = ((MR_Box) (input__V_11_11));
#line 414 "input.m"
      MR_hl_field(MR_mktag(1), input__V_10_10, 1) = ((MR_Box) (input__V_12_12));
#line 414 "input.m"
    }
#line 414 "input.m"
    {
#line 414 "input.m"
      input__V_8_8 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 414 "input.m"
      MR_hl_field(MR_mktag(1), input__V_8_8, 0) = ((MR_Box) (input__V_9_9));
#line 414 "input.m"
      MR_hl_field(MR_mktag(1), input__V_8_8, 1) = ((MR_Box) (input__V_10_10));
#line 414 "input.m"
    }
#line 523 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
    {
#line 523 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
      mercury__string__format_3_p_0(input__V_7_7, input__V_8_8, input__HeadVar__3_3);
    }
#line 415 "input.m"
    input__V_16_16 = (MR_String) "%s-%d%s";
#line 402 "input.m"
    input__V_24_24 = (MR_String) ".done";
#line 415 "input.m"
    input__V_22_22 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_1_0_3_V_22_22);
#line 415 "input.m"
    input__V_23_23 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 415 "input.m"
    input__V_21_21 = (MR_Word) MR_mkword(MR_mktag(1), &input__const_1_0_4_V_21_21);
#line 415 "input.m"
    {
#line 415 "input.m"
      input__V_19_19 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 415 "input.m"
      MR_hl_field(MR_mktag(1), input__V_19_19, 0) = ((MR_Box) (input__V_11_11));
#line 415 "input.m"
      MR_hl_field(MR_mktag(1), input__V_19_19, 1) = ((MR_Box) (input__V_21_21));
#line 415 "input.m"
    }
#line 415 "input.m"
    {
#line 415 "input.m"
      input__V_17_17 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 415 "input.m"
      MR_hl_field(MR_mktag(1), input__V_17_17, 0) = ((MR_Box) (input__V_9_9));
#line 415 "input.m"
      MR_hl_field(MR_mktag(1), input__V_17_17, 1) = ((MR_Box) (input__V_19_19));
#line 415 "input.m"
    }
#line 523 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
    {
#line 523 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
      mercury__string__format_3_p_0(input__V_16_16, input__V_17_17, input__HeadVar__4_4);
#line 523 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
      return;
    }
  }
#line 63 "input.m"
}
#line 94 "input.m"
static /* final */ const MR_Box input__const_0_0_1_V_28_28[1] = {
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};

#line 55 "input.m"
void MR_CALL input__read_smlng_7_p_0(
#line 55 "input.m"
  MR_String input__HeadVar__1_1,
#line 55 "input.m"
  MR_String input__HeadVar__2_2,
#line 55 "input.m"
  MR_String * input__HeadVar__3_3,
#line 55 "input.m"
  MR_Array * input__HeadVar__4_4,
#line 55 "input.m"
  MR_Array * input__HeadVar__5_5)
#line 55 "input.m"
{
  {
    bool input__succeeded;
    MR_Word input__Toks0_13;
    MR_Word input__Toks_14;
    MR_Word input__Result_15;
    MR_String input__V_23_23;
    MR_Word input__Toks_25;
    MR_Word input__V_28_28 = (MR_Word) MR_mkword(MR_mktag(2), &input__const_0_0_1_V_28_28);
    MR_Word input__V_29_29 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
    MR_Word input__V_30_30 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
    MR_Word input__V_31_31 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
    MR_Word input__TypeInfo_11_32;
    MR_Word input__V_5_37;
    MR_Word input__V_39_39;
    MR_Word input__V_40_40;
    MR_Word input__V_41_41;
    MR_Word input__V_42_42;
    MR_Word input__V_43_43;
    MR_Word input__TypeInfo_9_44;
    MR_Word input__V_5_49;
    MR_Word input__V_51_51;
#line 315 "input.m"
    MR_Word input__V_16_16;

#line 94 "input.m"
    {
#line 94 "input.m"
      input__parse_chars_6_p_0(input__V_28_28, input__V_29_29, input__V_30_30, &input__Toks_25);
    }
    input__TypeInfo_11_32 = (MR_Word) (&input__input__type_ctor_info_token_0);
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    input__V_5_37 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      mercury__list__reverse_2_3_p_0(input__TypeInfo_11_32, input__Toks_25, input__V_5_37, &input__Toks0_13);
    }
#line 224 "input.m"
    {
#line 224 "input.m"
      input__V_40_40 = attrs__root_attrs_1_f_0();
    }
#line 224 "input.m"
    input__V_41_41 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 224 "input.m"
    input__V_42_42 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 224 "input.m"
    input__V_43_43 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 224 "input.m"
    {
#line 224 "input.m"
      input__V_39_39 = input__pds_6_f_0(input__Toks0_13, input__V_40_40, input__V_41_41, input__V_42_42, input__V_43_43);
    }
    input__TypeInfo_9_44 = (MR_Word) (&input__input__type_ctor_info_token_0);
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    input__V_5_49 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      mercury__list__reverse_2_3_p_0(input__TypeInfo_9_44, input__V_39_39, input__V_5_49, &input__Toks_14);
    }
#line 224 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 224 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      input__filter_map__ho7_3_p_in__list_0(input__Toks_14, &input__V_51_51);
    }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL input__read_smlng_7_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
input__V_51_51
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
*input__HeadVar__3_3
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 302 "input.m"
    {
#line 302 "input.m"
      input__attrss_extents_3_p_0(input__Toks_14, input__HeadVar__4_4, input__HeadVar__5_5);
    }
#line 312 "input.m"
    {
#line 312 "input.m"
      input__write_tokens_to_file_4_p_0(input__HeadVar__1_1, input__Toks_14);
    }
#line 314 "input.m"
    {
#line 314 "input.m"
      mercury__io__tell_4_p_0(input__HeadVar__2_2, &input__Result_15);
    }
#line 315 "input.m"
    input__succeeded = (MR_tag((MR_Word) input__Result_15) == MR_mktag((MR_Integer) 1));
#line 315 "input.m"
    if ((MR_tag((MR_Word) input__Result_15) == MR_mktag((MR_Integer) 1)))
#line 315 "input.m"
      input__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(1), input__Result_15, (MR_Integer) 0)));
#line 315 "input.m"
    if (input__succeeded)
      {
        MR_Word input__TypeInfo_24_24 = (MR_Word) (&mercury__io__io__type_ctor_info_res_0);

#line 315 "input.m"
        {
#line 315 "input.m"
          mercury__exception__throw_1_p_0(input__TypeInfo_24_24, ((MR_Box) (input__Result_15)));
        }
      }
#line 315 "input.m"
    else
      {
      }
#line 316 "input.m"
    input__V_23_23 = (MR_String) "\n";
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL input__read_smlng_7_p_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
input__V_23_23
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 317 "input.m"
    {
#line 317 "input.m"
      mercury__io__told_2_p_0();
#line 317 "input.m"
      return;
    }
  }
#line 55 "input.m"
}

void mercury__input__init(void)
{
}

void mercury__input__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&input__input__type_ctor_info_tokens_0);
	MR_register_type_ctor_info(&input__input__type_ctor_info_token_0);
	MR_register_type_ctor_info(&input__input__type_ctor_info_tags_0);
	MR_register_type_ctor_info(&input__input__type_ctor_info_tag_0);
	MR_register_type_ctor_info(&input__input__type_ctor_info_st_0);
	MR_register_type_ctor_info(&input__input__type_ctor_info_extents_0);
	MR_register_type_ctor_info(&input__input__type_ctor_info_attrss_0);
	MR_register_type_ctor_info(&input__input__type_ctor_info_ae_0);
}

void mercury__input__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module input. */
