/*
** Automatically generated from `attrs.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module attrs. */
/* :- implementation. */

#include "attrs.h"


#include "mercury.assoc_list.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.enum.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "mercury.ops.h"
#include "mercury.private_builtin.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.term.h"
#include "mercury.time.h"
#include "mercury.tree234.h"



static const MR_EnumFunctorDescPtr attrs__attrs__enum_name_ordered_colour_0[9];
static const MR_EnumFunctorDescPtr attrs__attrs__enum_value_ordered_colour_0[9];
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_0;
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_1;
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_2;
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_3;
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_4;
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_5;
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_6;
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_7;
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_8;
static const MR_DuFunctorDescPtr attrs__attrs__du_name_ordered_attrs_0[1];
static const MR_DuFunctorDesc attrs__attrs__du_functor_desc_attrs_0_0;
static const MR_ConstString attrs__attrs__field_names_attrs_0_0[8];
static const MR_PseudoTypeInfo attrs__attrs__field_types_attrs_0_0[8];
static const MR_DuPtagLayout attrs__attrs__du_ptag_ordered_attrs_0[1];
static const MR_DuFunctorDescPtr attrs__attrs__du_stag_ordered_attrs_0_0[1];
#line 124 "attrs.m"
static /* final */ const MR_Box attrs__const_6_0_1_HeadVar__1_1[8];



const MR_TypeCtorInfo_Struct attrs__attrs__type_ctor_info_colour_0 = {
		(MR_Integer) 0,
		((MR_Box) (attrs____Unify____colour_0_0)),
		((MR_Box) (attrs____Unify____colour_0_0)),
		((MR_Box) (attrs____Compare____colour_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_ENUM,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "attrs",
		(MR_String) "colour",
		(MR_Integer) 4,
		{
		(MR_Box) attrs__attrs__enum_name_ordered_colour_0},
		{
		(MR_Box) attrs__attrs__enum_value_ordered_colour_0},
		(MR_Integer) 9,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct attrs__attrs__type_ctor_info_attrs_0 = {
		(MR_Integer) 0,
		((MR_Box) (attrs____Unify____attrs_0_0)),
		((MR_Box) (attrs____Unify____attrs_0_0)),
		((MR_Box) (attrs____Compare____attrs_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "attrs",
		(MR_String) "attrs",
		(MR_Integer) 4,
		{
		(MR_Box) attrs__attrs__du_name_ordered_attrs_0},
		{
		(MR_Box) attrs__attrs__du_ptag_ordered_attrs_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
static const MR_EnumFunctorDescPtr attrs__attrs__enum_name_ordered_colour_0[9] = {
		(&attrs__attrs__enum_functor_desc_colour_0_2),
		(&attrs__attrs__enum_functor_desc_colour_0_3),
		(&attrs__attrs__enum_functor_desc_colour_0_1),
		(&attrs__attrs__enum_functor_desc_colour_0_6),
		(&attrs__attrs__enum_functor_desc_colour_0_4),
		(&attrs__attrs__enum_functor_desc_colour_0_0),
		(&attrs__attrs__enum_functor_desc_colour_0_8),
		(&attrs__attrs__enum_functor_desc_colour_0_7),
		(&attrs__attrs__enum_functor_desc_colour_0_5)};
static const MR_EnumFunctorDescPtr attrs__attrs__enum_value_ordered_colour_0[9] = {
		(&attrs__attrs__enum_functor_desc_colour_0_0),
		(&attrs__attrs__enum_functor_desc_colour_0_1),
		(&attrs__attrs__enum_functor_desc_colour_0_2),
		(&attrs__attrs__enum_functor_desc_colour_0_3),
		(&attrs__attrs__enum_functor_desc_colour_0_4),
		(&attrs__attrs__enum_functor_desc_colour_0_5),
		(&attrs__attrs__enum_functor_desc_colour_0_6),
		(&attrs__attrs__enum_functor_desc_colour_0_7),
		(&attrs__attrs__enum_functor_desc_colour_0_8)};
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_0 = {
		(MR_String) "r",
		(MR_Integer) 0};
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_1 = {
		(MR_String) "g",
		(MR_Integer) 1};
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_2 = {
		(MR_String) "b",
		(MR_Integer) 2};
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_3 = {
		(MR_String) "c",
		(MR_Integer) 3};
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_4 = {
		(MR_String) "m",
		(MR_Integer) 4};
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_5 = {
		(MR_String) "y",
		(MR_Integer) 5};
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_6 = {
		(MR_String) "k",
		(MR_Integer) 6};
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_7 = {
		(MR_String) "w",
		(MR_Integer) 7};
static const MR_EnumFunctorDesc attrs__attrs__enum_functor_desc_colour_0_8 = {
		(MR_String) "root_colour",
		(MR_Integer) 8};
static const MR_DuFunctorDescPtr attrs__attrs__du_name_ordered_attrs_0[1] = {
		(&attrs__attrs__du_functor_desc_attrs_0_0)};
static const MR_DuFunctorDesc attrs__attrs__du_functor_desc_attrs_0_0 = {
		(MR_String) "attrs",
		(MR_Integer) 8,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		attrs__attrs__field_types_attrs_0_0,
		attrs__attrs__field_names_attrs_0_0,
		(MR_Box) NULL};
static const MR_ConstString attrs__attrs__field_names_attrs_0_0[8] = {
		(MR_String) "b",
		(MR_String) "em",
		(MR_String) "i",
		(MR_String) "s",
		(MR_String) "tt",
		(MR_String) "u",
		(MR_String) "size",
		(MR_String) "colour"};
static const MR_PseudoTypeInfo attrs__attrs__field_types_attrs_0_0[8] = {
		(MR_PseudoTypeInfo) (&mercury__bool__bool__type_ctor_info_bool_0),
		(MR_PseudoTypeInfo) (&mercury__bool__bool__type_ctor_info_bool_0),
		(MR_PseudoTypeInfo) (&mercury__bool__bool__type_ctor_info_bool_0),
		(MR_PseudoTypeInfo) (&mercury__bool__bool__type_ctor_info_bool_0),
		(MR_PseudoTypeInfo) (&mercury__bool__bool__type_ctor_info_bool_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0),
		(MR_PseudoTypeInfo) (&attrs__attrs__type_ctor_info_colour_0)};
static const MR_DuPtagLayout attrs__attrs__du_ptag_ordered_attrs_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		attrs__attrs__du_stag_ordered_attrs_0_0}};
static const MR_DuFunctorDescPtr attrs__attrs__du_stag_ordered_attrs_0_0[1] = {
		(&attrs__attrs__du_functor_desc_attrs_0_0)};

#line 40 "attrs.m"
void MR_CALL attrs____Compare____colour_0_0(
#line 40 "attrs.m"
  MR_Word * attrs__HeadVar__1_1,
#line 40 "attrs.m"
  MR_Word attrs__HeadVar__2_2,
#line 40 "attrs.m"
  MR_Word attrs__HeadVar__3_3)
#line 40 "attrs.m"
{
  {
    bool attrs__succeeded;
    MR_Integer attrs__V_4_4 = (MR_Integer) attrs__HeadVar__2_2;
    MR_Integer attrs__V_5_5 = (MR_Integer) attrs__HeadVar__3_3;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    attrs__succeeded = (attrs__V_4_4 < attrs__V_5_5);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (attrs__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *attrs__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        attrs__succeeded = (attrs__V_4_4 == attrs__V_5_5);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (attrs__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *attrs__HeadVar__1_1 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *attrs__HeadVar__1_1 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
  }
#line 40 "attrs.m"
}

#line 40 "attrs.m"
bool MR_CALL attrs____Unify____colour_0_0(
#line 40 "attrs.m"
  MR_Word attrs__HeadVar__1_1,
#line 40 "attrs.m"
  MR_Word attrs__HeadVar__2_2)
#line 40 "attrs.m"
{
#line 40 "attrs.m"
  {
#line 40 "attrs.m"
    bool attrs__succeeded = (attrs__HeadVar__1_1 == attrs__HeadVar__2_2);

#line 40 "attrs.m"
    return attrs__succeeded;
#line 40 "attrs.m"
  }
#line 40 "attrs.m"
}

#line 25 "attrs.m"
void MR_CALL attrs____Compare____attrs_0_0(
#line 25 "attrs.m"
  MR_Word * attrs__HeadVar__1_1,
#line 25 "attrs.m"
  MR_Word attrs__HeadVar__2_2,
#line 25 "attrs.m"
  MR_Word attrs__HeadVar__3_3)
#line 25 "attrs.m"
{
  {
    bool attrs__succeeded;
    MR_Word attrs__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word attrs__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word attrs__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word attrs__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 3)));
    MR_Word attrs__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 4)));
    MR_Integer attrs__V_9_9 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 5)));
    MR_Integer attrs__V_10_10 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 6)));
    MR_Word attrs__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 7)));
    MR_Word attrs__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__3_3, (MR_Integer) 0)));
    MR_Word attrs__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__3_3, (MR_Integer) 1)));
    MR_Word attrs__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__3_3, (MR_Integer) 2)));
    MR_Word attrs__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__3_3, (MR_Integer) 3)));
    MR_Word attrs__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__3_3, (MR_Integer) 4)));
    MR_Integer attrs__V_17_17 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__3_3, (MR_Integer) 5)));
    MR_Integer attrs__V_18_18 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__3_3, (MR_Integer) 6)));
    MR_Word attrs__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__3_3, (MR_Integer) 7)));
#line 25 "attrs.m"
    MR_Word attrs__V_20_20;
    MR_Integer attrs__V_35_35 = (MR_Integer) attrs__V_4_4;
    MR_Integer attrs__V_36_36 = (MR_Integer) attrs__V_12_12;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    attrs__succeeded = (attrs__V_35_35 < attrs__V_36_36);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (attrs__succeeded)
      {
        MR_Word attrs__V_71_71 = (MR_Integer) 1;

#line 25 "attrs.m"
        attrs__succeeded = (attrs__V_71_71 == (MR_Integer) 0);
#line 25 "attrs.m"
        attrs__succeeded = !(attrs__succeeded);
        if (attrs__succeeded)
          {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            attrs__V_20_20 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            attrs__succeeded = TRUE;
          }
      }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        attrs__succeeded = (attrs__V_35_35 == attrs__V_36_36);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (attrs__succeeded)
          {
            MR_Word attrs__V_72_72 = (MR_Integer) 0;

#line 25 "attrs.m"
            attrs__succeeded = (attrs__V_72_72 == (MR_Integer) 0);
#line 25 "attrs.m"
            attrs__succeeded = !(attrs__succeeded);
            if (attrs__succeeded)
              {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                attrs__V_20_20 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                attrs__succeeded = TRUE;
              }
          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
          {
            MR_Word attrs__V_73_73 = (MR_Integer) 2;

#line 25 "attrs.m"
            attrs__succeeded = (attrs__V_73_73 == (MR_Integer) 0);
#line 25 "attrs.m"
            attrs__succeeded = !(attrs__succeeded);
            if (attrs__succeeded)
              {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                attrs__V_20_20 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                attrs__succeeded = TRUE;
              }
          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 25 "attrs.m"
    if (attrs__succeeded)
#line 25 "attrs.m"
      *attrs__HeadVar__1_1 = attrs__V_20_20;
#line 25 "attrs.m"
    else
#line 25 "attrs.m"
      {
#line 25 "attrs.m"
        MR_Word attrs__V_21_21;
        MR_Integer attrs__V_37_37 = (MR_Integer) attrs__V_5_5;
        MR_Integer attrs__V_38_38 = (MR_Integer) attrs__V_13_13;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        attrs__succeeded = (attrs__V_37_37 < attrs__V_38_38);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (attrs__succeeded)
          {
            MR_Word attrs__V_74_74 = (MR_Integer) 1;

#line 25 "attrs.m"
            attrs__succeeded = (attrs__V_74_74 == (MR_Integer) 0);
#line 25 "attrs.m"
            attrs__succeeded = !(attrs__succeeded);
            if (attrs__succeeded)
              {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                attrs__V_21_21 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                attrs__succeeded = TRUE;
              }
          }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            attrs__succeeded = (attrs__V_37_37 == attrs__V_38_38);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (attrs__succeeded)
              {
                MR_Word attrs__V_75_75 = (MR_Integer) 0;

#line 25 "attrs.m"
                attrs__succeeded = (attrs__V_75_75 == (MR_Integer) 0);
#line 25 "attrs.m"
                attrs__succeeded = !(attrs__succeeded);
                if (attrs__succeeded)
                  {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    attrs__V_21_21 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    attrs__succeeded = TRUE;
                  }
              }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
              {
                MR_Word attrs__V_76_76 = (MR_Integer) 2;

#line 25 "attrs.m"
                attrs__succeeded = (attrs__V_76_76 == (MR_Integer) 0);
#line 25 "attrs.m"
                attrs__succeeded = !(attrs__succeeded);
                if (attrs__succeeded)
                  {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    attrs__V_21_21 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    attrs__succeeded = TRUE;
                  }
              }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 25 "attrs.m"
        if (attrs__succeeded)
#line 25 "attrs.m"
          *attrs__HeadVar__1_1 = attrs__V_21_21;
#line 25 "attrs.m"
        else
#line 25 "attrs.m"
          {
#line 25 "attrs.m"
            MR_Word attrs__V_22_22;
            MR_Integer attrs__V_39_39 = (MR_Integer) attrs__V_6_6;
            MR_Integer attrs__V_40_40 = (MR_Integer) attrs__V_14_14;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            attrs__succeeded = (attrs__V_39_39 < attrs__V_40_40);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (attrs__succeeded)
              {
                MR_Word attrs__V_77_77 = (MR_Integer) 1;

#line 25 "attrs.m"
                attrs__succeeded = (attrs__V_77_77 == (MR_Integer) 0);
#line 25 "attrs.m"
                attrs__succeeded = !(attrs__succeeded);
                if (attrs__succeeded)
                  {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    attrs__V_22_22 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    attrs__succeeded = TRUE;
                  }
              }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                attrs__succeeded = (attrs__V_39_39 == attrs__V_40_40);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (attrs__succeeded)
                  {
                    MR_Word attrs__V_78_78 = (MR_Integer) 0;

#line 25 "attrs.m"
                    attrs__succeeded = (attrs__V_78_78 == (MR_Integer) 0);
#line 25 "attrs.m"
                    attrs__succeeded = !(attrs__succeeded);
                    if (attrs__succeeded)
                      {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        attrs__V_22_22 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        attrs__succeeded = TRUE;
                      }
                  }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
                  {
                    MR_Word attrs__V_79_79 = (MR_Integer) 2;

#line 25 "attrs.m"
                    attrs__succeeded = (attrs__V_79_79 == (MR_Integer) 0);
#line 25 "attrs.m"
                    attrs__succeeded = !(attrs__succeeded);
                    if (attrs__succeeded)
                      {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        attrs__V_22_22 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        attrs__succeeded = TRUE;
                      }
                  }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              }
#line 25 "attrs.m"
            if (attrs__succeeded)
#line 25 "attrs.m"
              *attrs__HeadVar__1_1 = attrs__V_22_22;
#line 25 "attrs.m"
            else
#line 25 "attrs.m"
              {
#line 25 "attrs.m"
                MR_Word attrs__V_23_23;
                MR_Integer attrs__V_41_41 = (MR_Integer) attrs__V_7_7;
                MR_Integer attrs__V_42_42 = (MR_Integer) attrs__V_15_15;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                attrs__succeeded = (attrs__V_41_41 < attrs__V_42_42);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (attrs__succeeded)
                  {
                    MR_Word attrs__V_80_80 = (MR_Integer) 1;

#line 25 "attrs.m"
                    attrs__succeeded = (attrs__V_80_80 == (MR_Integer) 0);
#line 25 "attrs.m"
                    attrs__succeeded = !(attrs__succeeded);
                    if (attrs__succeeded)
                      {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        attrs__V_23_23 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        attrs__succeeded = TRUE;
                      }
                  }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    attrs__succeeded = (attrs__V_41_41 == attrs__V_42_42);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    if (attrs__succeeded)
                      {
                        MR_Word attrs__V_81_81 = (MR_Integer) 0;

#line 25 "attrs.m"
                        attrs__succeeded = (attrs__V_81_81 == (MR_Integer) 0);
#line 25 "attrs.m"
                        attrs__succeeded = !(attrs__succeeded);
                        if (attrs__succeeded)
                          {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            attrs__V_23_23 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            attrs__succeeded = TRUE;
                          }
                      }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    else
                      {
                        MR_Word attrs__V_82_82 = (MR_Integer) 2;

#line 25 "attrs.m"
                        attrs__succeeded = (attrs__V_82_82 == (MR_Integer) 0);
#line 25 "attrs.m"
                        attrs__succeeded = !(attrs__succeeded);
                        if (attrs__succeeded)
                          {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            attrs__V_23_23 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            attrs__succeeded = TRUE;
                          }
                      }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  }
#line 25 "attrs.m"
                if (attrs__succeeded)
#line 25 "attrs.m"
                  *attrs__HeadVar__1_1 = attrs__V_23_23;
#line 25 "attrs.m"
                else
#line 25 "attrs.m"
                  {
#line 25 "attrs.m"
                    MR_Word attrs__V_24_24;
                    MR_Integer attrs__V_43_43 = (MR_Integer) attrs__V_8_8;
                    MR_Integer attrs__V_44_44 = (MR_Integer) attrs__V_16_16;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    attrs__succeeded = (attrs__V_43_43 < attrs__V_44_44);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    if (attrs__succeeded)
                      {
                        MR_Word attrs__V_83_83 = (MR_Integer) 1;

#line 25 "attrs.m"
                        attrs__succeeded = (attrs__V_83_83 == (MR_Integer) 0);
#line 25 "attrs.m"
                        attrs__succeeded = !(attrs__succeeded);
                        if (attrs__succeeded)
                          {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            attrs__V_24_24 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            attrs__succeeded = TRUE;
                          }
                      }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        attrs__succeeded = (attrs__V_43_43 == attrs__V_44_44);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        if (attrs__succeeded)
                          {
                            MR_Word attrs__V_84_84 = (MR_Integer) 0;

#line 25 "attrs.m"
                            attrs__succeeded = (attrs__V_84_84 == (MR_Integer) 0);
#line 25 "attrs.m"
                            attrs__succeeded = !(attrs__succeeded);
                            if (attrs__succeeded)
                              {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                attrs__V_24_24 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                attrs__succeeded = TRUE;
                              }
                          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        else
                          {
                            MR_Word attrs__V_85_85 = (MR_Integer) 2;

#line 25 "attrs.m"
                            attrs__succeeded = (attrs__V_85_85 == (MR_Integer) 0);
#line 25 "attrs.m"
                            attrs__succeeded = !(attrs__succeeded);
                            if (attrs__succeeded)
                              {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                attrs__V_24_24 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                attrs__succeeded = TRUE;
                              }
                          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      }
#line 25 "attrs.m"
                    if (attrs__succeeded)
#line 25 "attrs.m"
                      *attrs__HeadVar__1_1 = attrs__V_24_24;
#line 25 "attrs.m"
                    else
#line 25 "attrs.m"
                      {
#line 25 "attrs.m"
                        MR_Word attrs__V_25_25;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        attrs__succeeded = (attrs__V_9_9 < attrs__V_17_17);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        if (attrs__succeeded)
                          {
                            MR_Word attrs__V_86_86 = (MR_Integer) 1;

#line 25 "attrs.m"
                            attrs__succeeded = (attrs__V_86_86 == (MR_Integer) 0);
#line 25 "attrs.m"
                            attrs__succeeded = !(attrs__succeeded);
                            if (attrs__succeeded)
                              {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                attrs__V_25_25 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                attrs__succeeded = TRUE;
                              }
                          }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            attrs__succeeded = (attrs__V_9_9 == attrs__V_17_17);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            if (attrs__succeeded)
                              {
                                MR_Word attrs__V_87_87 = (MR_Integer) 0;

#line 25 "attrs.m"
                                attrs__succeeded = (attrs__V_87_87 == (MR_Integer) 0);
#line 25 "attrs.m"
                                attrs__succeeded = !(attrs__succeeded);
                                if (attrs__succeeded)
                                  {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    attrs__V_25_25 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    attrs__succeeded = TRUE;
                                  }
                              }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            else
                              {
                                MR_Word attrs__V_88_88 = (MR_Integer) 2;

#line 25 "attrs.m"
                                attrs__succeeded = (attrs__V_88_88 == (MR_Integer) 0);
#line 25 "attrs.m"
                                attrs__succeeded = !(attrs__succeeded);
                                if (attrs__succeeded)
                                  {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    attrs__V_25_25 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    attrs__succeeded = TRUE;
                                  }
                              }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          }
#line 25 "attrs.m"
                        if (attrs__succeeded)
#line 25 "attrs.m"
                          *attrs__HeadVar__1_1 = attrs__V_25_25;
#line 25 "attrs.m"
                        else
#line 25 "attrs.m"
                          {
#line 25 "attrs.m"
                            MR_Word attrs__V_26_26;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            attrs__succeeded = (attrs__V_10_10 < attrs__V_18_18);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            if (attrs__succeeded)
                              {
                                MR_Word attrs__V_89_89 = (MR_Integer) 1;

#line 25 "attrs.m"
                                attrs__succeeded = (attrs__V_89_89 == (MR_Integer) 0);
#line 25 "attrs.m"
                                attrs__succeeded = !(attrs__succeeded);
                                if (attrs__succeeded)
                                  {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    attrs__V_26_26 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    attrs__succeeded = TRUE;
                                  }
                              }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                attrs__succeeded = (attrs__V_10_10 == attrs__V_18_18);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                if (attrs__succeeded)
                                  {
                                    MR_Word attrs__V_90_90 = (MR_Integer) 0;

#line 25 "attrs.m"
                                    attrs__succeeded = (attrs__V_90_90 == (MR_Integer) 0);
#line 25 "attrs.m"
                                    attrs__succeeded = !(attrs__succeeded);
                                    if (attrs__succeeded)
                                      {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        attrs__V_26_26 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        attrs__succeeded = TRUE;
                                      }
                                  }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                else
                                  {
                                    MR_Word attrs__V_91_91 = (MR_Integer) 2;

#line 25 "attrs.m"
                                    attrs__succeeded = (attrs__V_91_91 == (MR_Integer) 0);
#line 25 "attrs.m"
                                    attrs__succeeded = !(attrs__succeeded);
                                    if (attrs__succeeded)
                                      {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        attrs__V_26_26 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        attrs__succeeded = TRUE;
                                      }
                                  }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              }
#line 25 "attrs.m"
                            if (attrs__succeeded)
#line 25 "attrs.m"
                              *attrs__HeadVar__1_1 = attrs__V_26_26;
#line 25 "attrs.m"
                            else
                              {
                                MR_Integer attrs__V_45_45 = (MR_Integer) attrs__V_11_11;
                                MR_Integer attrs__V_46_46 = (MR_Integer) attrs__V_19_19;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                attrs__succeeded = (attrs__V_45_45 < attrs__V_46_46);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                if (attrs__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  *attrs__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    attrs__succeeded = (attrs__V_45_45 == attrs__V_46_46);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    if (attrs__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      *attrs__HeadVar__1_1 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      *attrs__HeadVar__1_1 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  }
                              }
#line 25 "attrs.m"
                          }
#line 25 "attrs.m"
                      }
#line 25 "attrs.m"
                  }
#line 25 "attrs.m"
              }
#line 25 "attrs.m"
          }
#line 25 "attrs.m"
      }
  }
#line 25 "attrs.m"
}

#line 25 "attrs.m"
bool MR_CALL attrs____Unify____attrs_0_0(
#line 25 "attrs.m"
  MR_Word attrs__HeadVar__1_1,
#line 25 "attrs.m"
  MR_Word attrs__HeadVar__2_2)
#line 25 "attrs.m"
{
  {
    bool attrs__succeeded;
    MR_Word attrs__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word attrs__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word attrs__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 2)));
    MR_Word attrs__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 3)));
    MR_Word attrs__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 4)));
    MR_Integer attrs__V_8_8 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 5)));
    MR_Integer attrs__V_9_9 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 6)));
    MR_Word attrs__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 7)));
    MR_Word attrs__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word attrs__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word attrs__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word attrs__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 3)));
    MR_Word attrs__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 4)));
    MR_Integer attrs__V_16_16 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 5)));
    MR_Integer attrs__V_17_17 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 6)));
    MR_Word attrs__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 7)));

    attrs__succeeded = (attrs__V_3_3 == attrs__V_11_11);
    if (attrs__succeeded)
      {
        attrs__succeeded = (attrs__V_4_4 == attrs__V_12_12);
        if (attrs__succeeded)
          {
            attrs__succeeded = (attrs__V_5_5 == attrs__V_13_13);
            if (attrs__succeeded)
              {
                attrs__succeeded = (attrs__V_6_6 == attrs__V_14_14);
                if (attrs__succeeded)
                  {
                    attrs__succeeded = (attrs__V_7_7 == attrs__V_15_15);
                    if (attrs__succeeded)
                      {
                        attrs__succeeded = (attrs__V_8_8 == attrs__V_16_16);
                        if (attrs__succeeded)
                          {
                            attrs__succeeded = (attrs__V_9_9 == attrs__V_17_17);
                            if (attrs__succeeded)
                              attrs__succeeded = (attrs__V_10_10 == attrs__V_18_18);
                          }
                      }
                  }
              }
          }
      }
    return attrs__succeeded;
  }
#line 25 "attrs.m"
}
#line 124 "attrs.m"
static /* final */ const MR_Box attrs__const_6_0_1_HeadVar__1_1[8] = {
		((MR_Box) ((MR_Integer) 0)),
		((MR_Box) ((MR_Integer) 0)),
		((MR_Box) ((MR_Integer) 0)),
		((MR_Box) ((MR_Integer) 0)),
		((MR_Box) ((MR_Integer) 0)),
		((MR_Box) ((MR_Integer) 0)),
		((MR_Box) ((MR_Integer) -1)),
		((MR_Box) ((MR_Integer) 8))};

#line 73 "attrs.m"
MR_Word MR_CALL attrs__root_attrs_1_f_0(void)
#line 73 "attrs.m"
{
  {
    bool attrs__succeeded;
    MR_Word attrs__HeadVar__1_1 = (MR_Word) &attrs__const_6_0_1_HeadVar__1_1;
    MR_Word attrs__V_2_2 = (MR_Integer) 0;
    MR_Word attrs__V_3_3 = (MR_Integer) 0;
    MR_Word attrs__V_4_4 = (MR_Integer) 0;
    MR_Word attrs__V_5_5 = (MR_Integer) 0;
    MR_Word attrs__V_6_6 = (MR_Integer) 0;
    MR_Integer attrs__V_7_7 = (MR_Integer) 0;
    MR_Integer attrs__V_8_8 = (MR_Integer) -1;
    MR_Word attrs__V_9_9 = (MR_Integer) 8;

    return attrs__HeadVar__1_1;
  }
#line 73 "attrs.m"
}

#line 69 "attrs.m"
MR_Word MR_CALL attrs__adjust_for_space_2_f_0(
#line 69 "attrs.m"
  MR_Word attrs__HeadVar__1_1)
#line 69 "attrs.m"
{
  {
    bool attrs__succeeded;
    MR_Word attrs__HeadVar__2_2;
    MR_Word attrs__V_4_4;
    MR_Word attrs__V_5_5;
    MR_Word attrs__V_7_7 = (MR_Integer) 0;
    MR_Word attrs__V_9_9 = (MR_Integer) 0;
    MR_Word attrs__V_11_11 = (MR_Integer) 0;
    MR_Word attrs__V_12_12 = (MR_Integer) 0;
    MR_Integer attrs__V_14_14;
    MR_Integer attrs__V_15_15;
    MR_Word attrs__V_16_16;
    MR_Word attrs__V_17_17;
    MR_Word attrs__V_18_18;
    MR_Word attrs__V_19_19;
    MR_Word attrs__V_20_20;
    MR_Word attrs__V_50_50 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 7)));
    MR_Integer attrs__V_51_51 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 6)));
    MR_Integer attrs__V_52_52 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 5)));
    MR_Word attrs__V_53_53 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 4)));
#line 117 "attrs.m"
    MR_Word attrs__V_46_46 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 2)));
#line 117 "attrs.m"
    MR_Word attrs__V_47_47 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 1)));
#line 117 "attrs.m"
    MR_Word attrs__V_48_48 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 0)));
#line 117 "attrs.m"
    MR_Word attrs__V_49_49 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 3)));
    MR_Integer attrs__V_13_13;
#line 120 "attrs.m"
    MR_Word attrs__V_54_54;
#line 120 "attrs.m"
    MR_Word attrs__V_55_55;
#line 120 "attrs.m"
    MR_Word attrs__V_56_56;
#line 120 "attrs.m"
    MR_Word attrs__V_57_57;
#line 120 "attrs.m"
    MR_Word attrs__V_58_58;
#line 120 "attrs.m"
    MR_Word attrs__V_59_59;
#line 120 "attrs.m"
    MR_Integer attrs__V_60_60;
#line 114 "attrs.m"
    MR_Word attrs__V_21_21;

#line 120 "attrs.m"
    {
#line 120 "attrs.m"
      attrs__V_4_4 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 8 * sizeof(MR_Word)), "attrs");
#line 120 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__V_4_4, 0) = ((MR_Box) (attrs__V_7_7));
#line 120 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__V_4_4, 1) = ((MR_Box) (attrs__V_11_11));
#line 120 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__V_4_4, 2) = ((MR_Box) (attrs__V_9_9));
#line 120 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__V_4_4, 3) = ((MR_Box) (attrs__V_12_12));
#line 120 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__V_4_4, 4) = ((MR_Box) (attrs__V_53_53));
#line 120 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__V_4_4, 5) = ((MR_Box) (attrs__V_52_52));
#line 120 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__V_4_4, 6) = ((MR_Box) (attrs__V_51_51));
#line 120 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__V_4_4, 7) = ((MR_Box) (attrs__V_50_50));
#line 120 "attrs.m"
    }
#line 120 "attrs.m"
    attrs__V_58_58 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 0)));
#line 120 "attrs.m"
    attrs__V_57_57 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 1)));
#line 120 "attrs.m"
    attrs__V_56_56 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 2)));
#line 120 "attrs.m"
    attrs__V_55_55 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 3)));
#line 120 "attrs.m"
    attrs__V_54_54 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 4)));
#line 120 "attrs.m"
    attrs__V_13_13 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 5)));
#line 120 "attrs.m"
    attrs__V_60_60 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 6)));
#line 120 "attrs.m"
    attrs__V_59_59 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 7)));
#line 120 "attrs.m"
    attrs__succeeded = (attrs__V_13_13 == (MR_Integer) 0);
#line 120 "attrs.m"
    if (attrs__succeeded)
#line 120 "attrs.m"
      attrs__V_5_5 = (MR_Integer) 7;
#line 120 "attrs.m"
    else
#line 120 "attrs.m"
      {
#line 120 "attrs.m"
        MR_Integer attrs__V_61_61 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 6)));
#line 120 "attrs.m"
        MR_Integer attrs__V_62_62 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 5)));
#line 120 "attrs.m"
        MR_Word attrs__V_63_63 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 4)));
#line 120 "attrs.m"
        MR_Word attrs__V_64_64 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 3)));
#line 120 "attrs.m"
        MR_Word attrs__V_65_65 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 2)));
#line 120 "attrs.m"
        MR_Word attrs__V_66_66 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 1)));
#line 120 "attrs.m"
        MR_Word attrs__V_67_67 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 0)));

#line 120 "attrs.m"
        attrs__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 7)));
#line 120 "attrs.m"
      }
#line 114 "attrs.m"
    attrs__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__V_4_4, (MR_Integer) 0)));
#line 114 "attrs.m"
    attrs__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__V_4_4, (MR_Integer) 1)));
#line 114 "attrs.m"
    attrs__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__V_4_4, (MR_Integer) 2)));
#line 114 "attrs.m"
    attrs__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__V_4_4, (MR_Integer) 3)));
#line 114 "attrs.m"
    attrs__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__V_4_4, (MR_Integer) 4)));
#line 114 "attrs.m"
    attrs__V_15_15 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__V_4_4, (MR_Integer) 5)));
#line 114 "attrs.m"
    attrs__V_14_14 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__V_4_4, (MR_Integer) 6)));
#line 114 "attrs.m"
    attrs__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__V_4_4, (MR_Integer) 7)));
#line 114 "attrs.m"
    {
#line 114 "attrs.m"
      attrs__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 8 * sizeof(MR_Word)), "attrs");
#line 114 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, 0) = ((MR_Box) (attrs__V_20_20));
#line 114 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, 1) = ((MR_Box) (attrs__V_19_19));
#line 114 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, 2) = ((MR_Box) (attrs__V_18_18));
#line 114 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, 3) = ((MR_Box) (attrs__V_17_17));
#line 114 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, 4) = ((MR_Box) (attrs__V_16_16));
#line 114 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, 5) = ((MR_Box) (attrs__V_15_15));
#line 114 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, 6) = ((MR_Box) (attrs__V_14_14));
#line 114 "attrs.m"
      MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, 7) = ((MR_Box) (attrs__V_5_5));
#line 114 "attrs.m"
    }
    return attrs__HeadVar__2_2;
  }
#line 69 "attrs.m"
}

#line 65 "attrs.m"
bool MR_CALL attrs__equivalent_for_space_2_p_0(
#line 65 "attrs.m"
  MR_Word attrs__HeadVar__1_1,
#line 65 "attrs.m"
  MR_Word attrs__HeadVar__2_2)
#line 65 "attrs.m"
{
  {
    bool attrs__succeeded;
    MR_Integer attrs__V_8_8;
    MR_Integer attrs__V_9_9;
    MR_Integer attrs__V_11_11;
    MR_Integer attrs__V_12_12;
    MR_Word attrs__V_14_14;
    MR_Word attrs__V_15_15;
    MR_Integer attrs__V_21_21;
    MR_Integer attrs__V_22_22;
    MR_Integer attrs__V_28_28;
    MR_Integer attrs__V_6_6;
    MR_Integer attrs__V_96_96;
    MR_Word attrs__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 7)));
    MR_Word attrs__V_83_83 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 7)));
#line 110 "attrs.m"
    MR_Integer attrs__V_65_65 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 6)));
#line 110 "attrs.m"
    MR_Integer attrs__V_66_66 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 5)));
#line 110 "attrs.m"
    MR_Word attrs__V_67_67 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 4)));
#line 110 "attrs.m"
    MR_Word attrs__V_68_68 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 3)));
#line 110 "attrs.m"
    MR_Word attrs__V_69_69 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 2)));
#line 110 "attrs.m"
    MR_Word attrs__V_70_70 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 1)));
#line 110 "attrs.m"
    MR_Word attrs__V_71_71 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 0)));
#line 110 "attrs.m"
    MR_Integer attrs__V_72_72 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 6)));
#line 110 "attrs.m"
    MR_Integer attrs__V_73_73 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 5)));
#line 110 "attrs.m"
    MR_Word attrs__V_74_74 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 4)));
#line 110 "attrs.m"
    MR_Word attrs__V_75_75 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 3)));
#line 110 "attrs.m"
    MR_Word attrs__V_76_76 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 2)));
#line 110 "attrs.m"
    MR_Word attrs__V_77_77 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 1)));
#line 110 "attrs.m"
    MR_Word attrs__V_78_78 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 0)));
#line 110 "attrs.m"
    MR_Word attrs__V_58_58;
#line 110 "attrs.m"
    MR_Word attrs__V_59_59;
#line 110 "attrs.m"
    MR_Word attrs__V_60_60;
#line 110 "attrs.m"
    MR_Word attrs__V_61_61;
#line 110 "attrs.m"
    MR_Word attrs__V_62_62;
#line 110 "attrs.m"
    MR_Word attrs__V_63_63;
#line 110 "attrs.m"
    MR_Integer attrs__V_64_64;
#line 105 "attrs.m"
    MR_Word attrs__V_16_16;
#line 105 "attrs.m"
    MR_Word attrs__V_17_17;
#line 105 "attrs.m"
    MR_Word attrs__V_18_18;
#line 105 "attrs.m"
    MR_Word attrs__V_19_19;
#line 105 "attrs.m"
    MR_Word attrs__V_20_20;
#line 106 "attrs.m"
    MR_Word attrs__V_23_23;
#line 106 "attrs.m"
    MR_Word attrs__V_24_24;
#line 106 "attrs.m"
    MR_Word attrs__V_25_25;
#line 106 "attrs.m"
    MR_Word attrs__V_26_26;
#line 106 "attrs.m"
    MR_Word attrs__V_27_27;
#line 106 "attrs.m"
    MR_Integer attrs__V_29_29;
#line 108 "attrs.m"
    MR_Word attrs__V_51_51;
#line 108 "attrs.m"
    MR_Word attrs__V_52_52;
#line 108 "attrs.m"
    MR_Word attrs__V_53_53;
#line 108 "attrs.m"
    MR_Word attrs__V_54_54;
#line 108 "attrs.m"
    MR_Word attrs__V_55_55;
#line 108 "attrs.m"
    MR_Word attrs__V_56_56;
#line 108 "attrs.m"
    MR_Integer attrs__V_57_57;

#line 110 "attrs.m"
    attrs__succeeded = (attrs__V_5_5 == attrs__V_83_83);
#line 110 "attrs.m"
    attrs__succeeded = !(attrs__succeeded);
    if (attrs__succeeded)
      {
#line 110 "attrs.m"
        attrs__V_62_62 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 0)));
#line 110 "attrs.m"
        attrs__V_61_61 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 1)));
#line 110 "attrs.m"
        attrs__V_60_60 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 2)));
#line 110 "attrs.m"
        attrs__V_59_59 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 3)));
#line 110 "attrs.m"
        attrs__V_58_58 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 4)));
#line 110 "attrs.m"
        attrs__V_6_6 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 5)));
#line 110 "attrs.m"
        attrs__V_64_64 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 6)));
#line 110 "attrs.m"
        attrs__V_63_63 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 7)));
#line 110 "attrs.m"
        attrs__V_96_96 = (MR_Integer) 0;
#line 110 "attrs.m"
        attrs__succeeded = (attrs__V_6_6 > attrs__V_96_96);
      }
#line 110 "attrs.m"
    attrs__succeeded = !(attrs__succeeded);
    if (attrs__succeeded)
      {
#line 105 "attrs.m"
        attrs__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 0)));
#line 105 "attrs.m"
        attrs__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 1)));
#line 105 "attrs.m"
        attrs__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 2)));
#line 105 "attrs.m"
        attrs__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 3)));
#line 105 "attrs.m"
        attrs__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 4)));
#line 105 "attrs.m"
        attrs__V_22_22 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 5)));
#line 105 "attrs.m"
        attrs__V_21_21 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 6)));
#line 105 "attrs.m"
        attrs__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 7)));
#line 105 "attrs.m"
        attrs__succeeded = (attrs__V_15_15 == (MR_Integer) 0);
        if (attrs__succeeded)
          {
#line 106 "attrs.m"
            attrs__V_26_26 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 0)));
#line 106 "attrs.m"
            attrs__V_25_25 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 1)));
#line 106 "attrs.m"
            attrs__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 2)));
#line 106 "attrs.m"
            attrs__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 3)));
#line 106 "attrs.m"
            attrs__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 4)));
#line 106 "attrs.m"
            attrs__V_29_29 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 5)));
#line 106 "attrs.m"
            attrs__V_28_28 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 6)));
#line 106 "attrs.m"
            attrs__V_27_27 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 7)));
#line 106 "attrs.m"
            attrs__succeeded = (attrs__V_14_14 == (MR_Integer) 0);
            if (attrs__succeeded)
              {
#line 107 "attrs.m"
                attrs__succeeded = (attrs__V_21_21 == attrs__V_28_28);
                if (attrs__succeeded)
                  {
#line 84 "attrs.m"
                    attrs__V_9_9 = (MR_Integer) 3;
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
                    attrs__succeeded = (attrs__V_9_9 < attrs__V_22_22);
#line 40 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
                    if (attrs__succeeded)
#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
                      attrs__V_8_8 = attrs__V_9_9;
#line 40 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
                    else
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
                      attrs__V_8_8 = attrs__V_22_22;
#line 84 "attrs.m"
                    attrs__V_11_11 = (MR_Integer) 3;
#line 108 "attrs.m"
                    attrs__V_55_55 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 0)));
#line 108 "attrs.m"
                    attrs__V_54_54 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 1)));
#line 108 "attrs.m"
                    attrs__V_53_53 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 2)));
#line 108 "attrs.m"
                    attrs__V_52_52 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 3)));
#line 108 "attrs.m"
                    attrs__V_51_51 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 4)));
#line 108 "attrs.m"
                    attrs__V_12_12 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 5)));
#line 108 "attrs.m"
                    attrs__V_57_57 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 6)));
#line 108 "attrs.m"
                    attrs__V_56_56 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 7)));
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
                    attrs__succeeded = (attrs__V_11_11 < attrs__V_12_12);
#line 40 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
                    if (attrs__succeeded)
#line 108 "attrs.m"
                      attrs__succeeded = (attrs__V_8_8 == attrs__V_11_11);
#line 40 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
                    else
#line 108 "attrs.m"
                      attrs__succeeded = (attrs__V_8_8 == attrs__V_12_12);
                  }
              }
          }
      }
    return attrs__succeeded;
  }
#line 65 "attrs.m"
}

#line 59 "attrs.m"
bool MR_CALL attrs__equivalent_2_p_0(
#line 59 "attrs.m"
  MR_Word attrs__HeadVar__1_1,
#line 59 "attrs.m"
  MR_Word attrs__HeadVar__2_2)
#line 59 "attrs.m"
{
  {
    bool attrs__succeeded;
    MR_Word attrs__V_5_5;
    MR_Integer attrs__V_6_6;
    MR_Integer attrs__V_7_7;
    MR_Integer attrs__V_8_8;
    MR_Integer attrs__V_9_9;
    MR_Integer attrs__V_10_10;
    MR_Word attrs__V_12_12;
    MR_Word attrs__V_17_17;
    MR_Word attrs__V_18_18;
    MR_Integer attrs__V_19_19;
    MR_Integer attrs__V_20_20;
    MR_Word attrs__V_21_21;
    MR_Word attrs__V_22_22;
    MR_Word attrs__V_23_23;
    MR_Word attrs__V_24_24;
    MR_Word attrs__V_25_25;
    MR_Integer attrs__V_26_26;
    MR_Integer attrs__V_27_27;
    MR_Word attrs__V_28_28;
    MR_Word attrs__V_29_29;
    MR_Word attrs__V_30_30;
    MR_Word attrs__V_31_31;
    MR_Word attrs__V_81_81;
    MR_Word attrs__V_82_82;
    MR_Word attrs__V_83_83;
    MR_Word attrs__V_84_84;
    MR_Word attrs__V_85_85;
    MR_Integer attrs__V_86_86;
    MR_Integer attrs__V_87_87;
    MR_Word attrs__V_88_88;
    MR_Word attrs__V_89_89;
    MR_Word attrs__V_90_90;
    MR_Word attrs__V_91_91;
    MR_Word attrs__V_92_92;
    MR_Integer attrs__V_93_93;
    MR_Integer attrs__V_94_94;
    MR_Word attrs__V_137_137;
    MR_Word attrs__V_141_141;
    MR_Integer attrs__V_145_145;
    MR_Word attrs__V_146_146;
    MR_Word attrs__V_14_14;
    MR_Word attrs__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word attrs__V_140_140 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 1)));
#line 94 "attrs.m"
    MR_Word attrs__V_67_67 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 0)));
#line 94 "attrs.m"
    MR_Word attrs__V_68_68 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 7)));
#line 94 "attrs.m"
    MR_Integer attrs__V_69_69 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 6)));
#line 94 "attrs.m"
    MR_Integer attrs__V_70_70 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 5)));
#line 94 "attrs.m"
    MR_Word attrs__V_71_71 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 4)));
#line 94 "attrs.m"
    MR_Word attrs__V_72_72 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 3)));
#line 94 "attrs.m"
    MR_Word attrs__V_73_73 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 2)));
#line 94 "attrs.m"
    MR_Word attrs__V_74_74 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 0)));
#line 94 "attrs.m"
    MR_Word attrs__V_75_75 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 7)));
#line 94 "attrs.m"
    MR_Integer attrs__V_76_76 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 6)));
#line 94 "attrs.m"
    MR_Integer attrs__V_77_77 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 5)));
#line 94 "attrs.m"
    MR_Word attrs__V_78_78 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 4)));
#line 94 "attrs.m"
    MR_Word attrs__V_79_79 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 3)));
#line 94 "attrs.m"
    MR_Word attrs__V_80_80 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 2)));
#line 94 "attrs.m"
    MR_Word attrs__V_60_60;
#line 94 "attrs.m"
    MR_Word attrs__V_61_61;
#line 94 "attrs.m"
    MR_Word attrs__V_62_62;
#line 94 "attrs.m"
    MR_Word attrs__V_63_63;
#line 94 "attrs.m"
    MR_Integer attrs__V_64_64;
#line 94 "attrs.m"
    MR_Integer attrs__V_65_65;
#line 94 "attrs.m"
    MR_Word attrs__V_66_66;
#line 97 "attrs.m"
    MR_Word attrs__V_109_109;
#line 97 "attrs.m"
    MR_Word attrs__V_110_110;
#line 97 "attrs.m"
    MR_Word attrs__V_111_111;
#line 97 "attrs.m"
    MR_Word attrs__V_112_112;
#line 97 "attrs.m"
    MR_Word attrs__V_113_113;
#line 97 "attrs.m"
    MR_Word attrs__V_114_114;
#line 97 "attrs.m"
    MR_Integer attrs__V_115_115;
#line 97 "attrs.m"
    MR_Word attrs__V_116_116;
#line 97 "attrs.m"
    MR_Word attrs__V_117_117;
#line 97 "attrs.m"
    MR_Word attrs__V_118_118;
#line 97 "attrs.m"
    MR_Word attrs__V_119_119;
#line 97 "attrs.m"
    MR_Word attrs__V_120_120;
#line 97 "attrs.m"
    MR_Word attrs__V_121_121;
#line 97 "attrs.m"
    MR_Integer attrs__V_122_122;
#line 98 "attrs.m"
    MR_Integer attrs__V_123_123;
#line 98 "attrs.m"
    MR_Integer attrs__V_124_124;
#line 98 "attrs.m"
    MR_Word attrs__V_125_125;
#line 98 "attrs.m"
    MR_Word attrs__V_126_126;
#line 98 "attrs.m"
    MR_Word attrs__V_127_127;
#line 98 "attrs.m"
    MR_Word attrs__V_128_128;
#line 98 "attrs.m"
    MR_Word attrs__V_129_129;
#line 98 "attrs.m"
    MR_Integer attrs__V_130_130;
#line 98 "attrs.m"
    MR_Integer attrs__V_131_131;
#line 98 "attrs.m"
    MR_Word attrs__V_132_132;
#line 98 "attrs.m"
    MR_Word attrs__V_133_133;
#line 98 "attrs.m"
    MR_Word attrs__V_134_134;
#line 98 "attrs.m"
    MR_Word attrs__V_135_135;
#line 98 "attrs.m"
    MR_Word attrs__V_136_136;

#line 94 "attrs.m"
    attrs__succeeded = (attrs__V_13_13 == attrs__V_140_140);
#line 94 "attrs.m"
    attrs__succeeded = !(attrs__succeeded);
    if (attrs__succeeded)
      {
#line 94 "attrs.m"
        attrs__V_62_62 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 0)));
#line 94 "attrs.m"
        attrs__V_61_61 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 1)));
#line 94 "attrs.m"
        attrs__V_60_60 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 2)));
#line 94 "attrs.m"
        attrs__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 3)));
#line 94 "attrs.m"
        attrs__V_66_66 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 4)));
#line 94 "attrs.m"
        attrs__V_65_65 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 5)));
#line 94 "attrs.m"
        attrs__V_64_64 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 6)));
#line 94 "attrs.m"
        attrs__V_63_63 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 7)));
#line 94 "attrs.m"
        attrs__succeeded = (attrs__V_14_14 == (MR_Integer) 0);
      }
#line 94 "attrs.m"
    attrs__succeeded = !(attrs__succeeded);
    if (attrs__succeeded)
      {
#line 91 "attrs.m"
        attrs__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 0)));
#line 91 "attrs.m"
        attrs__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 1)));
#line 91 "attrs.m"
        attrs__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 2)));
#line 91 "attrs.m"
        attrs__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 3)));
#line 91 "attrs.m"
        attrs__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 4)));
#line 91 "attrs.m"
        attrs__V_20_20 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 5)));
#line 91 "attrs.m"
        attrs__V_19_19 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 6)));
#line 91 "attrs.m"
        attrs__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 7)));
#line 91 "attrs.m"
        attrs__V_137_137 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 0)));
#line 91 "attrs.m"
        attrs__V_31_31 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 1)));
#line 91 "attrs.m"
        attrs__V_30_30 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 2)));
#line 91 "attrs.m"
        attrs__V_29_29 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 3)));
#line 91 "attrs.m"
        attrs__V_28_28 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 4)));
#line 91 "attrs.m"
        attrs__V_27_27 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 5)));
#line 91 "attrs.m"
        attrs__V_26_26 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 6)));
#line 91 "attrs.m"
        attrs__V_25_25 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 7)));
#line 91 "attrs.m"
        attrs__succeeded = (attrs__V_17_17 == attrs__V_137_137);
        if (attrs__succeeded)
          {
#line 92 "attrs.m"
            attrs__succeeded = (attrs__V_23_23 == attrs__V_30_30);
            if (attrs__succeeded)
              {
#line 93 "attrs.m"
                attrs__succeeded = (attrs__V_22_22 == attrs__V_29_29);
                if (attrs__succeeded)
                  {
                    attrs__V_84_84 = attrs__V_17_17;
                    attrs__V_83_83 = attrs__V_24_24;
                    attrs__V_82_82 = attrs__V_23_23;
                    attrs__V_81_81 = attrs__V_22_22;
                    attrs__V_12_12 = attrs__V_21_21;
                    attrs__V_87_87 = attrs__V_20_20;
                    attrs__V_86_86 = attrs__V_19_19;
                    attrs__V_85_85 = attrs__V_18_18;
                    attrs__V_91_91 = attrs__V_137_137;
                    attrs__V_90_90 = attrs__V_31_31;
                    attrs__V_89_89 = attrs__V_30_30;
                    attrs__V_88_88 = attrs__V_29_29;
                    attrs__V_141_141 = attrs__V_28_28;
                    attrs__V_94_94 = attrs__V_27_27;
                    attrs__V_93_93 = attrs__V_26_26;
                    attrs__V_92_92 = attrs__V_25_25;
#line 95 "attrs.m"
                    attrs__succeeded = (attrs__V_12_12 == attrs__V_141_141);
                    if (attrs__succeeded)
                      {
#line 96 "attrs.m"
                        attrs__succeeded = (attrs__V_86_86 == attrs__V_93_93);
                        if (attrs__succeeded)
                          {
#line 97 "attrs.m"
                            {
#line 97 "attrs.m"
                              attrs__V_7_7 = attrs__max_u_1_f_0();
                            }
#line 97 "attrs.m"
                            attrs__V_113_113 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 0)));
#line 97 "attrs.m"
                            attrs__V_112_112 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 1)));
#line 97 "attrs.m"
                            attrs__V_111_111 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 2)));
#line 97 "attrs.m"
                            attrs__V_110_110 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 3)));
#line 97 "attrs.m"
                            attrs__V_109_109 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 4)));
#line 97 "attrs.m"
                            attrs__V_8_8 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 5)));
#line 97 "attrs.m"
                            attrs__V_115_115 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 6)));
#line 97 "attrs.m"
                            attrs__V_114_114 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 7)));
#line 97 "attrs.m"
                            {
#line 97 "attrs.m"
                              attrs__V_6_6 = mercury__int__min_3_f_0(attrs__V_7_7, attrs__V_8_8);
                            }
#line 97 "attrs.m"
                            {
#line 97 "attrs.m"
                              attrs__V_9_9 = attrs__max_u_1_f_0();
                            }
#line 97 "attrs.m"
                            attrs__V_120_120 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 0)));
#line 97 "attrs.m"
                            attrs__V_119_119 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 1)));
#line 97 "attrs.m"
                            attrs__V_118_118 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 2)));
#line 97 "attrs.m"
                            attrs__V_117_117 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 3)));
#line 97 "attrs.m"
                            attrs__V_116_116 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 4)));
#line 97 "attrs.m"
                            attrs__V_10_10 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 5)));
#line 97 "attrs.m"
                            attrs__V_122_122 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 6)));
#line 97 "attrs.m"
                            attrs__V_121_121 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 7)));
#line 97 "attrs.m"
                            {
#line 97 "attrs.m"
                              attrs__V_145_145 = mercury__int__min_3_f_0(attrs__V_9_9, attrs__V_10_10);
                            }
#line 97 "attrs.m"
                            attrs__succeeded = (attrs__V_6_6 == attrs__V_145_145);
                            if (attrs__succeeded)
                              {
#line 98 "attrs.m"
                                attrs__V_129_129 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 0)));
#line 98 "attrs.m"
                                attrs__V_128_128 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 1)));
#line 98 "attrs.m"
                                attrs__V_127_127 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 2)));
#line 98 "attrs.m"
                                attrs__V_126_126 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 3)));
#line 98 "attrs.m"
                                attrs__V_125_125 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 4)));
#line 98 "attrs.m"
                                attrs__V_124_124 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 5)));
#line 98 "attrs.m"
                                attrs__V_123_123 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 6)));
#line 98 "attrs.m"
                                attrs__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__1_1, (MR_Integer) 7)));
#line 98 "attrs.m"
                                attrs__V_136_136 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 0)));
#line 98 "attrs.m"
                                attrs__V_135_135 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 1)));
#line 98 "attrs.m"
                                attrs__V_134_134 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 2)));
#line 98 "attrs.m"
                                attrs__V_133_133 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 3)));
#line 98 "attrs.m"
                                attrs__V_132_132 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 4)));
#line 98 "attrs.m"
                                attrs__V_131_131 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 5)));
#line 98 "attrs.m"
                                attrs__V_130_130 = ((MR_Integer) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 6)));
#line 98 "attrs.m"
                                attrs__V_146_146 = ((MR_Word) (MR_hl_field(MR_mktag(0), attrs__HeadVar__2_2, (MR_Integer) 7)));
#line 98 "attrs.m"
                                attrs__succeeded = (attrs__V_5_5 == attrs__V_146_146);
                              }
                          }
                      }
                  }
              }
          }
      }
    return attrs__succeeded;
  }
#line 59 "attrs.m"
}

#line 53 "attrs.m"
MR_Integer MR_CALL attrs__max_size_1_f_0(void)
#line 53 "attrs.m"
{
#line 86 "attrs.m"
  {
#line 86 "attrs.m"
    bool attrs__succeeded;
#line 86 "attrs.m"
    MR_Integer attrs__HeadVar__1_1 = (MR_Integer) 9;

#line 86 "attrs.m"
    return attrs__HeadVar__1_1;
#line 86 "attrs.m"
  }
#line 53 "attrs.m"
}

#line 49 "attrs.m"
MR_Integer MR_CALL attrs__max_u_1_f_0(void)
#line 49 "attrs.m"
{
#line 84 "attrs.m"
  {
#line 84 "attrs.m"
    bool attrs__succeeded;
#line 84 "attrs.m"
    MR_Integer attrs__HeadVar__1_1 = (MR_Integer) 3;

#line 84 "attrs.m"
    return attrs__HeadVar__1_1;
#line 84 "attrs.m"
  }
#line 49 "attrs.m"
}

#line 45 "attrs.m"
MR_Integer MR_CALL attrs__root_size_1_f_0(void)
#line 45 "attrs.m"
{
#line 82 "attrs.m"
  {
#line 82 "attrs.m"
    bool attrs__succeeded;
#line 82 "attrs.m"
    MR_Integer attrs__HeadVar__1_1 = (MR_Integer) -1;

#line 82 "attrs.m"
    return attrs__HeadVar__1_1;
#line 82 "attrs.m"
  }
#line 45 "attrs.m"
}

void mercury__attrs__init(void)
{
}

void mercury__attrs__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&attrs__attrs__type_ctor_info_colour_0);
	MR_register_type_ctor_info(&attrs__attrs__type_ctor_info_attrs_0);
}

void mercury__attrs__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module attrs. */
