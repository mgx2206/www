/*
** Automatically generated from `smlngopt.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module smlngopt. */
/* :- implementation. */

#include "smlngopt.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "attrs.h"
#include "mercury.benchmarking.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "input.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "mercury.ops.h"
#include "optimize.h"
#include "mercury.parser.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "mercury.tree234.h"
#include "mercury.varset.h"







#line 17 "smlngopt.m"
void MR_CALL main_2_p_0(void)
#line 17 "smlngopt.m"
{
  {
    bool smlngopt__succeeded;
    MR_Word smlngopt__ArgV_3;
#line 33 "smlngopt.m"
    MR_String smlngopt__BaseName_4;
    MR_Word smlngopt__V_14_14;

#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL main_2_p_0
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Args;
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	/* convert mercury_argv from a vector to a list */
	{ int i = mercury_argc;
	  Args = MR_list_empty_msg(MR_PROC_LABEL);
	  while (--i >= 0) {
		Args = MR_list_cons_msg((MR_Word) mercury_argv[i], Args,
			MR_PROC_LABEL);
	  }
	}
	update_io(IO0, IO);

#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
smlngopt__ArgV_3
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Args;
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 33 "smlngopt.m"
    smlngopt__succeeded = (MR_tag((MR_Word) smlngopt__ArgV_3) == MR_mktag((MR_Integer) 1));
#line 33 "smlngopt.m"
    if ((MR_tag((MR_Word) smlngopt__ArgV_3) == MR_mktag((MR_Integer) 1)))
#line 33 "smlngopt.m"
      {
#line 33 "smlngopt.m"
        smlngopt__BaseName_4 = ((MR_String) (MR_hl_field(MR_mktag(1), smlngopt__ArgV_3, (MR_Integer) 0)));
#line 33 "smlngopt.m"
        smlngopt__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(1), smlngopt__ArgV_3, (MR_Integer) 1)));
#line 33 "smlngopt.m"
      }
    if (smlngopt__succeeded)
#line 33 "smlngopt.m"
      smlngopt__succeeded = (smlngopt__V_14_14 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 33 "smlngopt.m"
    if (smlngopt__succeeded)
      {
        MR_String smlngopt__FirstSMLNG_5;
        MR_String smlngopt__FirstDone_6;
        MR_String smlngopt__Str_7;
        MR_Array smlngopt__Attrss_8;
        MR_Array smlngopt__Extents_9;
        MR_Integer smlngopt__V_15_15;
        MR_Integer smlngopt__V_16_16 = (MR_Integer) 0;

#line 35 "smlngopt.m"
        {
#line 35 "smlngopt.m"
          input__file_names_4_p_0(smlngopt__BaseName_4, smlngopt__V_16_16, &smlngopt__FirstSMLNG_5, &smlngopt__FirstDone_6);
        }
#line 36 "smlngopt.m"
        {
#line 36 "smlngopt.m"
          input__read_smlng_7_p_0(smlngopt__FirstSMLNG_5, smlngopt__FirstDone_6, &smlngopt__Str_7, &smlngopt__Attrss_8, &smlngopt__Extents_9);
        }
#line 37 "smlngopt.m"
        smlngopt__V_15_15 = (MR_Integer) 6;
#line 37 "smlngopt.m"
        {
#line 37 "smlngopt.m"
          optimize__write_optimized_files_7_p_0(smlngopt__BaseName_4, smlngopt__Str_7, smlngopt__Attrss_8, smlngopt__Extents_9, smlngopt__V_15_15);
#line 37 "smlngopt.m"
          return;
        }
      }
#line 33 "smlngopt.m"
    else
      {
        MR_String smlngopt__V_17_17 = (MR_String) "usage: smlngopt <BaseName>";
        MR_Word smlngopt__TypeInfo_18_18 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 41 "smlngopt.m"
        {
#line 41 "smlngopt.m"
          mercury__exception__throw_1_p_0(smlngopt__TypeInfo_18_18, ((MR_Box) (smlngopt__V_17_17)));
#line 41 "smlngopt.m"
          return;
        }
      }
  }
#line 17 "smlngopt.m"
}

void mercury__smlngopt__init(void)
{
}

void mercury__smlngopt__init_type_tables(void)
{
}

void mercury__smlngopt__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module smlngopt. */
