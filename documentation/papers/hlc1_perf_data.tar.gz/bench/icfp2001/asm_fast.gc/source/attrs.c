/*
** Automatically generated from `attrs.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__attrs__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "attrs.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "attrs.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 39 "attrs.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 42 "attrs.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 48 "attrs.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 56 "attrs.c"


static const struct mercury_data_attrs__common_0_struct {
	MR_Integer f1;
	MR_Integer f2;
	MR_Integer f3;
	MR_Integer f4;
	MR_Integer f5;
	MR_Integer f6;
	MR_Integer f7;
	MR_Integer f8;
}  mercury_data_attrs__common_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_attrs__type_ctor_info_colour_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_attrs__type_ctor_info_attrs_0;
extern const MR_EnumFunctorDesc * mercury_data_attrs__enum_name_ordered_colour_0[];
extern const MR_EnumFunctorDesc * mercury_data_attrs__enum_value_ordered_colour_0[];
static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_0;
static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_1;
static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_2;
static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_3;
static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_4;
static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_5;
static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_6;
static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_7;
static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_8;
extern const MR_DuFunctorDesc * mercury_data_attrs__du_name_ordered_attrs_0[];
static const MR_DuFunctorDesc mercury_data_attrs__du_functor_desc_attrs_0_0;
extern const MR_ConstString mercury_data_attrs__field_names_attrs_0_0[];
extern const MR_PseudoTypeInfo mercury_data_attrs__field_types_attrs_0_0[];
extern const MR_DuPtagLayout mercury_data_attrs__du_ptag_ordered_attrs_0[];
extern const MR_DuFunctorDesc * mercury_data_attrs__du_stag_ordered_attrs_0_0[];
MR_define_extern_entry(mercury__fn__attrs__root_size_0_0);
MR_define_extern_entry(mercury__fn__attrs__max_u_0_0);
MR_define_extern_entry(mercury__fn__attrs__max_size_0_0);
MR_define_extern_entry(mercury__attrs__equivalent_2_0);
MR_declare_label(mercury__attrs__equivalent_2_0_i11);
MR_declare_label(mercury__attrs__equivalent_2_0_i3);
MR_declare_label(mercury__attrs__equivalent_2_0_i6);
MR_declare_label(mercury__attrs__equivalent_2_0_i7);
MR_declare_label(mercury__attrs__equivalent_2_0_i8);
MR_declare_label(mercury__attrs__equivalent_2_0_i9);
MR_define_extern_entry(mercury__attrs__equivalent_for_space_2_0);
MR_declare_label(mercury__attrs__equivalent_for_space_2_0_i12);
MR_declare_label(mercury__attrs__equivalent_for_space_2_0_i3);
MR_declare_label(mercury__attrs__equivalent_for_space_2_0_i7);
MR_declare_label(mercury__attrs__equivalent_for_space_2_0_i9);
MR_define_extern_entry(mercury__fn__attrs__adjust_for_space_1_0);
MR_declare_label(mercury__fn__attrs__adjust_for_space_1_0_i2);
MR_define_extern_entry(mercury__fn__attrs__root_attrs_0_0);
MR_define_extern_entry(mercury____Unify___attrs__attrs_0_0);
MR_declare_label(mercury____Unify___attrs__attrs_0_0_i1);
MR_define_extern_entry(mercury____Compare___attrs__attrs_0_0);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i4);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i3);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i16);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i15);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i28);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i27);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i40);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i39);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i52);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i51);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i64);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i63);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i76);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i124);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i75);
MR_declare_label(mercury____Compare___attrs__attrs_0_0_i86);
MR_define_extern_entry(mercury____Unify___attrs__colour_0_0);
MR_define_extern_entry(mercury____Compare___attrs__colour_0_0);
MR_declare_label(mercury____Compare___attrs__colour_0_0_i2);
MR_declare_label(mercury____Compare___attrs__colour_0_0_i3);

static const struct mercury_data_attrs__common_0_struct mercury_data_attrs__common_0 = {
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) -1,
	(MR_Integer) 8
};
extern const MR_EnumFunctorDesc * mercury_data_attrs__enum_name_ordered_colour_0[];
extern const MR_EnumFunctorDesc * mercury_data_attrs__enum_value_ordered_colour_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_attrs__type_ctor_info_colour_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___attrs__colour_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___attrs__colour_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___attrs__colour_0_0)),
	MR_TYPECTOR_REP_ENUM,
	NULL,
	NULL,
	"attrs",
	"colour",
	4,
	{ (void *) mercury_data_attrs__enum_name_ordered_colour_0 },
	{ (void *) mercury_data_attrs__enum_value_ordered_colour_0 },
	9,
	-1
};
extern const MR_DuFunctorDesc * mercury_data_attrs__du_name_ordered_attrs_0[];
extern const MR_DuPtagLayout mercury_data_attrs__du_ptag_ordered_attrs_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_attrs__type_ctor_info_attrs_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___attrs__attrs_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___attrs__attrs_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___attrs__attrs_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"attrs",
	"attrs",
	4,
	{ (void *) mercury_data_attrs__du_name_ordered_attrs_0 },
	{ (void *) mercury_data_attrs__du_ptag_ordered_attrs_0 },
	1,
	1
};

const MR_EnumFunctorDesc * mercury_data_attrs__enum_name_ordered_colour_0[] = {
	&mercury_data_attrs__enum_functor_desc_colour_0_2,
	&mercury_data_attrs__enum_functor_desc_colour_0_3,
	&mercury_data_attrs__enum_functor_desc_colour_0_1,
	&mercury_data_attrs__enum_functor_desc_colour_0_6,
	&mercury_data_attrs__enum_functor_desc_colour_0_4,
	&mercury_data_attrs__enum_functor_desc_colour_0_0,
	&mercury_data_attrs__enum_functor_desc_colour_0_8,
	&mercury_data_attrs__enum_functor_desc_colour_0_7,
	&mercury_data_attrs__enum_functor_desc_colour_0_5
};

const MR_EnumFunctorDesc * mercury_data_attrs__enum_value_ordered_colour_0[] = {
	&mercury_data_attrs__enum_functor_desc_colour_0_0,
	&mercury_data_attrs__enum_functor_desc_colour_0_1,
	&mercury_data_attrs__enum_functor_desc_colour_0_2,
	&mercury_data_attrs__enum_functor_desc_colour_0_3,
	&mercury_data_attrs__enum_functor_desc_colour_0_4,
	&mercury_data_attrs__enum_functor_desc_colour_0_5,
	&mercury_data_attrs__enum_functor_desc_colour_0_6,
	&mercury_data_attrs__enum_functor_desc_colour_0_7,
	&mercury_data_attrs__enum_functor_desc_colour_0_8
};

static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_0 = {
	"r",
	0
};

static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_1 = {
	"g",
	1
};

static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_2 = {
	"b",
	2
};

static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_3 = {
	"c",
	3
};

static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_4 = {
	"m",
	4
};

static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_5 = {
	"y",
	5
};

static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_6 = {
	"k",
	6
};

static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_7 = {
	"w",
	7
};

static const MR_EnumFunctorDesc mercury_data_attrs__enum_functor_desc_colour_0_8 = {
	"root_colour",
	8
};

const MR_DuFunctorDesc * mercury_data_attrs__du_name_ordered_attrs_0[] = {
	&mercury_data_attrs__du_functor_desc_attrs_0_0
};

static const MR_DuFunctorDesc mercury_data_attrs__du_functor_desc_attrs_0_0 = {
	"attrs",
	8,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_attrs__field_types_attrs_0_0,
	mercury_data_attrs__field_names_attrs_0_0,
	NULL
};

const MR_ConstString mercury_data_attrs__field_names_attrs_0_0[] = {
	"b",
	"em",
	"i",
	"s",
	"tt",
	"u",
	"size",
	"colour"
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_bool__type_ctor_info_bool_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_attrs__type_ctor_info_colour_0;

const MR_PseudoTypeInfo mercury_data_attrs__field_types_attrs_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_bool__type_ctor_info_bool_0,
	(MR_PseudoTypeInfo) &mercury_data_bool__type_ctor_info_bool_0,
	(MR_PseudoTypeInfo) &mercury_data_bool__type_ctor_info_bool_0,
	(MR_PseudoTypeInfo) &mercury_data_bool__type_ctor_info_bool_0,
	(MR_PseudoTypeInfo) &mercury_data_bool__type_ctor_info_bool_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_attrs__type_ctor_info_colour_0
};

const MR_DuPtagLayout mercury_data_attrs__du_ptag_ordered_attrs_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_attrs__du_stag_ordered_attrs_0_0 }

};

const MR_DuFunctorDesc * mercury_data_attrs__du_stag_ordered_attrs_0_0[] = {
	&mercury_data_attrs__du_functor_desc_attrs_0_0

};

MR_declare_entry(mercury__fn__int__min_2_0);

MR_BEGIN_MODULE(attrs_module)
	MR_init_entry(mercury__fn__attrs__root_size_0_0);
	MR_init_entry(mercury__fn__attrs__max_u_0_0);
	MR_init_entry(mercury__fn__attrs__max_size_0_0);
	MR_init_entry(mercury__attrs__equivalent_2_0);
	MR_init_label(mercury__attrs__equivalent_2_0_i11);
	MR_init_label(mercury__attrs__equivalent_2_0_i3);
	MR_init_label(mercury__attrs__equivalent_2_0_i6);
	MR_init_label(mercury__attrs__equivalent_2_0_i7);
	MR_init_label(mercury__attrs__equivalent_2_0_i8);
	MR_init_label(mercury__attrs__equivalent_2_0_i9);
	MR_init_entry(mercury__attrs__equivalent_for_space_2_0);
	MR_init_label(mercury__attrs__equivalent_for_space_2_0_i12);
	MR_init_label(mercury__attrs__equivalent_for_space_2_0_i3);
	MR_init_label(mercury__attrs__equivalent_for_space_2_0_i7);
	MR_init_label(mercury__attrs__equivalent_for_space_2_0_i9);
	MR_init_entry(mercury__fn__attrs__adjust_for_space_1_0);
	MR_init_label(mercury__fn__attrs__adjust_for_space_1_0_i2);
	MR_init_entry(mercury__fn__attrs__root_attrs_0_0);
	MR_init_entry(mercury____Unify___attrs__attrs_0_0);
	MR_init_label(mercury____Unify___attrs__attrs_0_0_i1);
	MR_init_entry(mercury____Compare___attrs__attrs_0_0);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i4);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i3);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i16);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i15);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i28);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i27);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i40);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i39);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i52);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i51);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i64);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i63);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i76);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i124);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i75);
	MR_init_label(mercury____Compare___attrs__attrs_0_0_i86);
	MR_init_entry(mercury____Unify___attrs__colour_0_0);
	MR_init_entry(mercury____Compare___attrs__colour_0_0);
	MR_init_label(mercury____Compare___attrs__colour_0_0_i2);
	MR_init_label(mercury____Compare___attrs__colour_0_0_i3);
MR_BEGIN_CODE

/* code for predicate 'root_size'/1 in mode 0 */
MR_define_entry(mercury__fn__attrs__root_size_0_0);
	MR_r1 = (MR_Integer) -1;
	MR_proceed();
/* code for predicate 'max_u'/1 in mode 0 */
MR_define_entry(mercury__fn__attrs__max_u_0_0);
	MR_r1 = (MR_Integer) 3;
	MR_proceed();
/* code for predicate 'max_size'/1 in mode 0 */
MR_define_entry(mercury__fn__attrs__max_size_0_0);
	MR_r1 = (MR_Integer) 9;
	MR_proceed();
/* code for predicate 'equivalent'/2 in mode 0 */
MR_define_entry(mercury__attrs__equivalent_2_0);
	MR_incr_sp_push_msg(4, "attrs:equivalent/2");
	MR_stackvar(4) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	if ((MR_tempr1 == MR_tempr2)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_2_0_i3);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_2_0_i3);
	}
	}
MR_define_label(mercury__attrs__equivalent_2_0_i11);
	MR_r1 = FALSE;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__attrs__equivalent_2_0_i3);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_2_0_i11);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_2_0_i11);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_2_0_i11);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_2_0_i11);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 6);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 6);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_2_0_i11);
	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	}
	MR_localcall(mercury__fn__attrs__max_u_0_0,
		MR_LABEL(mercury__attrs__equivalent_2_0_i6),
		MR_ENTRY(mercury__attrs__equivalent_2_0));
MR_define_label(mercury__attrs__equivalent_2_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__attrs__equivalent_2_0));
	MR_r2 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 5);
	MR_call_localret(MR_ENTRY(mercury__fn__int__min_2_0),
		mercury__attrs__equivalent_2_0_i7,
		MR_ENTRY(mercury__attrs__equivalent_2_0));
MR_define_label(mercury__attrs__equivalent_2_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__attrs__equivalent_2_0));
	MR_stackvar(3) = MR_r1;
	MR_localcall(mercury__fn__attrs__max_u_0_0,
		MR_LABEL(mercury__attrs__equivalent_2_0_i8),
		MR_ENTRY(mercury__attrs__equivalent_2_0));
MR_define_label(mercury__attrs__equivalent_2_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__attrs__equivalent_2_0));
	MR_r2 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 5);
	MR_call_localret(MR_ENTRY(mercury__fn__int__min_2_0),
		mercury__attrs__equivalent_2_0_i9,
		MR_ENTRY(mercury__attrs__equivalent_2_0));
MR_define_label(mercury__attrs__equivalent_2_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__attrs__equivalent_2_0));
	if ((MR_stackvar(3) != MR_r1)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_2_0_i11);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 7);
	MR_r2 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 7);
	MR_r1 = (MR_r1 == MR_r2);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate 'equivalent_for_space'/2 in mode 0 */
MR_define_entry(mercury__attrs__equivalent_for_space_2_0);
	MR_incr_sp_push_msg(2, "attrs:equivalent_for_space/2");
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 7);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 7);
	if ((MR_tempr1 == MR_tempr2)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_for_space_2_0_i3);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 5);
	if (((MR_Integer) MR_tempr1 <= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_for_space_2_0_i3);
	}
	}
MR_define_label(mercury__attrs__equivalent_for_space_2_0_i12);
	MR_decr_sp_pop_msg(2);
	MR_r1 = FALSE;
	MR_proceed();
MR_define_label(mercury__attrs__equivalent_for_space_2_0_i3);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_for_space_2_0_i12);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_for_space_2_0_i12);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 6);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 6);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_for_space_2_0_i12);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 5);
	if (((MR_Integer) 3 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_for_space_2_0_i7);
	}
	MR_r1 = (MR_Integer) 3;
	MR_stackvar(2) = MR_r2;
	MR_r2 = (MR_Integer) 3;
	MR_r3 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 5);
	if (((MR_Integer) MR_r2 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_for_space_2_0_i9);
	}
	MR_r1 = (MR_r1 == MR_r2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
	}
MR_define_label(mercury__attrs__equivalent_for_space_2_0_i7);
	MR_r1 = MR_r3;
	MR_stackvar(2) = MR_r2;
	MR_r2 = (MR_Integer) 3;
	MR_r3 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 5);
	if (((MR_Integer) MR_r2 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury__attrs__equivalent_for_space_2_0_i9);
	}
	MR_r1 = (MR_r1 == MR_r2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
MR_define_label(mercury__attrs__equivalent_for_space_2_0_i9);
	MR_r1 = (MR_r1 == MR_r3);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate 'adjust_for_space'/2 in mode 0 */
MR_define_entry(mercury__fn__attrs__adjust_for_space_1_0);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 8, mercury__fn__attrs__adjust_for_space_1_0, "attrs:attrs/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = (MR_Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = (MR_Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3) = (MR_Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 7);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 5);
	if (((MR_Integer) MR_tempr2 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__attrs__adjust_for_space_1_0_i2);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 8, mercury__fn__attrs__adjust_for_space_1_0, "attrs:attrs/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 5) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 6) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 7) = (MR_Integer) 7;
	MR_proceed();
	}
MR_define_label(mercury__fn__attrs__adjust_for_space_1_0_i2);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 8, mercury__fn__attrs__adjust_for_space_1_0, "attrs:attrs/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 7);
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'root_attrs'/1 in mode 0 */
MR_define_entry(mercury__fn__attrs__root_attrs_0_0);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_attrs__common_0);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___attrs__attrs_0_0);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury____Unify___attrs__attrs_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury____Unify___attrs__attrs_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury____Unify___attrs__attrs_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury____Unify___attrs__attrs_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury____Unify___attrs__attrs_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 5);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 5);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury____Unify___attrs__attrs_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 6);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 6);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury____Unify___attrs__attrs_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 7);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 7);
	MR_r1 = (MR_r3 == MR_r1);
	MR_proceed();
	}
MR_define_label(mercury____Unify___attrs__attrs_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___attrs__attrs_0_0);
	MR_incr_sp_push_msg(14, "attrs:__Compare__/3");
	MR_stackvar(14) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 7);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 6);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 5);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 7);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 6);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 5);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if (((MR_Integer) MR_r2 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i4);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i3);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i4);
	if ((MR_r2 == MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i3);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i3);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i3);
	MR_r2 = MR_stackvar(8);
	MR_r3 = MR_stackvar(1);
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i16);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i15);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i16);
	if ((MR_r3 == MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i15);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i15);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i15);
	MR_r2 = MR_stackvar(9);
	MR_r3 = MR_stackvar(2);
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i28);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i27);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i28);
	if ((MR_r3 == MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i27);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i27);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i27);
	MR_r2 = MR_stackvar(10);
	MR_r3 = MR_stackvar(3);
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i40);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i39);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i40);
	if ((MR_r3 == MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i39);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i39);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i39);
	MR_r2 = MR_stackvar(11);
	MR_r3 = MR_stackvar(4);
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i52);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i51);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i52);
	if ((MR_r3 == MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i51);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i51);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i51);
	if (((MR_Integer) MR_stackvar(5) >= (MR_Integer) MR_stackvar(12))) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i64);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i63);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i64);
	if ((MR_stackvar(5) == MR_stackvar(12))) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i63);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i63);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i63);
	if (((MR_Integer) MR_stackvar(6) >= (MR_Integer) MR_stackvar(13))) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i76);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i75);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i76);
	if ((MR_stackvar(6) == MR_stackvar(13))) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i75);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i75);
	}
MR_define_label(mercury____Compare___attrs__attrs_0_0_i124);
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i75);
	MR_r2 = MR_stackvar(14);
	MR_r3 = MR_stackvar(7);
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i86);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
MR_define_label(mercury____Compare___attrs__attrs_0_0_i86);
	if ((MR_r3 != MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__attrs_0_0_i124);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_pop_msg(14);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___attrs__colour_0_0);
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___attrs__colour_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	if (((MR_Integer) MR_r2 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__colour_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___attrs__colour_0_0_i2);
	if ((MR_r2 != MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___attrs__colour_0_0_i3);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___attrs__colour_0_0_i3);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__attrs_maybe_bunch_0(void)
{
	attrs_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__attrs__init(void);
void mercury__attrs__init_type_tables(void);
void mercury__attrs__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__attrs__write_out_proc_statics(FILE *fp);
#endif

void mercury__attrs__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__attrs_maybe_bunch_0();
#endif

	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_attrs__type_ctor_info_colour_0,
		attrs__colour_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_attrs__type_ctor_info_attrs_0,
		attrs__attrs_0_0);
	mercury__attrs__init_debugger();
}

void mercury__attrs__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
	MR_register_type_ctor_info(
		&mercury_data_attrs__type_ctor_info_colour_0);
	MR_register_type_ctor_info(
		&mercury_data_attrs__type_ctor_info_attrs_0);
}


void mercury__attrs__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__attrs__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
