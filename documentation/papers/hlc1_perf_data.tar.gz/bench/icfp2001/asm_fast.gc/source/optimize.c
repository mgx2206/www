/*
** Automatically generated from `optimize.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__optimize__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "optimize.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "optimize.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

#ifdef MR_HIGHLEVEL_CODE
  bool MR_CALL mercury__array__do_unify__array_1_0(
  	MR_Mercury_Type_Info type_info, MR_Box x, MR_Box y);
  bool MR_CALL mercury__array____Unify____array_1_0(
	MR_Mercury_Type_Info type_info, MR_Array x, MR_Array y);
  void MR_CALL mercury__array__do_compare__array_1_0(MR_Mercury_Type_Info
 	 type_info, MR_Comparison_Result *result, MR_Box x, MR_Box y);
  void MR_CALL mercury__array____Compare____array_1_0(MR_Mercury_Type_Info
	type_info, MR_Comparison_Result *result, MR_Array x, MR_Array y);
#endif

#line 46 "optimize.c"
#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

#include "mercury_heap.h"		/* for MR_maybe_record_allocation() */
#include "mercury_library_types.h"	/* for MR_ArrayType */

#line 52 "optimize.c"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType *ML_make_array(MR_Integer size, MR_Word item);

#line 57 "optimize.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType * ML_resize_array(MR_ArrayType *old_array,
					MR_Integer array_size, MR_Word item);

#line 63 "optimize.c"
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType * ML_shrink_array(MR_ArrayType *old_array,
					MR_Integer array_size);

#line 69 "optimize.c"
#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType *ML_copy_array(MR_ArrayType *old_array);

#line 74 "optimize.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 81 "optimize.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_DETERMINISM_GUARD
#define ML_DETERMINISM_GUARD
	/*
	** The enumeration constants in this enum must be in the same
	** order as the functors in the Mercury type `determinism'
	** defined above.
	*/
	typedef enum {
		ML_DET,
		ML_SEMIDET,
		ML_CC_MULTI,
		ML_CC_NONDET,
		ML_MULTI,
		ML_NONDET,
		ML_ERRONEOUS,
		ML_FAILURE
	} ML_Determinism;
#endif

#line 104 "optimize.c"
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* protect against multiple inclusion */
#ifndef MR_HLC_EXCEPTION_GUARD
#define MR_HLC_EXCEPTION_GUARD

#ifdef MR_HIGHLEVEL_CODE

  #ifdef MR_USE_GCC_NESTED_FUNCTIONS
  	#define MR_CONT_PARAMS		MR_NestedCont cont
  	#define MR_CONT_PARAM_TYPES	MR_NestedCont
  	#define MR_CONT_ARGS		cont
  #else
  	#define MR_CONT_PARAMS		MR_Cont cont, void *cont_env
  	#define MR_CONT_PARAM_TYPES	MR_Cont, void *
  	#define MR_CONT_ARGS		cont, cont_env
  #endif

	/* det */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_0(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* semidet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_1(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_2(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_nondet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_3(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_4(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

	/* nondet */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_5(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

  #ifndef MR_AVOID_MACROS

	/* det ==> model_det */
	#define mercury__exception__builtin_catch_3_p_0 		mercury__exception__builtin_catch_model_det

	/* semidet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_1 		mercury__exception__builtin_catch_model_semi

	/* cc_multi ==> model_det */
	#define mercury__exception__builtin_catch_3_p_2 		mercury__exception__builtin_catch_model_det

	/* cc_nondet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_3 		mercury__exception__builtin_catch_model_semi

	/* multi ==> model_non */
	#define mercury__exception__builtin_catch_3_p_4 		mercury__exception__builtin_catch_model_non

	/* nondet ==> model_non */
	#define mercury__exception__builtin_catch_3_p_5 		mercury__exception__builtin_catch_model_non

  #endif /* !MR_AVOID_MACROS */

	void MR_CALL mercury__exception__builtin_throw_1_p_0(MR_Univ exception);

	void MR_CALL mercury__exception__builtin_catch_model_det(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	bool MR_CALL mercury__exception__builtin_catch_model_semi(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	void MR_CALL mercury__exception__builtin_catch_model_non(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

#endif /* MR_HIGHLEVEL_CODE */

#endif /* MR_HLC_EXCEPTION_GUARD */

#line 194 "optimize.c"
#line 147 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

#ifndef MR_HIGHLEVEL_CODE
	#include <assert.h>
	#include <stdio.h>
	#include "mercury_deep_copy.h"
	#include "mercury_trace_base.h"
	#include "mercury_stack_trace.h"
	#include "mercury_layout_util.h"
	#include "mercury_deep_profiling_hand.h"

	MR_DECLARE_TYPE_CTOR_INFO_STRUCT( 			mercury_data_std_util__type_ctor_info_univ_0);
#endif

#line 209 "optimize.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#include <string.h>
#include <stdio.h>

#include "mercury_string.h"	/* for MR_allocate_aligned_string*() etc. */
#include "mercury_tags.h"	/* for MR_list_cons*() */

#line 218 "optimize.c"
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#ifdef USE_GCC_GLOBAL_REGISTERS
	/*
	** GNU C version egcs-1.1.2 crashes with `fixed or forbidden
	** register spilled' in grade asm_fast.gc.tr.debug
	** if we write this inline.
	*/
	static void MR_set_char(MR_String str, MR_Integer ind, MR_Char ch)
	{
		str[ind] = ch;
	}
#else
	#define MR_set_char(str, ind, ch) \
		((str)[ind] = (ch))
#endif

#line 236 "optimize.c"
#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	extern MR_Word		ML_io_stream_names;
	extern MR_Word		ML_io_user_globals;
	#if 0
	  extern MR_Word	ML_io_ops_table;
	#endif

#line 245 "optimize.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
#ifdef HAVE_SYS_STAT_H
	#include <sys/stat.h>
#endif

#line 255 "optimize.c"
#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include "mercury_init.h"
#include "mercury_wrapper.h"
#include "mercury_type_info.h"
#include "mercury_library_types.h"
#include "mercury_file.h"
#include "mercury_heap.h"
#include "mercury_misc.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

#ifdef HAVE_SYS_WAIT
  #include <sys/wait.h>		/* for WIFEXITED, WEXITSTATUS, etc. */
#endif

extern MercuryFile mercury_stdin;
extern MercuryFile mercury_stdout;
extern MercuryFile mercury_stderr;
extern MercuryFile mercury_stdin_binary;
extern MercuryFile mercury_stdout_binary;
extern MercuryFile *mercury_current_text_input;
extern MercuryFile *mercury_current_text_output;
extern MercuryFile *mercury_current_binary_input;
extern MercuryFile *mercury_current_binary_output;

#define initial_io_state()		0	/* some random number */
#define update_io(r_src, r_dest)	((r_dest) = (r_src))
#define final_io_state(r)		((void)0)

void 		mercury_init_io(void);
MercuryFile*	mercury_open(const char *filename, const char *type);
void		mercury_io_error(MercuryFile* mf, const char *format, ...);
void		mercury_output_error(MercuryFile* mf);
void		mercury_print_string(MercuryFile* mf, const char *s);
void		mercury_print_binary_string(MercuryFile* mf, const char *s);
int		mercury_getc(MercuryFile* mf);
void		mercury_close(MercuryFile* mf);
int		ML_fprintf(MercuryFile* mf, const char *format, ...);

#line 301 "optimize.c"
#line 106 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <fcntl.h>

	#define	MAX_TEMPNAME_TRIES	(6 * 4)

	extern long ML_io_tempnam_counter;

#line 315 "optimize.c"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include <string.h>
#include <errno.h>

/*
** ML_maybe_make_err_msg(was_error, msg, procname, error_msg):
**	if `was_error' is true, then append `msg' and `strerror(errno)'
**	to give `error_msg'; otherwise, set `error_msg' to NULL.
**
** WARNING: this must only be called when the `hp' register is valid.
** That means it must only be called from procedures declared
** `will_not_call_mercury'.
**
** This is defined as a macro rather than a C function
** to avoid worrying about the `hp' register being
** invalidated by the function call.
** It also needs to be a macro because MR_incr_hp_atomic_msg()
** stringizes the procname argument.
*/
#define ML_maybe_make_err_msg(was_error, msg, procname, error_msg)	\
	do {								\
		char *errno_msg;					\
		size_t total_len;					\
		MR_Word tmp;						\
									\
		if (was_error) {					\
			errno_msg = strerror(errno);			\
			total_len = strlen(msg) + strlen(errno_msg);	\
			MR_incr_hp_atomic_msg(tmp,			\
				(total_len + sizeof(MR_Word))		\
					/ sizeof(MR_Word),		\
				procname,				\
				"string:string/0");			\
			(error_msg) = (char *)tmp;			\
			strcpy((error_msg), msg);			\
			strcat((error_msg), errno_msg);			\
		} else {						\
			(error_msg) = NULL;				\
		}							\
	} while(0)


#line 360 "optimize.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 363 "optimize.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 369 "optimize.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 377 "optimize.c"


static const struct mercury_data_optimize__common_0_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_data_optimize__common_0;

static const struct mercury_data_optimize__common_1_struct {
	MR_Integer f1;
}  mercury_data_optimize__common_1;

static const struct mercury_data_optimize__common_2_struct {
	MR_Word * f1;
	MR_Integer f2;
	MR_Word * f3;
	MR_Word * f4;
}  mercury_data_optimize__common_2;
extern const struct MR_TypeCtorInfo_Struct mercury_data_optimize__type_ctor_info_tas_0;
#ifndef MR_HO_PseudoTypeInfo_Struct2_GUARD
#define MR_HO_PseudoTypeInfo_Struct2_GUARD
MR_HIGHER_ORDER_PSEUDOTYPEINFO_STRUCT(MR_HO_PseudoTypeInfo_Struct2, 2);
#endif
static const struct MR_HO_PseudoTypeInfo_Struct2 mercury_data___ho_type_info_tuple_2__type0_12_input__tag_0__type0_14_attrs__attrs_0;
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__ho_type_9___tuple_0_2__type0_12_input__tag_0__type0_14_attrs__attrs_0;
MR_declare_static(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0);
MR_declare_label(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i3);
MR_declare_label(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i4);
MR_declare_label(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i5);
MR_declare_label(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i7);
MR_declare_static(mercury__optimize__list__map__ho4__ua0_3_0);
MR_declare_label(mercury__optimize__list__map__ho4__ua0_3_0_i4);
MR_declare_label(mercury__optimize__list__map__ho4__ua0_3_0_i5);
MR_declare_label(mercury__optimize__list__map__ho4__ua0_3_0_i2);
MR_declare_static(mercury__optimize__write_tokenss__ua0_9_0);
MR_declare_label(mercury__optimize__write_tokenss__ua0_9_0_i4);
MR_declare_label(mercury__optimize__write_tokenss__ua0_9_0_i5);
MR_declare_label(mercury__optimize__write_tokenss__ua0_9_0_i3);
MR_declare_static(mercury__optimize__io__write_list__ho2_5_0);
MR_declare_label(mercury__optimize__io__write_list__ho2_5_0_i4);
MR_declare_label(mercury__optimize__io__write_list__ho2_5_0_i6);
MR_declare_label(mercury__optimize__io__write_list__ho2_5_0_i3);
MR_define_extern_entry(mercury__optimize__write_optimized_files_7_0);
MR_declare_label(mercury__optimize__write_optimized_files_7_0_i2);
MR_declare_label(mercury__optimize__write_optimized_files_7_0_i3);
MR_declare_label(mercury__optimize__write_optimized_files_7_0_i6);
MR_declare_label(mercury__optimize__write_optimized_files_7_0_i4);
MR_declare_label(mercury__optimize__write_optimized_files_7_0_i8);
MR_declare_label(mercury__optimize__write_optimized_files_7_0_i9);
MR_declare_label(mercury__optimize__write_optimized_files_7_0_i10);
MR_declare_label(mercury__optimize__write_optimized_files_7_0_i11);
MR_declare_label(mercury__optimize__write_optimized_files_7_0_i14);
MR_declare_static(mercury__optimize__write_optimized_2_10_0);
MR_declare_label(mercury__optimize__write_optimized_2_10_0_i2);
MR_declare_label(mercury__optimize__write_optimized_2_10_0_i4);
MR_declare_label(mercury__optimize__write_optimized_2_10_0_i5);
MR_declare_label(mercury__optimize__write_optimized_2_10_0_i7);
MR_declare_label(mercury__optimize__write_optimized_2_10_0_i8);
MR_declare_static(mercury__optimize__gen_n_cc_9_0);
MR_declare_label(mercury__optimize__gen_n_cc_9_0_i6);
MR_declare_label(mercury__optimize__gen_n_cc_9_0_i4);
MR_declare_label(mercury__optimize__gen_n_cc_9_0_i8);
MR_declare_static(mercury__optimize__gen_n_10_0);
MR_declare_label(mercury__optimize__gen_n_10_0_i2);
MR_declare_label(mercury__optimize__gen_n_10_0_i3);
MR_declare_label(mercury__optimize__gen_n_10_0_i4);
MR_declare_label(mercury__optimize__gen_n_10_0_i5);
MR_declare_label(mercury__optimize__gen_n_10_0_i7);
MR_declare_static(mercury__optimize__gen_8_0);
MR_declare_label(mercury__optimize__gen_8_0_i3);
MR_declare_label(mercury__optimize__gen_8_0_i1);
MR_declare_label(mercury__optimize__gen_8_0_i9);
MR_declare_label(mercury__optimize__gen_8_0_i14);
MR_declare_label(mercury__optimize__gen_8_0_i16);
MR_declare_label(mercury__optimize__gen_8_0_i15);
MR_declare_label(mercury__optimize__gen_8_0_i6);
MR_declare_label(mercury__optimize__gen_8_0_i27);
MR_declare_label(mercury__optimize__gen_8_0_i25);
MR_declare_label(mercury__optimize__gen_8_0_i30);
MR_declare_label(mercury__optimize__gen_8_0_i22);
MR_declare_label(mercury__optimize__gen_8_0_i23);
MR_declare_label(mercury__optimize__gen_8_0_i34);
MR_declare_static(mercury__optimize__open_tag_9_0);
MR_declare_label(mercury__optimize__open_tag_9_0_i4);
MR_declare_label(mercury__optimize__open_tag_9_0_i2);
MR_declare_label(mercury__optimize__open_tag_9_0_i7);
MR_declare_label(mercury__optimize__open_tag_9_0_i1);
MR_declare_static(mercury__optimize__gen_open_8_0);
MR_declare_label(mercury__optimize__gen_open_8_0_i3);
MR_declare_label(mercury__optimize__gen_open_8_0_i1);
MR_declare_label(mercury__optimize__gen_open_8_0_i6);
MR_declare_label(mercury__optimize__gen_open_8_0_i7);
MR_declare_label(mercury__optimize__gen_open_8_0_i9);
MR_declare_label(mercury__optimize__gen_open_8_0_i10);
MR_declare_label(mercury__optimize__gen_open_8_0_i13);
MR_declare_label(mercury__optimize__gen_open_8_0_i14);
MR_declare_label(mercury__optimize__gen_open_8_0_i17);
MR_declare_label(mercury__optimize__gen_open_8_0_i18);
MR_declare_label(mercury__optimize__gen_open_8_0_i21);
MR_declare_label(mercury__optimize__gen_open_8_0_i22);
MR_declare_label(mercury__optimize__gen_open_8_0_i24);
MR_declare_label(mercury__optimize__gen_open_8_0_i25);
MR_declare_label(mercury__optimize__gen_open_8_0_i28);
MR_declare_label(mercury__optimize__gen_open_8_0_i29);
MR_declare_label(mercury__optimize__gen_open_8_0_i30);
MR_declare_label(mercury__optimize__gen_open_8_0_i31);
MR_declare_label(mercury__optimize__gen_open_8_0_i34);
MR_declare_label(mercury__optimize__gen_open_8_0_i37);
MR_declare_label(mercury__optimize__gen_open_8_0_i40);
MR_declare_label(mercury__optimize__gen_open_8_0_i43);
MR_declare_label(mercury__optimize__gen_open_8_0_i46);
MR_declare_label(mercury__optimize__gen_open_8_0_i49);
MR_define_extern_entry(mercury____Unify___optimize__tas_0_0);
MR_define_extern_entry(mercury____Compare___optimize__tas_0_0);

extern const struct MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_Struct mercury_data_input__type_ctor_info_token_0;
static const struct mercury_data_optimize__common_0_struct mercury_data_optimize__common_0 = {
	(MR_Word *) &mercury_data_list__type_ctor_info_list_1,
	(MR_Word *) &mercury_data_input__type_ctor_info_token_0
};

static const struct mercury_data_optimize__common_1_struct mercury_data_optimize__common_1 = {
	(MR_Integer) 0
};

extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_tuple_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_input__type_ctor_info_tag_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_attrs__type_ctor_info_attrs_0;
static const struct mercury_data_optimize__common_2_struct mercury_data_optimize__common_2 = {
	(MR_Word *) &mercury_data___type_ctor_info_tuple_0,
	(MR_Integer) 2,
	(MR_Word *) &mercury_data_input__type_ctor_info_tag_0,
	(MR_Word *) &mercury_data_attrs__type_ctor_info_attrs_0
};
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__ho_type_9___tuple_0_2__type0_12_input__tag_0__type0_14_attrs__attrs_0;

const struct MR_TypeCtorInfo_Struct mercury_data_optimize__type_ctor_info_tas_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___optimize__tas_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___optimize__tas_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___optimize__tas_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"optimize",
	"tas",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__ho_type_9___tuple_0_2__type0_12_input__tag_0__type0_14_attrs__attrs_0 },
	-1,
	-1
};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_tuple_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_input__type_ctor_info_tag_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_attrs__type_ctor_info_attrs_0;

#ifndef MR_HO_PseudoTypeInfo_Struct2_GUARD
#define MR_HO_PseudoTypeInfo_Struct2_GUARD
MR_HIGHER_ORDER_PSEUDOTYPEINFO_STRUCT(MR_HO_PseudoTypeInfo_Struct2, 2);
#endif
static const struct MR_HO_PseudoTypeInfo_Struct2 mercury_data___ho_type_info_tuple_2__type0_12_input__tag_0__type0_14_attrs__attrs_0 = {
	&mercury_data___type_ctor_info_tuple_0,
	2,
{	(MR_PseudoTypeInfo) &mercury_data_input__type_ctor_info_tag_0,
	(MR_PseudoTypeInfo) &mercury_data_attrs__type_ctor_info_attrs_0
}};
extern const struct MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__ho_type_9___tuple_0_2__type0_12_input__tag_0__type0_14_attrs__attrs_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_PseudoTypeInfo) &mercury_data___ho_type_info_tuple_2__type0_12_input__tag_0__type0_14_attrs__attrs_0
}};

MR_declare_entry(mercury__input__write_token_3_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;
MR_declare_entry(mercury__array__lookup_3_1);
MR_declare_entry(mercury__input__file_names_4_0);
MR_declare_entry(mercury__io__tell_4_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_res_0;
MR_declare_entry(mercury__exception__throw_1_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_string_0;
MR_declare_entry(mercury__map__delete_3_1);
MR_declare_entry(mercury__io__told_2_0);
MR_declare_entry(mercury__list__reverse_2_3_0);
MR_declare_entry(mercury__attrs__equivalent_2_0);
MR_declare_entry(mercury__fn__input__apply_tag_2_0);
MR_declare_entry(mercury____Unify___list__list_1_0);
MR_declare_entry(mercury____Compare___list__list_1_0);

MR_BEGIN_MODULE(optimize_module)
	MR_init_entry(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0);
	MR_init_label(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i3);
	MR_init_label(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i4);
	MR_init_label(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i5);
	MR_init_label(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i7);
	MR_init_entry(mercury__optimize__list__map__ho4__ua0_3_0);
	MR_init_label(mercury__optimize__list__map__ho4__ua0_3_0_i4);
	MR_init_label(mercury__optimize__list__map__ho4__ua0_3_0_i5);
	MR_init_label(mercury__optimize__list__map__ho4__ua0_3_0_i2);
	MR_init_entry(mercury__optimize__write_tokenss__ua0_9_0);
	MR_init_label(mercury__optimize__write_tokenss__ua0_9_0_i4);
	MR_init_label(mercury__optimize__write_tokenss__ua0_9_0_i5);
	MR_init_label(mercury__optimize__write_tokenss__ua0_9_0_i3);
	MR_init_entry(mercury__optimize__io__write_list__ho2_5_0);
	MR_init_label(mercury__optimize__io__write_list__ho2_5_0_i4);
	MR_init_label(mercury__optimize__io__write_list__ho2_5_0_i6);
	MR_init_label(mercury__optimize__io__write_list__ho2_5_0_i3);
	MR_init_entry(mercury__optimize__write_optimized_files_7_0);
	MR_init_label(mercury__optimize__write_optimized_files_7_0_i2);
	MR_init_label(mercury__optimize__write_optimized_files_7_0_i3);
	MR_init_label(mercury__optimize__write_optimized_files_7_0_i6);
	MR_init_label(mercury__optimize__write_optimized_files_7_0_i4);
	MR_init_label(mercury__optimize__write_optimized_files_7_0_i8);
	MR_init_label(mercury__optimize__write_optimized_files_7_0_i9);
	MR_init_label(mercury__optimize__write_optimized_files_7_0_i10);
	MR_init_label(mercury__optimize__write_optimized_files_7_0_i11);
	MR_init_label(mercury__optimize__write_optimized_files_7_0_i14);
	MR_init_entry(mercury__optimize__write_optimized_2_10_0);
	MR_init_label(mercury__optimize__write_optimized_2_10_0_i2);
	MR_init_label(mercury__optimize__write_optimized_2_10_0_i4);
	MR_init_label(mercury__optimize__write_optimized_2_10_0_i5);
	MR_init_label(mercury__optimize__write_optimized_2_10_0_i7);
	MR_init_label(mercury__optimize__write_optimized_2_10_0_i8);
	MR_init_entry(mercury__optimize__gen_n_cc_9_0);
	MR_init_label(mercury__optimize__gen_n_cc_9_0_i6);
	MR_init_label(mercury__optimize__gen_n_cc_9_0_i4);
	MR_init_label(mercury__optimize__gen_n_cc_9_0_i8);
	MR_init_entry(mercury__optimize__gen_n_10_0);
	MR_init_label(mercury__optimize__gen_n_10_0_i2);
	MR_init_label(mercury__optimize__gen_n_10_0_i3);
	MR_init_label(mercury__optimize__gen_n_10_0_i4);
	MR_init_label(mercury__optimize__gen_n_10_0_i5);
	MR_init_label(mercury__optimize__gen_n_10_0_i7);
	MR_init_entry(mercury__optimize__gen_8_0);
	MR_init_label(mercury__optimize__gen_8_0_i3);
	MR_init_label(mercury__optimize__gen_8_0_i1);
	MR_init_label(mercury__optimize__gen_8_0_i9);
	MR_init_label(mercury__optimize__gen_8_0_i14);
	MR_init_label(mercury__optimize__gen_8_0_i16);
	MR_init_label(mercury__optimize__gen_8_0_i15);
	MR_init_label(mercury__optimize__gen_8_0_i6);
	MR_init_label(mercury__optimize__gen_8_0_i27);
	MR_init_label(mercury__optimize__gen_8_0_i25);
	MR_init_label(mercury__optimize__gen_8_0_i30);
	MR_init_label(mercury__optimize__gen_8_0_i22);
	MR_init_label(mercury__optimize__gen_8_0_i23);
	MR_init_label(mercury__optimize__gen_8_0_i34);
	MR_init_entry(mercury__optimize__open_tag_9_0);
	MR_init_label(mercury__optimize__open_tag_9_0_i4);
	MR_init_label(mercury__optimize__open_tag_9_0_i2);
	MR_init_label(mercury__optimize__open_tag_9_0_i7);
	MR_init_label(mercury__optimize__open_tag_9_0_i1);
	MR_init_entry(mercury__optimize__gen_open_8_0);
	MR_init_label(mercury__optimize__gen_open_8_0_i3);
	MR_init_label(mercury__optimize__gen_open_8_0_i1);
	MR_init_label(mercury__optimize__gen_open_8_0_i6);
	MR_init_label(mercury__optimize__gen_open_8_0_i7);
	MR_init_label(mercury__optimize__gen_open_8_0_i9);
	MR_init_label(mercury__optimize__gen_open_8_0_i10);
	MR_init_label(mercury__optimize__gen_open_8_0_i13);
	MR_init_label(mercury__optimize__gen_open_8_0_i14);
	MR_init_label(mercury__optimize__gen_open_8_0_i17);
	MR_init_label(mercury__optimize__gen_open_8_0_i18);
	MR_init_label(mercury__optimize__gen_open_8_0_i21);
	MR_init_label(mercury__optimize__gen_open_8_0_i22);
	MR_init_label(mercury__optimize__gen_open_8_0_i24);
	MR_init_label(mercury__optimize__gen_open_8_0_i25);
	MR_init_label(mercury__optimize__gen_open_8_0_i28);
	MR_init_label(mercury__optimize__gen_open_8_0_i29);
	MR_init_label(mercury__optimize__gen_open_8_0_i30);
	MR_init_label(mercury__optimize__gen_open_8_0_i31);
	MR_init_label(mercury__optimize__gen_open_8_0_i34);
	MR_init_label(mercury__optimize__gen_open_8_0_i37);
	MR_init_label(mercury__optimize__gen_open_8_0_i40);
	MR_init_label(mercury__optimize__gen_open_8_0_i43);
	MR_init_label(mercury__optimize__gen_open_8_0_i46);
	MR_init_label(mercury__optimize__gen_open_8_0_i49);
	MR_init_entry(mercury____Unify___optimize__tas_0_0);
	MR_init_entry(mercury____Compare___optimize__tas_0_0);
MR_BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__write_optimized_2__128__0__ua0'/7 in mode 0 */
MR_define_static(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0);
	MR_incr_sp_push_msg(4, "optimize:DeforestationIn__pred__write_optimized_2__128__0__ua0/7");
	MR_stackvar(4) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i3);
	}
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i3);
	MR_tag_incr_hp_msg(MR_stackvar(3), MR_mktag(1), (MR_Integer) 1, mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0, "input:token/0");
	MR_field(MR_mktag(1), MR_stackvar(3), (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0), (MR_Integer) 0);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_localcall(mercury__optimize__list__map__ho4__ua0_3_0,
		MR_LABEL(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i4),
		MR_STATIC(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0));
MR_define_label(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0));
	MR_r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_stackvar(3);
	MR_call_localret(MR_ENTRY(mercury__input__write_token_3_0),
		mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i5,
		MR_STATIC(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0));
MR_define_label(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0));
	if (((MR_Integer) MR_stackvar(1) != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i7);
	}
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__optimize__io__write_list__ho2_5_0,
		MR_STATIC(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0));
MR_define_label(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0_i7);
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0
	Message = (MR_String) MR_stackvar(2);
	IO0 = MR_r1;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 726 "optimize.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r2 = MR_stackvar(2);
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__optimize__io__write_list__ho2_5_0,
		MR_STATIC(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0));
/* code for predicate 'map__ho4__ua0'/3 in mode 0 */
MR_define_static(mercury__optimize__list__map__ho4__ua0_3_0);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__optimize__list__map__ho4__ua0_3_0_i2);
	}
	MR_r3 = (MR_Word) MR_sp;
MR_define_label(mercury__optimize__list__map__ho4__ua0_3_0_i4);
	while (1) {
	MR_incr_sp_push_msg(1, "list:map__ho4__ua0");
	MR_tag_incr_hp_msg(MR_stackvar(1), MR_mktag(1), (MR_Integer) 1, mercury__optimize__list__map__ho4__ua0_3_0, "input:token/0");
	MR_field(MR_mktag(1), MR_stackvar(1), (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0), (MR_Integer) 0);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0))))
		continue;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	break; } /* end while */
MR_define_label(mercury__optimize__list__map__ho4__ua0_3_0_i5);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__optimize__list__map__ho4__ua0_3_0, "list:list/1");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_decr_sp_pop_msg(1);
	if (((MR_Integer) MR_sp > (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury__optimize__list__map__ho4__ua0_3_0_i5);
	}
	MR_proceed();
	}
MR_define_label(mercury__optimize__list__map__ho4__ua0_3_0_i2);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
/* code for predicate 'write_tokenss__ua0'/9 in mode 0 */
MR_define_static(mercury__optimize__write_tokenss__ua0_9_0);
	MR_incr_sp_push_msg(7, "optimize:write_tokenss__ua0/9");
	MR_stackvar(7) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r5 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__optimize__write_tokenss__ua0_9_0_i3);
	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_r2 = (MR_Word) MR_string_const("", 0);
	MR_r3 = MR_r6;
	MR_localcall(mercury__optimize__io__write_list__ho2_5_0,
		MR_LABEL(mercury__optimize__write_tokenss__ua0_9_0_i4),
		MR_STATIC(mercury__optimize__write_tokenss__ua0_9_0));
MR_define_label(mercury__optimize__write_tokenss__ua0_9_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__write_tokenss__ua0_9_0));
	MR_stackvar(6) = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_1),
		mercury__optimize__write_tokenss__ua0_9_0_i5,
		MR_STATIC(mercury__optimize__write_tokenss__ua0_9_0));
MR_define_label(mercury__optimize__write_tokenss__ua0_9_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__write_tokenss__ua0_9_0));
	{
	MR_String	Str;
	MR_Integer	Start;
	MR_Integer	Count;
	MR_String	SubString;
#define	MR_PROC_LABEL	mercury__optimize__write_tokenss__ua0_9_0
	Str = (MR_String) MR_stackvar(1);
	Start = MR_stackvar(4);
	Count = MR_r1;
{
#line 413 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Integer len;
	MR_Word tmp;
	if (Start < 0) Start = 0;
	if (Count <= 0) {
		MR_make_aligned_string(
			MR_LVALUE_CAST(MR_ConstString, SubString),
			"");
	} else {
		len = strlen(Str);
		if (Start > len) Start = len;
		if (Count > len - Start) Count = len - Start;
		MR_allocate_aligned_string_msg(SubString, Count, MR_PROC_LABEL);
		memcpy(SubString, Str + Start, Count);
		SubString[Count] = '\0';
	}
};}
#line 829 "optimize.c"
	MR_r7 = (MR_Word) SubString;
#undef	MR_PROC_LABEL

	}
	MR_r8 = MR_stackvar(6);
	MR_stackvar(6) = MR_r1;
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__optimize__write_tokenss__ua0_9_0
	Message = (MR_String) MR_r7;
	IO0 = MR_r8;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 850 "optimize.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r6 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = ((MR_Integer) MR_stackvar(3) + (MR_Integer) 1);
	MR_r4 = ((MR_Integer) MR_stackvar(4) + (MR_Integer) MR_stackvar(6));
	MR_r5 = MR_stackvar(5);
	MR_succip = (MR_Code *) MR_stackvar(7);
	if (((MR_Integer) MR_r5 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__optimize__write_tokenss__ua0_9_0_i3);
	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_r2 = (MR_Word) MR_string_const("", 0);
	MR_r3 = MR_r6;
	MR_localcall(mercury__optimize__io__write_list__ho2_5_0,
		MR_LABEL(mercury__optimize__write_tokenss__ua0_9_0_i4),
		MR_STATIC(mercury__optimize__write_tokenss__ua0_9_0));
MR_define_label(mercury__optimize__write_tokenss__ua0_9_0_i3);
	MR_r1 = MR_r4;
	MR_r2 = MR_r6;
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
/* code for predicate 'write_list__ho2'/5 in mode 0 */
MR_define_static(mercury__optimize__io__write_list__ho2_5_0);
	MR_incr_sp_push_msg(3, "io:write_list__ho2/5");
	MR_stackvar(3) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__optimize__io__write_list__ho2_5_0_i3);
	}
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__input__write_token_3_0),
		mercury__optimize__io__write_list__ho2_5_0_i4,
		MR_STATIC(mercury__optimize__io__write_list__ho2_5_0));
MR_define_label(mercury__optimize__io__write_list__ho2_5_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__io__write_list__ho2_5_0));
	if (((MR_Integer) MR_stackvar(2) != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__optimize__io__write_list__ho2_5_0_i6);
	}
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__optimize__io__write_list__ho2_5_0_i3);
	}
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__input__write_token_3_0),
		mercury__optimize__io__write_list__ho2_5_0_i4,
		MR_STATIC(mercury__optimize__io__write_list__ho2_5_0));
MR_define_label(mercury__optimize__io__write_list__ho2_5_0_i6);
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__optimize__io__write_list__ho2_5_0
	Message = (MR_String) MR_stackvar(1);
	IO0 = MR_r1;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 932 "optimize.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__optimize__io__write_list__ho2_5_0_i3);
	}
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__input__write_token_3_0),
		mercury__optimize__io__write_list__ho2_5_0_i4,
		MR_STATIC(mercury__optimize__io__write_list__ho2_5_0));
MR_define_label(mercury__optimize__io__write_list__ho2_5_0_i3);
	MR_r1 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate 'write_optimized_files'/7 in mode 0 */
MR_define_entry(mercury__optimize__write_optimized_files_7_0);
	MR_incr_sp_push_msg(7, "optimize:write_optimized_files/7");
	MR_stackvar(7) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_r2 = MR_r5;
	MR_call_localret(MR_ENTRY(mercury__input__file_names_4_0),
		mercury__optimize__write_optimized_files_7_0_i2,
		MR_ENTRY(mercury__optimize__write_optimized_files_7_0));
MR_define_label(mercury__optimize__write_optimized_files_7_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__write_optimized_files_7_0));
	MR_r3 = MR_r2;
	MR_r2 = MR_stackvar(5);
	MR_stackvar(5) = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__io__tell_4_0),
		mercury__optimize__write_optimized_files_7_0_i3,
		MR_ENTRY(mercury__optimize__write_optimized_files_7_0));
MR_define_label(mercury__optimize__write_optimized_files_7_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__write_optimized_files_7_0));
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__optimize__write_optimized_files_7_0_i4);
	}
	MR_stackvar(6) = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_io__type_ctor_info_res_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__optimize__write_optimized_files_7_0_i6,
		MR_ENTRY(mercury__optimize__write_optimized_files_7_0));
MR_define_label(mercury__optimize__write_optimized_files_7_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__write_optimized_files_7_0));
	MR_r5 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_r6 = MR_r2;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r4 = MR_stackvar(4);
	MR_r9 = MR_stackvar(6);
	{
	MR_Word	TypeInfo_for__T;
	MR_Word	Array;
	MR_Integer	Max;
#define	MR_PROC_LABEL	mercury__optimize__write_optimized_files_7_0
	TypeInfo_for__T = MR_r6;
	Array = MR_r2;
{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

	Max = ((MR_ArrayType *)Array)->size - 1;
;}
#line 1011 "optimize.c"
	MR_r6 = Max;
#undef	MR_PROC_LABEL

	}
	MR_r7 = (MR_Integer) 0;
	MR_r8 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_localcall(mercury__optimize__write_optimized_2_10_0,
		MR_LABEL(mercury__optimize__write_optimized_files_7_0_i8),
		MR_ENTRY(mercury__optimize__write_optimized_files_7_0));
MR_define_label(mercury__optimize__write_optimized_files_7_0_i4);
	MR_r1 = MR_stackvar(1);
	MR_r9 = MR_r2;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r4 = MR_stackvar(4);
	MR_r5 = (MR_Integer) 1;
	MR_r6 = (MR_Word) (MR_Word *) &mercury_data_attrs__type_ctor_info_attrs_0;
	{
	MR_Word	TypeInfo_for__T;
	MR_Word	Array;
	MR_Integer	Max;
#define	MR_PROC_LABEL	mercury__optimize__write_optimized_files_7_0
	TypeInfo_for__T = MR_r6;
	Array = MR_r2;
{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

	Max = ((MR_ArrayType *)Array)->size - 1;
;}
#line 1041 "optimize.c"
	MR_r6 = Max;
#undef	MR_PROC_LABEL

	}
	MR_r7 = (MR_Integer) 0;
	MR_r8 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_localcall(mercury__optimize__write_optimized_2_10_0,
		MR_LABEL(mercury__optimize__write_optimized_files_7_0_i8),
		MR_ENTRY(mercury__optimize__write_optimized_files_7_0));
MR_define_label(mercury__optimize__write_optimized_files_7_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__write_optimized_files_7_0));
	{
	MR_Word	Stream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__optimize__write_optimized_files_7_0
	IO0 = MR_r1;
{
#line 436 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) &mercury_stdout;
	update_io(IO0, IO);
;}
#line 1065 "optimize.c"
	MR_r5 = Stream;
	MR_r6 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	NewStream;
	MR_Word	OutStream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__optimize__write_optimized_files_7_0
	NewStream = MR_r5;
	IO0 = MR_r6;
	MR_OBTAIN_GLOBAL_LOCK("set_output_stream");
{
#line 431 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	OutStream = (MR_Word) mercury_current_text_output;
	mercury_current_text_output = (MercuryFile *) NewStream;
	update_io(IO0, IO);
;}
#line 1087 "optimize.c"
	MR_RELEASE_GLOBAL_LOCK("set_output_stream");
	MR_r5 = OutStream;
	MR_r6 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	StreamNames;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__optimize__write_optimized_files_7_0
	IO0 = MR_r6;
	MR_OBTAIN_GLOBAL_LOCK("get_stream_names");
{
#line 742 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	StreamNames = ML_io_stream_names;
	update_io(IO0, IO);
;}
#line 1107 "optimize.c"
	MR_RELEASE_GLOBAL_LOCK("get_stream_names");
	MR_r3 = StreamNames;
	MR_r6 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	Stream;
	MR_Integer	Id;
#define	MR_PROC_LABEL	mercury__optimize__write_optimized_files_7_0
	Stream = MR_r5;
	MR_OBTAIN_GLOBAL_LOCK("get_stream_id");
{
#line 715 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	/* 
	** Most of the time, we can just use the pointer to the stream
	** as a unique identifier.
	*/
	
	Id = (MR_Word) Stream;

#ifdef NATIVE_GC
	/* 
	** XXX for accurate GC we should embed an ID in the MercuryFile
	** and retrieve it here.
	*/
	MR_fatal_error("not implemented -- stream ids in native GC grades");
#endif
;}
#line 1138 "optimize.c"
	MR_RELEASE_GLOBAL_LOCK("get_stream_id");
	MR_r4 = Id;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(1) = MR_r5;
	MR_stackvar(2) = MR_r6;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_call_localret(MR_ENTRY(mercury__map__delete_3_1),
		mercury__optimize__write_optimized_files_7_0_i9,
		MR_ENTRY(mercury__optimize__write_optimized_files_7_0));
MR_define_label(mercury__optimize__write_optimized_files_7_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__write_optimized_files_7_0));
	{
	MR_Word	StreamNames;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__optimize__write_optimized_files_7_0
	StreamNames = MR_r1;
	IO0 = MR_stackvar(2);
	MR_OBTAIN_GLOBAL_LOCK("set_stream_names");
{
#line 746 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	ML_io_stream_names = StreamNames;
	update_io(IO0, IO);
;}
#line 1167 "optimize.c"
	MR_RELEASE_GLOBAL_LOCK("set_stream_names");
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	Stream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__optimize__write_optimized_files_7_0
	Stream = MR_stackvar(1);
	IO0 = MR_r3;
	MR_save_registers();
{
#line 769 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_close((MercuryFile *) Stream);
	update_io(IO0, IO);
;}
#line 1187 "optimize.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = MR_stackvar(5);
	MR_call_localret(MR_ENTRY(mercury__io__tell_4_0),
		mercury__optimize__write_optimized_files_7_0_i10,
		MR_ENTRY(mercury__optimize__write_optimized_files_7_0));
MR_define_label(mercury__optimize__write_optimized_files_7_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__write_optimized_files_7_0));
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__optimize__write_optimized_files_7_0_i11);
	}
	MR_stackvar(1) = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_io__type_ctor_info_res_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__optimize__write_optimized_files_7_0_i14,
		MR_ENTRY(mercury__optimize__write_optimized_files_7_0));
MR_define_label(mercury__optimize__write_optimized_files_7_0_i11);
	MR_stackvar(1) = MR_r2;
	MR_r1 = (MR_Word) MR_string_const("\n", 1);
MR_define_label(mercury__optimize__write_optimized_files_7_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__write_optimized_files_7_0));
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__optimize__write_optimized_files_7_0
	Message = (MR_String) MR_r1;
	IO0 = MR_stackvar(1);
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 1229 "optimize.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_tailcall(MR_ENTRY(mercury__io__told_2_0),
		MR_ENTRY(mercury__optimize__write_optimized_files_7_0));
/* code for predicate 'write_optimized_2'/10 in mode 0 */
MR_define_static(mercury__optimize__write_optimized_2_10_0);
	MR_incr_sp_push_msg(10, "optimize:write_optimized_2/10");
	MR_stackvar(10) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r5 <= (MR_Integer) MR_r6)) {
		MR_GOTO_LABEL(mercury__optimize__write_optimized_2_10_0_i2);
	}
	MR_r1 = MR_r8;
	MR_r2 = MR_r9;
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_succip = (MR_Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	MR_localtailcall(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0,
		MR_STATIC(mercury__optimize__write_optimized_2_10_0));
MR_define_label(mercury__optimize__write_optimized_2_10_0_i2);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_r5;
	MR_stackvar(6) = MR_r6;
	MR_stackvar(7) = MR_r7;
	MR_stackvar(8) = MR_r8;
	MR_stackvar(9) = MR_r9;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_attrs__type_ctor_info_attrs_0;
	MR_r3 = ((MR_Integer) MR_r5 - (MR_Integer) 1);
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_1),
		mercury__optimize__write_optimized_2_10_0_i4,
		MR_STATIC(mercury__optimize__write_optimized_2_10_0));
MR_define_label(mercury__optimize__write_optimized_2_10_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__write_optimized_2_10_0));
	MR_r3 = (((MR_Integer) MR_stackvar(5) + (MR_Integer) MR_stackvar(4)) - (MR_Integer) 1);
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_stackvar(6))) {
		MR_GOTO_LABEL(mercury__optimize__write_optimized_2_10_0_i5);
	}
	MR_r5 = MR_stackvar(2);
	MR_r2 = MR_stackvar(5);
	MR_r6 = MR_stackvar(8);
	MR_r4 = MR_r1;
	MR_r1 = (MR_Integer) 0;
	MR_r7 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_stackvar(2) = MR_r5;
	MR_stackvar(5) = MR_r2;
	MR_stackvar(8) = MR_r3;
	MR_localcall(mercury__optimize__gen_n_cc_9_0,
		MR_LABEL(mercury__optimize__write_optimized_2_10_0_i7),
		MR_STATIC(mercury__optimize__write_optimized_2_10_0));
MR_define_label(mercury__optimize__write_optimized_2_10_0_i5);
	MR_r5 = MR_stackvar(2);
	MR_r2 = MR_stackvar(5);
	MR_r6 = MR_stackvar(8);
	MR_r4 = MR_r1;
	MR_r3 = MR_stackvar(6);
	MR_r1 = (MR_Integer) 0;
	MR_r7 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_stackvar(2) = MR_r5;
	MR_stackvar(5) = MR_r2;
	MR_stackvar(8) = MR_r3;
	MR_localcall(mercury__optimize__gen_n_cc_9_0,
		MR_LABEL(mercury__optimize__write_optimized_2_10_0_i7),
		MR_STATIC(mercury__optimize__write_optimized_2_10_0));
MR_define_label(mercury__optimize__write_optimized_2_10_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__write_optimized_2_10_0));
	MR_r3 = MR_stackvar(5);
	MR_stackvar(5) = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_r5 = MR_r2;
	MR_r2 = MR_stackvar(3);
	MR_r4 = MR_stackvar(7);
	MR_r6 = MR_stackvar(9);
	MR_localcall(mercury__optimize__write_tokenss__ua0_9_0,
		MR_LABEL(mercury__optimize__write_optimized_2_10_0_i8),
		MR_STATIC(mercury__optimize__write_optimized_2_10_0));
MR_define_label(mercury__optimize__write_optimized_2_10_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__write_optimized_2_10_0));
	MR_r7 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_r9 = MR_r2;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r4 = MR_stackvar(4);
	MR_r5 = ((MR_Integer) MR_stackvar(8) + (MR_Integer) 1);
	MR_r6 = MR_stackvar(6);
	MR_r8 = MR_stackvar(5);
	MR_succip = (MR_Code *) MR_stackvar(10);
	if (((MR_Integer) MR_r5 <= (MR_Integer) MR_r6)) {
		MR_GOTO_LABEL(mercury__optimize__write_optimized_2_10_0_i2);
	}
	MR_r1 = MR_r8;
	MR_r2 = MR_r9;
	MR_r3 = (MR_Word) MR_string_const("", 0);
	MR_succip = (MR_Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	MR_localtailcall(mercury__optimize__DeforestationIn__pred__write_optimized_2__128__0__ua0_7_0,
		MR_STATIC(mercury__optimize__write_optimized_2_10_0));
/* code for predicate 'gen_n_cc'/9 in mode 0 */
MR_define_static(mercury__optimize__gen_n_cc_9_0);
	MR_incr_sp_push_msg(11, "optimize:gen_n_cc/9");
	MR_stackvar(11) = (MR_Word) MR_succip;
	MR_stackvar(8) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(9) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(10) = (MR_Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = MR_LABEL(mercury__optimize__gen_n_cc_9_0_i4);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_r5;
	MR_stackvar(6) = MR_r6;
	MR_stackvar(7) = MR_r7;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_r4 = MR_r5;
	MR_r5 = MR_r6;
	MR_r6 = MR_stackvar(1);
	MR_localcall(mercury__optimize__gen_n_10_0,
		MR_LABEL(mercury__optimize__gen_n_cc_9_0_i6),
		MR_STATIC(mercury__optimize__gen_n_cc_9_0));
MR_define_label(mercury__optimize__gen_n_cc_9_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_n_cc_9_0));
	MR_maxfr = (MR_Word *) MR_stackvar(10);
	MR_redoip_slot(MR_maxfr) = (MR_Code *) MR_stackvar(8);
	MR_redofr_slot(MR_maxfr) = (MR_Word *) MR_stackvar(9);
	MR_stackvar(1) = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_optimize__common_0);
	MR_r2 = MR_r3;
	MR_r3 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_call_localret(MR_ENTRY(mercury__list__reverse_2_3_0),
		mercury__optimize__gen_n_cc_9_0_i8,
		MR_STATIC(mercury__optimize__gen_n_cc_9_0));
MR_define_label(mercury__optimize__gen_n_cc_9_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_n_cc_9_0));
	MR_r1 = MR_stackvar(1);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5;
	MR_tempr1 = MR_stackvar(2);
	MR_r2 = MR_tempr1;
	MR_tempr2 = MR_stackvar(3);
	MR_r3 = MR_tempr2;
	MR_tempr3 = MR_stackvar(4);
	MR_r4 = MR_tempr3;
	MR_tempr4 = MR_stackvar(5);
	MR_r5 = MR_tempr4;
	MR_tempr5 = MR_stackvar(6);
	MR_r6 = MR_tempr5;
	MR_r7 = MR_stackvar(7);
	MR_redoip_slot(MR_maxfr) = (MR_Code *) MR_stackvar(8);
	MR_redofr_slot(MR_maxfr) = (MR_Word *) MR_stackvar(9);
	MR_r1 = ((MR_Integer) MR_r1 + (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(11);
	MR_stackvar(8) = (MR_Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(9) = (MR_Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(10) = (MR_Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = MR_LABEL(mercury__optimize__gen_n_cc_9_0_i4);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_tempr1;
	MR_stackvar(3) = MR_tempr2;
	MR_stackvar(4) = MR_tempr3;
	MR_stackvar(5) = MR_tempr4;
	MR_stackvar(6) = MR_tempr5;
	MR_stackvar(7) = MR_r7;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_tempr2;
	MR_r3 = MR_tempr3;
	MR_r4 = MR_tempr4;
	MR_r5 = MR_tempr5;
	MR_r6 = MR_stackvar(1);
	}
	MR_localcall(mercury__optimize__gen_n_10_0,
		MR_LABEL(mercury__optimize__gen_n_cc_9_0_i6),
		MR_STATIC(mercury__optimize__gen_n_cc_9_0));
MR_define_label(mercury__optimize__gen_n_cc_9_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_n_cc_9_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	MR_proceed();
/* code for predicate 'gen_n'/10 in mode 0 */
MR_define_static(mercury__optimize__gen_n_10_0);
	MR_mkframe("optimize:gen_n/10", 7, MR_ENTRY(MR_do_fail));
	if (((MR_Integer) MR_r1 <= (MR_Integer) MR_r2)) {
		MR_GOTO_LABEL(mercury__optimize__gen_n_10_0_i2);
	}
	MR_r1 = MR_r5;
	MR_r2 = MR_r6;
	MR_r3 = MR_r7;
	MR_succeed();
MR_define_label(mercury__optimize__gen_n_10_0_i2);
	MR_framevar(1) = MR_r1;
	MR_framevar(2) = MR_r2;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_framevar(6) = MR_r6;
	MR_framevar(7) = MR_r7;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_attrs__type_ctor_info_attrs_0;
	MR_r2 = MR_r4;
	MR_r3 = MR_framevar(1);
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_1),
		mercury__optimize__gen_n_10_0_i3,
		MR_STATIC(mercury__optimize__gen_n_10_0));
MR_define_label(mercury__optimize__gen_n_10_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_n_10_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_framevar(3);
	MR_framevar(3) = MR_r2;
	MR_r3 = MR_framevar(5);
	MR_r4 = MR_framevar(6);
	MR_r5 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_localcall(mercury__optimize__gen_8_0,
		MR_LABEL(mercury__optimize__gen_n_10_0_i4),
		MR_STATIC(mercury__optimize__gen_n_10_0));
MR_define_label(mercury__optimize__gen_n_10_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_n_10_0));
	MR_framevar(5) = MR_r1;
	MR_framevar(6) = MR_r2;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_input__type_ctor_info_token_0;
	MR_r2 = MR_r3;
	MR_r3 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_call_localret(MR_ENTRY(mercury__list__reverse_2_3_0),
		mercury__optimize__gen_n_10_0_i5,
		MR_STATIC(mercury__optimize__gen_n_10_0));
MR_define_label(mercury__optimize__gen_n_10_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_n_10_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__optimize__gen_n_10_0, "list:list/1");
	MR_r7 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_framevar(7);
	MR_r1 = ((MR_Integer) MR_framevar(1) + (MR_Integer) 1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
	MR_r6 = MR_framevar(6);
	}
	MR_localcall(mercury__optimize__gen_n_10_0,
		MR_LABEL(mercury__optimize__gen_n_10_0_i7),
		MR_STATIC(mercury__optimize__gen_n_10_0));
MR_define_label(mercury__optimize__gen_n_10_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_n_10_0));
	MR_succeed();
/* code for predicate 'gen'/8 in mode 0 */
MR_define_static(mercury__optimize__gen_8_0);
	MR_mkframe("optimize:gen/8", 5, MR_ENTRY(MR_do_fail));
	MR_framevar(1) = MR_r1;
	MR_framevar(2) = MR_r2;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_call_localret(MR_ENTRY(mercury__attrs__equivalent_2_0),
		mercury__optimize__gen_8_0_i3,
		MR_STATIC(mercury__optimize__gen_8_0));
MR_define_label(mercury__optimize__gen_8_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_8_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i1);
	}
	MR_r1 = MR_framevar(3);
	MR_r2 = MR_framevar(4);
	MR_r3 = MR_framevar(5);
	MR_succeed();
MR_define_label(mercury__optimize__gen_8_0_i1);
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 7);
	if (((MR_Integer) MR_tempr1 == (MR_Integer) 8)) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i9);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 7);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 8)) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i9);
	}
	MR_framevar(1) = MR_r1;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	if (((MR_Integer) MR_framevar(3) != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i14);
	}
	MR_fail();
	}
MR_define_label(mercury__optimize__gen_8_0_i9);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 6);
	if (((MR_Integer) MR_tempr1 == (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i6);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 6);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i6);
	}
	MR_framevar(1) = MR_r1;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	if (((MR_Integer) MR_framevar(3) == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_fail();
	}
	}
MR_define_label(mercury__optimize__gen_8_0_i14);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__optimize__gen_8_0, "input:token/0");
	MR_r6 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(1), MR_framevar(3), (MR_Integer) 0);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0);
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(1), (MR_Integer) 2, mercury__optimize__gen_8_0, "list:list/1");
	MR_r5 = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr3, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr3, (MR_Integer) 1) = MR_framevar(5);
	MR_r1 = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(1), MR_framevar(3), (MR_Integer) 1);
	if (((MR_Integer) MR_const_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i16);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0) != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i15);
	}
	}
MR_define_label(mercury__optimize__gen_8_0_i16);
	MR_r4 = (MR_Integer) 2;
	MR_r6 = ((MR_Integer) MR_framevar(4) - (MR_Integer) MR_r4);
	if (((MR_Integer) MR_r6 < (MR_Integer) 0)) {
		MR_fail();
	}
	MR_r4 = MR_r6;
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	MR_localtailcall(mercury__optimize__gen_8_0,
		MR_STATIC(mercury__optimize__gen_8_0));
MR_define_label(mercury__optimize__gen_8_0_i15);
	MR_r4 = (MR_Integer) 1;
	MR_r6 = ((MR_Integer) MR_framevar(4) - (MR_Integer) MR_r4);
	if (((MR_Integer) MR_r6 < (MR_Integer) 0)) {
		MR_fail();
	}
	MR_r4 = MR_r6;
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	MR_localtailcall(mercury__optimize__gen_8_0,
		MR_STATIC(mercury__optimize__gen_8_0));
MR_define_label(mercury__optimize__gen_8_0_i6);
	MR_redoip_slot(MR_maxfr) = MR_LABEL(mercury__optimize__gen_8_0_i22);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i23);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__optimize__gen_8_0, "input:token/0");
	MR_r6 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r7 = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0);
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(1), (MR_Integer) 2, mercury__optimize__gen_8_0, "list:list/1");
	MR_r8 = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr3, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr3, (MR_Integer) 1) = MR_r5;
	MR_r9 = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1);
	MR_r7 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_const_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i27);
	}
	MR_framevar(1) = MR_r1;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_r3 = MR_r7;
	MR_r5 = MR_r8;
	MR_r1 = MR_r9;
	MR_tempr1 = (MR_Integer) 2;
	MR_r6 = ((MR_Integer) MR_framevar(4) - (MR_Integer) MR_tempr1);
	if (((MR_Integer) MR_r6 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i30);
	}
	MR_framevar(2) = MR_r2;
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
	MR_redoip_slot(MR_curfr) = MR_ENTRY(MR_do_fail);
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	MR_localtailcall(mercury__optimize__gen_open_8_0,
		MR_STATIC(mercury__optimize__gen_8_0));
	}
MR_define_label(mercury__optimize__gen_8_0_i27);
	if (((MR_Integer) MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0) != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i25);
	}
	MR_framevar(1) = MR_r1;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_r3 = MR_r7;
	MR_r5 = MR_r8;
	MR_r1 = MR_r9;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = (MR_Integer) 2;
	MR_r6 = ((MR_Integer) MR_framevar(4) - (MR_Integer) MR_tempr1);
	if (((MR_Integer) MR_r6 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i30);
	}
	MR_framevar(2) = MR_r2;
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
	MR_redoip_slot(MR_curfr) = MR_ENTRY(MR_do_fail);
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	MR_localtailcall(mercury__optimize__gen_open_8_0,
		MR_STATIC(mercury__optimize__gen_8_0));
	}
MR_define_label(mercury__optimize__gen_8_0_i25);
	MR_framevar(1) = MR_r1;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_r3 = MR_r7;
	MR_r5 = MR_r8;
	MR_r1 = MR_r9;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = (MR_Integer) 1;
	MR_r6 = ((MR_Integer) MR_framevar(4) - (MR_Integer) MR_tempr1);
	if (((MR_Integer) MR_r6 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__gen_8_0_i30);
	}
	MR_framevar(2) = MR_r2;
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
	MR_redoip_slot(MR_curfr) = MR_ENTRY(MR_do_fail);
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	MR_localtailcall(mercury__optimize__gen_open_8_0,
		MR_STATIC(mercury__optimize__gen_8_0));
	}
MR_define_label(mercury__optimize__gen_8_0_i30);
	MR_framevar(2) = MR_r2;
	MR_r4 = MR_r6;
	MR_localcall(mercury__optimize__gen_8_0,
		MR_LABEL(mercury__optimize__gen_8_0_i34),
		MR_STATIC(mercury__optimize__gen_8_0));
MR_define_label(mercury__optimize__gen_8_0_i22);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_8_0));
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
MR_define_label(mercury__optimize__gen_8_0_i23);
	MR_redoip_slot(MR_curfr) = MR_ENTRY(MR_do_fail);
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	MR_localtailcall(mercury__optimize__gen_open_8_0,
		MR_STATIC(mercury__optimize__gen_8_0));
MR_define_label(mercury__optimize__gen_8_0_i34);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_8_0));
	MR_succeed();
/* code for predicate 'open_tag'/9 in mode 0 */
MR_define_static(mercury__optimize__open_tag_9_0);
	MR_incr_sp_push_msg(4, "optimize:open_tag/9");
	MR_stackvar(4) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__optimize__open_tag_9_0, "{}/2");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r2;
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__optimize__open_tag_9_0, "list:list/1");
	MR_stackvar(1) = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_r3;
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 1, mercury__optimize__open_tag_9_0, "input:token/0");
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_r1;
	MR_tag_incr_hp_msg(MR_tempr4, MR_mktag(1), (MR_Integer) 2, mercury__optimize__open_tag_9_0, "list:list/1");
	MR_stackvar(3) = MR_tempr4;
	MR_field(MR_mktag(1), MR_tempr4, (MR_Integer) 0) = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr4, (MR_Integer) 1) = MR_r5;
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__optimize__open_tag_9_0_i4);
	}
	MR_tempr1 = MR_r4;
	MR_tempr2 = (MR_Integer) 2;
	MR_r5 = ((MR_Integer) MR_tempr1 - ((MR_Integer) 1 + (MR_Integer) MR_tempr2));
	if (((MR_Integer) MR_r5 < (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__open_tag_9_0_i1);
	}
	MR_stackvar(2) = MR_r5;
	}
	MR_call_localret(MR_ENTRY(mercury__fn__input__apply_tag_2_0),
		mercury__optimize__open_tag_9_0_i7,
		MR_STATIC(mercury__optimize__open_tag_9_0));
MR_define_label(mercury__optimize__open_tag_9_0_i4);
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__optimize__open_tag_9_0_i2);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r4;
	MR_tempr2 = (MR_Integer) 2;
	MR_r5 = ((MR_Integer) MR_tempr1 - ((MR_Integer) 1 + (MR_Integer) MR_tempr2));
	if (((MR_Integer) MR_r5 < (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__open_tag_9_0_i1);
	}
	MR_stackvar(2) = MR_r5;
	}
	MR_call_localret(MR_ENTRY(mercury__fn__input__apply_tag_2_0),
		mercury__optimize__open_tag_9_0_i7,
		MR_STATIC(mercury__optimize__open_tag_9_0));
MR_define_label(mercury__optimize__open_tag_9_0_i2);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_r4;
	MR_tempr2 = (MR_Integer) 1;
	MR_r5 = ((MR_Integer) MR_tempr1 - ((MR_Integer) 1 + (MR_Integer) MR_tempr2));
	if (((MR_Integer) MR_r5 < (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__open_tag_9_0_i1);
	}
	MR_stackvar(2) = MR_r5;
	}
	MR_call_localret(MR_ENTRY(mercury__fn__input__apply_tag_2_0),
		mercury__optimize__open_tag_9_0_i7,
		MR_STATIC(mercury__optimize__open_tag_9_0));
MR_define_label(mercury__optimize__open_tag_9_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__open_tag_9_0));
	MR_r2 = MR_r1;
	MR_r3 = MR_stackvar(1);
	MR_r4 = MR_stackvar(2);
	MR_r5 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__optimize__open_tag_9_0_i1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate 'gen_open'/8 in mode 0 */
MR_define_static(mercury__optimize__gen_open_8_0);
	MR_mkframe("optimize:gen_open/8", 5, MR_ENTRY(MR_do_fail));
	MR_framevar(1) = MR_r1;
	MR_framevar(2) = MR_r2;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_call_localret(MR_ENTRY(mercury__attrs__equivalent_2_0),
		mercury__optimize__gen_open_8_0_i3,
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_open_8_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i1);
	}
	MR_r1 = MR_framevar(3);
	MR_r2 = MR_framevar(4);
	MR_r3 = MR_framevar(5);
	MR_succeed();
MR_define_label(mercury__optimize__gen_open_8_0_i1);
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
	MR_redoip_slot(MR_maxfr) = MR_LABEL(mercury__optimize__gen_open_8_0_i6);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 7);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 7);
	if ((MR_tempr1 == MR_tempr2)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i7);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 1, mercury__optimize__gen_open_8_0, "input:tag/0");
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 7);
	MR_framevar(1) = MR_r1;
	MR_framevar(2) = MR_r2;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_r2 = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_localcall(mercury__optimize__open_tag_9_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i46),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_open_8_0));
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
MR_define_label(mercury__optimize__gen_open_8_0_i7);
	MR_redoip_slot(MR_maxfr) = MR_LABEL(mercury__optimize__gen_open_8_0_i9);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i10);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i10);
	}
	MR_framevar(1) = MR_r1;
	MR_framevar(2) = MR_r2;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	}
	MR_localcall(mercury__optimize__open_tag_9_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i46),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_open_8_0));
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
MR_define_label(mercury__optimize__gen_open_8_0_i10);
	MR_redoip_slot(MR_maxfr) = MR_LABEL(mercury__optimize__gen_open_8_0_i13);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i14);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i14);
	}
	MR_framevar(1) = MR_r1;
	MR_framevar(2) = MR_r2;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 2));
	}
	MR_localcall(mercury__optimize__open_tag_9_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i46),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_open_8_0));
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
MR_define_label(mercury__optimize__gen_open_8_0_i14);
	MR_redoip_slot(MR_maxfr) = MR_LABEL(mercury__optimize__gen_open_8_0_i17);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i18);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i18);
	}
	MR_framevar(1) = MR_r1;
	MR_framevar(2) = MR_r2;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 5));
	}
	MR_localcall(mercury__optimize__open_tag_9_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i46),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i17);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_open_8_0));
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
MR_define_label(mercury__optimize__gen_open_8_0_i18);
	MR_redoip_slot(MR_maxfr) = MR_LABEL(mercury__optimize__gen_open_8_0_i21);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	if ((MR_tempr1 == MR_tempr2)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i22);
	}
	MR_framevar(1) = MR_r1;
	MR_framevar(2) = MR_r2;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 1));
	}
	MR_localcall(mercury__optimize__open_tag_9_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i46),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i21);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_open_8_0));
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
MR_define_label(mercury__optimize__gen_open_8_0_i22);
	MR_redoip_slot(MR_maxfr) = MR_LABEL(mercury__optimize__gen_open_8_0_i24);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i25);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i25);
	}
	MR_framevar(1) = MR_r1;
	MR_framevar(2) = MR_r2;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 4));
	}
	MR_localcall(mercury__optimize__open_tag_9_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i46),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i24);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_open_8_0));
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
MR_define_label(mercury__optimize__gen_open_8_0_i25);
	MR_redoip_slot(MR_maxfr) = MR_LABEL(mercury__optimize__gen_open_8_0_i28);
	MR_r6 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 5);
	if (((MR_Integer) MR_r6 >= (MR_Integer) 3)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i29);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 5);
	if (((MR_Integer) MR_r6 >= (MR_Integer) MR_tempr1)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i29);
	}
	MR_framevar(1) = MR_r1;
	MR_framevar(2) = MR_r2;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_optimize__common_1);
	}
	MR_localcall(mercury__optimize__open_tag_9_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i46),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i28);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_open_8_0));
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
MR_define_label(mercury__optimize__gen_open_8_0_i29);
	MR_redoip_slot(MR_maxfr) = MR_LABEL(mercury__optimize__gen_open_8_0_i30);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 6);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 6);
	if ((MR_tempr1 == MR_tempr2)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i31);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__optimize__gen_open_8_0, "input:tag/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 6);
	MR_framevar(1) = MR_r1;
	MR_framevar(2) = MR_r2;
	MR_framevar(3) = MR_r3;
	MR_framevar(4) = MR_r4;
	MR_framevar(5) = MR_r5;
	MR_r2 = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_localcall(mercury__optimize__open_tag_9_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i46),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i30);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_open_8_0));
	MR_r1 = MR_framevar(1);
	MR_r2 = MR_framevar(2);
	MR_r3 = MR_framevar(3);
	MR_r4 = MR_framevar(4);
	MR_r5 = MR_framevar(5);
MR_define_label(mercury__optimize__gen_open_8_0_i31);
	MR_redoip_slot(MR_curfr) = MR_ENTRY(MR_do_fail);
	MR_r6 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r7 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	MR_r8 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 5);
	MR_r9 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r10 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r11 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4);
	MR_r12 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 5);
	MR_r13 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if (((MR_Integer) MR_r13 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i34);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i34);
	}
	MR_framevar(2) = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 3));
	}
	MR_localcall(mercury__optimize__open_tag_9_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i46),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i34);
	if (((MR_Integer) MR_r10 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i37);
	}
	if (((MR_Integer) MR_r6 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i37);
	}
	MR_framevar(2) = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 3));
	MR_localcall(mercury__optimize__open_tag_9_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i46),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i37);
	if (((MR_Integer) MR_r11 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i40);
	}
	if (((MR_Integer) MR_r7 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i40);
	}
	MR_framevar(2) = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 3));
	MR_localcall(mercury__optimize__open_tag_9_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i46),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i40);
	if (((MR_Integer) MR_r9 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i43);
	}
	if (((MR_Integer) MR_r7 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__optimize__gen_open_8_0_i43);
	}
	MR_framevar(2) = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 3));
	MR_localcall(mercury__optimize__open_tag_9_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i46),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i43);
	if (((MR_Integer) MR_r12 <= (MR_Integer) MR_r8)) {
		MR_fail();
	}
	MR_r6 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 5);
	if (((MR_Integer) MR_r6 >= (MR_Integer) 3)) {
		MR_fail();
	}
	MR_framevar(2) = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 3));
	MR_localcall(mercury__optimize__open_tag_9_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i46),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i46);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_open_8_0));
	if (!(MR_r1)) {
		MR_redo();
	}
	MR_r1 = MR_r2;
	MR_r2 = MR_framevar(2);
	MR_localcall(mercury__optimize__gen_open_8_0,
		MR_LABEL(mercury__optimize__gen_open_8_0_i49),
		MR_STATIC(mercury__optimize__gen_open_8_0));
MR_define_label(mercury__optimize__gen_open_8_0_i49);
	MR_update_prof_current_proc(MR_LABEL(mercury__optimize__gen_open_8_0));
	MR_succeed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___optimize__tas_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_optimize__common_2);
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___optimize__tas_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___optimize__tas_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_optimize__common_2);
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___optimize__tas_0_0));
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__optimize_maybe_bunch_0(void)
{
	optimize_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__optimize__init(void);
void mercury__optimize__init_type_tables(void);
void mercury__optimize__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__optimize__write_out_proc_statics(FILE *fp);
#endif

void mercury__optimize__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__optimize_maybe_bunch_0();
#endif

	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_optimize__type_ctor_info_tas_0,
		optimize__tas_0_0);
	mercury__optimize__init_debugger();
}

void mercury__optimize__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
	MR_register_type_ctor_info(
		&mercury_data_optimize__type_ctor_info_tas_0);
}


void mercury__optimize__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__optimize__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
