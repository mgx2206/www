/*
** Automatically generated from `util.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module util. */
/* :- implementation. */

#include "util.h"


#include "mercury.assoc_list.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.enum.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "mercury.ops.h"
#include "mercury.private_builtin.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.term.h"
#include "mercury.time.h"
#include "mercury.tree234.h"






const MR_TypeCtorInfo_Struct util__util__type_ctor_info_code_0 = {
		(MR_Integer) 0,
		((MR_Box) (util____Unify____code_0_0)),
		((MR_Box) (util____Unify____code_0_0)),
		((MR_Box) (util____Compare____code_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "util",
		(MR_String) "code",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&mercury__builtin____type_ctor_info_int_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct util__util__type_ctor_info_byte_0 = {
		(MR_Integer) 0,
		((MR_Box) (util____Unify____byte_0_0)),
		((MR_Box) (util____Unify____byte_0_0)),
		((MR_Box) (util____Compare____byte_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "util",
		(MR_String) "byte",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&mercury__builtin____type_ctor_info_int_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};

#line 19 "util.m"
void MR_CALL util____Compare____byte_0_0(
#line 19 "util.m"
  MR_Word * util__HeadVar__1_1,
#line 19 "util.m"
  MR_Word util__HeadVar__2_2,
#line 19 "util.m"
  MR_Word util__HeadVar__3_3)
#line 19 "util.m"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  {
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    bool util__succeeded;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Integer util__conv1_HeadVar__2_2 = (MR_Integer) util__HeadVar__2_2;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Integer util__conv2_HeadVar__3_3 = (MR_Integer) util__HeadVar__3_3;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    util__succeeded = (util__conv1_HeadVar__2_2 < util__conv2_HeadVar__3_3);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (util__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *util__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        util__succeeded = (util__conv1_HeadVar__2_2 == util__conv2_HeadVar__3_3);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (util__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *util__HeadVar__1_1 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *util__HeadVar__1_1 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  }
#line 19 "util.m"
}

#line 19 "util.m"
bool MR_CALL util____Unify____byte_0_0(
#line 19 "util.m"
  MR_Word util__HeadVar__1_1,
#line 19 "util.m"
  MR_Word util__HeadVar__2_2)
#line 19 "util.m"
{
#line 19 "util.m"
  {
#line 19 "util.m"
    bool util__succeeded;
#line 19 "util.m"
    MR_Integer util__conv1_HeadVar__1_1 = (MR_Integer) util__HeadVar__1_1;
#line 19 "util.m"
    MR_Integer util__conv2_HeadVar__2_2 = (MR_Integer) util__HeadVar__2_2;

#line 19 "util.m"
    util__succeeded = (util__conv1_HeadVar__1_1 == util__conv2_HeadVar__2_2);
#line 19 "util.m"
    if (util__succeeded)
#line 19 "util.m"
      util__succeeded = TRUE;
#line 19 "util.m"
    return util__succeeded;
#line 19 "util.m"
  }
#line 19 "util.m"
}

#line 17 "util.m"
void MR_CALL util____Compare____code_0_0(
#line 17 "util.m"
  MR_Word * util__HeadVar__1_1,
#line 17 "util.m"
  MR_Word util__HeadVar__2_2,
#line 17 "util.m"
  MR_Word util__HeadVar__3_3)
#line 17 "util.m"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  {
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    bool util__succeeded;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Integer util__conv1_HeadVar__2_2 = (MR_Integer) util__HeadVar__2_2;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Integer util__conv2_HeadVar__3_3 = (MR_Integer) util__HeadVar__3_3;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    util__succeeded = (util__conv1_HeadVar__2_2 < util__conv2_HeadVar__3_3);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (util__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *util__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        util__succeeded = (util__conv1_HeadVar__2_2 == util__conv2_HeadVar__3_3);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (util__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *util__HeadVar__1_1 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *util__HeadVar__1_1 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  }
#line 17 "util.m"
}

#line 17 "util.m"
bool MR_CALL util____Unify____code_0_0(
#line 17 "util.m"
  MR_Word util__HeadVar__1_1,
#line 17 "util.m"
  MR_Word util__HeadVar__2_2)
#line 17 "util.m"
{
#line 17 "util.m"
  {
#line 17 "util.m"
    bool util__succeeded;
#line 17 "util.m"
    MR_Integer util__conv1_HeadVar__1_1 = (MR_Integer) util__HeadVar__1_1;
#line 17 "util.m"
    MR_Integer util__conv2_HeadVar__2_2 = (MR_Integer) util__HeadVar__2_2;

#line 17 "util.m"
    util__succeeded = (util__conv1_HeadVar__1_1 == util__conv2_HeadVar__2_2);
#line 17 "util.m"
    if (util__succeeded)
#line 17 "util.m"
      util__succeeded = TRUE;
#line 17 "util.m"
    return util__succeeded;
#line 17 "util.m"
  }
#line 17 "util.m"
}

#line 37 "util.m"
MR_Integer MR_CALL util__ratio_3_f_0(
#line 37 "util.m"
  MR_Integer util__HeadVar__1_1,
#line 37 "util.m"
  MR_Integer util__HeadVar__2_2)
#line 37 "util.m"
{
  {
    bool util__succeeded;
    MR_Integer util__HeadVar__3_3;
    MR_Integer util__V_6_6 = (util__HeadVar__1_1 - util__HeadVar__2_2);
    MR_Integer util__V_7_7 = (MR_Integer) 11;

#line 64 "util.m"
    util__HeadVar__3_3 = (util__V_6_6 >> util__V_7_7);
    return util__HeadVar__3_3;
  }
#line 37 "util.m"
}

#line 35 "util.m"
MR_Integer MR_CALL util__rshift_3_f_0(
#line 35 "util.m"
  MR_Integer util__HeadVar__1_1,
#line 35 "util.m"
  MR_Integer util__HeadVar__2_2)
#line 35 "util.m"
{
#line 64 "util.m"
  {
#line 64 "util.m"
    bool util__succeeded;
#line 64 "util.m"
    MR_Integer util__HeadVar__3_3 = (util__HeadVar__1_1 >> util__HeadVar__2_2);

#line 64 "util.m"
    return util__HeadVar__3_3;
#line 64 "util.m"
  }
#line 35 "util.m"
}

#line 33 "util.m"
MR_Integer MR_CALL util__lshift_3_f_0(
#line 33 "util.m"
  MR_Integer util__HeadVar__1_1,
#line 33 "util.m"
  MR_Integer util__HeadVar__2_2)
#line 33 "util.m"
{
#line 62 "util.m"
  {
#line 62 "util.m"
    bool util__succeeded;
#line 62 "util.m"
    MR_Integer util__HeadVar__3_3 = (util__HeadVar__1_1 << util__HeadVar__2_2);

#line 62 "util.m"
    return util__HeadVar__3_3;
#line 62 "util.m"
  }
#line 33 "util.m"
}

#line 31 "util.m"
MR_Integer MR_CALL util__update_bpc_3_f_0(
#line 31 "util.m"
  MR_Integer util__HeadVar__1_1,
#line 31 "util.m"
  MR_Integer util__HeadVar__2_2)
#line 31 "util.m"
{
  {
    bool util__succeeded;
    MR_Integer util__HeadVar__3_3;
    MR_Integer util__V_6_6;
    MR_Integer util__V_7_7;
    MR_Integer util__V_8_8 = (MR_Integer) 1;

#line 62 "util.m"
    util__V_7_7 = (util__V_8_8 << util__HeadVar__2_2);
#line 58 "util.m"
    util__succeeded = (util__HeadVar__1_1 >= util__V_7_7);
#line 58 "util.m"
    if (util__succeeded)
#line 58 "util.m"
      util__V_6_6 = (MR_Integer) 1;
#line 58 "util.m"
    else
#line 58 "util.m"
      util__V_6_6 = (MR_Integer) 0;
#line 58 "util.m"
    util__HeadVar__3_3 = (util__HeadVar__2_2 + util__V_6_6);
    return util__HeadVar__3_3;
  }
#line 31 "util.m"
}

#line 29 "util.m"
MR_Integer MR_CALL util__initial_bpc_1_f_0(void)
#line 29 "util.m"
{
#line 54 "util.m"
  {
#line 54 "util.m"
    bool util__succeeded;
#line 54 "util.m"
    MR_Integer util__HeadVar__1_1 = (MR_Integer) 9;

#line 54 "util.m"
    return util__HeadVar__1_1;
#line 54 "util.m"
  }
#line 29 "util.m"
}

#line 27 "util.m"
MR_Integer MR_CALL util__max_code_1_f_0(void)
#line 27 "util.m"
{
#line 52 "util.m"
  {
#line 52 "util.m"
    bool util__succeeded;
#line 52 "util.m"
    MR_Integer util__HeadVar__1_1 = (MR_Integer) 65535;

#line 52 "util.m"
    return util__HeadVar__1_1;
#line 52 "util.m"
  }
#line 27 "util.m"
}

#line 25 "util.m"
MR_Integer MR_CALL util__empty_code_1_f_0(void)
#line 25 "util.m"
{
#line 50 "util.m"
  {
#line 50 "util.m"
    bool util__succeeded;
#line 50 "util.m"
    MR_Integer util__HeadVar__1_1 = (MR_Integer) -1;

#line 50 "util.m"
    return util__HeadVar__1_1;
#line 50 "util.m"
  }
#line 25 "util.m"
}

#line 23 "util.m"
MR_Integer MR_CALL util__clear_code_1_f_0(void)
#line 23 "util.m"
{
#line 48 "util.m"
  {
#line 48 "util.m"
    bool util__succeeded;
#line 48 "util.m"
    MR_Integer util__HeadVar__1_1 = (MR_Integer) 256;

#line 48 "util.m"
    return util__HeadVar__1_1;
#line 48 "util.m"
  }
#line 23 "util.m"
}

#line 21 "util.m"
MR_Integer MR_CALL util__first_new_code_1_f_0(void)
#line 21 "util.m"
{
#line 46 "util.m"
  {
#line 46 "util.m"
    bool util__succeeded;
#line 46 "util.m"
    MR_Integer util__HeadVar__1_1 = (MR_Integer) 257;

#line 46 "util.m"
    return util__HeadVar__1_1;
#line 46 "util.m"
  }
#line 21 "util.m"
}

void mercury__util__init(void)
{
}

void mercury__util__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&util__util__type_ctor_info_code_0);
	MR_register_type_ctor_info(&util__util__type_ctor_info_byte_0);
}

void mercury__util__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module util. */
