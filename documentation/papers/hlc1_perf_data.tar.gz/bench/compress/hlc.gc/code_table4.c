/*
** Automatically generated from `code_table4.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module code_table4. */
/* :- implementation. */

#include "code_table4.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.enum.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "mercury.ops.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.term.h"
#include "mercury.time.h"
#include "mercury.tree234.h"
#include "util.h"



static const MR_FO_PseudoTypeInfo_Struct1 code_table4__array__type_info_array_1__type0_7___int_0;



const MR_TypeCtorInfo_Struct code_table4__code_table4__type_ctor_info_key_0 = {
		(MR_Integer) 0,
		((MR_Box) (code_table4____Unify____key_0_0)),
		((MR_Box) (code_table4____Unify____key_0_0)),
		((MR_Box) (code_table4____Compare____key_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "code_table4",
		(MR_String) "key",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&mercury__builtin____type_ctor_info_int_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct code_table4__code_table4__type_ctor_info_hash_0 = {
		(MR_Integer) 0,
		((MR_Box) (code_table4____Unify____hash_0_0)),
		((MR_Box) (code_table4____Unify____hash_0_0)),
		((MR_Box) (code_table4____Compare____hash_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "code_table4",
		(MR_String) "hash",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&mercury__builtin____type_ctor_info_int_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct code_table4__code_table4__type_ctor_info_code_table_0 = {
		(MR_Integer) 0,
		((MR_Box) (code_table4____Unify____code_table_0_0)),
		((MR_Box) (code_table4____Unify____code_table_0_0)),
		((MR_Box) (code_table4____Compare____code_table_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "code_table4",
		(MR_String) "code_table",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&code_table4__array__type_info_array_1__type0_7___int_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
static const MR_FO_PseudoTypeInfo_Struct1 code_table4__array__type_info_array_1__type0_7___int_0 = {
		(&mercury__array__array__type_ctor_info_array_1),
		{
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0)}};

#line 19 "code_table4.m"
void MR_CALL code_table4____Compare____key_0_0(
#line 19 "code_table4.m"
  MR_Word * code_table4__HeadVar__1_1,
#line 19 "code_table4.m"
  MR_Word code_table4__HeadVar__2_2,
#line 19 "code_table4.m"
  MR_Word code_table4__HeadVar__3_3)
#line 19 "code_table4.m"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  {
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    bool code_table4__succeeded;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Integer code_table4__conv1_HeadVar__2_2 = (MR_Integer) code_table4__HeadVar__2_2;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Integer code_table4__conv2_HeadVar__3_3 = (MR_Integer) code_table4__HeadVar__3_3;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    code_table4__succeeded = (code_table4__conv1_HeadVar__2_2 < code_table4__conv2_HeadVar__3_3);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (code_table4__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *code_table4__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        code_table4__succeeded = (code_table4__conv1_HeadVar__2_2 == code_table4__conv2_HeadVar__3_3);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (code_table4__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *code_table4__HeadVar__1_1 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *code_table4__HeadVar__1_1 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  }
#line 19 "code_table4.m"
}

#line 19 "code_table4.m"
bool MR_CALL code_table4____Unify____key_0_0(
#line 19 "code_table4.m"
  MR_Word code_table4__HeadVar__1_1,
#line 19 "code_table4.m"
  MR_Word code_table4__HeadVar__2_2)
#line 19 "code_table4.m"
{
#line 41 "code_table4.m"
  {
#line 41 "code_table4.m"
    bool code_table4__succeeded;
#line 41 "code_table4.m"
    MR_Integer code_table4__conv1_HeadVar__1_1 = (MR_Integer) code_table4__HeadVar__1_1;
#line 41 "code_table4.m"
    MR_Integer code_table4__conv2_HeadVar__2_2 = (MR_Integer) code_table4__HeadVar__2_2;

#line 41 "code_table4.m"
    code_table4__succeeded = (code_table4__conv1_HeadVar__1_1 == code_table4__conv2_HeadVar__2_2);
#line 41 "code_table4.m"
    if (code_table4__succeeded)
#line 41 "code_table4.m"
      code_table4__succeeded = TRUE;
#line 41 "code_table4.m"
    return code_table4__succeeded;
#line 41 "code_table4.m"
  }
#line 19 "code_table4.m"
}

#line 17 "code_table4.m"
void MR_CALL code_table4____Compare____hash_0_0(
#line 17 "code_table4.m"
  MR_Word * code_table4__HeadVar__1_1,
#line 17 "code_table4.m"
  MR_Word code_table4__HeadVar__2_2,
#line 17 "code_table4.m"
  MR_Word code_table4__HeadVar__3_3)
#line 17 "code_table4.m"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  {
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    bool code_table4__succeeded;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Integer code_table4__conv1_HeadVar__2_2 = (MR_Integer) code_table4__HeadVar__2_2;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Integer code_table4__conv2_HeadVar__3_3 = (MR_Integer) code_table4__HeadVar__3_3;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    code_table4__succeeded = (code_table4__conv1_HeadVar__2_2 < code_table4__conv2_HeadVar__3_3);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (code_table4__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *code_table4__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        code_table4__succeeded = (code_table4__conv1_HeadVar__2_2 == code_table4__conv2_HeadVar__3_3);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (code_table4__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *code_table4__HeadVar__1_1 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *code_table4__HeadVar__1_1 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  }
#line 17 "code_table4.m"
}

#line 17 "code_table4.m"
bool MR_CALL code_table4____Unify____hash_0_0(
#line 17 "code_table4.m"
  MR_Word code_table4__HeadVar__1_1,
#line 17 "code_table4.m"
  MR_Word code_table4__HeadVar__2_2)
#line 17 "code_table4.m"
{
#line 39 "code_table4.m"
  {
#line 39 "code_table4.m"
    bool code_table4__succeeded;
#line 39 "code_table4.m"
    MR_Integer code_table4__conv1_HeadVar__1_1 = (MR_Integer) code_table4__HeadVar__1_1;
#line 39 "code_table4.m"
    MR_Integer code_table4__conv2_HeadVar__2_2 = (MR_Integer) code_table4__HeadVar__2_2;

#line 39 "code_table4.m"
    code_table4__succeeded = (code_table4__conv1_HeadVar__1_1 == code_table4__conv2_HeadVar__2_2);
#line 39 "code_table4.m"
    if (code_table4__succeeded)
#line 39 "code_table4.m"
      code_table4__succeeded = TRUE;
#line 39 "code_table4.m"
    return code_table4__succeeded;
#line 39 "code_table4.m"
  }
#line 17 "code_table4.m"
}

#line 15 "code_table4.m"
void MR_CALL code_table4____Compare____code_table_0_0(
#line 15 "code_table4.m"
  MR_Word * code_table4__HeadVar__1_1,
#line 15 "code_table4.m"
  MR_Word code_table4__HeadVar__2_2,
#line 15 "code_table4.m"
  MR_Word code_table4__HeadVar__3_3)
#line 15 "code_table4.m"
{
  {
    bool code_table4__succeeded;
    MR_Array code_table4__conv1_HeadVar__2_2 = (MR_Array) code_table4__HeadVar__2_2;
    MR_Array code_table4__conv2_HeadVar__3_3 = (MR_Array) code_table4__HeadVar__3_3;
    MR_Word code_table4__TypeInfo_4_4 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);

#line 43 "code_table4.m"
    {
#line 43 "code_table4.m"
      mercury__array____Compare____array_1_0(code_table4__TypeInfo_4_4, code_table4__HeadVar__1_1, (MR_Array) code_table4__conv1_HeadVar__2_2, (MR_Array) code_table4__conv2_HeadVar__3_3);
#line 43 "code_table4.m"
      return;
    }
  }
#line 15 "code_table4.m"
}

#line 15 "code_table4.m"
bool MR_CALL code_table4____Unify____code_table_0_0(
#line 15 "code_table4.m"
  MR_Word code_table4__HeadVar__1_1,
#line 15 "code_table4.m"
  MR_Word code_table4__HeadVar__2_2)
#line 15 "code_table4.m"
{
  {
    bool code_table4__succeeded;
    MR_Array code_table4__conv1_HeadVar__1_1 = (MR_Array) code_table4__HeadVar__1_1;
    MR_Array code_table4__conv2_HeadVar__2_2 = (MR_Array) code_table4__HeadVar__2_2;
    MR_Word code_table4__TypeInfo_3_3 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);

#line 43 "code_table4.m"
    {
#line 43 "code_table4.m"
      code_table4__succeeded = mercury__array____Unify____array_1_0(code_table4__TypeInfo_3_3, (MR_Array) code_table4__conv1_HeadVar__1_1, (MR_Array) code_table4__conv2_HeadVar__2_2);
    }
    if (code_table4__succeeded)
      code_table4__succeeded = TRUE;
    return code_table4__succeeded;
  }
#line 15 "code_table4.m"
}

#line 87 "code_table4.m"
void MR_CALL code_table4__lookup_0_6_p_0(
#line 87 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1,
#line 87 "code_table4.m"
  MR_Integer code_table4__HeadVar__2_2,
#line 87 "code_table4.m"
  MR_Integer code_table4__HeadVar__3_3,
#line 87 "code_table4.m"
  MR_Array code_table4__HeadVar__4_4,
#line 87 "code_table4.m"
  MR_Integer * code_table4__HeadVar__5_5,
#line 87 "code_table4.m"
  MR_Integer * code_table4__HeadVar__6_6)
#line 87 "code_table4.m"
{
  {
    /* tailcall optimized into a loop */
  loop_top:;
    {
      bool code_table4__succeeded = (code_table4__HeadVar__2_2 <= code_table4__HeadVar__1_1);
      MR_Integer code_table4__H1_13;
      MR_Integer code_table4__K0_14;
      MR_Integer code_table4__V_17_17 = (code_table4__HeadVar__1_1 - code_table4__HeadVar__2_2);
      MR_Integer code_table4__V_18_18;
      MR_Word code_table4__TypeInfo_19_19;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      MR_Box code_table4__conv1_K0_14;

#line 90 "code_table4.m"
      if (code_table4__succeeded)
#line 90 "code_table4.m"
        code_table4__V_18_18 = (MR_Integer) 0;
#line 90 "code_table4.m"
      else
#line 46 "code_table4.m"
        code_table4__V_18_18 = (MR_Integer) 69001;
#line 90 "code_table4.m"
      code_table4__H1_13 = (code_table4__V_17_17 + code_table4__V_18_18);
      code_table4__TypeInfo_19_19 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
        mercury__array__lookup_3_p_0(code_table4__TypeInfo_19_19, (MR_Array) code_table4__HeadVar__4_4, code_table4__H1_13, &code_table4__conv1_K0_14);
      }
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      code_table4__K0_14 = ((MR_Integer) code_table4__conv1_K0_14);
#line 92 "code_table4.m"
      code_table4__succeeded = (code_table4__K0_14 == code_table4__HeadVar__3_3);
#line 92 "code_table4.m"
      if (!(code_table4__succeeded))
#line 92 "code_table4.m"
        {
          MR_Integer code_table4__V_31_31 = (MR_Integer) -1;

#line 92 "code_table4.m"
          code_table4__succeeded = (code_table4__K0_14 == code_table4__V_31_31);
#line 92 "code_table4.m"
        }
#line 95 "code_table4.m"
      if (code_table4__succeeded)
        {
          MR_Integer code_table4__V_15_15;
          MR_Word code_table4__TypeInfo_20_20;
          MR_Integer code_table4__V_27_27;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          MR_Box code_table4__conv2_HeadVar__6_6;

#line 93 "code_table4.m"
          *code_table4__HeadVar__5_5 = code_table4__H1_13;
#line 46 "code_table4.m"
          code_table4__V_27_27 = (MR_Integer) 69001;
#line 55 "code_table4.m"
          code_table4__V_15_15 = (code_table4__H1_13 + code_table4__V_27_27);
          code_table4__TypeInfo_20_20 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            mercury__array__lookup_3_p_0(code_table4__TypeInfo_20_20, (MR_Array) code_table4__HeadVar__4_4, code_table4__V_15_15, &code_table4__conv2_HeadVar__6_6);
          }
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          *code_table4__HeadVar__6_6 = ((MR_Integer) code_table4__conv2_HeadVar__6_6);
        }
#line 95 "code_table4.m"
      else
#line 96 "code_table4.m"
        {
#line 96 "code_table4.m"
          /* direct tailcall eliminated */
#line 96 "code_table4.m"
          {
#line 96 "code_table4.m"
            MR_Integer code_table4__HeadVar__1__tmp_copy_1 = code_table4__H1_13;

#line 96 "code_table4.m"
            code_table4__HeadVar__1_1 = code_table4__HeadVar__1__tmp_copy_1;
#line 96 "code_table4.m"
          }
#line 96 "code_table4.m"
          goto loop_top;
#line 96 "code_table4.m"
        }
    }
  }
#line 87 "code_table4.m"
}

#line 60 "code_table4.m"
MR_Integer MR_CALL code_table4__hash_delta_2_f_0(
#line 60 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1)
#line 60 "code_table4.m"
{
#line 61 "code_table4.m"
  {
#line 61 "code_table4.m"
    bool code_table4__succeeded = (code_table4__HeadVar__1_1 == (MR_Integer) 0);
#line 61 "code_table4.m"
    MR_Integer code_table4__HeadVar__2_2;

#line 61 "code_table4.m"
    if (code_table4__succeeded)
#line 61 "code_table4.m"
      code_table4__HeadVar__2_2 = (MR_Integer) 1;
#line 61 "code_table4.m"
    else
      {
        MR_Integer code_table4__V_4_4 = (MR_Integer) 69001;

#line 61 "code_table4.m"
        code_table4__HeadVar__2_2 = (code_table4__V_4_4 - code_table4__HeadVar__1_1);
      }
#line 61 "code_table4.m"
    return code_table4__HeadVar__2_2;
#line 61 "code_table4.m"
  }
#line 60 "code_table4.m"
}

#line 57 "code_table4.m"
MR_Integer MR_CALL code_table4__hash_3_f_0(
#line 57 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1,
#line 57 "code_table4.m"
  MR_Integer code_table4__HeadVar__2_2)
#line 57 "code_table4.m"
{
  {
    bool code_table4__succeeded;
    MR_Integer code_table4__HeadVar__3_3;
    MR_Integer code_table4__V_6_6;
    MR_Integer code_table4__V_7_7 = (MR_Integer) 8;

#line 20 "util.opt"
    code_table4__V_6_6 = (code_table4__HeadVar__2_2 << code_table4__V_7_7);
#line 58 "code_table4.m"
    code_table4__HeadVar__3_3 = (code_table4__HeadVar__1_1 ^ code_table4__V_6_6);
    return code_table4__HeadVar__3_3;
  }
#line 57 "code_table4.m"
}

#line 54 "code_table4.m"
MR_Integer MR_CALL code_table4__code_idx_2_f_0(
#line 54 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1)
#line 54 "code_table4.m"
{
  {
    bool code_table4__succeeded;
    MR_Integer code_table4__HeadVar__2_2;
    MR_Integer code_table4__V_4_4 = (MR_Integer) 69001;

#line 55 "code_table4.m"
    code_table4__HeadVar__2_2 = (code_table4__HeadVar__1_1 + code_table4__V_4_4);
    return code_table4__HeadVar__2_2;
  }
#line 54 "code_table4.m"
}

#line 51 "code_table4.m"
MR_Integer MR_CALL code_table4__key_idx_2_f_0(
#line 51 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1)
#line 51 "code_table4.m"
{
#line 52 "code_table4.m"
  {
#line 52 "code_table4.m"
    bool code_table4__succeeded;
#line 52 "code_table4.m"
    MR_Integer code_table4__HeadVar__2_2 = code_table4__HeadVar__1_1;

#line 52 "code_table4.m"
    return code_table4__HeadVar__2_2;
#line 52 "code_table4.m"
  }
#line 51 "code_table4.m"
}

#line 48 "code_table4.m"
MR_Integer MR_CALL code_table4__array_size_1_f_0(void)
#line 48 "code_table4.m"
{
#line 49 "code_table4.m"
  {
#line 49 "code_table4.m"
    bool code_table4__succeeded;
#line 49 "code_table4.m"
    MR_Integer code_table4__HeadVar__1_1 = (MR_Integer) 138002;

#line 49 "code_table4.m"
    return code_table4__HeadVar__1_1;
#line 49 "code_table4.m"
  }
#line 48 "code_table4.m"
}

#line 45 "code_table4.m"
MR_Integer MR_CALL code_table4__table_size_1_f_0(void)
#line 45 "code_table4.m"
{
#line 46 "code_table4.m"
  {
#line 46 "code_table4.m"
    bool code_table4__succeeded;
#line 46 "code_table4.m"
    MR_Integer code_table4__HeadVar__1_1 = (MR_Integer) 69001;

#line 46 "code_table4.m"
    return code_table4__HeadVar__1_1;
#line 46 "code_table4.m"
  }
#line 45 "code_table4.m"
}

#line 30 "code_table4.m"
MR_Array MR_CALL code_table4__set_5_f_0(
#line 30 "code_table4.m"
  MR_Array code_table4__HeadVar__1_1,
#line 30 "code_table4.m"
  MR_Integer code_table4__HeadVar__2_2,
#line 30 "code_table4.m"
  MR_Integer code_table4__HeadVar__3_3,
#line 30 "code_table4.m"
  MR_Integer code_table4__HeadVar__4_4)
#line 30 "code_table4.m"
{
  {
    bool code_table4__succeeded;
    MR_Array code_table4__HeadVar__5_5;
    MR_Array code_table4__T1_11;
    MR_Integer code_table4__V_12_12;
    MR_Word code_table4__TypeInfo_14_14 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
    MR_Word code_table4__TypeInfo_15_15;
    MR_Integer code_table4__V_22_22;
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    MR_Array code_table4__conv1_T1_11;
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    MR_Array code_table4__conv2_HeadVar__5_5;

#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    {
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      mercury__array__set_4_p_0(code_table4__TypeInfo_14_14, (MR_Array) code_table4__HeadVar__1_1, code_table4__HeadVar__2_2, ((MR_Box) (code_table4__HeadVar__3_3)), &code_table4__conv1_T1_11);
    }
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    code_table4__T1_11 = (MR_Array) code_table4__conv1_T1_11;
#line 46 "code_table4.m"
    code_table4__V_22_22 = (MR_Integer) 69001;
#line 55 "code_table4.m"
    code_table4__V_12_12 = (code_table4__HeadVar__2_2 + code_table4__V_22_22);
    code_table4__TypeInfo_15_15 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    {
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      mercury__array__set_4_p_0(code_table4__TypeInfo_15_15, (MR_Array) code_table4__T1_11, code_table4__V_12_12, ((MR_Box) (code_table4__HeadVar__4_4)), &code_table4__conv2_HeadVar__5_5);
    }
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    code_table4__HeadVar__5_5 = (MR_Array) code_table4__conv2_HeadVar__5_5;
    return code_table4__HeadVar__5_5;
  }
#line 30 "code_table4.m"
}

#line 27 "code_table4.m"
void MR_CALL code_table4__lookup_6_p_0(
#line 27 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1,
#line 27 "code_table4.m"
  MR_Integer code_table4__HeadVar__2_2,
#line 27 "code_table4.m"
  MR_Array code_table4__HeadVar__3_3,
#line 27 "code_table4.m"
  MR_Integer * code_table4__HeadVar__4_4,
#line 27 "code_table4.m"
  MR_Integer * code_table4__HeadVar__5_5,
#line 27 "code_table4.m"
  MR_Integer * code_table4__HeadVar__6_6)
#line 27 "code_table4.m"
{
  {
    bool code_table4__succeeded;
    MR_Integer code_table4__H0_13;
    MR_Integer code_table4__K0_14;
    MR_Word code_table4__TypeInfo_18_18;
    MR_Integer code_table4__V_23_23;
    MR_Integer code_table4__V_24_24 = (MR_Integer) 8;
    MR_Integer code_table4__V_30_30;
    MR_Integer code_table4__V_31_31;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    MR_Box code_table4__conv1_K0_14;

#line 20 "util.opt"
    code_table4__V_23_23 = (code_table4__HeadVar__2_2 << code_table4__V_24_24);
#line 58 "code_table4.m"
    code_table4__H0_13 = (code_table4__HeadVar__1_1 ^ code_table4__V_23_23);
#line 65 "code_table4.m"
    code_table4__V_31_31 = (MR_Integer) 8;
#line 20 "util.opt"
    code_table4__V_30_30 = (code_table4__HeadVar__1_1 << code_table4__V_31_31);
#line 65 "code_table4.m"
    *code_table4__HeadVar__5_5 = (code_table4__V_30_30 | code_table4__HeadVar__2_2);
    code_table4__TypeInfo_18_18 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      mercury__array__lookup_3_p_0(code_table4__TypeInfo_18_18, (MR_Array) code_table4__HeadVar__3_3, code_table4__H0_13, &code_table4__conv1_K0_14);
    }
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    code_table4__K0_14 = ((MR_Integer) code_table4__conv1_K0_14);
#line 77 "code_table4.m"
    code_table4__succeeded = (code_table4__K0_14 == *code_table4__HeadVar__5_5);
#line 77 "code_table4.m"
    if (!(code_table4__succeeded))
#line 77 "code_table4.m"
      {
        MR_Integer code_table4__V_46_46 = (MR_Integer) -1;

#line 77 "code_table4.m"
        code_table4__succeeded = (code_table4__K0_14 == code_table4__V_46_46);
#line 77 "code_table4.m"
      }
#line 80 "code_table4.m"
    if (code_table4__succeeded)
      {
        MR_Integer code_table4__V_15_15;
        MR_Word code_table4__TypeInfo_19_19;
        MR_Integer code_table4__V_40_40;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
        MR_Box code_table4__conv2_HeadVar__6_6;

#line 78 "code_table4.m"
        *code_table4__HeadVar__4_4 = code_table4__H0_13;
#line 46 "code_table4.m"
        code_table4__V_40_40 = (MR_Integer) 69001;
#line 55 "code_table4.m"
        code_table4__V_15_15 = (code_table4__H0_13 + code_table4__V_40_40);
        code_table4__TypeInfo_19_19 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
        {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          mercury__array__lookup_3_p_0(code_table4__TypeInfo_19_19, (MR_Array) code_table4__HeadVar__3_3, code_table4__V_15_15, &code_table4__conv2_HeadVar__6_6);
        }
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
        *code_table4__HeadVar__6_6 = ((MR_Integer) code_table4__conv2_HeadVar__6_6);
      }
#line 80 "code_table4.m"
    else
      {
        MR_Integer code_table4__V_16_16;

#line 61 "code_table4.m"
        code_table4__succeeded = (code_table4__H0_13 == (MR_Integer) 0);
#line 61 "code_table4.m"
        if (code_table4__succeeded)
#line 61 "code_table4.m"
          code_table4__V_16_16 = (MR_Integer) 1;
#line 61 "code_table4.m"
        else
          {
            MR_Integer code_table4__V_45_45 = (MR_Integer) 69001;

#line 61 "code_table4.m"
            code_table4__V_16_16 = (code_table4__V_45_45 - code_table4__H0_13);
          }
#line 81 "code_table4.m"
        {
#line 81 "code_table4.m"
          code_table4__lookup_0_6_p_0(code_table4__H0_13, code_table4__V_16_16, *code_table4__HeadVar__5_5, code_table4__HeadVar__3_3, code_table4__HeadVar__4_4, code_table4__HeadVar__6_6);
#line 81 "code_table4.m"
          return;
        }
      }
  }
#line 27 "code_table4.m"
}

#line 24 "code_table4.m"
MR_Array MR_CALL code_table4__new_code_table_1_f_0(void)
#line 24 "code_table4.m"
{
  {
    bool code_table4__succeeded;
    MR_Array code_table4__HeadVar__1_1;
    MR_Integer code_table4__V_2_2 = (MR_Integer) 138002;
    MR_Integer code_table4__V_3_3 = (MR_Integer) -1;
    MR_Word code_table4__TypeInfo_4_4 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    MR_Array code_table4__conv1_HeadVar__1_1;

#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    {
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      mercury__array__init_3_p_0(code_table4__TypeInfo_4_4, code_table4__V_2_2, ((MR_Box) (code_table4__V_3_3)), &code_table4__conv1_HeadVar__1_1);
    }
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    code_table4__HeadVar__1_1 = (MR_Array) code_table4__conv1_HeadVar__1_1;
    return code_table4__HeadVar__1_1;
  }
#line 24 "code_table4.m"
}

#line 21 "code_table4.m"
MR_Integer MR_CALL code_table4__key_3_f_0(
#line 21 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1,
#line 21 "code_table4.m"
  MR_Integer code_table4__HeadVar__2_2)
#line 21 "code_table4.m"
{
  {
    bool code_table4__succeeded;
    MR_Integer code_table4__HeadVar__3_3;
    MR_Integer code_table4__V_6_6;
    MR_Integer code_table4__V_7_7 = (MR_Integer) 8;

#line 20 "util.opt"
    code_table4__V_6_6 = (code_table4__HeadVar__1_1 << code_table4__V_7_7);
#line 65 "code_table4.m"
    code_table4__HeadVar__3_3 = (code_table4__V_6_6 | code_table4__HeadVar__2_2);
    return code_table4__HeadVar__3_3;
  }
#line 21 "code_table4.m"
}

void mercury__code_table4__init(void)
{
}

void mercury__code_table4__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&code_table4__code_table4__type_ctor_info_key_0);
	MR_register_type_ctor_info(&code_table4__code_table4__type_ctor_info_hash_0);
	MR_register_type_ctor_info(&code_table4__code_table4__type_ctor_info_code_table_0);
}

void mercury__code_table4__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module code_table4. */
