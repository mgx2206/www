/*
** Automatically generated from `bitbuf2.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module bitbuf2. */
/* :- implementation. */

#include "bitbuf2.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.benchmarking.h"
#include "bmio.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "mercury.tree234.h"
#include "util.h"
#include "mercury.varset.h"



static const MR_DuFunctorDescPtr bitbuf2__bitbuf2__du_name_ordered_bitbuf_1[1];
static const MR_DuFunctorDesc bitbuf2__bitbuf2__du_functor_desc_bitbuf_1_0;
static const MR_ConstString bitbuf2__bitbuf2__field_names_bitbuf_1_0[5];
static const MR_PseudoTypeInfo bitbuf2__bitbuf2__field_types_bitbuf_1_0[5];
static const MR_FO_PseudoTypeInfo_Struct1 bitbuf2__store__type_info_store_1__var_1;
static const MR_FO_PseudoTypeInfo_Struct2 bitbuf2__store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1;
static const MR_DuPtagLayout bitbuf2__bitbuf2__du_ptag_ordered_bitbuf_1[1];
static const MR_DuFunctorDescPtr bitbuf2__bitbuf2__du_stag_ordered_bitbuf_1_0[1];
static /* final */ const MR_Box bitbuf2__const_0_0_1_TypeInfo_21_21[2];
static /* final */ const MR_Box bitbuf2__const_0_0_2_TypeClassInfo_for_store_23[3];
static /* final */ const MR_Box bitbuf2__const_0_0_3_TypeInfo_26_26[2];
static /* final */ const MR_Box bitbuf2__const_0_0_4_TypeClassInfo_for_store_28[3];
static /* final */ const MR_Box bitbuf2__const_0_0_5_TypeInfo_31_31[2];
static /* final */ const MR_Box bitbuf2__const_0_0_6_TypeClassInfo_for_store_33[3];
static /* final */ const MR_Box bitbuf2__const_0_0_7_TypeInfo_36_36[2];
static /* final */ const MR_Box bitbuf2__const_0_0_8_TypeClassInfo_for_store_38[3];
static /* final */ const MR_Box bitbuf2__const_0_0_9_TypeInfo_41_41[2];
static /* final */ const MR_Box bitbuf2__const_0_0_10_TypeClassInfo_for_store_43[3];



const MR_TypeCtorInfo_Struct bitbuf2__bitbuf2__type_ctor_info_bitbuf_1 = {
		(MR_Integer) 1,
		((MR_Box) (bitbuf2____Unify____bitbuf_1_0)),
		((MR_Box) (bitbuf2____Unify____bitbuf_1_0)),
		((MR_Box) (bitbuf2____Compare____bitbuf_1_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "bitbuf2",
		(MR_String) "bitbuf",
		(MR_Integer) 4,
		{
		(MR_Box) bitbuf2__bitbuf2__du_name_ordered_bitbuf_1},
		{
		(MR_Box) bitbuf2__bitbuf2__du_ptag_ordered_bitbuf_1},
		(MR_Integer) 1,
		(MR_Integer) 1};
static const MR_DuFunctorDescPtr bitbuf2__bitbuf2__du_name_ordered_bitbuf_1[1] = {
		(&bitbuf2__bitbuf2__du_functor_desc_bitbuf_1_0)};
static const MR_DuFunctorDesc bitbuf2__bitbuf2__du_functor_desc_bitbuf_1_0 = {
		(MR_String) "bitbuf",
		(MR_Integer) 5,
		(MR_Integer) 31,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		bitbuf2__bitbuf2__field_types_bitbuf_1_0,
		bitbuf2__bitbuf2__field_names_bitbuf_1_0,
		(MR_Box) NULL};
static const MR_ConstString bitbuf2__bitbuf2__field_names_bitbuf_1_0[5] = {
		(MR_String) "bits_in",
		(MR_String) "bits_out",
		(MR_String) "ratio",
		(MR_String) "data",
		(MR_String) "size"};
static const MR_PseudoTypeInfo bitbuf2__bitbuf2__field_types_bitbuf_1_0[5] = {
		(MR_PseudoTypeInfo) (&bitbuf2__store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1),
		(MR_PseudoTypeInfo) (&bitbuf2__store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1),
		(MR_PseudoTypeInfo) (&bitbuf2__store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1),
		(MR_PseudoTypeInfo) (&bitbuf2__store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1),
		(MR_PseudoTypeInfo) (&bitbuf2__store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1)};
static const MR_FO_PseudoTypeInfo_Struct1 bitbuf2__store__type_info_store_1__var_1 = {
		(&mercury__store__store__type_ctor_info_store_1),
		{
		(MR_PseudoTypeInfo) (MR_Integer) 1}};
static const MR_FO_PseudoTypeInfo_Struct2 bitbuf2__store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1 = {
		(&mercury__store__store__type_ctor_info_generic_mutvar_2),
		{
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0),
		(MR_PseudoTypeInfo) (&bitbuf2__store__type_info_store_1__var_1)}};
static const MR_DuPtagLayout bitbuf2__bitbuf2__du_ptag_ordered_bitbuf_1[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		bitbuf2__bitbuf2__du_stag_ordered_bitbuf_1_0}};
static const MR_DuFunctorDescPtr bitbuf2__bitbuf2__du_stag_ordered_bitbuf_1_0[1] = {
		(&bitbuf2__bitbuf2__du_functor_desc_bitbuf_1_0)};

#line 15 "bitbuf2.m"
void MR_CALL bitbuf2____Compare____bitbuf_1_0(
#line 15 "bitbuf2.m"
  MR_Word bitbuf2__TypeInfo_for_S_18,
#line 15 "bitbuf2.m"
  MR_Word * bitbuf2__HeadVar__1_1,
#line 15 "bitbuf2.m"
  MR_Word bitbuf2__HeadVar__2_2,
#line 15 "bitbuf2.m"
  MR_Word bitbuf2__HeadVar__3_3)
#line 15 "bitbuf2.m"
{
  {
    bool bitbuf2__succeeded;
    MR_Word bitbuf2__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word bitbuf2__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word bitbuf2__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word bitbuf2__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 3)));
    MR_Word bitbuf2__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 4)));
    MR_Word bitbuf2__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 0)));
    MR_Word bitbuf2__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 1)));
    MR_Word bitbuf2__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 2)));
    MR_Word bitbuf2__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 3)));
    MR_Word bitbuf2__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 4)));
#line 46 "bitbuf2.m"
    MR_Word bitbuf2__V_14_14;
    MR_Word bitbuf2__TypeInfo_19_19 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
    MR_Word bitbuf2__TypeInfo_20_20 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    MR_Word bitbuf2__TypeInfo_21_21;

    {
      bitbuf2__TypeInfo_21_21 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_21_21, 0) = ((MR_Box) (bitbuf2__TypeInfo_20_20));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_21_21, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_18));
    }
#line 46 "bitbuf2.m"
    {
#line 46 "bitbuf2.m"
      mercury__store____Compare____generic_mutvar_2_0(bitbuf2__TypeInfo_19_19, bitbuf2__TypeInfo_21_21, &bitbuf2__V_14_14, bitbuf2__V_4_4, bitbuf2__V_9_9);
    }
#line 46 "bitbuf2.m"
    bitbuf2__succeeded = (bitbuf2__V_14_14 == (MR_Integer) 0);
#line 46 "bitbuf2.m"
    bitbuf2__succeeded = !(bitbuf2__succeeded);
#line 46 "bitbuf2.m"
    if (bitbuf2__succeeded)
#line 46 "bitbuf2.m"
      *bitbuf2__HeadVar__1_1 = bitbuf2__V_14_14;
#line 46 "bitbuf2.m"
    else
#line 46 "bitbuf2.m"
      {
#line 46 "bitbuf2.m"
        MR_Word bitbuf2__V_15_15;
        MR_Word bitbuf2__TypeInfo_24_24 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
        MR_Word bitbuf2__TypeInfo_25_25 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
        MR_Word bitbuf2__TypeInfo_26_26;

        {
          bitbuf2__TypeInfo_26_26 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
          MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_26_26, 0) = ((MR_Box) (bitbuf2__TypeInfo_25_25));
          MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_26_26, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_18));
        }
#line 46 "bitbuf2.m"
        {
#line 46 "bitbuf2.m"
          mercury__store____Compare____generic_mutvar_2_0(bitbuf2__TypeInfo_24_24, bitbuf2__TypeInfo_26_26, &bitbuf2__V_15_15, bitbuf2__V_5_5, bitbuf2__V_10_10);
        }
#line 46 "bitbuf2.m"
        bitbuf2__succeeded = (bitbuf2__V_15_15 == (MR_Integer) 0);
#line 46 "bitbuf2.m"
        bitbuf2__succeeded = !(bitbuf2__succeeded);
#line 46 "bitbuf2.m"
        if (bitbuf2__succeeded)
#line 46 "bitbuf2.m"
          *bitbuf2__HeadVar__1_1 = bitbuf2__V_15_15;
#line 46 "bitbuf2.m"
        else
#line 46 "bitbuf2.m"
          {
#line 46 "bitbuf2.m"
            MR_Word bitbuf2__V_16_16;
            MR_Word bitbuf2__TypeInfo_29_29 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
            MR_Word bitbuf2__TypeInfo_30_30 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
            MR_Word bitbuf2__TypeInfo_31_31;

            {
              bitbuf2__TypeInfo_31_31 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
              MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_31_31, 0) = ((MR_Box) (bitbuf2__TypeInfo_30_30));
              MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_31_31, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_18));
            }
#line 46 "bitbuf2.m"
            {
#line 46 "bitbuf2.m"
              mercury__store____Compare____generic_mutvar_2_0(bitbuf2__TypeInfo_29_29, bitbuf2__TypeInfo_31_31, &bitbuf2__V_16_16, bitbuf2__V_6_6, bitbuf2__V_11_11);
            }
#line 46 "bitbuf2.m"
            bitbuf2__succeeded = (bitbuf2__V_16_16 == (MR_Integer) 0);
#line 46 "bitbuf2.m"
            bitbuf2__succeeded = !(bitbuf2__succeeded);
#line 46 "bitbuf2.m"
            if (bitbuf2__succeeded)
#line 46 "bitbuf2.m"
              *bitbuf2__HeadVar__1_1 = bitbuf2__V_16_16;
#line 46 "bitbuf2.m"
            else
#line 46 "bitbuf2.m"
              {
#line 46 "bitbuf2.m"
                MR_Word bitbuf2__V_17_17;
                MR_Word bitbuf2__TypeInfo_34_34 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
                MR_Word bitbuf2__TypeInfo_35_35 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
                MR_Word bitbuf2__TypeInfo_36_36;

                {
                  bitbuf2__TypeInfo_36_36 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
                  MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_36_36, 0) = ((MR_Box) (bitbuf2__TypeInfo_35_35));
                  MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_36_36, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_18));
                }
#line 46 "bitbuf2.m"
                {
#line 46 "bitbuf2.m"
                  mercury__store____Compare____generic_mutvar_2_0(bitbuf2__TypeInfo_34_34, bitbuf2__TypeInfo_36_36, &bitbuf2__V_17_17, bitbuf2__V_7_7, bitbuf2__V_12_12);
                }
#line 46 "bitbuf2.m"
                bitbuf2__succeeded = (bitbuf2__V_17_17 == (MR_Integer) 0);
#line 46 "bitbuf2.m"
                bitbuf2__succeeded = !(bitbuf2__succeeded);
#line 46 "bitbuf2.m"
                if (bitbuf2__succeeded)
#line 46 "bitbuf2.m"
                  *bitbuf2__HeadVar__1_1 = bitbuf2__V_17_17;
#line 46 "bitbuf2.m"
                else
                  {
                    MR_Word bitbuf2__TypeInfo_39_39 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
                    MR_Word bitbuf2__TypeInfo_40_40 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
                    MR_Word bitbuf2__TypeInfo_41_41;

                    {
                      bitbuf2__TypeInfo_41_41 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
                      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_41_41, 0) = ((MR_Box) (bitbuf2__TypeInfo_40_40));
                      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_41_41, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_18));
                    }
#line 46 "bitbuf2.m"
                    {
#line 46 "bitbuf2.m"
                      mercury__store____Compare____generic_mutvar_2_0(bitbuf2__TypeInfo_39_39, bitbuf2__TypeInfo_41_41, bitbuf2__HeadVar__1_1, bitbuf2__V_8_8, bitbuf2__V_13_13);
#line 46 "bitbuf2.m"
                      return;
                    }
                  }
#line 46 "bitbuf2.m"
              }
#line 46 "bitbuf2.m"
          }
#line 46 "bitbuf2.m"
      }
  }
#line 15 "bitbuf2.m"
}

#line 15 "bitbuf2.m"
bool MR_CALL bitbuf2____Unify____bitbuf_1_0(
#line 15 "bitbuf2.m"
  MR_Word bitbuf2__TypeInfo_for_S_13,
#line 15 "bitbuf2.m"
  MR_Word bitbuf2__HeadVar__1_1,
#line 15 "bitbuf2.m"
  MR_Word bitbuf2__HeadVar__2_2)
#line 15 "bitbuf2.m"
{
  {
    bool bitbuf2__succeeded;
    MR_Word bitbuf2__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word bitbuf2__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word bitbuf2__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 2)));
    MR_Word bitbuf2__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 3)));
    MR_Word bitbuf2__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 4)));
    MR_Word bitbuf2__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word bitbuf2__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word bitbuf2__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word bitbuf2__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 3)));
    MR_Word bitbuf2__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 4)));
    MR_Word bitbuf2__TypeInfo_14_14 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
    MR_Word bitbuf2__TypeInfo_15_15 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    MR_Word bitbuf2__TypeInfo_16_16;
    MR_Word bitbuf2__TypeInfo_19_19;
    MR_Word bitbuf2__TypeInfo_20_20;
    MR_Word bitbuf2__TypeInfo_21_21;
    MR_Word bitbuf2__TypeInfo_24_24;
    MR_Word bitbuf2__TypeInfo_25_25;
    MR_Word bitbuf2__TypeInfo_26_26;
    MR_Word bitbuf2__TypeInfo_29_29;
    MR_Word bitbuf2__TypeInfo_30_30;
    MR_Word bitbuf2__TypeInfo_31_31;
    MR_Word bitbuf2__TypeInfo_34_34;
    MR_Word bitbuf2__TypeInfo_35_35;
    MR_Word bitbuf2__TypeInfo_36_36;

    {
      bitbuf2__TypeInfo_16_16 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_16_16, 0) = ((MR_Box) (bitbuf2__TypeInfo_15_15));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_16_16, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_13));
    }
    {
      bitbuf2__succeeded = mercury__store____Unify____generic_mutvar_2_0(bitbuf2__TypeInfo_14_14, bitbuf2__TypeInfo_16_16, bitbuf2__V_3_3, bitbuf2__V_8_8);
    }
    if (bitbuf2__succeeded)
      {
        bitbuf2__TypeInfo_19_19 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
        bitbuf2__TypeInfo_20_20 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
        {
          bitbuf2__TypeInfo_21_21 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
          MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_21_21, 0) = ((MR_Box) (bitbuf2__TypeInfo_20_20));
          MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_21_21, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_13));
        }
        {
          bitbuf2__succeeded = mercury__store____Unify____generic_mutvar_2_0(bitbuf2__TypeInfo_19_19, bitbuf2__TypeInfo_21_21, bitbuf2__V_4_4, bitbuf2__V_9_9);
        }
        if (bitbuf2__succeeded)
          {
            bitbuf2__TypeInfo_24_24 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
            bitbuf2__TypeInfo_25_25 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
            {
              bitbuf2__TypeInfo_26_26 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
              MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_26_26, 0) = ((MR_Box) (bitbuf2__TypeInfo_25_25));
              MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_26_26, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_13));
            }
            {
              bitbuf2__succeeded = mercury__store____Unify____generic_mutvar_2_0(bitbuf2__TypeInfo_24_24, bitbuf2__TypeInfo_26_26, bitbuf2__V_5_5, bitbuf2__V_10_10);
            }
            if (bitbuf2__succeeded)
              {
                bitbuf2__TypeInfo_29_29 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
                bitbuf2__TypeInfo_30_30 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
                {
                  bitbuf2__TypeInfo_31_31 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
                  MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_31_31, 0) = ((MR_Box) (bitbuf2__TypeInfo_30_30));
                  MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_31_31, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_13));
                }
                {
                  bitbuf2__succeeded = mercury__store____Unify____generic_mutvar_2_0(bitbuf2__TypeInfo_29_29, bitbuf2__TypeInfo_31_31, bitbuf2__V_6_6, bitbuf2__V_11_11);
                }
                if (bitbuf2__succeeded)
                  {
                    bitbuf2__TypeInfo_34_34 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
                    bitbuf2__TypeInfo_35_35 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
                    {
                      bitbuf2__TypeInfo_36_36 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
                      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_36_36, 0) = ((MR_Box) (bitbuf2__TypeInfo_35_35));
                      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_36_36, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_13));
                    }
                    {
                      return bitbuf2__succeeded = mercury__store____Unify____generic_mutvar_2_0(bitbuf2__TypeInfo_34_34, bitbuf2__TypeInfo_36_36, bitbuf2__V_7_7, bitbuf2__V_12_12);
                    }
                  }
              }
          }
      }
    return bitbuf2__succeeded;
  }
#line 15 "bitbuf2.m"
}

#line 90 "bitbuf2.m"
void MR_CALL bitbuf2__write_full_bytes_6_p_0(
#line 90 "bitbuf2.m"
  MR_Integer bitbuf2__HeadVar__1_1,
#line 90 "bitbuf2.m"
  MR_Integer * bitbuf2__HeadVar__2_2,
#line 90 "bitbuf2.m"
  MR_Integer bitbuf2__HeadVar__3_3,
#line 90 "bitbuf2.m"
  MR_Integer * bitbuf2__HeadVar__4_4)
#line 90 "bitbuf2.m"
{
#line 93 "bitbuf2.m"
  {
#line 93 "bitbuf2.m"
    /* tailcall optimized into a loop */
#line 93 "bitbuf2.m"
  loop_top:;
#line 93 "bitbuf2.m"
    {
#line 93 "bitbuf2.m"
      bool bitbuf2__succeeded;
      MR_Integer bitbuf2__V_29_29 = (MR_Integer) 8;

#line 93 "bitbuf2.m"
      bitbuf2__succeeded = (bitbuf2__HeadVar__3_3 >= bitbuf2__V_29_29);
#line 93 "bitbuf2.m"
      if (bitbuf2__succeeded)
        {
          MR_Integer bitbuf2__V_15_15;
          MR_Integer bitbuf2__V_16_16;
          MR_Integer bitbuf2__V_17_17;
          MR_Integer bitbuf2__V_18_18;
          MR_Word bitbuf2__TypeInfo_7_22 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);

#line 144 "bmio.opt"
#line 144 "bmio.opt"
{
#line 144 "bmio.opt"
#define MR_PROC_LABEL bitbuf2__write_full_bytes_6_p_0
#line 144 "bmio.opt"

#line 144 "bmio.opt"
	MR_Word TypeInfo_for_Byte;
#line 144 "bmio.opt"
	MR_Word Byte;
#line 144 "bmio.opt"
	MR_Word IO0;
#line 144 "bmio.opt"
	MR_Word IO;
#line 144 "bmio.opt"

#line 144 "bmio.opt"
	TypeInfo_for_Byte = 
#line 144 "bmio.opt"
bitbuf2__TypeInfo_7_22
#line 144 "bmio.opt"
;
#line 144 "bmio.opt"
	Byte = (MR_Word) 
#line 144 "bmio.opt"
((MR_Box) (bitbuf2__HeadVar__1_1))
#line 144 "bmio.opt"
;
#line 144 "bmio.opt"
	IO0 = 
#line 144 "bmio.opt"
(MR_Integer) 0
#line 144 "bmio.opt"
;
#line 144 "bmio.opt"
#line 144 "bmio.opt"
		{
#line 144 "bmio.opt"


 /* if(bmio__wr_buf > bmio__wr_ptr || bmio__wr_ptr >= bmio__wr_eof) {
  fprintf(stderr, "bmio__wr_buf = %p
", bmio__wr_buf);
  fprintf(stderr, "bmio__wr_ptr = %p
", bmio__wr_ptr);
  fprintf(stderr, "bmio__wr_eof = %p
", bmio__wr_eof);
 } */

 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

	*bmio__wr_ptr++ = Byte;

	IO0 = IO;

#line 144 "bmio.opt"

		;}
#line 144 "bmio.opt"
#undef MR_PROC_LABEL
#line 144 "bmio.opt"
#line 144 "bmio.opt"
#line 144 "bmio.opt"
}
#line 95 "bitbuf2.m"
          bitbuf2__V_17_17 = (MR_Integer) 8;
#line 22 "util.opt"
          bitbuf2__V_15_15 = (bitbuf2__HeadVar__1_1 >> bitbuf2__V_17_17);
#line 95 "bitbuf2.m"
          bitbuf2__V_18_18 = (MR_Integer) 8;
#line 95 "bitbuf2.m"
          bitbuf2__V_16_16 = (bitbuf2__HeadVar__3_3 - bitbuf2__V_18_18);
#line 95 "bitbuf2.m"
          {
#line 95 "bitbuf2.m"
            /* direct tailcall eliminated */
#line 95 "bitbuf2.m"
            {
#line 95 "bitbuf2.m"
              MR_Integer bitbuf2__HeadVar__1__tmp_copy_1 = bitbuf2__V_15_15;
#line 95 "bitbuf2.m"
              MR_Integer bitbuf2__HeadVar__3__tmp_copy_3 = bitbuf2__V_16_16;

#line 95 "bitbuf2.m"
              bitbuf2__HeadVar__1_1 = bitbuf2__HeadVar__1__tmp_copy_1;
#line 95 "bitbuf2.m"
              bitbuf2__HeadVar__3_3 = bitbuf2__HeadVar__3__tmp_copy_3;
#line 95 "bitbuf2.m"
            }
#line 95 "bitbuf2.m"
            goto loop_top;
#line 95 "bitbuf2.m"
          }
        }
#line 93 "bitbuf2.m"
      else
        {
#line 97 "bitbuf2.m"
          *bitbuf2__HeadVar__2_2 = bitbuf2__HeadVar__1_1;
#line 98 "bitbuf2.m"
          *bitbuf2__HeadVar__4_4 = bitbuf2__HeadVar__3_3;
        }
#line 93 "bitbuf2.m"
    }
#line 93 "bitbuf2.m"
  }
#line 90 "bitbuf2.m"
}

#line 35 "bitbuf2.m"
void MR_CALL bitbuf2__flush_buffer_5_p_0(
#line 35 "bitbuf2.m"
  MR_Word bitbuf2__TypeInfo_for_S_17,
#line 35 "bitbuf2.m"
  MR_Word bitbuf2__HeadVar__1_1)
#line 35 "bitbuf2.m"
{
  {
    bool bitbuf2__succeeded;
    MR_Integer bitbuf2__Data_9;
    MR_Word bitbuf2__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 3)));
    MR_Word bitbuf2__TypeInfo_18_18 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    MR_Word bitbuf2__TypeInfo_19_19;
    MR_Word bitbuf2__TypeClassInfo_for_store_20;
    MR_Word bitbuf2__TypeClassInfo_for_store_21;
    MR_Word bitbuf2__TypeInfo_22_22;
    MR_Word bitbuf2__TypeInfo_7_30;
#line 119 "bitbuf2.m"
    MR_Word bitbuf2__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 2)));
#line 119 "bitbuf2.m"
    MR_Word bitbuf2__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 1)));
#line 119 "bitbuf2.m"
    MR_Word bitbuf2__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 0)));
#line 119 "bitbuf2.m"
    MR_Word bitbuf2__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 4)));
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv1_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv2_S;

    {
      bitbuf2__TypeInfo_19_19 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_19_19, 0) = ((MR_Box) (bitbuf2__TypeInfo_18_18));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_19_19, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_17));
    }
    bitbuf2__TypeClassInfo_for_store_20 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_21 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_21, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_20));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_21, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_17));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_21, 2) = ((MR_Box) (bitbuf2__TypeInfo_19_19));
    }
    bitbuf2__TypeInfo_22_22 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__flush_buffer_5_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_22_22
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_21
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_12_12
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv1_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv2_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    bitbuf2__Data_9 = ((MR_Integer) bitbuf2__conv1_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
    bitbuf2__TypeInfo_7_30 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 144 "bmio.opt"
#line 144 "bmio.opt"
{
#line 144 "bmio.opt"
#define MR_PROC_LABEL bitbuf2__flush_buffer_5_p_0
#line 144 "bmio.opt"

#line 144 "bmio.opt"
	MR_Word TypeInfo_for_Byte;
#line 144 "bmio.opt"
	MR_Word Byte;
#line 144 "bmio.opt"
	MR_Word IO0;
#line 144 "bmio.opt"
	MR_Word IO;
#line 144 "bmio.opt"

#line 144 "bmio.opt"
	TypeInfo_for_Byte = 
#line 144 "bmio.opt"
bitbuf2__TypeInfo_7_30
#line 144 "bmio.opt"
;
#line 144 "bmio.opt"
	Byte = (MR_Word) 
#line 144 "bmio.opt"
((MR_Box) (bitbuf2__Data_9))
#line 144 "bmio.opt"
;
#line 144 "bmio.opt"
	IO0 = 
#line 144 "bmio.opt"
(MR_Integer) 0
#line 144 "bmio.opt"
;
#line 144 "bmio.opt"
#line 144 "bmio.opt"
		{
#line 144 "bmio.opt"


 /* if(bmio__wr_buf > bmio__wr_ptr || bmio__wr_ptr >= bmio__wr_eof) {
  fprintf(stderr, "bmio__wr_buf = %p
", bmio__wr_buf);
  fprintf(stderr, "bmio__wr_ptr = %p
", bmio__wr_ptr);
  fprintf(stderr, "bmio__wr_eof = %p
", bmio__wr_eof);
 } */

 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

	*bmio__wr_ptr++ = Byte;

	IO0 = IO;

#line 144 "bmio.opt"

		;}
#line 144 "bmio.opt"
#undef MR_PROC_LABEL
#line 144 "bmio.opt"
#line 144 "bmio.opt"
#line 144 "bmio.opt"
}
  }
#line 35 "bitbuf2.m"
}

#line 32 "bitbuf2.m"
void MR_CALL bitbuf2__reset_compression_ratio_3_p_0(
#line 32 "bitbuf2.m"
  MR_Word bitbuf2__TypeInfo_for_S_27,
#line 32 "bitbuf2.m"
  MR_Word bitbuf2__HeadVar__1_1)
#line 32 "bitbuf2.m"
{
  {
    bool bitbuf2__succeeded;
    MR_Word bitbuf2__V_9_9;
    MR_Integer bitbuf2__V_10_10;
    MR_Word bitbuf2__V_11_11;
    MR_Integer bitbuf2__V_12_12;
    MR_Word bitbuf2__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 0)));
    MR_Integer bitbuf2__V_14_14 = (MR_Integer) 0;
    MR_Word bitbuf2__TypeInfo_28_28 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    MR_Word bitbuf2__TypeInfo_29_29;
    MR_Word bitbuf2__TypeClassInfo_for_store_30;
    MR_Word bitbuf2__TypeClassInfo_for_store_31;
    MR_Word bitbuf2__TypeInfo_32_32;
    MR_Word bitbuf2__TypeInfo_33_33;
    MR_Word bitbuf2__TypeInfo_34_34;
    MR_Word bitbuf2__TypeClassInfo_for_store_35;
    MR_Word bitbuf2__TypeClassInfo_for_store_36;
    MR_Word bitbuf2__TypeInfo_37_37;
    MR_Word bitbuf2__TypeInfo_38_38;
    MR_Word bitbuf2__TypeInfo_39_39;
    MR_Word bitbuf2__TypeClassInfo_for_store_40;
    MR_Word bitbuf2__TypeClassInfo_for_store_41;
    MR_Word bitbuf2__TypeInfo_42_42;
#line 112 "bitbuf2.m"
    MR_Word bitbuf2__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 4)));
#line 112 "bitbuf2.m"
    MR_Word bitbuf2__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 3)));
#line 112 "bitbuf2.m"
    MR_Word bitbuf2__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 2)));
#line 112 "bitbuf2.m"
    MR_Word bitbuf2__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 1)));
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv1_S;
#line 113 "bitbuf2.m"
    MR_Word bitbuf2__V_19_19;
#line 113 "bitbuf2.m"
    MR_Word bitbuf2__V_20_20;
#line 113 "bitbuf2.m"
    MR_Word bitbuf2__V_21_21;
#line 113 "bitbuf2.m"
    MR_Word bitbuf2__V_22_22;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv2_S;
#line 114 "bitbuf2.m"
    MR_Word bitbuf2__V_23_23;
#line 114 "bitbuf2.m"
    MR_Word bitbuf2__V_24_24;
#line 114 "bitbuf2.m"
    MR_Word bitbuf2__V_25_25;
#line 114 "bitbuf2.m"
    MR_Word bitbuf2__V_26_26;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv3_S;

    {
      bitbuf2__TypeInfo_29_29 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_29_29, 0) = ((MR_Box) (bitbuf2__TypeInfo_28_28));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_29_29, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_27));
    }
    bitbuf2__TypeClassInfo_for_store_30 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_31 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_31, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_30));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_31, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_27));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_31, 2) = ((MR_Box) (bitbuf2__TypeInfo_29_29));
    }
    bitbuf2__TypeInfo_32_32 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__reset_compression_ratio_3_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_32_32
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_31
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_13_13
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (bitbuf2__V_14_14))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv1_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 113 "bitbuf2.m"
    bitbuf2__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 0)));
#line 113 "bitbuf2.m"
    bitbuf2__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 1)));
#line 113 "bitbuf2.m"
    bitbuf2__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 2)));
#line 113 "bitbuf2.m"
    bitbuf2__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 3)));
#line 113 "bitbuf2.m"
    bitbuf2__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 4)));
#line 113 "bitbuf2.m"
    bitbuf2__V_12_12 = (MR_Integer) 0;
    bitbuf2__TypeInfo_33_33 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    {
      bitbuf2__TypeInfo_34_34 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_34_34, 0) = ((MR_Box) (bitbuf2__TypeInfo_33_33));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_34_34, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_27));
    }
    bitbuf2__TypeClassInfo_for_store_35 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_36 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_36, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_35));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_36, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_27));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_36, 2) = ((MR_Box) (bitbuf2__TypeInfo_34_34));
    }
    bitbuf2__TypeInfo_37_37 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__reset_compression_ratio_3_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_37_37
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_36
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_11_11
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (bitbuf2__V_12_12))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv2_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 114 "bitbuf2.m"
    bitbuf2__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 0)));
#line 114 "bitbuf2.m"
    bitbuf2__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 1)));
#line 114 "bitbuf2.m"
    bitbuf2__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 2)));
#line 114 "bitbuf2.m"
    bitbuf2__V_26_26 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 3)));
#line 114 "bitbuf2.m"
    bitbuf2__V_25_25 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 4)));
#line 114 "bitbuf2.m"
    bitbuf2__V_10_10 = (MR_Integer) 0;
    bitbuf2__TypeInfo_38_38 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    {
      bitbuf2__TypeInfo_39_39 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_39_39, 0) = ((MR_Box) (bitbuf2__TypeInfo_38_38));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_39_39, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_27));
    }
    bitbuf2__TypeClassInfo_for_store_40 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_41 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_41, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_40));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_41, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_27));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_41, 2) = ((MR_Box) (bitbuf2__TypeInfo_39_39));
    }
    bitbuf2__TypeInfo_42_42 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__reset_compression_ratio_3_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_42_42
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_41
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_9_9
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (bitbuf2__V_10_10))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv3_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
  }
#line 32 "bitbuf2.m"
}

#line 29 "bitbuf2.m"
void MR_CALL bitbuf2__compression_ratio_fallen_4_p_0(
#line 29 "bitbuf2.m"
  MR_Word bitbuf2__TypeInfo_for_S_30,
#line 29 "bitbuf2.m"
  MR_Word bitbuf2__HeadVar__1_1,
#line 29 "bitbuf2.m"
  MR_Word * bitbuf2__HeadVar__2_2)
#line 29 "bitbuf2.m"
{
  {
    bool bitbuf2__succeeded;
    MR_Integer bitbuf2__BitsIn_9;
    MR_Integer bitbuf2__BitsOut_11;
    MR_Integer bitbuf2__Ratio_13;
    MR_Word bitbuf2__V_15_15;
    MR_Word bitbuf2__V_16_16;
    MR_Word bitbuf2__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word bitbuf2__TypeInfo_31_31 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    MR_Word bitbuf2__TypeInfo_32_32;
    MR_Word bitbuf2__TypeClassInfo_for_store_33;
    MR_Word bitbuf2__TypeClassInfo_for_store_34;
    MR_Word bitbuf2__TypeInfo_35_35;
    MR_Word bitbuf2__TypeInfo_36_36;
    MR_Word bitbuf2__TypeInfo_37_37;
    MR_Word bitbuf2__TypeClassInfo_for_store_38;
    MR_Word bitbuf2__TypeClassInfo_for_store_39;
    MR_Word bitbuf2__TypeInfo_40_40;
    MR_Word bitbuf2__TypeInfo_41_41;
    MR_Word bitbuf2__TypeInfo_42_42;
    MR_Word bitbuf2__TypeClassInfo_for_store_43;
    MR_Word bitbuf2__TypeClassInfo_for_store_44;
    MR_Word bitbuf2__TypeInfo_45_45;
#line 104 "bitbuf2.m"
    MR_Word bitbuf2__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 4)));
#line 104 "bitbuf2.m"
    MR_Word bitbuf2__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 3)));
#line 104 "bitbuf2.m"
    MR_Word bitbuf2__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 2)));
#line 104 "bitbuf2.m"
    MR_Word bitbuf2__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 1)));
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv1_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv2_S;
#line 105 "bitbuf2.m"
    MR_Word bitbuf2__V_22_22;
#line 105 "bitbuf2.m"
    MR_Word bitbuf2__V_23_23;
#line 105 "bitbuf2.m"
    MR_Word bitbuf2__V_24_24;
#line 105 "bitbuf2.m"
    MR_Word bitbuf2__V_25_25;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv3_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv4_S;
#line 106 "bitbuf2.m"
    MR_Word bitbuf2__V_26_26;
#line 106 "bitbuf2.m"
    MR_Word bitbuf2__V_27_27;
#line 106 "bitbuf2.m"
    MR_Word bitbuf2__V_28_28;
#line 106 "bitbuf2.m"
    MR_Word bitbuf2__V_29_29;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv5_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv6_S;
    MR_Integer bitbuf2__V_14_14;
    MR_Integer bitbuf2__V_6_61;
    MR_Integer bitbuf2__V_7_62;

    {
      bitbuf2__TypeInfo_32_32 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_32_32, 0) = ((MR_Box) (bitbuf2__TypeInfo_31_31));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_32_32, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_30));
    }
    bitbuf2__TypeClassInfo_for_store_33 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_34 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_34, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_33));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_34, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_30));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_34, 2) = ((MR_Box) (bitbuf2__TypeInfo_32_32));
    }
    bitbuf2__TypeInfo_35_35 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__compression_ratio_fallen_4_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_35_35
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_34
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_17_17
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv1_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv2_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    bitbuf2__BitsIn_9 = ((MR_Integer) bitbuf2__conv1_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 105 "bitbuf2.m"
    bitbuf2__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 0)));
#line 105 "bitbuf2.m"
    bitbuf2__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 1)));
#line 105 "bitbuf2.m"
    bitbuf2__V_25_25 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 2)));
#line 105 "bitbuf2.m"
    bitbuf2__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 3)));
#line 105 "bitbuf2.m"
    bitbuf2__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 4)));
    bitbuf2__TypeInfo_36_36 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    {
      bitbuf2__TypeInfo_37_37 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_37_37, 0) = ((MR_Box) (bitbuf2__TypeInfo_36_36));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_37_37, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_30));
    }
    bitbuf2__TypeClassInfo_for_store_38 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_39 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_39, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_38));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_39, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_30));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_39, 2) = ((MR_Box) (bitbuf2__TypeInfo_37_37));
    }
    bitbuf2__TypeInfo_40_40 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__compression_ratio_fallen_4_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_40_40
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_39
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_16_16
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv3_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv4_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    bitbuf2__BitsOut_11 = ((MR_Integer) bitbuf2__conv3_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 106 "bitbuf2.m"
    bitbuf2__V_27_27 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 0)));
#line 106 "bitbuf2.m"
    bitbuf2__V_26_26 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 1)));
#line 106 "bitbuf2.m"
    bitbuf2__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 2)));
#line 106 "bitbuf2.m"
    bitbuf2__V_29_29 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 3)));
#line 106 "bitbuf2.m"
    bitbuf2__V_28_28 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__1_1, (MR_Integer) 4)));
    bitbuf2__TypeInfo_41_41 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    {
      bitbuf2__TypeInfo_42_42 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_42_42, 0) = ((MR_Box) (bitbuf2__TypeInfo_41_41));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_42_42, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_30));
    }
    bitbuf2__TypeClassInfo_for_store_43 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_44 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_44, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_43));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_44, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_30));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_44, 2) = ((MR_Box) (bitbuf2__TypeInfo_42_42));
    }
    bitbuf2__TypeInfo_45_45 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__compression_ratio_fallen_4_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_45_45
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_44
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_15_15
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv5_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv6_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    bitbuf2__Ratio_13 = ((MR_Integer) bitbuf2__conv5_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 25 "util.opt"
    bitbuf2__V_6_61 = (bitbuf2__BitsIn_9 - bitbuf2__BitsOut_11);
#line 26 "util.opt"
    bitbuf2__V_7_62 = (MR_Integer) 11;
#line 22 "util.opt"
    bitbuf2__V_14_14 = (bitbuf2__V_6_61 >> bitbuf2__V_7_62);
#line 107 "bitbuf2.m"
    bitbuf2__succeeded = (bitbuf2__V_14_14 < bitbuf2__Ratio_13);
#line 107 "bitbuf2.m"
    if (bitbuf2__succeeded)
#line 107 "bitbuf2.m"
      *bitbuf2__HeadVar__2_2 = (MR_Integer) 1;
#line 107 "bitbuf2.m"
    else
#line 107 "bitbuf2.m"
      *bitbuf2__HeadVar__2_2 = (MR_Integer) 0;
  }
#line 29 "bitbuf2.m"
}

#line 26 "bitbuf2.m"
void MR_CALL bitbuf2__write_code_7_p_0(
#line 26 "bitbuf2.m"
  MR_Word bitbuf2__TypeInfo_for_S_73,
#line 26 "bitbuf2.m"
  MR_Integer bitbuf2__HeadVar__1_1,
#line 26 "bitbuf2.m"
  MR_Integer bitbuf2__HeadVar__2_2,
#line 26 "bitbuf2.m"
  MR_Word bitbuf2__HeadVar__3_3)
#line 26 "bitbuf2.m"
{
  {
    bool bitbuf2__succeeded;
    MR_Integer bitbuf2__BitsIn_13;
    MR_Integer bitbuf2__BitsOut_15;
    MR_Integer bitbuf2__Data0_17;
    MR_Integer bitbuf2__Size0_19;
    MR_Integer bitbuf2__Data_21;
    MR_Integer bitbuf2__Size_22;
    MR_Word bitbuf2__V_28_28;
    MR_Word bitbuf2__V_29_29;
    MR_Word bitbuf2__V_30_30;
    MR_Integer bitbuf2__V_31_31;
    MR_Word bitbuf2__V_32_32;
    MR_Integer bitbuf2__V_33_33;
    MR_Integer bitbuf2__V_34_34;
    MR_Integer bitbuf2__V_35_35;
    MR_Integer bitbuf2__V_36_36;
    MR_Word bitbuf2__V_37_37;
    MR_Word bitbuf2__V_38_38;
    MR_Word bitbuf2__V_39_39;
    MR_Word bitbuf2__V_40_40 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 0)));
    MR_Word bitbuf2__TypeInfo_74_74 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    MR_Word bitbuf2__TypeInfo_75_75;
    MR_Word bitbuf2__TypeClassInfo_for_store_76;
    MR_Word bitbuf2__TypeClassInfo_for_store_77;
    MR_Word bitbuf2__TypeInfo_78_78;
    MR_Word bitbuf2__TypeInfo_79_79;
    MR_Word bitbuf2__TypeInfo_80_80;
    MR_Word bitbuf2__TypeClassInfo_for_store_81;
    MR_Word bitbuf2__TypeClassInfo_for_store_82;
    MR_Word bitbuf2__TypeInfo_83_83;
    MR_Word bitbuf2__TypeInfo_84_84;
    MR_Word bitbuf2__TypeInfo_85_85;
    MR_Word bitbuf2__TypeClassInfo_for_store_86;
    MR_Word bitbuf2__TypeClassInfo_for_store_87;
    MR_Word bitbuf2__TypeInfo_88_88;
    MR_Word bitbuf2__TypeInfo_89_89;
    MR_Word bitbuf2__TypeInfo_90_90;
    MR_Word bitbuf2__TypeClassInfo_for_store_91;
    MR_Word bitbuf2__TypeClassInfo_for_store_92;
    MR_Word bitbuf2__TypeInfo_93_93;
    MR_Word bitbuf2__TypeInfo_94_94;
    MR_Word bitbuf2__TypeInfo_95_95;
    MR_Word bitbuf2__TypeClassInfo_for_store_96;
    MR_Word bitbuf2__TypeClassInfo_for_store_97;
    MR_Word bitbuf2__TypeInfo_98_98;
    MR_Word bitbuf2__TypeInfo_99_99;
    MR_Word bitbuf2__TypeInfo_100_100;
    MR_Word bitbuf2__TypeClassInfo_for_store_101;
    MR_Word bitbuf2__TypeClassInfo_for_store_102;
    MR_Word bitbuf2__TypeInfo_103_103;
    MR_Word bitbuf2__TypeInfo_104_104;
    MR_Word bitbuf2__TypeInfo_105_105;
    MR_Word bitbuf2__TypeClassInfo_for_store_106;
    MR_Word bitbuf2__TypeClassInfo_for_store_107;
    MR_Word bitbuf2__TypeInfo_108_108;
    MR_Word bitbuf2__TypeInfo_109_109;
    MR_Word bitbuf2__TypeInfo_110_110;
    MR_Word bitbuf2__TypeClassInfo_for_store_111;
    MR_Word bitbuf2__TypeClassInfo_for_store_112;
    MR_Word bitbuf2__TypeInfo_113_113;
    MR_Integer bitbuf2__V_6_140;
    MR_Integer bitbuf2__V_7_141;
#line 75 "bitbuf2.m"
    MR_Word bitbuf2__V_41_41 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 4)));
#line 75 "bitbuf2.m"
    MR_Word bitbuf2__V_42_42 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 3)));
#line 75 "bitbuf2.m"
    MR_Word bitbuf2__V_43_43 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 2)));
#line 75 "bitbuf2.m"
    MR_Word bitbuf2__V_44_44 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 1)));
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv1_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv2_S;
#line 76 "bitbuf2.m"
    MR_Word bitbuf2__V_45_45;
#line 76 "bitbuf2.m"
    MR_Word bitbuf2__V_46_46;
#line 76 "bitbuf2.m"
    MR_Word bitbuf2__V_47_47;
#line 76 "bitbuf2.m"
    MR_Word bitbuf2__V_48_48;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv3_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv4_S;
#line 77 "bitbuf2.m"
    MR_Word bitbuf2__V_49_49;
#line 77 "bitbuf2.m"
    MR_Word bitbuf2__V_50_50;
#line 77 "bitbuf2.m"
    MR_Word bitbuf2__V_51_51;
#line 77 "bitbuf2.m"
    MR_Word bitbuf2__V_52_52;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv5_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv6_S;
#line 78 "bitbuf2.m"
    MR_Word bitbuf2__V_53_53;
#line 78 "bitbuf2.m"
    MR_Word bitbuf2__V_54_54;
#line 78 "bitbuf2.m"
    MR_Word bitbuf2__V_55_55;
#line 78 "bitbuf2.m"
    MR_Word bitbuf2__V_56_56;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv7_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv8_S;
#line 82 "bitbuf2.m"
    MR_Word bitbuf2__V_57_57;
#line 82 "bitbuf2.m"
    MR_Word bitbuf2__V_58_58;
#line 82 "bitbuf2.m"
    MR_Word bitbuf2__V_59_59;
#line 82 "bitbuf2.m"
    MR_Word bitbuf2__V_60_60;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv9_S;
#line 83 "bitbuf2.m"
    MR_Word bitbuf2__V_61_61;
#line 83 "bitbuf2.m"
    MR_Word bitbuf2__V_62_62;
#line 83 "bitbuf2.m"
    MR_Word bitbuf2__V_63_63;
#line 83 "bitbuf2.m"
    MR_Word bitbuf2__V_64_64;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv10_S;
#line 84 "bitbuf2.m"
    MR_Word bitbuf2__V_65_65;
#line 84 "bitbuf2.m"
    MR_Word bitbuf2__V_66_66;
#line 84 "bitbuf2.m"
    MR_Word bitbuf2__V_67_67;
#line 84 "bitbuf2.m"
    MR_Word bitbuf2__V_68_68;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv11_S;
#line 85 "bitbuf2.m"
    MR_Word bitbuf2__V_69_69;
#line 85 "bitbuf2.m"
    MR_Word bitbuf2__V_70_70;
#line 85 "bitbuf2.m"
    MR_Word bitbuf2__V_71_71;
#line 85 "bitbuf2.m"
    MR_Word bitbuf2__V_72_72;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv12_S;

    {
      bitbuf2__TypeInfo_75_75 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_75_75, 0) = ((MR_Box) (bitbuf2__TypeInfo_74_74));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_75_75, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
    }
    bitbuf2__TypeClassInfo_for_store_76 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_77 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_77, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_76));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_77, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_77, 2) = ((MR_Box) (bitbuf2__TypeInfo_75_75));
    }
    bitbuf2__TypeInfo_78_78 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__write_code_7_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_78_78
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_77
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_40_40
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv1_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv2_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    bitbuf2__BitsIn_13 = ((MR_Integer) bitbuf2__conv1_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 76 "bitbuf2.m"
    bitbuf2__V_45_45 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 0)));
#line 76 "bitbuf2.m"
    bitbuf2__V_39_39 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 1)));
#line 76 "bitbuf2.m"
    bitbuf2__V_48_48 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 2)));
#line 76 "bitbuf2.m"
    bitbuf2__V_47_47 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 3)));
#line 76 "bitbuf2.m"
    bitbuf2__V_46_46 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 4)));
    bitbuf2__TypeInfo_79_79 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    {
      bitbuf2__TypeInfo_80_80 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_80_80, 0) = ((MR_Box) (bitbuf2__TypeInfo_79_79));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_80_80, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
    }
    bitbuf2__TypeClassInfo_for_store_81 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_82 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_82, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_81));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_82, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_82, 2) = ((MR_Box) (bitbuf2__TypeInfo_80_80));
    }
    bitbuf2__TypeInfo_83_83 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__write_code_7_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_83_83
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_82
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_39_39
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv3_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv4_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    bitbuf2__BitsOut_15 = ((MR_Integer) bitbuf2__conv3_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 77 "bitbuf2.m"
    bitbuf2__V_51_51 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 0)));
#line 77 "bitbuf2.m"
    bitbuf2__V_50_50 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 1)));
#line 77 "bitbuf2.m"
    bitbuf2__V_49_49 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 2)));
#line 77 "bitbuf2.m"
    bitbuf2__V_38_38 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 3)));
#line 77 "bitbuf2.m"
    bitbuf2__V_52_52 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 4)));
    bitbuf2__TypeInfo_84_84 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    {
      bitbuf2__TypeInfo_85_85 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_85_85, 0) = ((MR_Box) (bitbuf2__TypeInfo_84_84));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_85_85, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
    }
    bitbuf2__TypeClassInfo_for_store_86 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_87 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_87, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_86));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_87, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_87, 2) = ((MR_Box) (bitbuf2__TypeInfo_85_85));
    }
    bitbuf2__TypeInfo_88_88 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__write_code_7_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_88_88
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_87
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_38_38
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv5_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv6_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    bitbuf2__Data0_17 = ((MR_Integer) bitbuf2__conv5_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 78 "bitbuf2.m"
    bitbuf2__V_56_56 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 0)));
#line 78 "bitbuf2.m"
    bitbuf2__V_55_55 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 1)));
#line 78 "bitbuf2.m"
    bitbuf2__V_54_54 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 2)));
#line 78 "bitbuf2.m"
    bitbuf2__V_53_53 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 3)));
#line 78 "bitbuf2.m"
    bitbuf2__V_37_37 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 4)));
    bitbuf2__TypeInfo_89_89 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    {
      bitbuf2__TypeInfo_90_90 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_90_90, 0) = ((MR_Box) (bitbuf2__TypeInfo_89_89));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_90_90, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
    }
    bitbuf2__TypeClassInfo_for_store_91 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_92 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_92, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_91));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_92, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_92, 2) = ((MR_Box) (bitbuf2__TypeInfo_90_90));
    }
    bitbuf2__TypeInfo_93_93 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__write_code_7_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_93_93
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_92
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_37_37
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv7_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv8_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    bitbuf2__Size0_19 = ((MR_Integer) bitbuf2__conv7_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 20 "util.opt"
    bitbuf2__V_36_36 = (bitbuf2__HeadVar__1_1 << bitbuf2__Size0_19);
#line 80 "bitbuf2.m"
    bitbuf2__V_34_34 = (bitbuf2__Data0_17 | bitbuf2__V_36_36);
#line 80 "bitbuf2.m"
    bitbuf2__V_35_35 = (bitbuf2__Size0_19 + bitbuf2__HeadVar__2_2);
#line 80 "bitbuf2.m"
    {
#line 80 "bitbuf2.m"
      bitbuf2__write_full_bytes_6_p_0(bitbuf2__V_34_34, &bitbuf2__Data_21, bitbuf2__V_35_35, &bitbuf2__Size_22);
    }
#line 82 "bitbuf2.m"
    bitbuf2__V_57_57 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 0)));
#line 82 "bitbuf2.m"
    bitbuf2__V_32_32 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 1)));
#line 82 "bitbuf2.m"
    bitbuf2__V_60_60 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 2)));
#line 82 "bitbuf2.m"
    bitbuf2__V_59_59 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 3)));
#line 82 "bitbuf2.m"
    bitbuf2__V_58_58 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 4)));
#line 82 "bitbuf2.m"
    bitbuf2__V_33_33 = (bitbuf2__BitsOut_15 + bitbuf2__HeadVar__2_2);
    bitbuf2__TypeInfo_94_94 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    {
      bitbuf2__TypeInfo_95_95 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_95_95, 0) = ((MR_Box) (bitbuf2__TypeInfo_94_94));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_95_95, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
    }
    bitbuf2__TypeClassInfo_for_store_96 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_97 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_97, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_96));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_97, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_97, 2) = ((MR_Box) (bitbuf2__TypeInfo_95_95));
    }
    bitbuf2__TypeInfo_98_98 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__write_code_7_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_98_98
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_97
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_32_32
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (bitbuf2__V_33_33))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv9_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 83 "bitbuf2.m"
    bitbuf2__V_62_62 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 0)));
#line 83 "bitbuf2.m"
    bitbuf2__V_61_61 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 1)));
#line 83 "bitbuf2.m"
    bitbuf2__V_30_30 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 2)));
#line 83 "bitbuf2.m"
    bitbuf2__V_64_64 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 3)));
#line 83 "bitbuf2.m"
    bitbuf2__V_63_63 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 4)));
#line 25 "util.opt"
    bitbuf2__V_6_140 = (bitbuf2__BitsIn_13 - bitbuf2__BitsOut_15);
#line 26 "util.opt"
    bitbuf2__V_7_141 = (MR_Integer) 11;
#line 22 "util.opt"
    bitbuf2__V_31_31 = (bitbuf2__V_6_140 >> bitbuf2__V_7_141);
    bitbuf2__TypeInfo_99_99 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    {
      bitbuf2__TypeInfo_100_100 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_100_100, 0) = ((MR_Box) (bitbuf2__TypeInfo_99_99));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_100_100, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
    }
    bitbuf2__TypeClassInfo_for_store_101 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_102 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_102, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_101));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_102, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_102, 2) = ((MR_Box) (bitbuf2__TypeInfo_100_100));
    }
    bitbuf2__TypeInfo_103_103 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__write_code_7_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_103_103
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_102
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_30_30
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (bitbuf2__V_31_31))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv10_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 84 "bitbuf2.m"
    bitbuf2__V_67_67 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 0)));
#line 84 "bitbuf2.m"
    bitbuf2__V_66_66 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 1)));
#line 84 "bitbuf2.m"
    bitbuf2__V_65_65 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 2)));
#line 84 "bitbuf2.m"
    bitbuf2__V_29_29 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 3)));
#line 84 "bitbuf2.m"
    bitbuf2__V_68_68 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 4)));
    bitbuf2__TypeInfo_104_104 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    {
      bitbuf2__TypeInfo_105_105 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_105_105, 0) = ((MR_Box) (bitbuf2__TypeInfo_104_104));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_105_105, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
    }
    bitbuf2__TypeClassInfo_for_store_106 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_107 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_107, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_106));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_107, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_107, 2) = ((MR_Box) (bitbuf2__TypeInfo_105_105));
    }
    bitbuf2__TypeInfo_108_108 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__write_code_7_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_108_108
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_107
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_29_29
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (bitbuf2__Data_21))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv11_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 85 "bitbuf2.m"
    bitbuf2__V_72_72 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 0)));
#line 85 "bitbuf2.m"
    bitbuf2__V_71_71 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 1)));
#line 85 "bitbuf2.m"
    bitbuf2__V_70_70 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 2)));
#line 85 "bitbuf2.m"
    bitbuf2__V_69_69 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 3)));
#line 85 "bitbuf2.m"
    bitbuf2__V_28_28 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__3_3, (MR_Integer) 4)));
    bitbuf2__TypeInfo_109_109 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    {
      bitbuf2__TypeInfo_110_110 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_110_110, 0) = ((MR_Box) (bitbuf2__TypeInfo_109_109));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_110_110, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
    }
    bitbuf2__TypeClassInfo_for_store_111 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_112 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_112, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_111));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_112, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_73));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_112, 2) = ((MR_Box) (bitbuf2__TypeInfo_110_110));
    }
    bitbuf2__TypeInfo_113_113 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__write_code_7_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_113_113
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_112
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_28_28
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (bitbuf2__Size_22))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv12_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
  }
#line 26 "bitbuf2.m"
}

#line 22 "bitbuf2.m"
void MR_CALL bitbuf2__read_byte_6_p_0(
#line 22 "bitbuf2.m"
  MR_Word bitbuf2__TypeInfo_for_S_27,
#line 22 "bitbuf2.m"
  MR_Word * bitbuf2__HeadVar__1_1,
#line 22 "bitbuf2.m"
  MR_Word bitbuf2__HeadVar__2_2)
#line 22 "bitbuf2.m"
{
  {
    bool bitbuf2__succeeded;
    MR_Integer bitbuf2__BitsIn_11;
    MR_Word bitbuf2__V_15_15;
    MR_Integer bitbuf2__V_16_16;
    MR_Integer bitbuf2__V_17_17;
    MR_Word bitbuf2__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word bitbuf2__TypeInfo_28_28 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    MR_Word bitbuf2__TypeInfo_29_29;
    MR_Word bitbuf2__TypeClassInfo_for_store_30;
    MR_Word bitbuf2__TypeClassInfo_for_store_31;
    MR_Word bitbuf2__TypeInfo_32_32;
    MR_Word bitbuf2__TypeInfo_33_33;
    MR_Word bitbuf2__TypeInfo_34_34;
    MR_Word bitbuf2__TypeClassInfo_for_store_35;
    MR_Word bitbuf2__TypeClassInfo_for_store_36;
    MR_Word bitbuf2__TypeInfo_37_37;
    MR_Integer bitbuf2__Byte_5_45;
#line 68 "bitbuf2.m"
    MR_Word bitbuf2__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 4)));
#line 68 "bitbuf2.m"
    MR_Word bitbuf2__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 3)));
#line 68 "bitbuf2.m"
    MR_Word bitbuf2__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 2)));
#line 68 "bitbuf2.m"
    MR_Word bitbuf2__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 1)));
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv1_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv2_S;
#line 70 "bitbuf2.m"
    MR_Word bitbuf2__V_23_23;
#line 70 "bitbuf2.m"
    MR_Word bitbuf2__V_24_24;
#line 70 "bitbuf2.m"
    MR_Word bitbuf2__V_25_25;
#line 70 "bitbuf2.m"
    MR_Word bitbuf2__V_26_26;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv3_S;

    {
      bitbuf2__TypeInfo_29_29 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_29_29, 0) = ((MR_Box) (bitbuf2__TypeInfo_28_28));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_29_29, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_27));
    }
    bitbuf2__TypeClassInfo_for_store_30 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_31 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_31, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_30));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_31, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_27));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_31, 2) = ((MR_Box) (bitbuf2__TypeInfo_29_29));
    }
    bitbuf2__TypeInfo_32_32 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__read_byte_6_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_32_32
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_31
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_18_18
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv1_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv2_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    bitbuf2__BitsIn_11 = ((MR_Integer) bitbuf2__conv1_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 132 "bmio.opt"
#line 132 "bmio.opt"
{
#line 132 "bmio.opt"
#define MR_PROC_LABEL bitbuf2__read_byte_6_p_0
#line 132 "bmio.opt"

#line 132 "bmio.opt"
	MR_Integer Byte;
#line 132 "bmio.opt"
	MR_Word IO0;
#line 132 "bmio.opt"
	MR_Word IO;
#line 132 "bmio.opt"

#line 132 "bmio.opt"
	IO0 = 
#line 132 "bmio.opt"
(MR_Integer) 0
#line 132 "bmio.opt"
;
#line 132 "bmio.opt"
#line 132 "bmio.opt"
		{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;

#line 132 "bmio.opt"

		;}
#line 132 "bmio.opt"
#undef MR_PROC_LABEL
#line 132 "bmio.opt"
#line 132 "bmio.opt"
	
#line 132 "bmio.opt"
bitbuf2__Byte_5_45
#line 132 "bmio.opt"
 = Byte;
#line 132 "bmio.opt"
#line 132 "bmio.opt"
}
#line 92 "bmio.opt"
    bitbuf2__succeeded = (bitbuf2__Byte_5_45 == (MR_Integer) -1);
#line 95 "bmio.opt"
    if (bitbuf2__succeeded)
#line 94 "bmio.opt"
      *bitbuf2__HeadVar__1_1 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 95 "bmio.opt"
    else
#line 96 "bmio.opt"
      {
#line 96 "bmio.opt"
        *bitbuf2__HeadVar__1_1 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "ok"));
#line 96 "bmio.opt"
        MR_hl_field(MR_mktag(1), *bitbuf2__HeadVar__1_1, 0) = ((MR_Box) (bitbuf2__Byte_5_45));
#line 96 "bmio.opt"
      }
#line 70 "bitbuf2.m"
    bitbuf2__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 0)));
#line 70 "bitbuf2.m"
    bitbuf2__V_26_26 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 1)));
#line 70 "bitbuf2.m"
    bitbuf2__V_25_25 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 2)));
#line 70 "bitbuf2.m"
    bitbuf2__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 3)));
#line 70 "bitbuf2.m"
    bitbuf2__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(0), bitbuf2__HeadVar__2_2, (MR_Integer) 4)));
#line 70 "bitbuf2.m"
    bitbuf2__V_17_17 = (MR_Integer) 8;
#line 70 "bitbuf2.m"
    bitbuf2__V_16_16 = (bitbuf2__BitsIn_11 + bitbuf2__V_17_17);
    bitbuf2__TypeInfo_33_33 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    {
      bitbuf2__TypeInfo_34_34 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_34_34, 0) = ((MR_Box) (bitbuf2__TypeInfo_33_33));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeInfo_34_34, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_27));
    }
    bitbuf2__TypeClassInfo_for_store_35 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      bitbuf2__TypeClassInfo_for_store_36 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_36, 0) = ((MR_Box) (bitbuf2__TypeClassInfo_for_store_35));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_36, 1) = ((MR_Box) (bitbuf2__TypeInfo_for_S_27));
      MR_hl_field(MR_mktag(0), bitbuf2__TypeClassInfo_for_store_36, 2) = ((MR_Box) (bitbuf2__TypeInfo_34_34));
    }
    bitbuf2__TypeInfo_37_37 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__read_byte_6_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_37_37
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_36
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__V_15_15
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (bitbuf2__V_16_16))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv3_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
  }
#line 22 "bitbuf2.m"
}
static /* final */ const MR_Box bitbuf2__const_0_0_1_TypeInfo_21_21[2] = {
		((MR_Box) ((&mercury__store__store__type_ctor_info_store_1))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0)))};
static /* final */ const MR_Box bitbuf2__const_0_0_2_TypeClassInfo_for_store_23[3] = {
		((MR_Box) ((&base_typeclass_info_store__store__arity1__store__store__arity1__))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0))),
		((MR_Box) (&bitbuf2__const_0_0_1_TypeInfo_21_21))};
static /* final */ const MR_Box bitbuf2__const_0_0_3_TypeInfo_26_26[2] = {
		((MR_Box) ((&mercury__store__store__type_ctor_info_store_1))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0)))};
static /* final */ const MR_Box bitbuf2__const_0_0_4_TypeClassInfo_for_store_28[3] = {
		((MR_Box) ((&base_typeclass_info_store__store__arity1__store__store__arity1__))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0))),
		((MR_Box) (&bitbuf2__const_0_0_3_TypeInfo_26_26))};
static /* final */ const MR_Box bitbuf2__const_0_0_5_TypeInfo_31_31[2] = {
		((MR_Box) ((&mercury__store__store__type_ctor_info_store_1))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0)))};
static /* final */ const MR_Box bitbuf2__const_0_0_6_TypeClassInfo_for_store_33[3] = {
		((MR_Box) ((&base_typeclass_info_store__store__arity1__store__store__arity1__))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0))),
		((MR_Box) (&bitbuf2__const_0_0_5_TypeInfo_31_31))};
static /* final */ const MR_Box bitbuf2__const_0_0_7_TypeInfo_36_36[2] = {
		((MR_Box) ((&mercury__store__store__type_ctor_info_store_1))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0)))};
static /* final */ const MR_Box bitbuf2__const_0_0_8_TypeClassInfo_for_store_38[3] = {
		((MR_Box) ((&base_typeclass_info_store__store__arity1__store__store__arity1__))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0))),
		((MR_Box) (&bitbuf2__const_0_0_7_TypeInfo_36_36))};
static /* final */ const MR_Box bitbuf2__const_0_0_9_TypeInfo_41_41[2] = {
		((MR_Box) ((&mercury__store__store__type_ctor_info_store_1))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0)))};
static /* final */ const MR_Box bitbuf2__const_0_0_10_TypeClassInfo_for_store_43[3] = {
		((MR_Box) ((&base_typeclass_info_store__store__arity1__store__store__arity1__))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0))),
		((MR_Box) (&bitbuf2__const_0_0_9_TypeInfo_41_41))};

#line 18 "bitbuf2.m"
void MR_CALL bitbuf2__new_bitbuf_2_p_0(
#line 18 "bitbuf2.m"
  MR_Word * bitbuf2__TypeInfo_for_S_19,
#line 18 "bitbuf2.m"
  MR_Word * bitbuf2__HeadVar__1_1)
#line 18 "bitbuf2.m"
{
  {
    bool bitbuf2__succeeded;
    MR_Word bitbuf2__A_3;
    MR_Word bitbuf2__B_4;
    MR_Word bitbuf2__C_5;
    MR_Word bitbuf2__D_6;
    MR_Word bitbuf2__E_7;
    MR_Integer bitbuf2__V_14_14;
    MR_Integer bitbuf2__V_15_15;
    MR_Integer bitbuf2__V_16_16;
    MR_Integer bitbuf2__V_17_17;
    MR_Integer bitbuf2__V_18_18;
    MR_Word bitbuf2__TypeInfo_20_20;
    MR_Word bitbuf2__TypeInfo_21_21;
    MR_Word bitbuf2__TypeClassInfo_for_store_22;
    MR_Word bitbuf2__TypeClassInfo_for_store_23;
    MR_Word bitbuf2__TypeInfo_24_24;
    MR_Word bitbuf2__TypeInfo_25_25;
    MR_Word bitbuf2__TypeInfo_26_26;
    MR_Word bitbuf2__TypeClassInfo_for_store_27;
    MR_Word bitbuf2__TypeClassInfo_for_store_28;
    MR_Word bitbuf2__TypeInfo_29_29;
    MR_Word bitbuf2__TypeInfo_30_30;
    MR_Word bitbuf2__TypeInfo_31_31;
    MR_Word bitbuf2__TypeClassInfo_for_store_32;
    MR_Word bitbuf2__TypeClassInfo_for_store_33;
    MR_Word bitbuf2__TypeInfo_34_34;
    MR_Word bitbuf2__TypeInfo_35_35;
    MR_Word bitbuf2__TypeInfo_36_36;
    MR_Word bitbuf2__TypeClassInfo_for_store_37;
    MR_Word bitbuf2__TypeClassInfo_for_store_38;
    MR_Word bitbuf2__TypeInfo_39_39;
    MR_Word bitbuf2__TypeInfo_40_40;
    MR_Word bitbuf2__TypeInfo_41_41;
    MR_Word bitbuf2__TypeClassInfo_for_store_42;
    MR_Word bitbuf2__TypeClassInfo_for_store_43;
    MR_Word bitbuf2__TypeInfo_44_44;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv1_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv2_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv3_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv4_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box bitbuf2__conv5_S;

#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__new_bitbuf_2_p_0
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
    *bitbuf2__TypeInfo_for_S_19 = (MR_Word) (&mercury__store__store__type_ctor_info_some_store_type_0);
#line 59 "bitbuf2.m"
    bitbuf2__V_18_18 = (MR_Integer) 0;
    bitbuf2__TypeInfo_20_20 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    bitbuf2__TypeInfo_21_21 = (MR_Word) &bitbuf2__const_0_0_1_TypeInfo_21_21;
    bitbuf2__TypeClassInfo_for_store_22 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    bitbuf2__TypeClassInfo_for_store_23 = (MR_Word) &bitbuf2__const_0_0_2_TypeClassInfo_for_store_23;
    bitbuf2__TypeInfo_24_24 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__new_bitbuf_2_p_0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_24_24
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_23
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (bitbuf2__V_18_18))
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__A_3
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv1_S
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 60 "bitbuf2.m"
    bitbuf2__V_17_17 = (MR_Integer) 0;
    bitbuf2__TypeInfo_25_25 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    bitbuf2__TypeInfo_26_26 = (MR_Word) &bitbuf2__const_0_0_3_TypeInfo_26_26;
    bitbuf2__TypeClassInfo_for_store_27 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    bitbuf2__TypeClassInfo_for_store_28 = (MR_Word) &bitbuf2__const_0_0_4_TypeClassInfo_for_store_28;
    bitbuf2__TypeInfo_29_29 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__new_bitbuf_2_p_0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_29_29
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_28
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (bitbuf2__V_17_17))
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__B_4
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv2_S
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 61 "bitbuf2.m"
    bitbuf2__V_16_16 = (MR_Integer) 0;
    bitbuf2__TypeInfo_30_30 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    bitbuf2__TypeInfo_31_31 = (MR_Word) &bitbuf2__const_0_0_5_TypeInfo_31_31;
    bitbuf2__TypeClassInfo_for_store_32 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    bitbuf2__TypeClassInfo_for_store_33 = (MR_Word) &bitbuf2__const_0_0_6_TypeClassInfo_for_store_33;
    bitbuf2__TypeInfo_34_34 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__new_bitbuf_2_p_0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_34_34
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_33
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (bitbuf2__V_16_16))
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__C_5
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv3_S
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 62 "bitbuf2.m"
    bitbuf2__V_15_15 = (MR_Integer) 0;
    bitbuf2__TypeInfo_35_35 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    bitbuf2__TypeInfo_36_36 = (MR_Word) &bitbuf2__const_0_0_7_TypeInfo_36_36;
    bitbuf2__TypeClassInfo_for_store_37 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    bitbuf2__TypeClassInfo_for_store_38 = (MR_Word) &bitbuf2__const_0_0_8_TypeClassInfo_for_store_38;
    bitbuf2__TypeInfo_39_39 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__new_bitbuf_2_p_0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_39_39
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_38
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (bitbuf2__V_15_15))
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__D_6
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv4_S
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 63 "bitbuf2.m"
    bitbuf2__V_14_14 = (MR_Integer) 0;
    bitbuf2__TypeInfo_40_40 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    bitbuf2__TypeInfo_41_41 = (MR_Word) &bitbuf2__const_0_0_9_TypeInfo_41_41;
    bitbuf2__TypeClassInfo_for_store_42 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    bitbuf2__TypeClassInfo_for_store_43 = (MR_Word) &bitbuf2__const_0_0_10_TypeClassInfo_for_store_43;
    bitbuf2__TypeInfo_44_44 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL bitbuf2__new_bitbuf_2_p_0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeInfo_44_44
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) bitbuf2__TypeClassInfo_for_store_43
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (bitbuf2__V_14_14))
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__E_7
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
bitbuf2__conv5_S
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 57 "bitbuf2.m"
    {
#line 57 "bitbuf2.m"
      *bitbuf2__HeadVar__1_1 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 5 * sizeof(MR_Word)), "bitbuf");
#line 57 "bitbuf2.m"
      MR_hl_field(MR_mktag(0), *bitbuf2__HeadVar__1_1, 0) = ((MR_Box) (bitbuf2__A_3));
#line 57 "bitbuf2.m"
      MR_hl_field(MR_mktag(0), *bitbuf2__HeadVar__1_1, 1) = ((MR_Box) (bitbuf2__B_4));
#line 57 "bitbuf2.m"
      MR_hl_field(MR_mktag(0), *bitbuf2__HeadVar__1_1, 2) = ((MR_Box) (bitbuf2__C_5));
#line 57 "bitbuf2.m"
      MR_hl_field(MR_mktag(0), *bitbuf2__HeadVar__1_1, 3) = ((MR_Box) (bitbuf2__D_6));
#line 57 "bitbuf2.m"
      MR_hl_field(MR_mktag(0), *bitbuf2__HeadVar__1_1, 4) = ((MR_Box) (bitbuf2__E_7));
#line 57 "bitbuf2.m"
    }
  }
#line 18 "bitbuf2.m"
}

void mercury__bitbuf2__init(void)
{
}

void mercury__bitbuf2__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&bitbuf2__bitbuf2__type_ctor_info_bitbuf_1);
}

void mercury__bitbuf2__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module bitbuf2. */
