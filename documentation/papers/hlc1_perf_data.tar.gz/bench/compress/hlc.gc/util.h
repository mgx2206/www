/*
** Automatically generated from `util.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module util. */
/* :- interface. */

#ifndef MR_HEADER_GUARD_util
#define MR_HEADER_GUARD_util

#ifdef __cplusplus
extern "C" {
#endif

#include "mercury.h"


#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif



extern const MR_TypeCtorInfo_Struct util__util__type_ctor_info_code_0;
extern const MR_TypeCtorInfo_Struct util__util__type_ctor_info_byte_0;
#line 19 "util.m"
void MR_CALL util____Compare____byte_0_0(
#line 19 "util.m"
  MR_Word * util__HeadVar__1_1,
#line 19 "util.m"
  MR_Word util__HeadVar__2_2,
#line 19 "util.m"
  MR_Word util__HeadVar__3_3);
#line 19 "util.m"
bool MR_CALL util____Unify____byte_0_0(
#line 19 "util.m"
  MR_Word util__HeadVar__1_1,
#line 19 "util.m"
  MR_Word util__HeadVar__2_2);
#line 17 "util.m"
void MR_CALL util____Compare____code_0_0(
#line 17 "util.m"
  MR_Word * util__HeadVar__1_1,
#line 17 "util.m"
  MR_Word util__HeadVar__2_2,
#line 17 "util.m"
  MR_Word util__HeadVar__3_3);
#line 17 "util.m"
bool MR_CALL util____Unify____code_0_0(
#line 17 "util.m"
  MR_Word util__HeadVar__1_1,
#line 17 "util.m"
  MR_Word util__HeadVar__2_2);
#line 37 "util.m"
MR_Integer MR_CALL util__ratio_3_f_0(
#line 37 "util.m"
  MR_Integer util__HeadVar__1_1,
#line 37 "util.m"
  MR_Integer util__HeadVar__2_2);
#line 35 "util.m"
MR_Integer MR_CALL util__rshift_3_f_0(
#line 35 "util.m"
  MR_Integer util__HeadVar__1_1,
#line 35 "util.m"
  MR_Integer util__HeadVar__2_2);
#line 33 "util.m"
MR_Integer MR_CALL util__lshift_3_f_0(
#line 33 "util.m"
  MR_Integer util__HeadVar__1_1,
#line 33 "util.m"
  MR_Integer util__HeadVar__2_2);
#line 31 "util.m"
MR_Integer MR_CALL util__update_bpc_3_f_0(
#line 31 "util.m"
  MR_Integer util__HeadVar__1_1,
#line 31 "util.m"
  MR_Integer util__HeadVar__2_2);
#line 29 "util.m"
MR_Integer MR_CALL util__initial_bpc_1_f_0(void);
#line 27 "util.m"
MR_Integer MR_CALL util__max_code_1_f_0(void);
#line 25 "util.m"
MR_Integer MR_CALL util__empty_code_1_f_0(void);
#line 23 "util.m"
MR_Integer MR_CALL util__clear_code_1_f_0(void);
#line 21 "util.m"
MR_Integer MR_CALL util__first_new_code_1_f_0(void);

void mercury__util__init(void);
void mercury__util__init_type_tables(void);
void mercury__util__init_debugger(void);

#ifdef __cplusplus
}
#endif

#endif /* MR_HEADER_GUARD_util */

/* :- end_interface util. */
