/*
** Automatically generated from `code_table4.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module code_table4. */
/* :- interface. */

#ifndef MR_HEADER_GUARD_code_table4
#define MR_HEADER_GUARD_code_table4

#ifdef __cplusplus
extern "C" {
#endif

#include "mercury.h"


#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

#ifdef MR_HIGHLEVEL_CODE
  bool MR_CALL mercury__array__do_unify__array_1_0(
  	MR_Mercury_Type_Info type_info, MR_Box x, MR_Box y);
  bool MR_CALL mercury__array____Unify____array_1_0(
	MR_Mercury_Type_Info type_info, MR_Array x, MR_Array y);
  void MR_CALL mercury__array__do_compare__array_1_0(MR_Mercury_Type_Info
 	 type_info, MR_Comparison_Result *result, MR_Box x, MR_Box y);
  void MR_CALL mercury__array____Compare____array_1_0(MR_Mercury_Type_Info
	type_info, MR_Comparison_Result *result, MR_Array x, MR_Array y);
#endif

#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

#include "mercury_heap.h"		/* for MR_maybe_record_allocation() */
#include "mercury_library_types.h"	/* for MR_ArrayType */

#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType *ML_make_array(MR_Integer size, MR_Word item);

#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType * ML_resize_array(MR_ArrayType *old_array,
					MR_Integer array_size, MR_Word item);

#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType * ML_shrink_array(MR_ArrayType *old_array,
					MR_Integer array_size);

#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType *ML_copy_array(MR_ArrayType *old_array);

#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif



extern const MR_TypeCtorInfo_Struct code_table4__code_table4__type_ctor_info_key_0;
extern const MR_TypeCtorInfo_Struct code_table4__code_table4__type_ctor_info_hash_0;
extern const MR_TypeCtorInfo_Struct code_table4__code_table4__type_ctor_info_code_table_0;
#line 19 "code_table4.m"
void MR_CALL code_table4____Compare____key_0_0(
#line 19 "code_table4.m"
  MR_Word * code_table4__HeadVar__1_1,
#line 19 "code_table4.m"
  MR_Word code_table4__HeadVar__2_2,
#line 19 "code_table4.m"
  MR_Word code_table4__HeadVar__3_3);
#line 19 "code_table4.m"
bool MR_CALL code_table4____Unify____key_0_0(
#line 19 "code_table4.m"
  MR_Word code_table4__HeadVar__1_1,
#line 19 "code_table4.m"
  MR_Word code_table4__HeadVar__2_2);
#line 17 "code_table4.m"
void MR_CALL code_table4____Compare____hash_0_0(
#line 17 "code_table4.m"
  MR_Word * code_table4__HeadVar__1_1,
#line 17 "code_table4.m"
  MR_Word code_table4__HeadVar__2_2,
#line 17 "code_table4.m"
  MR_Word code_table4__HeadVar__3_3);
#line 17 "code_table4.m"
bool MR_CALL code_table4____Unify____hash_0_0(
#line 17 "code_table4.m"
  MR_Word code_table4__HeadVar__1_1,
#line 17 "code_table4.m"
  MR_Word code_table4__HeadVar__2_2);
#line 15 "code_table4.m"
void MR_CALL code_table4____Compare____code_table_0_0(
#line 15 "code_table4.m"
  MR_Word * code_table4__HeadVar__1_1,
#line 15 "code_table4.m"
  MR_Word code_table4__HeadVar__2_2,
#line 15 "code_table4.m"
  MR_Word code_table4__HeadVar__3_3);
#line 15 "code_table4.m"
bool MR_CALL code_table4____Unify____code_table_0_0(
#line 15 "code_table4.m"
  MR_Word code_table4__HeadVar__1_1,
#line 15 "code_table4.m"
  MR_Word code_table4__HeadVar__2_2);
#line 87 "code_table4.m"
void MR_CALL code_table4__lookup_0_6_p_0(
#line 87 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1,
#line 87 "code_table4.m"
  MR_Integer code_table4__HeadVar__2_2,
#line 87 "code_table4.m"
  MR_Integer code_table4__HeadVar__3_3,
#line 87 "code_table4.m"
  MR_Array code_table4__HeadVar__4_4,
#line 87 "code_table4.m"
  MR_Integer * code_table4__HeadVar__5_5,
#line 87 "code_table4.m"
  MR_Integer * code_table4__HeadVar__6_6);
#line 60 "code_table4.m"
MR_Integer MR_CALL code_table4__hash_delta_2_f_0(
#line 60 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1);
#line 57 "code_table4.m"
MR_Integer MR_CALL code_table4__hash_3_f_0(
#line 57 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1,
#line 57 "code_table4.m"
  MR_Integer code_table4__HeadVar__2_2);
#line 54 "code_table4.m"
MR_Integer MR_CALL code_table4__code_idx_2_f_0(
#line 54 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1);
#line 51 "code_table4.m"
MR_Integer MR_CALL code_table4__key_idx_2_f_0(
#line 51 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1);
#line 48 "code_table4.m"
MR_Integer MR_CALL code_table4__array_size_1_f_0(void);
#line 45 "code_table4.m"
MR_Integer MR_CALL code_table4__table_size_1_f_0(void);
#line 30 "code_table4.m"
MR_Array MR_CALL code_table4__set_5_f_0(
#line 30 "code_table4.m"
  MR_Array code_table4__HeadVar__1_1,
#line 30 "code_table4.m"
  MR_Integer code_table4__HeadVar__2_2,
#line 30 "code_table4.m"
  MR_Integer code_table4__HeadVar__3_3,
#line 30 "code_table4.m"
  MR_Integer code_table4__HeadVar__4_4);
#line 27 "code_table4.m"
void MR_CALL code_table4__lookup_6_p_0(
#line 27 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1,
#line 27 "code_table4.m"
  MR_Integer code_table4__HeadVar__2_2,
#line 27 "code_table4.m"
  MR_Array code_table4__HeadVar__3_3,
#line 27 "code_table4.m"
  MR_Integer * code_table4__HeadVar__4_4,
#line 27 "code_table4.m"
  MR_Integer * code_table4__HeadVar__5_5,
#line 27 "code_table4.m"
  MR_Integer * code_table4__HeadVar__6_6);
#line 24 "code_table4.m"
MR_Array MR_CALL code_table4__new_code_table_1_f_0(void);
#line 21 "code_table4.m"
MR_Integer MR_CALL code_table4__key_3_f_0(
#line 21 "code_table4.m"
  MR_Integer code_table4__HeadVar__1_1,
#line 21 "code_table4.m"
  MR_Integer code_table4__HeadVar__2_2);

void mercury__code_table4__init(void);
void mercury__code_table4__init_type_tables(void);
void mercury__code_table4__init_debugger(void);

#ifdef __cplusplus
}
#endif

#endif /* MR_HEADER_GUARD_code_table4 */

/* :- end_interface code_table4. */
