/*
** Automatically generated from `harness.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module harness. */
/* :- implementation. */

#include "harness.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.benchmarking.h"
#include "mercury.bintree_set.h"
#include "bitbuf2.h"
#include "bmio.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "code_table4.h"
#include "compress5.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "mercury.tree234.h"
#include "util.h"
#include "mercury.varset.h"



#line 63 "harness.m"
static void MR_CALL harness__test_loop__ho2_4_p_0(
#line 63 "harness.m"
  MR_Integer harness__HeadVar__1_1);
#line 55 "harness.m"
static /* final */ const MR_Box harness__const_2_0_1_V_17_17[1];
#line 55 "harness.m"
static /* final */ const MR_Box harness__const_2_0_2_V_16_16[2];
#line 55 "harness.m"
static /* final */ const MR_Box harness__const_0_0_1_V_39_39[1];
#line 55 "harness.m"
static /* final */ const MR_Box harness__const_0_0_2_V_41_41[1];
#line 55 "harness.m"
static /* final */ const MR_Box harness__const_0_0_3_V_40_40[2];
#line 55 "harness.m"
static /* final */ const MR_Box harness__const_0_0_4_V_38_38[2];




#line 63 "harness.m"
static void MR_CALL harness__test_loop__ho2_4_p_0(
#line 63 "harness.m"
  MR_Integer harness__HeadVar__1_1)
#line 63 "harness.m"
{
#line 66 "harness.m"
  {
#line 66 "harness.m"
    /* tailcall optimized into a loop */
#line 66 "harness.m"
  loop_top:;
#line 66 "harness.m"
    {
#line 66 "harness.m"
      bool harness__succeeded;
      MR_Integer harness__V_38_38 = (MR_Integer) 0;

#line 66 "harness.m"
      harness__succeeded = (harness__HeadVar__1_1 > harness__V_38_38);
#line 66 "harness.m"
      if (harness__succeeded)
        {
          MR_Integer harness__V_13_13;
          MR_Integer harness__V_14_14;
          MR_Word harness__Buf_3_19;
          MR_Word harness__TypeInfo_7_21;
          MR_Word harness__Result_7_26;

#line 64 "bmio.opt"
#line 64 "bmio.opt"
{
#line 64 "bmio.opt"
#define MR_PROC_LABEL harness__test_loop__ho2_4_p_0
#line 64 "bmio.opt"

#line 64 "bmio.opt"
	MR_Word IO0;
#line 64 "bmio.opt"
	MR_Word IO;
#line 64 "bmio.opt"

#line 64 "bmio.opt"
	IO0 = 
#line 64 "bmio.opt"
(MR_Integer) 0
#line 64 "bmio.opt"
;
#line 64 "bmio.opt"
#line 64 "bmio.opt"
		{
#line 64 "bmio.opt"


	bmio__rd_buf = bmio__plain_buf;
	bmio__rd_ptr = bmio__plain_buf;
	bmio__rd_eof = bmio__plain_buf_eof;

	bmio__wr_buf = bmio__zipped_buf;
	bmio__wr_ptr = bmio__zipped_buf;
	bmio__wr_eof = bmio__zipped_buf_eof;

	IO0 = IO;

#line 64 "bmio.opt"

		;}
#line 64 "bmio.opt"
#undef MR_PROC_LABEL
#line 64 "bmio.opt"
#line 64 "bmio.opt"
#line 64 "bmio.opt"
}
#line 9 "compress5.opt"
          {
#line 9 "compress5.opt"
            bitbuf2__new_bitbuf_2_p_0(&harness__TypeInfo_7_21, &harness__Buf_3_19);
          }
#line 13 "compress5.opt"
          {
#line 13 "compress5.opt"
            bitbuf2__read_byte_6_p_0(harness__TypeInfo_7_21, &harness__Result_7_26, harness__Buf_3_19);
          }
#line 20 "compress5.opt"
#line 20 "compress5.opt"
          switch (MR_tag((MR_Word) harness__Result_7_26)) {
#line 20 "compress5.opt"
            default: /*NOTREACHED*/ MR_assert(0);
#line 20 "compress5.opt"
            case (MR_Integer) 0:
#line 22 "compress5.opt"
              {
#line 22 "compress5.opt"
              }
#line 20 "compress5.opt"
              break;
#line 20 "compress5.opt"
            case (MR_Integer) 1:
              {
                MR_Integer harness__B_9_29 = ((MR_Integer) (MR_hl_field(MR_mktag(1), harness__Result_7_26, (MR_Integer) 0)));
                MR_Integer harness__V_15_30;
                MR_Word harness__V_16_31;
                MR_Integer harness__V_17_32;

#line 16 "compress5.opt"
                {
#line 16 "compress5.opt"
                  harness__V_15_30 = util__first_new_code_1_f_0();
                }
#line 17 "compress5.opt"
                {
#line 17 "compress5.opt"
                  harness__V_16_31 = code_table4__new_code_table_1_f_0();
                }
#line 18 "compress5.opt"
                {
#line 18 "compress5.opt"
                  harness__V_17_32 = util__initial_bpc_1_f_0();
                }
#line 19 "compress5.opt"
                {
#line 19 "compress5.opt"
                  compress5__main_loop_8_p_0(harness__TypeInfo_7_21, harness__B_9_29, harness__V_15_30, harness__V_16_31, harness__V_17_32, harness__Buf_3_19);
                }
              }
#line 20 "compress5.opt"
              break;
#line 20 "compress5.opt"
            case (MR_Integer) 2:
              {
                MR_Word harness__ErrNo_10_33 = ((MR_Word) (MR_hl_field(MR_mktag(2), harness__Result_7_26, (MR_Integer) 0)));
                MR_String harness__V_14_34 = (MR_String) harness__ErrNo_10_33;

#line 26 "compress5.opt"
                {
#line 26 "compress5.opt"
                  mercury__require__error_1_p_0(harness__V_14_34);
                }
              }
#line 20 "compress5.opt"
              break;
#line 20 "compress5.opt"
          }
#line 69 "harness.m"
          harness__V_14_14 = (MR_Integer) 1;
#line 69 "harness.m"
          harness__V_13_13 = (harness__HeadVar__1_1 - harness__V_14_14);
#line 69 "harness.m"
          {
#line 69 "harness.m"
            /* direct tailcall eliminated */
#line 69 "harness.m"
            {
#line 69 "harness.m"
              MR_Integer harness__HeadVar__1__tmp_copy_1 = harness__V_13_13;

#line 69 "harness.m"
              harness__HeadVar__1_1 = harness__HeadVar__1__tmp_copy_1;
#line 69 "harness.m"
            }
#line 69 "harness.m"
            goto loop_top;
#line 69 "harness.m"
          }
        }
#line 66 "harness.m"
      else
#line 70 "harness.m"
        {
#line 70 "harness.m"
        }
#line 66 "harness.m"
    }
#line 66 "harness.m"
  }
#line 63 "harness.m"
}

#line 63 "harness.m"
void MR_CALL harness__test_loop_4_p_0(
#line 63 "harness.m"
  MR_Integer harness__HeadVar__1_1,
#line 63 "harness.m"
  MR_Word harness__HeadVar__2_2)
#line 63 "harness.m"
{
#line 66 "harness.m"
  {
#line 66 "harness.m"
    /* tailcall optimized into a loop */
#line 66 "harness.m"
  loop_top:;
#line 66 "harness.m"
    {
#line 66 "harness.m"
      bool harness__succeeded;
      MR_Integer harness__V_17_17 = (MR_Integer) 0;

#line 66 "harness.m"
      harness__succeeded = (harness__HeadVar__1_1 > harness__V_17_17);
#line 66 "harness.m"
      if (harness__succeeded)
        {
          MR_Integer harness__V_13_13;
          MR_Integer harness__V_14_14;
#line 67 "harness.m"
          void MR_CALL (* harness__func_1)(MR_Box, MR_Box, MR_Box *);
#line 67 "harness.m"
          MR_Box harness__conv2_DCG_2_9;

#line 64 "bmio.opt"
#line 64 "bmio.opt"
{
#line 64 "bmio.opt"
#define MR_PROC_LABEL harness__test_loop_4_p_0
#line 64 "bmio.opt"

#line 64 "bmio.opt"
	MR_Word IO0;
#line 64 "bmio.opt"
	MR_Word IO;
#line 64 "bmio.opt"

#line 64 "bmio.opt"
	IO0 = 
#line 64 "bmio.opt"
(MR_Integer) 0
#line 64 "bmio.opt"
;
#line 64 "bmio.opt"
#line 64 "bmio.opt"
		{
#line 64 "bmio.opt"


	bmio__rd_buf = bmio__plain_buf;
	bmio__rd_ptr = bmio__plain_buf;
	bmio__rd_eof = bmio__plain_buf_eof;

	bmio__wr_buf = bmio__zipped_buf;
	bmio__wr_ptr = bmio__zipped_buf;
	bmio__wr_eof = bmio__zipped_buf_eof;

	IO0 = IO;

#line 64 "bmio.opt"

		;}
#line 64 "bmio.opt"
#undef MR_PROC_LABEL
#line 64 "bmio.opt"
#line 64 "bmio.opt"
#line 64 "bmio.opt"
}
#line 67 "harness.m"
          harness__func_1 = ((void MR_CALL (*)(MR_Box, MR_Box, MR_Box *)) (MR_hl_field(MR_mktag(0), harness__HeadVar__2_2, (MR_Integer) 1)));
#line 67 "harness.m"
          {
#line 67 "harness.m"
            harness__func_1(((MR_Box) harness__HeadVar__2_2), ((MR_Box) ((MR_Integer) 0)), &harness__conv2_DCG_2_9);
          }
#line 69 "harness.m"
          harness__V_14_14 = (MR_Integer) 1;
#line 69 "harness.m"
          harness__V_13_13 = (harness__HeadVar__1_1 - harness__V_14_14);
#line 69 "harness.m"
          {
#line 69 "harness.m"
            /* direct tailcall eliminated */
#line 69 "harness.m"
            {
#line 69 "harness.m"
              MR_Integer harness__HeadVar__1__tmp_copy_1 = harness__V_13_13;

#line 69 "harness.m"
              harness__HeadVar__1_1 = harness__HeadVar__1__tmp_copy_1;
#line 69 "harness.m"
            }
#line 69 "harness.m"
            goto loop_top;
#line 69 "harness.m"
          }
        }
#line 66 "harness.m"
      else
#line 70 "harness.m"
        {
#line 70 "harness.m"
        }
#line 66 "harness.m"
    }
#line 66 "harness.m"
  }
#line 63 "harness.m"
}
#line 55 "harness.m"
static /* final */ const MR_Box harness__const_2_0_1_V_17_17[1] = {
		((MR_Box) ((MR_Integer) 10))};
#line 55 "harness.m"
static /* final */ const MR_Box harness__const_2_0_2_V_16_16[2] = {
		((MR_Box) (MR_mkword(MR_mktag(1), &harness__const_2_0_1_V_17_17))),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};

#line 52 "harness.m"
void MR_CALL harness__test_4_p_0(
#line 52 "harness.m"
  MR_String harness__HeadVar__1_1,
#line 52 "harness.m"
  MR_Word harness__HeadVar__2_2)
#line 52 "harness.m"
{
  {
    bool harness__succeeded;
    MR_Integer harness__V_12_12;
    MR_String harness__V_13_13 = (MR_String) "\n\n******* %s x %d *******\n";
    MR_Word harness__V_14_14;
    MR_Word harness__V_15_15;
    MR_Word harness__V_16_16;
    MR_Word harness__V_17_17;
    MR_Word harness__V_18_18;
    MR_Integer harness__V_19_19;
    MR_Word harness__Stream_7_24;
    MR_String harness__String_9_34;
    MR_String harness__V_5_41;
    MR_String harness__V_5_44;

#line 55 "harness.m"
    {
#line 55 "harness.m"
      harness__V_15_15 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "s"));
#line 55 "harness.m"
      MR_hl_field(MR_mktag(2), harness__V_15_15, 0) = ((MR_Box) (harness__HeadVar__1_1));
#line 55 "harness.m"
    }
#line 28 "harness.m"
    harness__V_19_19 = (MR_Integer) 10;
#line 55 "harness.m"
    harness__V_17_17 = (MR_Word) MR_mkword(MR_mktag(1), &harness__const_2_0_1_V_17_17);
#line 55 "harness.m"
    harness__V_18_18 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 55 "harness.m"
    harness__V_16_16 = (MR_Word) MR_mkword(MR_mktag(1), &harness__const_2_0_2_V_16_16);
#line 55 "harness.m"
    {
#line 55 "harness.m"
      harness__V_14_14 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 55 "harness.m"
      MR_hl_field(MR_mktag(1), harness__V_14_14, 0) = ((MR_Box) (harness__V_15_15));
#line 55 "harness.m"
      MR_hl_field(MR_mktag(1), harness__V_14_14, 1) = ((MR_Box) (harness__V_16_16));
#line 55 "harness.m"
    }
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL harness__test_4_p_0
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_output;
	update_io(IO0, IO);

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
harness__Stream_7_24
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 343 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    {
#line 343 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      mercury__string__format_3_p_0(harness__V_13_13, harness__V_14_14, &harness__String_9_34);
    }
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL harness__test_4_p_0
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Stream = 
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
harness__Stream_7_24
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
harness__String_9_34
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile *stream = (MercuryFile *) Stream;
	mercury_print_string(stream, Message);
	update_io(IO0, IO);
}
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 687 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    harness__V_5_41 = (MR_String) "standard";
#line 688 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    {
#line 688 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      mercury__io__report_stats_3_p_0(harness__V_5_41);
    }
#line 28 "harness.m"
    harness__V_12_12 = (MR_Integer) 10;
#line 57 "harness.m"
    {
#line 57 "harness.m"
      harness__test_loop_4_p_0(harness__V_12_12, harness__HeadVar__2_2);
    }
#line 687 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    harness__V_5_44 = (MR_String) "standard";
#line 688 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    {
#line 688 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      mercury__io__report_stats_3_p_0(harness__V_5_44);
#line 688 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      return;
    }
  }
#line 52 "harness.m"
}

#line 27 "harness.m"
MR_Integer MR_CALL harness__num_iterations_1_f_0(void)
#line 27 "harness.m"
{
#line 28 "harness.m"
  {
#line 28 "harness.m"
    bool harness__succeeded;
#line 28 "harness.m"
    MR_Integer harness__HeadVar__1_1 = (MR_Integer) 10;

#line 28 "harness.m"
    return harness__HeadVar__1_1;
#line 28 "harness.m"
  }
#line 27 "harness.m"
}
#line 55 "harness.m"
static /* final */ const MR_Box harness__const_0_0_1_V_39_39[1] = {
		((MR_Box) ((MR_String) "compress5"))};
#line 55 "harness.m"
static /* final */ const MR_Box harness__const_0_0_2_V_41_41[1] = {
		((MR_Box) ((MR_Integer) 10))};
#line 55 "harness.m"
static /* final */ const MR_Box harness__const_0_0_3_V_40_40[2] = {
		((MR_Box) (MR_mkword(MR_mktag(1), &harness__const_0_0_2_V_41_41))),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 55 "harness.m"
static /* final */ const MR_Box harness__const_0_0_4_V_38_38[2] = {
		((MR_Box) (MR_mkword(MR_mktag(2), &harness__const_0_0_1_V_39_39))),
		((MR_Box) (MR_mkword(MR_mktag(1), &harness__const_0_0_3_V_40_40)))};

#line 16 "harness.m"
void MR_CALL main_2_p_0(void)
#line 16 "harness.m"
{
  {
    bool harness__succeeded;
    MR_Word harness__ArgV_3;
#line 35 "harness.m"
    MR_String harness__FileName_4;
#line 35 "harness.m"
    MR_Integer harness__NumBytes_6;
    MR_String harness__NumBytesStr_5;
    MR_Word harness__V_11_11;
    MR_Word harness__V_12_12;
    MR_Integer harness__V_5_23;

#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL main_2_p_0
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Args;
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	/* convert mercury_argv from a vector to a list */
	{ int i = mercury_argc;
	  Args = MR_list_empty_msg(MR_PROC_LABEL);
	  while (--i >= 0) {
		Args = MR_list_cons_msg((MR_Word) mercury_argv[i], Args,
			MR_PROC_LABEL);
	  }
	}
	update_io(IO0, IO);

#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
harness__ArgV_3
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Args;
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 36 "harness.m"
    harness__succeeded = (MR_tag((MR_Word) harness__ArgV_3) == MR_mktag((MR_Integer) 1));
#line 36 "harness.m"
    if ((MR_tag((MR_Word) harness__ArgV_3) == MR_mktag((MR_Integer) 1)))
#line 36 "harness.m"
      {
#line 36 "harness.m"
        harness__FileName_4 = ((MR_String) (MR_hl_field(MR_mktag(1), harness__ArgV_3, (MR_Integer) 0)));
#line 36 "harness.m"
        harness__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), harness__ArgV_3, (MR_Integer) 1)));
#line 36 "harness.m"
      }
    if (harness__succeeded)
      {
#line 36 "harness.m"
        harness__succeeded = (MR_tag((MR_Word) harness__V_11_11) == MR_mktag((MR_Integer) 1));
#line 36 "harness.m"
        if ((MR_tag((MR_Word) harness__V_11_11) == MR_mktag((MR_Integer) 1)))
#line 36 "harness.m"
          {
#line 36 "harness.m"
            harness__NumBytesStr_5 = ((MR_String) (MR_hl_field(MR_mktag(1), harness__V_11_11, (MR_Integer) 0)));
#line 36 "harness.m"
            harness__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(1), harness__V_11_11, (MR_Integer) 1)));
#line 36 "harness.m"
          }
        if (harness__succeeded)
          {
#line 36 "harness.m"
            harness__succeeded = (harness__V_12_12 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
            if (harness__succeeded)
              {
#line 266 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
                harness__V_5_23 = (MR_Integer) 10;
#line 267 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
                {
#line 267 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
                  harness__succeeded = mercury__string__base_string_to_int_3_p_0(harness__V_5_23, harness__NumBytesStr_5, &harness__NumBytes_6);
                }
              }
          }
      }
#line 35 "harness.m"
    if (harness__succeeded)
      {
        MR_String harness__V_13_13;
        MR_Integer harness__V_36_36;
        MR_String harness__V_37_37;
        MR_Word harness__V_38_38;
        MR_Word harness__V_39_39;
        MR_Word harness__V_40_40;
        MR_Word harness__V_41_41;
        MR_Word harness__V_42_42;
        MR_Integer harness__V_43_43;
        MR_Word harness__Stream_7_48;
        MR_String harness__String_9_58;
        MR_String harness__V_5_65;
        MR_String harness__V_5_68;

#line 33 "bmio.opt"
#line 33 "bmio.opt"
{
#line 33 "bmio.opt"
#define MR_PROC_LABEL main_2_p_0
#line 33 "bmio.opt"

#line 33 "bmio.opt"
	MR_String FileName;
#line 33 "bmio.opt"
	MR_Integer NumBytes;
#line 33 "bmio.opt"
	MR_Word IO0;
#line 33 "bmio.opt"
	MR_Word IO;
#line 33 "bmio.opt"

#line 33 "bmio.opt"
	FileName = 
#line 33 "bmio.opt"
harness__FileName_4
#line 33 "bmio.opt"
;
#line 33 "bmio.opt"
	NumBytes = 
#line 33 "bmio.opt"
harness__NumBytes_6
#line 33 "bmio.opt"
;
#line 33 "bmio.opt"
	IO0 = 
#line 33 "bmio.opt"
(MR_Integer) 0
#line 33 "bmio.opt"
;
#line 33 "bmio.opt"
#line 33 "bmio.opt"
		{
#line 33 "bmio.opt"


 printf("starting bmio__init
");

	assert(NumBytes > 0);
	bmio__buf_size = NumBytes;

 assert((
	bmio__plain_buf = (char *)malloc(NumBytes * sizeof(char))
		) != NULL);
	bmio__plain_buf_eof = bmio__plain_buf + NumBytes;

 assert((
	bmio__fp = fopen(FileName, "rb")
		) != NULL);
 assert((
	fread(bmio__plain_buf, sizeof(char), NumBytes, bmio__fp)
		) == NumBytes);
	fclose(bmio__fp);

 assert((
	bmio__zipped_buf = (char *)malloc(NumBytes * sizeof(char))
		) != NULL);
	bmio__zipped_buf_eof = bmio__zipped_buf + NumBytes;

 printf("finished bmio__init
");

	IO = IO0;

#line 33 "bmio.opt"

		;}
#line 33 "bmio.opt"
#undef MR_PROC_LABEL
#line 33 "bmio.opt"
#line 33 "bmio.opt"
#line 33 "bmio.opt"
}
#line 44 "harness.m"
        harness__V_13_13 = (MR_String) "compress5";
#line 55 "harness.m"
        harness__V_37_37 = (MR_String) "\n\n******* %s x %d *******\n";
#line 55 "harness.m"
        harness__V_39_39 = (MR_Word) MR_mkword(MR_mktag(2), &harness__const_0_0_1_V_39_39);
#line 28 "harness.m"
        harness__V_43_43 = (MR_Integer) 10;
#line 55 "harness.m"
        harness__V_41_41 = (MR_Word) MR_mkword(MR_mktag(1), &harness__const_0_0_2_V_41_41);
#line 55 "harness.m"
        harness__V_42_42 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 55 "harness.m"
        harness__V_40_40 = (MR_Word) MR_mkword(MR_mktag(1), &harness__const_0_0_3_V_40_40);
#line 55 "harness.m"
        harness__V_38_38 = (MR_Word) MR_mkword(MR_mktag(1), &harness__const_0_0_4_V_38_38);
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL main_2_p_0
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_output;
	update_io(IO0, IO);

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
harness__Stream_7_48
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 343 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        {
#line 343 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          mercury__string__format_3_p_0(harness__V_37_37, harness__V_38_38, &harness__String_9_58);
        }
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL main_2_p_0
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Stream = 
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
harness__Stream_7_48
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
harness__String_9_58
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile *stream = (MercuryFile *) Stream;
	mercury_print_string(stream, Message);
	update_io(IO0, IO);
}
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 687 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        harness__V_5_65 = (MR_String) "standard";
#line 688 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        {
#line 688 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          mercury__io__report_stats_3_p_0(harness__V_5_65);
        }
#line 28 "harness.m"
        harness__V_36_36 = (MR_Integer) 10;
#line 57 "harness.m"
        {
#line 57 "harness.m"
          harness__test_loop__ho2_4_p_0(harness__V_36_36);
        }
#line 687 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        harness__V_5_68 = (MR_String) "standard";
#line 688 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        {
#line 688 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          mercury__io__report_stats_3_p_0(harness__V_5_68);
#line 688 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          return;
        }
      }
#line 35 "harness.m"
    else
      {
        MR_String harness__V_15_15 = (MR_String) "usage: compress <infile> <nbytes>";

#line 46 "harness.m"
        {
#line 46 "harness.m"
          mercury__require__error_1_p_0(harness__V_15_15);
#line 46 "harness.m"
          return;
        }
      }
  }
#line 16 "harness.m"
}

void mercury__harness__init(void)
{
}

void mercury__harness__init_type_tables(void)
{
}

void mercury__harness__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module harness. */
