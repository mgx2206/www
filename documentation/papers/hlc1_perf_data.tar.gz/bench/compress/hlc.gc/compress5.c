/*
** Automatically generated from `compress5.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module compress5. */
/* :- implementation. */

#include "compress5.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.benchmarking.h"
#include "bitbuf2.h"
#include "bmio.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "code_table4.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "mercury.tree234.h"
#include "util.h"
#include "mercury.varset.h"



static /* final */ const MR_Box compress5__const_0_0_1_TypeInfo_21_25[2];
static /* final */ const MR_Box compress5__const_0_0_2_TypeClassInfo_for_store_27[3];
static /* final */ const MR_Box compress5__const_0_0_3_TypeInfo_26_30[2];
static /* final */ const MR_Box compress5__const_0_0_4_TypeClassInfo_for_store_32[3];
static /* final */ const MR_Box compress5__const_0_0_5_TypeInfo_31_35[2];
static /* final */ const MR_Box compress5__const_0_0_6_TypeClassInfo_for_store_37[3];
static /* final */ const MR_Box compress5__const_0_0_7_TypeInfo_36_40[2];
static /* final */ const MR_Box compress5__const_0_0_8_TypeClassInfo_for_store_42[3];
static /* final */ const MR_Box compress5__const_0_0_9_TypeInfo_41_45[2];
static /* final */ const MR_Box compress5__const_0_0_10_TypeClassInfo_for_store_47[3];
static /* final */ const MR_Box compress5__const_0_0_11_TypeInfo_29_106[2];
static /* final */ const MR_Box compress5__const_0_0_12_TypeClassInfo_for_store_108[3];
static /* final */ const MR_Box compress5__const_0_0_13_TypeInfo_34_111[2];
static /* final */ const MR_Box compress5__const_0_0_14_TypeClassInfo_for_store_113[3];




#line 56 "compress5.m"
void MR_CALL compress5__main_loop_8_p_0(
#line 56 "compress5.m"
  MR_Word compress5__TypeInfo_for_T_52,
#line 56 "compress5.m"
  MR_Integer compress5__HeadVar__1_1,
#line 56 "compress5.m"
  MR_Integer compress5__HeadVar__2_2,
#line 56 "compress5.m"
  MR_Array compress5__HeadVar__3_3,
#line 56 "compress5.m"
  MR_Integer compress5__HeadVar__4_4,
#line 56 "compress5.m"
  MR_Word compress5__HeadVar__5_5)
#line 56 "compress5.m"
{
  {
    /* tailcall optimized into a loop */
  loop_top:;
    {
      bool compress5__succeeded;
      MR_Word compress5__V_18_60 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 0)));
      MR_Integer compress5__BitsIn_11_65;
      MR_Word compress5__V_15_67;
      MR_Integer compress5__V_16_72;
      MR_Integer compress5__V_17_73;
      MR_Word compress5__TypeInfo_28_74 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
      MR_Word compress5__TypeInfo_29_75;
      MR_Word compress5__TypeClassInfo_for_store_76;
      MR_Word compress5__TypeClassInfo_for_store_77;
      MR_Word compress5__TypeInfo_32_78;
      MR_Word compress5__TypeInfo_33_79;
      MR_Word compress5__TypeInfo_34_80;
      MR_Word compress5__TypeClassInfo_for_store_81;
      MR_Word compress5__TypeClassInfo_for_store_82;
      MR_Word compress5__TypeInfo_37_83;
      MR_Integer compress5__Byte_5_91;
#line 20 "bitbuf2.opt"
      MR_Word compress5__V_22_61 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 1)));
#line 20 "bitbuf2.opt"
      MR_Word compress5__V_21_62 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 2)));
#line 20 "bitbuf2.opt"
      MR_Word compress5__V_20_63 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 3)));
#line 20 "bitbuf2.opt"
      MR_Word compress5__V_19_64 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 4)));
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
      MR_Box compress5__conv1_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
      MR_Box compress5__conv2_S;
#line 23 "bitbuf2.opt"
      MR_Word compress5__V_26_68;
#line 23 "bitbuf2.opt"
      MR_Word compress5__V_25_69;
#line 23 "bitbuf2.opt"
      MR_Word compress5__V_24_70;
#line 23 "bitbuf2.opt"
      MR_Word compress5__V_23_71;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
      MR_Box compress5__conv3_S;

      {
        compress5__TypeInfo_29_75 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
        MR_hl_field(MR_mktag(0), compress5__TypeInfo_29_75, 0) = ((MR_Box) (compress5__TypeInfo_28_74));
        MR_hl_field(MR_mktag(0), compress5__TypeInfo_29_75, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
      }
      compress5__TypeClassInfo_for_store_76 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
      {
        compress5__TypeClassInfo_for_store_77 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_77, 0) = ((MR_Box) (compress5__TypeClassInfo_for_store_76));
        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_77, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_77, 2) = ((MR_Box) (compress5__TypeInfo_29_75));
      }
      compress5__TypeInfo_32_78 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_32_78
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_77
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_18_60
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv1_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv2_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
      compress5__BitsIn_11_65 = ((MR_Integer) compress5__conv1_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 132 "bmio.opt"
#line 132 "bmio.opt"
{
#line 132 "bmio.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 132 "bmio.opt"

#line 132 "bmio.opt"
	MR_Integer Byte;
#line 132 "bmio.opt"
	MR_Word IO0;
#line 132 "bmio.opt"
	MR_Word IO;
#line 132 "bmio.opt"

#line 132 "bmio.opt"
	IO0 = 
#line 132 "bmio.opt"
(MR_Integer) 0
#line 132 "bmio.opt"
;
#line 132 "bmio.opt"
#line 132 "bmio.opt"
		{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;

#line 132 "bmio.opt"

		;}
#line 132 "bmio.opt"
#undef MR_PROC_LABEL
#line 132 "bmio.opt"
#line 132 "bmio.opt"
	
#line 132 "bmio.opt"
compress5__Byte_5_91
#line 132 "bmio.opt"
 = Byte;
#line 132 "bmio.opt"
#line 132 "bmio.opt"
}
#line 23 "bitbuf2.opt"
      compress5__V_15_67 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 0)));
#line 23 "bitbuf2.opt"
      compress5__V_26_68 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 1)));
#line 23 "bitbuf2.opt"
      compress5__V_25_69 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 2)));
#line 23 "bitbuf2.opt"
      compress5__V_24_70 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 3)));
#line 23 "bitbuf2.opt"
      compress5__V_23_71 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 4)));
#line 25 "bitbuf2.opt"
      compress5__V_17_73 = (MR_Integer) 8;
#line 24 "bitbuf2.opt"
      compress5__V_16_72 = (compress5__BitsIn_11_65 + compress5__V_17_73);
      compress5__TypeInfo_33_79 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
      {
        compress5__TypeInfo_34_80 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
        MR_hl_field(MR_mktag(0), compress5__TypeInfo_34_80, 0) = ((MR_Box) (compress5__TypeInfo_33_79));
        MR_hl_field(MR_mktag(0), compress5__TypeInfo_34_80, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
      }
      compress5__TypeClassInfo_for_store_81 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
      {
        compress5__TypeClassInfo_for_store_82 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_82, 0) = ((MR_Box) (compress5__TypeClassInfo_for_store_81));
        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_82, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_82, 2) = ((MR_Box) (compress5__TypeInfo_34_80));
      }
      compress5__TypeInfo_37_83 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_37_83
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_82
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_15_67
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (compress5__V_16_72))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv3_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 92 "bmio.opt"
      compress5__succeeded = (compress5__Byte_5_91 == (MR_Integer) -1);
      if (compress5__succeeded)
        {
          MR_Word compress5__V_12_107;
          MR_Integer compress5__Data_9_109;
          MR_Word compress5__TypeInfo_18_110;
          MR_Word compress5__TypeInfo_19_111;
          MR_Word compress5__TypeClassInfo_for_store_112;
          MR_Word compress5__TypeClassInfo_for_store_113;
          MR_Word compress5__TypeInfo_22_114;
          MR_Word compress5__TypeInfo_7_122;
#line 76 "bitbuf2.opt"
          MR_Word compress5__V_15_104;
#line 76 "bitbuf2.opt"
          MR_Word compress5__V_14_105;
#line 76 "bitbuf2.opt"
          MR_Word compress5__V_13_106;
#line 76 "bitbuf2.opt"
          MR_Word compress5__V_16_108;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
          MR_Box compress5__conv4_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
          MR_Box compress5__conv5_S;

#line 82 "compress5.m"
          {
#line 82 "compress5.m"
            bitbuf2__write_code_7_p_0(compress5__TypeInfo_for_T_52, compress5__HeadVar__1_1, compress5__HeadVar__4_4, compress5__HeadVar__5_5);
          }
#line 76 "bitbuf2.opt"
          compress5__V_15_104 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 0)));
#line 76 "bitbuf2.opt"
          compress5__V_14_105 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 1)));
#line 76 "bitbuf2.opt"
          compress5__V_13_106 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 2)));
#line 76 "bitbuf2.opt"
          compress5__V_12_107 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 3)));
#line 76 "bitbuf2.opt"
          compress5__V_16_108 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 4)));
          compress5__TypeInfo_18_110 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
          {
            compress5__TypeInfo_19_111 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
            MR_hl_field(MR_mktag(0), compress5__TypeInfo_19_111, 0) = ((MR_Box) (compress5__TypeInfo_18_110));
            MR_hl_field(MR_mktag(0), compress5__TypeInfo_19_111, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
          }
          compress5__TypeClassInfo_for_store_112 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
          {
            compress5__TypeClassInfo_for_store_113 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
            MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_113, 0) = ((MR_Box) (compress5__TypeClassInfo_for_store_112));
            MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_113, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
            MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_113, 2) = ((MR_Box) (compress5__TypeInfo_19_111));
          }
          compress5__TypeInfo_22_114 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_22_114
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_113
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_12_107
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv4_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv5_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
          compress5__Data_9_109 = ((MR_Integer) compress5__conv4_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
          compress5__TypeInfo_7_122 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 144 "bmio.opt"
#line 144 "bmio.opt"
{
#line 144 "bmio.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 144 "bmio.opt"

#line 144 "bmio.opt"
	MR_Word TypeInfo_for_Byte;
#line 144 "bmio.opt"
	MR_Word Byte;
#line 144 "bmio.opt"
	MR_Word IO0;
#line 144 "bmio.opt"
	MR_Word IO;
#line 144 "bmio.opt"

#line 144 "bmio.opt"
	TypeInfo_for_Byte = 
#line 144 "bmio.opt"
compress5__TypeInfo_7_122
#line 144 "bmio.opt"
;
#line 144 "bmio.opt"
	Byte = (MR_Word) 
#line 144 "bmio.opt"
((MR_Box) (compress5__Data_9_109))
#line 144 "bmio.opt"
;
#line 144 "bmio.opt"
	IO0 = 
#line 144 "bmio.opt"
(MR_Integer) 0
#line 144 "bmio.opt"
;
#line 144 "bmio.opt"
#line 144 "bmio.opt"
		{
#line 144 "bmio.opt"


 /* if(bmio__wr_buf > bmio__wr_ptr || bmio__wr_ptr >= bmio__wr_eof) {
  fprintf(stderr, "bmio__wr_buf = %p
", bmio__wr_buf);
  fprintf(stderr, "bmio__wr_ptr = %p
", bmio__wr_ptr);
  fprintf(stderr, "bmio__wr_eof = %p
", bmio__wr_eof);
 } */

 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

	*bmio__wr_ptr++ = Byte;

	IO0 = IO;

#line 144 "bmio.opt"

		;}
#line 144 "bmio.opt"
#undef MR_PROC_LABEL
#line 144 "bmio.opt"
#line 144 "bmio.opt"
#line 144 "bmio.opt"
}
        }
      else
        {
          MR_Integer compress5__H_18;
          MR_Integer compress5__K_19;
          MR_Integer compress5__C0_20;
          MR_Integer compress5__H0_13_135;
          MR_Integer compress5__K0_14_136;
          MR_Word compress5__TypeInfo_18_140;
          MR_Integer compress5__V_6_146;
          MR_Integer compress5__V_7_147 = (MR_Integer) 8;
          MR_Integer compress5__V_6_154;
          MR_Integer compress5__V_7_155;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          MR_Box compress5__conv6_K0_14_136;
          MR_Integer compress5__V_385_385;

#line 20 "util.opt"
          compress5__V_6_146 = (compress5__Byte_5_91 << compress5__V_7_147);
#line 62 "code_table4.opt"
          compress5__H0_13_135 = (compress5__HeadVar__1_1 ^ compress5__V_6_146);
#line 23 "code_table4.opt"
          compress5__V_7_155 = (MR_Integer) 8;
#line 20 "util.opt"
          compress5__V_6_154 = (compress5__HeadVar__1_1 << compress5__V_7_155);
#line 21 "code_table4.opt"
          compress5__K_19 = (compress5__V_6_154 | compress5__Byte_5_91);
          compress5__TypeInfo_18_140 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            mercury__array__lookup_3_p_0(compress5__TypeInfo_18_140, (MR_Array) compress5__HeadVar__3_3, compress5__H0_13_135, &compress5__conv6_K0_14_136);
          }
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          compress5__K0_14_136 = ((MR_Integer) compress5__conv6_K0_14_136);
#line 35 "code_table4.opt"
          compress5__succeeded = (compress5__K0_14_136 == compress5__K_19);
#line 36 "code_table4.opt"
          if (!(compress5__succeeded))
#line 36 "code_table4.opt"
            {
              MR_Integer compress5__V_384_384 = (MR_Integer) -1;

#line 37 "code_table4.opt"
              compress5__succeeded = (compress5__K0_14_136 == compress5__V_384_384);
#line 36 "code_table4.opt"
            }
#line 43 "code_table4.opt"
          if (compress5__succeeded)
            {
              MR_Integer compress5__V_15_138;
              MR_Word compress5__TypeInfo_19_141;
              MR_Integer compress5__V_4_165;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
              MR_Box compress5__conv7_C0_20;

#line 40 "code_table4.opt"
              compress5__H_18 = compress5__H0_13_135;
#line 52 "code_table4.opt"
              compress5__V_4_165 = (MR_Integer) 69001;
#line 59 "code_table4.opt"
              compress5__V_15_138 = (compress5__H0_13_135 + compress5__V_4_165);
              compress5__TypeInfo_19_141 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
              {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
                mercury__array__lookup_3_p_0(compress5__TypeInfo_19_141, (MR_Array) compress5__HeadVar__3_3, compress5__V_15_138, &compress5__conv7_C0_20);
              }
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
              compress5__C0_20 = ((MR_Integer) compress5__conv7_C0_20);
            }
#line 43 "code_table4.opt"
          else
            {
              MR_Integer compress5__V_16_139;

#line 67 "code_table4.opt"
              compress5__succeeded = (compress5__H0_13_135 == (MR_Integer) 0);
#line 70 "code_table4.opt"
              if (compress5__succeeded)
#line 69 "code_table4.opt"
                compress5__V_16_139 = (MR_Integer) 1;
#line 70 "code_table4.opt"
              else
                {
                  MR_Integer compress5__V_4_171 = (MR_Integer) 69001;

#line 71 "code_table4.opt"
                  compress5__V_16_139 = (compress5__V_4_171 - compress5__H0_13_135);
                }
#line 45 "code_table4.opt"
              {
#line 45 "code_table4.opt"
                code_table4__lookup_0_6_p_0(compress5__H0_13_135, compress5__V_16_139, compress5__K_19, compress5__HeadVar__3_3, &compress5__H_18, &compress5__C0_20);
              }
            }
#line 5 "util.opt"
          compress5__V_385_385 = (MR_Integer) -1;
#line 62 "compress5.m"
          compress5__succeeded = (compress5__C0_20 == compress5__V_385_385);
#line 62 "compress5.m"
          compress5__succeeded = !(compress5__succeeded);
#line 62 "compress5.m"
          if (compress5__succeeded)
#line 63 "compress5.m"
            {
#line 63 "compress5.m"
              /* direct tailcall eliminated */
#line 63 "compress5.m"
              {
#line 63 "compress5.m"
                MR_Integer compress5__HeadVar__1__tmp_copy_1 = compress5__C0_20;

#line 63 "compress5.m"
                compress5__HeadVar__1_1 = compress5__HeadVar__1__tmp_copy_1;
#line 63 "compress5.m"
              }
#line 63 "compress5.m"
              goto loop_top;
#line 63 "compress5.m"
            }
#line 62 "compress5.m"
          else
#line 64 "compress5.m"
            {
              MR_Integer compress5__V_386_386 = (MR_Integer) 65535;

#line 64 "compress5.m"
              compress5__succeeded = (compress5__HeadVar__2_2 <= compress5__V_386_386);
#line 64 "compress5.m"
              if (compress5__succeeded)
                {
                  MR_Integer compress5__V_44_44;
                  MR_Array compress5__V_45_45;
                  MR_Integer compress5__V_46_46;
                  MR_Integer compress5__V_47_47;
                  MR_Array compress5__T1_11_177;
                  MR_Integer compress5__V_12_179;
                  MR_Word compress5__TypeInfo_14_180;
                  MR_Word compress5__TypeInfo_15_181;
                  MR_Integer compress5__V_4_189;
                  MR_Integer compress5__V_6_197;
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
                  MR_Array compress5__conv8_T1_11_177;
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
                  MR_Array compress5__conv9_V_45_45;
                  MR_Integer compress5__V_7_198;
                  MR_Integer compress5__V_8_199;

#line 65 "compress5.m"
                  {
#line 65 "compress5.m"
                    bitbuf2__write_code_7_p_0(compress5__TypeInfo_for_T_52, compress5__HeadVar__1_1, compress5__HeadVar__4_4, compress5__HeadVar__5_5);
                  }
#line 66 "compress5.m"
                  compress5__V_47_47 = (MR_Integer) 1;
#line 66 "compress5.m"
                  compress5__V_44_44 = (compress5__HeadVar__2_2 + compress5__V_47_47);
                  compress5__TypeInfo_14_180 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
                  {
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
                    mercury__array__set_4_p_0(compress5__TypeInfo_14_180, (MR_Array) compress5__HeadVar__3_3, compress5__H_18, ((MR_Box) (compress5__K_19)), &compress5__conv8_T1_11_177);
                  }
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
                  compress5__T1_11_177 = (MR_Array) compress5__conv8_T1_11_177;
#line 52 "code_table4.opt"
                  compress5__V_4_189 = (MR_Integer) 69001;
#line 59 "code_table4.opt"
                  compress5__V_12_179 = (compress5__H_18 + compress5__V_4_189);
                  compress5__TypeInfo_15_181 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
                  {
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
                    mercury__array__set_4_p_0(compress5__TypeInfo_15_181, (MR_Array) compress5__T1_11_177, compress5__V_12_179, ((MR_Box) (compress5__HeadVar__2_2)), &compress5__conv9_V_45_45);
                  }
#line 107 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
                  compress5__V_45_45 = (MR_Array) compress5__conv9_V_45_45;
#line 12 "util.opt"
                  compress5__V_8_199 = (MR_Integer) 1;
#line 20 "util.opt"
                  compress5__V_7_198 = (compress5__V_8_199 << compress5__HeadVar__4_4);
#line 13 "util.opt"
                  compress5__succeeded = (compress5__HeadVar__2_2 >= compress5__V_7_198);
#line 16 "util.opt"
                  if (compress5__succeeded)
#line 15 "util.opt"
                    compress5__V_6_197 = (MR_Integer) 1;
#line 16 "util.opt"
                  else
#line 17 "util.opt"
                    compress5__V_6_197 = (MR_Integer) 0;
#line 9 "util.opt"
                  compress5__V_46_46 = (compress5__HeadVar__4_4 + compress5__V_6_197);
#line 66 "compress5.m"
                  {
#line 66 "compress5.m"
                    /* direct tailcall eliminated */
#line 66 "compress5.m"
                    {
#line 66 "compress5.m"
                      MR_Integer compress5__HeadVar__1__tmp_copy_1 = compress5__Byte_5_91;
#line 66 "compress5.m"
                      MR_Integer compress5__HeadVar__2__tmp_copy_2 = compress5__V_44_44;
#line 66 "compress5.m"
                      MR_Array compress5__HeadVar__3__tmp_copy_3 = compress5__V_45_45;
#line 66 "compress5.m"
                      MR_Integer compress5__HeadVar__4__tmp_copy_4 = compress5__V_46_46;

#line 66 "compress5.m"
                      compress5__HeadVar__1_1 = compress5__HeadVar__1__tmp_copy_1;
#line 66 "compress5.m"
                      compress5__HeadVar__2_2 = compress5__HeadVar__2__tmp_copy_2;
#line 66 "compress5.m"
                      compress5__HeadVar__3_3 = compress5__HeadVar__3__tmp_copy_3;
#line 66 "compress5.m"
                      compress5__HeadVar__4_4 = compress5__HeadVar__4__tmp_copy_4;
#line 66 "compress5.m"
                    }
#line 66 "compress5.m"
                    goto loop_top;
#line 66 "compress5.m"
                  }
                }
#line 64 "compress5.m"
              else
                {
                  MR_Word compress5__Fallen_22;
                  MR_Word compress5__V_17_207 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 0)));
                  MR_Word compress5__V_21_208 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 1)));
                  MR_Word compress5__V_20_209 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 2)));
                  MR_Integer compress5__BitsIn_9_212;
                  MR_Integer compress5__BitsOut_11_219;
                  MR_Integer compress5__Ratio_13_226;
                  MR_Word compress5__TypeInfo_31_228 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
                  MR_Word compress5__TypeInfo_32_229;
                  MR_Word compress5__TypeClassInfo_for_store_230;
                  MR_Word compress5__TypeClassInfo_for_store_231;
                  MR_Word compress5__TypeInfo_35_232;
                  MR_Word compress5__TypeInfo_36_233;
                  MR_Word compress5__TypeInfo_37_234;
                  MR_Word compress5__TypeClassInfo_for_store_235;
                  MR_Word compress5__TypeClassInfo_for_store_236;
                  MR_Word compress5__TypeInfo_40_237;
                  MR_Word compress5__TypeInfo_41_238;
                  MR_Word compress5__TypeInfo_42_239;
                  MR_Word compress5__TypeClassInfo_for_store_240;
                  MR_Word compress5__TypeClassInfo_for_store_241;
                  MR_Word compress5__TypeInfo_45_242;
#line 51 "bitbuf2.opt"
                  MR_Word compress5__V_19_210 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 3)));
#line 51 "bitbuf2.opt"
                  MR_Word compress5__V_18_211 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__5_5, (MR_Integer) 4)));
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                  MR_Box compress5__conv10_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                  MR_Box compress5__conv11_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                  MR_Box compress5__conv12_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                  MR_Box compress5__conv13_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                  MR_Box compress5__conv14_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                  MR_Box compress5__conv15_S;
                  MR_Integer compress5__V_14_227;
                  MR_Integer compress5__V_6_258;
                  MR_Integer compress5__V_7_259;

                  {
                    compress5__TypeInfo_32_229 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
                    MR_hl_field(MR_mktag(0), compress5__TypeInfo_32_229, 0) = ((MR_Box) (compress5__TypeInfo_31_228));
                    MR_hl_field(MR_mktag(0), compress5__TypeInfo_32_229, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                  }
                  compress5__TypeClassInfo_for_store_230 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
                  {
                    compress5__TypeClassInfo_for_store_231 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
                    MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_231, 0) = ((MR_Box) (compress5__TypeClassInfo_for_store_230));
                    MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_231, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                    MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_231, 2) = ((MR_Box) (compress5__TypeInfo_32_229));
                  }
                  compress5__TypeInfo_35_232 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_35_232
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_231
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_17_207
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv10_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv11_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                  compress5__BitsIn_9_212 = ((MR_Integer) compress5__conv10_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
                  compress5__TypeInfo_36_233 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
                  {
                    compress5__TypeInfo_37_234 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
                    MR_hl_field(MR_mktag(0), compress5__TypeInfo_37_234, 0) = ((MR_Box) (compress5__TypeInfo_36_233));
                    MR_hl_field(MR_mktag(0), compress5__TypeInfo_37_234, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                  }
                  compress5__TypeClassInfo_for_store_235 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
                  {
                    compress5__TypeClassInfo_for_store_236 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
                    MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_236, 0) = ((MR_Box) (compress5__TypeClassInfo_for_store_235));
                    MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_236, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                    MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_236, 2) = ((MR_Box) (compress5__TypeInfo_37_234));
                  }
                  compress5__TypeInfo_40_237 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_40_237
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_236
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_21_208
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv12_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv13_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                  compress5__BitsOut_11_219 = ((MR_Integer) compress5__conv12_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
                  compress5__TypeInfo_41_238 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
                  {
                    compress5__TypeInfo_42_239 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
                    MR_hl_field(MR_mktag(0), compress5__TypeInfo_42_239, 0) = ((MR_Box) (compress5__TypeInfo_41_238));
                    MR_hl_field(MR_mktag(0), compress5__TypeInfo_42_239, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                  }
                  compress5__TypeClassInfo_for_store_240 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
                  {
                    compress5__TypeClassInfo_for_store_241 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
                    MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_241, 0) = ((MR_Box) (compress5__TypeClassInfo_for_store_240));
                    MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_241, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                    MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_241, 2) = ((MR_Box) (compress5__TypeInfo_42_239));
                  }
                  compress5__TypeInfo_45_242 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_45_242
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_241
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_20_209
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv14_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv15_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                  compress5__Ratio_13_226 = ((MR_Integer) compress5__conv14_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 25 "util.opt"
                  compress5__V_6_258 = (compress5__BitsIn_9_212 - compress5__BitsOut_11_219);
#line 26 "util.opt"
                  compress5__V_7_259 = (MR_Integer) 11;
#line 22 "util.opt"
                  compress5__V_14_227 = (compress5__V_6_258 >> compress5__V_7_259);
#line 59 "bitbuf2.opt"
                  compress5__succeeded = (compress5__V_14_227 < compress5__Ratio_13_226);
#line 62 "bitbuf2.opt"
                  if (compress5__succeeded)
#line 61 "bitbuf2.opt"
                    compress5__Fallen_22 = (MR_Integer) 1;
#line 62 "bitbuf2.opt"
                  else
#line 63 "bitbuf2.opt"
                    compress5__Fallen_22 = (MR_Integer) 0;
#line 69 "compress5.m"
                  compress5__succeeded = (compress5__Fallen_22 == (MR_Integer) 0);
#line 69 "compress5.m"
                  if (compress5__succeeded)
                    {
#line 70 "compress5.m"
                      {
#line 70 "compress5.m"
                        bitbuf2__write_code_7_p_0(compress5__TypeInfo_for_T_52, compress5__HeadVar__1_1, compress5__HeadVar__4_4, compress5__HeadVar__5_5);
                      }
#line 71 "compress5.m"
                      {
#line 71 "compress5.m"
                        /* direct tailcall eliminated */
#line 71 "compress5.m"
                        {
#line 71 "compress5.m"
                          MR_Integer compress5__HeadVar__1__tmp_copy_1 = compress5__Byte_5_91;

#line 71 "compress5.m"
                          compress5__HeadVar__1_1 = compress5__HeadVar__1__tmp_copy_1;
#line 71 "compress5.m"
                        }
#line 71 "compress5.m"
                        goto loop_top;
#line 71 "compress5.m"
                      }
                    }
#line 69 "compress5.m"
                  else
                    {
                      MR_Integer compress5__V_48_48;
                      MR_Integer compress5__V_14_271;
                      MR_Integer compress5__V_12_278;
                      MR_Integer compress5__V_10_285;
                      MR_Word compress5__TypeInfo_28_286;
                      MR_Word compress5__TypeInfo_29_287;
                      MR_Word compress5__TypeClassInfo_for_store_288;
                      MR_Word compress5__TypeClassInfo_for_store_289;
                      MR_Word compress5__TypeInfo_32_290;
                      MR_Word compress5__TypeInfo_33_291;
                      MR_Word compress5__TypeInfo_34_292;
                      MR_Word compress5__TypeClassInfo_for_store_293;
                      MR_Word compress5__TypeClassInfo_for_store_294;
                      MR_Word compress5__TypeInfo_37_295;
                      MR_Word compress5__TypeInfo_38_296;
                      MR_Word compress5__TypeInfo_39_297;
                      MR_Word compress5__TypeClassInfo_for_store_298;
                      MR_Word compress5__TypeClassInfo_for_store_299;
                      MR_Word compress5__TypeInfo_42_300;
                      MR_Integer compress5__BitsIn_11_337;
                      MR_Integer compress5__V_16_344;
                      MR_Integer compress5__V_17_345;
                      MR_Word compress5__TypeInfo_28_346;
                      MR_Word compress5__TypeInfo_29_347;
                      MR_Word compress5__TypeClassInfo_for_store_348;
                      MR_Word compress5__TypeClassInfo_for_store_349;
                      MR_Word compress5__TypeInfo_32_350;
                      MR_Word compress5__TypeInfo_33_351;
                      MR_Word compress5__TypeInfo_34_352;
                      MR_Word compress5__TypeClassInfo_for_store_353;
                      MR_Word compress5__TypeClassInfo_for_store_354;
                      MR_Word compress5__TypeInfo_37_355;
                      MR_Integer compress5__Byte_5_363;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                      MR_Box compress5__conv16_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                      MR_Box compress5__conv17_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                      MR_Box compress5__conv18_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                      MR_Box compress5__conv19_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                      MR_Box compress5__conv20_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                      MR_Box compress5__conv21_S;

#line 73 "compress5.m"
                      {
#line 73 "compress5.m"
                        bitbuf2__write_code_7_p_0(compress5__TypeInfo_for_T_52, compress5__HeadVar__1_1, compress5__HeadVar__4_4, compress5__HeadVar__5_5);
                      }
#line 74 "compress5.m"
                      {
#line 74 "compress5.m"
                        bitbuf2__write_code_7_p_0(compress5__TypeInfo_for_T_52, compress5__Byte_5_91, compress5__HeadVar__4_4, compress5__HeadVar__5_5);
                      }
#line 4 "util.opt"
                      compress5__V_48_48 = (MR_Integer) 256;
#line 75 "compress5.m"
                      {
#line 75 "compress5.m"
                        bitbuf2__write_code_7_p_0(compress5__TypeInfo_for_T_52, compress5__V_48_48, compress5__HeadVar__4_4, compress5__HeadVar__5_5);
                      }
#line 67 "bitbuf2.opt"
                      compress5__V_14_271 = (MR_Integer) 0;
                      compress5__TypeInfo_28_286 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
                      {
                        compress5__TypeInfo_29_287 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
                        MR_hl_field(MR_mktag(0), compress5__TypeInfo_29_287, 0) = ((MR_Box) (compress5__TypeInfo_28_286));
                        MR_hl_field(MR_mktag(0), compress5__TypeInfo_29_287, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                      }
                      compress5__TypeClassInfo_for_store_288 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
                      {
                        compress5__TypeClassInfo_for_store_289 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_289, 0) = ((MR_Box) (compress5__TypeClassInfo_for_store_288));
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_289, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_289, 2) = ((MR_Box) (compress5__TypeInfo_29_287));
                      }
                      compress5__TypeInfo_32_290 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_32_290
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_289
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_17_207
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (compress5__V_14_271))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv16_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 70 "bitbuf2.opt"
                      compress5__V_12_278 = (MR_Integer) 0;
                      compress5__TypeInfo_33_291 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
                      {
                        compress5__TypeInfo_34_292 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
                        MR_hl_field(MR_mktag(0), compress5__TypeInfo_34_292, 0) = ((MR_Box) (compress5__TypeInfo_33_291));
                        MR_hl_field(MR_mktag(0), compress5__TypeInfo_34_292, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                      }
                      compress5__TypeClassInfo_for_store_293 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
                      {
                        compress5__TypeClassInfo_for_store_294 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_294, 0) = ((MR_Box) (compress5__TypeClassInfo_for_store_293));
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_294, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_294, 2) = ((MR_Box) (compress5__TypeInfo_34_292));
                      }
                      compress5__TypeInfo_37_295 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_37_295
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_294
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_21_208
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (compress5__V_12_278))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv17_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 73 "bitbuf2.opt"
                      compress5__V_10_285 = (MR_Integer) 0;
                      compress5__TypeInfo_38_296 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
                      {
                        compress5__TypeInfo_39_297 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
                        MR_hl_field(MR_mktag(0), compress5__TypeInfo_39_297, 0) = ((MR_Box) (compress5__TypeInfo_38_296));
                        MR_hl_field(MR_mktag(0), compress5__TypeInfo_39_297, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                      }
                      compress5__TypeClassInfo_for_store_298 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
                      {
                        compress5__TypeClassInfo_for_store_299 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_299, 0) = ((MR_Box) (compress5__TypeClassInfo_for_store_298));
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_299, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_299, 2) = ((MR_Box) (compress5__TypeInfo_39_297));
                      }
                      compress5__TypeInfo_42_300 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_42_300
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_299
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_20_209
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (compress5__V_10_285))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv18_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
                      compress5__TypeInfo_28_346 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
                      {
                        compress5__TypeInfo_29_347 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
                        MR_hl_field(MR_mktag(0), compress5__TypeInfo_29_347, 0) = ((MR_Box) (compress5__TypeInfo_28_346));
                        MR_hl_field(MR_mktag(0), compress5__TypeInfo_29_347, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                      }
                      compress5__TypeClassInfo_for_store_348 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
                      {
                        compress5__TypeClassInfo_for_store_349 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_349, 0) = ((MR_Box) (compress5__TypeClassInfo_for_store_348));
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_349, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_349, 2) = ((MR_Box) (compress5__TypeInfo_29_347));
                      }
                      compress5__TypeInfo_32_350 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_32_350
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_349
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_17_207
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv19_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv20_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
                      compress5__BitsIn_11_337 = ((MR_Integer) compress5__conv19_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 132 "bmio.opt"
#line 132 "bmio.opt"
{
#line 132 "bmio.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 132 "bmio.opt"

#line 132 "bmio.opt"
	MR_Integer Byte;
#line 132 "bmio.opt"
	MR_Word IO0;
#line 132 "bmio.opt"
	MR_Word IO;
#line 132 "bmio.opt"

#line 132 "bmio.opt"
	IO0 = 
#line 132 "bmio.opt"
(MR_Integer) 0
#line 132 "bmio.opt"
;
#line 132 "bmio.opt"
#line 132 "bmio.opt"
		{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;

#line 132 "bmio.opt"

		;}
#line 132 "bmio.opt"
#undef MR_PROC_LABEL
#line 132 "bmio.opt"
#line 132 "bmio.opt"
	
#line 132 "bmio.opt"
compress5__Byte_5_363
#line 132 "bmio.opt"
 = Byte;
#line 132 "bmio.opt"
#line 132 "bmio.opt"
}
#line 25 "bitbuf2.opt"
                      compress5__V_17_345 = (MR_Integer) 8;
#line 24 "bitbuf2.opt"
                      compress5__V_16_344 = (compress5__BitsIn_11_337 + compress5__V_17_345);
                      compress5__TypeInfo_33_351 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
                      {
                        compress5__TypeInfo_34_352 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
                        MR_hl_field(MR_mktag(0), compress5__TypeInfo_34_352, 0) = ((MR_Box) (compress5__TypeInfo_33_351));
                        MR_hl_field(MR_mktag(0), compress5__TypeInfo_34_352, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                      }
                      compress5__TypeClassInfo_for_store_353 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
                      {
                        compress5__TypeClassInfo_for_store_354 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_354, 0) = ((MR_Box) (compress5__TypeClassInfo_for_store_353));
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_354, 1) = ((MR_Box) (compress5__TypeInfo_for_T_52));
                        MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_354, 2) = ((MR_Box) (compress5__TypeInfo_34_352));
                      }
                      compress5__TypeInfo_37_355 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__main_loop_8_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_37_355
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_354
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_17_207
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (compress5__V_16_344))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv21_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 92 "bmio.opt"
                      compress5__succeeded = (compress5__Byte_5_363 == (MR_Integer) -1);
                      if (compress5__succeeded)
#line 46 "compress5.m"
                        {
#line 46 "compress5.m"
                        }
                      else
                        {
                          MR_Integer compress5__V_323_323 = (MR_Integer) 257;
                          MR_Array compress5__V_324_324;
                          MR_Integer compress5__V_325_325;
                          MR_Integer compress5__V_2_375 = (MR_Integer) 138002;
                          MR_Integer compress5__V_3_376 = (MR_Integer) -1;
                          MR_Word compress5__TypeInfo_5_377 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
                          MR_Array compress5__conv22_V_324_324;

#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
                          {
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
                            mercury__array__init_3_p_0(compress5__TypeInfo_5_377, compress5__V_2_375, ((MR_Box) (compress5__V_3_376)), &compress5__conv22_V_324_324);
                          }
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
                          compress5__V_324_324 = (MR_Array) compress5__conv22_V_324_324;
#line 7 "util.opt"
                          compress5__V_325_325 = (MR_Integer) 9;
#line 44 "compress5.m"
                          {
#line 44 "compress5.m"
                            /* direct tailcall eliminated */
#line 44 "compress5.m"
                            {
#line 44 "compress5.m"
                              MR_Integer compress5__HeadVar__1__tmp_copy_1 = compress5__Byte_5_363;
#line 44 "compress5.m"
                              MR_Integer compress5__HeadVar__2__tmp_copy_2 = compress5__V_323_323;
#line 44 "compress5.m"
                              MR_Array compress5__HeadVar__3__tmp_copy_3 = compress5__V_324_324;
#line 44 "compress5.m"
                              MR_Integer compress5__HeadVar__4__tmp_copy_4 = compress5__V_325_325;

#line 44 "compress5.m"
                              compress5__HeadVar__1_1 = compress5__HeadVar__1__tmp_copy_1;
#line 44 "compress5.m"
                              compress5__HeadVar__2_2 = compress5__HeadVar__2__tmp_copy_2;
#line 44 "compress5.m"
                              compress5__HeadVar__3_3 = compress5__HeadVar__3__tmp_copy_3;
#line 44 "compress5.m"
                              compress5__HeadVar__4_4 = compress5__HeadVar__4__tmp_copy_4;
#line 44 "compress5.m"
                            }
#line 44 "compress5.m"
                            goto loop_top;
#line 44 "compress5.m"
                          }
                        }
                    }
                }
#line 64 "compress5.m"
            }
        }
    }
  }
#line 56 "compress5.m"
}

#line 37 "compress5.m"
void MR_CALL compress5__start_4_p_0(
#line 37 "compress5.m"
  MR_Word compress5__TypeInfo_for_T_18,
#line 37 "compress5.m"
  MR_Word compress5__HeadVar__1_1)
#line 37 "compress5.m"
{
  {
    bool compress5__succeeded;
    MR_Word compress5__V_18_25 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__1_1, (MR_Integer) 0)));
    MR_Integer compress5__BitsIn_11_30;
    MR_Word compress5__V_15_32;
    MR_Integer compress5__V_16_37;
    MR_Integer compress5__V_17_38;
    MR_Word compress5__TypeInfo_28_39 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    MR_Word compress5__TypeInfo_29_40;
    MR_Word compress5__TypeClassInfo_for_store_41;
    MR_Word compress5__TypeClassInfo_for_store_42;
    MR_Word compress5__TypeInfo_32_43;
    MR_Word compress5__TypeInfo_33_44;
    MR_Word compress5__TypeInfo_34_45;
    MR_Word compress5__TypeClassInfo_for_store_46;
    MR_Word compress5__TypeClassInfo_for_store_47;
    MR_Word compress5__TypeInfo_37_48;
    MR_Integer compress5__Byte_5_56;
#line 20 "bitbuf2.opt"
    MR_Word compress5__V_22_26 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__1_1, (MR_Integer) 1)));
#line 20 "bitbuf2.opt"
    MR_Word compress5__V_21_27 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__1_1, (MR_Integer) 2)));
#line 20 "bitbuf2.opt"
    MR_Word compress5__V_20_28 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__1_1, (MR_Integer) 3)));
#line 20 "bitbuf2.opt"
    MR_Word compress5__V_19_29 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__1_1, (MR_Integer) 4)));
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box compress5__conv1_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box compress5__conv2_S;
#line 23 "bitbuf2.opt"
    MR_Word compress5__V_26_33;
#line 23 "bitbuf2.opt"
    MR_Word compress5__V_25_34;
#line 23 "bitbuf2.opt"
    MR_Word compress5__V_24_35;
#line 23 "bitbuf2.opt"
    MR_Word compress5__V_23_36;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box compress5__conv3_S;

    {
      compress5__TypeInfo_29_40 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), compress5__TypeInfo_29_40, 0) = ((MR_Box) (compress5__TypeInfo_28_39));
      MR_hl_field(MR_mktag(0), compress5__TypeInfo_29_40, 1) = ((MR_Box) (compress5__TypeInfo_for_T_18));
    }
    compress5__TypeClassInfo_for_store_41 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      compress5__TypeClassInfo_for_store_42 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_42, 0) = ((MR_Box) (compress5__TypeClassInfo_for_store_41));
      MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_42, 1) = ((MR_Box) (compress5__TypeInfo_for_T_18));
      MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_42, 2) = ((MR_Box) (compress5__TypeInfo_29_40));
    }
    compress5__TypeInfo_32_43 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__start_4_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_32_43
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_42
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_18_25
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv1_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv2_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    compress5__BitsIn_11_30 = ((MR_Integer) compress5__conv1_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 132 "bmio.opt"
#line 132 "bmio.opt"
{
#line 132 "bmio.opt"
#define MR_PROC_LABEL compress5__start_4_p_0
#line 132 "bmio.opt"

#line 132 "bmio.opt"
	MR_Integer Byte;
#line 132 "bmio.opt"
	MR_Word IO0;
#line 132 "bmio.opt"
	MR_Word IO;
#line 132 "bmio.opt"

#line 132 "bmio.opt"
	IO0 = 
#line 132 "bmio.opt"
(MR_Integer) 0
#line 132 "bmio.opt"
;
#line 132 "bmio.opt"
#line 132 "bmio.opt"
		{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;

#line 132 "bmio.opt"

		;}
#line 132 "bmio.opt"
#undef MR_PROC_LABEL
#line 132 "bmio.opt"
#line 132 "bmio.opt"
	
#line 132 "bmio.opt"
compress5__Byte_5_56
#line 132 "bmio.opt"
 = Byte;
#line 132 "bmio.opt"
#line 132 "bmio.opt"
}
#line 23 "bitbuf2.opt"
    compress5__V_15_32 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__1_1, (MR_Integer) 0)));
#line 23 "bitbuf2.opt"
    compress5__V_26_33 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__1_1, (MR_Integer) 1)));
#line 23 "bitbuf2.opt"
    compress5__V_25_34 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__1_1, (MR_Integer) 2)));
#line 23 "bitbuf2.opt"
    compress5__V_24_35 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__1_1, (MR_Integer) 3)));
#line 23 "bitbuf2.opt"
    compress5__V_23_36 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__HeadVar__1_1, (MR_Integer) 4)));
#line 25 "bitbuf2.opt"
    compress5__V_17_38 = (MR_Integer) 8;
#line 24 "bitbuf2.opt"
    compress5__V_16_37 = (compress5__BitsIn_11_30 + compress5__V_17_38);
    compress5__TypeInfo_33_44 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    {
      compress5__TypeInfo_34_45 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "type_info");
      MR_hl_field(MR_mktag(0), compress5__TypeInfo_34_45, 0) = ((MR_Box) (compress5__TypeInfo_33_44));
      MR_hl_field(MR_mktag(0), compress5__TypeInfo_34_45, 1) = ((MR_Box) (compress5__TypeInfo_for_T_18));
    }
    compress5__TypeClassInfo_for_store_46 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    {
      compress5__TypeClassInfo_for_store_47 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "typeclass_info");
      MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_47, 0) = ((MR_Box) (compress5__TypeClassInfo_for_store_46));
      MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_47, 1) = ((MR_Box) (compress5__TypeInfo_for_T_18));
      MR_hl_field(MR_mktag(0), compress5__TypeClassInfo_for_store_47, 2) = ((MR_Box) (compress5__TypeInfo_34_45));
    }
    compress5__TypeInfo_37_48 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__start_4_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_37_48
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_47
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_15_32
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (compress5__V_16_37))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv3_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 92 "bmio.opt"
    compress5__succeeded = (compress5__Byte_5_56 == (MR_Integer) -1);
    if (compress5__succeeded)
#line 46 "compress5.m"
      {
#line 46 "compress5.m"
      }
    else
      {
        MR_Integer compress5__V_15_15 = (MR_Integer) 257;
        MR_Array compress5__V_16_16;
        MR_Integer compress5__V_17_17;
        MR_Integer compress5__V_2_68 = (MR_Integer) 138002;
        MR_Integer compress5__V_3_69 = (MR_Integer) -1;
        MR_Word compress5__TypeInfo_5_70 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
        MR_Array compress5__conv4_V_16_16;

#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
        {
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          mercury__array__init_3_p_0(compress5__TypeInfo_5_70, compress5__V_2_68, ((MR_Box) (compress5__V_3_69)), &compress5__conv4_V_16_16);
        }
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
        compress5__V_16_16 = (MR_Array) compress5__conv4_V_16_16;
#line 7 "util.opt"
        compress5__V_17_17 = (MR_Integer) 9;
#line 44 "compress5.m"
        {
#line 44 "compress5.m"
          compress5__main_loop_8_p_0(compress5__TypeInfo_for_T_18, compress5__Byte_5_56, compress5__V_15_15, compress5__V_16_16, compress5__V_17_17, compress5__HeadVar__1_1);
#line 44 "compress5.m"
          return;
        }
      }
  }
#line 37 "compress5.m"
}
static /* final */ const MR_Box compress5__const_0_0_1_TypeInfo_21_25[2] = {
		((MR_Box) ((&mercury__store__store__type_ctor_info_store_1))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0)))};
static /* final */ const MR_Box compress5__const_0_0_2_TypeClassInfo_for_store_27[3] = {
		((MR_Box) ((&base_typeclass_info_store__store__arity1__store__store__arity1__))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0))),
		((MR_Box) (&compress5__const_0_0_1_TypeInfo_21_25))};
static /* final */ const MR_Box compress5__const_0_0_3_TypeInfo_26_30[2] = {
		((MR_Box) ((&mercury__store__store__type_ctor_info_store_1))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0)))};
static /* final */ const MR_Box compress5__const_0_0_4_TypeClassInfo_for_store_32[3] = {
		((MR_Box) ((&base_typeclass_info_store__store__arity1__store__store__arity1__))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0))),
		((MR_Box) (&compress5__const_0_0_3_TypeInfo_26_30))};
static /* final */ const MR_Box compress5__const_0_0_5_TypeInfo_31_35[2] = {
		((MR_Box) ((&mercury__store__store__type_ctor_info_store_1))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0)))};
static /* final */ const MR_Box compress5__const_0_0_6_TypeClassInfo_for_store_37[3] = {
		((MR_Box) ((&base_typeclass_info_store__store__arity1__store__store__arity1__))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0))),
		((MR_Box) (&compress5__const_0_0_5_TypeInfo_31_35))};
static /* final */ const MR_Box compress5__const_0_0_7_TypeInfo_36_40[2] = {
		((MR_Box) ((&mercury__store__store__type_ctor_info_store_1))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0)))};
static /* final */ const MR_Box compress5__const_0_0_8_TypeClassInfo_for_store_42[3] = {
		((MR_Box) ((&base_typeclass_info_store__store__arity1__store__store__arity1__))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0))),
		((MR_Box) (&compress5__const_0_0_7_TypeInfo_36_40))};
static /* final */ const MR_Box compress5__const_0_0_9_TypeInfo_41_45[2] = {
		((MR_Box) ((&mercury__store__store__type_ctor_info_store_1))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0)))};
static /* final */ const MR_Box compress5__const_0_0_10_TypeClassInfo_for_store_47[3] = {
		((MR_Box) ((&base_typeclass_info_store__store__arity1__store__store__arity1__))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0))),
		((MR_Box) (&compress5__const_0_0_9_TypeInfo_41_45))};
static /* final */ const MR_Box compress5__const_0_0_11_TypeInfo_29_106[2] = {
		((MR_Box) ((&mercury__store__store__type_ctor_info_store_1))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0)))};
static /* final */ const MR_Box compress5__const_0_0_12_TypeClassInfo_for_store_108[3] = {
		((MR_Box) ((&base_typeclass_info_store__store__arity1__store__store__arity1__))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0))),
		((MR_Box) (&compress5__const_0_0_11_TypeInfo_29_106))};
static /* final */ const MR_Box compress5__const_0_0_13_TypeInfo_34_111[2] = {
		((MR_Box) ((&mercury__store__store__type_ctor_info_store_1))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0)))};
static /* final */ const MR_Box compress5__const_0_0_14_TypeClassInfo_for_store_113[3] = {
		((MR_Box) ((&base_typeclass_info_store__store__arity1__store__store__arity1__))),
		((MR_Box) ((&mercury__store__store__type_ctor_info_some_store_type_0))),
		((MR_Box) (&compress5__const_0_0_13_TypeInfo_34_111))};

#line 16 "compress5.m"
void MR_CALL compress5__go_2_p_0(void)
#line 16 "compress5.m"
{
  {
    bool compress5__succeeded;
    MR_Word compress5__Buf_3;
    MR_Word compress5__TypeInfo_7_7;
    MR_Word compress5__A_3_8;
    MR_Word compress5__B_4_9;
    MR_Word compress5__C_5_10;
    MR_Word compress5__D_6_11;
    MR_Word compress5__E_7_12;
    MR_Integer compress5__V_18_15;
    MR_Integer compress5__V_17_17;
    MR_Integer compress5__V_16_19;
    MR_Integer compress5__V_15_21;
    MR_Integer compress5__V_14_23;
    MR_Word compress5__TypeInfo_20_24;
    MR_Word compress5__TypeInfo_21_25;
    MR_Word compress5__TypeClassInfo_for_store_26;
    MR_Word compress5__TypeClassInfo_for_store_27;
    MR_Word compress5__TypeInfo_24_28;
    MR_Word compress5__TypeInfo_25_29;
    MR_Word compress5__TypeInfo_26_30;
    MR_Word compress5__TypeClassInfo_for_store_31;
    MR_Word compress5__TypeClassInfo_for_store_32;
    MR_Word compress5__TypeInfo_29_33;
    MR_Word compress5__TypeInfo_30_34;
    MR_Word compress5__TypeInfo_31_35;
    MR_Word compress5__TypeClassInfo_for_store_36;
    MR_Word compress5__TypeClassInfo_for_store_37;
    MR_Word compress5__TypeInfo_34_38;
    MR_Word compress5__TypeInfo_35_39;
    MR_Word compress5__TypeInfo_36_40;
    MR_Word compress5__TypeClassInfo_for_store_41;
    MR_Word compress5__TypeClassInfo_for_store_42;
    MR_Word compress5__TypeInfo_39_43;
    MR_Word compress5__TypeInfo_40_44;
    MR_Word compress5__TypeInfo_41_45;
    MR_Word compress5__TypeClassInfo_for_store_46;
    MR_Word compress5__TypeClassInfo_for_store_47;
    MR_Word compress5__TypeInfo_44_48;
    MR_Integer compress5__BitsIn_11_96;
    MR_Word compress5__V_15_98;
    MR_Integer compress5__V_16_103;
    MR_Integer compress5__V_17_104;
    MR_Word compress5__TypeInfo_28_105;
    MR_Word compress5__TypeInfo_29_106;
    MR_Word compress5__TypeClassInfo_for_store_107;
    MR_Word compress5__TypeClassInfo_for_store_108;
    MR_Word compress5__TypeInfo_32_109;
    MR_Word compress5__TypeInfo_33_110;
    MR_Word compress5__TypeInfo_34_111;
    MR_Word compress5__TypeClassInfo_for_store_112;
    MR_Word compress5__TypeClassInfo_for_store_113;
    MR_Word compress5__TypeInfo_37_114;
    MR_Integer compress5__Byte_5_122;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box compress5__conv1_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box compress5__conv2_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box compress5__conv3_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box compress5__conv4_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box compress5__conv5_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box compress5__conv6_Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box compress5__conv7_S;
#line 23 "bitbuf2.opt"
    MR_Word compress5__V_26_99;
#line 23 "bitbuf2.opt"
    MR_Word compress5__V_25_100;
#line 23 "bitbuf2.opt"
    MR_Word compress5__V_24_101;
#line 23 "bitbuf2.opt"
    MR_Word compress5__V_23_102;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    MR_Box compress5__conv8_S;

#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__go_2_p_0
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 161 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
    compress5__TypeInfo_7_7 = (MR_Word) (&mercury__store__store__type_ctor_info_some_store_type_0);
#line 9 "bitbuf2.opt"
    compress5__V_18_15 = (MR_Integer) 0;
    compress5__TypeInfo_20_24 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    compress5__TypeInfo_21_25 = (MR_Word) &compress5__const_0_0_1_TypeInfo_21_25;
    compress5__TypeClassInfo_for_store_26 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    compress5__TypeClassInfo_for_store_27 = (MR_Word) &compress5__const_0_0_2_TypeClassInfo_for_store_27;
    compress5__TypeInfo_24_28 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__go_2_p_0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_24_28
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_27
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (compress5__V_18_15))
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__A_3_8
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv1_S
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 11 "bitbuf2.opt"
    compress5__V_17_17 = (MR_Integer) 0;
    compress5__TypeInfo_25_29 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    compress5__TypeInfo_26_30 = (MR_Word) &compress5__const_0_0_3_TypeInfo_26_30;
    compress5__TypeClassInfo_for_store_31 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    compress5__TypeClassInfo_for_store_32 = (MR_Word) &compress5__const_0_0_4_TypeClassInfo_for_store_32;
    compress5__TypeInfo_29_33 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__go_2_p_0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_29_33
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_32
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (compress5__V_17_17))
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__B_4_9
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv2_S
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 13 "bitbuf2.opt"
    compress5__V_16_19 = (MR_Integer) 0;
    compress5__TypeInfo_30_34 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    compress5__TypeInfo_31_35 = (MR_Word) &compress5__const_0_0_5_TypeInfo_31_35;
    compress5__TypeClassInfo_for_store_36 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    compress5__TypeClassInfo_for_store_37 = (MR_Word) &compress5__const_0_0_6_TypeClassInfo_for_store_37;
    compress5__TypeInfo_34_38 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__go_2_p_0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_34_38
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_37
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (compress5__V_16_19))
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__C_5_10
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv3_S
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 15 "bitbuf2.opt"
    compress5__V_15_21 = (MR_Integer) 0;
    compress5__TypeInfo_35_39 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    compress5__TypeInfo_36_40 = (MR_Word) &compress5__const_0_0_7_TypeInfo_36_40;
    compress5__TypeClassInfo_for_store_41 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    compress5__TypeClassInfo_for_store_42 = (MR_Word) &compress5__const_0_0_8_TypeClassInfo_for_store_42;
    compress5__TypeInfo_39_43 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__go_2_p_0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_39_43
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_42
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (compress5__V_15_21))
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__D_6_11
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv4_S
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 17 "bitbuf2.opt"
    compress5__V_14_23 = (MR_Integer) 0;
    compress5__TypeInfo_40_44 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    compress5__TypeInfo_41_45 = (MR_Word) &compress5__const_0_0_9_TypeInfo_41_45;
    compress5__TypeClassInfo_for_store_46 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    compress5__TypeClassInfo_for_store_47 = (MR_Word) &compress5__const_0_0_10_TypeClassInfo_for_store_47;
    compress5__TypeInfo_44_48 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__go_2_p_0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_44_48
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_47
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (compress5__V_14_23))
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__E_7_12
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = Mutvar;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv5_S
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 7 "bitbuf2.opt"
    {
#line 7 "bitbuf2.opt"
      compress5__Buf_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 5 * sizeof(MR_Word)), "bitbuf");
#line 7 "bitbuf2.opt"
      MR_hl_field(MR_mktag(0), compress5__Buf_3, 0) = ((MR_Box) (compress5__A_3_8));
#line 7 "bitbuf2.opt"
      MR_hl_field(MR_mktag(0), compress5__Buf_3, 1) = ((MR_Box) (compress5__B_4_9));
#line 7 "bitbuf2.opt"
      MR_hl_field(MR_mktag(0), compress5__Buf_3, 2) = ((MR_Box) (compress5__C_5_10));
#line 7 "bitbuf2.opt"
      MR_hl_field(MR_mktag(0), compress5__Buf_3, 3) = ((MR_Box) (compress5__D_6_11));
#line 7 "bitbuf2.opt"
      MR_hl_field(MR_mktag(0), compress5__Buf_3, 4) = ((MR_Box) (compress5__E_7_12));
#line 7 "bitbuf2.opt"
    }
    compress5__TypeInfo_28_105 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    compress5__TypeInfo_29_106 = (MR_Word) &compress5__const_0_0_11_TypeInfo_29_106;
    compress5__TypeClassInfo_for_store_107 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    compress5__TypeClassInfo_for_store_108 = (MR_Word) &compress5__const_0_0_12_TypeClassInfo_for_store_108;
    compress5__TypeInfo_32_109 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__go_2_p_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_32_109
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_108
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__A_3_8
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv6_Val
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) Val;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv7_S
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
    compress5__BitsIn_11_96 = ((MR_Integer) compress5__conv6_Val);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 132 "bmio.opt"
#line 132 "bmio.opt"
{
#line 132 "bmio.opt"
#define MR_PROC_LABEL compress5__go_2_p_0
#line 132 "bmio.opt"

#line 132 "bmio.opt"
	MR_Integer Byte;
#line 132 "bmio.opt"
	MR_Word IO0;
#line 132 "bmio.opt"
	MR_Word IO;
#line 132 "bmio.opt"

#line 132 "bmio.opt"
	IO0 = 
#line 132 "bmio.opt"
(MR_Integer) 0
#line 132 "bmio.opt"
;
#line 132 "bmio.opt"
#line 132 "bmio.opt"
		{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;

#line 132 "bmio.opt"

		;}
#line 132 "bmio.opt"
#undef MR_PROC_LABEL
#line 132 "bmio.opt"
#line 132 "bmio.opt"
	
#line 132 "bmio.opt"
compress5__Byte_5_122
#line 132 "bmio.opt"
 = Byte;
#line 132 "bmio.opt"
#line 132 "bmio.opt"
}
#line 23 "bitbuf2.opt"
    compress5__V_15_98 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__Buf_3, (MR_Integer) 0)));
#line 23 "bitbuf2.opt"
    compress5__V_26_99 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__Buf_3, (MR_Integer) 1)));
#line 23 "bitbuf2.opt"
    compress5__V_25_100 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__Buf_3, (MR_Integer) 2)));
#line 23 "bitbuf2.opt"
    compress5__V_24_101 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__Buf_3, (MR_Integer) 3)));
#line 23 "bitbuf2.opt"
    compress5__V_23_102 = ((MR_Word) (MR_hl_field(MR_mktag(0), compress5__Buf_3, (MR_Integer) 4)));
#line 25 "bitbuf2.opt"
    compress5__V_17_104 = (MR_Integer) 8;
#line 24 "bitbuf2.opt"
    compress5__V_16_103 = (compress5__BitsIn_11_96 + compress5__V_17_104);
    compress5__TypeInfo_33_110 = (MR_Word) (&mercury__store__store__type_ctor_info_store_1);
    compress5__TypeInfo_34_111 = (MR_Word) &compress5__const_0_0_13_TypeInfo_34_111;
    compress5__TypeClassInfo_for_store_112 = (MR_Word) (&base_typeclass_info_store__store__arity1__store__store__arity1__);
    compress5__TypeClassInfo_for_store_113 = (MR_Word) &compress5__const_0_0_14_TypeClassInfo_for_store_113;
    compress5__TypeInfo_37_114 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#define MR_PROC_LABEL compress5__go_2_p_0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeInfo_for_T;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word TypeClassInfo_for_store__store_S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Mutvar;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word Val;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S0;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	MR_Word S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeInfo_for_T = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeInfo_37_114
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	TypeClassInfo_for_store__store_S = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Word) compress5__TypeClassInfo_for_store_113
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Mutvar = 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__V_15_98
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	Val = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
((MR_Box) (compress5__V_16_103))
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	S0 = (MR_Word) 
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
(MR_Integer) 0
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
		{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

		;}
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#undef MR_PROC_LABEL
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
	
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
compress5__conv8_S
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
 = (MR_Box) S;
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"
}
#line 92 "bmio.opt"
    compress5__succeeded = (compress5__Byte_5_122 == (MR_Integer) -1);
    if (compress5__succeeded)
#line 46 "compress5.m"
      {
#line 46 "compress5.m"
      }
    else
      {
        MR_Integer compress5__V_82_82 = (MR_Integer) 257;
        MR_Array compress5__V_83_83;
        MR_Integer compress5__V_84_84;
        MR_Integer compress5__V_2_134 = (MR_Integer) 138002;
        MR_Integer compress5__V_3_135 = (MR_Integer) -1;
        MR_Word compress5__TypeInfo_5_136 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
        MR_Array compress5__conv9_V_83_83;

#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
        {
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          mercury__array__init_3_p_0(compress5__TypeInfo_5_136, compress5__V_2_134, ((MR_Box) (compress5__V_3_135)), &compress5__conv9_V_83_83);
        }
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
        compress5__V_83_83 = (MR_Array) compress5__conv9_V_83_83;
#line 7 "util.opt"
        compress5__V_84_84 = (MR_Integer) 9;
#line 44 "compress5.m"
        {
#line 44 "compress5.m"
          compress5__main_loop_8_p_0(compress5__TypeInfo_7_7, compress5__Byte_5_122, compress5__V_82_82, compress5__V_83_83, compress5__V_84_84, compress5__Buf_3);
#line 44 "compress5.m"
          return;
        }
      }
  }
#line 16 "compress5.m"
}

void mercury__compress5__init(void)
{
}

void mercury__compress5__init_type_tables(void)
{
}

void mercury__compress5__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module compress5. */
