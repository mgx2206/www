/*
** Automatically generated from `bmio.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module bmio. */
/* :- implementation. */

#include "bmio.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.benchmarking.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "mercury.tree234.h"
#include "mercury.varset.h"



#line 251 "bmio.m"
static /* final */ const MR_Box bmio__const_7_0_1_V_22_22[1];
#line 251 "bmio.m"
static /* final */ const MR_Box bmio__const_7_0_2_V_27_27[1];
#line 251 "bmio.m"
static /* final */ const MR_Box bmio__const_7_0_3_V_26_26[2];
#line 252 "bmio.m"
static /* final */ const MR_Box bmio__const_7_0_4_V_13_13[1];
#line 252 "bmio.m"
static /* final */ const MR_Box bmio__const_7_0_5_V_18_18[1];
#line 252 "bmio.m"
static /* final */ const MR_Box bmio__const_7_0_6_V_17_17[2];



const MR_TypeCtorInfo_Struct bmio__bmio__type_ctor_info_state_0 = {
		(MR_Integer) 0,
		((MR_Box) (bmio____Unify____state_0_0)),
		((MR_Box) (bmio____Unify____state_0_0)),
		((MR_Box) (bmio____Compare____state_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "bmio",
		(MR_String) "state",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&mercury__io__io__type_ctor_info_state_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};

#line 23 "bmio.m"
void MR_CALL bmio____Compare____state_0_0(
#line 23 "bmio.m"
  MR_Word * bmio__HeadVar__1_1,
#line 23 "bmio.m"
  MR_Word bmio__HeadVar__2_2,
#line 23 "bmio.m"
  MR_Word bmio__HeadVar__3_3)
#line 23 "bmio.m"
{
#line 23 "bmio.m"
  {
#line 23 "bmio.m"
    bool bmio__succeeded;
#line 23 "bmio.m"
    MR_Word bmio__conv1_HeadVar__2_2 = (MR_Word) bmio__HeadVar__2_2;
#line 23 "bmio.m"
    MR_Word bmio__conv2_HeadVar__3_3 = (MR_Word) bmio__HeadVar__3_3;

#line 23 "bmio.m"
    {
#line 23 "bmio.m"
      mercury__io____Compare____state_0_0(bmio__HeadVar__1_1);
#line 23 "bmio.m"
      return;
    }
#line 23 "bmio.m"
  }
#line 23 "bmio.m"
}

#line 23 "bmio.m"
bool MR_CALL bmio____Unify____state_0_0(
#line 23 "bmio.m"
  MR_Word bmio__HeadVar__1_1,
#line 23 "bmio.m"
  MR_Word bmio__HeadVar__2_2)
#line 23 "bmio.m"
{
#line 23 "bmio.m"
  {
#line 23 "bmio.m"
    bool bmio__succeeded;
#line 23 "bmio.m"
    MR_Word bmio__conv1_HeadVar__1_1 = (MR_Word) bmio__HeadVar__1_1;
#line 23 "bmio.m"
    MR_Word bmio__conv2_HeadVar__2_2 = (MR_Word) bmio__HeadVar__2_2;

#line 23 "bmio.m"
    {
#line 23 "bmio.m"
      bmio__succeeded = mercury__io____Unify____state_0_0();
    }
#line 23 "bmio.m"
    if (bmio__succeeded)
#line 23 "bmio.m"
      bmio__succeeded = TRUE;
#line 23 "bmio.m"
    return bmio__succeeded;
#line 23 "bmio.m"
  }
#line 23 "bmio.m"
}

#line 267 "bmio.m"
void MR_CALL bmio__wr_bytes_3_p_0(
#line 267 "bmio.m"
  MR_Integer * bmio__W_1)
#line 267 "bmio.m"
{
#line 269 "bmio.m"
  {
#line 269 "bmio.m"
    bool bmio__succeeded;

#line 269 "bmio.m"
#line 269 "bmio.m"
{
#line 269 "bmio.m"
#define MR_PROC_LABEL bmio__wr_bytes_3_p_0
#line 269 "bmio.m"

#line 269 "bmio.m"
	MR_Integer W;
#line 269 "bmio.m"
	MR_Word IO0;
#line 269 "bmio.m"
	MR_Word IO;
#line 269 "bmio.m"

#line 269 "bmio.m"
	IO0 = 
#line 269 "bmio.m"
(MR_Integer) 0
#line 269 "bmio.m"
;
#line 269 "bmio.m"
#line 269 "bmio.m"
		{
#line 269 "bmio.m"


    W = bmio__wr_ptr - bmio__wr_buf;
    IO0 = IO;

#line 269 "bmio.m"

		;}
#line 269 "bmio.m"
#undef MR_PROC_LABEL
#line 269 "bmio.m"
#line 269 "bmio.m"
	
#line 269 "bmio.m"
*bmio__W_1
#line 269 "bmio.m"
 = W;
#line 269 "bmio.m"
#line 269 "bmio.m"
}
#line 269 "bmio.m"
  }
#line 267 "bmio.m"
}

#line 256 "bmio.m"
void MR_CALL bmio__rd_bytes_3_p_0(
#line 256 "bmio.m"
  MR_Integer * bmio__R_1)
#line 256 "bmio.m"
{
#line 258 "bmio.m"
  {
#line 258 "bmio.m"
    bool bmio__succeeded;

#line 258 "bmio.m"
#line 258 "bmio.m"
{
#line 258 "bmio.m"
#define MR_PROC_LABEL bmio__rd_bytes_3_p_0
#line 258 "bmio.m"

#line 258 "bmio.m"
	MR_Integer R;
#line 258 "bmio.m"
	MR_Word IO0;
#line 258 "bmio.m"
	MR_Word IO;
#line 258 "bmio.m"

#line 258 "bmio.m"
	IO0 = 
#line 258 "bmio.m"
(MR_Integer) 0
#line 258 "bmio.m"
;
#line 258 "bmio.m"
#line 258 "bmio.m"
		{
#line 258 "bmio.m"


    R = bmio__rd_ptr - bmio__rd_buf;
    IO0 = IO;

#line 258 "bmio.m"

		;}
#line 258 "bmio.m"
#undef MR_PROC_LABEL
#line 258 "bmio.m"
#line 258 "bmio.m"
	
#line 258 "bmio.m"
*bmio__R_1
#line 258 "bmio.m"
 = R;
#line 258 "bmio.m"
#line 258 "bmio.m"
}
#line 258 "bmio.m"
  }
#line 256 "bmio.m"
}

#line 230 "bmio.m"
void MR_CALL bmio__chk_wr_3_p_0(
#line 230 "bmio.m"
  MR_Word bmio__TypeInfo_for_Byte_7,
#line 230 "bmio.m"
  MR_Box bmio__Byte_1)
#line 230 "bmio.m"
{
#line 232 "bmio.m"
  {
#line 232 "bmio.m"
    bool bmio__succeeded;

#line 232 "bmio.m"
#line 232 "bmio.m"
{
#line 232 "bmio.m"
#define MR_PROC_LABEL bmio__chk_wr_3_p_0
#line 232 "bmio.m"

#line 232 "bmio.m"
	MR_Word TypeInfo_for_Byte;
#line 232 "bmio.m"
	MR_Word Byte;
#line 232 "bmio.m"
	MR_Word IO0;
#line 232 "bmio.m"
	MR_Word IO;
#line 232 "bmio.m"

#line 232 "bmio.m"
	TypeInfo_for_Byte = 
#line 232 "bmio.m"
bmio__TypeInfo_for_Byte_7
#line 232 "bmio.m"
;
#line 232 "bmio.m"
	Byte = (MR_Word) 
#line 232 "bmio.m"
bmio__Byte_1
#line 232 "bmio.m"
;
#line 232 "bmio.m"
	IO0 = 
#line 232 "bmio.m"
(MR_Integer) 0
#line 232 "bmio.m"
;
#line 232 "bmio.m"
#line 232 "bmio.m"
		{
#line 232 "bmio.m"


 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

 assert((
	*bmio__wr_ptr++
		) == Byte);

	IO0 = IO;

#line 232 "bmio.m"

		;}
#line 232 "bmio.m"
#undef MR_PROC_LABEL
#line 232 "bmio.m"
#line 232 "bmio.m"
#line 232 "bmio.m"
}
#line 232 "bmio.m"
  }
#line 230 "bmio.m"
}

#line 207 "bmio.m"
void MR_CALL bmio__wr_3_p_0(
#line 207 "bmio.m"
  MR_Word bmio__TypeInfo_for_Byte_7,
#line 207 "bmio.m"
  MR_Box bmio__Byte_1)
#line 207 "bmio.m"
{
#line 209 "bmio.m"
  {
#line 209 "bmio.m"
    bool bmio__succeeded;

#line 209 "bmio.m"
#line 209 "bmio.m"
{
#line 209 "bmio.m"
#define MR_PROC_LABEL bmio__wr_3_p_0
#line 209 "bmio.m"

#line 209 "bmio.m"
	MR_Word TypeInfo_for_Byte;
#line 209 "bmio.m"
	MR_Word Byte;
#line 209 "bmio.m"
	MR_Word IO0;
#line 209 "bmio.m"
	MR_Word IO;
#line 209 "bmio.m"

#line 209 "bmio.m"
	TypeInfo_for_Byte = 
#line 209 "bmio.m"
bmio__TypeInfo_for_Byte_7
#line 209 "bmio.m"
;
#line 209 "bmio.m"
	Byte = (MR_Word) 
#line 209 "bmio.m"
bmio__Byte_1
#line 209 "bmio.m"
;
#line 209 "bmio.m"
	IO0 = 
#line 209 "bmio.m"
(MR_Integer) 0
#line 209 "bmio.m"
;
#line 209 "bmio.m"
#line 209 "bmio.m"
		{
#line 209 "bmio.m"


 /* if(bmio__wr_buf > bmio__wr_ptr || bmio__wr_ptr >= bmio__wr_eof) {
  fprintf(stderr, "bmio__wr_buf = %p
", bmio__wr_buf);
  fprintf(stderr, "bmio__wr_ptr = %p
", bmio__wr_ptr);
  fprintf(stderr, "bmio__wr_eof = %p
", bmio__wr_eof);
 } */

 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

	*bmio__wr_ptr++ = Byte;

	IO0 = IO;

#line 209 "bmio.m"

		;}
#line 209 "bmio.m"
#undef MR_PROC_LABEL
#line 209 "bmio.m"
#line 209 "bmio.m"
#line 209 "bmio.m"
}
#line 209 "bmio.m"
  }
#line 207 "bmio.m"
}

#line 187 "bmio.m"
void MR_CALL bmio__rd_3_p_0(
#line 187 "bmio.m"
  MR_Integer * bmio__Byte_1)
#line 187 "bmio.m"
{
#line 189 "bmio.m"
  {
#line 189 "bmio.m"
    bool bmio__succeeded;

#line 189 "bmio.m"
#line 189 "bmio.m"
{
#line 189 "bmio.m"
#define MR_PROC_LABEL bmio__rd_3_p_0
#line 189 "bmio.m"

#line 189 "bmio.m"
	MR_Integer Byte;
#line 189 "bmio.m"
	MR_Word IO0;
#line 189 "bmio.m"
	MR_Word IO;
#line 189 "bmio.m"

#line 189 "bmio.m"
	IO0 = 
#line 189 "bmio.m"
(MR_Integer) 0
#line 189 "bmio.m"
;
#line 189 "bmio.m"
#line 189 "bmio.m"
		{
#line 189 "bmio.m"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;

#line 189 "bmio.m"

		;}
#line 189 "bmio.m"
#undef MR_PROC_LABEL
#line 189 "bmio.m"
#line 189 "bmio.m"
	
#line 189 "bmio.m"
*bmio__Byte_1
#line 189 "bmio.m"
 = Byte;
#line 189 "bmio.m"
#line 189 "bmio.m"
}
#line 189 "bmio.m"
  }
#line 187 "bmio.m"
}
#line 251 "bmio.m"
static /* final */ const MR_Box bmio__const_7_0_1_V_22_22[1] = {
		((MR_Box) ((MR_String) "bmio: read    "))};
#line 251 "bmio.m"
static /* final */ const MR_Box bmio__const_7_0_2_V_27_27[1] = {
		((MR_Box) ((MR_String) " bytes\n"))};
#line 251 "bmio.m"
static /* final */ const MR_Box bmio__const_7_0_3_V_26_26[2] = {
		((MR_Box) (MR_mkword(MR_mktag(2), &bmio__const_7_0_2_V_27_27))),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 252 "bmio.m"
static /* final */ const MR_Box bmio__const_7_0_4_V_13_13[1] = {
		((MR_Box) ((MR_String) "bmio: written "))};
#line 252 "bmio.m"
static /* final */ const MR_Box bmio__const_7_0_5_V_18_18[1] = {
		((MR_Box) ((MR_String) " bytes\n"))};
#line 252 "bmio.m"
static /* final */ const MR_Box bmio__const_7_0_6_V_17_17[2] = {
		((MR_Box) (MR_mkword(MR_mktag(2), &bmio__const_7_0_5_V_18_18))),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};

#line 49 "bmio.m"
void MR_CALL bmio__report_stats_2_p_0(void)
#line 49 "bmio.m"
{
  {
    bool bmio__succeeded;
    MR_Integer bmio__R_3;
    MR_Integer bmio__W_4;
    MR_Word bmio__E_5;
    MR_Word bmio__V_12_12;
    MR_Word bmio__V_13_13;
    MR_Word bmio__V_14_14;
    MR_String bmio__V_15_15;
    MR_Word bmio__V_16_16;
    MR_Word bmio__V_17_17;
    MR_Word bmio__V_18_18;
    MR_Word bmio__V_19_19;
    MR_String bmio__V_20_20;
    MR_Word bmio__V_21_21;
    MR_Word bmio__V_22_22;
    MR_Word bmio__V_23_23;
    MR_String bmio__V_24_24;
    MR_Word bmio__V_25_25;
    MR_Word bmio__V_26_26;
    MR_Word bmio__V_27_27;
    MR_Word bmio__V_28_28;
    MR_String bmio__V_29_29;

#line 258 "bmio.m"
#line 258 "bmio.m"
{
#line 258 "bmio.m"
#define MR_PROC_LABEL bmio__report_stats_2_p_0
#line 258 "bmio.m"

#line 258 "bmio.m"
	MR_Integer R;
#line 258 "bmio.m"
	MR_Word IO0;
#line 258 "bmio.m"
	MR_Word IO;
#line 258 "bmio.m"

#line 258 "bmio.m"
	IO0 = 
#line 258 "bmio.m"
(MR_Integer) 0
#line 258 "bmio.m"
;
#line 258 "bmio.m"
#line 258 "bmio.m"
		{
#line 258 "bmio.m"


    R = bmio__rd_ptr - bmio__rd_buf;
    IO0 = IO;

#line 258 "bmio.m"

		;}
#line 258 "bmio.m"
#undef MR_PROC_LABEL
#line 258 "bmio.m"
#line 258 "bmio.m"
	
#line 258 "bmio.m"
bmio__R_3
#line 258 "bmio.m"
 = R;
#line 258 "bmio.m"
#line 258 "bmio.m"
}
#line 269 "bmio.m"
#line 269 "bmio.m"
{
#line 269 "bmio.m"
#define MR_PROC_LABEL bmio__report_stats_2_p_0
#line 269 "bmio.m"

#line 269 "bmio.m"
	MR_Integer W;
#line 269 "bmio.m"
	MR_Word IO0;
#line 269 "bmio.m"
	MR_Word IO;
#line 269 "bmio.m"

#line 269 "bmio.m"
	IO0 = 
#line 269 "bmio.m"
(MR_Integer) 0
#line 269 "bmio.m"
;
#line 269 "bmio.m"
#line 269 "bmio.m"
		{
#line 269 "bmio.m"


    W = bmio__wr_ptr - bmio__wr_buf;
    IO0 = IO;

#line 269 "bmio.m"

		;}
#line 269 "bmio.m"
#undef MR_PROC_LABEL
#line 269 "bmio.m"
#line 269 "bmio.m"
	
#line 269 "bmio.m"
bmio__W_4
#line 269 "bmio.m"
 = W;
#line 269 "bmio.m"
#line 269 "bmio.m"
}
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL bmio__report_stats_2_p_0
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) &mercury_stderr;
	update_io(IO0, IO);

#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
bmio__E_5
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 251 "bmio.m"
    bmio__V_24_24 = (MR_String) "bmio: read    ";
#line 251 "bmio.m"
    bmio__V_22_22 = (MR_Word) MR_mkword(MR_mktag(2), &bmio__const_7_0_1_V_22_22);
#line 251 "bmio.m"
    {
#line 251 "bmio.m"
      bmio__V_25_25 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "i"));
#line 251 "bmio.m"
      MR_hl_field(MR_mktag(1), bmio__V_25_25, 0) = ((MR_Box) (bmio__R_3));
#line 251 "bmio.m"
    }
#line 251 "bmio.m"
    bmio__V_29_29 = (MR_String) " bytes\n";
#line 251 "bmio.m"
    bmio__V_27_27 = (MR_Word) MR_mkword(MR_mktag(2), &bmio__const_7_0_2_V_27_27);
#line 251 "bmio.m"
    bmio__V_28_28 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 251 "bmio.m"
    bmio__V_26_26 = (MR_Word) MR_mkword(MR_mktag(1), &bmio__const_7_0_3_V_26_26);
#line 251 "bmio.m"
    {
#line 251 "bmio.m"
      bmio__V_23_23 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 251 "bmio.m"
      MR_hl_field(MR_mktag(1), bmio__V_23_23, 0) = ((MR_Box) (bmio__V_25_25));
#line 251 "bmio.m"
      MR_hl_field(MR_mktag(1), bmio__V_23_23, 1) = ((MR_Box) (bmio__V_26_26));
#line 251 "bmio.m"
    }
#line 251 "bmio.m"
    {
#line 251 "bmio.m"
      bmio__V_21_21 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 251 "bmio.m"
      MR_hl_field(MR_mktag(1), bmio__V_21_21, 0) = ((MR_Box) (bmio__V_22_22));
#line 251 "bmio.m"
      MR_hl_field(MR_mktag(1), bmio__V_21_21, 1) = ((MR_Box) (bmio__V_23_23));
#line 251 "bmio.m"
    }
#line 251 "bmio.m"
    {
#line 251 "bmio.m"
      mercury__io__write_many_4_p_0(bmio__E_5, bmio__V_21_21);
    }
#line 252 "bmio.m"
    bmio__V_15_15 = (MR_String) "bmio: written ";
#line 252 "bmio.m"
    bmio__V_13_13 = (MR_Word) MR_mkword(MR_mktag(2), &bmio__const_7_0_4_V_13_13);
#line 252 "bmio.m"
    {
#line 252 "bmio.m"
      bmio__V_16_16 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "i"));
#line 252 "bmio.m"
      MR_hl_field(MR_mktag(1), bmio__V_16_16, 0) = ((MR_Box) (bmio__W_4));
#line 252 "bmio.m"
    }
#line 252 "bmio.m"
    bmio__V_20_20 = (MR_String) " bytes\n";
#line 252 "bmio.m"
    bmio__V_18_18 = (MR_Word) MR_mkword(MR_mktag(2), &bmio__const_7_0_5_V_18_18);
#line 252 "bmio.m"
    bmio__V_19_19 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 252 "bmio.m"
    bmio__V_17_17 = (MR_Word) MR_mkword(MR_mktag(1), &bmio__const_7_0_6_V_17_17);
#line 252 "bmio.m"
    {
#line 252 "bmio.m"
      bmio__V_14_14 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 252 "bmio.m"
      MR_hl_field(MR_mktag(1), bmio__V_14_14, 0) = ((MR_Box) (bmio__V_16_16));
#line 252 "bmio.m"
      MR_hl_field(MR_mktag(1), bmio__V_14_14, 1) = ((MR_Box) (bmio__V_17_17));
#line 252 "bmio.m"
    }
#line 252 "bmio.m"
    {
#line 252 "bmio.m"
      bmio__V_12_12 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 252 "bmio.m"
      MR_hl_field(MR_mktag(1), bmio__V_12_12, 0) = ((MR_Box) (bmio__V_13_13));
#line 252 "bmio.m"
      MR_hl_field(MR_mktag(1), bmio__V_12_12, 1) = ((MR_Box) (bmio__V_14_14));
#line 252 "bmio.m"
    }
#line 252 "bmio.m"
    {
#line 252 "bmio.m"
      mercury__io__write_many_4_p_0(bmio__E_5, bmio__V_12_12);
#line 252 "bmio.m"
      return;
    }
  }
#line 49 "bmio.m"
}

#line 46 "bmio.m"
void MR_CALL bmio__write_byte_checked_3_p_0(
#line 46 "bmio.m"
  MR_Integer bmio__HeadVar__1_1)
#line 46 "bmio.m"
{
  {
    bool bmio__succeeded;
    MR_Word bmio__TypeInfo_7_7 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);

#line 232 "bmio.m"
#line 232 "bmio.m"
{
#line 232 "bmio.m"
#define MR_PROC_LABEL bmio__write_byte_checked_3_p_0
#line 232 "bmio.m"

#line 232 "bmio.m"
	MR_Word TypeInfo_for_Byte;
#line 232 "bmio.m"
	MR_Word Byte;
#line 232 "bmio.m"
	MR_Word IO0;
#line 232 "bmio.m"
	MR_Word IO;
#line 232 "bmio.m"

#line 232 "bmio.m"
	TypeInfo_for_Byte = 
#line 232 "bmio.m"
bmio__TypeInfo_7_7
#line 232 "bmio.m"
;
#line 232 "bmio.m"
	Byte = (MR_Word) 
#line 232 "bmio.m"
((MR_Box) (bmio__HeadVar__1_1))
#line 232 "bmio.m"
;
#line 232 "bmio.m"
	IO0 = 
#line 232 "bmio.m"
(MR_Integer) 0
#line 232 "bmio.m"
;
#line 232 "bmio.m"
#line 232 "bmio.m"
		{
#line 232 "bmio.m"


 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

 assert((
	*bmio__wr_ptr++
		) == Byte);

	IO0 = IO;

#line 232 "bmio.m"

		;}
#line 232 "bmio.m"
#undef MR_PROC_LABEL
#line 232 "bmio.m"
#line 232 "bmio.m"
#line 232 "bmio.m"
}
  }
#line 46 "bmio.m"
}

#line 43 "bmio.m"
void MR_CALL bmio__mark_decompression_eof_2_p_0(void)
#line 43 "bmio.m"
{
#line 170 "bmio.m"
  {
#line 170 "bmio.m"
    bool bmio__succeeded;

#line 170 "bmio.m"
#line 170 "bmio.m"
{
#line 170 "bmio.m"
#define MR_PROC_LABEL bmio__mark_decompression_eof_2_p_0
#line 170 "bmio.m"

#line 170 "bmio.m"
	MR_Word IO0;
#line 170 "bmio.m"
	MR_Word IO;
#line 170 "bmio.m"

#line 170 "bmio.m"
	IO0 = 
#line 170 "bmio.m"
(MR_Integer) 0
#line 170 "bmio.m"
;
#line 170 "bmio.m"
#line 170 "bmio.m"
		{
#line 170 "bmio.m"


	bmio__zipped_buf_eof = bmio__wr_ptr;

	IO0 = IO;

#line 170 "bmio.m"

		;}
#line 170 "bmio.m"
#undef MR_PROC_LABEL
#line 170 "bmio.m"
#line 170 "bmio.m"
#line 170 "bmio.m"
}
#line 170 "bmio.m"
  }
#line 43 "bmio.m"
}

#line 40 "bmio.m"
void MR_CALL bmio__write_byte_3_p_0(
#line 40 "bmio.m"
  MR_Integer bmio__HeadVar__1_1)
#line 40 "bmio.m"
{
  {
    bool bmio__succeeded;
    MR_Word bmio__TypeInfo_7_7 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);

#line 209 "bmio.m"
#line 209 "bmio.m"
{
#line 209 "bmio.m"
#define MR_PROC_LABEL bmio__write_byte_3_p_0
#line 209 "bmio.m"

#line 209 "bmio.m"
	MR_Word TypeInfo_for_Byte;
#line 209 "bmio.m"
	MR_Word Byte;
#line 209 "bmio.m"
	MR_Word IO0;
#line 209 "bmio.m"
	MR_Word IO;
#line 209 "bmio.m"

#line 209 "bmio.m"
	TypeInfo_for_Byte = 
#line 209 "bmio.m"
bmio__TypeInfo_7_7
#line 209 "bmio.m"
;
#line 209 "bmio.m"
	Byte = (MR_Word) 
#line 209 "bmio.m"
((MR_Box) (bmio__HeadVar__1_1))
#line 209 "bmio.m"
;
#line 209 "bmio.m"
	IO0 = 
#line 209 "bmio.m"
(MR_Integer) 0
#line 209 "bmio.m"
;
#line 209 "bmio.m"
#line 209 "bmio.m"
		{
#line 209 "bmio.m"


 /* if(bmio__wr_buf > bmio__wr_ptr || bmio__wr_ptr >= bmio__wr_eof) {
  fprintf(stderr, "bmio__wr_buf = %p
", bmio__wr_buf);
  fprintf(stderr, "bmio__wr_ptr = %p
", bmio__wr_ptr);
  fprintf(stderr, "bmio__wr_eof = %p
", bmio__wr_eof);
 } */

 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

	*bmio__wr_ptr++ = Byte;

	IO0 = IO;

#line 209 "bmio.m"

		;}
#line 209 "bmio.m"
#undef MR_PROC_LABEL
#line 209 "bmio.m"
#line 209 "bmio.m"
#line 209 "bmio.m"
}
  }
#line 40 "bmio.m"
}

#line 37 "bmio.m"
void MR_CALL bmio__read_byte_3_p_0(
#line 37 "bmio.m"
  MR_Word * bmio__HeadVar__1_1)
#line 37 "bmio.m"
{
  {
    bool bmio__succeeded;
    MR_Integer bmio__Byte_5;

#line 189 "bmio.m"
#line 189 "bmio.m"
{
#line 189 "bmio.m"
#define MR_PROC_LABEL bmio__read_byte_3_p_0
#line 189 "bmio.m"

#line 189 "bmio.m"
	MR_Integer Byte;
#line 189 "bmio.m"
	MR_Word IO0;
#line 189 "bmio.m"
	MR_Word IO;
#line 189 "bmio.m"

#line 189 "bmio.m"
	IO0 = 
#line 189 "bmio.m"
(MR_Integer) 0
#line 189 "bmio.m"
;
#line 189 "bmio.m"
#line 189 "bmio.m"
		{
#line 189 "bmio.m"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;

#line 189 "bmio.m"

		;}
#line 189 "bmio.m"
#undef MR_PROC_LABEL
#line 189 "bmio.m"
#line 189 "bmio.m"
	
#line 189 "bmio.m"
bmio__Byte_5
#line 189 "bmio.m"
 = Byte;
#line 189 "bmio.m"
#line 189 "bmio.m"
}
#line 159 "bmio.m"
    bmio__succeeded = (bmio__Byte_5 == (MR_Integer) -1);
#line 159 "bmio.m"
    if (bmio__succeeded)
#line 159 "bmio.m"
      *bmio__HeadVar__1_1 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 159 "bmio.m"
    else
#line 159 "bmio.m"
      {
#line 159 "bmio.m"
        *bmio__HeadVar__1_1 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "ok"));
#line 159 "bmio.m"
        MR_hl_field(MR_mktag(1), *bmio__HeadVar__1_1, 0) = ((MR_Box) (bmio__Byte_5));
#line 159 "bmio.m"
      }
  }
#line 37 "bmio.m"
}

#line 34 "bmio.m"
void MR_CALL bmio__use_decompression_io_2_p_0(void)
#line 34 "bmio.m"
{
#line 139 "bmio.m"
  {
#line 139 "bmio.m"
    bool bmio__succeeded;

#line 139 "bmio.m"
#line 139 "bmio.m"
{
#line 139 "bmio.m"
#define MR_PROC_LABEL bmio__use_decompression_io_2_p_0
#line 139 "bmio.m"

#line 139 "bmio.m"
	MR_Word IO0;
#line 139 "bmio.m"
	MR_Word IO;
#line 139 "bmio.m"

#line 139 "bmio.m"
	IO0 = 
#line 139 "bmio.m"
(MR_Integer) 0
#line 139 "bmio.m"
;
#line 139 "bmio.m"
#line 139 "bmio.m"
		{
#line 139 "bmio.m"


	bmio__rd_buf = bmio__zipped_buf;
	bmio__rd_ptr = bmio__zipped_buf;
	bmio__rd_eof = bmio__zipped_buf_eof;

	bmio__wr_buf = bmio__plain_buf;
	bmio__wr_ptr = bmio__plain_buf;
	bmio__wr_eof = bmio__plain_buf_eof;

	IO0 = IO;

#line 139 "bmio.m"

		;}
#line 139 "bmio.m"
#undef MR_PROC_LABEL
#line 139 "bmio.m"
#line 139 "bmio.m"
#line 139 "bmio.m"
}
#line 139 "bmio.m"
  }
#line 34 "bmio.m"
}

#line 31 "bmio.m"
void MR_CALL bmio__use_compression_io_2_p_0(void)
#line 31 "bmio.m"
{
#line 121 "bmio.m"
  {
#line 121 "bmio.m"
    bool bmio__succeeded;

#line 121 "bmio.m"
#line 121 "bmio.m"
{
#line 121 "bmio.m"
#define MR_PROC_LABEL bmio__use_compression_io_2_p_0
#line 121 "bmio.m"

#line 121 "bmio.m"
	MR_Word IO0;
#line 121 "bmio.m"
	MR_Word IO;
#line 121 "bmio.m"

#line 121 "bmio.m"
	IO0 = 
#line 121 "bmio.m"
(MR_Integer) 0
#line 121 "bmio.m"
;
#line 121 "bmio.m"
#line 121 "bmio.m"
		{
#line 121 "bmio.m"


	bmio__rd_buf = bmio__plain_buf;
	bmio__rd_ptr = bmio__plain_buf;
	bmio__rd_eof = bmio__plain_buf_eof;

	bmio__wr_buf = bmio__zipped_buf;
	bmio__wr_ptr = bmio__zipped_buf;
	bmio__wr_eof = bmio__zipped_buf_eof;

	IO0 = IO;

#line 121 "bmio.m"

		;}
#line 121 "bmio.m"
#undef MR_PROC_LABEL
#line 121 "bmio.m"
#line 121 "bmio.m"
#line 121 "bmio.m"
}
#line 121 "bmio.m"
  }
#line 31 "bmio.m"
}

#line 28 "bmio.m"
void MR_CALL bmio__init_4_p_0(
#line 28 "bmio.m"
  MR_String bmio__FileName_1,
#line 28 "bmio.m"
  MR_Integer bmio__NumBytes_2)
#line 28 "bmio.m"
{
#line 86 "bmio.m"
  {
#line 86 "bmio.m"
    bool bmio__succeeded;

#line 86 "bmio.m"
#line 86 "bmio.m"
{
#line 86 "bmio.m"
#define MR_PROC_LABEL bmio__init_4_p_0
#line 86 "bmio.m"

#line 86 "bmio.m"
	MR_String FileName;
#line 86 "bmio.m"
	MR_Integer NumBytes;
#line 86 "bmio.m"
	MR_Word IO0;
#line 86 "bmio.m"
	MR_Word IO;
#line 86 "bmio.m"

#line 86 "bmio.m"
	FileName = 
#line 86 "bmio.m"
bmio__FileName_1
#line 86 "bmio.m"
;
#line 86 "bmio.m"
	NumBytes = 
#line 86 "bmio.m"
bmio__NumBytes_2
#line 86 "bmio.m"
;
#line 86 "bmio.m"
	IO0 = 
#line 86 "bmio.m"
(MR_Integer) 0
#line 86 "bmio.m"
;
#line 86 "bmio.m"
#line 86 "bmio.m"
		{
#line 86 "bmio.m"


 printf("starting bmio__init
");

	assert(NumBytes > 0);
	bmio__buf_size = NumBytes;

 assert((
	bmio__plain_buf = (char *)malloc(NumBytes * sizeof(char))
		) != NULL);
	bmio__plain_buf_eof = bmio__plain_buf + NumBytes;

 assert((
	bmio__fp = fopen(FileName, "rb")
		) != NULL);
 assert((
	fread(bmio__plain_buf, sizeof(char), NumBytes, bmio__fp)
		) == NumBytes);
	fclose(bmio__fp);

 assert((
	bmio__zipped_buf = (char *)malloc(NumBytes * sizeof(char))
		) != NULL);
	bmio__zipped_buf_eof = bmio__zipped_buf + NumBytes;

 printf("finished bmio__init
");

	IO = IO0;

#line 86 "bmio.m"

		;}
#line 86 "bmio.m"
#undef MR_PROC_LABEL
#line 86 "bmio.m"
#line 86 "bmio.m"
#line 86 "bmio.m"
}
#line 86 "bmio.m"
  }
#line 28 "bmio.m"
}

void mercury__bmio__init(void)
{
}

void mercury__bmio__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&bmio__bmio__type_ctor_info_state_0);
}

void mercury__bmio__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module bmio. */
