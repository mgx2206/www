/*
** Automatically generated from `compress5.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__compress5__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "compress5.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "compress5.c"
#line 3 "bmio.opt"


#include <stdio.h>
#include <malloc.h>
#include <assert.h>

unsigned int	 bmio__buf_size;
unsigned char	*bmio__plain_buf;
unsigned char	*bmio__plain_buf_eof;
unsigned char	*bmio__zipped_buf;
unsigned char	*bmio__zipped_buf_eof;
unsigned char	*bmio__rd_buf;
unsigned char	*bmio__rd_ptr;
unsigned char	*bmio__rd_eof;
unsigned char	*bmio__wr_buf;
unsigned char	*bmio__wr_ptr;
unsigned char	*bmio__wr_eof;
FILE		*bmio__fp;


#line 54 "compress5.c"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	#include "mercury_type_info.h"
	#include "mercury_heap.h"
	#include "mercury_misc.h"	/* for MR_fatal_error() */

	/* ML_arg() is defined in std_util.m */
	bool ML_arg(MR_TypeInfo term_type_info, MR_Word *term, int arg_index,
			MR_TypeInfo *arg_type_info_ptr, MR_Word **arg_ptr);


#line 66 "compress5.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

#ifdef MR_HIGHLEVEL_CODE
  bool MR_CALL mercury__array__do_unify__array_1_0(
  	MR_Mercury_Type_Info type_info, MR_Box x, MR_Box y);
  bool MR_CALL mercury__array____Unify____array_1_0(
	MR_Mercury_Type_Info type_info, MR_Array x, MR_Array y);
  void MR_CALL mercury__array__do_compare__array_1_0(MR_Mercury_Type_Info
 	 type_info, MR_Comparison_Result *result, MR_Box x, MR_Box y);
  void MR_CALL mercury__array____Compare____array_1_0(MR_Mercury_Type_Info
	type_info, MR_Comparison_Result *result, MR_Array x, MR_Array y);
#endif

#line 80 "compress5.c"
#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

#include "mercury_heap.h"		/* for MR_maybe_record_allocation() */
#include "mercury_library_types.h"	/* for MR_ArrayType */

#line 86 "compress5.c"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType *ML_make_array(MR_Integer size, MR_Word item);

#line 91 "compress5.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType * ML_resize_array(MR_ArrayType *old_array,
					MR_Integer array_size, MR_Word item);

#line 97 "compress5.c"
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType * ML_shrink_array(MR_ArrayType *old_array,
					MR_Integer array_size);

#line 103 "compress5.c"
#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType *ML_copy_array(MR_ArrayType *old_array);

#line 108 "compress5.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 115 "compress5.c"
#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	extern MR_Word		ML_io_stream_names;
	extern MR_Word		ML_io_user_globals;
	#if 0
	  extern MR_Word	ML_io_ops_table;
	#endif

#line 124 "compress5.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
#ifdef HAVE_SYS_STAT_H
	#include <sys/stat.h>
#endif

#line 134 "compress5.c"
#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include "mercury_init.h"
#include "mercury_wrapper.h"
#include "mercury_type_info.h"
#include "mercury_library_types.h"
#include "mercury_file.h"
#include "mercury_heap.h"
#include "mercury_misc.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

#ifdef HAVE_SYS_WAIT
  #include <sys/wait.h>		/* for WIFEXITED, WEXITSTATUS, etc. */
#endif

extern MercuryFile mercury_stdin;
extern MercuryFile mercury_stdout;
extern MercuryFile mercury_stderr;
extern MercuryFile mercury_stdin_binary;
extern MercuryFile mercury_stdout_binary;
extern MercuryFile *mercury_current_text_input;
extern MercuryFile *mercury_current_text_output;
extern MercuryFile *mercury_current_binary_input;
extern MercuryFile *mercury_current_binary_output;

#define initial_io_state()		0	/* some random number */
#define update_io(r_src, r_dest)	((r_dest) = (r_src))
#define final_io_state(r)		((void)0)

void 		mercury_init_io(void);
MercuryFile*	mercury_open(const char *filename, const char *type);
void		mercury_io_error(MercuryFile* mf, const char *format, ...);
void		mercury_output_error(MercuryFile* mf);
void		mercury_print_string(MercuryFile* mf, const char *s);
void		mercury_print_binary_string(MercuryFile* mf, const char *s);
int		mercury_getc(MercuryFile* mf);
void		mercury_close(MercuryFile* mf);
int		ML_fprintf(MercuryFile* mf, const char *format, ...);

#line 180 "compress5.c"
#line 106 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <fcntl.h>

	#define	MAX_TEMPNAME_TRIES	(6 * 4)

	extern long ML_io_tempnam_counter;

#line 194 "compress5.c"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include <string.h>
#include <errno.h>

/*
** ML_maybe_make_err_msg(was_error, msg, procname, error_msg):
**	if `was_error' is true, then append `msg' and `strerror(errno)'
**	to give `error_msg'; otherwise, set `error_msg' to NULL.
**
** WARNING: this must only be called when the `hp' register is valid.
** That means it must only be called from procedures declared
** `will_not_call_mercury'.
**
** This is defined as a macro rather than a C function
** to avoid worrying about the `hp' register being
** invalidated by the function call.
** It also needs to be a macro because MR_incr_hp_atomic_msg()
** stringizes the procname argument.
*/
#define ML_maybe_make_err_msg(was_error, msg, procname, error_msg)	\
	do {								\
		char *errno_msg;					\
		size_t total_len;					\
		MR_Word tmp;						\
									\
		if (was_error) {					\
			errno_msg = strerror(errno);			\
			total_len = strlen(msg) + strlen(errno_msg);	\
			MR_incr_hp_atomic_msg(tmp,			\
				(total_len + sizeof(MR_Word))		\
					/ sizeof(MR_Word),		\
				procname,				\
				"string:string/0");			\
			(error_msg) = (char *)tmp;			\
			strcpy((error_msg), msg);			\
			strcat((error_msg), errno_msg);			\
		} else {						\
			(error_msg) = NULL;				\
		}							\
	} while(0)


#line 239 "compress5.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 242 "compress5.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 248 "compress5.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 256 "compress5.c"

MR_define_extern_entry(mercury__compress5__go_2_0);
MR_declare_label(mercury__compress5__go_2_0_i4);
MR_declare_label(mercury__compress5__go_2_0_i6);
MR_define_extern_entry(mercury__compress5__start_4_0);
MR_declare_label(mercury__compress5__start_4_0_i2);
MR_declare_label(mercury__compress5__start_4_0_i4);
MR_define_extern_entry(mercury__compress5__main_loop_8_0);
MR_declare_label(mercury__compress5__main_loop_8_0_i4);
MR_declare_label(mercury__compress5__main_loop_8_0_i50);
MR_declare_label(mercury__compress5__main_loop_8_0_i2);
MR_declare_label(mercury__compress5__main_loop_8_0_i5);
MR_declare_label(mercury__compress5__main_loop_8_0_i9);
MR_declare_label(mercury__compress5__main_loop_8_0_i10);
MR_declare_label(mercury__compress5__main_loop_8_0_i7);
MR_declare_label(mercury__compress5__main_loop_8_0_i11);
MR_declare_label(mercury__compress5__main_loop_8_0_i14);
MR_declare_label(mercury__compress5__main_loop_8_0_i18);
MR_declare_label(mercury__compress5__main_loop_8_0_i17);
MR_declare_label(mercury__compress5__main_loop_8_0_i21);
MR_declare_label(mercury__compress5__main_loop_8_0_i22);
MR_declare_label(mercury__compress5__main_loop_8_0_i23);
MR_declare_label(mercury__compress5__main_loop_8_0_i24);
MR_declare_label(mercury__compress5__main_loop_8_0_i20);
MR_declare_label(mercury__compress5__main_loop_8_0_i62);
MR_declare_label(mercury__compress5__main_loop_8_0_i27);
MR_declare_label(mercury__compress5__main_loop_8_0_i30);
MR_declare_label(mercury__compress5__main_loop_8_0_i31);
MR_declare_label(mercury__compress5__main_loop_8_0_i33);
MR_declare_label(mercury__compress5__main_loop_8_0_i34);
MR_declare_label(mercury__compress5__main_loop_8_0_i35);
MR_declare_label(mercury__compress5__main_loop_8_0_i38);

	extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;
	extern const MR_Code * mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__[];
	extern const struct MR_TypeCtorInfo_Struct mercury_data_store__type_ctor_info_some_store_type_0;
	extern const struct MR_TypeCtorInfo_Struct mercury_data_store__type_ctor_info_store_1;
	static const struct mercury_const_1_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_const_1 = {
	(MR_Word *) &mercury_data_store__type_ctor_info_store_1,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0
	};
	static const struct mercury_const_2_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_const_2 = {
	(MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0,
	MR_mkword(MR_mktag(0), &mercury_const_1)
	};
	static const struct mercury_const_3_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_const_3 = {
	(MR_Word *) &mercury_data_store__type_ctor_info_store_1,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0
	};
	static const struct mercury_const_4_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_const_4 = {
	(MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0,
	MR_mkword(MR_mktag(0), &mercury_const_3)
	};
	static const struct mercury_const_5_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_const_5 = {
	(MR_Word *) &mercury_data_store__type_ctor_info_store_1,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0
	};
	static const struct mercury_const_6_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_const_6 = {
	(MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0,
	MR_mkword(MR_mktag(0), &mercury_const_5)
	};
	static const struct mercury_const_7_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_const_7 = {
	(MR_Word *) &mercury_data_store__type_ctor_info_store_1,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0
	};
	static const struct mercury_const_8_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_const_8 = {
	(MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0,
	MR_mkword(MR_mktag(0), &mercury_const_7)
	};
	static const struct mercury_const_9_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_const_9 = {
	(MR_Word *) &mercury_data_store__type_ctor_info_store_1,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0
	};
	static const struct mercury_const_10_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_const_10 = {
	(MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0,
	MR_mkword(MR_mktag(0), &mercury_const_9)
	};
	static const struct mercury_const_12_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_const_12 = {
	(MR_Word *) &mercury_data_store__type_ctor_info_store_1,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0
	};
	static const struct mercury_const_13_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_const_13 = {
	(MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0,
	MR_mkword(MR_mktag(0), &mercury_const_12)
	};
	static const struct mercury_const_14_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_const_14 = {
	(MR_Word *) &mercury_data_store__type_ctor_info_store_1,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0
	};
	static const struct mercury_const_15_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_const_15 = {
	(MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0,
	MR_mkword(MR_mktag(0), &mercury_const_14)
	};
MR_declare_entry(mercury__array__init_3_0);
MR_declare_entry(mercury__bitbuf2__write_code_7_0);
MR_declare_entry(mercury__array__lookup_3_0);
MR_declare_entry(mercury__code_table4__lookup_0_6_0);
MR_declare_entry(mercury__array__set_4_0);

MR_BEGIN_MODULE(compress5_module)
	MR_init_entry(mercury__compress5__go_2_0);
	MR_init_label(mercury__compress5__go_2_0_i4);
	MR_init_label(mercury__compress5__go_2_0_i6);
	MR_init_entry(mercury__compress5__start_4_0);
	MR_init_label(mercury__compress5__start_4_0_i2);
	MR_init_label(mercury__compress5__start_4_0_i4);
	MR_init_entry(mercury__compress5__main_loop_8_0);
	MR_init_label(mercury__compress5__main_loop_8_0_i4);
	MR_init_label(mercury__compress5__main_loop_8_0_i50);
	MR_init_label(mercury__compress5__main_loop_8_0_i2);
	MR_init_label(mercury__compress5__main_loop_8_0_i5);
	MR_init_label(mercury__compress5__main_loop_8_0_i9);
	MR_init_label(mercury__compress5__main_loop_8_0_i10);
	MR_init_label(mercury__compress5__main_loop_8_0_i7);
	MR_init_label(mercury__compress5__main_loop_8_0_i11);
	MR_init_label(mercury__compress5__main_loop_8_0_i14);
	MR_init_label(mercury__compress5__main_loop_8_0_i18);
	MR_init_label(mercury__compress5__main_loop_8_0_i17);
	MR_init_label(mercury__compress5__main_loop_8_0_i21);
	MR_init_label(mercury__compress5__main_loop_8_0_i22);
	MR_init_label(mercury__compress5__main_loop_8_0_i23);
	MR_init_label(mercury__compress5__main_loop_8_0_i24);
	MR_init_label(mercury__compress5__main_loop_8_0_i20);
	MR_init_label(mercury__compress5__main_loop_8_0_i62);
	MR_init_label(mercury__compress5__main_loop_8_0_i27);
	MR_init_label(mercury__compress5__main_loop_8_0_i30);
	MR_init_label(mercury__compress5__main_loop_8_0_i31);
	MR_init_label(mercury__compress5__main_loop_8_0_i33);
	MR_init_label(mercury__compress5__main_loop_8_0_i34);
	MR_init_label(mercury__compress5__main_loop_8_0_i35);
	MR_init_label(mercury__compress5__main_loop_8_0_i38);
MR_BEGIN_CODE

/* code for predicate 'go'/2 in mode 0 */
MR_define_entry(mercury__compress5__go_2_0);
	{
#define	MR_PROC_LABEL	mercury__compress5__go_2_0
	MR_OBTAIN_GLOBAL_LOCK("do_init");
	MR_RELEASE_GLOBAL_LOCK("do_init");
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Val;
	MR_Word	Mutvar;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__go_2_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = (MR_Word) MR_mkword(MR_mktag(0), &mercury_const_2);
	Val = (MR_Integer) 0;
	S0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("new_mutvar");
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 475 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("new_mutvar");
	MR_r2 = Mutvar;
	MR_r3 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Val;
	MR_Word	Mutvar;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__go_2_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = (MR_Word) MR_mkword(MR_mktag(0), &mercury_const_4);
	Val = (MR_Integer) 0;
	S0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("new_mutvar");
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 502 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("new_mutvar");
	MR_r3 = Mutvar;
	MR_r4 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Val;
	MR_Word	Mutvar;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__go_2_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = (MR_Word) MR_mkword(MR_mktag(0), &mercury_const_6);
	Val = (MR_Integer) 0;
	S0 = MR_r4;
	MR_OBTAIN_GLOBAL_LOCK("new_mutvar");
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 529 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("new_mutvar");
	MR_r4 = Mutvar;
	MR_r5 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Val;
	MR_Word	Mutvar;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__go_2_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = (MR_Word) MR_mkword(MR_mktag(0), &mercury_const_8);
	Val = (MR_Integer) 0;
	S0 = MR_r5;
	MR_OBTAIN_GLOBAL_LOCK("new_mutvar");
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 556 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("new_mutvar");
	MR_r5 = Mutvar;
	MR_r6 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Val;
	MR_Word	Mutvar;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__go_2_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = (MR_Word) MR_mkword(MR_mktag(0), &mercury_const_10);
	Val = (MR_Integer) 0;
	S0 = MR_r6;
	MR_OBTAIN_GLOBAL_LOCK("new_mutvar");
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 583 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("new_mutvar");
	MR_r6 = Mutvar;
	MR_r7 = S;
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(6, "compress5:go/2");
	MR_stackvar(6) = (MR_Word) MR_succip;
	MR_tag_incr_hp_msg(MR_stackvar(1), MR_mktag(0), (MR_Integer) 5, mercury__compress5__go_2_0, "bitbuf2:bitbuf/1");
	MR_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0) = MR_r2;
	MR_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1) = MR_r3;
	MR_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2) = MR_r4;
	MR_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 3) = MR_r5;
	MR_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 4) = MR_r6;
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__go_2_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = (MR_Word) MR_mkword(MR_mktag(0), &mercury_const_13);
	Mutvar = MR_r2;
	S0 = MR_r7;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 617 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r2 = Val;
	MR_r3 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Integer	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__compress5__go_2_0
	IO0 = MR_r1;
	MR_OBTAIN_GLOBAL_LOCK("rd");
{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;
;}
#line 645 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("rd");
	MR_r4 = Byte;
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r5 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_r6 = ((MR_Integer) MR_r2 + (MR_Integer) 8);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__go_2_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = (MR_Word) MR_mkword(MR_mktag(0), &mercury_const_15);
	Mutvar = MR_r5;
	Val = MR_r6;
	S0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 674 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r2 = S;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(2) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0;
	if (((MR_Integer) MR_r4 == (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__compress5__go_2_0_i6);
	}
	MR_stackvar(3) = MR_r2;
	MR_stackvar(4) = MR_r1;
	MR_stackvar(5) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r2 = (MR_Integer) 138002;
	MR_r3 = (MR_Integer) -1;
	MR_call_localret(MR_ENTRY(mercury__array__init_3_0),
		mercury__compress5__go_2_0_i4,
		MR_ENTRY(mercury__compress5__go_2_0));
MR_define_label(mercury__compress5__go_2_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__go_2_0));
	MR_r4 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_r2 = MR_stackvar(5);
	MR_r3 = (MR_Integer) 257;
	MR_r5 = (MR_Integer) 9;
	MR_r6 = MR_stackvar(1);
	MR_r7 = MR_stackvar(3);
	MR_r8 = MR_stackvar(4);
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_localtailcall(mercury__compress5__main_loop_8_0,
		MR_ENTRY(mercury__compress5__go_2_0));
MR_define_label(mercury__compress5__go_2_0_i6);
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
/* code for predicate 'start'/4 in mode 0 */
MR_define_entry(mercury__compress5__start_4_0);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 2, mercury__compress5__start_4_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(0), (MR_Integer) 3, mercury__compress5__start_4_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 2) = MR_r5;
	MR_r7 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__start_4_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r6;
	Mutvar = MR_r7;
	S0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 740 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r3 = Val;
	MR_r7 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Integer	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__compress5__start_4_0
	IO0 = MR_r4;
	MR_OBTAIN_GLOBAL_LOCK("rd");
{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;
;}
#line 768 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("rd");
	MR_r4 = Byte;
	MR_r8 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r9, MR_mktag(0), (MR_Integer) 2, mercury__compress5__start_4_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(0), (MR_Integer) 3, mercury__compress5__start_4_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 2) = MR_r9;
	MR_r11 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r12 = ((MR_Integer) MR_r3 + (MR_Integer) 8);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__start_4_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r10;
	Mutvar = MR_r11;
	Val = MR_r12;
	S0 = MR_r7;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 804 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r3 = S;
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(6, "compress5:start/4");
	MR_stackvar(6) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r4 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__compress5__start_4_0_i2);
	}
	MR_r1 = MR_r8;
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury__compress5__start_4_0_i2);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r8;
	MR_stackvar(4) = MR_r1;
	MR_stackvar(5) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r2 = (MR_Integer) 138002;
	MR_r3 = (MR_Integer) -1;
	MR_call_localret(MR_ENTRY(mercury__array__init_3_0),
		mercury__compress5__start_4_0_i4,
		MR_ENTRY(mercury__compress5__start_4_0));
MR_define_label(mercury__compress5__start_4_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__start_4_0));
	MR_r4 = MR_r1;
	MR_r1 = MR_stackvar(4);
	MR_r2 = MR_stackvar(5);
	MR_r3 = (MR_Integer) 257;
	MR_r5 = (MR_Integer) 9;
	MR_r6 = MR_stackvar(1);
	MR_r7 = MR_stackvar(2);
	MR_r8 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_localtailcall(mercury__compress5__main_loop_8_0,
		MR_ENTRY(mercury__compress5__start_4_0));
/* code for predicate 'main_loop'/8 in mode 0 */
MR_define_entry(mercury__compress5__main_loop_8_0);
	MR_incr_sp_push_msg(12, "compress5:main_loop/8");
	MR_stackvar(12) = (MR_Word) MR_succip;
	MR_tag_incr_hp_msg(MR_r9, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 2) = MR_r9;
	MR_r11 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r10;
	Mutvar = MR_r11;
	S0 = MR_r7;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 876 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r7 = Val;
	MR_r11 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Integer	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	IO0 = MR_r8;
	MR_OBTAIN_GLOBAL_LOCK("rd");
{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;
;}
#line 904 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("rd");
	MR_r8 = Byte;
	MR_r12 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r13, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r14, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 2) = MR_r13;
	MR_r15 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_r16 = ((MR_Integer) MR_r7 + (MR_Integer) 8);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r14;
	Mutvar = MR_r15;
	Val = MR_r16;
	S0 = MR_r11;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 940 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r7 = S;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r8 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i2);
	}
	MR_stackvar(5) = MR_r6;
	MR_stackvar(10) = MR_r1;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_r12;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__write_code_7_0),
		mercury__compress5__main_loop_8_0_i4,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__main_loop_8_0));
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 1) = MR_stackvar(10);
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_r3;
	MR_r3 = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 3);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r4;
	Mutvar = MR_r3;
	S0 = MR_r1;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 987 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r3 = Val;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	TypeInfo_for_Byte;
	MR_Word	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_Byte = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	Byte = MR_r3;
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("wr");
{
#line 144 "bmio.opt"


 /* if(bmio__wr_buf > bmio__wr_ptr || bmio__wr_ptr >= bmio__wr_eof) {
  fprintf(stderr, "bmio__wr_buf = %p
", bmio__wr_buf);
  fprintf(stderr, "bmio__wr_ptr = %p
", bmio__wr_ptr);
  fprintf(stderr, "bmio__wr_eof = %p
", bmio__wr_eof);
 } */

 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

	*bmio__wr_ptr++ = Byte;

	IO0 = IO;
;}
#line 1023 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("wr");
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
MR_define_label(mercury__compress5__main_loop_8_0_i50);
	MR_succip = (MR_Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	MR_proceed();
MR_define_label(mercury__compress5__main_loop_8_0_i2);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(6) = MR_r7;
	MR_stackvar(8) = (((MR_Integer) MR_r2 << (MR_Integer) 8) | (MR_Integer) MR_r8);
	MR_stackvar(9) = MR_r12;
	MR_stackvar(10) = MR_r1;
	MR_stackvar(11) = MR_r8;
	MR_stackvar(7) = ((MR_Integer) MR_r2 ^ ((MR_Integer) MR_r8 << (MR_Integer) 8));
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r2 = MR_r4;
	MR_r3 = MR_stackvar(7);
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_0),
		mercury__compress5__main_loop_8_0_i5,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__main_loop_8_0));
	if ((MR_r1 != MR_stackvar(8))) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i9);
	}
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_r2;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = ((MR_Integer) MR_stackvar(7) + (MR_Integer) 69001);
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_0),
		mercury__compress5__main_loop_8_0_i10,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i9);
	if (((MR_Integer) MR_r1 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i7);
	}
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_r2;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = ((MR_Integer) MR_stackvar(7) + (MR_Integer) 69001);
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_0),
		mercury__compress5__main_loop_8_0_i10,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__main_loop_8_0));
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r2 = MR_r1;
	MR_r8 = MR_stackvar(9);
	MR_r1 = MR_stackvar(10);
	if (((MR_Integer) MR_r2 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i18);
	}
	if (((MR_Integer) MR_r3 > (MR_Integer) 65535)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i20);
	}
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(10) = MR_r1;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_r8;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__write_code_7_0),
		mercury__compress5__main_loop_8_0_i21,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i7);
	if (((MR_Integer) MR_stackvar(7) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i11);
	}
	MR_r4 = MR_stackvar(3);
	MR_r3 = MR_stackvar(8);
	MR_r1 = MR_stackvar(7);
	MR_r2 = (MR_Integer) 1;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(8) = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__code_table4__lookup_0_6_0),
		mercury__compress5__main_loop_8_0_i14,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i11);
	MR_r4 = MR_stackvar(3);
	MR_r3 = MR_stackvar(8);
	MR_r1 = MR_stackvar(7);
	MR_r2 = ((MR_Integer) 69001 - (MR_Integer) MR_r1);
	MR_stackvar(3) = MR_r4;
	MR_stackvar(8) = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__code_table4__lookup_0_6_0),
		mercury__compress5__main_loop_8_0_i14,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__main_loop_8_0));
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_stackvar(7) = MR_r1;
	MR_r8 = MR_stackvar(9);
	MR_r1 = MR_stackvar(10);
	if (((MR_Integer) MR_r2 == (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i17);
	}
MR_define_label(mercury__compress5__main_loop_8_0_i18);
	MR_succip = (MR_Code *) MR_stackvar(12);
	MR_tag_incr_hp_msg(MR_r9, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 2) = MR_r9;
	MR_r11 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r10;
	Mutvar = MR_r11;
	S0 = MR_r7;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 1168 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r7 = Val;
	MR_r11 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Integer	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	IO0 = MR_r8;
	MR_OBTAIN_GLOBAL_LOCK("rd");
{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;
;}
#line 1196 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("rd");
	MR_r8 = Byte;
	MR_r12 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r13, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r14, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 2) = MR_r13;
	MR_r15 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_r16 = ((MR_Integer) MR_r7 + (MR_Integer) 8);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r14;
	Mutvar = MR_r15;
	Val = MR_r16;
	S0 = MR_r11;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 1232 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r7 = S;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r8 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i2);
	}
	MR_stackvar(5) = MR_r6;
	MR_stackvar(10) = MR_r1;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_r12;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__write_code_7_0),
		mercury__compress5__main_loop_8_0_i4,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i17);
	if (((MR_Integer) MR_r3 > (MR_Integer) 65535)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i20);
	}
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(10) = MR_r1;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_r8;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__write_code_7_0),
		mercury__compress5__main_loop_8_0_i21,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i21);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__main_loop_8_0));
	MR_stackvar(1) = MR_r1;
	MR_r5 = MR_r2;
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_r5;
	MR_stackvar(6) = ((MR_Integer) MR_stackvar(2) + (MR_Integer) 1);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = MR_stackvar(7);
	MR_r4 = MR_stackvar(8);
	MR_call_localret(MR_ENTRY(mercury__array__set_4_0),
		mercury__compress5__main_loop_8_0_i22,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i22);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__main_loop_8_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = ((MR_Integer) MR_stackvar(7) + (MR_Integer) 69001);
	MR_r4 = MR_stackvar(2);
	MR_call_localret(MR_ENTRY(mercury__array__set_4_0),
		mercury__compress5__main_loop_8_0_i23,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i23);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__main_loop_8_0));
	MR_r9 = ((MR_Integer) 1 << (MR_Integer) MR_stackvar(4));
	if (((MR_Integer) MR_stackvar(2) < (MR_Integer) MR_r9)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i24);
	}
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(1);
	MR_r8 = MR_stackvar(3);
	MR_r3 = MR_stackvar(6);
	MR_r4 = MR_r1;
	MR_r5 = ((MR_Integer) MR_stackvar(4) + (MR_Integer) 1);
	MR_r1 = MR_stackvar(10);
	MR_r2 = MR_stackvar(11);
	MR_succip = (MR_Code *) MR_stackvar(12);
	MR_tag_incr_hp_msg(MR_r9, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 2) = MR_r9;
	MR_r11 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r10;
	Mutvar = MR_r11;
	S0 = MR_r7;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 1331 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r7 = Val;
	MR_r11 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Integer	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	IO0 = MR_r8;
	MR_OBTAIN_GLOBAL_LOCK("rd");
{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;
;}
#line 1359 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("rd");
	MR_r8 = Byte;
	MR_r12 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r13, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r14, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 2) = MR_r13;
	MR_r15 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_r16 = ((MR_Integer) MR_r7 + (MR_Integer) 8);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r14;
	Mutvar = MR_r15;
	Val = MR_r16;
	S0 = MR_r11;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 1395 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r7 = S;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r8 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i2);
	}
	MR_stackvar(5) = MR_r6;
	MR_stackvar(10) = MR_r1;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_r12;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__write_code_7_0),
		mercury__compress5__main_loop_8_0_i4,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i24);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(1);
	MR_r8 = MR_stackvar(3);
	MR_r3 = MR_stackvar(6);
	MR_r4 = MR_r1;
	MR_r5 = ((MR_Integer) MR_stackvar(4) + (MR_Integer) 0);
	MR_r1 = MR_stackvar(10);
	MR_r2 = MR_stackvar(11);
	MR_succip = (MR_Code *) MR_stackvar(12);
	MR_tag_incr_hp_msg(MR_r9, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 2) = MR_r9;
	MR_r11 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r10;
	Mutvar = MR_r11;
	S0 = MR_r7;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 1450 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r7 = Val;
	MR_r11 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Integer	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	IO0 = MR_r8;
	MR_OBTAIN_GLOBAL_LOCK("rd");
{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;
;}
#line 1478 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("rd");
	MR_r8 = Byte;
	MR_r12 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r13, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r14, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 2) = MR_r13;
	MR_r15 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_r16 = ((MR_Integer) MR_r7 + (MR_Integer) 8);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r14;
	Mutvar = MR_r15;
	Val = MR_r16;
	S0 = MR_r11;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 1514 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r7 = S;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r8 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i2);
	}
	MR_stackvar(5) = MR_r6;
	MR_stackvar(10) = MR_r1;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_r12;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__write_code_7_0),
		mercury__compress5__main_loop_8_0_i4,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i20);
	MR_tag_incr_hp_msg(MR_r9, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 2) = MR_r9;
	MR_r11 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r10;
	Mutvar = MR_r11;
	S0 = MR_r7;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 1560 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r7 = Val;
	MR_r12 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r13, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r14, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 2) = MR_r13;
	MR_r15 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 1);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r14;
	Mutvar = MR_r15;
	S0 = MR_r12;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 1594 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r12 = Val;
	MR_r16 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r17, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r17, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r17, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r18, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r18, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r18, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r18, (MR_Integer) 2) = MR_r17;
	MR_r19 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 2);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r18;
	Mutvar = MR_r19;
	S0 = MR_r16;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 1628 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r16 = Val;
	MR_r20 = S;
#undef	MR_PROC_LABEL

	}
	MR_r21 = (((MR_Integer) MR_r7 - (MR_Integer) MR_r12) >> (MR_Integer) 11);
	if (((MR_Integer) MR_r21 >= (MR_Integer) MR_r16)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i27);
	}
	MR_r2 = MR_stackvar(1);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r7 = (MR_Integer) 1;
	MR_r6 = MR_r8;
	MR_r5 = MR_r20;
	MR_stackvar(1) = MR_r11;
	MR_r8 = MR_r15;
	MR_r9 = MR_r19;
	if (((MR_Integer) MR_r7 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i30);
	}
MR_define_label(mercury__compress5__main_loop_8_0_i62);
	MR_stackvar(4) = MR_r3;
	MR_stackvar(5) = MR_r4;
	MR_stackvar(10) = MR_r1;
	MR_stackvar(2) = MR_r8;
	MR_stackvar(3) = MR_r9;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__write_code_7_0),
		mercury__compress5__main_loop_8_0_i33,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i27);
	MR_r2 = MR_stackvar(1);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r7 = (MR_Integer) 0;
	MR_r6 = MR_r8;
	MR_r5 = MR_r20;
	MR_stackvar(1) = MR_r11;
	MR_r8 = MR_r15;
	MR_r9 = MR_r19;
	if (((MR_Integer) MR_r7 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i62);
	}
MR_define_label(mercury__compress5__main_loop_8_0_i30);
	MR_stackvar(4) = MR_r3;
	MR_stackvar(5) = MR_r4;
	MR_stackvar(10) = MR_r1;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__write_code_7_0),
		mercury__compress5__main_loop_8_0_i31,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i31);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__main_loop_8_0));
	MR_r7 = MR_r1;
	MR_r1 = MR_stackvar(10);
	MR_r8 = MR_r2;
	MR_r2 = MR_stackvar(11);
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_succip = (MR_Code *) MR_stackvar(12);
	MR_tag_incr_hp_msg(MR_r9, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 2) = MR_r9;
	MR_r11 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r10;
	Mutvar = MR_r11;
	S0 = MR_r7;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 1722 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r7 = Val;
	MR_r11 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Integer	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	IO0 = MR_r8;
	MR_OBTAIN_GLOBAL_LOCK("rd");
{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;
;}
#line 1750 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("rd");
	MR_r8 = Byte;
	MR_r12 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r13, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r14, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 2) = MR_r13;
	MR_r15 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_r16 = ((MR_Integer) MR_r7 + (MR_Integer) 8);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r14;
	Mutvar = MR_r15;
	Val = MR_r16;
	S0 = MR_r11;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 1786 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r7 = S;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r8 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i2);
	}
	MR_stackvar(5) = MR_r6;
	MR_stackvar(10) = MR_r1;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_r12;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__write_code_7_0),
		mercury__compress5__main_loop_8_0_i4,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i33);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__main_loop_8_0));
	MR_r5 = MR_r1;
	MR_r1 = MR_stackvar(10);
	MR_r6 = MR_r2;
	MR_r2 = MR_stackvar(11);
	MR_r3 = MR_stackvar(4);
	MR_r4 = MR_stackvar(5);
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__write_code_7_0),
		mercury__compress5__main_loop_8_0_i34,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i34);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__main_loop_8_0));
	MR_r5 = MR_r1;
	MR_r1 = MR_stackvar(10);
	MR_r6 = MR_r2;
	MR_r2 = (MR_Integer) 256;
	MR_r3 = MR_stackvar(4);
	MR_r4 = MR_stackvar(5);
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__write_code_7_0),
		mercury__compress5__main_loop_8_0_i35,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i35);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__main_loop_8_0));
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 1) = MR_stackvar(10);
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_r3;
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r4;
	Mutvar = MR_stackvar(1);
	Val = (MR_Integer) 0;
	S0 = MR_r1;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 1855 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r5 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 1) = MR_stackvar(10);
	MR_tag_incr_hp_msg(MR_r7, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r7, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r7, (MR_Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), MR_r7, (MR_Integer) 2) = MR_r6;
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r7;
	Mutvar = MR_stackvar(2);
	Val = (MR_Integer) 0;
	S0 = MR_r5;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 1888 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r5 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r8, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r8, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r8, (MR_Integer) 1) = MR_stackvar(10);
	MR_tag_incr_hp_msg(MR_r9, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 2) = MR_r8;
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r9;
	Mutvar = MR_stackvar(3);
	Val = (MR_Integer) 0;
	S0 = MR_r5;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 1921 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r5 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 1) = MR_stackvar(10);
	MR_tag_incr_hp_msg(MR_r11, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 2) = MR_r10;
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r11;
	Mutvar = MR_stackvar(1);
	S0 = MR_r5;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 1953 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r5 = Val;
	MR_r12 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Integer	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("rd");
{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;
;}
#line 1981 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("rd");
	MR_r2 = Byte;
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r13, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 1) = MR_stackvar(10);
	MR_tag_incr_hp_msg(MR_r14, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 2) = MR_r13;
	MR_r15 = ((MR_Integer) MR_r5 + (MR_Integer) 8);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r14;
	Mutvar = MR_stackvar(1);
	Val = MR_r15;
	S0 = MR_r12;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 2016 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r5 = S;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r2 == (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i50);
	}
	MR_stackvar(1) = MR_r5;
	MR_stackvar(2) = MR_r1;
	MR_stackvar(3) = MR_r2;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r2 = (MR_Integer) 138002;
	MR_r3 = (MR_Integer) -1;
	MR_call_localret(MR_ENTRY(mercury__array__init_3_0),
		mercury__compress5__main_loop_8_0_i38,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_define_label(mercury__compress5__main_loop_8_0_i38);
	MR_update_prof_current_proc(MR_LABEL(mercury__compress5__main_loop_8_0));
	MR_r4 = MR_r1;
	MR_r1 = MR_stackvar(10);
	MR_r2 = MR_stackvar(3);
	MR_r3 = (MR_Integer) 257;
	MR_r5 = (MR_Integer) 9;
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(1);
	MR_r8 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(12);
	MR_tag_incr_hp_msg(MR_r9, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 2) = MR_r9;
	MR_r11 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r10;
	Mutvar = MR_r11;
	S0 = MR_r7;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 2072 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r7 = Val;
	MR_r11 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Integer	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	IO0 = MR_r8;
	MR_OBTAIN_GLOBAL_LOCK("rd");
{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;
;}
#line 2100 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("rd");
	MR_r8 = Byte;
	MR_r12 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r13, MR_mktag(0), (MR_Integer) 2, mercury__compress5__main_loop_8_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r14, MR_mktag(0), (MR_Integer) 3, mercury__compress5__main_loop_8_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 2) = MR_r13;
	MR_r15 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_r16 = ((MR_Integer) MR_r7 + (MR_Integer) 8);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__compress5__main_loop_8_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r14;
	Mutvar = MR_r15;
	Val = MR_r16;
	S0 = MR_r11;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 2136 "compress5.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r7 = S;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r8 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__compress5__main_loop_8_0_i2);
	}
	MR_stackvar(5) = MR_r6;
	MR_stackvar(10) = MR_r1;
	MR_r3 = MR_r5;
	MR_r4 = MR_r6;
	MR_r5 = MR_r7;
	MR_r6 = MR_r12;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__write_code_7_0),
		mercury__compress5__main_loop_8_0_i4,
		MR_ENTRY(mercury__compress5__main_loop_8_0));
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__compress5_maybe_bunch_0(void)
{
	compress5_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__compress5__init(void);
void mercury__compress5__init_type_tables(void);
void mercury__compress5__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__compress5__write_out_proc_statics(FILE *fp);
#endif

void mercury__compress5__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__compress5_maybe_bunch_0();
#endif

	mercury__compress5__init_debugger();
}

void mercury__compress5__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}


void mercury__compress5__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__compress5__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
