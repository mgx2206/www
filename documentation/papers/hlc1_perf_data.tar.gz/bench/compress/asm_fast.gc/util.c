/*
** Automatically generated from `util.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__util__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "util.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "util.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 39 "util.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 42 "util.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 48 "util.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 56 "util.c"

extern const struct MR_TypeCtorInfo_Struct mercury_data_util__type_ctor_info_code_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_util__type_ctor_info_byte_0;
MR_define_extern_entry(mercury__fn__util__first_new_code_0_0);
MR_define_extern_entry(mercury__fn__util__clear_code_0_0);
MR_define_extern_entry(mercury__fn__util__empty_code_0_0);
MR_define_extern_entry(mercury__fn__util__max_code_0_0);
MR_define_extern_entry(mercury__fn__util__initial_bpc_0_0);
MR_define_extern_entry(mercury__fn__util__update_bpc_2_0);
MR_declare_label(mercury__fn__util__update_bpc_2_0_i2);
MR_define_extern_entry(mercury__fn__util__lshift_2_0);
MR_define_extern_entry(mercury__fn__util__rshift_2_0);
MR_define_extern_entry(mercury__fn__util__ratio_2_0);
MR_define_extern_entry(mercury____Unify___util__code_0_0);
MR_define_extern_entry(mercury____Compare___util__code_0_0);
MR_declare_label(mercury____Compare___util__code_0_0_i2);
MR_declare_label(mercury____Compare___util__code_0_0_i3);
MR_define_extern_entry(mercury____Unify___util__byte_0_0);
MR_define_extern_entry(mercury____Compare___util__byte_0_0);
MR_declare_label(mercury____Compare___util__byte_0_0_i2);
MR_declare_label(mercury____Compare___util__byte_0_0_i3);
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;

const struct MR_TypeCtorInfo_Struct mercury_data_util__type_ctor_info_code_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___util__code_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___util__code_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___util__code_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"util",
	"code",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0 },
	-1,
	-1
};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;

const struct MR_TypeCtorInfo_Struct mercury_data_util__type_ctor_info_byte_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___util__byte_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___util__byte_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___util__byte_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"util",
	"byte",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0 },
	-1,
	-1
};


MR_BEGIN_MODULE(util_module)
	MR_init_entry(mercury__fn__util__first_new_code_0_0);
	MR_init_entry(mercury__fn__util__clear_code_0_0);
	MR_init_entry(mercury__fn__util__empty_code_0_0);
	MR_init_entry(mercury__fn__util__max_code_0_0);
	MR_init_entry(mercury__fn__util__initial_bpc_0_0);
	MR_init_entry(mercury__fn__util__update_bpc_2_0);
	MR_init_label(mercury__fn__util__update_bpc_2_0_i2);
	MR_init_entry(mercury__fn__util__lshift_2_0);
	MR_init_entry(mercury__fn__util__rshift_2_0);
	MR_init_entry(mercury__fn__util__ratio_2_0);
	MR_init_entry(mercury____Unify___util__code_0_0);
	MR_init_entry(mercury____Compare___util__code_0_0);
	MR_init_label(mercury____Compare___util__code_0_0_i2);
	MR_init_label(mercury____Compare___util__code_0_0_i3);
	MR_init_entry(mercury____Unify___util__byte_0_0);
	MR_init_entry(mercury____Compare___util__byte_0_0);
	MR_init_label(mercury____Compare___util__byte_0_0_i2);
	MR_init_label(mercury____Compare___util__byte_0_0_i3);
MR_BEGIN_CODE

/* code for predicate 'first_new_code'/1 in mode 0 */
MR_define_entry(mercury__fn__util__first_new_code_0_0);
	MR_r1 = (MR_Integer) 257;
	MR_proceed();
/* code for predicate 'clear_code'/1 in mode 0 */
MR_define_entry(mercury__fn__util__clear_code_0_0);
	MR_r1 = (MR_Integer) 256;
	MR_proceed();
/* code for predicate 'empty_code'/1 in mode 0 */
MR_define_entry(mercury__fn__util__empty_code_0_0);
	MR_r1 = (MR_Integer) -1;
	MR_proceed();
/* code for predicate 'max_code'/1 in mode 0 */
MR_define_entry(mercury__fn__util__max_code_0_0);
	MR_r1 = (MR_Integer) 65535;
	MR_proceed();
/* code for predicate 'initial_bpc'/1 in mode 0 */
MR_define_entry(mercury__fn__util__initial_bpc_0_0);
	MR_r1 = (MR_Integer) 9;
	MR_proceed();
/* code for predicate 'update_bpc'/3 in mode 0 */
MR_define_entry(mercury__fn__util__update_bpc_2_0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = ((MR_Integer) 1 << (MR_Integer) MR_r2);
	if (((MR_Integer) MR_r1 < (MR_Integer) MR_tempr1)) {
		MR_GOTO_LABEL(mercury__fn__util__update_bpc_2_0_i2);
	}
	MR_r1 = ((MR_Integer) MR_r2 + (MR_Integer) 1);
	MR_proceed();
	}
MR_define_label(mercury__fn__util__update_bpc_2_0_i2);
	MR_r1 = ((MR_Integer) MR_r2 + (MR_Integer) 0);
	MR_proceed();
/* code for predicate 'lshift'/3 in mode 0 */
MR_define_entry(mercury__fn__util__lshift_2_0);
	MR_r1 = ((MR_Integer) MR_r1 << (MR_Integer) MR_r2);
	MR_proceed();
/* code for predicate 'rshift'/3 in mode 0 */
MR_define_entry(mercury__fn__util__rshift_2_0);
	MR_r1 = ((MR_Integer) MR_r1 >> (MR_Integer) MR_r2);
	MR_proceed();
/* code for predicate 'ratio'/3 in mode 0 */
MR_define_entry(mercury__fn__util__ratio_2_0);
	MR_r1 = (((MR_Integer) MR_r1 - (MR_Integer) MR_r2) >> (MR_Integer) 11);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___util__code_0_0);
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___util__code_0_0);
	if (((MR_Integer) MR_r1 >= (MR_Integer) MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___util__code_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___util__code_0_0_i2);
	if ((MR_r1 != MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___util__code_0_0_i3);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___util__code_0_0_i3);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___util__byte_0_0);
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___util__byte_0_0);
	if (((MR_Integer) MR_r1 >= (MR_Integer) MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___util__byte_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___util__byte_0_0_i2);
	if ((MR_r1 != MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___util__byte_0_0_i3);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___util__byte_0_0_i3);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__util_maybe_bunch_0(void)
{
	util_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__util__init(void);
void mercury__util__init_type_tables(void);
void mercury__util__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__util__write_out_proc_statics(FILE *fp);
#endif

void mercury__util__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__util_maybe_bunch_0();
#endif

	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_util__type_ctor_info_code_0,
		util__code_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_util__type_ctor_info_byte_0,
		util__byte_0_0);
	mercury__util__init_debugger();
}

void mercury__util__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
	MR_register_type_ctor_info(
		&mercury_data_util__type_ctor_info_code_0);
	MR_register_type_ctor_info(
		&mercury_data_util__type_ctor_info_byte_0);
}


void mercury__util__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__util__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
