/*
** Automatically generated from `code_table4.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__code_table4__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "code_table4.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "code_table4.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 39 "code_table4.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

#ifdef MR_HIGHLEVEL_CODE
  bool MR_CALL mercury__array__do_unify__array_1_0(
  	MR_Mercury_Type_Info type_info, MR_Box x, MR_Box y);
  bool MR_CALL mercury__array____Unify____array_1_0(
	MR_Mercury_Type_Info type_info, MR_Array x, MR_Array y);
  void MR_CALL mercury__array__do_compare__array_1_0(MR_Mercury_Type_Info
 	 type_info, MR_Comparison_Result *result, MR_Box x, MR_Box y);
  void MR_CALL mercury__array____Compare____array_1_0(MR_Mercury_Type_Info
	type_info, MR_Comparison_Result *result, MR_Array x, MR_Array y);
#endif

#line 53 "code_table4.c"
#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

#include "mercury_heap.h"		/* for MR_maybe_record_allocation() */
#include "mercury_library_types.h"	/* for MR_ArrayType */

#line 59 "code_table4.c"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType *ML_make_array(MR_Integer size, MR_Word item);

#line 64 "code_table4.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType * ML_resize_array(MR_ArrayType *old_array,
					MR_Integer array_size, MR_Word item);

#line 70 "code_table4.c"
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType * ML_shrink_array(MR_ArrayType *old_array,
					MR_Integer array_size);

#line 76 "code_table4.c"
#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType *ML_copy_array(MR_ArrayType *old_array);

#line 81 "code_table4.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 84 "code_table4.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 90 "code_table4.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 98 "code_table4.c"

extern const struct MR_TypeCtorInfo_Struct mercury_data_code_table4__type_ctor_info_key_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_code_table4__type_ctor_info_hash_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_code_table4__type_ctor_info_code_table_0;
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_array__type_info_array_1__type0_7___int_0;
MR_define_extern_entry(mercury__fn__code_table4__key_2_0);
MR_define_extern_entry(mercury__fn__code_table4__new_code_table_0_0);
MR_define_extern_entry(mercury__code_table4__lookup_6_0);
MR_declare_label(mercury__code_table4__lookup_6_0_i2);
MR_declare_label(mercury__code_table4__lookup_6_0_i6);
MR_declare_label(mercury__code_table4__lookup_6_0_i7);
MR_declare_label(mercury__code_table4__lookup_6_0_i4);
MR_declare_label(mercury__code_table4__lookup_6_0_i8);
MR_declare_label(mercury__code_table4__lookup_6_0_i11);
MR_define_extern_entry(mercury__fn__code_table4__set_4_0);
MR_declare_label(mercury__fn__code_table4__set_4_0_i2);
MR_define_extern_entry(mercury__fn__code_table4__table_size_0_0);
MR_define_extern_entry(mercury__fn__code_table4__array_size_0_0);
MR_define_extern_entry(mercury__fn__code_table4__key_idx_1_0);
MR_define_extern_entry(mercury__fn__code_table4__code_idx_1_0);
MR_define_extern_entry(mercury__fn__code_table4__hash_2_0);
MR_define_extern_entry(mercury__fn__code_table4__hash_delta_1_0);
MR_declare_label(mercury__fn__code_table4__hash_delta_1_0_i2);
MR_define_extern_entry(mercury__code_table4__lookup_0_6_0);
MR_declare_label(mercury__code_table4__lookup_0_6_0_i2);
MR_declare_label(mercury__code_table4__lookup_0_6_0_i4);
MR_declare_label(mercury__code_table4__lookup_0_6_0_i8);
MR_declare_label(mercury__code_table4__lookup_0_6_0_i9);
MR_declare_label(mercury__code_table4__lookup_0_6_0_i6);
MR_define_extern_entry(mercury____Unify___code_table4__code_table_0_0);
MR_define_extern_entry(mercury____Compare___code_table4__code_table_0_0);
MR_define_extern_entry(mercury____Unify___code_table4__hash_0_0);
MR_define_extern_entry(mercury____Compare___code_table4__hash_0_0);
MR_declare_label(mercury____Compare___code_table4__hash_0_0_i2);
MR_declare_label(mercury____Compare___code_table4__hash_0_0_i3);
MR_define_extern_entry(mercury____Unify___code_table4__key_0_0);
MR_define_extern_entry(mercury____Compare___code_table4__key_0_0);
MR_declare_label(mercury____Compare___code_table4__key_0_0_i2);
MR_declare_label(mercury____Compare___code_table4__key_0_0_i3);
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;

const struct MR_TypeCtorInfo_Struct mercury_data_code_table4__type_ctor_info_key_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___code_table4__key_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___code_table4__key_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___code_table4__key_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"code_table4",
	"key",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0 },
	-1,
	-1
};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;

const struct MR_TypeCtorInfo_Struct mercury_data_code_table4__type_ctor_info_hash_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___code_table4__hash_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___code_table4__hash_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___code_table4__hash_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"code_table4",
	"hash",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0 },
	-1,
	-1
};
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_array__type_info_array_1__type0_7___int_0;

const struct MR_TypeCtorInfo_Struct mercury_data_code_table4__type_ctor_info_code_table_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___code_table4__code_table_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___code_table4__code_table_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___code_table4__code_table_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"code_table4",
	"code_table",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_array__type_info_array_1__type0_7___int_0 },
	-1,
	-1
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_array__type_ctor_info_array_1;

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_array__type_info_array_1__type0_7___int_0 = {
	&mercury_data_array__type_ctor_info_array_1,
{	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0
}};

extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;
MR_declare_entry(mercury__array__init_3_0);
MR_declare_entry(mercury__array__lookup_3_0);
MR_declare_entry(mercury__array__set_4_0);
MR_declare_entry(mercury____Unify___array__array_1_0);
MR_declare_entry(mercury____Compare___array__array_1_0);

MR_BEGIN_MODULE(code_table4_module)
	MR_init_entry(mercury__fn__code_table4__key_2_0);
	MR_init_entry(mercury__fn__code_table4__new_code_table_0_0);
	MR_init_entry(mercury__code_table4__lookup_6_0);
	MR_init_label(mercury__code_table4__lookup_6_0_i2);
	MR_init_label(mercury__code_table4__lookup_6_0_i6);
	MR_init_label(mercury__code_table4__lookup_6_0_i7);
	MR_init_label(mercury__code_table4__lookup_6_0_i4);
	MR_init_label(mercury__code_table4__lookup_6_0_i8);
	MR_init_label(mercury__code_table4__lookup_6_0_i11);
	MR_init_entry(mercury__fn__code_table4__set_4_0);
	MR_init_label(mercury__fn__code_table4__set_4_0_i2);
	MR_init_entry(mercury__fn__code_table4__table_size_0_0);
	MR_init_entry(mercury__fn__code_table4__array_size_0_0);
	MR_init_entry(mercury__fn__code_table4__key_idx_1_0);
	MR_init_entry(mercury__fn__code_table4__code_idx_1_0);
	MR_init_entry(mercury__fn__code_table4__hash_2_0);
	MR_init_entry(mercury__fn__code_table4__hash_delta_1_0);
	MR_init_label(mercury__fn__code_table4__hash_delta_1_0_i2);
	MR_init_entry(mercury__code_table4__lookup_0_6_0);
	MR_init_label(mercury__code_table4__lookup_0_6_0_i2);
	MR_init_label(mercury__code_table4__lookup_0_6_0_i4);
	MR_init_label(mercury__code_table4__lookup_0_6_0_i8);
	MR_init_label(mercury__code_table4__lookup_0_6_0_i9);
	MR_init_label(mercury__code_table4__lookup_0_6_0_i6);
	MR_init_entry(mercury____Unify___code_table4__code_table_0_0);
	MR_init_entry(mercury____Compare___code_table4__code_table_0_0);
	MR_init_entry(mercury____Unify___code_table4__hash_0_0);
	MR_init_entry(mercury____Compare___code_table4__hash_0_0);
	MR_init_label(mercury____Compare___code_table4__hash_0_0_i2);
	MR_init_label(mercury____Compare___code_table4__hash_0_0_i3);
	MR_init_entry(mercury____Unify___code_table4__key_0_0);
	MR_init_entry(mercury____Compare___code_table4__key_0_0);
	MR_init_label(mercury____Compare___code_table4__key_0_0_i2);
	MR_init_label(mercury____Compare___code_table4__key_0_0_i3);
MR_BEGIN_CODE

/* code for predicate 'key'/3 in mode 0 */
MR_define_entry(mercury__fn__code_table4__key_2_0);
	MR_r1 = (((MR_Integer) MR_r1 << (MR_Integer) 8) | (MR_Integer) MR_r2);
	MR_proceed();
/* code for predicate 'new_code_table'/1 in mode 0 */
MR_define_entry(mercury__fn__code_table4__new_code_table_0_0);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r2 = (MR_Integer) 138002;
	MR_r3 = (MR_Integer) -1;
	MR_tailcall(MR_ENTRY(mercury__array__init_3_0),
		MR_ENTRY(mercury__fn__code_table4__new_code_table_0_0));
/* code for predicate 'lookup'/6 in mode 0 */
MR_define_entry(mercury__code_table4__lookup_6_0);
	MR_incr_sp_push_msg(4, "code_table4:lookup/6");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r3;
	MR_stackvar(2) = (((MR_Integer) MR_r1 << (MR_Integer) 8) | (MR_Integer) MR_r2);
	MR_stackvar(3) = ((MR_Integer) MR_r1 ^ ((MR_Integer) MR_r2 << (MR_Integer) 8));
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r2 = MR_r3;
	MR_r3 = MR_stackvar(3);
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_0),
		mercury__code_table4__lookup_6_0_i2,
		MR_ENTRY(mercury__code_table4__lookup_6_0));
MR_define_label(mercury__code_table4__lookup_6_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__code_table4__lookup_6_0));
	if ((MR_r1 != MR_stackvar(2))) {
		MR_GOTO_LABEL(mercury__code_table4__lookup_6_0_i6);
	}
	MR_r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_stackvar(3);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = ((MR_Integer) MR_stackvar(1) + (MR_Integer) 69001);
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_0),
		mercury__code_table4__lookup_6_0_i7,
		MR_ENTRY(mercury__code_table4__lookup_6_0));
MR_define_label(mercury__code_table4__lookup_6_0_i6);
	if (((MR_Integer) MR_r1 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__code_table4__lookup_6_0_i4);
	}
	MR_r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_stackvar(3);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = ((MR_Integer) MR_stackvar(1) + (MR_Integer) 69001);
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_0),
		mercury__code_table4__lookup_6_0_i7,
		MR_ENTRY(mercury__code_table4__lookup_6_0));
MR_define_label(mercury__code_table4__lookup_6_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__code_table4__lookup_6_0));
	MR_r3 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__code_table4__lookup_6_0_i4);
	if (((MR_Integer) MR_stackvar(3) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__code_table4__lookup_6_0_i8);
	}
	MR_r4 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_r1 = MR_stackvar(3);
	MR_r2 = (MR_Integer) 1;
	MR_stackvar(2) = MR_r3;
	MR_localcall(mercury__code_table4__lookup_0_6_0,
		MR_LABEL(mercury__code_table4__lookup_6_0_i11),
		MR_ENTRY(mercury__code_table4__lookup_6_0));
MR_define_label(mercury__code_table4__lookup_6_0_i8);
	MR_r4 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_r1 = MR_stackvar(3);
	MR_r2 = ((MR_Integer) 69001 - (MR_Integer) MR_r1);
	MR_stackvar(2) = MR_r3;
	MR_localcall(mercury__code_table4__lookup_0_6_0,
		MR_LABEL(mercury__code_table4__lookup_6_0_i11),
		MR_ENTRY(mercury__code_table4__lookup_6_0));
MR_define_label(mercury__code_table4__lookup_6_0_i11);
	MR_update_prof_current_proc(MR_LABEL(mercury__code_table4__lookup_6_0));
	MR_r3 = MR_r2;
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate 'set'/5 in mode 0 */
MR_define_entry(mercury__fn__code_table4__set_4_0);
	MR_incr_sp_push_msg(3, "code_table4:set/5");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r4;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r4 = MR_r3;
	MR_r3 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__array__set_4_0),
		mercury__fn__code_table4__set_4_0_i2,
		MR_ENTRY(mercury__fn__code_table4__set_4_0));
MR_define_label(mercury__fn__code_table4__set_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__code_table4__set_4_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = ((MR_Integer) MR_stackvar(1) + (MR_Integer) 69001);
	MR_r4 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury__array__set_4_0),
		MR_ENTRY(mercury__fn__code_table4__set_4_0));
/* code for predicate 'table_size'/1 in mode 0 */
MR_define_entry(mercury__fn__code_table4__table_size_0_0);
	MR_r1 = (MR_Integer) 69001;
	MR_proceed();
/* code for predicate 'array_size'/1 in mode 0 */
MR_define_entry(mercury__fn__code_table4__array_size_0_0);
	MR_r1 = (MR_Integer) 138002;
	MR_proceed();
/* code for predicate 'key_idx'/2 in mode 0 */
MR_define_entry(mercury__fn__code_table4__key_idx_1_0);
	MR_proceed();
/* code for predicate 'code_idx'/2 in mode 0 */
MR_define_entry(mercury__fn__code_table4__code_idx_1_0);
	MR_r1 = ((MR_Integer) MR_r1 + (MR_Integer) 69001);
	MR_proceed();
/* code for predicate 'hash'/3 in mode 0 */
MR_define_entry(mercury__fn__code_table4__hash_2_0);
	MR_r1 = ((MR_Integer) MR_r1 ^ ((MR_Integer) MR_r2 << (MR_Integer) 8));
	MR_proceed();
/* code for predicate 'hash_delta'/2 in mode 0 */
MR_define_entry(mercury__fn__code_table4__hash_delta_1_0);
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__code_table4__hash_delta_1_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury__fn__code_table4__hash_delta_1_0_i2);
	MR_r1 = ((MR_Integer) 69001 - (MR_Integer) MR_r1);
	MR_proceed();
/* code for predicate 'lookup_0'/6 in mode 0 */
MR_define_entry(mercury__code_table4__lookup_0_6_0);
	MR_incr_sp_push_msg(5, "code_table4:lookup_0/6");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_r5 = ((MR_Integer) MR_r1 - (MR_Integer) MR_r2);
	if (((MR_Integer) MR_r2 > (MR_Integer) MR_r1)) {
		MR_GOTO_LABEL(mercury__code_table4__lookup_0_6_0_i2);
	}
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_r2 = MR_r4;
	MR_r3 = ((MR_Integer) MR_r5 + (MR_Integer) 0);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(3) = MR_r2;
	MR_stackvar(4) = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_0),
		mercury__code_table4__lookup_0_6_0_i4,
		MR_ENTRY(mercury__code_table4__lookup_0_6_0));
MR_define_label(mercury__code_table4__lookup_0_6_0_i2);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_r2 = MR_r4;
	MR_r3 = ((MR_Integer) MR_r5 + (MR_Integer) 69001);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(3) = MR_r2;
	MR_stackvar(4) = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_0),
		mercury__code_table4__lookup_0_6_0_i4,
		MR_ENTRY(mercury__code_table4__lookup_0_6_0));
MR_define_label(mercury__code_table4__lookup_0_6_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__code_table4__lookup_0_6_0));
	if ((MR_r1 != MR_stackvar(2))) {
		MR_GOTO_LABEL(mercury__code_table4__lookup_0_6_0_i8);
	}
	MR_r2 = MR_stackvar(3);
	MR_stackvar(1) = MR_stackvar(4);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = ((MR_Integer) MR_stackvar(1) + (MR_Integer) 69001);
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_0),
		mercury__code_table4__lookup_0_6_0_i9,
		MR_ENTRY(mercury__code_table4__lookup_0_6_0));
MR_define_label(mercury__code_table4__lookup_0_6_0_i8);
	if (((MR_Integer) MR_r1 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__code_table4__lookup_0_6_0_i6);
	}
	MR_r2 = MR_stackvar(3);
	MR_stackvar(1) = MR_stackvar(4);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = ((MR_Integer) MR_stackvar(1) + (MR_Integer) 69001);
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_0),
		mercury__code_table4__lookup_0_6_0_i9,
		MR_ENTRY(mercury__code_table4__lookup_0_6_0));
MR_define_label(mercury__code_table4__lookup_0_6_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__code_table4__lookup_0_6_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury__code_table4__lookup_0_6_0_i6);
	MR_r1 = MR_stackvar(4);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_r5 = ((MR_Integer) MR_r1 - (MR_Integer) MR_tempr1);
	if (((MR_Integer) MR_tempr1 > (MR_Integer) MR_r1)) {
		MR_GOTO_LABEL(mercury__code_table4__lookup_0_6_0_i2);
	}
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_r2 = MR_r4;
	MR_r3 = ((MR_Integer) MR_r5 + (MR_Integer) 0);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(3) = MR_r2;
	MR_stackvar(4) = MR_r3;
	}
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_0),
		mercury__code_table4__lookup_0_6_0_i4,
		MR_ENTRY(mercury__code_table4__lookup_0_6_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___code_table4__code_table_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_tailcall(MR_ENTRY(mercury____Unify___array__array_1_0),
		MR_ENTRY(mercury____Unify___code_table4__code_table_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___code_table4__code_table_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_tailcall(MR_ENTRY(mercury____Compare___array__array_1_0),
		MR_ENTRY(mercury____Compare___code_table4__code_table_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___code_table4__hash_0_0);
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___code_table4__hash_0_0);
	if (((MR_Integer) MR_r1 >= (MR_Integer) MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___code_table4__hash_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___code_table4__hash_0_0_i2);
	if ((MR_r1 != MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___code_table4__hash_0_0_i3);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___code_table4__hash_0_0_i3);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___code_table4__key_0_0);
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___code_table4__key_0_0);
	if (((MR_Integer) MR_r1 >= (MR_Integer) MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___code_table4__key_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___code_table4__key_0_0_i2);
	if ((MR_r1 != MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___code_table4__key_0_0_i3);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___code_table4__key_0_0_i3);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__code_table4_maybe_bunch_0(void)
{
	code_table4_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__code_table4__init(void);
void mercury__code_table4__init_type_tables(void);
void mercury__code_table4__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__code_table4__write_out_proc_statics(FILE *fp);
#endif

void mercury__code_table4__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__code_table4_maybe_bunch_0();
#endif

	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_code_table4__type_ctor_info_key_0,
		code_table4__key_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_code_table4__type_ctor_info_hash_0,
		code_table4__hash_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_code_table4__type_ctor_info_code_table_0,
		code_table4__code_table_0_0);
	mercury__code_table4__init_debugger();
}

void mercury__code_table4__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
	MR_register_type_ctor_info(
		&mercury_data_code_table4__type_ctor_info_key_0);
	MR_register_type_ctor_info(
		&mercury_data_code_table4__type_ctor_info_hash_0);
	MR_register_type_ctor_info(
		&mercury_data_code_table4__type_ctor_info_code_table_0);
}


void mercury__code_table4__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__code_table4__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
