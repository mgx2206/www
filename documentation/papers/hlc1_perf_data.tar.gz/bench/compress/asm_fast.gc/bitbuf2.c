/*
** Automatically generated from `bitbuf2.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__bitbuf2__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "bitbuf2.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "bitbuf2.c"
#line 3 "bmio.opt"


#include <stdio.h>
#include <malloc.h>
#include <assert.h>

unsigned int	 bmio__buf_size;
unsigned char	*bmio__plain_buf;
unsigned char	*bmio__plain_buf_eof;
unsigned char	*bmio__zipped_buf;
unsigned char	*bmio__zipped_buf_eof;
unsigned char	*bmio__rd_buf;
unsigned char	*bmio__rd_ptr;
unsigned char	*bmio__rd_eof;
unsigned char	*bmio__wr_buf;
unsigned char	*bmio__wr_ptr;
unsigned char	*bmio__wr_eof;
FILE		*bmio__fp;


#line 54 "bitbuf2.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 61 "bitbuf2.c"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	#include "mercury_type_info.h"
	#include "mercury_heap.h"
	#include "mercury_misc.h"	/* for MR_fatal_error() */

	/* ML_arg() is defined in std_util.m */
	bool ML_arg(MR_TypeInfo term_type_info, MR_Word *term, int arg_index,
			MR_TypeInfo *arg_type_info_ptr, MR_Word **arg_ptr);


#line 73 "bitbuf2.c"
#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	extern MR_Word		ML_io_stream_names;
	extern MR_Word		ML_io_user_globals;
	#if 0
	  extern MR_Word	ML_io_ops_table;
	#endif

#line 82 "bitbuf2.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
#ifdef HAVE_SYS_STAT_H
	#include <sys/stat.h>
#endif

#line 92 "bitbuf2.c"
#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include "mercury_init.h"
#include "mercury_wrapper.h"
#include "mercury_type_info.h"
#include "mercury_library_types.h"
#include "mercury_file.h"
#include "mercury_heap.h"
#include "mercury_misc.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

#ifdef HAVE_SYS_WAIT
  #include <sys/wait.h>		/* for WIFEXITED, WEXITSTATUS, etc. */
#endif

extern MercuryFile mercury_stdin;
extern MercuryFile mercury_stdout;
extern MercuryFile mercury_stderr;
extern MercuryFile mercury_stdin_binary;
extern MercuryFile mercury_stdout_binary;
extern MercuryFile *mercury_current_text_input;
extern MercuryFile *mercury_current_text_output;
extern MercuryFile *mercury_current_binary_input;
extern MercuryFile *mercury_current_binary_output;

#define initial_io_state()		0	/* some random number */
#define update_io(r_src, r_dest)	((r_dest) = (r_src))
#define final_io_state(r)		((void)0)

void 		mercury_init_io(void);
MercuryFile*	mercury_open(const char *filename, const char *type);
void		mercury_io_error(MercuryFile* mf, const char *format, ...);
void		mercury_output_error(MercuryFile* mf);
void		mercury_print_string(MercuryFile* mf, const char *s);
void		mercury_print_binary_string(MercuryFile* mf, const char *s);
int		mercury_getc(MercuryFile* mf);
void		mercury_close(MercuryFile* mf);
int		ML_fprintf(MercuryFile* mf, const char *format, ...);

#line 138 "bitbuf2.c"
#line 106 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <fcntl.h>

	#define	MAX_TEMPNAME_TRIES	(6 * 4)

	extern long ML_io_tempnam_counter;

#line 152 "bitbuf2.c"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include <string.h>
#include <errno.h>

/*
** ML_maybe_make_err_msg(was_error, msg, procname, error_msg):
**	if `was_error' is true, then append `msg' and `strerror(errno)'
**	to give `error_msg'; otherwise, set `error_msg' to NULL.
**
** WARNING: this must only be called when the `hp' register is valid.
** That means it must only be called from procedures declared
** `will_not_call_mercury'.
**
** This is defined as a macro rather than a C function
** to avoid worrying about the `hp' register being
** invalidated by the function call.
** It also needs to be a macro because MR_incr_hp_atomic_msg()
** stringizes the procname argument.
*/
#define ML_maybe_make_err_msg(was_error, msg, procname, error_msg)	\
	do {								\
		char *errno_msg;					\
		size_t total_len;					\
		MR_Word tmp;						\
									\
		if (was_error) {					\
			errno_msg = strerror(errno);			\
			total_len = strlen(msg) + strlen(errno_msg);	\
			MR_incr_hp_atomic_msg(tmp,			\
				(total_len + sizeof(MR_Word))		\
					/ sizeof(MR_Word),		\
				procname,				\
				"string:string/0");			\
			(error_msg) = (char *)tmp;			\
			strcpy((error_msg), msg);			\
			strcat((error_msg), errno_msg);			\
		} else {						\
			(error_msg) = NULL;				\
		}							\
	} while(0)


#line 197 "bitbuf2.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 200 "bitbuf2.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 206 "bitbuf2.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 214 "bitbuf2.c"

extern const struct MR_TypeCtorInfo_Struct mercury_data_bitbuf2__type_ctor_info_bitbuf_1;
extern const MR_DuFunctorDesc * mercury_data_bitbuf2__du_name_ordered_bitbuf_1[];
static const MR_DuFunctorDesc mercury_data_bitbuf2__du_functor_desc_bitbuf_1_0;
extern const MR_ConstString mercury_data_bitbuf2__field_names_bitbuf_1_0[];
extern const MR_PseudoTypeInfo mercury_data_bitbuf2__field_types_bitbuf_1_0[];
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_store__type_info_store_1__var_1;
#ifndef MR_FO_PseudoTypeInfo_Struct2_GUARD
#define MR_FO_PseudoTypeInfo_Struct2_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct2, 2);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct2 mercury_data_store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1;
extern const MR_DuPtagLayout mercury_data_bitbuf2__du_ptag_ordered_bitbuf_1[];
extern const MR_DuFunctorDesc * mercury_data_bitbuf2__du_stag_ordered_bitbuf_1_0[];
MR_define_extern_entry(mercury__bitbuf2__new_bitbuf_2_0);
MR_define_extern_entry(mercury__bitbuf2__read_byte_6_0);
MR_declare_label(mercury__bitbuf2__read_byte_6_0_i2);
MR_define_extern_entry(mercury__bitbuf2__write_code_7_0);
MR_declare_label(mercury__bitbuf2__write_code_7_0_i2);
MR_define_extern_entry(mercury__bitbuf2__compression_ratio_fallen_4_0);
MR_declare_label(mercury__bitbuf2__compression_ratio_fallen_4_0_i2);
MR_define_extern_entry(mercury__bitbuf2__reset_compression_ratio_3_0);
MR_define_extern_entry(mercury__bitbuf2__flush_buffer_5_0);
MR_define_extern_entry(mercury__bitbuf2__write_full_bytes_6_0);
MR_declare_label(mercury__bitbuf2__write_full_bytes_6_0_i13);
MR_declare_label(mercury__bitbuf2__write_full_bytes_6_0_i4);
MR_define_extern_entry(mercury____Unify___bitbuf2__bitbuf_1_0);
MR_declare_label(mercury____Unify___bitbuf2__bitbuf_1_0_i2);
MR_declare_label(mercury____Unify___bitbuf2__bitbuf_1_0_i4);
MR_declare_label(mercury____Unify___bitbuf2__bitbuf_1_0_i6);
MR_declare_label(mercury____Unify___bitbuf2__bitbuf_1_0_i8);
MR_declare_label(mercury____Unify___bitbuf2__bitbuf_1_0_i1);
MR_define_extern_entry(mercury____Compare___bitbuf2__bitbuf_1_0);
MR_declare_label(mercury____Compare___bitbuf2__bitbuf_1_0_i3);
MR_declare_label(mercury____Compare___bitbuf2__bitbuf_1_0_i7);
MR_declare_label(mercury____Compare___bitbuf2__bitbuf_1_0_i11);
MR_declare_label(mercury____Compare___bitbuf2__bitbuf_1_0_i15);
MR_declare_label(mercury____Compare___bitbuf2__bitbuf_1_0_i22);
extern const MR_DuFunctorDesc * mercury_data_bitbuf2__du_name_ordered_bitbuf_1[];
extern const MR_DuPtagLayout mercury_data_bitbuf2__du_ptag_ordered_bitbuf_1[];

const struct MR_TypeCtorInfo_Struct mercury_data_bitbuf2__type_ctor_info_bitbuf_1 = {
	1,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___bitbuf2__bitbuf_1_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___bitbuf2__bitbuf_1_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___bitbuf2__bitbuf_1_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"bitbuf2",
	"bitbuf",
	4,
	{ (void *) mercury_data_bitbuf2__du_name_ordered_bitbuf_1 },
	{ (void *) mercury_data_bitbuf2__du_ptag_ordered_bitbuf_1 },
	1,
	1
};

const MR_DuFunctorDesc * mercury_data_bitbuf2__du_name_ordered_bitbuf_1[] = {
	&mercury_data_bitbuf2__du_functor_desc_bitbuf_1_0
};

static const MR_DuFunctorDesc mercury_data_bitbuf2__du_functor_desc_bitbuf_1_0 = {
	"bitbuf",
	5,
	31,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_bitbuf2__field_types_bitbuf_1_0,
	mercury_data_bitbuf2__field_names_bitbuf_1_0,
	NULL
};

const MR_ConstString mercury_data_bitbuf2__field_names_bitbuf_1_0[] = {
	"bits_in",
	"bits_out",
	"ratio",
	"data",
	"size"
};

const MR_PseudoTypeInfo mercury_data_bitbuf2__field_types_bitbuf_1_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1,
	(MR_PseudoTypeInfo) &mercury_data_store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1,
	(MR_PseudoTypeInfo) &mercury_data_store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1,
	(MR_PseudoTypeInfo) &mercury_data_store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1,
	(MR_PseudoTypeInfo) &mercury_data_store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_store__type_ctor_info_store_1;

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_store__type_info_store_1__var_1 = {
	&mercury_data_store__type_ctor_info_store_1,
{	(MR_PseudoTypeInfo) 1
}};
extern const struct MR_TypeCtorInfo_Struct mercury_data_store__type_ctor_info_generic_mutvar_2;
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;

#ifndef MR_FO_PseudoTypeInfo_Struct2_GUARD
#define MR_FO_PseudoTypeInfo_Struct2_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct2, 2);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct2 mercury_data_store__type_info_generic_mutvar_2__type0_7___int_0__type_14_store__store_1__var_1 = {
	&mercury_data_store__type_ctor_info_generic_mutvar_2,
{	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_store__type_info_store_1__var_1
}};

const MR_DuPtagLayout mercury_data_bitbuf2__du_ptag_ordered_bitbuf_1[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_bitbuf2__du_stag_ordered_bitbuf_1_0 }

};

const MR_DuFunctorDesc * mercury_data_bitbuf2__du_stag_ordered_bitbuf_1_0[] = {
	&mercury_data_bitbuf2__du_functor_desc_bitbuf_1_0

};

	extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;
	extern const MR_Code * mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__[];
	extern const struct MR_TypeCtorInfo_Struct mercury_data_store__type_ctor_info_some_store_type_0;
	extern const struct MR_TypeCtorInfo_Struct mercury_data_store__type_ctor_info_store_1;
	static const struct mercury_const_1_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_const_1 = {
	(MR_Word *) &mercury_data_store__type_ctor_info_store_1,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0
	};
	static const struct mercury_const_2_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_const_2 = {
	(MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0,
	MR_mkword(MR_mktag(0), &mercury_const_1)
	};
	static const struct mercury_const_3_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_const_3 = {
	(MR_Word *) &mercury_data_store__type_ctor_info_store_1,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0
	};
	static const struct mercury_const_4_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_const_4 = {
	(MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0,
	MR_mkword(MR_mktag(0), &mercury_const_3)
	};
	static const struct mercury_const_5_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_const_5 = {
	(MR_Word *) &mercury_data_store__type_ctor_info_store_1,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0
	};
	static const struct mercury_const_6_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_const_6 = {
	(MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0,
	MR_mkword(MR_mktag(0), &mercury_const_5)
	};
	static const struct mercury_const_7_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_const_7 = {
	(MR_Word *) &mercury_data_store__type_ctor_info_store_1,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0
	};
	static const struct mercury_const_8_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_const_8 = {
	(MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0,
	MR_mkword(MR_mktag(0), &mercury_const_7)
	};
	static const struct mercury_const_9_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_const_9 = {
	(MR_Word *) &mercury_data_store__type_ctor_info_store_1,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0
	};
	static const struct mercury_const_10_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_const_10 = {
	(MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__,
	(MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0,
	MR_mkword(MR_mktag(0), &mercury_const_9)
	};
MR_declare_entry(mercury____Unify___store__generic_mutvar_2_0);
MR_declare_entry(mercury____Compare___store__generic_mutvar_2_0);

MR_BEGIN_MODULE(bitbuf2_module)
	MR_init_entry(mercury__bitbuf2__new_bitbuf_2_0);
	MR_init_entry(mercury__bitbuf2__read_byte_6_0);
	MR_init_label(mercury__bitbuf2__read_byte_6_0_i2);
	MR_init_entry(mercury__bitbuf2__write_code_7_0);
	MR_init_label(mercury__bitbuf2__write_code_7_0_i2);
	MR_init_entry(mercury__bitbuf2__compression_ratio_fallen_4_0);
	MR_init_label(mercury__bitbuf2__compression_ratio_fallen_4_0_i2);
	MR_init_entry(mercury__bitbuf2__reset_compression_ratio_3_0);
	MR_init_entry(mercury__bitbuf2__flush_buffer_5_0);
	MR_init_entry(mercury__bitbuf2__write_full_bytes_6_0);
	MR_init_label(mercury__bitbuf2__write_full_bytes_6_0_i13);
	MR_init_label(mercury__bitbuf2__write_full_bytes_6_0_i4);
	MR_init_entry(mercury____Unify___bitbuf2__bitbuf_1_0);
	MR_init_label(mercury____Unify___bitbuf2__bitbuf_1_0_i2);
	MR_init_label(mercury____Unify___bitbuf2__bitbuf_1_0_i4);
	MR_init_label(mercury____Unify___bitbuf2__bitbuf_1_0_i6);
	MR_init_label(mercury____Unify___bitbuf2__bitbuf_1_0_i8);
	MR_init_label(mercury____Unify___bitbuf2__bitbuf_1_0_i1);
	MR_init_entry(mercury____Compare___bitbuf2__bitbuf_1_0);
	MR_init_label(mercury____Compare___bitbuf2__bitbuf_1_0_i3);
	MR_init_label(mercury____Compare___bitbuf2__bitbuf_1_0_i7);
	MR_init_label(mercury____Compare___bitbuf2__bitbuf_1_0_i11);
	MR_init_label(mercury____Compare___bitbuf2__bitbuf_1_0_i15);
	MR_init_label(mercury____Compare___bitbuf2__bitbuf_1_0_i22);
MR_BEGIN_CODE

/* code for predicate 'new_bitbuf'/2 in mode 0 */
MR_define_entry(mercury__bitbuf2__new_bitbuf_2_0);
	{
#define	MR_PROC_LABEL	mercury__bitbuf2__new_bitbuf_2_0
	MR_OBTAIN_GLOBAL_LOCK("do_init");
	MR_RELEASE_GLOBAL_LOCK("do_init");
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Val;
	MR_Word	Mutvar;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__new_bitbuf_2_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = (MR_Word) MR_mkword(MR_mktag(0), &mercury_const_2);
	Val = (MR_Integer) 0;
	S0 = MR_r4;
	MR_OBTAIN_GLOBAL_LOCK("new_mutvar");
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 486 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("new_mutvar");
	MR_r4 = Mutvar;
	MR_r5 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Val;
	MR_Word	Mutvar;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__new_bitbuf_2_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = (MR_Word) MR_mkword(MR_mktag(0), &mercury_const_4);
	Val = (MR_Integer) 0;
	S0 = MR_r5;
	MR_OBTAIN_GLOBAL_LOCK("new_mutvar");
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 513 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("new_mutvar");
	MR_r5 = Mutvar;
	MR_r6 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Val;
	MR_Word	Mutvar;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__new_bitbuf_2_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = (MR_Word) MR_mkword(MR_mktag(0), &mercury_const_6);
	Val = (MR_Integer) 0;
	S0 = MR_r6;
	MR_OBTAIN_GLOBAL_LOCK("new_mutvar");
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 540 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("new_mutvar");
	MR_r6 = Mutvar;
	MR_r7 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Val;
	MR_Word	Mutvar;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__new_bitbuf_2_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = (MR_Word) MR_mkword(MR_mktag(0), &mercury_const_8);
	Val = (MR_Integer) 0;
	S0 = MR_r7;
	MR_OBTAIN_GLOBAL_LOCK("new_mutvar");
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 567 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("new_mutvar");
	MR_r7 = Mutvar;
	MR_r8 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Val;
	MR_Word	Mutvar;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__new_bitbuf_2_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = (MR_Word) MR_mkword(MR_mktag(0), &mercury_const_10);
	Val = (MR_Integer) 0;
	S0 = MR_r8;
	MR_OBTAIN_GLOBAL_LOCK("new_mutvar");
{
#line 38 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	MR_incr_hp_msg(Mutvar, 1, MR_PROC_LABEL, "store:mutvar/2");
	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 594 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("new_mutvar");
	MR_r8 = Mutvar;
	MR_r3 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 5, mercury__bitbuf2__new_bitbuf_2_0, "bitbuf2:bitbuf/1");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r5;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_r6;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 3) = MR_r7;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 4) = MR_r8;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_some_store_type_0;
	MR_proceed();
/* code for predicate 'read_byte'/6 in mode 0 */
MR_define_entry(mercury__bitbuf2__read_byte_6_0);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__read_byte_6_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__read_byte_6_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 2) = MR_r5;
	MR_r7 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__read_byte_6_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r6;
	Mutvar = MR_r7;
	S0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 638 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r7 = Val;
	MR_r8 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Integer	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bitbuf2__read_byte_6_0
	IO0 = MR_r4;
	MR_OBTAIN_GLOBAL_LOCK("rd");
{
#line 132 "bmio.opt"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;
;}
#line 666 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("rd");
	MR_r4 = Byte;
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r4 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__bitbuf2__read_byte_6_0_i2);
	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__read_byte_6_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r9, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__read_byte_6_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 2) = MR_r4;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r10 = MR_r2;
	MR_r2 = MR_r8;
	MR_r4 = MR_const_field(MR_mktag(0), MR_r10, (MR_Integer) 0);
	MR_r5 = ((MR_Integer) MR_r7 + (MR_Integer) 8);
	MR_r6 = MR_r9;
	MR_r7 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__read_byte_6_0
	TypeInfo_for_T = MR_r7;
	TypeClassInfo_for_store__store_S = MR_r6;
	Mutvar = MR_r4;
	Val = MR_r5;
	S0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 710 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r2 = S;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
MR_define_label(mercury__bitbuf2__read_byte_6_0_i2);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 1, mercury__bitbuf2__read_byte_6_0, "io:result/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_r4;
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__read_byte_6_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__read_byte_6_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 2) = MR_r4;
	MR_r1 = MR_r5;
	MR_r9 = MR_r2;
	MR_r2 = MR_r8;
	MR_r4 = MR_const_field(MR_mktag(0), MR_r9, (MR_Integer) 0);
	MR_r5 = ((MR_Integer) MR_r7 + (MR_Integer) 8);
	MR_r7 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__read_byte_6_0
	TypeInfo_for_T = MR_r7;
	TypeClassInfo_for_store__store_S = MR_r6;
	Mutvar = MR_r4;
	Val = MR_r5;
	S0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 753 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r2 = S;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'write_code'/7 in mode 0 */
MR_define_entry(mercury__bitbuf2__write_code_7_0);
	MR_tag_incr_hp_msg(MR_r7, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__write_code_7_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r7, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r7, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r8, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__write_code_7_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r8, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r8, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r8, (MR_Integer) 2) = MR_r7;
	MR_r9 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__write_code_7_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r8;
	Mutvar = MR_r9;
	S0 = MR_r5;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 789 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r5 = Val;
	MR_r9 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__write_code_7_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r11, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__write_code_7_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 2) = MR_r10;
	MR_r12 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__write_code_7_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r11;
	Mutvar = MR_r12;
	S0 = MR_r9;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 823 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r9 = Val;
	MR_r12 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r13, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__write_code_7_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r13, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r14, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__write_code_7_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r14, (MR_Integer) 2) = MR_r13;
	MR_r15 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 3);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__write_code_7_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r14;
	Mutvar = MR_r15;
	S0 = MR_r12;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 857 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r12 = Val;
	MR_r15 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r16, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__write_code_7_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r16, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r16, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r17, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__write_code_7_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r17, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r17, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r17, (MR_Integer) 2) = MR_r16;
	MR_r18 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 4);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__write_code_7_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r17;
	Mutvar = MR_r18;
	S0 = MR_r15;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 891 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r15 = Val;
	MR_r18 = S;
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(7, "bitbuf2:write_code/7");
	MR_stackvar(7) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r3;
	MR_stackvar(2) = MR_r4;
	MR_stackvar(3) = MR_r5;
	MR_stackvar(4) = MR_r9;
	MR_stackvar(5) = MR_r18;
	MR_stackvar(6) = MR_r1;
	MR_r1 = ((MR_Integer) MR_r12 | ((MR_Integer) MR_r2 << (MR_Integer) MR_r15));
	MR_r2 = ((MR_Integer) MR_r15 + (MR_Integer) MR_r3);
	MR_r3 = MR_r6;
	MR_localcall(mercury__bitbuf2__write_full_bytes_6_0,
		MR_LABEL(mercury__bitbuf2__write_code_7_0_i2),
		MR_ENTRY(mercury__bitbuf2__write_code_7_0));
MR_define_label(mercury__bitbuf2__write_code_7_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__bitbuf2__write_code_7_0));
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__write_code_7_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_stackvar(6);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__write_code_7_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_r4;
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_r7 = ((MR_Integer) MR_stackvar(4) + (MR_Integer) MR_stackvar(1));
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__write_code_7_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r5;
	Mutvar = MR_r6;
	Val = MR_r7;
	S0 = MR_stackvar(5);
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 943 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r6 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r7, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__write_code_7_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r7, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r7, (MR_Integer) 1) = MR_stackvar(6);
	MR_tag_incr_hp_msg(MR_r8, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__write_code_7_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r8, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r8, (MR_Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r8, (MR_Integer) 2) = MR_r7;
	MR_r9 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 2);
	MR_r10 = (((MR_Integer) MR_stackvar(3) - (MR_Integer) MR_stackvar(4)) >> (MR_Integer) 11);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__write_code_7_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r8;
	Mutvar = MR_r9;
	Val = MR_r10;
	S0 = MR_r6;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 978 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r6 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r9, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__write_code_7_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 1) = MR_stackvar(6);
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__write_code_7_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 2) = MR_r9;
	MR_r11 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 3);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__write_code_7_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r10;
	Mutvar = MR_r11;
	Val = MR_r1;
	S0 = MR_r6;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 1012 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r6 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r11, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__write_code_7_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 1) = MR_stackvar(6);
	MR_tag_incr_hp_msg(MR_r12, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__write_code_7_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r12, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r12, (MR_Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r12, (MR_Integer) 2) = MR_r11;
	MR_r4 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 4);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__write_code_7_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r12;
	Mutvar = MR_r4;
	Val = MR_r2;
	S0 = MR_r6;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 1046 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r1 = S;
#undef	MR_PROC_LABEL

	}
	MR_r2 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
/* code for predicate 'compression_ratio_fallen'/4 in mode 0 */
MR_define_entry(mercury__bitbuf2__compression_ratio_fallen_4_0);
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__compression_ratio_fallen_4_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__compression_ratio_fallen_4_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_r4;
	MR_r6 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__compression_ratio_fallen_4_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r5;
	Mutvar = MR_r6;
	S0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 1085 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r3 = Val;
	MR_r6 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r7, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__compression_ratio_fallen_4_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r7, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r7, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r8, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__compression_ratio_fallen_4_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r8, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r8, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r8, (MR_Integer) 2) = MR_r7;
	MR_r9 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__compression_ratio_fallen_4_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r8;
	Mutvar = MR_r9;
	S0 = MR_r6;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 1119 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r6 = Val;
	MR_r9 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__compression_ratio_fallen_4_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r10, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r11, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__compression_ratio_fallen_4_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 2) = MR_r10;
	MR_r4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__compression_ratio_fallen_4_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r11;
	Mutvar = MR_r4;
	S0 = MR_r9;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 1153 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r4 = Val;
	MR_r2 = S;
#undef	MR_PROC_LABEL

	}
	MR_r5 = (((MR_Integer) MR_r3 - (MR_Integer) MR_r6) >> (MR_Integer) 11);
	if (((MR_Integer) MR_r5 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury__bitbuf2__compression_ratio_fallen_4_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury__bitbuf2__compression_ratio_fallen_4_0_i2);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
/* code for predicate 'reset_compression_ratio'/3 in mode 0 */
MR_define_entry(mercury__bitbuf2__reset_compression_ratio_3_0);
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__reset_compression_ratio_3_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__reset_compression_ratio_3_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_r4;
	MR_r6 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__reset_compression_ratio_3_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r5;
	Mutvar = MR_r6;
	Val = (MR_Integer) 0;
	S0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 1199 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r3 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__reset_compression_ratio_3_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r7, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__reset_compression_ratio_3_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r7, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r7, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r7, (MR_Integer) 2) = MR_r6;
	MR_r8 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__reset_compression_ratio_3_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r7;
	Mutvar = MR_r8;
	Val = (MR_Integer) 0;
	S0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 1233 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r3 = S;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r8, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__reset_compression_ratio_3_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r8, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r8, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r9, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__reset_compression_ratio_3_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r9, (MR_Integer) 2) = MR_r8;
	MR_r4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__reset_compression_ratio_3_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r9;
	Mutvar = MR_r4;
	Val = (MR_Integer) 0;
	S0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("set_mutvar");
{
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	* (MR_Word *) Mutvar = Val;
	S = S0;
;}
#line 1267 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("set_mutvar");
	MR_r1 = S;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'flush_buffer'/5 in mode 0 */
MR_define_entry(mercury__bitbuf2__flush_buffer_5_0);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 2, mercury__bitbuf2__flush_buffer_5_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(0), (MR_Integer) 3, mercury__bitbuf2__flush_buffer_5_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data___base_typeclass_info_store__store__arity1__store__store__arity1__;
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_r6, (MR_Integer) 2) = MR_r5;
	MR_r5 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	{
	MR_Word	TypeInfo_for_T;
	MR_Word	TypeClassInfo_for_store__store_S;
	MR_Word	Mutvar;
	MR_Word	Val;
	MR_Word	S0;
	MR_Word	S;
#define	MR_PROC_LABEL	mercury__bitbuf2__flush_buffer_5_0
	TypeInfo_for_T = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	TypeClassInfo_for_store__store_S = MR_r6;
	Mutvar = MR_r5;
	S0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("get_mutvar");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/store.opt"

	Val = * (MR_Word *) Mutvar;
	S = S0;
;}
#line 1303 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("get_mutvar");
	MR_r3 = Val;
	MR_r1 = S;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	TypeInfo_for_Byte;
	MR_Word	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bitbuf2__flush_buffer_5_0
	TypeInfo_for_Byte = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	Byte = MR_r3;
	IO0 = MR_r4;
	MR_OBTAIN_GLOBAL_LOCK("wr");
{
#line 144 "bmio.opt"


 /* if(bmio__wr_buf > bmio__wr_ptr || bmio__wr_ptr >= bmio__wr_eof) {
  fprintf(stderr, "bmio__wr_buf = %p
", bmio__wr_buf);
  fprintf(stderr, "bmio__wr_ptr = %p
", bmio__wr_ptr);
  fprintf(stderr, "bmio__wr_eof = %p
", bmio__wr_eof);
 } */

 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

	*bmio__wr_ptr++ = Byte;

	IO0 = IO;
;}
#line 1340 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("wr");
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'write_full_bytes'/6 in mode 0 */
MR_define_entry(mercury__bitbuf2__write_full_bytes_6_0);
	MR_incr_sp_push_msg(1, "bitbuf2:write_full_bytes/6");
	MR_stackvar(1) = (MR_Word) MR_succip;
MR_define_label(mercury__bitbuf2__write_full_bytes_6_0_i13);
	while (1) {
	if (((MR_Integer) MR_r2 < (MR_Integer) 8)) {
		MR_GOTO_LABEL(mercury__bitbuf2__write_full_bytes_6_0_i4);
	}
	{
	MR_Word	TypeInfo_for_Byte;
	MR_Word	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bitbuf2__write_full_bytes_6_0
	TypeInfo_for_Byte = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	Byte = MR_r1;
	IO0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("wr");
{
#line 144 "bmio.opt"


 /* if(bmio__wr_buf > bmio__wr_ptr || bmio__wr_ptr >= bmio__wr_eof) {
  fprintf(stderr, "bmio__wr_buf = %p
", bmio__wr_buf);
  fprintf(stderr, "bmio__wr_ptr = %p
", bmio__wr_ptr);
  fprintf(stderr, "bmio__wr_eof = %p
", bmio__wr_eof);
 } */

 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

	*bmio__wr_ptr++ = Byte;

	IO0 = IO;
;}
#line 1386 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("wr");
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = ((MR_Integer) MR_r1 >> (MR_Integer) 8);
	MR_r2 = ((MR_Integer) MR_r2 - (MR_Integer) 8);
	if (((MR_Integer) MR_r2 < (MR_Integer) 8)) {
		MR_GOTO_LABEL(mercury__bitbuf2__write_full_bytes_6_0_i4);
	}
	{
	MR_Word	TypeInfo_for_Byte;
	MR_Word	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bitbuf2__write_full_bytes_6_0
	TypeInfo_for_Byte = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	Byte = MR_r1;
	IO0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("wr");
{
#line 144 "bmio.opt"


 /* if(bmio__wr_buf > bmio__wr_ptr || bmio__wr_ptr >= bmio__wr_eof) {
  fprintf(stderr, "bmio__wr_buf = %p
", bmio__wr_buf);
  fprintf(stderr, "bmio__wr_ptr = %p
", bmio__wr_ptr);
  fprintf(stderr, "bmio__wr_eof = %p
", bmio__wr_eof);
 } */

 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

	*bmio__wr_ptr++ = Byte;

	IO0 = IO;
;}
#line 1427 "bitbuf2.c"
	MR_RELEASE_GLOBAL_LOCK("wr");
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = ((MR_Integer) MR_r1 >> (MR_Integer) 8);
	MR_r2 = ((MR_Integer) MR_r2 - (MR_Integer) 8);
	/* continue */ } /* end while */
MR_define_label(mercury__bitbuf2__write_full_bytes_6_0_i4);
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___bitbuf2__bitbuf_1_0);
	MR_incr_sp_push_msg(10, "bitbuf2:__Unify__/2");
	MR_stackvar(10) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury____Unify___bitbuf2__bitbuf_1_0, "private_builtin:type_info/1");
	MR_r5 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 4);
	MR_stackvar(9) = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r6 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r7 = MR_r3;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r7, (MR_Integer) 0);
	}
	MR_call_localret(MR_ENTRY(mercury____Unify___store__generic_mutvar_2_0),
		mercury____Unify___bitbuf2__bitbuf_1_0_i2,
		MR_ENTRY(mercury____Unify___bitbuf2__bitbuf_1_0));
MR_define_label(mercury____Unify___bitbuf2__bitbuf_1_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___bitbuf2__bitbuf_1_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___bitbuf2__bitbuf_1_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury____Unify___bitbuf2__bitbuf_1_0, "private_builtin:type_info/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(9);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = MR_stackvar(1);
	MR_r4 = MR_stackvar(5);
	}
	MR_call_localret(MR_ENTRY(mercury____Unify___store__generic_mutvar_2_0),
		mercury____Unify___bitbuf2__bitbuf_1_0_i4,
		MR_ENTRY(mercury____Unify___bitbuf2__bitbuf_1_0));
MR_define_label(mercury____Unify___bitbuf2__bitbuf_1_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___bitbuf2__bitbuf_1_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___bitbuf2__bitbuf_1_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury____Unify___bitbuf2__bitbuf_1_0, "private_builtin:type_info/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(9);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(6);
	}
	MR_call_localret(MR_ENTRY(mercury____Unify___store__generic_mutvar_2_0),
		mercury____Unify___bitbuf2__bitbuf_1_0_i6,
		MR_ENTRY(mercury____Unify___bitbuf2__bitbuf_1_0));
MR_define_label(mercury____Unify___bitbuf2__bitbuf_1_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___bitbuf2__bitbuf_1_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___bitbuf2__bitbuf_1_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury____Unify___bitbuf2__bitbuf_1_0, "private_builtin:type_info/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(9);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = MR_stackvar(3);
	MR_r4 = MR_stackvar(7);
	}
	MR_call_localret(MR_ENTRY(mercury____Unify___store__generic_mutvar_2_0),
		mercury____Unify___bitbuf2__bitbuf_1_0_i8,
		MR_ENTRY(mercury____Unify___bitbuf2__bitbuf_1_0));
MR_define_label(mercury____Unify___bitbuf2__bitbuf_1_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___bitbuf2__bitbuf_1_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___bitbuf2__bitbuf_1_0_i1);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury____Unify___bitbuf2__bitbuf_1_0, "private_builtin:type_info/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(9);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = MR_stackvar(4);
	MR_r4 = MR_stackvar(8);
	MR_succip = (MR_Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	MR_tailcall(MR_ENTRY(mercury____Unify___store__generic_mutvar_2_0),
		MR_ENTRY(mercury____Unify___bitbuf2__bitbuf_1_0));
	}
MR_define_label(mercury____Unify___bitbuf2__bitbuf_1_0_i1);
	MR_succip = (MR_Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___bitbuf2__bitbuf_1_0);
	MR_incr_sp_push_msg(10, "bitbuf2:__Compare__/3");
	MR_stackvar(10) = (MR_Word) MR_succip;
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury____Compare___bitbuf2__bitbuf_1_0, "private_builtin:type_info/1");
	MR_r5 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_stackvar(9) = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r6 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_r7 = MR_r3;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r7, (MR_Integer) 0);
	}
	MR_call_localret(MR_ENTRY(mercury____Compare___store__generic_mutvar_2_0),
		mercury____Compare___bitbuf2__bitbuf_1_0_i3,
		MR_ENTRY(mercury____Compare___bitbuf2__bitbuf_1_0));
MR_define_label(mercury____Compare___bitbuf2__bitbuf_1_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___bitbuf2__bitbuf_1_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___bitbuf2__bitbuf_1_0_i22);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury____Compare___bitbuf2__bitbuf_1_0, "private_builtin:type_info/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(9);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = MR_stackvar(1);
	MR_r4 = MR_stackvar(5);
	}
	MR_call_localret(MR_ENTRY(mercury____Compare___store__generic_mutvar_2_0),
		mercury____Compare___bitbuf2__bitbuf_1_0_i7,
		MR_ENTRY(mercury____Compare___bitbuf2__bitbuf_1_0));
MR_define_label(mercury____Compare___bitbuf2__bitbuf_1_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___bitbuf2__bitbuf_1_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___bitbuf2__bitbuf_1_0_i22);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury____Compare___bitbuf2__bitbuf_1_0, "private_builtin:type_info/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(9);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(6);
	}
	MR_call_localret(MR_ENTRY(mercury____Compare___store__generic_mutvar_2_0),
		mercury____Compare___bitbuf2__bitbuf_1_0_i11,
		MR_ENTRY(mercury____Compare___bitbuf2__bitbuf_1_0));
MR_define_label(mercury____Compare___bitbuf2__bitbuf_1_0_i11);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___bitbuf2__bitbuf_1_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___bitbuf2__bitbuf_1_0_i22);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury____Compare___bitbuf2__bitbuf_1_0, "private_builtin:type_info/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(9);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = MR_stackvar(3);
	MR_r4 = MR_stackvar(7);
	}
	MR_call_localret(MR_ENTRY(mercury____Compare___store__generic_mutvar_2_0),
		mercury____Compare___bitbuf2__bitbuf_1_0_i15,
		MR_ENTRY(mercury____Compare___bitbuf2__bitbuf_1_0));
MR_define_label(mercury____Compare___bitbuf2__bitbuf_1_0_i15);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___bitbuf2__bitbuf_1_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___bitbuf2__bitbuf_1_0_i22);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury____Compare___bitbuf2__bitbuf_1_0, "private_builtin:type_info/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) (MR_Word *) &mercury_data_store__type_ctor_info_store_1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(9);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = MR_stackvar(4);
	MR_r4 = MR_stackvar(8);
	MR_succip = (MR_Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	MR_tailcall(MR_ENTRY(mercury____Compare___store__generic_mutvar_2_0),
		MR_ENTRY(mercury____Compare___bitbuf2__bitbuf_1_0));
	}
MR_define_label(mercury____Compare___bitbuf2__bitbuf_1_0_i22);
	MR_succip = (MR_Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	MR_proceed();
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__bitbuf2_maybe_bunch_0(void)
{
	bitbuf2_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__bitbuf2__init(void);
void mercury__bitbuf2__init_type_tables(void);
void mercury__bitbuf2__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__bitbuf2__write_out_proc_statics(FILE *fp);
#endif

void mercury__bitbuf2__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__bitbuf2_maybe_bunch_0();
#endif

	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_bitbuf2__type_ctor_info_bitbuf_1,
		bitbuf2__bitbuf_1_0);
	mercury__bitbuf2__init_debugger();
}

void mercury__bitbuf2__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
	MR_register_type_ctor_info(
		&mercury_data_bitbuf2__type_ctor_info_bitbuf_1);
}


void mercury__bitbuf2__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__bitbuf2__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
