/*
** Automatically generated from `harness.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__harness__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "harness.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "harness.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#include <string.h>
#include <stdio.h>

#include "mercury_string.h"	/* for MR_allocate_aligned_string*() etc. */
#include "mercury_tags.h"	/* for MR_list_cons*() */

#line 41 "harness.c"
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#ifdef USE_GCC_GLOBAL_REGISTERS
	/*
	** GNU C version egcs-1.1.2 crashes with `fixed or forbidden
	** register spilled' in grade asm_fast.gc.tr.debug
	** if we write this inline.
	*/
	static void MR_set_char(MR_String str, MR_Integer ind, MR_Char ch)
	{
		str[ind] = ch;
	}
#else
	#define MR_set_char(str, ind, ch) \
		((str)[ind] = (ch))
#endif

#line 59 "harness.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 66 "harness.c"
#line 3 "bmio.opt"


#include <stdio.h>
#include <malloc.h>
#include <assert.h>

unsigned int	 bmio__buf_size;
unsigned char	*bmio__plain_buf;
unsigned char	*bmio__plain_buf_eof;
unsigned char	*bmio__zipped_buf;
unsigned char	*bmio__zipped_buf_eof;
unsigned char	*bmio__rd_buf;
unsigned char	*bmio__rd_ptr;
unsigned char	*bmio__rd_eof;
unsigned char	*bmio__wr_buf;
unsigned char	*bmio__wr_ptr;
unsigned char	*bmio__wr_eof;
FILE		*bmio__fp;


#line 88 "harness.c"
#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	extern MR_Word		ML_io_stream_names;
	extern MR_Word		ML_io_user_globals;
	#if 0
	  extern MR_Word	ML_io_ops_table;
	#endif

#line 97 "harness.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
#ifdef HAVE_SYS_STAT_H
	#include <sys/stat.h>
#endif

#line 107 "harness.c"
#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include "mercury_init.h"
#include "mercury_wrapper.h"
#include "mercury_type_info.h"
#include "mercury_library_types.h"
#include "mercury_file.h"
#include "mercury_heap.h"
#include "mercury_misc.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

#ifdef HAVE_SYS_WAIT
  #include <sys/wait.h>		/* for WIFEXITED, WEXITSTATUS, etc. */
#endif

extern MercuryFile mercury_stdin;
extern MercuryFile mercury_stdout;
extern MercuryFile mercury_stderr;
extern MercuryFile mercury_stdin_binary;
extern MercuryFile mercury_stdout_binary;
extern MercuryFile *mercury_current_text_input;
extern MercuryFile *mercury_current_text_output;
extern MercuryFile *mercury_current_binary_input;
extern MercuryFile *mercury_current_binary_output;

#define initial_io_state()		0	/* some random number */
#define update_io(r_src, r_dest)	((r_dest) = (r_src))
#define final_io_state(r)		((void)0)

void 		mercury_init_io(void);
MercuryFile*	mercury_open(const char *filename, const char *type);
void		mercury_io_error(MercuryFile* mf, const char *format, ...);
void		mercury_output_error(MercuryFile* mf);
void		mercury_print_string(MercuryFile* mf, const char *s);
void		mercury_print_binary_string(MercuryFile* mf, const char *s);
int		mercury_getc(MercuryFile* mf);
void		mercury_close(MercuryFile* mf);
int		ML_fprintf(MercuryFile* mf, const char *format, ...);

#line 153 "harness.c"
#line 106 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <fcntl.h>

	#define	MAX_TEMPNAME_TRIES	(6 * 4)

	extern long ML_io_tempnam_counter;

#line 167 "harness.c"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include <string.h>
#include <errno.h>

/*
** ML_maybe_make_err_msg(was_error, msg, procname, error_msg):
**	if `was_error' is true, then append `msg' and `strerror(errno)'
**	to give `error_msg'; otherwise, set `error_msg' to NULL.
**
** WARNING: this must only be called when the `hp' register is valid.
** That means it must only be called from procedures declared
** `will_not_call_mercury'.
**
** This is defined as a macro rather than a C function
** to avoid worrying about the `hp' register being
** invalidated by the function call.
** It also needs to be a macro because MR_incr_hp_atomic_msg()
** stringizes the procname argument.
*/
#define ML_maybe_make_err_msg(was_error, msg, procname, error_msg)	\
	do {								\
		char *errno_msg;					\
		size_t total_len;					\
		MR_Word tmp;						\
									\
		if (was_error) {					\
			errno_msg = strerror(errno);			\
			total_len = strlen(msg) + strlen(errno_msg);	\
			MR_incr_hp_atomic_msg(tmp,			\
				(total_len + sizeof(MR_Word))		\
					/ sizeof(MR_Word),		\
				procname,				\
				"string:string/0");			\
			(error_msg) = (char *)tmp;			\
			strcpy((error_msg), msg);			\
			strcat((error_msg), errno_msg);			\
		} else {						\
			(error_msg) = NULL;				\
		}							\
	} while(0)


#line 212 "harness.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 215 "harness.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 221 "harness.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 229 "harness.c"


static const struct mercury_data_harness__common_0_struct {
	MR_String f1;
}  mercury_data_harness__common_0;

static const struct mercury_data_harness__common_1_struct {
	MR_Integer f1;
}  mercury_data_harness__common_1;

static const struct mercury_data_harness__common_2_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_data_harness__common_2;

static const struct mercury_data_harness__common_3_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_data_harness__common_3;
MR_declare_static(mercury__harness__test_loop__ho2_4_0);
MR_declare_label(mercury__harness__test_loop__ho2_4_0_i3);
MR_declare_label(mercury__harness__test_loop__ho2_4_0_i4);
MR_declare_label(mercury__harness__test_loop__ho2_4_0_i12);
MR_declare_label(mercury__harness__test_loop__ho2_4_0_i13);
MR_declare_label(mercury__harness__test_loop__ho2_4_0_i7);
MR_declare_label(mercury__harness__test_loop__ho2_4_0_i8);
MR_declare_label(mercury__harness__test_loop__ho2_4_0_i9);
MR_declare_label(mercury__harness__test_loop__ho2_4_0_i10);
MR_declare_label(mercury__harness__test_loop__ho2_4_0_i11);
MR_declare_label(mercury__harness__test_loop__ho2_4_0_i2);
MR_define_extern_entry(mercury__main_2_0);
MR_declare_label(mercury__main_2_0_i7);
MR_declare_label(mercury__main_2_0_i9);
MR_declare_label(mercury__main_2_0_i10);
MR_declare_label(mercury__main_2_0_i11);
MR_declare_label(mercury__main_2_0_i3);
MR_define_extern_entry(mercury__fn__harness__num_iterations_0_0);
MR_define_extern_entry(mercury__harness__test_4_0);
MR_declare_label(mercury__harness__test_4_0_i2);
MR_declare_label(mercury__harness__test_4_0_i3);
MR_declare_label(mercury__harness__test_4_0_i4);
MR_define_extern_entry(mercury__harness__test_loop_4_0);
MR_declare_label(mercury__harness__test_loop_4_0_i3);
MR_declare_label(mercury__harness__test_loop_4_0_i2);

static const struct mercury_data_harness__common_0_struct mercury_data_harness__common_0 = {
	MR_string_const("compress5", 9)
};

static const struct mercury_data_harness__common_1_struct mercury_data_harness__common_1 = {
	(MR_Integer) 10
};

static const struct mercury_data_harness__common_2_struct mercury_data_harness__common_2 = {
	MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_harness__common_1),
	MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0))
};

static const struct mercury_data_harness__common_3_struct mercury_data_harness__common_3 = {
	MR_mkword(MR_mktag(2), (MR_Word *) &mercury_data_harness__common_0),
	MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_harness__common_2)
};

MR_declare_entry(mercury__bitbuf2__new_bitbuf_2_0);
MR_declare_entry(mercury__bitbuf2__read_byte_6_0);
MR_declare_entry(mercury__require__error_1_0);
MR_declare_entry(mercury__fn__util__first_new_code_0_0);
MR_declare_entry(mercury__fn__code_table4__new_code_table_0_0);
MR_declare_entry(mercury__fn__util__initial_bpc_0_0);
MR_declare_entry(mercury__compress5__main_loop_8_0);
MR_declare_entry(mercury__string__base_string_to_int_3_0);
MR_declare_entry(mercury__string__format_3_0);
MR_declare_entry(mercury__io__report_stats_3_0);
MR_declare_entry(mercury__do_call_closure);

MR_BEGIN_MODULE(harness_module)
	MR_init_entry(mercury__harness__test_loop__ho2_4_0);
	MR_init_label(mercury__harness__test_loop__ho2_4_0_i3);
	MR_init_label(mercury__harness__test_loop__ho2_4_0_i4);
	MR_init_label(mercury__harness__test_loop__ho2_4_0_i12);
	MR_init_label(mercury__harness__test_loop__ho2_4_0_i13);
	MR_init_label(mercury__harness__test_loop__ho2_4_0_i7);
	MR_init_label(mercury__harness__test_loop__ho2_4_0_i8);
	MR_init_label(mercury__harness__test_loop__ho2_4_0_i9);
	MR_init_label(mercury__harness__test_loop__ho2_4_0_i10);
	MR_init_label(mercury__harness__test_loop__ho2_4_0_i11);
	MR_init_label(mercury__harness__test_loop__ho2_4_0_i2);
	MR_init_entry(mercury__main_2_0);
	MR_init_label(mercury__main_2_0_i7);
	MR_init_label(mercury__main_2_0_i9);
	MR_init_label(mercury__main_2_0_i10);
	MR_init_label(mercury__main_2_0_i11);
	MR_init_label(mercury__main_2_0_i3);
	MR_init_entry(mercury__fn__harness__num_iterations_0_0);
	MR_init_entry(mercury__harness__test_4_0);
	MR_init_label(mercury__harness__test_4_0_i2);
	MR_init_label(mercury__harness__test_4_0_i3);
	MR_init_label(mercury__harness__test_4_0_i4);
	MR_init_entry(mercury__harness__test_loop_4_0);
	MR_init_label(mercury__harness__test_loop_4_0_i3);
	MR_init_label(mercury__harness__test_loop_4_0_i2);
MR_BEGIN_CODE

/* code for predicate 'test_loop__ho2'/4 in mode 0 */
MR_define_static(mercury__harness__test_loop__ho2_4_0);
	MR_incr_sp_push_msg(9, "harness:test_loop__ho2/4");
	MR_stackvar(9) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r1 <= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__harness__test_loop__ho2_4_0_i2);
	}
	{
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__harness__test_loop__ho2_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("use_compression_io");
{
#line 64 "bmio.opt"


	bmio__rd_buf = bmio__plain_buf;
	bmio__rd_ptr = bmio__plain_buf;
	bmio__rd_eof = bmio__plain_buf_eof;

	bmio__wr_buf = bmio__zipped_buf;
	bmio__wr_ptr = bmio__zipped_buf;
	bmio__wr_eof = bmio__zipped_buf_eof;

	IO0 = IO;
;}
#line 360 "harness.c"
	MR_RELEASE_GLOBAL_LOCK("use_compression_io");
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__new_bitbuf_2_0),
		mercury__harness__test_loop__ho2_4_0_i3,
		MR_STATIC(mercury__harness__test_loop__ho2_4_0));
MR_define_label(mercury__harness__test_loop__ho2_4_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__harness__test_loop__ho2_4_0));
	MR_r4 = MR_stackvar(2);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r1;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__read_byte_6_0),
		mercury__harness__test_loop__ho2_4_0_i4,
		MR_STATIC(mercury__harness__test_loop__ho2_4_0));
MR_define_label(mercury__harness__test_loop__ho2_4_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__harness__test_loop__ho2_4_0));
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__harness__test_loop__ho2_4_0_i7);
	}
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__harness__test_loop__ho2_4_0_i12);
	}
	MR_r2 = MR_r3;
	MR_r1 = ((MR_Integer) MR_stackvar(1) - (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(9);
	if (((MR_Integer) MR_r1 <= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__harness__test_loop__ho2_4_0_i2);
	}
	{
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__harness__test_loop__ho2_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("use_compression_io");
{
#line 64 "bmio.opt"


	bmio__rd_buf = bmio__plain_buf;
	bmio__rd_ptr = bmio__plain_buf;
	bmio__rd_eof = bmio__plain_buf_eof;

	bmio__wr_buf = bmio__zipped_buf;
	bmio__wr_ptr = bmio__zipped_buf;
	bmio__wr_eof = bmio__zipped_buf_eof;

	IO0 = IO;
;}
#line 413 "harness.c"
	MR_RELEASE_GLOBAL_LOCK("use_compression_io");
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__new_bitbuf_2_0),
		mercury__harness__test_loop__ho2_4_0_i3,
		MR_STATIC(mercury__harness__test_loop__ho2_4_0));
MR_define_label(mercury__harness__test_loop__ho2_4_0_i12);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__require__error_1_0),
		mercury__harness__test_loop__ho2_4_0_i13,
		MR_STATIC(mercury__harness__test_loop__ho2_4_0));
MR_define_label(mercury__harness__test_loop__ho2_4_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__harness__test_loop__ho2_4_0));
	MR_r3 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(9);
	if (((MR_Integer) MR_r1 <= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__harness__test_loop__ho2_4_0_i2);
	}
	{
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__harness__test_loop__ho2_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("use_compression_io");
{
#line 64 "bmio.opt"


	bmio__rd_buf = bmio__plain_buf;
	bmio__rd_ptr = bmio__plain_buf;
	bmio__rd_eof = bmio__plain_buf_eof;

	bmio__wr_buf = bmio__zipped_buf;
	bmio__wr_ptr = bmio__zipped_buf;
	bmio__wr_eof = bmio__zipped_buf_eof;

	IO0 = IO;
;}
#line 458 "harness.c"
	MR_RELEASE_GLOBAL_LOCK("use_compression_io");
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__new_bitbuf_2_0),
		mercury__harness__test_loop__ho2_4_0_i3,
		MR_STATIC(mercury__harness__test_loop__ho2_4_0));
MR_define_label(mercury__harness__test_loop__ho2_4_0_i7);
	MR_stackvar(4) = MR_r2;
	MR_stackvar(5) = MR_r3;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__util__first_new_code_0_0),
		mercury__harness__test_loop__ho2_4_0_i8,
		MR_STATIC(mercury__harness__test_loop__ho2_4_0));
MR_define_label(mercury__harness__test_loop__ho2_4_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__harness__test_loop__ho2_4_0));
	MR_stackvar(7) = MR_r1;
	MR_call_localret(MR_ENTRY(mercury__fn__code_table4__new_code_table_0_0),
		mercury__harness__test_loop__ho2_4_0_i9,
		MR_STATIC(mercury__harness__test_loop__ho2_4_0));
MR_define_label(mercury__harness__test_loop__ho2_4_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__harness__test_loop__ho2_4_0));
	MR_stackvar(8) = MR_r1;
	MR_call_localret(MR_ENTRY(mercury__fn__util__initial_bpc_0_0),
		mercury__harness__test_loop__ho2_4_0_i10,
		MR_STATIC(mercury__harness__test_loop__ho2_4_0));
MR_define_label(mercury__harness__test_loop__ho2_4_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__harness__test_loop__ho2_4_0));
	MR_r5 = MR_r1;
	MR_r1 = MR_stackvar(3);
	MR_r2 = MR_stackvar(6);
	MR_r3 = MR_stackvar(7);
	MR_r4 = MR_stackvar(8);
	MR_r6 = MR_stackvar(2);
	MR_r7 = MR_stackvar(4);
	MR_r8 = MR_stackvar(5);
	MR_call_localret(MR_ENTRY(mercury__compress5__main_loop_8_0),
		mercury__harness__test_loop__ho2_4_0_i11,
		MR_STATIC(mercury__harness__test_loop__ho2_4_0));
MR_define_label(mercury__harness__test_loop__ho2_4_0_i11);
	MR_update_prof_current_proc(MR_LABEL(mercury__harness__test_loop__ho2_4_0));
	MR_r2 = MR_r1;
	MR_r1 = ((MR_Integer) MR_stackvar(1) - (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(9);
	if (((MR_Integer) MR_r1 <= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__harness__test_loop__ho2_4_0_i2);
	}
	{
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__harness__test_loop__ho2_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("use_compression_io");
{
#line 64 "bmio.opt"


	bmio__rd_buf = bmio__plain_buf;
	bmio__rd_ptr = bmio__plain_buf;
	bmio__rd_eof = bmio__plain_buf_eof;

	bmio__wr_buf = bmio__zipped_buf;
	bmio__wr_ptr = bmio__zipped_buf;
	bmio__wr_eof = bmio__zipped_buf_eof;

	IO0 = IO;
;}
#line 529 "harness.c"
	MR_RELEASE_GLOBAL_LOCK("use_compression_io");
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__bitbuf2__new_bitbuf_2_0),
		mercury__harness__test_loop__ho2_4_0_i3,
		MR_STATIC(mercury__harness__test_loop__ho2_4_0));
MR_define_label(mercury__harness__test_loop__ho2_4_0_i2);
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
/* code for predicate 'main'/2 in mode 0 */
MR_define_entry(mercury__main_2_0);
	{
	MR_Word	Args;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__main_2_0
	IO0 = MR_r1;
{
#line 652 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	/* convert mercury_argv from a vector to a list */
	{ int i = mercury_argc;
	  Args = MR_list_empty_msg(MR_PROC_LABEL);
	  while (--i >= 0) {
		Args = MR_list_cons_msg((MR_Word) mercury_argv[i], Args,
			MR_PROC_LABEL);
	  }
	}
	update_io(IO0, IO);
;}
#line 566 "harness.c"
	MR_r3 = Args;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(3, "harness:main/2");
	MR_stackvar(3) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__main_2_0_i3);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r5 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__main_2_0_i3);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__main_2_0_i3);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_stackvar(2) = MR_r4;
	MR_r1 = (MR_Integer) 10;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__string__base_string_to_int_3_0),
		mercury__main_2_0_i7,
		MR_ENTRY(mercury__main_2_0));
MR_define_label(mercury__main_2_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__main_2_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__main_2_0_i3);
	}
	{
	MR_String	FileName;
	MR_Integer	NumBytes;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__main_2_0
	FileName = (MR_String) MR_stackvar(1);
	NumBytes = MR_r2;
	IO0 = MR_stackvar(2);
	MR_OBTAIN_GLOBAL_LOCK("init");
{
#line 33 "bmio.opt"


 printf("starting bmio__init
");

	assert(NumBytes > 0);
	bmio__buf_size = NumBytes;

 assert((
	bmio__plain_buf = (char *)malloc(NumBytes * sizeof(char))
		) != NULL);
	bmio__plain_buf_eof = bmio__plain_buf + NumBytes;

 assert((
	bmio__fp = fopen(FileName, "rb")
		) != NULL);
 assert((
	fread(bmio__plain_buf, sizeof(char), NumBytes, bmio__fp)
		) == NumBytes);
	fclose(bmio__fp);

 assert((
	bmio__zipped_buf = (char *)malloc(NumBytes * sizeof(char))
		) != NULL);
	bmio__zipped_buf_eof = bmio__zipped_buf + NumBytes;

 printf("finished bmio__init
");

	IO = IO0;
;}
#line 640 "harness.c"
	MR_RELEASE_GLOBAL_LOCK("init");
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	Stream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__main_2_0
	IO0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("output_stream");
{
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_output;
	update_io(IO0, IO);
;}
#line 659 "harness.c"
	MR_RELEASE_GLOBAL_LOCK("output_stream");
	MR_r3 = Stream;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(1) = MR_r3;
	MR_stackvar(2) = MR_r4;
	MR_r1 = (MR_Word) MR_string_const("\n\n******* %s x %d *******\n", 26);
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_harness__common_3);
	MR_call_localret(MR_ENTRY(mercury__string__format_3_0),
		mercury__main_2_0_i9,
		MR_ENTRY(mercury__main_2_0));
MR_define_label(mercury__main_2_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__main_2_0));
	{
	MR_Word	Stream;
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__main_2_0
	Stream = MR_stackvar(1);
	Message = (MR_String) MR_r1;
	IO0 = MR_stackvar(2);
	MR_save_registers();
{
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile *stream = (MercuryFile *) Stream;
	mercury_print_string(stream, Message);
	update_io(IO0, IO);
};}
#line 692 "harness.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = (MR_Word) MR_string_const("standard", 8);
	MR_call_localret(MR_ENTRY(mercury__io__report_stats_3_0),
		mercury__main_2_0_i10,
		MR_ENTRY(mercury__main_2_0));
MR_define_label(mercury__main_2_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__main_2_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Integer) 10;
	MR_localcall(mercury__harness__test_loop__ho2_4_0,
		MR_LABEL(mercury__main_2_0_i11),
		MR_ENTRY(mercury__main_2_0));
MR_define_label(mercury__main_2_0_i11);
	MR_update_prof_current_proc(MR_LABEL(mercury__main_2_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("standard", 8);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury__io__report_stats_3_0),
		MR_ENTRY(mercury__main_2_0));
MR_define_label(mercury__main_2_0_i3);
	MR_r1 = (MR_Word) MR_string_const("usage: compress <infile> <nbytes>", 33);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury__require__error_1_0),
		MR_ENTRY(mercury__main_2_0));
/* code for predicate 'num_iterations'/1 in mode 0 */
MR_define_entry(mercury__fn__harness__num_iterations_0_0);
	MR_r1 = (MR_Integer) 10;
	MR_proceed();
/* code for predicate 'test'/4 in mode 0 */
MR_define_entry(mercury__harness__test_4_0);
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(2), (MR_Integer) 1, mercury__harness__test_4_0, "string:poly_type/0");
	MR_field(MR_mktag(2), MR_r4, (MR_Integer) 0) = MR_r1;
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__harness__test_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_harness__common_2);
	{
	MR_Word	Stream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__harness__test_4_0
	IO0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("output_stream");
{
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_output;
	update_io(IO0, IO);
;}
#line 749 "harness.c"
	MR_RELEASE_GLOBAL_LOCK("output_stream");
	MR_r3 = Stream;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(4, "harness:test/4");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_r1 = (MR_Word) MR_string_const("\n\n******* %s x %d *******\n", 26);
	MR_r2 = MR_r5;
	MR_call_localret(MR_ENTRY(mercury__string__format_3_0),
		mercury__harness__test_4_0_i2,
		MR_ENTRY(mercury__harness__test_4_0));
MR_define_label(mercury__harness__test_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__harness__test_4_0));
	{
	MR_Word	Stream;
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__harness__test_4_0
	Stream = MR_stackvar(2);
	Message = (MR_String) MR_r1;
	IO0 = MR_stackvar(3);
	MR_save_registers();
{
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile *stream = (MercuryFile *) Stream;
	mercury_print_string(stream, Message);
	update_io(IO0, IO);
};}
#line 785 "harness.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = (MR_Word) MR_string_const("standard", 8);
	MR_call_localret(MR_ENTRY(mercury__io__report_stats_3_0),
		mercury__harness__test_4_0_i3,
		MR_ENTRY(mercury__harness__test_4_0));
MR_define_label(mercury__harness__test_4_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__harness__test_4_0));
	MR_r3 = MR_r1;
	MR_r1 = (MR_Integer) 10;
	MR_r2 = MR_stackvar(1);
	MR_localcall(mercury__harness__test_loop_4_0,
		MR_LABEL(mercury__harness__test_4_0_i4),
		MR_ENTRY(mercury__harness__test_4_0));
MR_define_label(mercury__harness__test_4_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__harness__test_4_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("standard", 8);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury__io__report_stats_3_0),
		MR_ENTRY(mercury__harness__test_4_0));
/* code for predicate 'test_loop'/4 in mode 0 */
MR_define_entry(mercury__harness__test_loop_4_0);
	MR_incr_sp_push_msg(3, "harness:test_loop/4");
	MR_stackvar(3) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r1 <= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__harness__test_loop_4_0_i2);
	}
	{
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__harness__test_loop_4_0
	IO0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("use_compression_io");
{
#line 64 "bmio.opt"


	bmio__rd_buf = bmio__plain_buf;
	bmio__rd_ptr = bmio__plain_buf;
	bmio__rd_eof = bmio__plain_buf_eof;

	bmio__wr_buf = bmio__zipped_buf;
	bmio__wr_ptr = bmio__zipped_buf;
	bmio__wr_eof = bmio__zipped_buf_eof;

	IO0 = IO;
;}
#line 840 "harness.c"
	MR_RELEASE_GLOBAL_LOCK("use_compression_io");
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_r1 = MR_r2;
	MR_r2 = (MR_Integer) 1;
	MR_r3 = (MR_Integer) 1;
	MR_set_prof_ho_caller_proc(MR_ENTRY(mercury__harness__test_loop_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_closure),
		mercury__harness__test_loop_4_0_i3);
MR_define_label(mercury__harness__test_loop_4_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__harness__test_loop_4_0));
	MR_r3 = MR_r1;
	MR_r1 = ((MR_Integer) MR_stackvar(1) - (MR_Integer) 1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	if (((MR_Integer) MR_r1 <= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__harness__test_loop_4_0_i2);
	}
	{
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__harness__test_loop_4_0
	IO0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("use_compression_io");
{
#line 64 "bmio.opt"


	bmio__rd_buf = bmio__plain_buf;
	bmio__rd_ptr = bmio__plain_buf;
	bmio__rd_eof = bmio__plain_buf_eof;

	bmio__wr_buf = bmio__zipped_buf;
	bmio__wr_ptr = bmio__zipped_buf;
	bmio__wr_eof = bmio__zipped_buf_eof;

	IO0 = IO;
;}
#line 883 "harness.c"
	MR_RELEASE_GLOBAL_LOCK("use_compression_io");
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_r1 = MR_r2;
	MR_r2 = (MR_Integer) 1;
	MR_r3 = (MR_Integer) 1;
	MR_set_prof_ho_caller_proc(MR_ENTRY(mercury__harness__test_loop_4_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_closure),
		mercury__harness__test_loop_4_0_i3);
MR_define_label(mercury__harness__test_loop_4_0_i2);
	MR_r1 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__harness_maybe_bunch_0(void)
{
	harness_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__harness__init(void);
void mercury__harness__init_type_tables(void);
void mercury__harness__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__harness__write_out_proc_statics(FILE *fp);
#endif

void mercury__harness__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__harness_maybe_bunch_0();
#endif

	mercury__harness__init_debugger();
}

void mercury__harness__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}


void mercury__harness__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__harness__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
