/*
** Automatically generated from `bmio.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__bmio__init
ENDINIT
*/

#include "mercury_imp.h"
#line 61 "bmio.m"


#include <stdio.h>
#include <malloc.h>
#include <assert.h>

unsigned int	 bmio__buf_size;
unsigned char	*bmio__plain_buf;
unsigned char	*bmio__plain_buf_eof;
unsigned char	*bmio__zipped_buf;
unsigned char	*bmio__zipped_buf_eof;
unsigned char	*bmio__rd_buf;
unsigned char	*bmio__rd_ptr;
unsigned char	*bmio__rd_eof;
unsigned char	*bmio__wr_buf;
unsigned char	*bmio__wr_ptr;
unsigned char	*bmio__wr_eof;
FILE		*bmio__fp;


#line 42 "bmio.c"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 47 "bmio.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 54 "bmio.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#include <string.h>
#include <stdio.h>

#include "mercury_string.h"	/* for MR_allocate_aligned_string*() etc. */
#include "mercury_tags.h"	/* for MR_list_cons*() */

#line 63 "bmio.c"
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#ifdef USE_GCC_GLOBAL_REGISTERS
	/*
	** GNU C version egcs-1.1.2 crashes with `fixed or forbidden
	** register spilled' in grade asm_fast.gc.tr.debug
	** if we write this inline.
	*/
	static void MR_set_char(MR_String str, MR_Integer ind, MR_Char ch)
	{
		str[ind] = ch;
	}
#else
	#define MR_set_char(str, ind, ch) \
		((str)[ind] = (ch))
#endif

#line 81 "bmio.c"
#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	extern MR_Word		ML_io_stream_names;
	extern MR_Word		ML_io_user_globals;
	#if 0
	  extern MR_Word	ML_io_ops_table;
	#endif

#line 90 "bmio.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
#ifdef HAVE_SYS_STAT_H
	#include <sys/stat.h>
#endif

#line 100 "bmio.c"
#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include "mercury_init.h"
#include "mercury_wrapper.h"
#include "mercury_type_info.h"
#include "mercury_library_types.h"
#include "mercury_file.h"
#include "mercury_heap.h"
#include "mercury_misc.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

#ifdef HAVE_SYS_WAIT
  #include <sys/wait.h>		/* for WIFEXITED, WEXITSTATUS, etc. */
#endif

extern MercuryFile mercury_stdin;
extern MercuryFile mercury_stdout;
extern MercuryFile mercury_stderr;
extern MercuryFile mercury_stdin_binary;
extern MercuryFile mercury_stdout_binary;
extern MercuryFile *mercury_current_text_input;
extern MercuryFile *mercury_current_text_output;
extern MercuryFile *mercury_current_binary_input;
extern MercuryFile *mercury_current_binary_output;

#define initial_io_state()		0	/* some random number */
#define update_io(r_src, r_dest)	((r_dest) = (r_src))
#define final_io_state(r)		((void)0)

void 		mercury_init_io(void);
MercuryFile*	mercury_open(const char *filename, const char *type);
void		mercury_io_error(MercuryFile* mf, const char *format, ...);
void		mercury_output_error(MercuryFile* mf);
void		mercury_print_string(MercuryFile* mf, const char *s);
void		mercury_print_binary_string(MercuryFile* mf, const char *s);
int		mercury_getc(MercuryFile* mf);
void		mercury_close(MercuryFile* mf);
int		ML_fprintf(MercuryFile* mf, const char *format, ...);

#line 146 "bmio.c"
#line 106 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <fcntl.h>

	#define	MAX_TEMPNAME_TRIES	(6 * 4)

	extern long ML_io_tempnam_counter;

#line 160 "bmio.c"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include <string.h>
#include <errno.h>

/*
** ML_maybe_make_err_msg(was_error, msg, procname, error_msg):
**	if `was_error' is true, then append `msg' and `strerror(errno)'
**	to give `error_msg'; otherwise, set `error_msg' to NULL.
**
** WARNING: this must only be called when the `hp' register is valid.
** That means it must only be called from procedures declared
** `will_not_call_mercury'.
**
** This is defined as a macro rather than a C function
** to avoid worrying about the `hp' register being
** invalidated by the function call.
** It also needs to be a macro because MR_incr_hp_atomic_msg()
** stringizes the procname argument.
*/
#define ML_maybe_make_err_msg(was_error, msg, procname, error_msg)	\
	do {								\
		char *errno_msg;					\
		size_t total_len;					\
		MR_Word tmp;						\
									\
		if (was_error) {					\
			errno_msg = strerror(errno);			\
			total_len = strlen(msg) + strlen(errno_msg);	\
			MR_incr_hp_atomic_msg(tmp,			\
				(total_len + sizeof(MR_Word))		\
					/ sizeof(MR_Word),		\
				procname,				\
				"string:string/0");			\
			(error_msg) = (char *)tmp;			\
			strcpy((error_msg), msg);			\
			strcat((error_msg), errno_msg);			\
		} else {						\
			(error_msg) = NULL;				\
		}							\
	} while(0)


#line 205 "bmio.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 208 "bmio.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 214 "bmio.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 222 "bmio.c"


static const struct mercury_data_bmio__common_0_struct {
	MR_String f1;
}  mercury_data_bmio__common_0;

static const struct mercury_data_bmio__common_1_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_data_bmio__common_1;

static const struct mercury_data_bmio__common_2_struct {
	MR_String f1;
}  mercury_data_bmio__common_2;

static const struct mercury_data_bmio__common_3_struct {
	MR_String f1;
}  mercury_data_bmio__common_3;
extern const struct MR_TypeCtorInfo_Struct mercury_data_bmio__type_ctor_info_state_0;
MR_define_extern_entry(mercury__bmio__init_4_0);
MR_define_extern_entry(mercury__bmio__use_compression_io_2_0);
MR_define_extern_entry(mercury__bmio__use_decompression_io_2_0);
MR_define_extern_entry(mercury__bmio__read_byte_3_0);
MR_declare_label(mercury__bmio__read_byte_3_0_i2);
MR_define_extern_entry(mercury__bmio__write_byte_3_0);
MR_define_extern_entry(mercury__bmio__mark_decompression_eof_2_0);
MR_define_extern_entry(mercury__bmio__write_byte_checked_3_0);
MR_define_extern_entry(mercury__bmio__report_stats_2_0);
MR_declare_label(mercury__bmio__report_stats_2_0_i2);
MR_define_extern_entry(mercury__bmio__rd_3_0);
MR_define_extern_entry(mercury__bmio__wr_3_0);
MR_define_extern_entry(mercury__bmio__chk_wr_3_0);
MR_define_extern_entry(mercury__bmio__rd_bytes_3_0);
MR_define_extern_entry(mercury__bmio__wr_bytes_3_0);
MR_define_extern_entry(mercury____Unify___bmio__state_0_0);
MR_define_extern_entry(mercury____Compare___bmio__state_0_0);

static const struct mercury_data_bmio__common_0_struct mercury_data_bmio__common_0 = {
	MR_string_const(" bytes\n", 7)
};

static const struct mercury_data_bmio__common_1_struct mercury_data_bmio__common_1 = {
	MR_mkword(MR_mktag(2), (MR_Word *) &mercury_data_bmio__common_0),
	MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0))
};

static const struct mercury_data_bmio__common_2_struct mercury_data_bmio__common_2 = {
	MR_string_const("bmio: read    ", 14)
};

static const struct mercury_data_bmio__common_3_struct mercury_data_bmio__common_3 = {
	MR_string_const("bmio: written ", 14)
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_state_0;

const struct MR_TypeCtorInfo_Struct mercury_data_bmio__type_ctor_info_state_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___bmio__state_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___bmio__state_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___bmio__state_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"bmio",
	"state",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_io__type_ctor_info_state_0 },
	-1,
	-1
};

	extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;
MR_declare_entry(mercury__io__write_many_4_0);
MR_declare_entry(mercury____Unify___io__state_0_0);
MR_declare_entry(mercury____Compare___io__state_0_0);

MR_BEGIN_MODULE(bmio_module)
	MR_init_entry(mercury__bmio__init_4_0);
	MR_init_entry(mercury__bmio__use_compression_io_2_0);
	MR_init_entry(mercury__bmio__use_decompression_io_2_0);
	MR_init_entry(mercury__bmio__read_byte_3_0);
	MR_init_label(mercury__bmio__read_byte_3_0_i2);
	MR_init_entry(mercury__bmio__write_byte_3_0);
	MR_init_entry(mercury__bmio__mark_decompression_eof_2_0);
	MR_init_entry(mercury__bmio__write_byte_checked_3_0);
	MR_init_entry(mercury__bmio__report_stats_2_0);
	MR_init_label(mercury__bmio__report_stats_2_0_i2);
	MR_init_entry(mercury__bmio__rd_3_0);
	MR_init_entry(mercury__bmio__wr_3_0);
	MR_init_entry(mercury__bmio__chk_wr_3_0);
	MR_init_entry(mercury__bmio__rd_bytes_3_0);
	MR_init_entry(mercury__bmio__wr_bytes_3_0);
	MR_init_entry(mercury____Unify___bmio__state_0_0);
	MR_init_entry(mercury____Compare___bmio__state_0_0);
MR_BEGIN_CODE

/* code for predicate 'init'/4 in mode 0 */
MR_define_entry(mercury__bmio__init_4_0);
	{
	MR_String	FileName;
	MR_Integer	NumBytes;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__init_4_0
	FileName = (MR_String) MR_r1;
	NumBytes = MR_r2;
	IO0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("init");
{
#line 87 "bmio.m"


 printf("starting bmio__init
");

	assert(NumBytes > 0);
	bmio__buf_size = NumBytes;

 assert((
	bmio__plain_buf = (char *)malloc(NumBytes * sizeof(char))
		) != NULL);
	bmio__plain_buf_eof = bmio__plain_buf + NumBytes;

 assert((
	bmio__fp = fopen(FileName, "rb")
		) != NULL);
 assert((
	fread(bmio__plain_buf, sizeof(char), NumBytes, bmio__fp)
		) == NumBytes);
	fclose(bmio__fp);

 assert((
	bmio__zipped_buf = (char *)malloc(NumBytes * sizeof(char))
		) != NULL);
	bmio__zipped_buf_eof = bmio__zipped_buf + NumBytes;

 printf("finished bmio__init
");

	IO = IO0;
;}
#line 365 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("init");
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'use_compression_io'/2 in mode 0 */
MR_define_entry(mercury__bmio__use_compression_io_2_0);
	{
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__use_compression_io_2_0
	IO0 = MR_r1;
	MR_OBTAIN_GLOBAL_LOCK("use_compression_io");
{
#line 122 "bmio.m"


	bmio__rd_buf = bmio__plain_buf;
	bmio__rd_ptr = bmio__plain_buf;
	bmio__rd_eof = bmio__plain_buf_eof;

	bmio__wr_buf = bmio__zipped_buf;
	bmio__wr_ptr = bmio__zipped_buf;
	bmio__wr_eof = bmio__zipped_buf_eof;

	IO0 = IO;
;}
#line 394 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("use_compression_io");
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'use_decompression_io'/2 in mode 0 */
MR_define_entry(mercury__bmio__use_decompression_io_2_0);
	{
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__use_decompression_io_2_0
	IO0 = MR_r1;
	MR_OBTAIN_GLOBAL_LOCK("use_decompression_io");
{
#line 140 "bmio.m"


	bmio__rd_buf = bmio__zipped_buf;
	bmio__rd_ptr = bmio__zipped_buf;
	bmio__rd_eof = bmio__zipped_buf_eof;

	bmio__wr_buf = bmio__plain_buf;
	bmio__wr_ptr = bmio__plain_buf;
	bmio__wr_eof = bmio__plain_buf_eof;

	IO0 = IO;
;}
#line 423 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("use_decompression_io");
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'read_byte'/3 in mode 0 */
MR_define_entry(mercury__bmio__read_byte_3_0);
	{
	MR_Integer	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__read_byte_3_0
	IO0 = MR_r1;
	MR_OBTAIN_GLOBAL_LOCK("rd");
{
#line 190 "bmio.m"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;
;}
#line 453 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("rd");
	MR_r3 = Byte;
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r3 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__bmio__read_byte_3_0_i2);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
MR_define_label(mercury__bmio__read_byte_3_0_i2);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__bmio__read_byte_3_0, "io:result/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r3;
	MR_proceed();
/* code for predicate 'write_byte'/3 in mode 0 */
MR_define_entry(mercury__bmio__write_byte_3_0);
	{
	MR_Word	TypeInfo_for_Byte;
	MR_Word	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__write_byte_3_0
	TypeInfo_for_Byte = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	Byte = MR_r1;
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("wr");
{
#line 210 "bmio.m"


 /* if(bmio__wr_buf > bmio__wr_ptr || bmio__wr_ptr >= bmio__wr_eof) {
  fprintf(stderr, "bmio__wr_buf = %p
", bmio__wr_buf);
  fprintf(stderr, "bmio__wr_ptr = %p
", bmio__wr_ptr);
  fprintf(stderr, "bmio__wr_eof = %p
", bmio__wr_eof);
 } */

 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

	*bmio__wr_ptr++ = Byte;

	IO0 = IO;
;}
#line 501 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("wr");
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'mark_decompression_eof'/2 in mode 0 */
MR_define_entry(mercury__bmio__mark_decompression_eof_2_0);
	{
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__mark_decompression_eof_2_0
	IO0 = MR_r1;
	MR_OBTAIN_GLOBAL_LOCK("mark_decompression_eof");
{
#line 171 "bmio.m"


	bmio__zipped_buf_eof = bmio__wr_ptr;

	IO0 = IO;
;}
#line 524 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("mark_decompression_eof");
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'write_byte_checked'/3 in mode 0 */
MR_define_entry(mercury__bmio__write_byte_checked_3_0);
	{
	MR_Word	TypeInfo_for_Byte;
	MR_Word	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__write_byte_checked_3_0
	TypeInfo_for_Byte = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	Byte = MR_r1;
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("chk_wr");
{
#line 233 "bmio.m"


 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

 assert((
	*bmio__wr_ptr++
		) == Byte);

	IO0 = IO;
;}
#line 556 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("chk_wr");
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'report_stats'/2 in mode 0 */
MR_define_entry(mercury__bmio__report_stats_2_0);
	{
	MR_Integer	R;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__report_stats_2_0
	IO0 = MR_r1;
	MR_OBTAIN_GLOBAL_LOCK("rd_bytes");
{
#line 259 "bmio.m"


    R = bmio__rd_ptr - bmio__rd_buf;
    IO0 = IO;
;}
#line 579 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("rd_bytes");
	MR_r4 = R;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Integer	W;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__report_stats_2_0
	IO0 = MR_r5;
	MR_OBTAIN_GLOBAL_LOCK("wr_bytes");
{
#line 270 "bmio.m"


    W = bmio__wr_ptr - bmio__wr_buf;
    IO0 = IO;
;}
#line 600 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("wr_bytes");
	MR_r5 = W;
	MR_r6 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	Stream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__report_stats_2_0
	IO0 = MR_r6;
{
#line 440 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) &mercury_stderr;
	update_io(IO0, IO);
;}
#line 619 "bmio.c"
	MR_r1 = Stream;
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(3, "bmio:report_stats/2");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 1, mercury__bmio__report_stats_2_0, "string:poly_type/0");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = MR_r4;
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(1), (MR_Integer) 2, mercury__bmio__report_stats_2_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r4, (MR_Integer) 0) = MR_r6;
	MR_field(MR_mktag(1), MR_r4, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_bmio__common_1);
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(1), (MR_Integer) 2, mercury__bmio__report_stats_2_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r2, (MR_Integer) 0) = (MR_Word) MR_mkword(MR_mktag(2), (MR_Word *) &mercury_data_bmio__common_2);
	MR_field(MR_mktag(1), MR_r2, (MR_Integer) 1) = MR_r4;
	MR_stackvar(1) = MR_r5;
	MR_stackvar(2) = MR_r1;
	MR_call_localret(MR_ENTRY(mercury__io__write_many_4_0),
		mercury__bmio__report_stats_2_0_i2,
		MR_ENTRY(mercury__bmio__report_stats_2_0));
MR_define_label(mercury__bmio__report_stats_2_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__bmio__report_stats_2_0));
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(1), (MR_Integer) 1, mercury__bmio__report_stats_2_0, "string:poly_type/0");
	MR_field(MR_mktag(1), MR_r4, (MR_Integer) 0) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__bmio__report_stats_2_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_bmio__common_1);
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(1), (MR_Integer) 2, mercury__bmio__report_stats_2_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r2, (MR_Integer) 0) = (MR_Word) MR_mkword(MR_mktag(2), (MR_Word *) &mercury_data_bmio__common_3);
	MR_field(MR_mktag(1), MR_r2, (MR_Integer) 1) = MR_r5;
	MR_r3 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury__io__write_many_4_0),
		MR_ENTRY(mercury__bmio__report_stats_2_0));
/* code for predicate 'rd'/3 in mode 0 */
MR_define_entry(mercury__bmio__rd_3_0);
	{
	MR_Integer	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__rd_3_0
	IO0 = MR_r1;
	MR_OBTAIN_GLOBAL_LOCK("rd");
{
#line 190 "bmio.m"


 /* assert(bmio__rd_buf <= bmio__rd_ptr); */
 /* assert(bmio__rd_ptr <= bmio__rd_eof); */

	if(bmio__rd_ptr < bmio__rd_eof)
		Byte = (unsigned char)(*bmio__rd_ptr++);
	else
		Byte = -1;

	IO0 = IO;
;}
#line 679 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("rd");
	MR_r1 = Byte;
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'wr'/3 in mode 0 */
MR_define_entry(mercury__bmio__wr_3_0);
	{
	MR_Word	TypeInfo_for_Byte;
	MR_Word	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__wr_3_0
	TypeInfo_for_Byte = MR_r1;
	Byte = MR_r2;
	IO0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("wr");
{
#line 210 "bmio.m"


 /* if(bmio__wr_buf > bmio__wr_ptr || bmio__wr_ptr >= bmio__wr_eof) {
  fprintf(stderr, "bmio__wr_buf = %p
", bmio__wr_buf);
  fprintf(stderr, "bmio__wr_ptr = %p
", bmio__wr_ptr);
  fprintf(stderr, "bmio__wr_eof = %p
", bmio__wr_eof);
 } */

 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

	*bmio__wr_ptr++ = Byte;

	IO0 = IO;
;}
#line 719 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("wr");
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'chk_wr'/3 in mode 0 */
MR_define_entry(mercury__bmio__chk_wr_3_0);
	{
	MR_Word	TypeInfo_for_Byte;
	MR_Word	Byte;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__chk_wr_3_0
	TypeInfo_for_Byte = MR_r1;
	Byte = MR_r2;
	IO0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("chk_wr");
{
#line 233 "bmio.m"


 /* assert(bmio__wr_buf <= bmio__wr_ptr); */
 /* assert(bmio__wr_ptr <  bmio__wr_eof); */

 assert((
	*bmio__wr_ptr++
		) == Byte);

	IO0 = IO;
;}
#line 751 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("chk_wr");
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'rd_bytes'/3 in mode 0 */
MR_define_entry(mercury__bmio__rd_bytes_3_0);
	{
	MR_Integer	R;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__rd_bytes_3_0
	IO0 = MR_r1;
	MR_OBTAIN_GLOBAL_LOCK("rd_bytes");
{
#line 259 "bmio.m"


    R = bmio__rd_ptr - bmio__rd_buf;
    IO0 = IO;
;}
#line 774 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("rd_bytes");
	MR_r1 = R;
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'wr_bytes'/3 in mode 0 */
MR_define_entry(mercury__bmio__wr_bytes_3_0);
	{
	MR_Integer	W;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__bmio__wr_bytes_3_0
	IO0 = MR_r1;
	MR_OBTAIN_GLOBAL_LOCK("wr_bytes");
{
#line 270 "bmio.m"


    W = bmio__wr_ptr - bmio__wr_buf;
    IO0 = IO;
;}
#line 798 "bmio.c"
	MR_RELEASE_GLOBAL_LOCK("wr_bytes");
	MR_r1 = W;
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___bmio__state_0_0);
	MR_tailcall(MR_ENTRY(mercury____Unify___io__state_0_0),
		MR_ENTRY(mercury____Unify___bmio__state_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___bmio__state_0_0);
	MR_tailcall(MR_ENTRY(mercury____Compare___io__state_0_0),
		MR_ENTRY(mercury____Compare___bmio__state_0_0));
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__bmio_maybe_bunch_0(void)
{
	bmio_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__bmio__init(void);
void mercury__bmio__init_type_tables(void);
void mercury__bmio__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__bmio__write_out_proc_statics(FILE *fp);
#endif

void mercury__bmio__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__bmio_maybe_bunch_0();
#endif

	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_bmio__type_ctor_info_state_0,
		bmio__state_0_0);
	mercury__bmio__init_debugger();
}

void mercury__bmio__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
	MR_register_type_ctor_info(
		&mercury_data_bmio__type_ctor_info_state_0);
}


void mercury__bmio__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__bmio__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
