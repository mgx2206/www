/*
** Automatically generated from `nuc5.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module nuc5. */
/* :- interface. */

#ifndef MR_HEADER_GUARD_nuc5
#define MR_HEADER_GUARD_nuc5

#ifdef __cplusplus
extern "C" {
#endif

#include "mercury.h"





extern const MR_TypeCtorInfo_Struct nuc5__nuc5__type_ctor_info_variable_0;
extern const MR_TypeCtorInfo_Struct nuc5__nuc5__type_ctor_info_tfo_0;
extern const MR_TypeCtorInfo_Struct nuc5__nuc5__type_ctor_info_pt_0;
extern const MR_TypeCtorInfo_Struct nuc5__nuc5__type_ctor_info_partial_inst_0;
extern const MR_TypeCtorInfo_Struct nuc5__nuc5__type_ctor_info_nuc_specific_0;
extern const MR_TypeCtorInfo_Struct nuc5__nuc5__type_ctor_info_nuc_0;
extern const MR_TypeCtorInfo_Struct nuc5__nuc5__type_ctor_info_constraint_0;
extern const MR_TypeCtorInfo_Struct nuc5__nuc5__type_ctor_info_closure_0;
extern const MR_TypeCtorInfo_Struct nuc5__nuc5__type_ctor_info_atom_0;
extern const MR_TypeCtorInfo_Struct nuc5__nuc5__type_ctor_info_acgt_0;
#line 25 "nuc5.m"
void MR_CALL main_2_p_0(void);

void mercury__nuc5__init(void);
void mercury__nuc5__init_type_tables(void);
void mercury__nuc5__init_debugger(void);

#ifdef __cplusplus
}
#endif

#endif /* MR_HEADER_GUARD_nuc5 */

/* :- end_interface nuc5. */
