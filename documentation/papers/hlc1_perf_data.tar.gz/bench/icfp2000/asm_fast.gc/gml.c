/*
** Automatically generated from `gml.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__gml__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "gml.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "gml.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#include <string.h>
#include <stdio.h>

#include "mercury_string.h"	/* for MR_allocate_aligned_string*() etc. */
#include "mercury_tags.h"	/* for MR_list_cons*() */

#line 41 "gml.c"
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#ifdef USE_GCC_GLOBAL_REGISTERS
	/*
	** GNU C version egcs-1.1.2 crashes with `fixed or forbidden
	** register spilled' in grade asm_fast.gc.tr.debug
	** if we write this inline.
	*/
	static void MR_set_char(MR_String str, MR_Integer ind, MR_Char ch)
	{
		str[ind] = ch;
	}
#else
	#define MR_set_char(str, ind, ch) \
		((str)[ind] = (ch))
#endif

#line 59 "gml.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_DETERMINISM_GUARD
#define ML_DETERMINISM_GUARD
	/*
	** The enumeration constants in this enum must be in the same
	** order as the functors in the Mercury type `determinism'
	** defined above.
	*/
	typedef enum {
		ML_DET,
		ML_SEMIDET,
		ML_CC_MULTI,
		ML_CC_NONDET,
		ML_MULTI,
		ML_NONDET,
		ML_ERRONEOUS,
		ML_FAILURE
	} ML_Determinism;
#endif

#line 82 "gml.c"
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* protect against multiple inclusion */
#ifndef MR_HLC_EXCEPTION_GUARD
#define MR_HLC_EXCEPTION_GUARD

#ifdef MR_HIGHLEVEL_CODE

  #ifdef MR_USE_GCC_NESTED_FUNCTIONS
  	#define MR_CONT_PARAMS		MR_NestedCont cont
  	#define MR_CONT_PARAM_TYPES	MR_NestedCont
  	#define MR_CONT_ARGS		cont
  #else
  	#define MR_CONT_PARAMS		MR_Cont cont, void *cont_env
  	#define MR_CONT_PARAM_TYPES	MR_Cont, void *
  	#define MR_CONT_ARGS		cont, cont_env
  #endif

	/* det */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_0(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* semidet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_1(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_2(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_nondet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_3(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_4(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

	/* nondet */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_5(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

  #ifndef MR_AVOID_MACROS

	/* det ==> model_det */
	#define mercury__exception__builtin_catch_3_p_0 		mercury__exception__builtin_catch_model_det

	/* semidet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_1 		mercury__exception__builtin_catch_model_semi

	/* cc_multi ==> model_det */
	#define mercury__exception__builtin_catch_3_p_2 		mercury__exception__builtin_catch_model_det

	/* cc_nondet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_3 		mercury__exception__builtin_catch_model_semi

	/* multi ==> model_non */
	#define mercury__exception__builtin_catch_3_p_4 		mercury__exception__builtin_catch_model_non

	/* nondet ==> model_non */
	#define mercury__exception__builtin_catch_3_p_5 		mercury__exception__builtin_catch_model_non

  #endif /* !MR_AVOID_MACROS */

	void MR_CALL mercury__exception__builtin_throw_1_p_0(MR_Univ exception);

	void MR_CALL mercury__exception__builtin_catch_model_det(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	bool MR_CALL mercury__exception__builtin_catch_model_semi(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	void MR_CALL mercury__exception__builtin_catch_model_non(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

#endif /* MR_HIGHLEVEL_CODE */

#endif /* MR_HLC_EXCEPTION_GUARD */

#line 172 "gml.c"
#line 147 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

#ifndef MR_HIGHLEVEL_CODE
	#include <assert.h>
	#include <stdio.h>
	#include "mercury_deep_copy.h"
	#include "mercury_trace_base.h"
	#include "mercury_stack_trace.h"
	#include "mercury_layout_util.h"
	#include "mercury_deep_profiling_hand.h"

	MR_DECLARE_TYPE_CTOR_INFO_STRUCT( 			mercury_data_std_util__type_ctor_info_univ_0);
#endif

#line 187 "gml.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#include <limits.h>
#line 190 "gml.c"
#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	extern MR_Word		ML_io_stream_names;
	extern MR_Word		ML_io_user_globals;
	#if 0
	  extern MR_Word	ML_io_ops_table;
	#endif

#line 199 "gml.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
#ifdef HAVE_SYS_STAT_H
	#include <sys/stat.h>
#endif

#line 209 "gml.c"
#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include "mercury_init.h"
#include "mercury_wrapper.h"
#include "mercury_type_info.h"
#include "mercury_library_types.h"
#include "mercury_file.h"
#include "mercury_heap.h"
#include "mercury_misc.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

#ifdef HAVE_SYS_WAIT
  #include <sys/wait.h>		/* for WIFEXITED, WEXITSTATUS, etc. */
#endif

extern MercuryFile mercury_stdin;
extern MercuryFile mercury_stdout;
extern MercuryFile mercury_stderr;
extern MercuryFile mercury_stdin_binary;
extern MercuryFile mercury_stdout_binary;
extern MercuryFile *mercury_current_text_input;
extern MercuryFile *mercury_current_text_output;
extern MercuryFile *mercury_current_binary_input;
extern MercuryFile *mercury_current_binary_output;

#define initial_io_state()		0	/* some random number */
#define update_io(r_src, r_dest)	((r_dest) = (r_src))
#define final_io_state(r)		((void)0)

void 		mercury_init_io(void);
MercuryFile*	mercury_open(const char *filename, const char *type);
void		mercury_io_error(MercuryFile* mf, const char *format, ...);
void		mercury_output_error(MercuryFile* mf);
void		mercury_print_string(MercuryFile* mf, const char *s);
void		mercury_print_binary_string(MercuryFile* mf, const char *s);
int		mercury_getc(MercuryFile* mf);
void		mercury_close(MercuryFile* mf);
int		ML_fprintf(MercuryFile* mf, const char *format, ...);

#line 255 "gml.c"
#line 106 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <fcntl.h>

	#define	MAX_TEMPNAME_TRIES	(6 * 4)

	extern long ML_io_tempnam_counter;

#line 269 "gml.c"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include <string.h>
#include <errno.h>

/*
** ML_maybe_make_err_msg(was_error, msg, procname, error_msg):
**	if `was_error' is true, then append `msg' and `strerror(errno)'
**	to give `error_msg'; otherwise, set `error_msg' to NULL.
**
** WARNING: this must only be called when the `hp' register is valid.
** That means it must only be called from procedures declared
** `will_not_call_mercury'.
**
** This is defined as a macro rather than a C function
** to avoid worrying about the `hp' register being
** invalidated by the function call.
** It also needs to be a macro because MR_incr_hp_atomic_msg()
** stringizes the procname argument.
*/
#define ML_maybe_make_err_msg(was_error, msg, procname, error_msg)	\
	do {								\
		char *errno_msg;					\
		size_t total_len;					\
		MR_Word tmp;						\
									\
		if (was_error) {					\
			errno_msg = strerror(errno);			\
			total_len = strlen(msg) + strlen(errno_msg);	\
			MR_incr_hp_atomic_msg(tmp,			\
				(total_len + sizeof(MR_Word))		\
					/ sizeof(MR_Word),		\
				procname,				\
				"string:string/0");			\
			(error_msg) = (char *)tmp;			\
			strcpy((error_msg), msg);			\
			strcat((error_msg), errno_msg);			\
		} else {						\
			(error_msg) = NULL;				\
		}							\
	} while(0)


#line 314 "gml.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 317 "gml.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 323 "gml.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 331 "gml.c"


static const struct mercury_data_gml__common_0_struct {
	MR_Integer f1;
	MR_Integer f2;
}  mercury_data_gml__common_0;

static const struct mercury_data_gml__common_1_struct {
	MR_Word * f1;
}  mercury_data_gml__common_1;

static const struct mercury_data_gml__common_2_struct {
	MR_Integer f1;
	MR_Integer f2;
}  mercury_data_gml__common_2;

static const struct mercury_data_gml__common_3_struct {
	MR_Word * f1;
}  mercury_data_gml__common_3;

static const struct mercury_data_gml__common_4_struct {
	MR_String f1;
	MR_Word * f2;
}  mercury_data_gml__common_4;

static const struct mercury_data_gml__common_5_struct {
	MR_String f1;
	MR_Word * f2;
}  mercury_data_gml__common_5;

static const struct mercury_data_gml__common_6_struct {
	MR_String f1;
	MR_Word * f2;
}  mercury_data_gml__common_6;

static const struct mercury_data_gml__common_7_struct {
	MR_Integer f1;
	MR_String f2;
	MR_String f3;
	MR_String f4;
	MR_String f5;
	MR_String f6;
	MR_String f7;
	MR_String f8;
	MR_String f9;
	MR_Integer f10;
	MR_String f11;
	MR_Integer f12;
	MR_String f13;
	MR_Integer f14;
	MR_Integer f15;
	MR_Integer f16;
	MR_Integer f17;
	MR_String f18;
	MR_Integer f19;
	MR_Integer f20;
	MR_Integer f21;
	MR_Integer f22;
	MR_Integer f23;
	MR_Integer f24;
	MR_String f25;
	MR_Integer f26;
	MR_Integer f27;
	MR_Integer f28;
	MR_String f29;
	MR_String f30;
	MR_Integer f31;
	MR_Integer f32;
	MR_String f33;
	MR_String f34;
	MR_Integer f35;
	MR_String f36;
	MR_Integer f37;
	MR_String f38;
	MR_String f39;
	MR_Integer f40;
	MR_Integer f41;
	MR_String f42;
	MR_String f43;
	MR_String f44;
	MR_String f45;
	MR_String f46;
	MR_String f47;
	MR_Integer f48;
	MR_Integer f49;
	MR_Integer f50;
	MR_Integer f51;
	MR_String f52;
	MR_Integer f53;
	MR_String f54;
	MR_String f55;
	MR_Integer f56;
	MR_Integer f57;
	MR_String f58;
	MR_Integer f59;
	MR_Integer f60;
	MR_Integer f61;
	MR_String f62;
	MR_Integer f63;
	MR_String f64;
	MR_Integer f65;
	MR_Integer f66;
	MR_Integer f67;
	MR_Integer f68;
	MR_Integer f69;
	MR_Integer f70;
	MR_Integer f71;
	MR_Integer f72;
	MR_Integer f73;
	MR_String f74;
	MR_Integer f75;
	MR_String f76;
	MR_Integer f77;
	MR_Integer f78;
	MR_Integer f79;
	MR_String f80;
	MR_Integer f81;
	MR_String f82;
	MR_Integer f83;
	MR_String f84;
	MR_Integer f85;
	MR_String f86;
	MR_String f87;
	MR_String f88;
	MR_Integer f89;
	MR_String f90;
	MR_String f91;
	MR_String f92;
	MR_Integer f93;
	MR_Integer f94;
	MR_String f95;
	MR_Integer f96;
	MR_Integer f97;
	MR_Integer f98;
	MR_Integer f99;
	MR_Integer f100;
	MR_Integer f101;
	MR_Integer f102;
	MR_Integer f103;
	MR_Integer f104;
	MR_String f105;
	MR_Integer f106;
	MR_String f107;
	MR_String f108;
	MR_Integer f109;
	MR_Integer f110;
	MR_Integer f111;
	MR_String f112;
	MR_Integer f113;
	MR_String f114;
	MR_String f115;
	MR_Integer f116;
	MR_Integer f117;
	MR_Integer f118;
	MR_Integer f119;
	MR_Integer f120;
	MR_Integer f121;
	MR_Integer f122;
	MR_Integer f123;
	MR_Integer f124;
	MR_Integer f125;
	MR_Integer f126;
	MR_String f127;
	MR_Integer f128;
}  mercury_data_gml__common_7;

static const struct mercury_data_gml__common_8_struct {
	MR_Integer f1;
	MR_Integer f2;
	MR_Integer f3;
	MR_Integer f4;
	MR_Integer f5;
	MR_Integer f6;
	MR_Integer f7;
	MR_Integer f8;
	MR_Integer f9;
	MR_Integer f10;
	MR_Integer f11;
	MR_Integer f12;
	MR_Integer f13;
	MR_Integer f14;
	MR_Integer f15;
	MR_Integer f16;
	MR_Integer f17;
	MR_Integer f18;
	MR_Integer f19;
	MR_Integer f20;
	MR_Integer f21;
	MR_Integer f22;
	MR_Integer f23;
	MR_Integer f24;
	MR_Integer f25;
	MR_Integer f26;
	MR_Integer f27;
	MR_Integer f28;
	MR_Integer f29;
	MR_Integer f30;
	MR_Integer f31;
	MR_Integer f32;
	MR_Integer f33;
	MR_Integer f34;
	MR_Integer f35;
	MR_Integer f36;
	MR_Integer f37;
	MR_Integer f38;
	MR_Integer f39;
	MR_Integer f40;
	MR_Integer f41;
	MR_Integer f42;
	MR_Integer f43;
	MR_Integer f44;
	MR_Integer f45;
	MR_Integer f46;
	MR_Integer f47;
	MR_Integer f48;
	MR_Integer f49;
	MR_Integer f50;
	MR_Integer f51;
	MR_Integer f52;
	MR_Integer f53;
	MR_Integer f54;
	MR_Integer f55;
	MR_Integer f56;
	MR_Integer f57;
	MR_Integer f58;
	MR_Integer f59;
	MR_Integer f60;
	MR_Integer f61;
	MR_Integer f62;
	MR_Integer f63;
	MR_Integer f64;
	MR_Integer f65;
	MR_Integer f66;
	MR_Integer f67;
	MR_Integer f68;
	MR_Integer f69;
	MR_Integer f70;
	MR_Integer f71;
	MR_Integer f72;
	MR_Integer f73;
	MR_Integer f74;
	MR_Integer f75;
	MR_Integer f76;
	MR_Integer f77;
	MR_Integer f78;
	MR_Integer f79;
	MR_Integer f80;
	MR_Integer f81;
	MR_Integer f82;
	MR_Integer f83;
	MR_Integer f84;
	MR_Integer f85;
	MR_Integer f86;
	MR_Integer f87;
	MR_Integer f88;
	MR_Integer f89;
	MR_Integer f90;
	MR_Integer f91;
	MR_Integer f92;
	MR_Integer f93;
	MR_Integer f94;
	MR_Integer f95;
	MR_Integer f96;
	MR_Integer f97;
	MR_Integer f98;
	MR_Integer f99;
	MR_Integer f100;
	MR_Integer f101;
	MR_Integer f102;
	MR_Integer f103;
	MR_Integer f104;
	MR_Integer f105;
	MR_Integer f106;
	MR_Integer f107;
	MR_Integer f108;
	MR_Integer f109;
	MR_Integer f110;
	MR_Integer f111;
	MR_Integer f112;
	MR_Integer f113;
	MR_Integer f114;
	MR_Integer f115;
	MR_Integer f116;
	MR_Integer f117;
	MR_Integer f118;
	MR_Integer f119;
	MR_Integer f120;
	MR_Integer f121;
	MR_Integer f122;
	MR_Integer f123;
	MR_Integer f124;
	MR_Integer f125;
	MR_Integer f126;
	MR_Integer f127;
	MR_Integer f128;
}  mercury_data_gml__common_8;

static const struct mercury_data_gml__common_9_struct {
	MR_String f1;
	MR_Word * f2;
}  mercury_data_gml__common_9;

static const struct mercury_data_gml__common_10_struct {
	MR_String f1;
	MR_Word * f2;
}  mercury_data_gml__common_10;

static const struct mercury_data_gml__common_11_struct {
	MR_String f1;
	MR_Word * f2;
}  mercury_data_gml__common_11;

static const struct mercury_data_gml__common_12_struct {
	MR_String f1;
	MR_Word * f2;
}  mercury_data_gml__common_12;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_token_list_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_token_group_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_token_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_stop_at_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_parse_error_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_operator_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_number_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_lexer_error_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_gml_program_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_extra_operator_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_basic_token_0;
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_18_gml__token_group_0;
extern const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_token_group_0[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_group_0_0;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_token_group_0_0[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_group_0_1;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_token_group_0_1[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_group_0_2;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_token_group_0_2[];
extern const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_token_group_0[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_group_0_0[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_group_0_1[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_group_0_2[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_token_0[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_0;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_0[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_1;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_1[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_2;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_2[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_3;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_3[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_4;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_4[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_5;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_5[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_6;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_6[];
extern const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_token_0[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_0_0[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_0_1[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_0_2[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_0_3[];
extern const MR_EnumFunctorDesc * mercury_data_gml__enum_name_ordered_stop_at_0[];
extern const MR_EnumFunctorDesc * mercury_data_gml__enum_value_ordered_stop_at_0[];
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_stop_at_0_0;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_stop_at_0_1;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_stop_at_0_2;
static const MR_NotagFunctorDesc mercury_data_gml__notag_functor_desc_parse_error_0;
extern const MR_EnumFunctorDesc * mercury_data_gml__enum_name_ordered_operator_0[];
extern const MR_EnumFunctorDesc * mercury_data_gml__enum_value_ordered_operator_0[];
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_0;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_1;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_2;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_3;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_4;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_5;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_6;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_7;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_8;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_9;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_10;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_11;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_12;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_13;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_14;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_15;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_16;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_17;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_18;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_19;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_20;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_21;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_22;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_23;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_24;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_25;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_26;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_27;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_28;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_29;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_30;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_31;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_32;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_33;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_34;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_35;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_36;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_37;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_38;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_39;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_40;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_41;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_42;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_43;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_44;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_45;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_46;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_47;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_48;
static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_49;
extern const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_number_0[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_number_0_0;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_number_0_0[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_number_0_1;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_number_0_1[];
extern const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_number_0[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_number_0_0[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_number_0_1[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_lexer_error_0[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_lexer_error_0_0;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_lexer_error_0_0[];
extern const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_lexer_error_0[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_lexer_error_0_0[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_extra_operator_0[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_0;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_0[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_1;
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_2;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_2[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_3;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_3[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_4;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_4[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_5;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_5[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_6;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_6[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_7;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_7[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_8;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_8[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_9;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_9[];
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_13_eval__value_0;
#ifndef MR_FO_PseudoTypeInfo_Struct2_GUARD
#define MR_FO_PseudoTypeInfo_Struct2_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct2, 2);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct2 mercury_data_tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0;
#ifndef MR_HO_PseudoTypeInfo_Struct6_GUARD
#define MR_HO_PseudoTypeInfo_Struct6_GUARD
MR_HIGHER_ORDER_PSEUDOTYPEINFO_STRUCT(MR_HO_PseudoTypeInfo_Struct6, 6);
#endif
static const struct MR_HO_PseudoTypeInfo_Struct6 mercury_data___ho_type_info_pred_6__type_18_tree234__tree234_2__type0_10___string_0__type0_13_eval__value_0__type_12_list__list_1__type0_13_eval__value_0__type_18_tree234__tree234_2__type0_10___string_0__type0_13_eval__value_0__type_12_list__list_1__type0_13_eval__value_0__type0_11_io__state_0__type0_11_io__state_0;
extern const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_extra_operator_0[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_extra_operator_0_0[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_extra_operator_0_1[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_extra_operator_0_2[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_extra_operator_0_3[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_basic_token_0[];
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_basic_token_0_0;
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_basic_token_0_1;
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_basic_token_0_2;
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_basic_token_0_3;
static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_basic_token_0_4;
extern const MR_PseudoTypeInfo mercury_data_gml__field_types_basic_token_0_4[];
extern const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_basic_token_0[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_basic_token_0_0[];
extern const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_basic_token_0_1[];
MR_declare_static(mercury__gml__builtin_compare_pred__ua0_3_0);
MR_declare_label(mercury__gml__builtin_compare_pred__ua0_3_0_i4);
MR_declare_label(mercury__gml__builtin_compare_pred__ua0_3_0_i3);
MR_declare_static(mercury__gml__builtin_unify_pred__ua0_2_0);
MR_declare_label(mercury__gml__builtin_unify_pred__ua0_2_0_i4);
MR_declare_label(mercury__gml__builtin_unify_pred__ua0_2_0_i3);
MR_declare_label(mercury__gml__builtin_unify_pred__ua0_2_0_i9);
MR_define_extern_entry(mercury__gml__tokenize_3_0);
MR_declare_label(mercury__gml__tokenize_3_0_i2);
MR_declare_label(mercury__gml__tokenize_3_0_i3);
MR_define_extern_entry(mercury__gml__parse_2_0);
MR_declare_label(mercury__gml__parse_2_0_i2);
MR_declare_label(mercury__gml__parse_2_0_i3);
MR_declare_label(mercury__gml__parse_2_0_i5);
MR_define_extern_entry(mercury__gml__tokenize_2_4_0);
MR_declare_label(mercury__gml__tokenize_2_4_0_i2);
MR_declare_label(mercury__gml__tokenize_2_4_0_i8);
MR_declare_label(mercury__gml__tokenize_2_4_0_i9);
MR_declare_label(mercury__gml__tokenize_2_4_0_i5);
MR_declare_label(mercury__gml__tokenize_2_4_0_i6);
MR_declare_static(mercury__gml__skip_whitespace_3_0);
MR_declare_label(mercury__gml__skip_whitespace_3_0_i2);
MR_declare_label(mercury__gml__skip_whitespace_3_0_i4);
MR_declare_label(mercury__gml__skip_whitespace_3_0_i7);
MR_declare_label(mercury__gml__skip_whitespace_3_0_i5);
MR_declare_label(mercury__gml__skip_whitespace_3_0_i11);
MR_declare_label(mercury__gml__skip_whitespace_3_0_i12);
MR_declare_label(mercury__gml__skip_whitespace_3_0_i13);
MR_declare_label(mercury__gml__skip_whitespace_3_0_i14);
MR_declare_label(mercury__gml__skip_whitespace_3_0_i15);
MR_declare_label(mercury__gml__skip_whitespace_3_0_i3);
MR_declare_static(mercury__gml__skip_to_end_of_line_2_0);
MR_declare_label(mercury__gml__skip_to_end_of_line_2_0_i2);
MR_declare_label(mercury__gml__skip_to_end_of_line_2_0_i4);
MR_declare_label(mercury__gml__skip_to_end_of_line_2_0_i5);
MR_declare_label(mercury__gml__skip_to_end_of_line_2_0_i7);
MR_declare_label(mercury__gml__skip_to_end_of_line_2_0_i9);
MR_declare_label(mercury__gml__skip_to_end_of_line_2_0_i11);
MR_declare_static(mercury__gml__get_token_4_0);
MR_declare_label(mercury__gml__get_token_4_0_i4);
MR_declare_label(mercury__gml__get_token_4_0_i5);
MR_declare_label(mercury__gml__get_token_4_0_i6);
MR_declare_label(mercury__gml__get_token_4_0_i2);
MR_declare_label(mercury__gml__get_token_4_0_i10);
MR_declare_label(mercury__gml__get_token_4_0_i8);
MR_declare_label(mercury__gml__get_token_4_0_i13);
MR_declare_label(mercury__gml__get_token_4_0_i15);
MR_declare_label(mercury__gml__get_token_4_0_i16);
MR_declare_label(mercury__gml__get_token_4_0_i18);
MR_declare_label(mercury__gml__get_token_4_0_i22);
MR_declare_label(mercury__gml__get_token_4_0_i20);
MR_declare_label(mercury__gml__get_token_4_0_i11);
MR_declare_label(mercury__gml__get_token_4_0_i29);
MR_declare_label(mercury__gml__get_token_4_0_i35);
MR_declare_label(mercury__gml__get_token_4_0_i33);
MR_declare_label(mercury__gml__get_token_4_0_i37);
MR_declare_label(mercury__gml__get_token_4_0_i30);
MR_declare_label(mercury__gml__get_token_4_0_i27);
MR_declare_label(mercury__gml__get_token_4_0_i41);
MR_declare_label(mercury__gml__get_token_4_0_i46);
MR_declare_label(mercury__gml__get_token_4_0_i48);
MR_declare_label(mercury__gml__get_token_4_0_i44);
MR_declare_label(mercury__gml__get_token_4_0_i49);
MR_declare_static(mercury__gml__is_operator_2_0);
MR_declare_label(mercury__gml__is_operator_2_0_i3);
MR_declare_label(mercury__gml__is_operator_2_0_i57);
MR_declare_label(mercury__gml__is_operator_2_0_i5);
MR_declare_label(mercury__gml__is_operator_2_0_i6);
MR_declare_label(mercury__gml__is_operator_2_0_i7);
MR_declare_label(mercury__gml__is_operator_2_0_i8);
MR_declare_label(mercury__gml__is_operator_2_0_i9);
MR_declare_label(mercury__gml__is_operator_2_0_i10);
MR_declare_label(mercury__gml__is_operator_2_0_i11);
MR_declare_label(mercury__gml__is_operator_2_0_i12);
MR_declare_label(mercury__gml__is_operator_2_0_i13);
MR_declare_label(mercury__gml__is_operator_2_0_i14);
MR_declare_label(mercury__gml__is_operator_2_0_i15);
MR_declare_label(mercury__gml__is_operator_2_0_i16);
MR_declare_label(mercury__gml__is_operator_2_0_i17);
MR_declare_label(mercury__gml__is_operator_2_0_i18);
MR_declare_label(mercury__gml__is_operator_2_0_i19);
MR_declare_label(mercury__gml__is_operator_2_0_i20);
MR_declare_label(mercury__gml__is_operator_2_0_i21);
MR_declare_label(mercury__gml__is_operator_2_0_i22);
MR_declare_label(mercury__gml__is_operator_2_0_i23);
MR_declare_label(mercury__gml__is_operator_2_0_i24);
MR_declare_label(mercury__gml__is_operator_2_0_i25);
MR_declare_label(mercury__gml__is_operator_2_0_i26);
MR_declare_label(mercury__gml__is_operator_2_0_i27);
MR_declare_label(mercury__gml__is_operator_2_0_i28);
MR_declare_label(mercury__gml__is_operator_2_0_i29);
MR_declare_label(mercury__gml__is_operator_2_0_i30);
MR_declare_label(mercury__gml__is_operator_2_0_i31);
MR_declare_label(mercury__gml__is_operator_2_0_i32);
MR_declare_label(mercury__gml__is_operator_2_0_i33);
MR_declare_label(mercury__gml__is_operator_2_0_i34);
MR_declare_label(mercury__gml__is_operator_2_0_i35);
MR_declare_label(mercury__gml__is_operator_2_0_i36);
MR_declare_label(mercury__gml__is_operator_2_0_i37);
MR_declare_label(mercury__gml__is_operator_2_0_i38);
MR_declare_label(mercury__gml__is_operator_2_0_i39);
MR_declare_label(mercury__gml__is_operator_2_0_i40);
MR_declare_label(mercury__gml__is_operator_2_0_i41);
MR_declare_label(mercury__gml__is_operator_2_0_i42);
MR_declare_label(mercury__gml__is_operator_2_0_i43);
MR_declare_label(mercury__gml__is_operator_2_0_i44);
MR_declare_label(mercury__gml__is_operator_2_0_i45);
MR_declare_label(mercury__gml__is_operator_2_0_i46);
MR_declare_label(mercury__gml__is_operator_2_0_i47);
MR_declare_label(mercury__gml__is_operator_2_0_i48);
MR_declare_label(mercury__gml__is_operator_2_0_i49);
MR_declare_label(mercury__gml__is_operator_2_0_i50);
MR_declare_label(mercury__gml__is_operator_2_0_i51);
MR_declare_label(mercury__gml__is_operator_2_0_i52);
MR_declare_label(mercury__gml__is_operator_2_0_i53);
MR_declare_label(mercury__gml__is_operator_2_0_i54);
MR_declare_label(mercury__gml__is_operator_2_0_i55);
MR_declare_static(mercury__gml__get_identifier_4_0);
MR_declare_label(mercury__gml__get_identifier_4_0_i2);
MR_declare_label(mercury__gml__get_identifier_4_0_i4);
MR_declare_label(mercury__gml__get_identifier_4_0_i10);
MR_declare_label(mercury__gml__get_identifier_4_0_i8);
MR_declare_label(mercury__gml__get_identifier_4_0_i6);
MR_declare_static(mercury__gml__get_string_4_0);
MR_declare_label(mercury__gml__get_string_4_0_i2);
MR_declare_label(mercury__gml__get_string_4_0_i5);
MR_declare_label(mercury__gml__get_string_4_0_i4);
MR_declare_label(mercury__gml__get_string_4_0_i7);
MR_declare_label(mercury__gml__get_string_4_0_i14);
MR_declare_label(mercury__gml__get_string_4_0_i12);
MR_declare_label(mercury__gml__get_string_4_0_i10);
MR_declare_label(mercury__gml__get_string_4_0_i18);
MR_declare_static(mercury__gml__get_number_4_0);
MR_declare_label(mercury__gml__get_number_4_0_i2);
MR_declare_label(mercury__gml__get_number_4_0_i6);
MR_declare_label(mercury__gml__get_number_4_0_i5);
MR_declare_label(mercury__gml__get_number_4_0_i4);
MR_declare_label(mercury__gml__get_number_4_0_i12);
MR_declare_label(mercury__gml__get_number_4_0_i10);
MR_declare_label(mercury__gml__get_number_4_0_i15);
MR_declare_label(mercury__gml__get_number_4_0_i20);
MR_declare_label(mercury__gml__get_number_4_0_i18);
MR_declare_label(mercury__gml__get_number_4_0_i24);
MR_declare_label(mercury__gml__get_number_4_0_i23);
MR_declare_label(mercury__gml__get_number_4_0_i26);
MR_declare_static(mercury__gml__get_int_dot_4_0);
MR_declare_label(mercury__gml__get_int_dot_4_0_i2);
MR_declare_label(mercury__gml__get_int_dot_4_0_i6);
MR_declare_label(mercury__gml__get_int_dot_4_0_i5);
MR_declare_label(mercury__gml__get_int_dot_4_0_i8);
MR_declare_label(mercury__gml__get_int_dot_4_0_i4);
MR_declare_label(mercury__gml__get_int_dot_4_0_i12);
MR_declare_label(mercury__gml__get_int_dot_4_0_i10);
MR_declare_static(mercury__gml__get_float_decimals_4_0);
MR_declare_label(mercury__gml__get_float_decimals_4_0_i2);
MR_declare_label(mercury__gml__get_float_decimals_4_0_i7);
MR_declare_label(mercury__gml__get_float_decimals_4_0_i4);
MR_declare_label(mercury__gml__get_float_decimals_4_0_i13);
MR_declare_label(mercury__gml__get_float_decimals_4_0_i11);
MR_declare_label(mercury__gml__get_float_decimals_4_0_i18);
MR_declare_label(mercury__gml__get_float_decimals_4_0_i16);
MR_declare_label(mercury__gml__get_float_decimals_4_0_i23);
MR_declare_label(mercury__gml__get_float_decimals_4_0_i25);
MR_declare_static(mercury__gml__get_float_exponent_4_0);
MR_declare_label(mercury__gml__get_float_exponent_4_0_i2);
MR_declare_label(mercury__gml__get_float_exponent_4_0_i7);
MR_declare_label(mercury__gml__get_float_exponent_4_0_i4);
MR_declare_label(mercury__gml__get_float_exponent_4_0_i11);
MR_declare_label(mercury__gml__get_float_exponent_4_0_i16);
MR_declare_label(mercury__gml__get_float_exponent_4_0_i14);
MR_declare_label(mercury__gml__get_float_exponent_4_0_i19);
MR_declare_static(mercury__gml__get_float_exponent_2_4_0);
MR_declare_label(mercury__gml__get_float_exponent_2_4_0_i2);
MR_declare_label(mercury__gml__get_float_exponent_2_4_0_i5);
MR_declare_label(mercury__gml__get_float_exponent_2_4_0_i4);
MR_declare_label(mercury__gml__get_float_exponent_2_4_0_i9);
MR_declare_label(mercury__gml__get_float_exponent_2_4_0_i7);
MR_declare_label(mercury__gml__get_float_exponent_2_4_0_i12);
MR_declare_static(mercury__gml__get_float_exponent_3_4_0);
MR_declare_label(mercury__gml__get_float_exponent_3_4_0_i2);
MR_declare_label(mercury__gml__get_float_exponent_3_4_0_i7);
MR_declare_label(mercury__gml__get_float_exponent_3_4_0_i4);
MR_declare_label(mercury__gml__get_float_exponent_3_4_0_i13);
MR_declare_label(mercury__gml__get_float_exponent_3_4_0_i11);
MR_declare_label(mercury__gml__get_float_exponent_3_4_0_i18);
MR_declare_label(mercury__gml__get_float_exponent_3_4_0_i20);
MR_declare_static(mercury__gml__rev_char_list_to_int_5_0);
MR_declare_label(mercury__gml__rev_char_list_to_int_5_0_i4);
MR_declare_label(mercury__gml__rev_char_list_to_int_5_0_i2);
MR_declare_label(mercury__gml__rev_char_list_to_int_5_0_i6);
MR_declare_static(mercury__gml__lexer_read_char_3_0);
MR_declare_label(mercury__gml__lexer_read_char_3_0_i2);
MR_declare_label(mercury__gml__lexer_read_char_3_0_i6);
MR_declare_label(mercury__gml__lexer_read_char_3_0_i8);
MR_declare_static(mercury__gml__parse_2_5_0);
MR_declare_label(mercury__gml__parse_2_5_0_i5);
MR_declare_label(mercury__gml__parse_2_5_0_i6);
MR_declare_label(mercury__gml__parse_2_5_0_i3);
MR_declare_label(mercury__gml__parse_2_5_0_i25);
MR_declare_label(mercury__gml__parse_2_5_0_i21);
MR_declare_label(mercury__gml__parse_2_5_0_i22);
MR_declare_label(mercury__gml__parse_2_5_0_i23);
MR_declare_label(mercury__gml__parse_2_5_0_i16);
MR_declare_label(mercury__gml__parse_2_5_0_i17);
MR_declare_label(mercury__gml__parse_2_5_0_i12);
MR_declare_label(mercury__gml__parse_2_5_0_i13);
MR_declare_label(mercury__gml__parse_2_5_0_i14);
MR_declare_label(mercury__gml__parse_2_5_0_i11);
MR_define_extern_entry(mercury____Unify___gml__basic_token_0_0);
MR_declare_label(mercury____Unify___gml__basic_token_0_0_i9);
MR_declare_label(mercury____Unify___gml__basic_token_0_0_i7);
MR_declare_label(mercury____Unify___gml__basic_token_0_0_i5);
MR_declare_label(mercury____Unify___gml__basic_token_0_0_i4);
MR_declare_label(mercury____Unify___gml__basic_token_0_0_i1);
MR_define_extern_entry(mercury____Index___gml__basic_token_0_0);
MR_declare_label(mercury____Index___gml__basic_token_0_0_i7);
MR_declare_label(mercury____Index___gml__basic_token_0_0_i6);
MR_declare_label(mercury____Index___gml__basic_token_0_0_i5);
MR_declare_label(mercury____Index___gml__basic_token_0_0_i4);
MR_define_extern_entry(mercury____Compare___gml__basic_token_0_0);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i7);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i6);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i5);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i4);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i13);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i12);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i11);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i10);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i14);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i15);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i25);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i23);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i21);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i20);
MR_declare_label(mercury____Compare___gml__basic_token_0_0_i232);
MR_define_extern_entry(mercury____Unify___gml__token_0_0);
MR_declare_label(mercury____Unify___gml__token_0_0_i4);
MR_declare_label(mercury____Unify___gml__token_0_0_i6);
MR_declare_label(mercury____Unify___gml__token_0_0_i8);
MR_declare_label(mercury____Unify___gml__token_0_0_i10);
MR_declare_label(mercury____Unify___gml__token_0_0_i19);
MR_declare_label(mercury____Unify___gml__token_0_0_i13);
MR_declare_label(mercury____Unify___gml__token_0_0_i16);
MR_declare_label(mercury____Unify___gml__token_0_0_i11);
MR_declare_label(mercury____Unify___gml__token_0_0_i1);
MR_define_extern_entry(mercury____Index___gml__token_0_0);
MR_declare_label(mercury____Index___gml__token_0_0_i4);
MR_declare_label(mercury____Index___gml__token_0_0_i5);
MR_declare_label(mercury____Index___gml__token_0_0_i6);
MR_declare_label(mercury____Index___gml__token_0_0_i7);
MR_declare_label(mercury____Index___gml__token_0_0_i10);
MR_declare_label(mercury____Index___gml__token_0_0_i9);
MR_declare_label(mercury____Index___gml__token_0_0_i8);
MR_define_extern_entry(mercury____Compare___gml__token_0_0);
MR_declare_label(mercury____Compare___gml__token_0_0_i2);
MR_declare_label(mercury____Compare___gml__token_0_0_i3);
MR_declare_label(mercury____Compare___gml__token_0_0_i4);
MR_declare_label(mercury____Compare___gml__token_0_0_i54);
MR_declare_label(mercury____Compare___gml__token_0_0_i5);
MR_declare_label(mercury____Compare___gml__token_0_0_i10);
MR_declare_label(mercury____Compare___gml__token_0_0_i12);
MR_declare_label(mercury____Compare___gml__token_0_0_i16);
MR_declare_label(mercury____Compare___gml__token_0_0_i18);
MR_declare_label(mercury____Compare___gml__token_0_0_i23);
MR_declare_label(mercury____Compare___gml__token_0_0_i25);
MR_declare_label(mercury____Compare___gml__token_0_0_i30);
MR_declare_label(mercury____Compare___gml__token_0_0_i40);
MR_declare_label(mercury____Compare___gml__token_0_0_i42);
MR_declare_label(mercury____Compare___gml__token_0_0_i37);
MR_declare_label(mercury____Compare___gml__token_0_0_i31);
MR_declare_label(mercury____Compare___gml__token_0_0_i33);
MR_declare_label(mercury____Compare___gml__token_0_0_i7);
MR_define_extern_entry(mercury____Unify___gml__number_0_0);
MR_declare_label(mercury____Unify___gml__number_0_0_i3);
MR_declare_label(mercury____Unify___gml__number_0_0_i1);
MR_define_extern_entry(mercury____Compare___gml__number_0_0);
MR_declare_label(mercury____Compare___gml__number_0_0_i6);
MR_declare_label(mercury____Compare___gml__number_0_0_i19);
MR_declare_label(mercury____Compare___gml__number_0_0_i3);
MR_declare_label(mercury____Compare___gml__number_0_0_i11);
MR_declare_label(mercury____Compare___gml__number_0_0_i21);
MR_declare_label(mercury____Compare___gml__number_0_0_i12);
MR_declare_label(mercury____Compare___gml__number_0_0_i22);
MR_define_extern_entry(mercury____Unify___gml__operator_0_0);
MR_define_extern_entry(mercury____Compare___gml__operator_0_0);
MR_declare_label(mercury____Compare___gml__operator_0_0_i2);
MR_declare_label(mercury____Compare___gml__operator_0_0_i3);
MR_define_extern_entry(mercury____Unify___gml__extra_operator_0_0);
MR_declare_label(mercury____Unify___gml__extra_operator_0_0_i4);
MR_declare_label(mercury____Unify___gml__extra_operator_0_0_i6);
MR_declare_label(mercury____Unify___gml__extra_operator_0_0_i8);
MR_declare_label(mercury____Unify___gml__extra_operator_0_0_i12);
MR_declare_label(mercury____Unify___gml__extra_operator_0_0_i13);
MR_declare_label(mercury____Unify___gml__extra_operator_0_0_i17);
MR_declare_label(mercury____Unify___gml__extra_operator_0_0_i21);
MR_declare_label(mercury____Unify___gml__extra_operator_0_0_i25);
MR_declare_label(mercury____Unify___gml__extra_operator_0_0_i29);
MR_declare_label(mercury____Unify___gml__extra_operator_0_0_i33);
MR_declare_label(mercury____Unify___gml__extra_operator_0_0_i35);
MR_declare_label(mercury____Unify___gml__extra_operator_0_0_i39);
MR_declare_label(mercury____Unify___gml__extra_operator_0_0_i1);
MR_define_extern_entry(mercury____Index___gml__extra_operator_0_0);
MR_declare_label(mercury____Index___gml__extra_operator_0_0_i4);
MR_declare_label(mercury____Index___gml__extra_operator_0_0_i5);
MR_declare_label(mercury____Index___gml__extra_operator_0_0_i6);
MR_declare_label(mercury____Index___gml__extra_operator_0_0_i7);
MR_declare_label(mercury____Index___gml__extra_operator_0_0_i8);
MR_declare_label(mercury____Index___gml__extra_operator_0_0_i9);
MR_declare_label(mercury____Index___gml__extra_operator_0_0_i10);
MR_declare_label(mercury____Index___gml__extra_operator_0_0_i11);
MR_declare_label(mercury____Index___gml__extra_operator_0_0_i12);
MR_declare_label(mercury____Index___gml__extra_operator_0_0_i13);
MR_declare_label(mercury____Index___gml__extra_operator_0_0_i14);
MR_define_extern_entry(mercury____Compare___gml__extra_operator_0_0);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i2);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i3);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i4);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i53);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i5);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i10);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i12);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i14);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i18);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i21);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i22);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i25);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i28);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i31);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i34);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i37);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i40);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i45);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i7);
MR_declare_label(mercury____Compare___gml__extra_operator_0_0_i51);
MR_define_extern_entry(mercury____Unify___gml__lexer_error_0_0);
MR_declare_label(mercury____Unify___gml__lexer_error_0_0_i1);
MR_define_extern_entry(mercury____Compare___gml__lexer_error_0_0);
MR_declare_label(mercury____Compare___gml__lexer_error_0_0_i4);
MR_declare_label(mercury____Compare___gml__lexer_error_0_0_i23);
MR_declare_label(mercury____Compare___gml__lexer_error_0_0_i3);
MR_declare_label(mercury____Compare___gml__lexer_error_0_0_i14);
MR_define_extern_entry(mercury____Unify___gml__parse_error_0_0);
MR_define_extern_entry(mercury____Compare___gml__parse_error_0_0);
MR_declare_label(mercury____Compare___gml__parse_error_0_0_i2);
MR_declare_label(mercury____Compare___gml__parse_error_0_0_i3);
MR_define_extern_entry(mercury____Unify___gml__gml_program_0_0);
MR_define_extern_entry(mercury____Compare___gml__gml_program_0_0);
MR_define_extern_entry(mercury____Unify___gml__token_list_0_0);
MR_define_extern_entry(mercury____Compare___gml__token_list_0_0);
MR_define_extern_entry(mercury____Unify___gml__token_group_0_0);
MR_declare_label(mercury____Unify___gml__token_group_0_0_i8);
MR_declare_label(mercury____Unify___gml__token_group_0_0_i4);
MR_declare_label(mercury____Unify___gml__token_group_0_0_i1);
MR_define_extern_entry(mercury____Compare___gml__token_group_0_0);
MR_declare_label(mercury____Compare___gml__token_group_0_0_i10);
MR_declare_label(mercury____Compare___gml__token_group_0_0_i4);
MR_declare_label(mercury____Compare___gml__token_group_0_0_i28);
MR_declare_label(mercury____Compare___gml__token_group_0_0_i9);
MR_declare_label(mercury____Compare___gml__token_group_0_0_i7);
MR_define_extern_entry(mercury____Unify___gml__stop_at_0_0);
MR_define_extern_entry(mercury____Compare___gml__stop_at_0_0);
MR_declare_label(mercury____Compare___gml__stop_at_0_0_i2);
MR_declare_label(mercury____Compare___gml__stop_at_0_0_i3);

static const struct mercury_data_gml__common_0_struct mercury_data_gml__common_0 = {
	(MR_Integer) 0,
	(MR_Integer) 1
};

static const struct mercury_data_gml__common_1_struct mercury_data_gml__common_1 = {
	MR_mkword(MR_mktag(3), (MR_Word *) &mercury_data_gml__common_0)
};

static const struct mercury_data_gml__common_2_struct mercury_data_gml__common_2 = {
	(MR_Integer) 0,
	(MR_Integer) 0
};

static const struct mercury_data_gml__common_3_struct mercury_data_gml__common_3 = {
	MR_mkword(MR_mktag(3), (MR_Word *) &mercury_data_gml__common_2)
};

static const struct mercury_data_gml__common_4_struct mercury_data_gml__common_4 = {
	MR_string_const("'", 1),
	MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0))
};

static const struct mercury_data_gml__common_5_struct mercury_data_gml__common_5 = {
	MR_string_const("start of token", 14),
	MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0))
};

static const struct mercury_data_gml__common_6_struct mercury_data_gml__common_6 = {
	MR_string_const("' in ", 5),
	MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_5)
};

static const struct mercury_data_gml__common_7_struct mercury_data_gml__common_7 = {
	(MR_Integer) 0,
	MR_string_const("floor", 5),
	MR_string_const("addf", 4),
	MR_string_const("addi", 4),
	MR_string_const("rotatez", 7),
	MR_string_const("divi", 4),
	MR_string_const("rotatex", 7),
	MR_string_const("rotatey", 7),
	MR_string_const("acos", 4),
	(MR_Integer) 0,
	MR_string_const("cylinder", 8),
	(MR_Integer) 0,
	MR_string_const("intersect", 9),
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("asin", 4),
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("pointlight", 10),
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("cos", 3),
	MR_string_const("scale", 5),
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("sqrt", 4),
	MR_string_const("negi", 4),
	(MR_Integer) 0,
	MR_string_const("cone", 4),
	(MR_Integer) 0,
	MR_string_const("lessi", 5),
	MR_string_const("subf", 4),
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("subi", 4),
	MR_string_const("lessf", 5),
	MR_string_const("modi", 4),
	MR_string_const("render", 6),
	MR_string_const("if", 2),
	MR_string_const("negf", 4),
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("plane", 5),
	(MR_Integer) 0,
	MR_string_const("cube", 4),
	MR_string_const("mulf", 4),
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("muli", 4),
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("difference", 10),
	(MR_Integer) 0,
	MR_string_const("sphere", 6),
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("point", 5),
	(MR_Integer) 0,
	MR_string_const("uscale", 6),
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("spotlight", 9),
	(MR_Integer) 0,
	MR_string_const("eqf", 3),
	(MR_Integer) 0,
	MR_string_const("clampf", 6),
	(MR_Integer) 0,
	MR_string_const("get", 3),
	MR_string_const("union", 5),
	MR_string_const("sin", 3),
	(MR_Integer) 0,
	MR_string_const("divf", 4),
	MR_string_const("length", 6),
	MR_string_const("light", 5),
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("eqi", 3),
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("getz", 4),
	(MR_Integer) 0,
	MR_string_const("getx", 4),
	MR_string_const("gety", 4),
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("translate", 9),
	(MR_Integer) 0,
	MR_string_const("apply", 5),
	MR_string_const("frac", 4),
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	(MR_Integer) 0,
	MR_string_const("real", 4),
	(MR_Integer) 0
};

static const struct mercury_data_gml__common_8_struct mercury_data_gml__common_8 = {
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) 1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) 2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) 3,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) 5,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) 8,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -1,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -2,
	(MR_Integer) -1,
	(MR_Integer) -2
};

static const struct mercury_data_gml__common_9_struct mercury_data_gml__common_9 = {
	MR_string_const("string", 6),
	MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0))
};

static const struct mercury_data_gml__common_10_struct mercury_data_gml__common_10 = {
	MR_string_const("' in ", 5),
	MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_9)
};

static const struct mercury_data_gml__common_11_struct mercury_data_gml__common_11 = {
	MR_string_const("float exponent", 14),
	MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0))
};

static const struct mercury_data_gml__common_12_struct mercury_data_gml__common_12 = {
	MR_string_const("' in ", 5),
	MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_11)
};
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_18_gml__token_group_0;

const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_token_list_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__token_list_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__token_list_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___gml__token_list_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"gml",
	"token_list",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_18_gml__token_group_0 },
	-1,
	-1
};
extern const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_token_group_0[];
extern const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_token_group_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_token_group_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__token_group_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__token_group_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___gml__token_group_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"gml",
	"token_group",
	4,
	{ (void *) mercury_data_gml__du_name_ordered_token_group_0 },
	{ (void *) mercury_data_gml__du_ptag_ordered_token_group_0 },
	3,
	3
};
extern const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_token_0[];
extern const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_token_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_token_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__token_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__token_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___gml__token_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"gml",
	"token",
	4,
	{ (void *) mercury_data_gml__du_name_ordered_token_0 },
	{ (void *) mercury_data_gml__du_ptag_ordered_token_0 },
	7,
	4
};
extern const MR_EnumFunctorDesc * mercury_data_gml__enum_name_ordered_stop_at_0[];
extern const MR_EnumFunctorDesc * mercury_data_gml__enum_value_ordered_stop_at_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_stop_at_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__stop_at_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__stop_at_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___gml__stop_at_0_0)),
	MR_TYPECTOR_REP_ENUM,
	NULL,
	NULL,
	"gml",
	"stop_at",
	4,
	{ (void *) mercury_data_gml__enum_name_ordered_stop_at_0 },
	{ (void *) mercury_data_gml__enum_value_ordered_stop_at_0 },
	3,
	-1
};
static const MR_NotagFunctorDesc mercury_data_gml__notag_functor_desc_parse_error_0;
static const MR_NotagFunctorDesc mercury_data_gml__notag_functor_desc_parse_error_0;

const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_parse_error_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__parse_error_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__parse_error_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___gml__parse_error_0_0)),
	MR_TYPECTOR_REP_NOTAG_GROUND,
	NULL,
	NULL,
	"gml",
	"parse_error",
	4,
	{ (void *) &mercury_data_gml__notag_functor_desc_parse_error_0 },
	{ (void *) &mercury_data_gml__notag_functor_desc_parse_error_0 },
	1,
	-1
};
extern const MR_EnumFunctorDesc * mercury_data_gml__enum_name_ordered_operator_0[];
extern const MR_EnumFunctorDesc * mercury_data_gml__enum_value_ordered_operator_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_operator_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__operator_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__operator_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___gml__operator_0_0)),
	MR_TYPECTOR_REP_ENUM,
	NULL,
	NULL,
	"gml",
	"operator",
	4,
	{ (void *) mercury_data_gml__enum_name_ordered_operator_0 },
	{ (void *) mercury_data_gml__enum_value_ordered_operator_0 },
	50,
	-1
};
extern const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_number_0[];
extern const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_number_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_number_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__number_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__number_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___gml__number_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"gml",
	"number",
	4,
	{ (void *) mercury_data_gml__du_name_ordered_number_0 },
	{ (void *) mercury_data_gml__du_ptag_ordered_number_0 },
	2,
	2
};
extern const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_lexer_error_0[];
extern const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_lexer_error_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_lexer_error_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__lexer_error_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__lexer_error_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___gml__lexer_error_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"gml",
	"lexer_error",
	4,
	{ (void *) mercury_data_gml__du_name_ordered_lexer_error_0 },
	{ (void *) mercury_data_gml__du_ptag_ordered_lexer_error_0 },
	1,
	1
};
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_18_gml__token_group_0;

const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_gml_program_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__gml_program_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__gml_program_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___gml__gml_program_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"gml",
	"gml_program",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_18_gml__token_group_0 },
	-1,
	-1
};
extern const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_extra_operator_0[];
extern const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_extra_operator_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_extra_operator_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__extra_operator_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__extra_operator_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___gml__extra_operator_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"gml",
	"extra_operator",
	4,
	{ (void *) mercury_data_gml__du_name_ordered_extra_operator_0 },
	{ (void *) mercury_data_gml__du_ptag_ordered_extra_operator_0 },
	10,
	4
};
extern const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_basic_token_0[];
extern const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_basic_token_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_basic_token_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__basic_token_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___gml__basic_token_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___gml__basic_token_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"gml",
	"basic_token",
	4,
	{ (void *) mercury_data_gml__du_name_ordered_basic_token_0 },
	{ (void *) mercury_data_gml__du_ptag_ordered_basic_token_0 },
	5,
	2
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_token_group_0;

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_18_gml__token_group_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_PseudoTypeInfo) &mercury_data_gml__type_ctor_info_token_group_0
}};

const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_token_group_0[] = {
	&mercury_data_gml__du_functor_desc_token_group_0_2,
	&mercury_data_gml__du_functor_desc_token_group_0_1,
	&mercury_data_gml__du_functor_desc_token_group_0_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_group_0_0 = {
	"single_token",
	1,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_token_group_0_0,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_token_0;

const MR_PseudoTypeInfo mercury_data_gml__field_types_token_group_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_gml__type_ctor_info_token_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_group_0_1 = {
	"function",
	1,
	0,
	MR_SECTAG_NONE,
	1,
	0,
	1,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_token_group_0_1,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_gml__field_types_token_group_0_1[] = {
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_18_gml__token_group_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_group_0_2 = {
	"array",
	1,
	0,
	MR_SECTAG_NONE,
	2,
	0,
	2,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_token_group_0_2,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_gml__field_types_token_group_0_2[] = {
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_18_gml__token_group_0
};

const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_token_group_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_gml__du_stag_ordered_token_group_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_gml__du_stag_ordered_token_group_0_1 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_gml__du_stag_ordered_token_group_0_2 }

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_group_0_0[] = {
	&mercury_data_gml__du_functor_desc_token_group_0_0

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_group_0_1[] = {
	&mercury_data_gml__du_functor_desc_token_group_0_1

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_group_0_2[] = {
	&mercury_data_gml__du_functor_desc_token_group_0_2

};

const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_token_0[] = {
	&mercury_data_gml__du_functor_desc_token_0_2,
	&mercury_data_gml__du_functor_desc_token_0_3,
	&mercury_data_gml__du_functor_desc_token_0_6,
	&mercury_data_gml__du_functor_desc_token_0_1,
	&mercury_data_gml__du_functor_desc_token_0_4,
	&mercury_data_gml__du_functor_desc_token_0_0,
	&mercury_data_gml__du_functor_desc_token_0_5
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_0 = {
	"operator",
	1,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_token_0_0,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_operator_0;

const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_gml__type_ctor_info_operator_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_1 = {
	"identifier",
	1,
	0,
	MR_SECTAG_NONE,
	1,
	0,
	1,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_token_0_1,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_string_0;

const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_1[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_2 = {
	"binder",
	1,
	0,
	MR_SECTAG_NONE,
	2,
	0,
	2,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_token_0_2,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_2[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_3 = {
	"boolean",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	0,
	3,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_token_0_3,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_bool__type_ctor_info_bool_0;

const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_3[] = {
	(MR_PseudoTypeInfo) &mercury_data_bool__type_ctor_info_bool_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_4 = {
	"number",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	1,
	4,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_token_0_4,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_number_0;

const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_4[] = {
	(MR_PseudoTypeInfo) &mercury_data_gml__type_ctor_info_number_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_5 = {
	"string",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	2,
	5,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_token_0_5,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_5[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_token_0_6 = {
	"extra",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	3,
	6,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_token_0_6,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_extra_operator_0;

const MR_PseudoTypeInfo mercury_data_gml__field_types_token_0_6[] = {
	(MR_PseudoTypeInfo) &mercury_data_gml__type_ctor_info_extra_operator_0
};

const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_token_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_gml__du_stag_ordered_token_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_gml__du_stag_ordered_token_0_1 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_gml__du_stag_ordered_token_0_2 },
	{ 4, MR_SECTAG_REMOTE,
	mercury_data_gml__du_stag_ordered_token_0_3 }

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_0_0[] = {
	&mercury_data_gml__du_functor_desc_token_0_0

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_0_1[] = {
	&mercury_data_gml__du_functor_desc_token_0_1

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_0_2[] = {
	&mercury_data_gml__du_functor_desc_token_0_2

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_token_0_3[] = {
	&mercury_data_gml__du_functor_desc_token_0_3,
	&mercury_data_gml__du_functor_desc_token_0_4,
	&mercury_data_gml__du_functor_desc_token_0_5,
	&mercury_data_gml__du_functor_desc_token_0_6

};

const MR_EnumFunctorDesc * mercury_data_gml__enum_name_ordered_stop_at_0[] = {
	&mercury_data_gml__enum_functor_desc_stop_at_0_1,
	&mercury_data_gml__enum_functor_desc_stop_at_0_2,
	&mercury_data_gml__enum_functor_desc_stop_at_0_0
};

const MR_EnumFunctorDesc * mercury_data_gml__enum_value_ordered_stop_at_0[] = {
	&mercury_data_gml__enum_functor_desc_stop_at_0_0,
	&mercury_data_gml__enum_functor_desc_stop_at_0_1,
	&mercury_data_gml__enum_functor_desc_stop_at_0_2
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_stop_at_0_0 = {
	"eof",
	0
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_stop_at_0_1 = {
	"end_array",
	1
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_stop_at_0_2 = {
	"end_function",
	2
};

static const MR_NotagFunctorDesc mercury_data_gml__notag_functor_desc_parse_error_0 = {
	"parse_error",
	 (MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0,
	NULL
};

const MR_EnumFunctorDesc * mercury_data_gml__enum_name_ordered_operator_0[] = {
	&mercury_data_gml__enum_functor_desc_operator_0_0,
	&mercury_data_gml__enum_functor_desc_operator_0_2,
	&mercury_data_gml__enum_functor_desc_operator_0_1,
	&mercury_data_gml__enum_functor_desc_operator_0_3,
	&mercury_data_gml__enum_functor_desc_operator_0_4,
	&mercury_data_gml__enum_functor_desc_operator_0_5,
	&mercury_data_gml__enum_functor_desc_operator_0_6,
	&mercury_data_gml__enum_functor_desc_operator_0_7,
	&mercury_data_gml__enum_functor_desc_operator_0_8,
	&mercury_data_gml__enum_functor_desc_operator_0_9,
	&mercury_data_gml__enum_functor_desc_operator_0_10,
	&mercury_data_gml__enum_functor_desc_operator_0_12,
	&mercury_data_gml__enum_functor_desc_operator_0_11,
	&mercury_data_gml__enum_functor_desc_operator_0_14,
	&mercury_data_gml__enum_functor_desc_operator_0_13,
	&mercury_data_gml__enum_functor_desc_operator_0_15,
	&mercury_data_gml__enum_functor_desc_operator_0_16,
	&mercury_data_gml__enum_functor_desc_operator_0_17,
	&mercury_data_gml__enum_functor_desc_operator_0_18,
	&mercury_data_gml__enum_functor_desc_operator_0_19,
	&mercury_data_gml__enum_functor_desc_operator_0_20,
	&mercury_data_gml__enum_functor_desc_operator_0_21,
	&mercury_data_gml__enum_functor_desc_operator_0_22,
	&mercury_data_gml__enum_functor_desc_operator_0_23,
	&mercury_data_gml__enum_functor_desc_operator_0_25,
	&mercury_data_gml__enum_functor_desc_operator_0_24,
	&mercury_data_gml__enum_functor_desc_operator_0_26,
	&mercury_data_gml__enum_functor_desc_operator_0_27,
	&mercury_data_gml__enum_functor_desc_operator_0_29,
	&mercury_data_gml__enum_functor_desc_operator_0_28,
	&mercury_data_gml__enum_functor_desc_operator_0_31,
	&mercury_data_gml__enum_functor_desc_operator_0_30,
	&mercury_data_gml__enum_functor_desc_operator_0_32,
	&mercury_data_gml__enum_functor_desc_operator_0_33,
	&mercury_data_gml__enum_functor_desc_operator_0_34,
	&mercury_data_gml__enum_functor_desc_operator_0_35,
	&mercury_data_gml__enum_functor_desc_operator_0_36,
	&mercury_data_gml__enum_functor_desc_operator_0_37,
	&mercury_data_gml__enum_functor_desc_operator_0_38,
	&mercury_data_gml__enum_functor_desc_operator_0_39,
	&mercury_data_gml__enum_functor_desc_operator_0_40,
	&mercury_data_gml__enum_functor_desc_operator_0_41,
	&mercury_data_gml__enum_functor_desc_operator_0_42,
	&mercury_data_gml__enum_functor_desc_operator_0_43,
	&mercury_data_gml__enum_functor_desc_operator_0_44,
	&mercury_data_gml__enum_functor_desc_operator_0_46,
	&mercury_data_gml__enum_functor_desc_operator_0_45,
	&mercury_data_gml__enum_functor_desc_operator_0_47,
	&mercury_data_gml__enum_functor_desc_operator_0_48,
	&mercury_data_gml__enum_functor_desc_operator_0_49
};

const MR_EnumFunctorDesc * mercury_data_gml__enum_value_ordered_operator_0[] = {
	&mercury_data_gml__enum_functor_desc_operator_0_0,
	&mercury_data_gml__enum_functor_desc_operator_0_1,
	&mercury_data_gml__enum_functor_desc_operator_0_2,
	&mercury_data_gml__enum_functor_desc_operator_0_3,
	&mercury_data_gml__enum_functor_desc_operator_0_4,
	&mercury_data_gml__enum_functor_desc_operator_0_5,
	&mercury_data_gml__enum_functor_desc_operator_0_6,
	&mercury_data_gml__enum_functor_desc_operator_0_7,
	&mercury_data_gml__enum_functor_desc_operator_0_8,
	&mercury_data_gml__enum_functor_desc_operator_0_9,
	&mercury_data_gml__enum_functor_desc_operator_0_10,
	&mercury_data_gml__enum_functor_desc_operator_0_11,
	&mercury_data_gml__enum_functor_desc_operator_0_12,
	&mercury_data_gml__enum_functor_desc_operator_0_13,
	&mercury_data_gml__enum_functor_desc_operator_0_14,
	&mercury_data_gml__enum_functor_desc_operator_0_15,
	&mercury_data_gml__enum_functor_desc_operator_0_16,
	&mercury_data_gml__enum_functor_desc_operator_0_17,
	&mercury_data_gml__enum_functor_desc_operator_0_18,
	&mercury_data_gml__enum_functor_desc_operator_0_19,
	&mercury_data_gml__enum_functor_desc_operator_0_20,
	&mercury_data_gml__enum_functor_desc_operator_0_21,
	&mercury_data_gml__enum_functor_desc_operator_0_22,
	&mercury_data_gml__enum_functor_desc_operator_0_23,
	&mercury_data_gml__enum_functor_desc_operator_0_24,
	&mercury_data_gml__enum_functor_desc_operator_0_25,
	&mercury_data_gml__enum_functor_desc_operator_0_26,
	&mercury_data_gml__enum_functor_desc_operator_0_27,
	&mercury_data_gml__enum_functor_desc_operator_0_28,
	&mercury_data_gml__enum_functor_desc_operator_0_29,
	&mercury_data_gml__enum_functor_desc_operator_0_30,
	&mercury_data_gml__enum_functor_desc_operator_0_31,
	&mercury_data_gml__enum_functor_desc_operator_0_32,
	&mercury_data_gml__enum_functor_desc_operator_0_33,
	&mercury_data_gml__enum_functor_desc_operator_0_34,
	&mercury_data_gml__enum_functor_desc_operator_0_35,
	&mercury_data_gml__enum_functor_desc_operator_0_36,
	&mercury_data_gml__enum_functor_desc_operator_0_37,
	&mercury_data_gml__enum_functor_desc_operator_0_38,
	&mercury_data_gml__enum_functor_desc_operator_0_39,
	&mercury_data_gml__enum_functor_desc_operator_0_40,
	&mercury_data_gml__enum_functor_desc_operator_0_41,
	&mercury_data_gml__enum_functor_desc_operator_0_42,
	&mercury_data_gml__enum_functor_desc_operator_0_43,
	&mercury_data_gml__enum_functor_desc_operator_0_44,
	&mercury_data_gml__enum_functor_desc_operator_0_45,
	&mercury_data_gml__enum_functor_desc_operator_0_46,
	&mercury_data_gml__enum_functor_desc_operator_0_47,
	&mercury_data_gml__enum_functor_desc_operator_0_48,
	&mercury_data_gml__enum_functor_desc_operator_0_49
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_0 = {
	"acos",
	0
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_1 = {
	"addi",
	1
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_2 = {
	"addf",
	2
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_3 = {
	"apply",
	3
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_4 = {
	"asin",
	4
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_5 = {
	"clampf",
	5
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_6 = {
	"cone",
	6
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_7 = {
	"cos",
	7
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_8 = {
	"cube",
	8
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_9 = {
	"cylinder",
	9
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_10 = {
	"difference",
	10
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_11 = {
	"divi",
	11
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_12 = {
	"divf",
	12
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_13 = {
	"eqi",
	13
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_14 = {
	"eqf",
	14
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_15 = {
	"floor",
	15
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_16 = {
	"frac",
	16
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_17 = {
	"get",
	17
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_18 = {
	"getx",
	18
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_19 = {
	"gety",
	19
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_20 = {
	"getz",
	20
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_21 = {
	"if",
	21
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_22 = {
	"intersect",
	22
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_23 = {
	"length",
	23
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_24 = {
	"lessi",
	24
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_25 = {
	"lessf",
	25
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_26 = {
	"light",
	26
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_27 = {
	"modi",
	27
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_28 = {
	"muli",
	28
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_29 = {
	"mulf",
	29
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_30 = {
	"negi",
	30
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_31 = {
	"negf",
	31
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_32 = {
	"plane",
	32
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_33 = {
	"point",
	33
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_34 = {
	"pointlight",
	34
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_35 = {
	"real",
	35
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_36 = {
	"render",
	36
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_37 = {
	"rotatex",
	37
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_38 = {
	"rotatey",
	38
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_39 = {
	"rotatez",
	39
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_40 = {
	"scale",
	40
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_41 = {
	"sin",
	41
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_42 = {
	"sphere",
	42
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_43 = {
	"spotlight",
	43
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_44 = {
	"sqrt",
	44
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_45 = {
	"subi",
	45
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_46 = {
	"subf",
	46
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_47 = {
	"translate",
	47
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_48 = {
	"union",
	48
};

static const MR_EnumFunctorDesc mercury_data_gml__enum_functor_desc_operator_0_49 = {
	"uscale",
	49
};

const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_number_0[] = {
	&mercury_data_gml__du_functor_desc_number_0_0,
	&mercury_data_gml__du_functor_desc_number_0_1
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_number_0_0 = {
	"integer",
	1,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_number_0_0,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;

const MR_PseudoTypeInfo mercury_data_gml__field_types_number_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_number_0_1 = {
	"real",
	1,
	0,
	MR_SECTAG_NONE,
	1,
	0,
	1,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_number_0_1,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_float_0;

const MR_PseudoTypeInfo mercury_data_gml__field_types_number_0_1[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_number_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_gml__du_stag_ordered_number_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_gml__du_stag_ordered_number_0_1 }

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_number_0_0[] = {
	&mercury_data_gml__du_functor_desc_number_0_0

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_number_0_1[] = {
	&mercury_data_gml__du_functor_desc_number_0_1

};

const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_lexer_error_0[] = {
	&mercury_data_gml__du_functor_desc_lexer_error_0_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_lexer_error_0_0 = {
	"lexer_error",
	2,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_lexer_error_0_0,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_gml__field_types_lexer_error_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0
};

const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_lexer_error_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_gml__du_stag_ordered_lexer_error_0_0 }

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_lexer_error_0_0[] = {
	&mercury_data_gml__du_functor_desc_lexer_error_0_0

};

const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_extra_operator_0[] = {
	&mercury_data_gml__du_functor_desc_extra_operator_0_4,
	&mercury_data_gml__du_functor_desc_extra_operator_0_5,
	&mercury_data_gml__du_functor_desc_extra_operator_0_6,
	&mercury_data_gml__du_functor_desc_extra_operator_0_8,
	&mercury_data_gml__du_functor_desc_extra_operator_0_3,
	&mercury_data_gml__du_functor_desc_extra_operator_0_7,
	&mercury_data_gml__du_functor_desc_extra_operator_0_2,
	&mercury_data_gml__du_functor_desc_extra_operator_0_1,
	&mercury_data_gml__du_functor_desc_extra_operator_0_9,
	&mercury_data_gml__du_functor_desc_extra_operator_0_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_0 = {
	"popn",
	1,
	0,
	MR_SECTAG_NONE,
	1,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_extra_operator_0_0,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_1 = {
	"dup",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	0,
	1,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_2 = {
	"constant_sphere",
	1,
	0,
	MR_SECTAG_NONE,
	2,
	0,
	2,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_extra_operator_0_2,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_surface_properties_0;

const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_2[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_surface_properties_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_3 = {
	"constant_plane",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	0,
	3,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_extra_operator_0_3,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_3[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_surface_properties_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_4 = {
	"constant_cone",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	1,
	4,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_extra_operator_0_4,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_4[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_surface_properties_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_5 = {
	"constant_cube",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	2,
	5,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_extra_operator_0_5,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_5[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_surface_properties_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_6 = {
	"constant_cylinder",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	3,
	6,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_extra_operator_0_6,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_6[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_surface_properties_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_7 = {
	"constant_point",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	4,
	7,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_extra_operator_0_7,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_vector_0;

const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_7[] = {
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_8 = {
	"constant_if",
	2,
	0,
	MR_SECTAG_REMOTE,
	3,
	5,
	8,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_extra_operator_0_8,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_value_0;

const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_8[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_value_0,
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_value_0
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_extra_operator_0_9 = {
	"mercury_closure",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	6,
	9,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_extra_operator_0_9,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_gml__field_types_extra_operator_0_9[] = {
	(MR_PseudoTypeInfo) &mercury_data___ho_type_info_pred_6__type_18_tree234__tree234_2__type0_10___string_0__type0_13_eval__value_0__type_12_list__list_1__type0_13_eval__value_0__type_18_tree234__tree234_2__type0_10___string_0__type0_13_eval__value_0__type_12_list__list_1__type0_13_eval__value_0__type0_11_io__state_0__type0_11_io__state_0
};

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_13_eval__value_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_value_0
}};
extern const struct MR_TypeCtorInfo_Struct mercury_data_tree234__type_ctor_info_tree234_2;

#ifndef MR_FO_PseudoTypeInfo_Struct2_GUARD
#define MR_FO_PseudoTypeInfo_Struct2_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct2, 2);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct2 mercury_data_tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0 = {
	&mercury_data_tree234__type_ctor_info_tree234_2,
{	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0,
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_value_0
}};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_pred_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_state_0;

#ifndef MR_HO_PseudoTypeInfo_Struct6_GUARD
#define MR_HO_PseudoTypeInfo_Struct6_GUARD
MR_HIGHER_ORDER_PSEUDOTYPEINFO_STRUCT(MR_HO_PseudoTypeInfo_Struct6, 6);
#endif
static const struct MR_HO_PseudoTypeInfo_Struct6 mercury_data___ho_type_info_pred_6__type_18_tree234__tree234_2__type0_10___string_0__type0_13_eval__value_0__type_12_list__list_1__type0_13_eval__value_0__type_18_tree234__tree234_2__type0_10___string_0__type0_13_eval__value_0__type_12_list__list_1__type0_13_eval__value_0__type0_11_io__state_0__type0_11_io__state_0 = {
	&mercury_data___type_ctor_info_pred_0,
	6,
{	(MR_PseudoTypeInfo) &mercury_data_tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0,
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_13_eval__value_0,
	(MR_PseudoTypeInfo) &mercury_data_tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0,
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_13_eval__value_0,
	(MR_PseudoTypeInfo) &mercury_data_io__type_ctor_info_state_0,
	(MR_PseudoTypeInfo) &mercury_data_io__type_ctor_info_state_0
}};

const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_extra_operator_0[] = {
	{ 1, MR_SECTAG_LOCAL,
	mercury_data_gml__du_stag_ordered_extra_operator_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_gml__du_stag_ordered_extra_operator_0_1 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_gml__du_stag_ordered_extra_operator_0_2 },
	{ 7, MR_SECTAG_REMOTE,
	mercury_data_gml__du_stag_ordered_extra_operator_0_3 }

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_extra_operator_0_0[] = {
	&mercury_data_gml__du_functor_desc_extra_operator_0_1

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_extra_operator_0_1[] = {
	&mercury_data_gml__du_functor_desc_extra_operator_0_0

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_extra_operator_0_2[] = {
	&mercury_data_gml__du_functor_desc_extra_operator_0_2

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_extra_operator_0_3[] = {
	&mercury_data_gml__du_functor_desc_extra_operator_0_3,
	&mercury_data_gml__du_functor_desc_extra_operator_0_4,
	&mercury_data_gml__du_functor_desc_extra_operator_0_5,
	&mercury_data_gml__du_functor_desc_extra_operator_0_6,
	&mercury_data_gml__du_functor_desc_extra_operator_0_7,
	&mercury_data_gml__du_functor_desc_extra_operator_0_8,
	&mercury_data_gml__du_functor_desc_extra_operator_0_9

};

const MR_DuFunctorDesc * mercury_data_gml__du_name_ordered_basic_token_0[] = {
	&mercury_data_gml__du_functor_desc_basic_token_0_0,
	&mercury_data_gml__du_functor_desc_basic_token_0_1,
	&mercury_data_gml__du_functor_desc_basic_token_0_4,
	&mercury_data_gml__du_functor_desc_basic_token_0_2,
	&mercury_data_gml__du_functor_desc_basic_token_0_3
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_basic_token_0_0 = {
	"[",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_basic_token_0_1 = {
	"]",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	1,
	1,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_basic_token_0_2 = {
	"{",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	2,
	2,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_basic_token_0_3 = {
	"}",
	0,
	0,
	MR_SECTAG_LOCAL,
	0,
	3,
	3,
	(MR_PseudoTypeInfo *) NULL,
	NULL,
	NULL
};

static const MR_DuFunctorDesc mercury_data_gml__du_functor_desc_basic_token_0_4 = {
	"token",
	1,
	0,
	MR_SECTAG_NONE,
	1,
	0,
	4,
	(MR_PseudoTypeInfo *) mercury_data_gml__field_types_basic_token_0_4,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_gml__field_types_basic_token_0_4[] = {
	(MR_PseudoTypeInfo) &mercury_data_gml__type_ctor_info_token_0
};

const MR_DuPtagLayout mercury_data_gml__du_ptag_ordered_basic_token_0[] = {
	{ 4, MR_SECTAG_LOCAL,
	mercury_data_gml__du_stag_ordered_basic_token_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_gml__du_stag_ordered_basic_token_0_1 }

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_basic_token_0_0[] = {
	&mercury_data_gml__du_functor_desc_basic_token_0_0,
	&mercury_data_gml__du_functor_desc_basic_token_0_1,
	&mercury_data_gml__du_functor_desc_basic_token_0_2,
	&mercury_data_gml__du_functor_desc_basic_token_0_3

};

const MR_DuFunctorDesc * mercury_data_gml__du_stag_ordered_basic_token_0_1[] = {
	&mercury_data_gml__du_functor_desc_basic_token_0_4

};

MR_declare_entry(mercury__std_util__semidet_succeed_0_0);
MR_declare_entry(mercury__require__error_1_0);
MR_declare_entry(mercury__list__reverse_2_3_0);
MR_declare_entry(mercury__exception__throw_1_0);
MR_declare_entry(mercury__char__is_alpha_1_0);
MR_declare_entry(mercury__char__is_digit_1_0);
MR_declare_entry(mercury__char__is_alnum_or_underscore_1_0);
MR_declare_entry(mercury__string__append_3_2);
static const struct mercury_const_36_struct {
	MR_Integer f1;
	MR_Integer f2;
	MR_Integer f3;
}  mercury_const_36 = {
	(MR_Integer) -67043329,
	(MR_Integer) -134217727,
	(MR_Integer) 2013265921
};
MR_declare_entry(mercury__string__base_string_to_int_3_0);
MR_declare_entry(mercury__compare_error_0_0);
MR_declare_entry(mercury____Unify___eval__surface_properties_0_0);
MR_declare_entry(mercury____Unify___vector__vector_0_0);
MR_declare_entry(mercury____Unify___eval__value_0_0);
MR_declare_entry(mercury____Compare___eval__surface_properties_0_0);
MR_declare_entry(mercury____Compare___vector__vector_0_0);
MR_declare_entry(mercury____Compare___eval__value_0_0);
MR_declare_entry(mercury____Unify___list__list_1_0);
MR_declare_entry(mercury____Compare___list__list_1_0);

MR_BEGIN_MODULE(gml_module)
	MR_init_entry(mercury__gml__builtin_compare_pred__ua0_3_0);
	MR_init_label(mercury__gml__builtin_compare_pred__ua0_3_0_i4);
	MR_init_label(mercury__gml__builtin_compare_pred__ua0_3_0_i3);
	MR_init_entry(mercury__gml__builtin_unify_pred__ua0_2_0);
	MR_init_label(mercury__gml__builtin_unify_pred__ua0_2_0_i4);
	MR_init_label(mercury__gml__builtin_unify_pred__ua0_2_0_i3);
	MR_init_label(mercury__gml__builtin_unify_pred__ua0_2_0_i9);
	MR_init_entry(mercury__gml__tokenize_3_0);
	MR_init_label(mercury__gml__tokenize_3_0_i2);
	MR_init_label(mercury__gml__tokenize_3_0_i3);
	MR_init_entry(mercury__gml__parse_2_0);
	MR_init_label(mercury__gml__parse_2_0_i2);
	MR_init_label(mercury__gml__parse_2_0_i3);
	MR_init_label(mercury__gml__parse_2_0_i5);
	MR_init_entry(mercury__gml__tokenize_2_4_0);
	MR_init_label(mercury__gml__tokenize_2_4_0_i2);
	MR_init_label(mercury__gml__tokenize_2_4_0_i8);
	MR_init_label(mercury__gml__tokenize_2_4_0_i9);
	MR_init_label(mercury__gml__tokenize_2_4_0_i5);
	MR_init_label(mercury__gml__tokenize_2_4_0_i6);
	MR_init_entry(mercury__gml__skip_whitespace_3_0);
	MR_init_label(mercury__gml__skip_whitespace_3_0_i2);
	MR_init_label(mercury__gml__skip_whitespace_3_0_i4);
	MR_init_label(mercury__gml__skip_whitespace_3_0_i7);
	MR_init_label(mercury__gml__skip_whitespace_3_0_i5);
	MR_init_label(mercury__gml__skip_whitespace_3_0_i11);
	MR_init_label(mercury__gml__skip_whitespace_3_0_i12);
	MR_init_label(mercury__gml__skip_whitespace_3_0_i13);
	MR_init_label(mercury__gml__skip_whitespace_3_0_i14);
	MR_init_label(mercury__gml__skip_whitespace_3_0_i15);
	MR_init_label(mercury__gml__skip_whitespace_3_0_i3);
	MR_init_entry(mercury__gml__skip_to_end_of_line_2_0);
	MR_init_label(mercury__gml__skip_to_end_of_line_2_0_i2);
	MR_init_label(mercury__gml__skip_to_end_of_line_2_0_i4);
	MR_init_label(mercury__gml__skip_to_end_of_line_2_0_i5);
	MR_init_label(mercury__gml__skip_to_end_of_line_2_0_i7);
	MR_init_label(mercury__gml__skip_to_end_of_line_2_0_i9);
	MR_init_label(mercury__gml__skip_to_end_of_line_2_0_i11);
	MR_init_entry(mercury__gml__get_token_4_0);
	MR_init_label(mercury__gml__get_token_4_0_i4);
	MR_init_label(mercury__gml__get_token_4_0_i5);
	MR_init_label(mercury__gml__get_token_4_0_i6);
	MR_init_label(mercury__gml__get_token_4_0_i2);
	MR_init_label(mercury__gml__get_token_4_0_i10);
	MR_init_label(mercury__gml__get_token_4_0_i8);
	MR_init_label(mercury__gml__get_token_4_0_i13);
	MR_init_label(mercury__gml__get_token_4_0_i15);
	MR_init_label(mercury__gml__get_token_4_0_i16);
	MR_init_label(mercury__gml__get_token_4_0_i18);
	MR_init_label(mercury__gml__get_token_4_0_i22);
	MR_init_label(mercury__gml__get_token_4_0_i20);
	MR_init_label(mercury__gml__get_token_4_0_i11);
	MR_init_label(mercury__gml__get_token_4_0_i29);
	MR_init_label(mercury__gml__get_token_4_0_i35);
	MR_init_label(mercury__gml__get_token_4_0_i33);
	MR_init_label(mercury__gml__get_token_4_0_i37);
	MR_init_label(mercury__gml__get_token_4_0_i30);
	MR_init_label(mercury__gml__get_token_4_0_i27);
	MR_init_label(mercury__gml__get_token_4_0_i41);
	MR_init_label(mercury__gml__get_token_4_0_i46);
	MR_init_label(mercury__gml__get_token_4_0_i48);
	MR_init_label(mercury__gml__get_token_4_0_i44);
	MR_init_label(mercury__gml__get_token_4_0_i49);
	MR_init_entry(mercury__gml__is_operator_2_0);
	MR_init_label(mercury__gml__is_operator_2_0_i3);
	MR_init_label(mercury__gml__is_operator_2_0_i57);
	MR_init_label(mercury__gml__is_operator_2_0_i5);
	MR_init_label(mercury__gml__is_operator_2_0_i6);
	MR_init_label(mercury__gml__is_operator_2_0_i7);
	MR_init_label(mercury__gml__is_operator_2_0_i8);
	MR_init_label(mercury__gml__is_operator_2_0_i9);
	MR_init_label(mercury__gml__is_operator_2_0_i10);
	MR_init_label(mercury__gml__is_operator_2_0_i11);
	MR_init_label(mercury__gml__is_operator_2_0_i12);
	MR_init_label(mercury__gml__is_operator_2_0_i13);
	MR_init_label(mercury__gml__is_operator_2_0_i14);
	MR_init_label(mercury__gml__is_operator_2_0_i15);
	MR_init_label(mercury__gml__is_operator_2_0_i16);
	MR_init_label(mercury__gml__is_operator_2_0_i17);
	MR_init_label(mercury__gml__is_operator_2_0_i18);
	MR_init_label(mercury__gml__is_operator_2_0_i19);
	MR_init_label(mercury__gml__is_operator_2_0_i20);
	MR_init_label(mercury__gml__is_operator_2_0_i21);
	MR_init_label(mercury__gml__is_operator_2_0_i22);
	MR_init_label(mercury__gml__is_operator_2_0_i23);
	MR_init_label(mercury__gml__is_operator_2_0_i24);
	MR_init_label(mercury__gml__is_operator_2_0_i25);
	MR_init_label(mercury__gml__is_operator_2_0_i26);
	MR_init_label(mercury__gml__is_operator_2_0_i27);
	MR_init_label(mercury__gml__is_operator_2_0_i28);
	MR_init_label(mercury__gml__is_operator_2_0_i29);
	MR_init_label(mercury__gml__is_operator_2_0_i30);
	MR_init_label(mercury__gml__is_operator_2_0_i31);
	MR_init_label(mercury__gml__is_operator_2_0_i32);
	MR_init_label(mercury__gml__is_operator_2_0_i33);
	MR_init_label(mercury__gml__is_operator_2_0_i34);
	MR_init_label(mercury__gml__is_operator_2_0_i35);
	MR_init_label(mercury__gml__is_operator_2_0_i36);
	MR_init_label(mercury__gml__is_operator_2_0_i37);
	MR_init_label(mercury__gml__is_operator_2_0_i38);
	MR_init_label(mercury__gml__is_operator_2_0_i39);
	MR_init_label(mercury__gml__is_operator_2_0_i40);
	MR_init_label(mercury__gml__is_operator_2_0_i41);
	MR_init_label(mercury__gml__is_operator_2_0_i42);
	MR_init_label(mercury__gml__is_operator_2_0_i43);
	MR_init_label(mercury__gml__is_operator_2_0_i44);
	MR_init_label(mercury__gml__is_operator_2_0_i45);
	MR_init_label(mercury__gml__is_operator_2_0_i46);
	MR_init_label(mercury__gml__is_operator_2_0_i47);
	MR_init_label(mercury__gml__is_operator_2_0_i48);
	MR_init_label(mercury__gml__is_operator_2_0_i49);
	MR_init_label(mercury__gml__is_operator_2_0_i50);
	MR_init_label(mercury__gml__is_operator_2_0_i51);
	MR_init_label(mercury__gml__is_operator_2_0_i52);
	MR_init_label(mercury__gml__is_operator_2_0_i53);
	MR_init_label(mercury__gml__is_operator_2_0_i54);
	MR_init_label(mercury__gml__is_operator_2_0_i55);
	MR_init_entry(mercury__gml__get_identifier_4_0);
	MR_init_label(mercury__gml__get_identifier_4_0_i2);
	MR_init_label(mercury__gml__get_identifier_4_0_i4);
	MR_init_label(mercury__gml__get_identifier_4_0_i10);
	MR_init_label(mercury__gml__get_identifier_4_0_i8);
	MR_init_label(mercury__gml__get_identifier_4_0_i6);
	MR_init_entry(mercury__gml__get_string_4_0);
	MR_init_label(mercury__gml__get_string_4_0_i2);
	MR_init_label(mercury__gml__get_string_4_0_i5);
	MR_init_label(mercury__gml__get_string_4_0_i4);
	MR_init_label(mercury__gml__get_string_4_0_i7);
	MR_init_label(mercury__gml__get_string_4_0_i14);
	MR_init_label(mercury__gml__get_string_4_0_i12);
	MR_init_label(mercury__gml__get_string_4_0_i10);
	MR_init_label(mercury__gml__get_string_4_0_i18);
	MR_init_entry(mercury__gml__get_number_4_0);
	MR_init_label(mercury__gml__get_number_4_0_i2);
	MR_init_label(mercury__gml__get_number_4_0_i6);
	MR_init_label(mercury__gml__get_number_4_0_i5);
	MR_init_label(mercury__gml__get_number_4_0_i4);
	MR_init_label(mercury__gml__get_number_4_0_i12);
	MR_init_label(mercury__gml__get_number_4_0_i10);
	MR_init_label(mercury__gml__get_number_4_0_i15);
	MR_init_label(mercury__gml__get_number_4_0_i20);
	MR_init_label(mercury__gml__get_number_4_0_i18);
	MR_init_label(mercury__gml__get_number_4_0_i24);
	MR_init_label(mercury__gml__get_number_4_0_i23);
	MR_init_label(mercury__gml__get_number_4_0_i26);
	MR_init_entry(mercury__gml__get_int_dot_4_0);
	MR_init_label(mercury__gml__get_int_dot_4_0_i2);
	MR_init_label(mercury__gml__get_int_dot_4_0_i6);
	MR_init_label(mercury__gml__get_int_dot_4_0_i5);
	MR_init_label(mercury__gml__get_int_dot_4_0_i8);
	MR_init_label(mercury__gml__get_int_dot_4_0_i4);
	MR_init_label(mercury__gml__get_int_dot_4_0_i12);
	MR_init_label(mercury__gml__get_int_dot_4_0_i10);
	MR_init_entry(mercury__gml__get_float_decimals_4_0);
	MR_init_label(mercury__gml__get_float_decimals_4_0_i2);
	MR_init_label(mercury__gml__get_float_decimals_4_0_i7);
	MR_init_label(mercury__gml__get_float_decimals_4_0_i4);
	MR_init_label(mercury__gml__get_float_decimals_4_0_i13);
	MR_init_label(mercury__gml__get_float_decimals_4_0_i11);
	MR_init_label(mercury__gml__get_float_decimals_4_0_i18);
	MR_init_label(mercury__gml__get_float_decimals_4_0_i16);
	MR_init_label(mercury__gml__get_float_decimals_4_0_i23);
	MR_init_label(mercury__gml__get_float_decimals_4_0_i25);
	MR_init_entry(mercury__gml__get_float_exponent_4_0);
	MR_init_label(mercury__gml__get_float_exponent_4_0_i2);
	MR_init_label(mercury__gml__get_float_exponent_4_0_i7);
	MR_init_label(mercury__gml__get_float_exponent_4_0_i4);
	MR_init_label(mercury__gml__get_float_exponent_4_0_i11);
	MR_init_label(mercury__gml__get_float_exponent_4_0_i16);
	MR_init_label(mercury__gml__get_float_exponent_4_0_i14);
	MR_init_label(mercury__gml__get_float_exponent_4_0_i19);
	MR_init_entry(mercury__gml__get_float_exponent_2_4_0);
	MR_init_label(mercury__gml__get_float_exponent_2_4_0_i2);
	MR_init_label(mercury__gml__get_float_exponent_2_4_0_i5);
	MR_init_label(mercury__gml__get_float_exponent_2_4_0_i4);
	MR_init_label(mercury__gml__get_float_exponent_2_4_0_i9);
	MR_init_label(mercury__gml__get_float_exponent_2_4_0_i7);
	MR_init_label(mercury__gml__get_float_exponent_2_4_0_i12);
	MR_init_entry(mercury__gml__get_float_exponent_3_4_0);
	MR_init_label(mercury__gml__get_float_exponent_3_4_0_i2);
	MR_init_label(mercury__gml__get_float_exponent_3_4_0_i7);
	MR_init_label(mercury__gml__get_float_exponent_3_4_0_i4);
	MR_init_label(mercury__gml__get_float_exponent_3_4_0_i13);
	MR_init_label(mercury__gml__get_float_exponent_3_4_0_i11);
	MR_init_label(mercury__gml__get_float_exponent_3_4_0_i18);
	MR_init_label(mercury__gml__get_float_exponent_3_4_0_i20);
	MR_init_entry(mercury__gml__rev_char_list_to_int_5_0);
	MR_init_label(mercury__gml__rev_char_list_to_int_5_0_i4);
	MR_init_label(mercury__gml__rev_char_list_to_int_5_0_i2);
	MR_init_label(mercury__gml__rev_char_list_to_int_5_0_i6);
	MR_init_entry(mercury__gml__lexer_read_char_3_0);
	MR_init_label(mercury__gml__lexer_read_char_3_0_i2);
	MR_init_label(mercury__gml__lexer_read_char_3_0_i6);
	MR_init_label(mercury__gml__lexer_read_char_3_0_i8);
	MR_init_entry(mercury__gml__parse_2_5_0);
	MR_init_label(mercury__gml__parse_2_5_0_i5);
	MR_init_label(mercury__gml__parse_2_5_0_i6);
	MR_init_label(mercury__gml__parse_2_5_0_i3);
	MR_init_label(mercury__gml__parse_2_5_0_i25);
	MR_init_label(mercury__gml__parse_2_5_0_i21);
	MR_init_label(mercury__gml__parse_2_5_0_i22);
	MR_init_label(mercury__gml__parse_2_5_0_i23);
	MR_init_label(mercury__gml__parse_2_5_0_i16);
	MR_init_label(mercury__gml__parse_2_5_0_i17);
	MR_init_label(mercury__gml__parse_2_5_0_i12);
	MR_init_label(mercury__gml__parse_2_5_0_i13);
	MR_init_label(mercury__gml__parse_2_5_0_i14);
	MR_init_label(mercury__gml__parse_2_5_0_i11);
	MR_init_entry(mercury____Unify___gml__basic_token_0_0);
	MR_init_label(mercury____Unify___gml__basic_token_0_0_i9);
	MR_init_label(mercury____Unify___gml__basic_token_0_0_i7);
	MR_init_label(mercury____Unify___gml__basic_token_0_0_i5);
	MR_init_label(mercury____Unify___gml__basic_token_0_0_i4);
	MR_init_label(mercury____Unify___gml__basic_token_0_0_i1);
	MR_init_entry(mercury____Index___gml__basic_token_0_0);
	MR_init_label(mercury____Index___gml__basic_token_0_0_i7);
	MR_init_label(mercury____Index___gml__basic_token_0_0_i6);
	MR_init_label(mercury____Index___gml__basic_token_0_0_i5);
	MR_init_label(mercury____Index___gml__basic_token_0_0_i4);
	MR_init_entry(mercury____Compare___gml__basic_token_0_0);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i7);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i6);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i5);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i4);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i13);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i12);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i11);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i10);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i14);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i15);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i25);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i23);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i21);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i20);
	MR_init_label(mercury____Compare___gml__basic_token_0_0_i232);
	MR_init_entry(mercury____Unify___gml__token_0_0);
	MR_init_label(mercury____Unify___gml__token_0_0_i4);
	MR_init_label(mercury____Unify___gml__token_0_0_i6);
	MR_init_label(mercury____Unify___gml__token_0_0_i8);
	MR_init_label(mercury____Unify___gml__token_0_0_i10);
	MR_init_label(mercury____Unify___gml__token_0_0_i19);
	MR_init_label(mercury____Unify___gml__token_0_0_i13);
	MR_init_label(mercury____Unify___gml__token_0_0_i16);
	MR_init_label(mercury____Unify___gml__token_0_0_i11);
	MR_init_label(mercury____Unify___gml__token_0_0_i1);
	MR_init_entry(mercury____Index___gml__token_0_0);
	MR_init_label(mercury____Index___gml__token_0_0_i4);
	MR_init_label(mercury____Index___gml__token_0_0_i5);
	MR_init_label(mercury____Index___gml__token_0_0_i6);
	MR_init_label(mercury____Index___gml__token_0_0_i7);
	MR_init_label(mercury____Index___gml__token_0_0_i10);
	MR_init_label(mercury____Index___gml__token_0_0_i9);
	MR_init_label(mercury____Index___gml__token_0_0_i8);
	MR_init_entry(mercury____Compare___gml__token_0_0);
	MR_init_label(mercury____Compare___gml__token_0_0_i2);
	MR_init_label(mercury____Compare___gml__token_0_0_i3);
	MR_init_label(mercury____Compare___gml__token_0_0_i4);
	MR_init_label(mercury____Compare___gml__token_0_0_i54);
	MR_init_label(mercury____Compare___gml__token_0_0_i5);
	MR_init_label(mercury____Compare___gml__token_0_0_i10);
	MR_init_label(mercury____Compare___gml__token_0_0_i12);
	MR_init_label(mercury____Compare___gml__token_0_0_i16);
	MR_init_label(mercury____Compare___gml__token_0_0_i18);
	MR_init_label(mercury____Compare___gml__token_0_0_i23);
	MR_init_label(mercury____Compare___gml__token_0_0_i25);
	MR_init_label(mercury____Compare___gml__token_0_0_i30);
	MR_init_label(mercury____Compare___gml__token_0_0_i40);
	MR_init_label(mercury____Compare___gml__token_0_0_i42);
	MR_init_label(mercury____Compare___gml__token_0_0_i37);
	MR_init_label(mercury____Compare___gml__token_0_0_i31);
	MR_init_label(mercury____Compare___gml__token_0_0_i33);
	MR_init_label(mercury____Compare___gml__token_0_0_i7);
	MR_init_entry(mercury____Unify___gml__number_0_0);
	MR_init_label(mercury____Unify___gml__number_0_0_i3);
	MR_init_label(mercury____Unify___gml__number_0_0_i1);
	MR_init_entry(mercury____Compare___gml__number_0_0);
	MR_init_label(mercury____Compare___gml__number_0_0_i6);
	MR_init_label(mercury____Compare___gml__number_0_0_i19);
	MR_init_label(mercury____Compare___gml__number_0_0_i3);
	MR_init_label(mercury____Compare___gml__number_0_0_i11);
	MR_init_label(mercury____Compare___gml__number_0_0_i21);
	MR_init_label(mercury____Compare___gml__number_0_0_i12);
	MR_init_label(mercury____Compare___gml__number_0_0_i22);
	MR_init_entry(mercury____Unify___gml__operator_0_0);
	MR_init_entry(mercury____Compare___gml__operator_0_0);
	MR_init_label(mercury____Compare___gml__operator_0_0_i2);
	MR_init_label(mercury____Compare___gml__operator_0_0_i3);
	MR_init_entry(mercury____Unify___gml__extra_operator_0_0);
	MR_init_label(mercury____Unify___gml__extra_operator_0_0_i4);
	MR_init_label(mercury____Unify___gml__extra_operator_0_0_i6);
	MR_init_label(mercury____Unify___gml__extra_operator_0_0_i8);
	MR_init_label(mercury____Unify___gml__extra_operator_0_0_i12);
	MR_init_label(mercury____Unify___gml__extra_operator_0_0_i13);
	MR_init_label(mercury____Unify___gml__extra_operator_0_0_i17);
	MR_init_label(mercury____Unify___gml__extra_operator_0_0_i21);
	MR_init_label(mercury____Unify___gml__extra_operator_0_0_i25);
	MR_init_label(mercury____Unify___gml__extra_operator_0_0_i29);
	MR_init_label(mercury____Unify___gml__extra_operator_0_0_i33);
	MR_init_label(mercury____Unify___gml__extra_operator_0_0_i35);
	MR_init_label(mercury____Unify___gml__extra_operator_0_0_i39);
	MR_init_label(mercury____Unify___gml__extra_operator_0_0_i1);
	MR_init_entry(mercury____Index___gml__extra_operator_0_0);
	MR_init_label(mercury____Index___gml__extra_operator_0_0_i4);
	MR_init_label(mercury____Index___gml__extra_operator_0_0_i5);
	MR_init_label(mercury____Index___gml__extra_operator_0_0_i6);
	MR_init_label(mercury____Index___gml__extra_operator_0_0_i7);
	MR_init_label(mercury____Index___gml__extra_operator_0_0_i8);
	MR_init_label(mercury____Index___gml__extra_operator_0_0_i9);
	MR_init_label(mercury____Index___gml__extra_operator_0_0_i10);
	MR_init_label(mercury____Index___gml__extra_operator_0_0_i11);
	MR_init_label(mercury____Index___gml__extra_operator_0_0_i12);
	MR_init_label(mercury____Index___gml__extra_operator_0_0_i13);
	MR_init_label(mercury____Index___gml__extra_operator_0_0_i14);
	MR_init_entry(mercury____Compare___gml__extra_operator_0_0);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i2);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i3);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i4);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i53);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i5);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i10);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i12);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i14);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i18);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i21);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i22);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i25);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i28);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i31);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i34);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i37);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i40);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i45);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i7);
	MR_init_label(mercury____Compare___gml__extra_operator_0_0_i51);
	MR_init_entry(mercury____Unify___gml__lexer_error_0_0);
	MR_init_label(mercury____Unify___gml__lexer_error_0_0_i1);
	MR_init_entry(mercury____Compare___gml__lexer_error_0_0);
	MR_init_label(mercury____Compare___gml__lexer_error_0_0_i4);
	MR_init_label(mercury____Compare___gml__lexer_error_0_0_i23);
	MR_init_label(mercury____Compare___gml__lexer_error_0_0_i3);
	MR_init_label(mercury____Compare___gml__lexer_error_0_0_i14);
	MR_init_entry(mercury____Unify___gml__parse_error_0_0);
	MR_init_entry(mercury____Compare___gml__parse_error_0_0);
	MR_init_label(mercury____Compare___gml__parse_error_0_0_i2);
	MR_init_label(mercury____Compare___gml__parse_error_0_0_i3);
	MR_init_entry(mercury____Unify___gml__gml_program_0_0);
	MR_init_entry(mercury____Compare___gml__gml_program_0_0);
	MR_init_entry(mercury____Unify___gml__token_list_0_0);
	MR_init_entry(mercury____Compare___gml__token_list_0_0);
	MR_init_entry(mercury____Unify___gml__token_group_0_0);
	MR_init_label(mercury____Unify___gml__token_group_0_0_i8);
	MR_init_label(mercury____Unify___gml__token_group_0_0_i4);
	MR_init_label(mercury____Unify___gml__token_group_0_0_i1);
	MR_init_entry(mercury____Compare___gml__token_group_0_0);
	MR_init_label(mercury____Compare___gml__token_group_0_0_i10);
	MR_init_label(mercury____Compare___gml__token_group_0_0_i4);
	MR_init_label(mercury____Compare___gml__token_group_0_0_i28);
	MR_init_label(mercury____Compare___gml__token_group_0_0_i9);
	MR_init_label(mercury____Compare___gml__token_group_0_0_i7);
	MR_init_entry(mercury____Unify___gml__stop_at_0_0);
	MR_init_entry(mercury____Compare___gml__stop_at_0_0);
	MR_init_label(mercury____Compare___gml__stop_at_0_0_i2);
	MR_init_label(mercury____Compare___gml__stop_at_0_0_i3);
MR_BEGIN_CODE

/* code for predicate 'builtin_compare_pred__ua0'/3 in mode 0 */
MR_define_static(mercury__gml__builtin_compare_pred__ua0_3_0);
	MR_incr_sp_push_msg(1, "private_builtin:builtin_compare_pred__ua0/3");
	MR_stackvar(1) = (MR_Word) MR_succip;
	MR_call_localret(MR_ENTRY(mercury__std_util__semidet_succeed_0_0),
		mercury__gml__builtin_compare_pred__ua0_3_0_i4,
		MR_STATIC(mercury__gml__builtin_compare_pred__ua0_3_0));
MR_define_label(mercury__gml__builtin_compare_pred__ua0_3_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__builtin_compare_pred__ua0_3_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__builtin_compare_pred__ua0_3_0_i3);
	}
	MR_r1 = (MR_Word) MR_string_const("attempted higher-order comparison", 33);
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_tailcall(MR_ENTRY(mercury__require__error_1_0),
		MR_STATIC(mercury__gml__builtin_compare_pred__ua0_3_0));
MR_define_label(mercury__gml__builtin_compare_pred__ua0_3_0_i3);
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
/* code for predicate 'builtin_unify_pred__ua0'/2 in mode 0 */
MR_define_static(mercury__gml__builtin_unify_pred__ua0_2_0);
	MR_incr_sp_push_msg(1, "private_builtin:builtin_unify_pred__ua0/2");
	MR_stackvar(1) = (MR_Word) MR_succip;
	MR_call_localret(MR_ENTRY(mercury__std_util__semidet_succeed_0_0),
		mercury__gml__builtin_unify_pred__ua0_2_0_i4,
		MR_STATIC(mercury__gml__builtin_unify_pred__ua0_2_0));
MR_define_label(mercury__gml__builtin_unify_pred__ua0_2_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__builtin_unify_pred__ua0_2_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__builtin_unify_pred__ua0_2_0_i3);
	}
	MR_r1 = (MR_Word) MR_string_const("attempted higher-order unification", 34);
	MR_call_localret(MR_ENTRY(mercury__require__error_1_0),
		mercury__gml__builtin_unify_pred__ua0_2_0_i9,
		MR_STATIC(mercury__gml__builtin_unify_pred__ua0_2_0));
MR_define_label(mercury__gml__builtin_unify_pred__ua0_2_0_i3);
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_tailcall(MR_ENTRY(mercury__std_util__semidet_succeed_0_0),
		MR_STATIC(mercury__gml__builtin_unify_pred__ua0_2_0));
MR_define_label(mercury__gml__builtin_unify_pred__ua0_2_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__builtin_unify_pred__ua0_2_0));
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_r1 = TRUE;
	MR_proceed();
/* code for predicate 'tokenize'/3 in mode 0 */
MR_define_entry(mercury__gml__tokenize_3_0);
	MR_incr_sp_push_msg(2, "gml:tokenize/3");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_localcall(mercury__gml__tokenize_2_4_0,
		MR_LABEL(mercury__gml__tokenize_3_0_i2),
		MR_ENTRY(mercury__gml__tokenize_3_0));
MR_define_label(mercury__gml__tokenize_3_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__tokenize_3_0));
	MR_stackvar(1) = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_basic_token_0;
	MR_r3 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_call_localret(MR_ENTRY(mercury__list__reverse_2_3_0),
		mercury__gml__tokenize_3_0_i3,
		MR_ENTRY(mercury__gml__tokenize_3_0));
MR_define_label(mercury__gml__tokenize_3_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__tokenize_3_0));
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate 'parse'/2 in mode 0 */
MR_define_entry(mercury__gml__parse_2_0);
	MR_incr_sp_push_msg(2, "gml:parse/2");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Integer) 0;
	MR_r3 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_localcall(mercury__gml__parse_2_5_0,
		MR_LABEL(mercury__gml__parse_2_0_i2),
		MR_ENTRY(mercury__gml__parse_2_0));
MR_define_label(mercury__gml__parse_2_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__parse_2_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__parse_2_0_i3);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_r3 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_tailcall(MR_ENTRY(mercury__list__reverse_2_3_0),
		MR_ENTRY(mercury__gml__parse_2_0));
MR_define_label(mercury__gml__parse_2_0_i3);
	MR_stackvar(1) = MR_r2;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_parse_error_0;
	MR_r2 = (MR_Word) MR_string_const("tokens left over at end of parse", 32);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__parse_2_0_i5,
		MR_ENTRY(mercury__gml__parse_2_0));
MR_define_label(mercury__gml__parse_2_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__parse_2_0));
	MR_r3 = MR_r2;
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_tailcall(MR_ENTRY(mercury__list__reverse_2_3_0),
		MR_ENTRY(mercury__gml__parse_2_0));
/* code for predicate 'tokenize_2'/4 in mode 0 */
MR_define_entry(mercury__gml__tokenize_2_4_0);
	MR_incr_sp_push_msg(2, "gml:tokenize_2/4");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__skip_whitespace_3_0,
		MR_LABEL(mercury__gml__tokenize_2_4_0_i2),
		MR_ENTRY(mercury__gml__tokenize_2_4_0));
MR_define_label(mercury__gml__tokenize_2_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__tokenize_2_4_0));
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__gml__tokenize_2_4_0_i5);
	}
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__gml__tokenize_2_4_0_i8);
	}
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
MR_define_label(mercury__gml__tokenize_2_4_0_i8);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__tokenize_2_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 3348 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r3 = LineNum;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__tokenize_2_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_stackvar(1) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__tokenize_2_4_0_i9,
		MR_ENTRY(mercury__gml__tokenize_2_4_0));
MR_define_label(mercury__gml__tokenize_2_4_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__tokenize_2_4_0));
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
MR_define_label(mercury__gml__tokenize_2_4_0_i5);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__gml__get_token_4_0,
		MR_LABEL(mercury__gml__tokenize_2_4_0_i6),
		MR_ENTRY(mercury__gml__tokenize_2_4_0));
MR_define_label(mercury__gml__tokenize_2_4_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__tokenize_2_4_0));
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(1), (MR_Integer) 2, mercury__gml__tokenize_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 1) = MR_stackvar(1);
	MR_r1 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__skip_whitespace_3_0,
		MR_LABEL(mercury__gml__tokenize_2_4_0_i2),
		MR_ENTRY(mercury__gml__tokenize_2_4_0));
/* code for predicate 'skip_whitespace'/3 in mode 0 */
MR_define_static(mercury__gml__skip_whitespace_3_0);
	MR_incr_sp_push_msg(1, "gml:skip_whitespace/3");
	MR_stackvar(1) = (MR_Word) MR_succip;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__skip_whitespace_3_0_i2),
		MR_STATIC(mercury__gml__skip_whitespace_3_0));
MR_define_label(mercury__gml__skip_whitespace_3_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__skip_whitespace_3_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__skip_whitespace_3_0_i4);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
MR_define_label(mercury__gml__skip_whitespace_3_0_i4);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	if (((MR_Integer) MR_r3 != (MR_Integer) 37)) {
		MR_GOTO_LABEL(mercury__gml__skip_whitespace_3_0_i5);
	}
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__skip_to_end_of_line_2_0,
		MR_LABEL(mercury__gml__skip_whitespace_3_0_i7),
		MR_STATIC(mercury__gml__skip_whitespace_3_0));
MR_define_label(mercury__gml__skip_whitespace_3_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__skip_whitespace_3_0));
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__skip_whitespace_3_0_i2),
		MR_STATIC(mercury__gml__skip_whitespace_3_0));
MR_define_label(mercury__gml__skip_whitespace_3_0_i5);
	if (((MR_Integer) MR_r3 != (MR_Integer) 9)) {
		MR_GOTO_LABEL(mercury__gml__skip_whitespace_3_0_i11);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(1);
	}
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__skip_whitespace_3_0_i2),
		MR_STATIC(mercury__gml__skip_whitespace_3_0));
MR_define_label(mercury__gml__skip_whitespace_3_0_i11);
	if (((MR_Integer) MR_r3 != (MR_Integer) 10)) {
		MR_GOTO_LABEL(mercury__gml__skip_whitespace_3_0_i12);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(1);
	}
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__skip_whitespace_3_0_i2),
		MR_STATIC(mercury__gml__skip_whitespace_3_0));
MR_define_label(mercury__gml__skip_whitespace_3_0_i12);
	if (((MR_Integer) MR_r3 != (MR_Integer) 11)) {
		MR_GOTO_LABEL(mercury__gml__skip_whitespace_3_0_i13);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(1);
	}
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__skip_whitespace_3_0_i2),
		MR_STATIC(mercury__gml__skip_whitespace_3_0));
MR_define_label(mercury__gml__skip_whitespace_3_0_i13);
	if (((MR_Integer) MR_r3 != (MR_Integer) 12)) {
		MR_GOTO_LABEL(mercury__gml__skip_whitespace_3_0_i14);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(1);
	}
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__skip_whitespace_3_0_i2),
		MR_STATIC(mercury__gml__skip_whitespace_3_0));
MR_define_label(mercury__gml__skip_whitespace_3_0_i14);
	if (((MR_Integer) MR_r3 != (MR_Integer) 13)) {
		MR_GOTO_LABEL(mercury__gml__skip_whitespace_3_0_i15);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(1);
	}
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__skip_whitespace_3_0_i2),
		MR_STATIC(mercury__gml__skip_whitespace_3_0));
MR_define_label(mercury__gml__skip_whitespace_3_0_i15);
	if (((MR_Integer) MR_r3 != (MR_Integer) 32)) {
		MR_GOTO_LABEL(mercury__gml__skip_whitespace_3_0_i3);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(1);
	}
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__skip_whitespace_3_0_i2),
		MR_STATIC(mercury__gml__skip_whitespace_3_0));
MR_define_label(mercury__gml__skip_whitespace_3_0_i3);
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
/* code for predicate 'skip_to_end_of_line'/2 in mode 0 */
MR_define_static(mercury__gml__skip_to_end_of_line_2_0);
	MR_incr_sp_push_msg(1, "gml:skip_to_end_of_line/2");
	MR_stackvar(1) = (MR_Word) MR_succip;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__skip_to_end_of_line_2_0_i2),
		MR_STATIC(mercury__gml__skip_to_end_of_line_2_0));
MR_define_label(mercury__gml__skip_to_end_of_line_2_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__skip_to_end_of_line_2_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__skip_to_end_of_line_2_0_i4);
	}
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
MR_define_label(mercury__gml__skip_to_end_of_line_2_0_i4);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	if (((MR_Integer) MR_r3 != (MR_Integer) 10)) {
		MR_GOTO_LABEL(mercury__gml__skip_to_end_of_line_2_0_i5);
	}
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
MR_define_label(mercury__gml__skip_to_end_of_line_2_0_i5);
	if (((MR_Integer) MR_r3 != (MR_Integer) 11)) {
		MR_GOTO_LABEL(mercury__gml__skip_to_end_of_line_2_0_i7);
	}
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
MR_define_label(mercury__gml__skip_to_end_of_line_2_0_i7);
	if (((MR_Integer) MR_r3 != (MR_Integer) 12)) {
		MR_GOTO_LABEL(mercury__gml__skip_to_end_of_line_2_0_i9);
	}
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
MR_define_label(mercury__gml__skip_to_end_of_line_2_0_i9);
	if (((MR_Integer) MR_r3 != (MR_Integer) 13)) {
		MR_GOTO_LABEL(mercury__gml__skip_to_end_of_line_2_0_i11);
	}
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
MR_define_label(mercury__gml__skip_to_end_of_line_2_0_i11);
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__skip_to_end_of_line_2_0_i2),
		MR_STATIC(mercury__gml__skip_to_end_of_line_2_0));
/* code for predicate 'get_token'/4 in mode 0 */
MR_define_static(mercury__gml__get_token_4_0);
	MR_incr_sp_push_msg(3, "gml:get_token/4");
	MR_stackvar(3) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r1 != (MR_Integer) 91)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i4);
	}
	MR_stackvar(1) = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__gml__get_token_4_0_i4);
	if (((MR_Integer) MR_r1 != (MR_Integer) 93)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i5);
	}
	MR_stackvar(1) = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 1));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__gml__get_token_4_0_i5);
	if (((MR_Integer) MR_r1 != (MR_Integer) 123)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i6);
	}
	MR_stackvar(1) = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 2));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__gml__get_token_4_0_i6);
	if (((MR_Integer) MR_r1 != (MR_Integer) 125)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i2);
	}
	MR_stackvar(1) = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 3));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__gml__get_token_4_0_i2);
	if (((MR_Integer) MR_r1 != (MR_Integer) 34)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i8);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_localcall(mercury__gml__get_string_4_0,
		MR_LABEL(mercury__gml__get_token_4_0_i10),
		MR_STATIC(mercury__gml__get_token_4_0));
MR_define_label(mercury__gml__get_token_4_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_token_4_0));
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(3), (MR_Integer) 2, mercury__gml__get_token_4_0, "gml:token/0");
	MR_field(MR_mktag(3), MR_r3, (MR_Integer) 0) = (MR_Integer) 2;
	MR_field(MR_mktag(3), MR_r3, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__gml__get_token_4_0, "gml:basic_token/0");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__gml__get_token_4_0_i8);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__char__is_alpha_1_0),
		mercury__gml__get_token_4_0_i13,
		MR_STATIC(mercury__gml__get_token_4_0));
MR_define_label(mercury__gml__get_token_4_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_token_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i11);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_token_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r2 = MR_stackvar(2);
	MR_localcall(mercury__gml__get_identifier_4_0,
		MR_LABEL(mercury__gml__get_token_4_0_i15),
		MR_STATIC(mercury__gml__get_token_4_0));
MR_define_label(mercury__gml__get_token_4_0_i15);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_token_4_0));
	if ((strcmp((char *)MR_r1, (char *)(MR_Word) MR_string_const("true", 4)) != 0)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i16);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__gml__get_token_4_0_i16);
	if ((strcmp((char *)MR_r1, (char *)(MR_Word) MR_string_const("false", 5)) != 0)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i18);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_3);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__gml__get_token_4_0_i18);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__gml__is_operator_2_0,
		MR_LABEL(mercury__gml__get_token_4_0_i22),
		MR_STATIC(mercury__gml__get_token_4_0));
MR_define_label(mercury__gml__get_token_4_0_i22);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_token_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i20);
	}
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(0), (MR_Integer) 1, mercury__gml__get_token_4_0, "gml:token/0");
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 0) = MR_r2;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__gml__get_token_4_0, "gml:basic_token/0");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r3;
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__gml__get_token_4_0_i20);
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(2);
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(1), (MR_Integer) 1, mercury__gml__get_token_4_0, "gml:token/0");
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 0) = MR_r1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__gml__get_token_4_0, "gml:basic_token/0");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__gml__get_token_4_0_i11);
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	if (((MR_Integer) MR_r1 != (MR_Integer) 47)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i27);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_localcall(mercury__gml__get_identifier_4_0,
		MR_LABEL(mercury__gml__get_token_4_0_i29),
		MR_STATIC(mercury__gml__get_token_4_0));
MR_define_label(mercury__gml__get_token_4_0_i29);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_token_4_0));
	if ((strcmp((char *)MR_r1, (char *)(MR_Word) MR_string_const("false", 5)) != 0)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i35);
	}
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r1;
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_token_4_0
	IO0 = MR_stackvar(1);
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 3711 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r3 = LineNum;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_token_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_4);
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_token_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = (MR_Word) MR_string_const("attempt to rebind operator `", 28);
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = MR_r5;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_token_4_0
	Strs = MR_r6;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 3758 "gml.c"
	MR_r5 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_token_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r5;
	MR_stackvar(1) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_token_4_0_i49,
		MR_STATIC(mercury__gml__get_token_4_0));
MR_define_label(mercury__gml__get_token_4_0_i35);
	if ((strcmp((char *)MR_r1, (char *)(MR_Word) MR_string_const("true", 4)) != 0)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i33);
	}
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r1;
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_token_4_0
	IO0 = MR_stackvar(1);
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 3790 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r3 = LineNum;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_token_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_4);
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_token_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = (MR_Word) MR_string_const("attempt to rebind operator `", 28);
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = MR_r5;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_token_4_0
	Strs = MR_r6;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 3837 "gml.c"
	MR_r5 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_token_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r5;
	MR_stackvar(1) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_token_4_0_i49,
		MR_STATIC(mercury__gml__get_token_4_0));
MR_define_label(mercury__gml__get_token_4_0_i33);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__gml__is_operator_2_0,
		MR_LABEL(mercury__gml__get_token_4_0_i37),
		MR_STATIC(mercury__gml__get_token_4_0));
MR_define_label(mercury__gml__get_token_4_0_i37);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_token_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i30);
	}
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_token_4_0
	IO0 = MR_stackvar(1);
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 3874 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r3 = LineNum;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_token_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_4);
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_token_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = (MR_Word) MR_string_const("attempt to rebind operator `", 28);
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = MR_r5;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_token_4_0
	Strs = MR_r6;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 3921 "gml.c"
	MR_r5 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_token_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r5;
	MR_stackvar(1) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_token_4_0_i49,
		MR_STATIC(mercury__gml__get_token_4_0));
MR_define_label(mercury__gml__get_token_4_0_i30);
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(2);
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(2), (MR_Integer) 1, mercury__gml__get_token_4_0, "gml:token/0");
	MR_field(MR_mktag(2), MR_r3, (MR_Integer) 0) = MR_r1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__gml__get_token_4_0, "gml:basic_token/0");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__gml__get_token_4_0_i27);
	if (((MR_Integer) MR_r1 != (MR_Integer) 45)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i41);
	}
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_token_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r1 = MR_r3;
	MR_localcall(mercury__gml__get_number_4_0,
		MR_LABEL(mercury__gml__get_token_4_0_i48),
		MR_STATIC(mercury__gml__get_token_4_0));
MR_define_label(mercury__gml__get_token_4_0_i41);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__char__is_digit_1_0),
		mercury__gml__get_token_4_0_i46,
		MR_STATIC(mercury__gml__get_token_4_0));
MR_define_label(mercury__gml__get_token_4_0_i46);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_token_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_token_4_0_i44);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_token_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r2 = MR_stackvar(2);
	MR_localcall(mercury__gml__get_number_4_0,
		MR_LABEL(mercury__gml__get_token_4_0_i48),
		MR_STATIC(mercury__gml__get_token_4_0));
MR_define_label(mercury__gml__get_token_4_0_i48);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_token_4_0));
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(3), (MR_Integer) 2, mercury__gml__get_token_4_0, "gml:token/0");
	MR_field(MR_mktag(3), MR_r3, (MR_Integer) 0) = (MR_Integer) 1;
	MR_field(MR_mktag(3), MR_r3, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__gml__get_token_4_0, "gml:basic_token/0");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__gml__get_token_4_0_i44);
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_token_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 3999 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r3 = LineNum;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_token_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	{
	MR_String	Str;
	MR_Word	CharList;
#define	MR_PROC_LABEL	mercury__gml__get_token_4_0
	CharList = MR_r5;
{
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
		/* mode (out, in) is det */
	MR_Word char_list_ptr;
	size_t size;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `char_list_ptr'
*/
	size = sizeof(MR_Word);
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		size++;
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** loop to copy the characters from the char_list to the string
*/
	size = 0;
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		Str[size++] = MR_list_head(char_list_ptr);
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** null terminate the string
*/
	Str[size] = '\0';
};}
#line 4050 "gml.c"
	MR_r5 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_token_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = MR_r5;
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_6);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_token_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = (MR_Word) MR_string_const("unexpected character `", 22);
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = MR_r6;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_token_4_0
	Strs = MR_r5;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 4095 "gml.c"
	MR_r5 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_token_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r5;
	MR_stackvar(1) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_token_4_0_i49,
		MR_STATIC(mercury__gml__get_token_4_0));
MR_define_label(mercury__gml__get_token_4_0_i49);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_token_4_0));
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate 'is_operator'/2 in mode 0 */
MR_define_static(mercury__gml__is_operator_2_0);
	MR_r3 = (MR_hash_string(MR_r1) & (MR_Integer) 127);
MR_define_label(mercury__gml__is_operator_2_0_i3);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = (MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_gml__common_7))[(MR_Integer) MR_r3];
	if (((MR_Integer) MR_tempr1 && (strcmp((char *)MR_tempr1, (char *)MR_r1) == 0))) {
		MR_GOTO_LABEL(mercury__gml__is_operator_2_0_i5);
	}
	MR_r3 = (MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_gml__common_8))[(MR_Integer) MR_r3];
	if (((MR_Integer) MR_r3 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__gml__is_operator_2_0_i3);
	}
	}
MR_define_label(mercury__gml__is_operator_2_0_i57);
	MR_r1 = FALSE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i5);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_r3,
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i6) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i7) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i8) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i9) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i10) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i11) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i12) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i13) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i14) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i15) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i16) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i17) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i18) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i19) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i20) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i21) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i22) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i23) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i24) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i25) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i26) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i27) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i28) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i29) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i30) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i31) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i32) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i33) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i34) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i35) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i36) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i37) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i38) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i39) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i40) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i41) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i42) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i43) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i44) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i45) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i46) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i47) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i48) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i49) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i50) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i51) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i52) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i53) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i54) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i55) MR_AND
		MR_LABEL(mercury__gml__is_operator_2_0_i57));
MR_define_label(mercury__gml__is_operator_2_0_i6);
	MR_r2 = (MR_Integer) 15;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i7);
	MR_r2 = (MR_Integer) 2;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i8);
	MR_r2 = (MR_Integer) 1;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i9);
	MR_r2 = (MR_Integer) 39;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i10);
	MR_r2 = (MR_Integer) 11;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i11);
	MR_r2 = (MR_Integer) 37;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i12);
	MR_r2 = (MR_Integer) 38;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i13);
	MR_r2 = (MR_Integer) 0;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i14);
	MR_r2 = (MR_Integer) 9;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i15);
	MR_r2 = (MR_Integer) 22;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i16);
	MR_r2 = (MR_Integer) 4;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i17);
	MR_r2 = (MR_Integer) 34;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i18);
	MR_r2 = (MR_Integer) 7;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i19);
	MR_r2 = (MR_Integer) 40;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i20);
	MR_r2 = (MR_Integer) 44;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i21);
	MR_r2 = (MR_Integer) 30;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i22);
	MR_r2 = (MR_Integer) 6;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i23);
	MR_r2 = (MR_Integer) 24;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i24);
	MR_r2 = (MR_Integer) 46;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i25);
	MR_r2 = (MR_Integer) 45;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i26);
	MR_r2 = (MR_Integer) 25;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i27);
	MR_r2 = (MR_Integer) 27;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i28);
	MR_r2 = (MR_Integer) 36;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i29);
	MR_r2 = (MR_Integer) 21;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i30);
	MR_r2 = (MR_Integer) 31;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i31);
	MR_r2 = (MR_Integer) 32;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i32);
	MR_r2 = (MR_Integer) 8;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i33);
	MR_r2 = (MR_Integer) 29;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i34);
	MR_r2 = (MR_Integer) 28;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i35);
	MR_r2 = (MR_Integer) 10;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i36);
	MR_r2 = (MR_Integer) 42;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i37);
	MR_r2 = (MR_Integer) 33;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i38);
	MR_r2 = (MR_Integer) 49;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i39);
	MR_r2 = (MR_Integer) 43;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i40);
	MR_r2 = (MR_Integer) 14;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i41);
	MR_r2 = (MR_Integer) 5;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i42);
	MR_r2 = (MR_Integer) 17;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i43);
	MR_r2 = (MR_Integer) 48;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i44);
	MR_r2 = (MR_Integer) 41;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i45);
	MR_r2 = (MR_Integer) 12;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i46);
	MR_r2 = (MR_Integer) 23;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i47);
	MR_r2 = (MR_Integer) 26;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i48);
	MR_r2 = (MR_Integer) 13;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i49);
	MR_r2 = (MR_Integer) 20;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i50);
	MR_r2 = (MR_Integer) 18;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i51);
	MR_r2 = (MR_Integer) 19;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i52);
	MR_r2 = (MR_Integer) 47;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i53);
	MR_r2 = (MR_Integer) 3;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i54);
	MR_r2 = (MR_Integer) 16;
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__gml__is_operator_2_0_i55);
	MR_r2 = (MR_Integer) 35;
	MR_r1 = TRUE;
	MR_proceed();
/* code for predicate 'get_identifier'/4 in mode 0 */
MR_define_static(mercury__gml__get_identifier_4_0);
	MR_incr_sp_push_msg(4, "gml:get_identifier/4");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_identifier_4_0_i2),
		MR_STATIC(mercury__gml__get_identifier_4_0));
MR_define_label(mercury__gml__get_identifier_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_identifier_4_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__get_identifier_4_0_i4);
	}
	{
	MR_Word	Chars;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_identifier_4_0
	Chars = MR_stackvar(1);
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
};}
#line 4520 "gml.c"
	MR_r1 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__get_identifier_4_0_i4);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r2;
	MR_r1 = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__char__is_alnum_or_underscore_1_0),
		mercury__gml__get_identifier_4_0_i10,
		MR_STATIC(mercury__gml__get_identifier_4_0));
MR_define_label(mercury__gml__get_identifier_4_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_identifier_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_identifier_4_0_i8);
	}
	MR_r2 = MR_stackvar(3);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_identifier_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_identifier_4_0_i2),
		MR_STATIC(mercury__gml__get_identifier_4_0));
MR_define_label(mercury__gml__get_identifier_4_0_i8);
	MR_r3 = MR_stackvar(2);
	MR_r2 = MR_stackvar(3);
	if (((MR_Integer) MR_r3 != (MR_Integer) 45)) {
		MR_GOTO_LABEL(mercury__gml__get_identifier_4_0_i6);
	}
	MR_stackvar(2) = MR_r3;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_identifier_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_identifier_4_0_i2),
		MR_STATIC(mercury__gml__get_identifier_4_0));
MR_define_label(mercury__gml__get_identifier_4_0_i6);
	{
	MR_Word	Stream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_identifier_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("input_stream");
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);
;}
#line 4581 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("input_stream");
	MR_r4 = Stream;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	File;
	MR_Char	Character;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_identifier_4_0
	File = MR_r4;
	Character = MR_r3;
	IO0 = MR_r5;
	MR_save_registers();
	MR_OBTAIN_GLOBAL_LOCK("putback_char");
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
};}
#line 4612 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("putback_char");
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	Chars;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_identifier_4_0
	Chars = MR_stackvar(1);
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
};}
#line 4665 "gml.c"
	MR_r1 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate 'get_string'/4 in mode 0 */
MR_define_static(mercury__gml__get_string_4_0);
	MR_incr_sp_push_msg(4, "gml:get_string/4");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_string_4_0_i2),
		MR_STATIC(mercury__gml__get_string_4_0));
MR_define_label(mercury__gml__get_string_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_string_4_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__get_string_4_0_i4);
	}
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_string_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 4700 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r3 = LineNum;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(1) = MR_r4;
	MR_stackvar(2) = MR_r3;
	MR_r1 = (MR_Word) MR_string_const("unexpected end-of-file in ", 26);
	MR_r2 = (MR_Word) MR_string_const("string constant", 15);
	MR_call_localret(MR_ENTRY(mercury__string__append_3_2),
		mercury__gml__get_string_4_0_i5,
		MR_STATIC(mercury__gml__get_string_4_0));
MR_define_label(mercury__gml__get_string_4_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_string_4_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_string_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_string_4_0_i18,
		MR_STATIC(mercury__gml__get_string_4_0));
MR_define_label(mercury__gml__get_string_4_0_i4);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	if (((MR_Integer) MR_stackvar(2) != (MR_Integer) 34)) {
		MR_GOTO_LABEL(mercury__gml__get_string_4_0_i7);
	}
	{
	MR_Word	Chars;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_string_4_0
	Chars = MR_stackvar(1);
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
};}
#line 4772 "gml.c"
	MR_r1 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__get_string_4_0_i7);
	MR_stackvar(3) = MR_r2;
	MR_r1 = MR_stackvar(2);
	MR_call_localret(MR_ENTRY(mercury__char__is_alnum_or_underscore_1_0),
		mercury__gml__get_string_4_0_i14,
		MR_STATIC(mercury__gml__get_string_4_0));
MR_define_label(mercury__gml__get_string_4_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_string_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_string_4_0_i12);
	}
	MR_r2 = MR_stackvar(3);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_string_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_string_4_0_i2),
		MR_STATIC(mercury__gml__get_string_4_0));
MR_define_label(mercury__gml__get_string_4_0_i12);
	MR_r2 = MR_stackvar(3);
	if (!(((MR_Unsigned) ((MR_Integer) MR_stackvar(2) - (MR_Integer) 32) <= (MR_Unsigned) (MR_Integer) 94))) {
		MR_GOTO_LABEL(mercury__gml__get_string_4_0_i10);
	}
	if (!((((MR_Integer) 1 << (((MR_Integer) MR_stackvar(2) - (MR_Integer) 32) & (MR_Integer) 31)) & (MR_Integer) MR_const_field(MR_mktag(0), MR_mkword(MR_mktag(0), &mercury_const_36), (((MR_Integer) MR_stackvar(2) - (MR_Integer) 32) >> (MR_Integer) 5))))) {
		MR_GOTO_LABEL(mercury__gml__get_string_4_0_i10);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_string_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_string_4_0_i2),
		MR_STATIC(mercury__gml__get_string_4_0));
MR_define_label(mercury__gml__get_string_4_0_i10);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_string_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 4832 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r3 = LineNum;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_string_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	{
	MR_String	Str;
	MR_Word	CharList;
#define	MR_PROC_LABEL	mercury__gml__get_string_4_0
	CharList = MR_r5;
{
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
		/* mode (out, in) is det */
	MR_Word char_list_ptr;
	size_t size;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `char_list_ptr'
*/
	size = sizeof(MR_Word);
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		size++;
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** loop to copy the characters from the char_list to the string
*/
	size = 0;
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		Str[size++] = MR_list_head(char_list_ptr);
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** null terminate the string
*/
	Str[size] = '\0';
};}
#line 4883 "gml.c"
	MR_r5 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_string_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = MR_r5;
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_10);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_string_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = (MR_Word) MR_string_const("unexpected character `", 22);
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = MR_r6;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_string_4_0
	Strs = MR_r5;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 4928 "gml.c"
	MR_r5 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_string_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r5;
	MR_stackvar(1) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_string_4_0_i18,
		MR_STATIC(mercury__gml__get_string_4_0));
MR_define_label(mercury__gml__get_string_4_0_i18);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_string_4_0));
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate 'get_number'/4 in mode 0 */
MR_define_static(mercury__gml__get_number_4_0);
	MR_incr_sp_push_msg(4, "gml:get_number/4");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_number_4_0_i2),
		MR_STATIC(mercury__gml__get_number_4_0));
MR_define_label(mercury__gml__get_number_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_number_4_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__get_number_4_0_i4);
	}
	{
	MR_Word	Chars;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_number_4_0
	Chars = MR_stackvar(1);
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
};}
#line 5005 "gml.c"
	MR_r3 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(3) = MR_r2;
	MR_stackvar(1) = MR_r3;
	MR_r1 = (MR_Integer) 10;
	MR_r2 = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__string__base_string_to_int_3_0),
		mercury__gml__get_number_4_0_i6,
		MR_STATIC(mercury__gml__get_number_4_0));
MR_define_label(mercury__gml__get_number_4_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_number_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_number_4_0_i5);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 1, mercury__gml__get_number_4_0, "gml:number/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r2;
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__get_number_4_0_i5);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_number_4_0
	IO0 = MR_stackvar(3);
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 5042 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r3 = LineNum;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_number_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_4);
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_number_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = (MR_Word) MR_string_const("invalid int token `", 19);
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = MR_r5;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_number_4_0
	Strs = MR_r6;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 5089 "gml.c"
	MR_r5 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_number_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r5;
	MR_stackvar(1) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_number_4_0_i26,
		MR_STATIC(mercury__gml__get_number_4_0));
MR_define_label(mercury__gml__get_number_4_0_i4);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r2;
	MR_r1 = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__char__is_digit_1_0),
		mercury__gml__get_number_4_0_i12,
		MR_STATIC(mercury__gml__get_number_4_0));
MR_define_label(mercury__gml__get_number_4_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_number_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_number_4_0_i10);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_number_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_number_4_0_i2),
		MR_STATIC(mercury__gml__get_number_4_0));
MR_define_label(mercury__gml__get_number_4_0_i10);
	MR_r3 = MR_stackvar(2);
	MR_r2 = MR_stackvar(3);
	if (((MR_Integer) MR_r3 != (MR_Integer) 46)) {
		MR_GOTO_LABEL(mercury__gml__get_number_4_0_i15);
	}
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__gml__get_int_dot_4_0,
		MR_STATIC(mercury__gml__get_number_4_0));
MR_define_label(mercury__gml__get_number_4_0_i15);
	if (((MR_Integer) MR_r3 != (MR_Integer) 69)) {
		MR_GOTO_LABEL(mercury__gml__get_number_4_0_i20);
	}
	MR_stackvar(2) = MR_r3;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_number_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__gml__get_float_exponent_4_0,
		MR_STATIC(mercury__gml__get_number_4_0));
MR_define_label(mercury__gml__get_number_4_0_i20);
	if (((MR_Integer) MR_r3 != (MR_Integer) 101)) {
		MR_GOTO_LABEL(mercury__gml__get_number_4_0_i18);
	}
	MR_stackvar(2) = MR_r3;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_number_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__gml__get_float_exponent_4_0,
		MR_STATIC(mercury__gml__get_number_4_0));
MR_define_label(mercury__gml__get_number_4_0_i18);
	{
	MR_Word	Stream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_number_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("input_stream");
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);
;}
#line 5174 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("input_stream");
	MR_r4 = Stream;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	File;
	MR_Char	Character;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_number_4_0
	File = MR_r4;
	Character = MR_r3;
	IO0 = MR_r5;
	MR_save_registers();
	MR_OBTAIN_GLOBAL_LOCK("putback_char");
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
};}
#line 5205 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("putback_char");
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	Chars;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_number_4_0
	Chars = MR_stackvar(1);
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
};}
#line 5258 "gml.c"
	MR_r2 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(1) = MR_r3;
	MR_stackvar(2) = MR_r2;
	MR_r1 = (MR_Integer) 10;
	MR_call_localret(MR_ENTRY(mercury__string__base_string_to_int_3_0),
		mercury__gml__get_number_4_0_i24,
		MR_STATIC(mercury__gml__get_number_4_0));
MR_define_label(mercury__gml__get_number_4_0_i24);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_number_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_number_4_0_i23);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 1, mercury__gml__get_number_4_0, "gml:number/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r2;
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__get_number_4_0_i23);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_number_4_0
	IO0 = MR_stackvar(1);
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 5294 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r3 = LineNum;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_number_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_4);
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_number_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = (MR_Word) MR_string_const("invalid int token `", 19);
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = MR_r5;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_number_4_0
	Strs = MR_r6;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 5341 "gml.c"
	MR_r5 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_number_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r5;
	MR_stackvar(1) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_number_4_0_i26,
		MR_STATIC(mercury__gml__get_number_4_0));
MR_define_label(mercury__gml__get_number_4_0_i26);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_number_4_0));
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate 'get_int_dot'/4 in mode 0 */
MR_define_static(mercury__gml__get_int_dot_4_0);
	MR_incr_sp_push_msg(4, "gml:get_int_dot/4");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_int_dot_4_0_i2),
		MR_STATIC(mercury__gml__get_int_dot_4_0));
MR_define_label(mercury__gml__get_int_dot_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_int_dot_4_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__get_int_dot_4_0_i4);
	}
	{
	MR_Word	Stream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_int_dot_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("input_stream");
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);
;}
#line 5387 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("input_stream");
	MR_r3 = Stream;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	File;
	MR_Char	Character;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_int_dot_4_0
	File = MR_r3;
	Character = (MR_Integer) 46;
	IO0 = MR_r4;
	MR_save_registers();
	MR_OBTAIN_GLOBAL_LOCK("putback_char");
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
};}
#line 5418 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("putback_char");
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	Chars;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_int_dot_4_0
	Chars = MR_stackvar(1);
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
};}
#line 5471 "gml.c"
	MR_r2 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(1) = MR_r3;
	MR_stackvar(2) = MR_r2;
	MR_r1 = (MR_Integer) 10;
	MR_call_localret(MR_ENTRY(mercury__string__base_string_to_int_3_0),
		mercury__gml__get_int_dot_4_0_i6,
		MR_STATIC(mercury__gml__get_int_dot_4_0));
MR_define_label(mercury__gml__get_int_dot_4_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_int_dot_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_int_dot_4_0_i5);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 1, mercury__gml__get_int_dot_4_0, "gml:number/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r2;
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__get_int_dot_4_0_i5);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_int_dot_4_0
	IO0 = MR_stackvar(1);
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 5507 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r3 = LineNum;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_int_dot_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_4);
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_int_dot_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = (MR_Word) MR_string_const("invalid int token `", 19);
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = MR_r5;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_int_dot_4_0
	Strs = MR_r6;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 5554 "gml.c"
	MR_r5 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_int_dot_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r5;
	MR_stackvar(1) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_int_dot_4_0_i8,
		MR_STATIC(mercury__gml__get_int_dot_4_0));
MR_define_label(mercury__gml__get_int_dot_4_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_int_dot_4_0));
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__get_int_dot_4_0_i4);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r2;
	MR_r1 = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__char__is_digit_1_0),
		mercury__gml__get_int_dot_4_0_i12,
		MR_STATIC(mercury__gml__get_int_dot_4_0));
MR_define_label(mercury__gml__get_int_dot_4_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_int_dot_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_int_dot_4_0_i10);
	}
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_int_dot_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 0) = (MR_Integer) 46;
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 1) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_int_dot_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_r3;
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__gml__get_float_decimals_4_0,
		MR_STATIC(mercury__gml__get_int_dot_4_0));
MR_define_label(mercury__gml__get_int_dot_4_0_i10);
	MR_r3 = MR_stackvar(2);
	MR_r2 = MR_stackvar(3);
	{
	MR_Word	Stream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_int_dot_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("input_stream");
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);
;}
#line 5613 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("input_stream");
	MR_r4 = Stream;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	File;
	MR_Char	Character;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_int_dot_4_0
	File = MR_r4;
	Character = MR_r3;
	IO0 = MR_r5;
	MR_save_registers();
	MR_OBTAIN_GLOBAL_LOCK("putback_char");
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
};}
#line 5644 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("putback_char");
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	Stream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_int_dot_4_0
	IO0 = MR_r4;
	MR_OBTAIN_GLOBAL_LOCK("input_stream");
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);
;}
#line 5666 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("input_stream");
	MR_r4 = Stream;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	File;
	MR_Char	Character;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_int_dot_4_0
	File = MR_r4;
	Character = (MR_Integer) 46;
	IO0 = MR_r5;
	MR_save_registers();
	MR_OBTAIN_GLOBAL_LOCK("putback_char");
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
};}
#line 5697 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("putback_char");
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = (MR_Integer) 10;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__gml__rev_char_list_to_int_5_0,
		MR_STATIC(mercury__gml__get_int_dot_4_0));
/* code for predicate 'get_float_decimals'/4 in mode 0 */
MR_define_static(mercury__gml__get_float_decimals_4_0);
	MR_incr_sp_push_msg(4, "gml:get_float_decimals/4");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_float_decimals_4_0_i2),
		MR_STATIC(mercury__gml__get_float_decimals_4_0));
MR_define_label(mercury__gml__get_float_decimals_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_float_decimals_4_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__get_float_decimals_4_0_i4);
	}
	{
	MR_Word	Chars;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_float_decimals_4_0
	Chars = MR_stackvar(1);
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
};}
#line 5770 "gml.c"
	MR_r3 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	{
	MR_String	FloatString;
	MR_Float	FloatVal;
#define	MR_PROC_LABEL	mercury__gml__get_float_decimals_4_0
	FloatString = (MR_String) MR_r3;
{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	/* use a temporary, since we can't don't know whether FloatVal
	   is a double or float */
	double tmp;
	SUCCESS_INDICATOR = (sscanf(FloatString, "%lf", &tmp) == 1);
		/* TRUE if sscanf succeeds, FALSE otherwise */
	FloatVal = tmp;
};}
#line 5790 "gml.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__gml__get_float_decimals_4_0_i7);
	MR_r4 = MR_float_to_word(FloatVal);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__gml__get_float_decimals_4_0, "gml:number/0");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__get_float_decimals_4_0_i7);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_float_decimals_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 5815 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r4 = LineNum;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_decimals_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_4);
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_decimals_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 0) = (MR_Word) MR_string_const("invalid float token `", 21);
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 1) = MR_r6;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_float_decimals_4_0
	Strs = MR_r3;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 5862 "gml.c"
	MR_r3 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_float_decimals_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r3;
	MR_stackvar(1) = MR_r5;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_float_decimals_4_0_i25,
		MR_STATIC(mercury__gml__get_float_decimals_4_0));
MR_define_label(mercury__gml__get_float_decimals_4_0_i4);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r2;
	MR_r1 = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__char__is_digit_1_0),
		mercury__gml__get_float_decimals_4_0_i13,
		MR_STATIC(mercury__gml__get_float_decimals_4_0));
MR_define_label(mercury__gml__get_float_decimals_4_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_float_decimals_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_float_decimals_4_0_i11);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_decimals_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_float_decimals_4_0_i2),
		MR_STATIC(mercury__gml__get_float_decimals_4_0));
MR_define_label(mercury__gml__get_float_decimals_4_0_i11);
	MR_r3 = MR_stackvar(2);
	MR_r2 = MR_stackvar(3);
	if (((MR_Integer) MR_r3 != (MR_Integer) 69)) {
		MR_GOTO_LABEL(mercury__gml__get_float_decimals_4_0_i18);
	}
	MR_stackvar(2) = MR_r3;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_decimals_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__gml__get_float_exponent_4_0,
		MR_STATIC(mercury__gml__get_float_decimals_4_0));
MR_define_label(mercury__gml__get_float_decimals_4_0_i18);
	if (((MR_Integer) MR_r3 != (MR_Integer) 101)) {
		MR_GOTO_LABEL(mercury__gml__get_float_decimals_4_0_i16);
	}
	MR_stackvar(2) = MR_r3;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_decimals_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__gml__get_float_exponent_4_0,
		MR_STATIC(mercury__gml__get_float_decimals_4_0));
MR_define_label(mercury__gml__get_float_decimals_4_0_i16);
	{
	MR_Word	Stream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_float_decimals_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("input_stream");
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);
;}
#line 5938 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("input_stream");
	MR_r4 = Stream;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	File;
	MR_Char	Character;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_float_decimals_4_0
	File = MR_r4;
	Character = MR_r3;
	IO0 = MR_r5;
	MR_save_registers();
	MR_OBTAIN_GLOBAL_LOCK("putback_char");
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
};}
#line 5969 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("putback_char");
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	Chars;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_float_decimals_4_0
	Chars = MR_stackvar(1);
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
};}
#line 6022 "gml.c"
	MR_r3 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	{
	MR_String	FloatString;
	MR_Float	FloatVal;
#define	MR_PROC_LABEL	mercury__gml__get_float_decimals_4_0
	FloatString = (MR_String) MR_r3;
{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	/* use a temporary, since we can't don't know whether FloatVal
	   is a double or float */
	double tmp;
	SUCCESS_INDICATOR = (sscanf(FloatString, "%lf", &tmp) == 1);
		/* TRUE if sscanf succeeds, FALSE otherwise */
	FloatVal = tmp;
};}
#line 6042 "gml.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__gml__get_float_decimals_4_0_i23);
	MR_r4 = MR_float_to_word(FloatVal);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__gml__get_float_decimals_4_0, "gml:number/0");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__get_float_decimals_4_0_i23);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_float_decimals_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 6067 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r4 = LineNum;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_decimals_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_4);
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_decimals_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 0) = (MR_Word) MR_string_const("invalid float token `", 21);
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 1) = MR_r6;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_float_decimals_4_0
	Strs = MR_r3;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 6114 "gml.c"
	MR_r3 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_float_decimals_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r3;
	MR_stackvar(1) = MR_r5;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_float_decimals_4_0_i25,
		MR_STATIC(mercury__gml__get_float_decimals_4_0));
MR_define_label(mercury__gml__get_float_decimals_4_0_i25);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_float_decimals_4_0));
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate 'get_float_exponent'/4 in mode 0 */
MR_define_static(mercury__gml__get_float_exponent_4_0);
	MR_incr_sp_push_msg(4, "gml:get_float_exponent/4");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_float_exponent_4_0_i2),
		MR_STATIC(mercury__gml__get_float_exponent_4_0));
MR_define_label(mercury__gml__get_float_exponent_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_float_exponent_4_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__get_float_exponent_4_0_i4);
	}
	{
	MR_Word	Chars;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_4_0
	Chars = MR_stackvar(1);
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
};}
#line 6191 "gml.c"
	MR_r3 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	{
	MR_String	FloatString;
	MR_Float	FloatVal;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_4_0
	FloatString = (MR_String) MR_r3;
{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	/* use a temporary, since we can't don't know whether FloatVal
	   is a double or float */
	double tmp;
	SUCCESS_INDICATOR = (sscanf(FloatString, "%lf", &tmp) == 1);
		/* TRUE if sscanf succeeds, FALSE otherwise */
	FloatVal = tmp;
};}
#line 6211 "gml.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__gml__get_float_exponent_4_0_i7);
	MR_r4 = MR_float_to_word(FloatVal);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__gml__get_float_exponent_4_0, "gml:number/0");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__get_float_exponent_4_0_i7);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 6236 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r4 = LineNum;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_4);
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 0) = (MR_Word) MR_string_const("invalid float token `", 21);
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 1) = MR_r6;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_4_0
	Strs = MR_r3;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 6283 "gml.c"
	MR_r3 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_float_exponent_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r3;
	MR_stackvar(1) = MR_r5;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_float_exponent_4_0_i19,
		MR_STATIC(mercury__gml__get_float_exponent_4_0));
MR_define_label(mercury__gml__get_float_exponent_4_0_i4);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	if (((MR_Integer) MR_stackvar(2) != (MR_Integer) 45)) {
		MR_GOTO_LABEL(mercury__gml__get_float_exponent_4_0_i11);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__gml__get_float_exponent_2_4_0,
		MR_STATIC(mercury__gml__get_float_exponent_4_0));
MR_define_label(mercury__gml__get_float_exponent_4_0_i11);
	MR_stackvar(3) = MR_r2;
	MR_r1 = MR_stackvar(2);
	MR_call_localret(MR_ENTRY(mercury__char__is_digit_1_0),
		mercury__gml__get_float_exponent_4_0_i16,
		MR_STATIC(mercury__gml__get_float_exponent_4_0));
MR_define_label(mercury__gml__get_float_exponent_4_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_float_exponent_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_float_exponent_4_0_i14);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__gml__get_float_exponent_3_4_0,
		MR_STATIC(mercury__gml__get_float_exponent_4_0));
MR_define_label(mercury__gml__get_float_exponent_4_0_i14);
	MR_r2 = MR_stackvar(3);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 6342 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r3 = LineNum;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	{
	MR_String	Str;
	MR_Word	CharList;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_4_0
	CharList = MR_r5;
{
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
		/* mode (out, in) is det */
	MR_Word char_list_ptr;
	size_t size;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `char_list_ptr'
*/
	size = sizeof(MR_Word);
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		size++;
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** loop to copy the characters from the char_list to the string
*/
	size = 0;
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		Str[size++] = MR_list_head(char_list_ptr);
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** null terminate the string
*/
	Str[size] = '\0';
};}
#line 6393 "gml.c"
	MR_r5 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = MR_r5;
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_12);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = (MR_Word) MR_string_const("unexpected character `", 22);
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = MR_r6;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_4_0
	Strs = MR_r5;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 6438 "gml.c"
	MR_r5 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_float_exponent_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r5;
	MR_stackvar(1) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_float_exponent_4_0_i19,
		MR_STATIC(mercury__gml__get_float_exponent_4_0));
MR_define_label(mercury__gml__get_float_exponent_4_0_i19);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_float_exponent_4_0));
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate 'get_float_exponent_2'/4 in mode 0 */
MR_define_static(mercury__gml__get_float_exponent_2_4_0);
	MR_incr_sp_push_msg(4, "gml:get_float_exponent_2/4");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_float_exponent_2_4_0_i2),
		MR_STATIC(mercury__gml__get_float_exponent_2_4_0));
MR_define_label(mercury__gml__get_float_exponent_2_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_float_exponent_2_4_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__get_float_exponent_2_4_0_i4);
	}
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_2_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 6484 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r3 = LineNum;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	MR_stackvar(1) = MR_r4;
	MR_stackvar(2) = MR_r3;
	MR_r1 = (MR_Word) MR_string_const("unexpected end-of-file in ", 26);
	MR_r2 = (MR_Word) MR_string_const("float exponent", 14);
	MR_call_localret(MR_ENTRY(mercury__string__append_3_2),
		mercury__gml__get_float_exponent_2_4_0_i5,
		MR_STATIC(mercury__gml__get_float_exponent_2_4_0));
MR_define_label(mercury__gml__get_float_exponent_2_4_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_float_exponent_2_4_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_float_exponent_2_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_float_exponent_2_4_0_i12,
		MR_STATIC(mercury__gml__get_float_exponent_2_4_0));
MR_define_label(mercury__gml__get_float_exponent_2_4_0_i4);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r2;
	MR_r1 = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__char__is_digit_1_0),
		mercury__gml__get_float_exponent_2_4_0_i9,
		MR_STATIC(mercury__gml__get_float_exponent_2_4_0));
MR_define_label(mercury__gml__get_float_exponent_2_4_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_float_exponent_2_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_float_exponent_2_4_0_i7);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__gml__get_float_exponent_3_4_0,
		MR_STATIC(mercury__gml__get_float_exponent_2_4_0));
MR_define_label(mercury__gml__get_float_exponent_2_4_0_i7);
	MR_r3 = MR_stackvar(2);
	MR_r2 = MR_stackvar(3);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_2_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 6544 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r4 = LineNum;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	{
	MR_String	Str;
	MR_Word	CharList;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_2_4_0
	CharList = MR_r6;
{
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
		/* mode (out, in) is det */
	MR_Word char_list_ptr;
	size_t size;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `char_list_ptr'
*/
	size = sizeof(MR_Word);
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		size++;
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** loop to copy the characters from the char_list to the string
*/
	size = 0;
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		Str[size++] = MR_list_head(char_list_ptr);
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** null terminate the string
*/
	Str[size] = '\0';
};}
#line 6595 "gml.c"
	MR_r3 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_12);
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 0) = (MR_Word) MR_string_const("unexpected character `", 22);
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 1) = MR_r6;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_2_4_0
	Strs = MR_r3;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 6640 "gml.c"
	MR_r3 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_float_exponent_2_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r3;
	MR_stackvar(1) = MR_r5;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_float_exponent_2_4_0_i12,
		MR_STATIC(mercury__gml__get_float_exponent_2_4_0));
MR_define_label(mercury__gml__get_float_exponent_2_4_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_float_exponent_2_4_0));
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate 'get_float_exponent_3'/4 in mode 0 */
MR_define_static(mercury__gml__get_float_exponent_3_4_0);
	MR_incr_sp_push_msg(4, "gml:get_float_exponent_3/4");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_float_exponent_3_4_0_i2),
		MR_STATIC(mercury__gml__get_float_exponent_3_4_0));
MR_define_label(mercury__gml__get_float_exponent_3_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_float_exponent_3_4_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__get_float_exponent_3_4_0_i4);
	}
	{
	MR_Word	Chars;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_3_4_0
	Chars = MR_stackvar(1);
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
};}
#line 6717 "gml.c"
	MR_r3 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	{
	MR_String	FloatString;
	MR_Float	FloatVal;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_3_4_0
	FloatString = (MR_String) MR_r3;
{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	/* use a temporary, since we can't don't know whether FloatVal
	   is a double or float */
	double tmp;
	SUCCESS_INDICATOR = (sscanf(FloatString, "%lf", &tmp) == 1);
		/* TRUE if sscanf succeeds, FALSE otherwise */
	FloatVal = tmp;
};}
#line 6737 "gml.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__gml__get_float_exponent_3_4_0_i7);
	MR_r4 = MR_float_to_word(FloatVal);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__gml__get_float_exponent_3_4_0, "gml:number/0");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__get_float_exponent_3_4_0_i7);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_3_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 6762 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r4 = LineNum;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_3_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_4);
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_3_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 0) = (MR_Word) MR_string_const("invalid float token `", 21);
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 1) = MR_r6;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_3_4_0
	Strs = MR_r3;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 6809 "gml.c"
	MR_r3 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_float_exponent_3_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r3;
	MR_stackvar(1) = MR_r5;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_float_exponent_3_4_0_i20,
		MR_STATIC(mercury__gml__get_float_exponent_3_4_0));
MR_define_label(mercury__gml__get_float_exponent_3_4_0_i4);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r2;
	MR_r1 = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__char__is_digit_1_0),
		mercury__gml__get_float_exponent_3_4_0_i13,
		MR_STATIC(mercury__gml__get_float_exponent_3_4_0));
MR_define_label(mercury__gml__get_float_exponent_3_4_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_float_exponent_3_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__get_float_exponent_3_4_0_i11);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_3_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(1);
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__gml__lexer_read_char_3_0,
		MR_LABEL(mercury__gml__get_float_exponent_3_4_0_i2),
		MR_STATIC(mercury__gml__get_float_exponent_3_4_0));
MR_define_label(mercury__gml__get_float_exponent_3_4_0_i11);
	MR_r3 = MR_stackvar(2);
	MR_r2 = MR_stackvar(3);
	{
	MR_Word	Stream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_3_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("input_stream");
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);
;}
#line 6861 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("input_stream");
	MR_r4 = Stream;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	File;
	MR_Char	Character;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_3_4_0
	File = MR_r4;
	Character = MR_r3;
	IO0 = MR_r5;
	MR_save_registers();
	MR_OBTAIN_GLOBAL_LOCK("putback_char");
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
};}
#line 6892 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("putback_char");
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	Chars;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_3_4_0
	Chars = MR_stackvar(1);
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
};}
#line 6945 "gml.c"
	MR_r3 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	{
	MR_String	FloatString;
	MR_Float	FloatVal;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_3_4_0
	FloatString = (MR_String) MR_r3;
{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	/* use a temporary, since we can't don't know whether FloatVal
	   is a double or float */
	double tmp;
	SUCCESS_INDICATOR = (sscanf(FloatString, "%lf", &tmp) == 1);
		/* TRUE if sscanf succeeds, FALSE otherwise */
	FloatVal = tmp;
};}
#line 6965 "gml.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__gml__get_float_exponent_3_4_0_i18);
	MR_r4 = MR_float_to_word(FloatVal);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__gml__get_float_exponent_3_4_0, "gml:number/0");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__get_float_exponent_3_4_0_i18);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_3_4_0
	IO0 = MR_r2;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 6990 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r4 = LineNum;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_3_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_4);
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(1), (MR_Integer) 2, mercury__gml__get_float_exponent_3_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 0) = (MR_Word) MR_string_const("invalid float token `", 21);
	MR_field(MR_mktag(1), MR_r3, (MR_Integer) 1) = MR_r6;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__get_float_exponent_3_4_0
	Strs = MR_r3;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 7037 "gml.c"
	MR_r3 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__get_float_exponent_3_4_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r3;
	MR_stackvar(1) = MR_r5;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__get_float_exponent_3_4_0_i20,
		MR_STATIC(mercury__gml__get_float_exponent_3_4_0));
MR_define_label(mercury__gml__get_float_exponent_3_4_0_i20);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__get_float_exponent_3_4_0));
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate 'rev_char_list_to_int'/5 in mode 0 */
MR_define_static(mercury__gml__rev_char_list_to_int_5_0);
	{
	MR_Word	Chars;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__rev_char_list_to_int_5_0
	Chars = MR_r1;
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
};}
#line 7102 "gml.c"
	MR_r4 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(3, "gml:rev_char_list_to_int/5");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r3;
	MR_stackvar(2) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r4;
	MR_call_localret(MR_ENTRY(mercury__string__base_string_to_int_3_0),
		mercury__gml__rev_char_list_to_int_5_0_i4,
		MR_STATIC(mercury__gml__rev_char_list_to_int_5_0));
MR_define_label(mercury__gml__rev_char_list_to_int_5_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__rev_char_list_to_int_5_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__gml__rev_char_list_to_int_5_0_i2);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 1, mercury__gml__rev_char_list_to_int_5_0, "gml:number/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r2;
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__gml__rev_char_list_to_int_5_0_i2);
	MR_r3 = MR_stackvar(1);
	MR_r4 = MR_stackvar(2);
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__rev_char_list_to_int_5_0
	IO0 = MR_r3;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 7143 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r3 = LineNum;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__gml__rev_char_list_to_int_5_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_gml__common_4);
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(1), (MR_Integer) 2, mercury__gml__rev_char_list_to_int_5_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r4, (MR_Integer) 0) = (MR_Word) MR_string_const("invalid int token `", 19);
	MR_field(MR_mktag(1), MR_r4, (MR_Integer) 1) = MR_r6;
	{
	MR_Word	Strs;
	MR_String	Str;
#define	MR_PROC_LABEL	mercury__gml__rev_char_list_to_int_5_0
	Strs = MR_r4;
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
};}
#line 7190 "gml.c"
	MR_r4 = (MR_Word) Str;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__rev_char_list_to_int_5_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r4;
	MR_stackvar(1) = MR_r5;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__rev_char_list_to_int_5_0_i6,
		MR_STATIC(mercury__gml__rev_char_list_to_int_5_0));
MR_define_label(mercury__gml__rev_char_list_to_int_5_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__rev_char_list_to_int_5_0));
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate 'lexer_read_char'/3 in mode 0 */
MR_define_static(mercury__gml__lexer_read_char_3_0);
	{
	MR_Word	Stream;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__lexer_read_char_3_0
	IO0 = MR_r1;
	MR_OBTAIN_GLOBAL_LOCK("input_stream");
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);
;}
#line 7224 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("input_stream");
	MR_r3 = Stream;
	MR_r4 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_Word	File;
	MR_Integer	CharCode;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__lexer_read_char_3_0
	File = MR_r3;
	IO0 = MR_r4;
	MR_OBTAIN_GLOBAL_LOCK("read_char_code");
{
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	CharCode = mercury_getc((MercuryFile *) File);
	update_io(IO0, IO);
;}
#line 7246 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("read_char_code");
	MR_r3 = CharCode;
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r3 != (MR_Integer) -1)) {
		MR_GOTO_LABEL(mercury__gml__lexer_read_char_3_0_i2);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
MR_define_label(mercury__gml__lexer_read_char_3_0_i2);
	{
	MR_Char	Character;
	MR_Integer	Int;
#define	MR_PROC_LABEL	mercury__gml__lexer_read_char_3_0
	Int = MR_r3;
{
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

	/*
	** If the integer doesn't fit into a char, then
	** the assignment `Character = Int' below will truncate it.
	** SUCCESS_INDICATOR will be set to true only if
	** the result was not truncated.
	*/
	Character = Int;
	SUCCESS_INDICATOR = ((MR_UnsignedChar) Character == Int);
;}
#line 7276 "gml.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__gml__lexer_read_char_3_0_i6);
	MR_r3 = Character;
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__gml__lexer_read_char_3_0, "io:result/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r3;
	MR_proceed();
MR_define_label(mercury__gml__lexer_read_char_3_0_i6);
	{
	MR_String	Msg0;
	MR_String	Msg;
#define	MR_PROC_LABEL	mercury__gml__lexer_read_char_3_0
	Msg0 = (MR_String) (MR_Word) MR_string_const("read failed: ", 13);
	MR_OBTAIN_GLOBAL_LOCK("make_err_msg");
{
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	ML_maybe_make_err_msg(TRUE, Msg0, MR_PROC_LABEL, Msg);
};}
#line 7297 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("make_err_msg");
	MR_r3 = (MR_Word) Msg;
#undef	MR_PROC_LABEL

	}
	{
	MR_Integer	LineNum;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__gml__lexer_read_char_3_0
	IO0 = MR_r4;
	MR_OBTAIN_GLOBAL_LOCK("get_line_number");
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);
;}
#line 7316 "gml.c"
	MR_RELEASE_GLOBAL_LOCK("get_line_number");
	MR_r4 = LineNum;
	MR_r5 = IO;
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(2, "gml:lexer_read_char/3");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__gml__lexer_read_char_3_0, "gml:lexer_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r3;
	MR_stackvar(1) = MR_r5;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__gml__lexer_read_char_3_0_i8,
		MR_STATIC(mercury__gml__lexer_read_char_3_0));
MR_define_label(mercury__gml__lexer_read_char_3_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__lexer_read_char_3_0));
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate 'parse_2'/5 in mode 0 */
MR_define_static(mercury__gml__parse_2_5_0);
	MR_incr_sp_push_msg(4, "gml:parse_2/5");
	MR_stackvar(4) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r2 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i3);
	}
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i5);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r2 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__parse_2_5_0_i5);
	if (((MR_Integer) MR_r1 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i6);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_parse_error_0;
	MR_r2 = (MR_Word) MR_string_const("unterminated array", 18);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_STATIC(mercury__gml__parse_2_5_0));
MR_define_label(mercury__gml__parse_2_5_0_i6);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_parse_error_0;
	MR_r2 = (MR_Word) MR_string_const("unterminated function", 21);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_STATIC(mercury__gml__parse_2_5_0));
MR_define_label(mercury__gml__parse_2_5_0_i3);
	MR_r4 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	if ((MR_tag(MR_r4) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i11);
	}
	if (((MR_Integer) MR_unmkbody(MR_r4) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i12);
	}
	if (((MR_Integer) MR_unmkbody(MR_r4) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i16);
	}
	if (((MR_Integer) MR_unmkbody(MR_r4) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i21);
	}
	if (((MR_Integer) MR_r1 != (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i25);
	}
	MR_r1 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_r2 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__parse_2_5_0_i25);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_parse_error_0;
	MR_r2 = (MR_Word) MR_string_const("'}' without preceding '{'", 25);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_STATIC(mercury__gml__parse_2_5_0));
MR_define_label(mercury__gml__parse_2_5_0_i21);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r3;
	MR_r1 = (MR_Integer) 2;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_r3 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_localcall(mercury__gml__parse_2_5_0,
		MR_LABEL(mercury__gml__parse_2_5_0_i22),
		MR_STATIC(mercury__gml__parse_2_5_0));
MR_define_label(mercury__gml__parse_2_5_0_i22);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__parse_2_5_0));
	MR_stackvar(3) = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_r3 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_call_localret(MR_ENTRY(mercury__list__reverse_2_3_0),
		mercury__gml__parse_2_5_0_i23,
		MR_STATIC(mercury__gml__parse_2_5_0));
MR_define_label(mercury__gml__parse_2_5_0_i23);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__parse_2_5_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__gml__parse_2_5_0, "gml:token_group/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__gml__parse_2_5_0, "list:list/1");
	MR_r3 = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_stackvar(2);
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	if (((MR_Integer) MR_r2 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i3);
	}
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i5);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r2 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
	}
MR_define_label(mercury__gml__parse_2_5_0_i16);
	if (((MR_Integer) MR_r1 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i17);
	}
	MR_r1 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_r2 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__gml__parse_2_5_0_i17);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_parse_error_0;
	MR_r2 = (MR_Word) MR_string_const("']' without preceding '['", 25);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_STATIC(mercury__gml__parse_2_5_0));
MR_define_label(mercury__gml__parse_2_5_0_i12);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r3;
	MR_r1 = (MR_Integer) 1;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_r3 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_localcall(mercury__gml__parse_2_5_0,
		MR_LABEL(mercury__gml__parse_2_5_0_i13),
		MR_STATIC(mercury__gml__parse_2_5_0));
MR_define_label(mercury__gml__parse_2_5_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__parse_2_5_0));
	MR_stackvar(3) = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_r3 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_call_localret(MR_ENTRY(mercury__list__reverse_2_3_0),
		mercury__gml__parse_2_5_0_i14,
		MR_STATIC(mercury__gml__parse_2_5_0));
MR_define_label(mercury__gml__parse_2_5_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury__gml__parse_2_5_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__gml__parse_2_5_0, "gml:token_group/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__gml__parse_2_5_0, "list:list/1");
	MR_r3 = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_stackvar(2);
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	if (((MR_Integer) MR_r2 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i3);
	}
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i5);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r2 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
	}
MR_define_label(mercury__gml__parse_2_5_0_i11);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 1, mercury__gml__parse_2_5_0, "gml:token_group/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 0);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__gml__parse_2_5_0, "list:list/1");
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_r3;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_r3 = MR_tempr2;
	MR_succip = (MR_Code *) MR_stackvar(4);
	if (((MR_Integer) MR_r2 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i3);
	}
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__gml__parse_2_5_0_i5);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r2 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
	}
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___gml__basic_token_0_0);
	if ((MR_tag(MR_r1) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___gml__basic_token_0_0_i4);
	}
	if (((MR_Integer) MR_unmkbody(MR_r1) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Unify___gml__basic_token_0_0_i5);
	}
	if (((MR_Integer) MR_unmkbody(MR_r1) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Unify___gml__basic_token_0_0_i7);
	}
	if (((MR_Integer) MR_unmkbody(MR_r1) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Unify___gml__basic_token_0_0_i9);
	}
	MR_r1 = ((MR_Integer) MR_r2 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 3)));
	MR_proceed();
MR_define_label(mercury____Unify___gml__basic_token_0_0_i9);
	MR_r1 = ((MR_Integer) MR_r2 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 2)));
	MR_proceed();
MR_define_label(mercury____Unify___gml__basic_token_0_0_i7);
	MR_r1 = ((MR_Integer) MR_r2 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 1)));
	MR_proceed();
MR_define_label(mercury____Unify___gml__basic_token_0_0_i5);
	MR_r1 = ((MR_Integer) MR_r2 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)));
	MR_proceed();
MR_define_label(mercury____Unify___gml__basic_token_0_0_i4);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___gml__basic_token_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Unify___gml__token_0_0,
		MR_ENTRY(mercury____Unify___gml__basic_token_0_0));
MR_define_label(mercury____Unify___gml__basic_token_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Index__'/2 in mode 0 */
MR_define_entry(mercury____Index___gml__basic_token_0_0);
	if ((MR_tag(MR_r1) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Index___gml__basic_token_0_0_i4);
	}
	if (((MR_Integer) MR_unmkbody(MR_r1) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Index___gml__basic_token_0_0_i5);
	}
	if (((MR_Integer) MR_unmkbody(MR_r1) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Index___gml__basic_token_0_0_i6);
	}
	if (((MR_Integer) MR_unmkbody(MR_r1) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Index___gml__basic_token_0_0_i7);
	}
	MR_r1 = (MR_Integer) 3;
	MR_proceed();
MR_define_label(mercury____Index___gml__basic_token_0_0_i7);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Index___gml__basic_token_0_0_i6);
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Index___gml__basic_token_0_0_i5);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Index___gml__basic_token_0_0_i4);
	MR_r1 = (MR_Integer) 4;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___gml__basic_token_0_0);
	if ((MR_tag(MR_r1) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i4);
	}
	if (((MR_Integer) MR_unmkbody(MR_r1) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i5);
	}
	if (((MR_Integer) MR_unmkbody(MR_r1) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i6);
	}
	if (((MR_Integer) MR_unmkbody(MR_r1) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i7);
	}
	MR_r3 = (MR_Integer) 3;
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i10);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i11);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i12);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i13);
	}
	MR_r4 = (MR_Integer) 3;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i14);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i7);
	MR_r3 = (MR_Integer) 2;
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i10);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i11);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i12);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i13);
	}
	MR_r4 = (MR_Integer) 3;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i14);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i6);
	MR_r3 = (MR_Integer) 1;
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i10);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i11);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i12);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i13);
	}
	MR_r4 = (MR_Integer) 3;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i14);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i5);
	MR_r3 = (MR_Integer) 0;
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i10);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i11);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i12);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i13);
	}
	MR_r4 = (MR_Integer) 3;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i14);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i4);
	MR_r3 = (MR_Integer) 4;
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i10);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i11);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i12);
	}
	if (((MR_Integer) MR_unmkbody(MR_r2) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i13);
	}
	MR_r4 = (MR_Integer) 3;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i14);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i13);
	MR_r4 = (MR_Integer) 2;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i14);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i12);
	MR_r4 = (MR_Integer) 1;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i14);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i11);
	MR_r4 = (MR_Integer) 0;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i14);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i10);
	MR_r4 = (MR_Integer) 4;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i14);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i14);
	if (((MR_Integer) MR_r3 <= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i15);
	}
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i15);
	if ((MR_tag(MR_r1) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i20);
	}
	if (((MR_Integer) MR_unmkbody(MR_r1) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i21);
	}
	if (((MR_Integer) MR_unmkbody(MR_r1) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i23);
	}
	if (((MR_Integer) MR_unmkbody(MR_r1) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i25);
	}
	if (((MR_Integer) MR_r2 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i232);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i25);
	if (((MR_Integer) MR_r2 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 2)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i232);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i23);
	if (((MR_Integer) MR_r2 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i232);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i21);
	if (((MR_Integer) MR_r2 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i232);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___gml__basic_token_0_0_i20);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___gml__basic_token_0_0_i232);
	}
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Compare___gml__token_0_0,
		MR_ENTRY(mercury____Compare___gml__basic_token_0_0));
MR_define_label(mercury____Compare___gml__basic_token_0_0_i232);
	MR_tailcall(MR_ENTRY(mercury__compare_error_0_0),
		MR_ENTRY(mercury____Compare___gml__basic_token_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___gml__token_0_0);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Unify___gml__token_0_0_i4) MR_AND
		MR_LABEL(mercury____Unify___gml__token_0_0_i6) MR_AND
		MR_LABEL(mercury____Unify___gml__token_0_0_i8) MR_AND
		MR_LABEL(mercury____Unify___gml__token_0_0_i10));
MR_define_label(mercury____Unify___gml__token_0_0_i4);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r1 = (MR_r3 == MR_r4);
	MR_proceed();
MR_define_label(mercury____Unify___gml__token_0_0_i6);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_r1 = (strcmp((char *)MR_r3, (char *)MR_r4) == 0);
	MR_proceed();
MR_define_label(mercury____Unify___gml__token_0_0_i8);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 0);
	MR_r1 = (strcmp((char *)MR_r3, (char *)MR_r1) == 0);
	MR_proceed();
MR_define_label(mercury____Unify___gml__token_0_0_i10);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_0_0_i11);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_0_0_i13);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_0_0_i19);
	}
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_localtailcall(mercury____Unify___gml__extra_operator_0_0,
		MR_ENTRY(mercury____Unify___gml__token_0_0));
MR_define_label(mercury____Unify___gml__token_0_0_i19);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 2)))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_r1 = (strcmp((char *)MR_r3, (char *)MR_r4) == 0);
	MR_proceed();
MR_define_label(mercury____Unify___gml__token_0_0_i13);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	if ((MR_tag(MR_r3) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_0_0_i16);
	}
	MR_r4 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	if ((MR_tag(MR_r4) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_0_0_i1);
	}
	MR_r5 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	MR_r1 = (MR_r5 == MR_r3);
	MR_proceed();
MR_define_label(mercury____Unify___gml__token_0_0_i16);
	MR_r4 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	if ((MR_tag(MR_r4) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_0_0_i1);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 0);
	MR_r1 = (MR_word_to_float(MR_r5) == MR_word_to_float(MR_r3));
	MR_proceed();
MR_define_label(mercury____Unify___gml__token_0_0_i11);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_r1 = (MR_r3 == MR_r1);
	MR_proceed();
MR_define_label(mercury____Unify___gml__token_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Index__'/2 in mode 0 */
MR_define_entry(mercury____Index___gml__token_0_0);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Index___gml__token_0_0_i4) MR_AND
		MR_LABEL(mercury____Index___gml__token_0_0_i5) MR_AND
		MR_LABEL(mercury____Index___gml__token_0_0_i6) MR_AND
		MR_LABEL(mercury____Index___gml__token_0_0_i7));
MR_define_label(mercury____Index___gml__token_0_0_i4);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Index___gml__token_0_0_i5);
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Index___gml__token_0_0_i6);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Index___gml__token_0_0_i7);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Index___gml__token_0_0_i8);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Index___gml__token_0_0_i9);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Index___gml__token_0_0_i10);
	}
	MR_r1 = (MR_Integer) 6;
	MR_proceed();
MR_define_label(mercury____Index___gml__token_0_0_i10);
	MR_r1 = (MR_Integer) 5;
	MR_proceed();
MR_define_label(mercury____Index___gml__token_0_0_i9);
	MR_r1 = (MR_Integer) 4;
	MR_proceed();
MR_define_label(mercury____Index___gml__token_0_0_i8);
	MR_r1 = (MR_Integer) 3;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___gml__token_0_0);
	MR_incr_sp_push_msg(4, "gml:__Compare__/3");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_localcall(mercury____Index___gml__token_0_0,
		MR_LABEL(mercury____Compare___gml__token_0_0_i2),
		MR_ENTRY(mercury____Compare___gml__token_0_0));
MR_define_label(mercury____Compare___gml__token_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___gml__token_0_0));
	MR_stackvar(3) = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_localcall(mercury____Index___gml__token_0_0,
		MR_LABEL(mercury____Compare___gml__token_0_0_i3),
		MR_ENTRY(mercury____Compare___gml__token_0_0));
MR_define_label(mercury____Compare___gml__token_0_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___gml__token_0_0));
	if (((MR_Integer) MR_stackvar(3) >= (MR_Integer) MR_r1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i4);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_0_0_i4);
	if (((MR_Integer) MR_stackvar(3) <= (MR_Integer) MR_r1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i5);
	}
MR_define_label(mercury____Compare___gml__token_0_0_i54);
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_0_0_i5);
	MR_r2 = MR_stackvar(1);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r2),
		MR_LABEL(mercury____Compare___gml__token_0_0_i10) MR_AND
		MR_LABEL(mercury____Compare___gml__token_0_0_i16) MR_AND
		MR_LABEL(mercury____Compare___gml__token_0_0_i23) MR_AND
		MR_LABEL(mercury____Compare___gml__token_0_0_i30));
MR_define_label(mercury____Compare___gml__token_0_0_i10);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i7);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if (((MR_Integer) MR_r4 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i12);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_0_0_i12);
	if ((MR_r4 != MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i54);
	}
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_0_0_i16);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i7);
	}
	MR_r3 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(1), MR_stackvar(2), (MR_Integer) 0);
	{
	MR_Integer	Res;
	MR_String	S1;
	MR_String	S2;
#define	MR_PROC_LABEL	mercury____Compare___gml__token_0_0
	S1 = (MR_String) MR_r3;
	S2 = (MR_String) MR_r4;
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);;}
#line 7988 "gml.c"
	MR_r3 = Res;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r3 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i18);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_0_0_i18);
	if (((MR_Integer) MR_r3 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i54);
	}
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_0_0_i23);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i7);
	}
	MR_r3 = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_stackvar(2), (MR_Integer) 0);
	{
	MR_Integer	Res;
	MR_String	S1;
	MR_String	S2;
#define	MR_PROC_LABEL	mercury____Compare___gml__token_0_0
	S1 = (MR_String) MR_r3;
	S2 = (MR_String) MR_r2;
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);;}
#line 8024 "gml.c"
	MR_r2 = Res;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r2 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i25);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_0_0_i25);
	if (((MR_Integer) MR_r2 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i54);
	}
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_0_0_i30);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i31);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i37);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i40);
	}
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i7);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury____Compare___gml__extra_operator_0_0,
		MR_ENTRY(mercury____Compare___gml__token_0_0));
MR_define_label(mercury____Compare___gml__token_0_0_i40);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 2)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i7);
	}
	MR_r3 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	{
	MR_Integer	Res;
	MR_String	S1;
	MR_String	S2;
#define	MR_PROC_LABEL	mercury____Compare___gml__token_0_0
	S1 = (MR_String) MR_r3;
	S2 = (MR_String) MR_r4;
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);;}
#line 8079 "gml.c"
	MR_r3 = Res;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r3 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i42);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_0_0_i42);
	if (((MR_Integer) MR_r3 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i54);
	}
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_0_0_i37);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i7);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury____Compare___gml__number_0_0,
		MR_ENTRY(mercury____Compare___gml__token_0_0));
MR_define_label(mercury____Compare___gml__token_0_0_i31);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i7);
	}
	MR_r3 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	if (((MR_Integer) MR_r4 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i33);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_0_0_i33);
	if ((MR_r4 != MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_0_0_i54);
	}
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_0_0_i7);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury__compare_error_0_0),
		MR_ENTRY(mercury____Compare___gml__token_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___gml__number_0_0);
	if ((MR_tag(MR_r1) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___gml__number_0_0_i3);
	}
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___gml__number_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r1 = (MR_r3 == MR_r1);
	MR_proceed();
MR_define_label(mercury____Unify___gml__number_0_0_i3);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___gml__number_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r1));
	MR_proceed();
MR_define_label(mercury____Unify___gml__number_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___gml__number_0_0);
	if ((MR_tag(MR_r1) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___gml__number_0_0_i3);
	}
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___gml__number_0_0_i21);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___gml__number_0_0_i6);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__number_0_0_i6);
	if ((MR_r3 != MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___gml__number_0_0_i22);
	}
MR_define_label(mercury____Compare___gml__number_0_0_i19);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___gml__number_0_0_i3);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___gml__number_0_0_i11);
	}
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Compare___gml__number_0_0_i11);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	if ((MR_word_to_float(MR_r3) >= MR_word_to_float(MR_r4))) {
		MR_GOTO_LABEL(mercury____Compare___gml__number_0_0_i12);
	}
MR_define_label(mercury____Compare___gml__number_0_0_i21);
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__number_0_0_i12);
	if ((MR_word_to_float(MR_r3) <= MR_word_to_float(MR_r4))) {
		MR_GOTO_LABEL(mercury____Compare___gml__number_0_0_i19);
	}
MR_define_label(mercury____Compare___gml__number_0_0_i22);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___gml__operator_0_0);
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___gml__operator_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	if (((MR_Integer) MR_r2 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___gml__operator_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__operator_0_0_i2);
	if ((MR_r2 != MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___gml__operator_0_0_i3);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___gml__operator_0_0_i3);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___gml__extra_operator_0_0);
	MR_incr_sp_push_msg(3, "gml:__Unify__/2");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Unify___gml__extra_operator_0_0_i4) MR_AND
		MR_LABEL(mercury____Unify___gml__extra_operator_0_0_i6) MR_AND
		MR_LABEL(mercury____Unify___gml__extra_operator_0_0_i8) MR_AND
		MR_LABEL(mercury____Unify___gml__extra_operator_0_0_i12));
MR_define_label(mercury____Unify___gml__extra_operator_0_0_i4);
	MR_r1 = ((MR_Integer) MR_r2 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Unify___gml__extra_operator_0_0_i6);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___gml__extra_operator_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_r1 = (MR_r3 == MR_r1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Unify___gml__extra_operator_0_0_i8);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Unify___gml__extra_operator_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 0);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___eval__surface_properties_0_0),
		MR_ENTRY(mercury____Unify___gml__extra_operator_0_0));
MR_define_label(mercury____Unify___gml__extra_operator_0_0_i12);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0),
		MR_LABEL(mercury____Unify___gml__extra_operator_0_0_i13) MR_AND
		MR_LABEL(mercury____Unify___gml__extra_operator_0_0_i17) MR_AND
		MR_LABEL(mercury____Unify___gml__extra_operator_0_0_i21) MR_AND
		MR_LABEL(mercury____Unify___gml__extra_operator_0_0_i25) MR_AND
		MR_LABEL(mercury____Unify___gml__extra_operator_0_0_i29) MR_AND
		MR_LABEL(mercury____Unify___gml__extra_operator_0_0_i33) MR_AND
		MR_LABEL(mercury____Unify___gml__extra_operator_0_0_i39));
MR_define_label(mercury____Unify___gml__extra_operator_0_0_i13);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Unify___gml__extra_operator_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___eval__surface_properties_0_0),
		MR_ENTRY(mercury____Unify___gml__extra_operator_0_0));
MR_define_label(mercury____Unify___gml__extra_operator_0_0_i17);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury____Unify___gml__extra_operator_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___eval__surface_properties_0_0),
		MR_ENTRY(mercury____Unify___gml__extra_operator_0_0));
MR_define_label(mercury____Unify___gml__extra_operator_0_0_i21);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 2)))) {
		MR_GOTO_LABEL(mercury____Unify___gml__extra_operator_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___eval__surface_properties_0_0),
		MR_ENTRY(mercury____Unify___gml__extra_operator_0_0));
MR_define_label(mercury____Unify___gml__extra_operator_0_0_i25);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury____Unify___gml__extra_operator_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___eval__surface_properties_0_0),
		MR_ENTRY(mercury____Unify___gml__extra_operator_0_0));
MR_define_label(mercury____Unify___gml__extra_operator_0_0_i29);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury____Unify___gml__extra_operator_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		MR_ENTRY(mercury____Unify___gml__extra_operator_0_0));
MR_define_label(mercury____Unify___gml__extra_operator_0_0_i33);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 5)))) {
		MR_GOTO_LABEL(mercury____Unify___gml__extra_operator_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_call_localret(MR_ENTRY(mercury____Unify___eval__value_0_0),
		mercury____Unify___gml__extra_operator_0_0_i35,
		MR_ENTRY(mercury____Unify___gml__extra_operator_0_0));
MR_define_label(mercury____Unify___gml__extra_operator_0_0_i35);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___gml__extra_operator_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___gml__extra_operator_0_0_i1);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___eval__value_0_0),
		MR_ENTRY(mercury____Unify___gml__extra_operator_0_0));
MR_define_label(mercury____Unify___gml__extra_operator_0_0_i39);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 6)))) {
		MR_GOTO_LABEL(mercury____Unify___gml__extra_operator_0_0_i1);
	}
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_localtailcall(mercury__gml__builtin_unify_pred__ua0_2_0,
		MR_ENTRY(mercury____Unify___gml__extra_operator_0_0));
MR_define_label(mercury____Unify___gml__extra_operator_0_0_i1);
	MR_r1 = FALSE;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate '__Index__'/2 in mode 0 */
MR_define_entry(mercury____Index___gml__extra_operator_0_0);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Index___gml__extra_operator_0_0_i4) MR_AND
		MR_LABEL(mercury____Index___gml__extra_operator_0_0_i5) MR_AND
		MR_LABEL(mercury____Index___gml__extra_operator_0_0_i6) MR_AND
		MR_LABEL(mercury____Index___gml__extra_operator_0_0_i7));
MR_define_label(mercury____Index___gml__extra_operator_0_0_i4);
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Index___gml__extra_operator_0_0_i5);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Index___gml__extra_operator_0_0_i6);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Index___gml__extra_operator_0_0_i7);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0),
		MR_LABEL(mercury____Index___gml__extra_operator_0_0_i8) MR_AND
		MR_LABEL(mercury____Index___gml__extra_operator_0_0_i9) MR_AND
		MR_LABEL(mercury____Index___gml__extra_operator_0_0_i10) MR_AND
		MR_LABEL(mercury____Index___gml__extra_operator_0_0_i11) MR_AND
		MR_LABEL(mercury____Index___gml__extra_operator_0_0_i12) MR_AND
		MR_LABEL(mercury____Index___gml__extra_operator_0_0_i13) MR_AND
		MR_LABEL(mercury____Index___gml__extra_operator_0_0_i14));
MR_define_label(mercury____Index___gml__extra_operator_0_0_i8);
	MR_r1 = (MR_Integer) 3;
	MR_proceed();
MR_define_label(mercury____Index___gml__extra_operator_0_0_i9);
	MR_r1 = (MR_Integer) 4;
	MR_proceed();
MR_define_label(mercury____Index___gml__extra_operator_0_0_i10);
	MR_r1 = (MR_Integer) 5;
	MR_proceed();
MR_define_label(mercury____Index___gml__extra_operator_0_0_i11);
	MR_r1 = (MR_Integer) 6;
	MR_proceed();
MR_define_label(mercury____Index___gml__extra_operator_0_0_i12);
	MR_r1 = (MR_Integer) 7;
	MR_proceed();
MR_define_label(mercury____Index___gml__extra_operator_0_0_i13);
	MR_r1 = (MR_Integer) 8;
	MR_proceed();
MR_define_label(mercury____Index___gml__extra_operator_0_0_i14);
	MR_r1 = (MR_Integer) 9;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___gml__extra_operator_0_0);
	MR_incr_sp_push_msg(4, "gml:__Compare__/3");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_localcall(mercury____Index___gml__extra_operator_0_0,
		MR_LABEL(mercury____Compare___gml__extra_operator_0_0_i2),
		MR_ENTRY(mercury____Compare___gml__extra_operator_0_0));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___gml__extra_operator_0_0));
	MR_stackvar(3) = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_localcall(mercury____Index___gml__extra_operator_0_0,
		MR_LABEL(mercury____Compare___gml__extra_operator_0_0_i3),
		MR_ENTRY(mercury____Compare___gml__extra_operator_0_0));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___gml__extra_operator_0_0));
	if (((MR_Integer) MR_stackvar(3) >= (MR_Integer) MR_r1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i4);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i4);
	if (((MR_Integer) MR_stackvar(3) <= (MR_Integer) MR_r1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i5);
	}
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i53);
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i5);
	MR_r3 = MR_stackvar(1);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r3),
		MR_LABEL(mercury____Compare___gml__extra_operator_0_0_i10) MR_AND
		MR_LABEL(mercury____Compare___gml__extra_operator_0_0_i12) MR_AND
		MR_LABEL(mercury____Compare___gml__extra_operator_0_0_i18) MR_AND
		MR_LABEL(mercury____Compare___gml__extra_operator_0_0_i21));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i10);
	if (((MR_Integer) MR_stackvar(2) != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i7);
	}
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i12);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i7);
	}
	MR_r1 = MR_const_field(MR_mktag(1), MR_stackvar(2), (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if (((MR_Integer) MR_r2 >= (MR_Integer) MR_r1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i14);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i14);
	if ((MR_r2 != MR_r1)) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i53);
	}
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i18);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i7);
	}
	MR_r1 = MR_const_field(MR_mktag(2), MR_r3, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_stackvar(2), (MR_Integer) 0);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury____Compare___eval__surface_properties_0_0),
		MR_ENTRY(mercury____Compare___gml__extra_operator_0_0));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i21);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 0),
		MR_LABEL(mercury____Compare___gml__extra_operator_0_0_i22) MR_AND
		MR_LABEL(mercury____Compare___gml__extra_operator_0_0_i25) MR_AND
		MR_LABEL(mercury____Compare___gml__extra_operator_0_0_i28) MR_AND
		MR_LABEL(mercury____Compare___gml__extra_operator_0_0_i31) MR_AND
		MR_LABEL(mercury____Compare___gml__extra_operator_0_0_i34) MR_AND
		MR_LABEL(mercury____Compare___gml__extra_operator_0_0_i37) MR_AND
		MR_LABEL(mercury____Compare___gml__extra_operator_0_0_i45));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i22);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i7);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury____Compare___eval__surface_properties_0_0),
		MR_ENTRY(mercury____Compare___gml__extra_operator_0_0));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i25);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i7);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury____Compare___eval__surface_properties_0_0),
		MR_ENTRY(mercury____Compare___gml__extra_operator_0_0));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i28);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 2)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i7);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury____Compare___eval__surface_properties_0_0),
		MR_ENTRY(mercury____Compare___gml__extra_operator_0_0));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i31);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i7);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury____Compare___eval__surface_properties_0_0),
		MR_ENTRY(mercury____Compare___gml__extra_operator_0_0));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i34);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i7);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		MR_ENTRY(mercury____Compare___gml__extra_operator_0_0));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i37);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 5)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i7);
	}
	MR_r4 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 2);
	MR_r5 = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 2);
	MR_stackvar(1) = MR_r5;
	MR_r6 = MR_stackvar(2);
	MR_stackvar(2) = MR_r4;
	MR_r1 = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r6, (MR_Integer) 1);
	MR_call_localret(MR_ENTRY(mercury____Compare___eval__value_0_0),
		mercury____Compare___gml__extra_operator_0_0_i40,
		MR_ENTRY(mercury____Compare___gml__extra_operator_0_0));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i40);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___gml__extra_operator_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i51);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury____Compare___eval__value_0_0),
		MR_ENTRY(mercury____Compare___gml__extra_operator_0_0));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i45);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 6)))) {
		MR_GOTO_LABEL(mercury____Compare___gml__extra_operator_0_0_i7);
	}
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__gml__builtin_compare_pred__ua0_3_0,
		MR_ENTRY(mercury____Compare___gml__extra_operator_0_0));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i7);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury__compare_error_0_0),
		MR_ENTRY(mercury____Compare___gml__extra_operator_0_0));
MR_define_label(mercury____Compare___gml__extra_operator_0_0_i51);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___gml__lexer_error_0_0);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury____Unify___gml__lexer_error_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r1 = (strcmp((char *)MR_r3, (char *)MR_r1) == 0);
	MR_proceed();
	}
MR_define_label(mercury____Unify___gml__lexer_error_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___gml__lexer_error_0_0);
	MR_incr_sp_push_msg(2, "gml:__Compare__/3");
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if (((MR_Integer) MR_r2 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___gml__lexer_error_0_0_i4);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__lexer_error_0_0_i3);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(2);
	MR_proceed();
MR_define_label(mercury____Compare___gml__lexer_error_0_0_i4);
	if ((MR_r2 == MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___gml__lexer_error_0_0_i3);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__lexer_error_0_0_i3);
	}
MR_define_label(mercury____Compare___gml__lexer_error_0_0_i23);
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(2);
	MR_proceed();
MR_define_label(mercury____Compare___gml__lexer_error_0_0_i3);
	{
	MR_Integer	Res;
	MR_String	S1;
	MR_String	S2;
#define	MR_PROC_LABEL	mercury____Compare___gml__lexer_error_0_0
	S1 = (MR_String) MR_stackvar(1);
	S2 = (MR_String) MR_stackvar(2);
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);;}
#line 8634 "gml.c"
	MR_r2 = Res;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r2 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__lexer_error_0_0_i14);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(2);
	MR_proceed();
MR_define_label(mercury____Compare___gml__lexer_error_0_0_i14);
	if (((MR_Integer) MR_r2 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__lexer_error_0_0_i23);
	}
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___gml__parse_error_0_0);
	MR_r1 = (strcmp((char *)MR_r1, (char *)MR_r2) == 0);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___gml__parse_error_0_0);
	{
	MR_Integer	Res;
	MR_String	S1;
	MR_String	S2;
#define	MR_PROC_LABEL	mercury____Compare___gml__parse_error_0_0
	S1 = (MR_String) MR_r1;
	S2 = (MR_String) MR_r2;
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);;}
#line 8668 "gml.c"
	MR_r2 = Res;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r2 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__parse_error_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__parse_error_0_0_i2);
	if (((MR_Integer) MR_r2 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___gml__parse_error_0_0_i3);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___gml__parse_error_0_0_i3);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___gml__gml_program_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___gml__gml_program_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___gml__gml_program_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___gml__gml_program_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___gml__token_list_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___gml__token_list_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___gml__token_list_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___gml__token_list_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___gml__token_group_0_0);
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_group_0_0_i4);
	}
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_group_0_0_i8);
	}
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_group_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Unify___gml__token_0_0,
		MR_ENTRY(mercury____Unify___gml__token_group_0_0));
MR_define_label(mercury____Unify___gml__token_group_0_0_i8);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_group_0_0_i1);
	}
	MR_r4 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_r5 = MR_r2;
	MR_r2 = MR_const_field(MR_mktag(2), MR_r4, (MR_Integer) 0);
	MR_r3 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___gml__token_group_0_0));
MR_define_label(mercury____Unify___gml__token_group_0_0_i4);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___gml__token_group_0_0_i1);
	}
	MR_r4 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_r5 = MR_r2;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 0);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___gml__token_group_0_0));
MR_define_label(mercury____Unify___gml__token_group_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___gml__token_group_0_0);
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_group_0_0_i4);
	}
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_group_0_0_i10);
	}
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_group_0_0_i9);
	}
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_group_0_0_i9);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Compare___gml__token_0_0,
		MR_ENTRY(mercury____Compare___gml__token_group_0_0));
MR_define_label(mercury____Compare___gml__token_group_0_0_i10);
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_group_0_0_i28);
	}
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_group_0_0_i7);
	}
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_group_0_0_i4);
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_group_0_0_i7);
	}
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___gml__token_group_0_0_i9);
	}
MR_define_label(mercury____Compare___gml__token_group_0_0_i28);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_group_0_0_i9);
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__token_group_0_0_i7);
	MR_r4 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_r5 = MR_r2;
	MR_r2 = MR_const_mask_field(MR_r4, (MR_Integer) 0);
	MR_r3 = MR_const_mask_field(MR_r5, (MR_Integer) 0);
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___gml__token_group_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___gml__stop_at_0_0);
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___gml__stop_at_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	if (((MR_Integer) MR_r2 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___gml__stop_at_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___gml__stop_at_0_0_i2);
	if ((MR_r2 != MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___gml__stop_at_0_0_i3);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___gml__stop_at_0_0_i3);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__gml_maybe_bunch_0(void)
{
	gml_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__gml__init(void);
void mercury__gml__init_type_tables(void);
void mercury__gml__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__gml__write_out_proc_statics(FILE *fp);
#endif

void mercury__gml__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__gml_maybe_bunch_0();
#endif

	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_gml__type_ctor_info_token_list_0,
		gml__token_list_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_gml__type_ctor_info_token_group_0,
		gml__token_group_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_gml__type_ctor_info_token_0,
		gml__token_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_gml__type_ctor_info_stop_at_0,
		gml__stop_at_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_gml__type_ctor_info_parse_error_0,
		gml__parse_error_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_gml__type_ctor_info_operator_0,
		gml__operator_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_gml__type_ctor_info_number_0,
		gml__number_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_gml__type_ctor_info_lexer_error_0,
		gml__lexer_error_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_gml__type_ctor_info_gml_program_0,
		gml__gml_program_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_gml__type_ctor_info_extra_operator_0,
		gml__extra_operator_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_gml__type_ctor_info_basic_token_0,
		gml__basic_token_0_0);
	mercury__gml__init_debugger();
}

void mercury__gml__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
	MR_register_type_ctor_info(
		&mercury_data_gml__type_ctor_info_token_list_0);
	MR_register_type_ctor_info(
		&mercury_data_gml__type_ctor_info_token_group_0);
	MR_register_type_ctor_info(
		&mercury_data_gml__type_ctor_info_token_0);
	MR_register_type_ctor_info(
		&mercury_data_gml__type_ctor_info_stop_at_0);
	MR_register_type_ctor_info(
		&mercury_data_gml__type_ctor_info_parse_error_0);
	MR_register_type_ctor_info(
		&mercury_data_gml__type_ctor_info_operator_0);
	MR_register_type_ctor_info(
		&mercury_data_gml__type_ctor_info_number_0);
	MR_register_type_ctor_info(
		&mercury_data_gml__type_ctor_info_lexer_error_0);
	MR_register_type_ctor_info(
		&mercury_data_gml__type_ctor_info_gml_program_0);
	MR_register_type_ctor_info(
		&mercury_data_gml__type_ctor_info_extra_operator_0);
	MR_register_type_ctor_info(
		&mercury_data_gml__type_ctor_info_basic_token_0);
}


void mercury__gml__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__gml__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
