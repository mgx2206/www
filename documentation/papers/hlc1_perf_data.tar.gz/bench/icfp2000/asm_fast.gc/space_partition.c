/*
** Automatically generated from `space_partition.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__space_partition__init
ENDINIT
*/

#include "mercury_imp.h"
#line 433 "space_partition.m"

/* 
Fast Ray-Box Intersection
by Andrew Woo
from "Graphics Gems", Academic Press, 1990
*/

#define NUMDIM	3
#define RIGHT	0
#define LEFT	1
#define MIDDLE	2

Bool HitBoundingBox(double minB[3],double maxB[3], double origin[3],
		double dir[3], double coord[3]);

#line 37 "space_partition.c"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 42 "space_partition.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 49 "space_partition.c"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"


	#include <math.h>

	/*
	** Mathematical constants.
	**
	** The maximum number of significant decimal digits which
	** can be packed into an IEEE-754 extended precision
	** floating point number is 18.  Therefore 20 significant
	** decimal digits for these constants should be plenty.
	*/

	#define	ML_FLOAT_E		2.7182818284590452354
	#define	ML_FLOAT_PI		3.1415926535897932384
	#define	ML_FLOAT_LN2		0.69314718055994530941


#line 69 "space_partition.c"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#include <float.h>
	#include <math.h>


#line 77 "space_partition.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#define	ML_FLOAT_RADIX	FLT_RADIX	/* There is no DBL_RADIX. */

	#if defined USE_SINGLE_PREC_FLOAT
		#define	ML_FLOAT_MAX		FLT_MAX
		#define	ML_FLOAT_MIN		FLT_MIN
		#define	ML_FLOAT_EPSILON	FLT_EPSILON
		#define	ML_FLOAT_MANT_DIG	FLT_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	FLT_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	FLT_MAX_EXP
	#else
		#define	ML_FLOAT_MAX		DBL_MAX
		#define	ML_FLOAT_MIN		DBL_MIN
		#define	ML_FLOAT_EPSILON	DBL_EPSILON
		#define	ML_FLOAT_MANT_DIG	DBL_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	DBL_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	DBL_MAX_EXP
	#endif


#line 100 "space_partition.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 107 "space_partition.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_DETERMINISM_GUARD
#define ML_DETERMINISM_GUARD
	/*
	** The enumeration constants in this enum must be in the same
	** order as the functors in the Mercury type `determinism'
	** defined above.
	*/
	typedef enum {
		ML_DET,
		ML_SEMIDET,
		ML_CC_MULTI,
		ML_CC_NONDET,
		ML_MULTI,
		ML_NONDET,
		ML_ERRONEOUS,
		ML_FAILURE
	} ML_Determinism;
#endif

#line 130 "space_partition.c"
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* protect against multiple inclusion */
#ifndef MR_HLC_EXCEPTION_GUARD
#define MR_HLC_EXCEPTION_GUARD

#ifdef MR_HIGHLEVEL_CODE

  #ifdef MR_USE_GCC_NESTED_FUNCTIONS
  	#define MR_CONT_PARAMS		MR_NestedCont cont
  	#define MR_CONT_PARAM_TYPES	MR_NestedCont
  	#define MR_CONT_ARGS		cont
  #else
  	#define MR_CONT_PARAMS		MR_Cont cont, void *cont_env
  	#define MR_CONT_PARAM_TYPES	MR_Cont, void *
  	#define MR_CONT_ARGS		cont, cont_env
  #endif

	/* det */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_0(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* semidet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_1(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_2(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_nondet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_3(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_4(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

	/* nondet */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_5(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

  #ifndef MR_AVOID_MACROS

	/* det ==> model_det */
	#define mercury__exception__builtin_catch_3_p_0 		mercury__exception__builtin_catch_model_det

	/* semidet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_1 		mercury__exception__builtin_catch_model_semi

	/* cc_multi ==> model_det */
	#define mercury__exception__builtin_catch_3_p_2 		mercury__exception__builtin_catch_model_det

	/* cc_nondet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_3 		mercury__exception__builtin_catch_model_semi

	/* multi ==> model_non */
	#define mercury__exception__builtin_catch_3_p_4 		mercury__exception__builtin_catch_model_non

	/* nondet ==> model_non */
	#define mercury__exception__builtin_catch_3_p_5 		mercury__exception__builtin_catch_model_non

  #endif /* !MR_AVOID_MACROS */

	void MR_CALL mercury__exception__builtin_throw_1_p_0(MR_Univ exception);

	void MR_CALL mercury__exception__builtin_catch_model_det(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	bool MR_CALL mercury__exception__builtin_catch_model_semi(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	void MR_CALL mercury__exception__builtin_catch_model_non(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

#endif /* MR_HIGHLEVEL_CODE */

#endif /* MR_HLC_EXCEPTION_GUARD */

#line 220 "space_partition.c"
#line 147 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

#ifndef MR_HIGHLEVEL_CODE
	#include <assert.h>
	#include <stdio.h>
	#include "mercury_deep_copy.h"
	#include "mercury_trace_base.h"
	#include "mercury_stack_trace.h"
	#include "mercury_layout_util.h"
	#include "mercury_deep_profiling_hand.h"

	MR_DECLARE_TYPE_CTOR_INFO_STRUCT( 			mercury_data_std_util__type_ctor_info_univ_0);
#endif

#line 235 "space_partition.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


#include "mercury_deep_copy.h"

#ifdef CONSERVATIVE_GC
  /* for conservative GC, shallow copies suffice */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		NewVal = OldVal;					\
	} while (0)
#else
  /*
  ** Note that we need to save/restore the MR_hp register, if it
  ** is transient, before/after calling MR_deep_copy().
  */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		MR_save_transient_hp();					\
		NewVal = MR_deep_copy(&OldVal, (MR_TypeInfo) TypeInfo_for_T,\
				(const MR_Word *) SolutionsHeapPtr,	\
				MR_ENGINE(MR_eng_solutions_heap_zone)->top);\
		MR_restore_transient_hp();				\
	} while (0)
#endif


#line 265 "space_partition.c"
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"

#include "mercury_heap.h"	/* for MR_incr_hp_msg() etc. */
#include "mercury_misc.h"	/* for MR_fatal_error() */
#include "mercury_string.h"	/* for MR_make_aligned_string() */

#line 272 "space_partition.c"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_TYPECTORDESC_GUARD
#define ML_TYPECTORDESC_GUARD

/*
** Values of type `std_util:type_desc' are represented the same way as
** values of type `private_builtin:type_info' (this representation is
** documented in compiler/polymorphism.m). Some parts of the library
** (e.g. the gc initialization code) depend on this.
** The C type corresponding to these Mercury types is `MR_TypeInfo'.
**
** Values of type `std_util:type_ctor_desc' are not guaranteed to be
** represented the same way as values of type `private_builtin:type_ctor_info'.
** The representations *are* in fact identical for first order types, but they
** differ for higher order and tuple types. Instead of a type_ctor_desc
** being a structure containing a pointer to the type_ctor_info for pred/0
** or func/0 and an arity, we have a single small encoded integer. This
** integer is four times the arity, plus zero, one or two; plus zero encodes a
** tuple, plus one encodes a predicate, plus two encodes a function.
** The maximum arity that can be encoded is given by MR_MAX_VARIABLE_ARITY
** (see below).
** The C type corresponding to std_util:type_ctor_desc is `MR_TypeCtorDesc'.
*/

/*
** Declare the MR_TypeCtorDesc ADT.
**
** Note that `struct MR_TypeCtorDesc_Struct' is deliberately left undefined.
** MR_TypeCtorDesc is declared as a pointer to a dummy structure only
** in order to allow the C compiler to catch errors in which things other
** than MR_TypeCtorDescs are given as arguments to macros that depend on their
** arguments being MR_TypeCtorDescs. The actual value is either a small integer
** or a pointer to a MR_TypeCtorInfo_Struct structure, as described above.
*/
typedef struct MR_TypeCtorDesc_Struct *MR_TypeCtorDesc;

/*
** The maximum arity that can be encoded should be set to twice the maximum
** number of general purpose registers, since an predicate or function having
** more arguments that this would run out of registers when passing the input
** arguments, or the output arguments, or both.
**
** XXX When tuples were added this was reduced to be the maximum number
** of general purpose registers, to reduce the probability that the
** `small' integers for higher-order and tuple types are confused with
** type_ctor_info pointers. This still allows higher-order terms with
** 1024 arguments, which is more than ../LIMITATIONS promises.
*/
#define MR_MAX_VARIABLE_ARITY         MR_MAX_VIRTUAL_REG

/*
** Constructors for the MR_TypeCtorDesc ADT
*/

#define MR_TYPECTOR_DESC_MAKE_PRED(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4) )
#define MR_TYPECTOR_DESC_MAKE_FUNC(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4 + 1) )
#define MR_TYPECTOR_DESC_MAKE_TUPLE(Arity)                                      ( (MR_TypeCtorDesc) ((Arity) * 4 + 2) )
#define MR_TYPECTOR_DESC_MAKE_FIXED_ARITY(type_ctor_info)                       ( MR_CHECK_EXPR_TYPE(type_ctor_info, MR_TypeCtorInfo),                    (MR_TypeCtorDesc) type_ctor_info )

/*
** Access macros for the MR_TypeCtor ADT.
**
** The MR_TYPECTOR_DESC_GET_VA_* macros should only be called if
** MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns true.
** The MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO() macro
** should only be called if MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns false.
*/
#define MR_TYPECTOR_DESC_IS_VARIABLE_ARITY(T)                                   ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) <= (4 * MR_MAX_VARIABLE_ARITY + 2) )
#define MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO(T)                      ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_TypeCtorInfo) (T) )
#define MR_TYPECTOR_DESC_GET_VA_ARITY(T)                                        ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) / 4 )
#define MR_TYPECTOR_DESC_GET_VA_NAME(T)                                         ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) (((MR_Unsigned) (T) % 4 == 0)                                ? "pred"                                                              : (((MR_Unsigned) (T) % 4 == 1)                                             ? "func"                                                              : "{}" )) )
#define MR_TYPECTOR_DESC_GET_VA_MODULE_NAME(T)                                  ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) "builtin" )
#define MR_TYPECTOR_DESC_GET_VA_TYPE_CTOR_INFO(T)                               ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 ((MR_Unsigned) (T) % 4 == 0)                                                  ? MR_TYPE_CTOR_INFO_HO_PRED                                             : (((MR_Unsigned) (T) % 4 == 1)                                            ? MR_TYPE_CTOR_INFO_HO_FUNC                                             : MR_TYPE_CTOR_INFO_TUPLE ) )

#endif /* ML_TYPECTORDESC_GUARD */


#line 353 "space_partition.c"
#line 126 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_CONSTRUCT_INFO_GUARD
#define ML_CONSTRUCT_INFO_GUARD

typedef struct ML_Construct_Info_Struct {
    MR_ConstString          functor_name;
    MR_Integer              arity;
    const MR_PseudoTypeInfo *arg_pseudo_type_infos;
    MR_ConstString          *arg_names;
    MR_TypeCtorRep          type_ctor_rep;
    union {
        const MR_EnumFunctorDesc  *enum_functor_desc;
        const MR_NotagFunctorDesc *notag_functor_desc;
        const MR_DuFunctorDesc    *du_functor_desc;
    }                       functor_info;
} ML_Construct_Info;

#endif

extern  void            ML_type_ctor_and_args(MR_TypeInfo type_info,
                            bool collapse_equivalences,
                            MR_TypeCtorDesc *type_ctor_desc_ptr,
                            MR_Word *arg_type_info_list_ptr);
extern  int     	    ML_get_num_functors(MR_TypeInfo type_info);
extern	MR_Word		    ML_type_params_vector_to_list(int arity,
                            MR_TypeInfoParams type_params);
extern	MR_Word		    ML_arg_name_vector_to_list(int arity,
                            MR_ConstString *arg_names);
extern	MR_Word		    ML_pseudo_type_info_vector_to_type_info_list(int arity,
                            MR_TypeInfoParams type_params,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  bool    	    ML_get_functors_check_range(int functor_number,
                            MR_TypeInfo type_info,
                            ML_Construct_Info *construct_info);
extern  void    	    ML_copy_arguments_from_list_to_vector(int arity,
                            MR_Word arg_list, MR_Word term_vector);
extern  bool    	    ML_typecheck_arguments(MR_TypeInfo type_info,
                            int arity, MR_Word arg_list,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  MR_TypeInfo	    ML_make_type(int arity, MR_TypeCtorDesc type_ctor_desc,
				             MR_Word arg_type_list);

#line 399 "space_partition.c"
#line 170 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


extern	MR_TypeCtorDesc ML_make_type_ctor_desc(MR_TypeInfo type_info,
				MR_TypeCtorInfo type_ctor_info);


#line 407 "space_partition.c"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


    #include <stdio.h>
	#include "mercury_library_types.h"		/* for MR_ArrayType */

#ifdef MR_DEEP_PROFILING
    #include "mercury_deep_profiling.h"
#endif

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef	ML_EXPAND_INFO_GUARD
#define	ML_EXPAND_INFO_GUARD

typedef struct {
    int                     num_extra_args;
    MR_Word                 *arg_values;
    MR_TypeInfo             *arg_type_infos;
    bool                    can_free_arg_type_infos;
} ML_Expand_Args_Fields;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
} ML_Expand_Functor_Args_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
    bool                    limit_reached;
} ML_Expand_Functor_Args_Limit_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor_only;
} ML_Expand_Functor_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    ML_Expand_Args_Fields   args_only;
} ML_Expand_Args_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    bool                    chosen_index_exists;
    MR_Word                 *chosen_value_ptr;
    MR_TypeInfo             chosen_type_info;
} ML_Expand_Chosen_Arg_Only_Info;

    /* Prototypes */

extern  void    ML_expand_functor_args(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Args_Info *expand_info);

extern  void    ML_expand_functor_args_limit(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int max_arity,
                    ML_Expand_Functor_Args_Limit_Info *expand_info);

extern  void    ML_expand_functor_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Only_Info *expand_info);

extern  void    ML_expand_args_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Args_Only_Info *expand_info);

extern  void    ML_expand_chosen_arg_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int chosen,
                    ML_Expand_Chosen_Arg_Only_Info *expand_info);

    /*
    ** NB. ML_arg() is also used by arg_ref and new_arg_ref
    ** in store.m, in trace/mercury_trace_vars.m, and in
    ** extras/trailed_update/tr_store.m.
    */
extern  bool    ML_arg(MR_TypeInfo type_info, MR_Word *term, int arg_index,
                    MR_TypeInfo *arg_type_info_ptr, MR_Word **argument_ptr);

    /*
    ** NB. ML_named_arg_num() is used in mercury_trace_vars.c.
    */
extern  bool    ML_named_arg_num(MR_TypeInfo type_info, MR_Word *term_ptr,
                    const char *arg_name, int *arg_num_ptr);

/*
** The following macros factor out the common parts of the various
** deconstruction predicates.
*/

    /*
    ** Check for attempts to deconstruct a non-canonical type.
    ** Such deconstructions must be cc_multi, which is why we treat
    ** violations of this as runtime errors in det deconstruction
    ** predicates.
    ** (There ought to be cc_multi versions of those predicates.)
    */
#define ML_abort_if_type_is_noncanonical(ei, predname)                  do {                                                                    if ((ei).non_canonical_type) {                                          MR_fatal_error("called " predname " for a type "                    "with a user-defined equality predicate");                }                                                               } while (0)

#endif

#define ML_deconstruct_get_functor(ei, functor_field, var)              do {                                                                    MR_make_aligned_string(MR_LVALUE_CAST(MR_ConstString, var),             (ei).functor_field);                                        } while (0)

#define ML_deconstruct_get_arity(ei, var)                               do {                                                                    var = (ei).arity;                                               } while (0)

#define ML_deconstruct_get_arg_list(ei, args_field, var)                do {                                                                    int     i;                                                                                                                              var = MR_list_empty_msg(MR_PROC_LABEL);                             i = (ei).arity;                                                                                                                         while (--i >= 0) {                                                      MR_Word arg;                                                                                                                                /* Create an argument on the heap */                            MR_new_univ_on_hp(arg,                                                  (ei).args_field.arg_type_infos[i],                                  (ei).args_field.arg_values[i +                                          (ei).args_field.num_extra_args]);                                                                                                   /* Join the argument to the front of the list */                var = MR_list_cons_msg(arg, var, MR_PROC_LABEL);                }                                                               } while (0)

    /*
    ** Free any arg_type_infos allocated by the ML_expand variant.
    ** Should be called after we have used them for the last time.
    */
#define ML_deconstruct_free_allocated_arg_type_infos(ei, args_field)    do {                                                                    if ((ei).args_field.can_free_arg_type_infos) {                          MR_GC_free((ei).args_field.arg_type_infos);                     }                                                               } while (0)


#line 529 "space_partition.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 532 "space_partition.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 538 "space_partition.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 546 "space_partition.c"


static const struct mercury_data_space_partition__common_0_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_space_partition__common_0;

static const struct mercury_data_space_partition__common_1_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_space_partition__common_1;

static const struct mercury_data_space_partition__common_2_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_data_space_partition__common_2;

static const struct mercury_data_space_partition__common_3_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_space_partition__common_3;

static const struct mercury_data_space_partition__common_4_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_data_space_partition__common_4;

static const struct mercury_data_space_partition__common_5_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_space_partition__common_5;

static const struct mercury_data_space_partition__common_6_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_data_space_partition__common_6;
extern const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_surface_area_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_subtree_result_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_space_tree_object_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_space_tree_node_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_space_tree_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_scene_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_normal_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_invalid_transformation_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_invalid_object_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_bounding_box_0;
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_subtree_result_0[];
static const MR_DuFunctorDesc mercury_data_space_partition__du_functor_desc_subtree_result_0_0;
extern const MR_PseudoTypeInfo mercury_data_space_partition__field_types_subtree_result_0_0[];
#ifndef MR_FO_PseudoTypeInfo_Struct2_GUARD
#define MR_FO_PseudoTypeInfo_Struct2_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct2, 2);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct2 mercury_data_std_util__type_info_pair_2__type0_16_vector__vector_0__type0_16_vector__vector_0;
extern const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_subtree_result_0[];
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_stag_ordered_subtree_result_0_0[];
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_space_tree_object_0[];
static const MR_DuFunctorDesc mercury_data_space_partition__du_functor_desc_space_tree_object_0_0;
extern const MR_PseudoTypeInfo mercury_data_space_partition__field_types_space_tree_object_0_0[];
extern const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_space_tree_object_0[];
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_stag_ordered_space_tree_object_0_0[];
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_space_tree_node_0[];
static const MR_DuFunctorDesc mercury_data_space_partition__du_functor_desc_space_tree_node_0_0;
extern const MR_PseudoTypeInfo mercury_data_space_partition__field_types_space_tree_node_0_0[];
static const MR_DuFunctorDesc mercury_data_space_partition__du_functor_desc_space_tree_node_0_1;
extern const MR_PseudoTypeInfo mercury_data_space_partition__field_types_space_tree_node_0_1[];
extern const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_space_tree_node_0[];
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_stag_ordered_space_tree_node_0_0[];
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_stag_ordered_space_tree_node_0_1[];
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_space_tree_0[];
static const MR_DuFunctorDesc mercury_data_space_partition__du_functor_desc_space_tree_0_0;
extern const MR_PseudoTypeInfo mercury_data_space_partition__field_types_space_tree_0_0[];
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_34_space_partition__space_tree_node_0;
extern const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_space_tree_0[];
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_stag_ordered_space_tree_0_0[];
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_scene_0[];
static const MR_DuFunctorDesc mercury_data_space_partition__du_functor_desc_scene_0_0;
extern const MR_PseudoTypeInfo mercury_data_space_partition__field_types_scene_0_0[];
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_14_eval__object_0;
extern const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_scene_0[];
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_stag_ordered_scene_0_0[];
static const MR_NotagFunctorDesc mercury_data_space_partition__notag_functor_desc_invalid_transformation_0;
static const MR_NotagFunctorDesc mercury_data_space_partition__notag_functor_desc_invalid_object_0;
MR_declare_static(mercury__space_partition__list__map__ho6__ua0_3_0);
MR_declare_label(mercury__space_partition__list__map__ho6__ua0_3_0_i4);
MR_declare_label(mercury__space_partition__list__map__ho6__ua0_3_0_i5);
MR_declare_label(mercury__space_partition__list__map__ho6__ua0_3_0_i2);
MR_declare_static(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0);
MR_declare_label(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i3);
MR_declare_label(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i4);
MR_declare_label(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i5);
MR_declare_label(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i6);
MR_declare_static(mercury__space_partition__list__map__ho7_3_0);
MR_declare_label(mercury__space_partition__list__map__ho7_3_0_i4);
MR_declare_label(mercury__space_partition__list__map__ho7_3_0_i5);
MR_declare_label(mercury__space_partition__list__map__ho7_3_0_i3);
MR_declare_static(mercury__space_partition__list__foldl__ho3_4_0);
MR_declare_label(mercury__space_partition__list__foldl__ho3_4_0_i4);
MR_declare_label(mercury__space_partition__list__foldl__ho3_4_0_i3);
MR_declare_static(mercury__fn__space_partition__IntroducedFrom__func__build_space_tree__253__2_1_0);
MR_declare_label(mercury__fn__space_partition__IntroducedFrom__func__build_space_tree__253__2_1_0_i2);
MR_define_extern_entry(mercury__fn__space_partition__create_scene_1_0);
MR_declare_label(mercury__fn__space_partition__create_scene_1_0_i2);
MR_declare_label(mercury__fn__space_partition__create_scene_1_0_i3);
MR_define_extern_entry(mercury__space_partition__traverse_space_tree_4_0);
MR_declare_label(mercury__space_partition__traverse_space_tree_4_0_i4);
MR_define_extern_entry(mercury__fn__space_partition__find_object_bounding_box_1_0);
MR_declare_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i4);
MR_declare_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i6);
MR_declare_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i7);
MR_declare_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i8);
MR_declare_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i10);
MR_declare_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i11);
MR_declare_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i15);
MR_declare_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i17);
MR_declare_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i16);
MR_declare_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i21);
MR_declare_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i22);
MR_declare_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i23);
MR_declare_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i24);
MR_define_extern_entry(mercury__fn__space_partition__transform_bounding_box_2_0);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i2);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i3);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i4);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i5);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i6);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i7);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i8);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i9);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i10);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i11);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i12);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i13);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i14);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i15);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i16);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i17);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i18);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i19);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i20);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i21);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i22);
MR_declare_label(mercury__fn__space_partition__transform_bounding_box_2_0_i23);
MR_define_extern_entry(mercury__space_partition__split_partitionable_objects_3_0);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i4);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i5);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i8);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i9);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i10);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i12);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i13);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i14);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i15);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i16);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i17);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i23);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i25);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i21);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i19);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i18);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i32);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i34);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i30);
MR_declare_label(mercury__space_partition__split_partitionable_objects_3_0_i28);
MR_declare_static(mercury__fn__space_partition__object_contains_plane_1_0);
MR_declare_label(mercury__fn__space_partition__object_contains_plane_1_0_i4);
MR_declare_label(mercury__fn__space_partition__object_contains_plane_1_0_i8);
MR_declare_label(mercury__fn__space_partition__object_contains_plane_1_0_i10);
MR_declare_label(mercury__fn__space_partition__object_contains_plane_1_0_i11);
MR_declare_label(mercury__fn__space_partition__object_contains_plane_1_0_i12);
MR_declare_label(mercury__fn__space_partition__object_contains_plane_1_0_i15);
MR_declare_label(mercury__fn__space_partition__object_contains_plane_1_0_i17);
MR_declare_label(mercury__fn__space_partition__object_contains_plane_1_0_i18);
MR_declare_label(mercury__fn__space_partition__object_contains_plane_1_0_i16);
MR_declare_label(mercury__fn__space_partition__object_contains_plane_1_0_i21);
MR_declare_label(mercury__fn__space_partition__object_contains_plane_1_0_i22);
MR_declare_label(mercury__fn__space_partition__object_contains_plane_1_0_i29);
MR_declare_label(mercury__fn__space_partition__object_contains_plane_1_0_i2);
MR_declare_static(mercury__fn__space_partition__min_point_2_0);
MR_declare_label(mercury__fn__space_partition__min_point_2_0_i2);
MR_declare_label(mercury__fn__space_partition__min_point_2_0_i4);
MR_declare_label(mercury__fn__space_partition__min_point_2_0_i6);
MR_declare_static(mercury__fn__space_partition__max_point_2_0);
MR_declare_label(mercury__fn__space_partition__max_point_2_0_i2);
MR_declare_label(mercury__fn__space_partition__max_point_2_0_i4);
MR_declare_label(mercury__fn__space_partition__max_point_2_0_i6);
MR_declare_static(mercury__fn__space_partition__find_basic_object_bounding_box_1_0);
MR_declare_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i4);
MR_declare_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i5);
MR_declare_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i6);
MR_declare_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i7);
MR_declare_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i8);
MR_define_extern_entry(mercury__fn__space_partition__build_space_tree_1_0);
MR_declare_static(mercury__space_partition__space_tree_insert_3_0);
MR_declare_label(mercury__space_partition__space_tree_insert_3_0_i2);
MR_declare_label(mercury__space_partition__space_tree_insert_3_0_i3);
MR_declare_label(mercury__space_partition__space_tree_insert_3_0_i4);
MR_declare_label(mercury__space_partition__space_tree_insert_3_0_i6);
MR_declare_label(mercury__space_partition__space_tree_insert_3_0_i9);
MR_declare_label(mercury__space_partition__space_tree_insert_3_0_i10);
MR_declare_static(mercury__space_partition__select_subtree_5_0);
MR_declare_label(mercury__space_partition__select_subtree_5_0_i6);
MR_declare_label(mercury__space_partition__select_subtree_5_0_i7);
MR_declare_label(mercury__space_partition__select_subtree_5_0_i8);
MR_declare_label(mercury__space_partition__select_subtree_5_0_i3);
MR_declare_static(mercury__space_partition__subtree_insert_4_0);
MR_declare_label(mercury__space_partition__subtree_insert_4_0_i3);
MR_declare_label(mercury__space_partition__subtree_insert_4_0_i8);
MR_declare_label(mercury__space_partition__subtree_insert_4_0_i7);
MR_declare_label(mercury__space_partition__subtree_insert_4_0_i9);
MR_declare_label(mercury__space_partition__subtree_insert_4_0_i10);
MR_declare_label(mercury__space_partition__subtree_insert_4_0_i4);
MR_declare_label(mercury__space_partition__subtree_insert_4_0_i11);
MR_declare_static(mercury__space_partition__intersect_bounding_box_2_12_0);
MR_declare_label(mercury__space_partition__intersect_bounding_box_2_12_0_i2);
MR_declare_static(mercury__space_partition__traverse_space_tree_nodes_5_0);
MR_declare_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i6);
MR_declare_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i5);
MR_declare_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i7);
MR_declare_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i11);
MR_declare_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i10);
MR_declare_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i13);
MR_declare_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i3);
MR_define_extern_entry(mercury____Unify___space_partition__scene_0_0);
MR_declare_label(mercury____Unify___space_partition__scene_0_0_i2);
MR_declare_label(mercury____Unify___space_partition__scene_0_0_i1);
MR_define_extern_entry(mercury____Compare___space_partition__scene_0_0);
MR_declare_label(mercury____Compare___space_partition__scene_0_0_i3);
MR_declare_label(mercury____Compare___space_partition__scene_0_0_i7);
MR_define_extern_entry(mercury____Unify___space_partition__invalid_transformation_0_0);
MR_define_extern_entry(mercury____Compare___space_partition__invalid_transformation_0_0);
MR_define_extern_entry(mercury____Unify___space_partition__invalid_object_0_0);
MR_define_extern_entry(mercury____Compare___space_partition__invalid_object_0_0);
MR_define_extern_entry(mercury____Unify___space_partition__normal_0_0);
MR_define_extern_entry(mercury____Compare___space_partition__normal_0_0);
MR_define_extern_entry(mercury____Unify___space_partition__surface_area_0_0);
MR_define_extern_entry(mercury____Compare___space_partition__surface_area_0_0);
MR_declare_label(mercury____Compare___space_partition__surface_area_0_0_i2);
MR_declare_label(mercury____Compare___space_partition__surface_area_0_0_i3);
MR_define_extern_entry(mercury____Unify___space_partition__space_tree_0_0);
MR_declare_label(mercury____Unify___space_partition__space_tree_0_0_i2);
MR_declare_label(mercury____Unify___space_partition__space_tree_0_0_i1);
MR_define_extern_entry(mercury____Compare___space_partition__space_tree_0_0);
MR_declare_label(mercury____Compare___space_partition__space_tree_0_0_i3);
MR_declare_label(mercury____Compare___space_partition__space_tree_0_0_i8);
MR_declare_label(mercury____Compare___space_partition__space_tree_0_0_i7);
MR_declare_label(mercury____Compare___space_partition__space_tree_0_0_i20);
MR_define_extern_entry(mercury____Unify___space_partition__space_tree_node_0_0);
MR_declare_label(mercury____Unify___space_partition__space_tree_node_0_0_i3);
MR_declare_label(mercury____Unify___space_partition__space_tree_node_0_0_i1);
MR_define_extern_entry(mercury____Compare___space_partition__space_tree_node_0_0);
MR_declare_label(mercury____Compare___space_partition__space_tree_node_0_0_i5);
MR_declare_label(mercury____Compare___space_partition__space_tree_node_0_0_i3);
MR_declare_label(mercury____Compare___space_partition__space_tree_node_0_0_i8);
MR_define_extern_entry(mercury____Unify___space_partition__space_tree_object_0_0);
MR_declare_label(mercury____Unify___space_partition__space_tree_object_0_0_i2);
MR_declare_label(mercury____Unify___space_partition__space_tree_object_0_0_i1);
MR_define_extern_entry(mercury____Compare___space_partition__space_tree_object_0_0);
MR_declare_label(mercury____Compare___space_partition__space_tree_object_0_0_i3);
MR_declare_label(mercury____Compare___space_partition__space_tree_object_0_0_i8);
MR_declare_label(mercury____Compare___space_partition__space_tree_object_0_0_i7);
MR_declare_label(mercury____Compare___space_partition__space_tree_object_0_0_i20);
MR_define_extern_entry(mercury____Unify___space_partition__bounding_box_0_0);
MR_define_extern_entry(mercury____Compare___space_partition__bounding_box_0_0);
MR_define_extern_entry(mercury____Unify___space_partition__subtree_result_0_0);
MR_declare_label(mercury____Unify___space_partition__subtree_result_0_0_i2);
MR_declare_label(mercury____Unify___space_partition__subtree_result_0_0_i1);
MR_define_extern_entry(mercury____Compare___space_partition__subtree_result_0_0);
MR_declare_label(mercury____Compare___space_partition__subtree_result_0_0_i3);
MR_declare_label(mercury____Compare___space_partition__subtree_result_0_0_i8);
MR_declare_label(mercury____Compare___space_partition__subtree_result_0_0_i7);
MR_declare_label(mercury____Compare___space_partition__subtree_result_0_0_i18);
MR_declare_label(mercury____Compare___space_partition__subtree_result_0_0_i19);
MR_declare_label(mercury____Compare___space_partition__subtree_result_0_0_i23);

static const MR_Float mercury_float_const_neg1pt00000000000000 = -1.00000000000000;
static const struct mercury_data_space_partition__common_0_struct mercury_data_space_partition__common_0 = {
	(MR_Word *) &mercury_float_const_neg1pt00000000000000,
	(MR_Word *) &mercury_float_const_neg1pt00000000000000,
	(MR_Word *) &mercury_float_const_neg1pt00000000000000
};

static const MR_Float mercury_float_const_1pt00000000000000 = 1.00000000000000;
static const struct mercury_data_space_partition__common_1_struct mercury_data_space_partition__common_1 = {
	(MR_Word *) &mercury_float_const_1pt00000000000000,
	(MR_Word *) &mercury_float_const_1pt00000000000000,
	(MR_Word *) &mercury_float_const_1pt00000000000000
};

static const struct mercury_data_space_partition__common_2_struct mercury_data_space_partition__common_2 = {
	MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_space_partition__common_0),
	MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_space_partition__common_1)
};

static const MR_Float mercury_float_const_0pt00000000000000 = 0.00000000000000;
static const struct mercury_data_space_partition__common_3_struct mercury_data_space_partition__common_3 = {
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000
};

static const struct mercury_data_space_partition__common_4_struct mercury_data_space_partition__common_4 = {
	MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_space_partition__common_3),
	MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_space_partition__common_1)
};

static const struct mercury_data_space_partition__common_5_struct mercury_data_space_partition__common_5 = {
	(MR_Word *) &mercury_float_const_neg1pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_neg1pt00000000000000
};

static const struct mercury_data_space_partition__common_6_struct mercury_data_space_partition__common_6 = {
	MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_space_partition__common_5),
	MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_space_partition__common_1)
};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_float_0;

const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_surface_area_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__surface_area_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__surface_area_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___space_partition__surface_area_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"space_partition",
	"surface_area",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0 },
	-1,
	-1
};
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_subtree_result_0[];
extern const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_subtree_result_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_subtree_result_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__subtree_result_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__subtree_result_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___space_partition__subtree_result_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"space_partition",
	"subtree_result",
	4,
	{ (void *) mercury_data_space_partition__du_name_ordered_subtree_result_0 },
	{ (void *) mercury_data_space_partition__du_ptag_ordered_subtree_result_0 },
	1,
	1
};
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_space_tree_object_0[];
extern const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_space_tree_object_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_space_tree_object_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__space_tree_object_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__space_tree_object_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___space_partition__space_tree_object_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"space_partition",
	"space_tree_object",
	4,
	{ (void *) mercury_data_space_partition__du_name_ordered_space_tree_object_0 },
	{ (void *) mercury_data_space_partition__du_ptag_ordered_space_tree_object_0 },
	1,
	1
};
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_space_tree_node_0[];
extern const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_space_tree_node_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_space_tree_node_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__space_tree_node_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__space_tree_node_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___space_partition__space_tree_node_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"space_partition",
	"space_tree_node",
	4,
	{ (void *) mercury_data_space_partition__du_name_ordered_space_tree_node_0 },
	{ (void *) mercury_data_space_partition__du_ptag_ordered_space_tree_node_0 },
	2,
	2
};
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_space_tree_0[];
extern const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_space_tree_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_space_tree_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__space_tree_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__space_tree_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___space_partition__space_tree_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"space_partition",
	"space_tree",
	4,
	{ (void *) mercury_data_space_partition__du_name_ordered_space_tree_0 },
	{ (void *) mercury_data_space_partition__du_ptag_ordered_space_tree_0 },
	1,
	1
};
extern const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_scene_0[];
extern const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_scene_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_scene_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__scene_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__scene_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___space_partition__scene_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"space_partition",
	"scene",
	4,
	{ (void *) mercury_data_space_partition__du_name_ordered_scene_0 },
	{ (void *) mercury_data_space_partition__du_ptag_ordered_scene_0 },
	1,
	1
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_vector_0;

const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_normal_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__normal_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__normal_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___space_partition__normal_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"space_partition",
	"normal",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0 },
	-1,
	-1
};
static const MR_NotagFunctorDesc mercury_data_space_partition__notag_functor_desc_invalid_transformation_0;
static const MR_NotagFunctorDesc mercury_data_space_partition__notag_functor_desc_invalid_transformation_0;

const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_invalid_transformation_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__invalid_transformation_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__invalid_transformation_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___space_partition__invalid_transformation_0_0)),
	MR_TYPECTOR_REP_NOTAG_GROUND,
	NULL,
	NULL,
	"space_partition",
	"invalid_transformation",
	4,
	{ (void *) &mercury_data_space_partition__notag_functor_desc_invalid_transformation_0 },
	{ (void *) &mercury_data_space_partition__notag_functor_desc_invalid_transformation_0 },
	1,
	-1
};
static const MR_NotagFunctorDesc mercury_data_space_partition__notag_functor_desc_invalid_object_0;
static const MR_NotagFunctorDesc mercury_data_space_partition__notag_functor_desc_invalid_object_0;

const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_invalid_object_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__invalid_object_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__invalid_object_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___space_partition__invalid_object_0_0)),
	MR_TYPECTOR_REP_NOTAG_GROUND,
	NULL,
	NULL,
	"space_partition",
	"invalid_object",
	4,
	{ (void *) &mercury_data_space_partition__notag_functor_desc_invalid_object_0 },
	{ (void *) &mercury_data_space_partition__notag_functor_desc_invalid_object_0 },
	1,
	-1
};
#ifndef MR_FO_PseudoTypeInfo_Struct2_GUARD
#define MR_FO_PseudoTypeInfo_Struct2_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct2, 2);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct2 mercury_data_std_util__type_info_pair_2__type0_16_vector__vector_0__type0_16_vector__vector_0;

const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_bounding_box_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__bounding_box_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___space_partition__bounding_box_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___space_partition__bounding_box_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"space_partition",
	"bounding_box",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_std_util__type_info_pair_2__type0_16_vector__vector_0__type0_16_vector__vector_0 },
	-1,
	-1
};

const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_subtree_result_0[] = {
	&mercury_data_space_partition__du_functor_desc_subtree_result_0_0
};

static const MR_DuFunctorDesc mercury_data_space_partition__du_functor_desc_subtree_result_0_0 = {
	"subtree_result",
	3,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_space_partition__field_types_subtree_result_0_0,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;

const MR_PseudoTypeInfo mercury_data_space_partition__field_types_subtree_result_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_std_util__type_info_pair_2__type0_16_vector__vector_0__type0_16_vector__vector_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_std_util__type_ctor_info_pair_2;

#ifndef MR_FO_PseudoTypeInfo_Struct2_GUARD
#define MR_FO_PseudoTypeInfo_Struct2_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct2, 2);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct2 mercury_data_std_util__type_info_pair_2__type0_16_vector__vector_0__type0_16_vector__vector_0 = {
	&mercury_data_std_util__type_ctor_info_pair_2,
{	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0,
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0
}};

const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_subtree_result_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_space_partition__du_stag_ordered_subtree_result_0_0 }

};

const MR_DuFunctorDesc * mercury_data_space_partition__du_stag_ordered_subtree_result_0_0[] = {
	&mercury_data_space_partition__du_functor_desc_subtree_result_0_0

};

const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_space_tree_object_0[] = {
	&mercury_data_space_partition__du_functor_desc_space_tree_object_0_0
};

static const MR_DuFunctorDesc mercury_data_space_partition__du_functor_desc_space_tree_object_0_0 = {
	"space_tree_object",
	3,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_space_partition__field_types_space_tree_object_0_0,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_object_0;

const MR_PseudoTypeInfo mercury_data_space_partition__field_types_space_tree_object_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_std_util__type_info_pair_2__type0_16_vector__vector_0__type0_16_vector__vector_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_object_0
};

const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_space_tree_object_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_space_partition__du_stag_ordered_space_tree_object_0_0 }

};

const MR_DuFunctorDesc * mercury_data_space_partition__du_stag_ordered_space_tree_object_0_0[] = {
	&mercury_data_space_partition__du_functor_desc_space_tree_object_0_0

};

const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_space_tree_node_0[] = {
	&mercury_data_space_partition__du_functor_desc_space_tree_node_0_1,
	&mercury_data_space_partition__du_functor_desc_space_tree_node_0_0
};

static const MR_DuFunctorDesc mercury_data_space_partition__du_functor_desc_space_tree_node_0_0 = {
	"node",
	1,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_space_partition__field_types_space_tree_node_0_0,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_space_tree_0;

const MR_PseudoTypeInfo mercury_data_space_partition__field_types_space_tree_node_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_space_partition__type_ctor_info_space_tree_0
};

static const MR_DuFunctorDesc mercury_data_space_partition__du_functor_desc_space_tree_node_0_1 = {
	"leaf",
	1,
	0,
	MR_SECTAG_NONE,
	1,
	0,
	1,
	(MR_PseudoTypeInfo *) mercury_data_space_partition__field_types_space_tree_node_0_1,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_space_tree_object_0;

const MR_PseudoTypeInfo mercury_data_space_partition__field_types_space_tree_node_0_1[] = {
	(MR_PseudoTypeInfo) &mercury_data_space_partition__type_ctor_info_space_tree_object_0
};

const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_space_tree_node_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_space_partition__du_stag_ordered_space_tree_node_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_space_partition__du_stag_ordered_space_tree_node_0_1 }

};

const MR_DuFunctorDesc * mercury_data_space_partition__du_stag_ordered_space_tree_node_0_0[] = {
	&mercury_data_space_partition__du_functor_desc_space_tree_node_0_0

};

const MR_DuFunctorDesc * mercury_data_space_partition__du_stag_ordered_space_tree_node_0_1[] = {
	&mercury_data_space_partition__du_functor_desc_space_tree_node_0_1

};

const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_space_tree_0[] = {
	&mercury_data_space_partition__du_functor_desc_space_tree_0_0
};

static const MR_DuFunctorDesc mercury_data_space_partition__du_functor_desc_space_tree_0_0 = {
	"space_tree",
	3,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_space_partition__field_types_space_tree_0_0,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_space_partition__field_types_space_tree_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_std_util__type_info_pair_2__type0_16_vector__vector_0__type0_16_vector__vector_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_34_space_partition__space_tree_node_0
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_Struct mercury_data_space_partition__type_ctor_info_space_tree_node_0;

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_34_space_partition__space_tree_node_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_PseudoTypeInfo) &mercury_data_space_partition__type_ctor_info_space_tree_node_0
}};

const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_space_tree_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_space_partition__du_stag_ordered_space_tree_0_0 }

};

const MR_DuFunctorDesc * mercury_data_space_partition__du_stag_ordered_space_tree_0_0[] = {
	&mercury_data_space_partition__du_functor_desc_space_tree_0_0

};

const MR_DuFunctorDesc * mercury_data_space_partition__du_name_ordered_scene_0[] = {
	&mercury_data_space_partition__du_functor_desc_scene_0_0
};

static const MR_DuFunctorDesc mercury_data_space_partition__du_functor_desc_scene_0_0 = {
	"scene",
	2,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_space_partition__field_types_scene_0_0,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_space_partition__field_types_scene_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_space_partition__type_ctor_info_space_tree_0,
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_14_eval__object_0
};

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_14_eval__object_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_object_0
}};

const MR_DuPtagLayout mercury_data_space_partition__du_ptag_ordered_scene_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_space_partition__du_stag_ordered_scene_0_0 }

};

const MR_DuFunctorDesc * mercury_data_space_partition__du_stag_ordered_scene_0_0[] = {
	&mercury_data_space_partition__du_functor_desc_scene_0_0

};
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_transformation_0;

static const MR_NotagFunctorDesc mercury_data_space_partition__notag_functor_desc_invalid_transformation_0 = {
	"invalid_transformation",
	 (MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_transformation_0,
	NULL
};

static const MR_NotagFunctorDesc mercury_data_space_partition__notag_functor_desc_invalid_object_0 = {
	"invalid_object",
	 (MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_object_0,
	NULL
};

MR_declare_entry(mercury__fn__renderer__maybe_transformation_to_trans_1_0);
MR_declare_entry(mercury__fn__trans__transform_point_2_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_object_0;
MR_declare_entry(mercury__list__append_3_1);
MR_declare_entry(mercury__exception__throw_1_0);
MR_declare_entry(mercury__renderer__find_object_intersection_5_0);
MR_declare_entry(mercury____Unify___list__list_1_0);
MR_declare_entry(mercury____Compare___list__list_1_0);
MR_declare_entry(mercury____Unify___eval__transformation_0_0);
MR_declare_entry(mercury____Compare___eval__transformation_0_0);
MR_declare_entry(mercury____Unify___eval__object_0_0);
MR_declare_entry(mercury____Compare___eval__object_0_0);
MR_declare_entry(mercury____Unify___vector__vector_0_0);
MR_declare_entry(mercury____Compare___vector__vector_0_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_vector_0;
MR_declare_entry(mercury____Unify___std_util__pair_2_0);
MR_declare_entry(mercury____Compare___std_util__pair_2_0);

MR_BEGIN_MODULE(space_partition_module)
	MR_init_entry(mercury__space_partition__list__map__ho6__ua0_3_0);
	MR_init_label(mercury__space_partition__list__map__ho6__ua0_3_0_i4);
	MR_init_label(mercury__space_partition__list__map__ho6__ua0_3_0_i5);
	MR_init_label(mercury__space_partition__list__map__ho6__ua0_3_0_i2);
	MR_init_entry(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0);
	MR_init_label(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i3);
	MR_init_label(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i4);
	MR_init_label(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i5);
	MR_init_label(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i6);
	MR_init_entry(mercury__space_partition__list__map__ho7_3_0);
	MR_init_label(mercury__space_partition__list__map__ho7_3_0_i4);
	MR_init_label(mercury__space_partition__list__map__ho7_3_0_i5);
	MR_init_label(mercury__space_partition__list__map__ho7_3_0_i3);
	MR_init_entry(mercury__space_partition__list__foldl__ho3_4_0);
	MR_init_label(mercury__space_partition__list__foldl__ho3_4_0_i4);
	MR_init_label(mercury__space_partition__list__foldl__ho3_4_0_i3);
	MR_init_entry(mercury__fn__space_partition__IntroducedFrom__func__build_space_tree__253__2_1_0);
	MR_init_label(mercury__fn__space_partition__IntroducedFrom__func__build_space_tree__253__2_1_0_i2);
	MR_init_entry(mercury__fn__space_partition__create_scene_1_0);
	MR_init_label(mercury__fn__space_partition__create_scene_1_0_i2);
	MR_init_label(mercury__fn__space_partition__create_scene_1_0_i3);
	MR_init_entry(mercury__space_partition__traverse_space_tree_4_0);
	MR_init_label(mercury__space_partition__traverse_space_tree_4_0_i4);
	MR_init_entry(mercury__fn__space_partition__find_object_bounding_box_1_0);
	MR_init_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i4);
	MR_init_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i6);
	MR_init_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i7);
	MR_init_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i8);
	MR_init_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i10);
	MR_init_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i11);
	MR_init_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i15);
	MR_init_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i17);
	MR_init_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i16);
	MR_init_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i21);
	MR_init_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i22);
	MR_init_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i23);
	MR_init_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i24);
	MR_init_entry(mercury__fn__space_partition__transform_bounding_box_2_0);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i2);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i3);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i4);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i5);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i6);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i7);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i8);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i9);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i10);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i11);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i12);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i13);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i14);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i15);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i16);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i17);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i18);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i19);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i20);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i21);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i22);
	MR_init_label(mercury__fn__space_partition__transform_bounding_box_2_0_i23);
	MR_init_entry(mercury__space_partition__split_partitionable_objects_3_0);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i4);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i5);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i8);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i9);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i10);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i12);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i13);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i14);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i15);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i16);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i17);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i23);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i25);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i21);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i19);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i18);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i32);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i34);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i30);
	MR_init_label(mercury__space_partition__split_partitionable_objects_3_0_i28);
	MR_init_entry(mercury__fn__space_partition__object_contains_plane_1_0);
	MR_init_label(mercury__fn__space_partition__object_contains_plane_1_0_i4);
	MR_init_label(mercury__fn__space_partition__object_contains_plane_1_0_i8);
	MR_init_label(mercury__fn__space_partition__object_contains_plane_1_0_i10);
	MR_init_label(mercury__fn__space_partition__object_contains_plane_1_0_i11);
	MR_init_label(mercury__fn__space_partition__object_contains_plane_1_0_i12);
	MR_init_label(mercury__fn__space_partition__object_contains_plane_1_0_i15);
	MR_init_label(mercury__fn__space_partition__object_contains_plane_1_0_i17);
	MR_init_label(mercury__fn__space_partition__object_contains_plane_1_0_i18);
	MR_init_label(mercury__fn__space_partition__object_contains_plane_1_0_i16);
	MR_init_label(mercury__fn__space_partition__object_contains_plane_1_0_i21);
	MR_init_label(mercury__fn__space_partition__object_contains_plane_1_0_i22);
	MR_init_label(mercury__fn__space_partition__object_contains_plane_1_0_i29);
	MR_init_label(mercury__fn__space_partition__object_contains_plane_1_0_i2);
	MR_init_entry(mercury__fn__space_partition__min_point_2_0);
	MR_init_label(mercury__fn__space_partition__min_point_2_0_i2);
	MR_init_label(mercury__fn__space_partition__min_point_2_0_i4);
	MR_init_label(mercury__fn__space_partition__min_point_2_0_i6);
	MR_init_entry(mercury__fn__space_partition__max_point_2_0);
	MR_init_label(mercury__fn__space_partition__max_point_2_0_i2);
	MR_init_label(mercury__fn__space_partition__max_point_2_0_i4);
	MR_init_label(mercury__fn__space_partition__max_point_2_0_i6);
	MR_init_entry(mercury__fn__space_partition__find_basic_object_bounding_box_1_0);
	MR_init_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i4);
	MR_init_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i5);
	MR_init_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i6);
	MR_init_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i7);
	MR_init_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i8);
	MR_init_entry(mercury__fn__space_partition__build_space_tree_1_0);
	MR_init_entry(mercury__space_partition__space_tree_insert_3_0);
	MR_init_label(mercury__space_partition__space_tree_insert_3_0_i2);
	MR_init_label(mercury__space_partition__space_tree_insert_3_0_i3);
	MR_init_label(mercury__space_partition__space_tree_insert_3_0_i4);
	MR_init_label(mercury__space_partition__space_tree_insert_3_0_i6);
	MR_init_label(mercury__space_partition__space_tree_insert_3_0_i9);
	MR_init_label(mercury__space_partition__space_tree_insert_3_0_i10);
	MR_init_entry(mercury__space_partition__select_subtree_5_0);
	MR_init_label(mercury__space_partition__select_subtree_5_0_i6);
	MR_init_label(mercury__space_partition__select_subtree_5_0_i7);
	MR_init_label(mercury__space_partition__select_subtree_5_0_i8);
	MR_init_label(mercury__space_partition__select_subtree_5_0_i3);
	MR_init_entry(mercury__space_partition__subtree_insert_4_0);
	MR_init_label(mercury__space_partition__subtree_insert_4_0_i3);
	MR_init_label(mercury__space_partition__subtree_insert_4_0_i8);
	MR_init_label(mercury__space_partition__subtree_insert_4_0_i7);
	MR_init_label(mercury__space_partition__subtree_insert_4_0_i9);
	MR_init_label(mercury__space_partition__subtree_insert_4_0_i10);
	MR_init_label(mercury__space_partition__subtree_insert_4_0_i4);
	MR_init_label(mercury__space_partition__subtree_insert_4_0_i11);
	MR_init_entry(mercury__space_partition__intersect_bounding_box_2_12_0);
	MR_init_label(mercury__space_partition__intersect_bounding_box_2_12_0_i2);
	MR_init_entry(mercury__space_partition__traverse_space_tree_nodes_5_0);
	MR_init_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i6);
	MR_init_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i5);
	MR_init_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i7);
	MR_init_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i11);
	MR_init_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i10);
	MR_init_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i13);
	MR_init_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i3);
	MR_init_entry(mercury____Unify___space_partition__scene_0_0);
	MR_init_label(mercury____Unify___space_partition__scene_0_0_i2);
	MR_init_label(mercury____Unify___space_partition__scene_0_0_i1);
	MR_init_entry(mercury____Compare___space_partition__scene_0_0);
	MR_init_label(mercury____Compare___space_partition__scene_0_0_i3);
	MR_init_label(mercury____Compare___space_partition__scene_0_0_i7);
	MR_init_entry(mercury____Unify___space_partition__invalid_transformation_0_0);
	MR_init_entry(mercury____Compare___space_partition__invalid_transformation_0_0);
	MR_init_entry(mercury____Unify___space_partition__invalid_object_0_0);
	MR_init_entry(mercury____Compare___space_partition__invalid_object_0_0);
	MR_init_entry(mercury____Unify___space_partition__normal_0_0);
	MR_init_entry(mercury____Compare___space_partition__normal_0_0);
	MR_init_entry(mercury____Unify___space_partition__surface_area_0_0);
	MR_init_entry(mercury____Compare___space_partition__surface_area_0_0);
	MR_init_label(mercury____Compare___space_partition__surface_area_0_0_i2);
	MR_init_label(mercury____Compare___space_partition__surface_area_0_0_i3);
	MR_init_entry(mercury____Unify___space_partition__space_tree_0_0);
	MR_init_label(mercury____Unify___space_partition__space_tree_0_0_i2);
	MR_init_label(mercury____Unify___space_partition__space_tree_0_0_i1);
	MR_init_entry(mercury____Compare___space_partition__space_tree_0_0);
	MR_init_label(mercury____Compare___space_partition__space_tree_0_0_i3);
	MR_init_label(mercury____Compare___space_partition__space_tree_0_0_i8);
	MR_init_label(mercury____Compare___space_partition__space_tree_0_0_i7);
	MR_init_label(mercury____Compare___space_partition__space_tree_0_0_i20);
	MR_init_entry(mercury____Unify___space_partition__space_tree_node_0_0);
	MR_init_label(mercury____Unify___space_partition__space_tree_node_0_0_i3);
	MR_init_label(mercury____Unify___space_partition__space_tree_node_0_0_i1);
	MR_init_entry(mercury____Compare___space_partition__space_tree_node_0_0);
	MR_init_label(mercury____Compare___space_partition__space_tree_node_0_0_i5);
	MR_init_label(mercury____Compare___space_partition__space_tree_node_0_0_i3);
	MR_init_label(mercury____Compare___space_partition__space_tree_node_0_0_i8);
	MR_init_entry(mercury____Unify___space_partition__space_tree_object_0_0);
	MR_init_label(mercury____Unify___space_partition__space_tree_object_0_0_i2);
	MR_init_label(mercury____Unify___space_partition__space_tree_object_0_0_i1);
	MR_init_entry(mercury____Compare___space_partition__space_tree_object_0_0);
	MR_init_label(mercury____Compare___space_partition__space_tree_object_0_0_i3);
	MR_init_label(mercury____Compare___space_partition__space_tree_object_0_0_i8);
	MR_init_label(mercury____Compare___space_partition__space_tree_object_0_0_i7);
	MR_init_label(mercury____Compare___space_partition__space_tree_object_0_0_i20);
	MR_init_entry(mercury____Unify___space_partition__bounding_box_0_0);
	MR_init_entry(mercury____Compare___space_partition__bounding_box_0_0);
	MR_init_entry(mercury____Unify___space_partition__subtree_result_0_0);
	MR_init_label(mercury____Unify___space_partition__subtree_result_0_0_i2);
	MR_init_label(mercury____Unify___space_partition__subtree_result_0_0_i1);
	MR_init_entry(mercury____Compare___space_partition__subtree_result_0_0);
	MR_init_label(mercury____Compare___space_partition__subtree_result_0_0_i3);
	MR_init_label(mercury____Compare___space_partition__subtree_result_0_0_i8);
	MR_init_label(mercury____Compare___space_partition__subtree_result_0_0_i7);
	MR_init_label(mercury____Compare___space_partition__subtree_result_0_0_i18);
	MR_init_label(mercury____Compare___space_partition__subtree_result_0_0_i19);
	MR_init_label(mercury____Compare___space_partition__subtree_result_0_0_i23);
MR_BEGIN_CODE

/* code for predicate 'map__ho6__ua0'/3 in mode 0 */
MR_define_static(mercury__space_partition__list__map__ho6__ua0_3_0);
	if (((MR_Integer) MR_r2 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__list__map__ho6__ua0_3_0_i2);
	}
	MR_r3 = (MR_Word) MR_sp;
MR_define_label(mercury__space_partition__list__map__ho6__ua0_3_0_i4);
	MR_incr_sp_push_msg(1, "list:map__ho6__ua0");
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__list__map__ho6__ua0_3_0, "eval:object/0");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	if (((MR_Integer) MR_r2 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__list__map__ho6__ua0_3_0_i4);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	}
MR_define_label(mercury__space_partition__list__map__ho6__ua0_3_0_i5);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__list__map__ho6__ua0_3_0, "list:list/1");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_decr_sp_pop_msg(1);
	if (((MR_Integer) MR_sp > (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury__space_partition__list__map__ho6__ua0_3_0_i5);
	}
	MR_proceed();
	}
MR_define_label(mercury__space_partition__list__map__ho6__ua0_3_0_i2);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
/* code for predicate 'DeforestationIn__pred__build_space_tree__128__0'/3 in mode 0 */
MR_define_static(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0);
	MR_incr_sp_push_msg(3, "space_partition:DeforestationIn__pred__build_space_tree__128__0/3");
	MR_stackvar(3) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i3);
	}
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i3);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__fn__space_partition__IntroducedFrom__func__build_space_tree__253__2_1_0,
		MR_LABEL(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i4),
		MR_STATIC(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0));
MR_define_label(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	}
	MR_localcall(mercury__space_partition__list__map__ho7_3_0,
		MR_LABEL(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i5),
		MR_STATIC(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0));
MR_define_label(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0));
	MR_r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_localcall(mercury__space_partition__space_tree_insert_3_0,
		MR_LABEL(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i6),
		MR_STATIC(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0));
MR_define_label(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_localtailcall(mercury__space_partition__list__foldl__ho3_4_0,
		MR_STATIC(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0));
/* code for predicate 'map__ho7'/3 in mode 0 */
MR_define_static(mercury__space_partition__list__map__ho7_3_0);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__list__map__ho7_3_0_i3);
	}
	MR_incr_sp_push_msg(2, "list:map__ho7/3");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__fn__space_partition__IntroducedFrom__func__build_space_tree__253__2_1_0,
		MR_LABEL(mercury__space_partition__list__map__ho7_3_0_i4),
		MR_STATIC(mercury__space_partition__list__map__ho7_3_0));
MR_define_label(mercury__space_partition__list__map__ho7_3_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__list__map__ho7_3_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__space_partition__list__map__ho7_3_0,
		MR_LABEL(mercury__space_partition__list__map__ho7_3_0_i5),
		MR_STATIC(mercury__space_partition__list__map__ho7_3_0));
MR_define_label(mercury__space_partition__list__map__ho7_3_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__list__map__ho7_3_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__list__map__ho7_3_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
	}
MR_define_label(mercury__space_partition__list__map__ho7_3_0_i3);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
/* code for predicate 'foldl__ho3'/4 in mode 0 */
MR_define_static(mercury__space_partition__list__foldl__ho3_4_0);
	MR_incr_sp_push_msg(2, "list:foldl__ho3/4");
	MR_stackvar(2) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__list__foldl__ho3_4_0_i3);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__space_partition__space_tree_insert_3_0,
		MR_LABEL(mercury__space_partition__list__foldl__ho3_4_0_i4),
		MR_STATIC(mercury__space_partition__list__foldl__ho3_4_0));
MR_define_label(mercury__space_partition__list__foldl__ho3_4_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__list__foldl__ho3_4_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__list__foldl__ho3_4_0_i3);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__space_partition__space_tree_insert_3_0,
		MR_LABEL(mercury__space_partition__list__foldl__ho3_4_0_i4),
		MR_STATIC(mercury__space_partition__list__foldl__ho3_4_0));
MR_define_label(mercury__space_partition__list__foldl__ho3_4_0_i3);
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate 'IntroducedFrom__func__build_space_tree__253__2'/2 in mode 0 */
MR_define_static(mercury__fn__space_partition__IntroducedFrom__func__build_space_tree__253__2_1_0);
	MR_incr_sp_push_msg(2, "space_partition:IntroducedFrom__func__build_space_tree__253__2/2");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_localcall(mercury__fn__space_partition__find_object_bounding_box_1_0,
		MR_LABEL(mercury__fn__space_partition__IntroducedFrom__func__build_space_tree__253__2_1_0_i2),
		MR_STATIC(mercury__fn__space_partition__IntroducedFrom__func__build_space_tree__253__2_1_0));
MR_define_label(mercury__fn__space_partition__IntroducedFrom__func__build_space_tree__253__2_1_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__IntroducedFrom__func__build_space_tree__253__2_1_0));
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__IntroducedFrom__func__build_space_tree__253__2_1_0, "space_partition:space_tree_object/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r3 = MR_tempr2;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r4 = MR_tempr3;
	MR_tempr4 = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0))));
	MR_r5 = MR_tempr4;
	MR_tempr5 = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1))));
	MR_r6 = MR_tempr5;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word((((MR_word_to_float(MR_tempr4) + MR_word_to_float(MR_tempr5)) * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 2)))) + (MR_word_to_float(MR_tempr4) * MR_word_to_float(MR_tempr5))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_stackvar(1);
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
	}
/* code for predicate 'create_scene'/2 in mode 0 */
MR_define_entry(mercury__fn__space_partition__create_scene_1_0);
	MR_incr_sp_push_msg(2, "space_partition:create_scene/2");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_localcall(mercury__space_partition__split_partitionable_objects_3_0,
		MR_LABEL(mercury__fn__space_partition__create_scene_1_0_i2),
		MR_ENTRY(mercury__fn__space_partition__create_scene_1_0));
MR_define_label(mercury__fn__space_partition__create_scene_1_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__create_scene_1_0));
	MR_stackvar(1) = MR_r2;
	MR_localcall(mercury__fn__space_partition__build_space_tree_1_0,
		MR_LABEL(mercury__fn__space_partition__create_scene_1_0_i3),
		MR_ENTRY(mercury__fn__space_partition__create_scene_1_0));
MR_define_label(mercury__fn__space_partition__create_scene_1_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__create_scene_1_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__fn__space_partition__create_scene_1_0, "space_partition:scene/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(1);
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
	}
/* code for predicate 'traverse_space_tree'/4 in mode 0 */
MR_define_entry(mercury__space_partition__traverse_space_tree_4_0);
	MR_r5 = MR_r1;
	MR_r6 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r7 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r8 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r9 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	MR_r10 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1);
	MR_r11 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2);
	MR_r13 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	MR_r14 = MR_const_field(MR_mktag(0), MR_r13, (MR_Integer) 0);
	MR_r12 = MR_const_field(MR_mktag(0), MR_r14, (MR_Integer) 0);
	MR_r15 = MR_const_field(MR_mktag(0), MR_r14, (MR_Integer) 1);
	MR_r16 = MR_const_field(MR_mktag(0), MR_r14, (MR_Integer) 2);
	MR_r17 = MR_const_field(MR_mktag(0), MR_r13, (MR_Integer) 1);
	MR_r14 = MR_const_field(MR_mktag(0), MR_r17, (MR_Integer) 0);
	MR_r13 = MR_const_field(MR_mktag(0), MR_r17, (MR_Integer) 1);
	MR_r18 = MR_const_field(MR_mktag(0), MR_r17, (MR_Integer) 2);
	{
	MR_Float	XRay;
	MR_Float	YRay;
	MR_Float	ZRay;
	MR_Float	XDir;
	MR_Float	YDir;
	MR_Float	ZDir;
	MR_Float	XMin;
	MR_Float	YMin;
	MR_Float	ZMin;
	MR_Float	XMax;
	MR_Float	YMax;
	MR_Float	ZMax;
#define	MR_PROC_LABEL	mercury__space_partition__traverse_space_tree_4_0
	XRay = MR_word_to_float(MR_r6);
	YRay = MR_word_to_float(MR_r7);
	ZRay = MR_word_to_float(MR_r8);
	XDir = MR_word_to_float(MR_r9);
	YDir = MR_word_to_float(MR_r10);
	ZDir = MR_word_to_float(MR_r11);
	XMin = MR_word_to_float(MR_r12);
	YMin = MR_word_to_float(MR_r15);
	ZMin = MR_word_to_float(MR_r16);
	XMax = MR_word_to_float(MR_r14);
	YMax = MR_word_to_float(MR_r13);
	ZMax = MR_word_to_float(MR_r18);
	MR_OBTAIN_GLOBAL_LOCK("intersect_bounding_box_2");
{
#line 409 "space_partition.m"

{
	double minB[3], maxB[3];	/*box */
	double origin[3], dir[3];	/*ray */
	double coord[3];		/* hit point (not used -stayl)*/
	bool succeeded;

	minB[0] = XMin;
	minB[1] = YMin;
	minB[2] = ZMin;
	maxB[0] = XMax;
	maxB[1] = YMax;
	maxB[2] = ZMax;
	origin[0] = XRay;
	origin[1] = YRay;
	origin[2] = ZRay;
	dir[0] = XDir;
	dir[1] = YDir;
	dir[2] = ZDir;
	succeeded = HitBoundingBox(minB, maxB, origin, dir, coord);
	/*fprintf(stderr, succeeded ? "1\n" : "0\n"); */
	SUCCESS_INDICATOR = succeeded;
};}
#line 1795 "space_partition.c"
	MR_RELEASE_GLOBAL_LOCK("intersect_bounding_box_2");
if (!MR_r1) MR_GOTO_LABEL(mercury__space_partition__traverse_space_tree_4_0_i4);
#undef	MR_PROC_LABEL

	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 2);
	MR_r4 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_localtailcall(mercury__space_partition__traverse_space_tree_nodes_5_0,
		MR_ENTRY(mercury__space_partition__traverse_space_tree_4_0));
MR_define_label(mercury__space_partition__traverse_space_tree_4_0_i4);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
/* code for predicate 'find_object_bounding_box'/2 in mode 0 */
MR_define_entry(mercury__fn__space_partition__find_object_bounding_box_1_0);
	MR_incr_sp_push_msg(3, "space_partition:find_object_bounding_box/2");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i4) MR_AND
		MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i6) MR_AND
		MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i10) MR_AND
		MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i15));
MR_define_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i4);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_localtailcall(mercury__fn__space_partition__find_basic_object_bounding_box_1_0,
		MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0));
MR_define_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i6);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__fn__space_partition__find_object_bounding_box_1_0,
		MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i7),
		MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0));
MR_define_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__fn__space_partition__find_object_bounding_box_1_0, "std_util:maybe/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_call_localret(MR_ENTRY(mercury__fn__renderer__maybe_transformation_to_trans_1_0),
		mercury__fn__space_partition__find_object_bounding_box_1_0_i8,
		MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0));
MR_define_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_localtailcall(mercury__fn__space_partition__transform_bounding_box_2_0,
		MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0));
MR_define_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i10);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__fn__space_partition__find_object_bounding_box_1_0,
		MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i11),
		MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0));
MR_define_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i11);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__fn__space_partition__find_object_bounding_box_1_0,
		MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i22),
		MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0));
MR_define_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i15);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i16);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_localcall(mercury__fn__space_partition__find_object_bounding_box_1_0,
		MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i17),
		MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0));
MR_define_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i17);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__fn__space_partition__find_object_bounding_box_1_0,
		MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i22),
		MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0));
MR_define_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i16);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_localcall(mercury__fn__space_partition__find_object_bounding_box_1_0,
		MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i21),
		MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0));
MR_define_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i21);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__fn__space_partition__find_object_bounding_box_1_0,
		MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i22),
		MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0));
MR_define_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i22);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_stackvar(1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_tempr2 = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0);
	}
	MR_localcall(mercury__fn__space_partition__min_point_2_0,
		MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i23),
		MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0));
MR_define_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i23);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__fn__space_partition__max_point_2_0,
		MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0_i24),
		MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0));
MR_define_label(mercury__fn__space_partition__find_object_bounding_box_1_0_i24);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__find_object_bounding_box_1_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__fn__space_partition__find_object_bounding_box_1_0, "std_util:pair/2");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
/* code for predicate 'transform_bounding_box'/3 in mode 0 */
MR_define_entry(mercury__fn__space_partition__transform_bounding_box_2_0);
	MR_incr_sp_push_msg(9, "space_partition:transform_bounding_box/3");
	MR_stackvar(9) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7, MR_tempr8;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__transform_bounding_box_2_0, "vector:vector/0");
	MR_stackvar(3) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0);
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_tempr3;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 2);
	MR_tag_incr_hp_msg(MR_tempr4, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__transform_bounding_box_2_0, "vector:vector/0");
	MR_stackvar(4) = MR_tempr4;
	MR_field(MR_mktag(0), MR_tempr4, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr4, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_tempr4, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	MR_tag_incr_hp_msg(MR_tempr5, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__transform_bounding_box_2_0, "vector:vector/0");
	MR_stackvar(5) = MR_tempr5;
	MR_field(MR_mktag(0), MR_tempr5, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr5, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_tempr5, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2);
	MR_tag_incr_hp_msg(MR_tempr6, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__transform_bounding_box_2_0, "vector:vector/0");
	MR_stackvar(6) = MR_tempr6;
	MR_field(MR_mktag(0), MR_tempr6, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr6, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_tempr6, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	MR_tag_incr_hp_msg(MR_tempr7, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__transform_bounding_box_2_0, "vector:vector/0");
	MR_stackvar(7) = MR_tempr7;
	MR_field(MR_mktag(0), MR_tempr7, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr7, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_tempr7, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr5, (MR_Integer) 2);
	MR_tag_incr_hp_msg(MR_tempr8, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__transform_bounding_box_2_0, "vector:vector/0");
	MR_stackvar(8) = MR_tempr8;
	MR_field(MR_mktag(0), MR_tempr8, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr8, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_tempr8, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr5, (MR_Integer) 2);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_tempr2;
	MR_r1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_tempr3;
	}
	MR_call_localret(MR_ENTRY(mercury__fn__trans__transform_point_2_0),
		mercury__fn__space_partition__transform_bounding_box_2_0_i2,
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_stackvar(2);
	MR_stackvar(2) = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__trans__transform_point_2_0),
		mercury__fn__space_partition__transform_bounding_box_2_0_i3,
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__trans__transform_point_2_0),
		mercury__fn__space_partition__transform_bounding_box_2_0_i4,
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_stackvar(4);
	MR_stackvar(4) = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__trans__transform_point_2_0),
		mercury__fn__space_partition__transform_bounding_box_2_0_i5,
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_stackvar(5);
	MR_stackvar(5) = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__trans__transform_point_2_0),
		mercury__fn__space_partition__transform_bounding_box_2_0_i6,
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_stackvar(6);
	MR_stackvar(6) = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__trans__transform_point_2_0),
		mercury__fn__space_partition__transform_bounding_box_2_0_i7,
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_stackvar(7);
	MR_stackvar(7) = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__trans__transform_point_2_0),
		mercury__fn__space_partition__transform_bounding_box_2_0_i8,
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r3 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	MR_r2 = MR_stackvar(8);
	MR_call_localret(MR_ENTRY(mercury__fn__trans__transform_point_2_0),
		mercury__fn__space_partition__transform_bounding_box_2_0_i9,
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_stackvar(8) = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(8);
	MR_localcall(mercury__fn__space_partition__min_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i10),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(7);
	MR_localcall(mercury__fn__space_partition__min_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i11),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i11);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(6);
	MR_localcall(mercury__fn__space_partition__min_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i12),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(5);
	MR_localcall(mercury__fn__space_partition__min_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i13),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(4);
	MR_localcall(mercury__fn__space_partition__min_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i14),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(3);
	MR_localcall(mercury__fn__space_partition__min_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i15),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i15);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_localcall(mercury__fn__space_partition__min_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i16),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_r2 = MR_stackvar(8);
	}
	MR_localcall(mercury__fn__space_partition__max_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i17),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i17);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(7);
	MR_localcall(mercury__fn__space_partition__max_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i18),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i18);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(6);
	MR_localcall(mercury__fn__space_partition__max_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i19),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i19);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(5);
	MR_localcall(mercury__fn__space_partition__max_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i20),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i20);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(4);
	MR_localcall(mercury__fn__space_partition__max_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i21),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i21);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(3);
	MR_localcall(mercury__fn__space_partition__max_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i22),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i22);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_localcall(mercury__fn__space_partition__max_point_2_0,
		MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0_i23),
		MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0));
MR_define_label(mercury__fn__space_partition__transform_bounding_box_2_0_i23);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__transform_bounding_box_2_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__fn__space_partition__transform_bounding_box_2_0, "std_util:pair/2");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
	}
/* code for predicate 'split_partitionable_objects'/3 in mode 0 */
MR_define_entry(mercury__space_partition__split_partitionable_objects_3_0);
	MR_incr_sp_push_msg(3, "space_partition:split_partitionable_objects/3");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i4) MR_AND
		MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i8) MR_AND
		MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i12) MR_AND
		MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i17));
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i4);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i5);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__split_partitionable_objects_3_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i5);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__split_partitionable_objects_3_0, "list:list/1");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i8);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__space_partition__split_partitionable_objects_3_0,
		MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i9),
		MR_ENTRY(mercury__space_partition__split_partitionable_objects_3_0));
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0));
	MR_stackvar(2) = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_localcall(mercury__space_partition__list__map__ho6__ua0_3_0,
		MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i10),
		MR_ENTRY(mercury__space_partition__split_partitionable_objects_3_0));
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__space_partition__list__map__ho6__ua0_3_0,
		MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i16),
		MR_ENTRY(mercury__space_partition__split_partitionable_objects_3_0));
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i12);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__space_partition__split_partitionable_objects_3_0,
		MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i13),
		MR_ENTRY(mercury__space_partition__split_partitionable_objects_3_0));
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(2) = MR_r2;
	}
	MR_localcall(mercury__space_partition__split_partitionable_objects_3_0,
		MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i14),
		MR_ENTRY(mercury__space_partition__split_partitionable_objects_3_0));
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0));
	MR_r4 = MR_r2;
	MR_r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_r4;
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_object_0;
	MR_call_localret(MR_ENTRY(mercury__list__append_3_1),
		mercury__space_partition__split_partitionable_objects_3_0_i15,
		MR_ENTRY(mercury__space_partition__split_partitionable_objects_3_0));
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i15);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0));
	MR_r3 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_object_0;
	MR_r2 = MR_stackvar(2);
	MR_call_localret(MR_ENTRY(mercury__list__append_3_1),
		mercury__space_partition__split_partitionable_objects_3_0_i16,
		MR_ENTRY(mercury__space_partition__split_partitionable_objects_3_0));
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i17);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i18);
	}
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_localcall(mercury__fn__space_partition__object_contains_plane_1_0,
		MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i23),
		MR_ENTRY(mercury__space_partition__split_partitionable_objects_3_0));
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i23);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0));
	if (((MR_Integer) MR_r1 == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i21);
	}
	MR_r1 = MR_stackvar(2);
	MR_localcall(mercury__fn__space_partition__object_contains_plane_1_0,
		MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i25),
		MR_ENTRY(mercury__space_partition__split_partitionable_objects_3_0));
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i25);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i19);
	}
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i21);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__split_partitionable_objects_3_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i19);
	MR_r1 = MR_stackvar(1);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__split_partitionable_objects_3_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i18);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_localcall(mercury__fn__space_partition__object_contains_plane_1_0,
		MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i32),
		MR_ENTRY(mercury__space_partition__split_partitionable_objects_3_0));
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i32);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0));
	if (((MR_Integer) MR_r1 == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i30);
	}
	MR_r1 = MR_stackvar(2);
	MR_localcall(mercury__fn__space_partition__object_contains_plane_1_0,
		MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i34),
		MR_ENTRY(mercury__space_partition__split_partitionable_objects_3_0));
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i34);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__split_partitionable_objects_3_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__space_partition__split_partitionable_objects_3_0_i28);
	}
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i30);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__split_partitionable_objects_3_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
MR_define_label(mercury__space_partition__split_partitionable_objects_3_0_i28);
	MR_r1 = MR_stackvar(1);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__split_partitionable_objects_3_0, "list:list/1");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r1 = MR_tempr1;
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
/* code for predicate 'object_contains_plane'/2 in mode 0 */
MR_define_static(mercury__fn__space_partition__object_contains_plane_1_0);
	MR_incr_sp_push_msg(2, "space_partition:object_contains_plane/2");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i4) MR_AND
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i8) MR_AND
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i10) MR_AND
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i15));
MR_define_label(mercury__fn__space_partition__object_contains_plane_1_0_i4);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i29);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
	}
MR_define_label(mercury__fn__space_partition__object_contains_plane_1_0_i8);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i4) MR_AND
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i8) MR_AND
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i10) MR_AND
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i15));
MR_define_label(mercury__fn__space_partition__object_contains_plane_1_0_i10);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__fn__space_partition__object_contains_plane_1_0,
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i11),
		MR_STATIC(mercury__fn__space_partition__object_contains_plane_1_0));
MR_define_label(mercury__fn__space_partition__object_contains_plane_1_0_i11);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__fn__space_partition__object_contains_plane_1_0,
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i12),
		MR_STATIC(mercury__fn__space_partition__object_contains_plane_1_0));
MR_define_label(mercury__fn__space_partition__object_contains_plane_1_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0));
	if (((MR_Integer) MR_stackvar(1) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i2);
	}
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
MR_define_label(mercury__fn__space_partition__object_contains_plane_1_0_i15);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i16);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_localcall(mercury__fn__space_partition__object_contains_plane_1_0,
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i17),
		MR_STATIC(mercury__fn__space_partition__object_contains_plane_1_0));
MR_define_label(mercury__fn__space_partition__object_contains_plane_1_0_i17);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__fn__space_partition__object_contains_plane_1_0,
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i18),
		MR_STATIC(mercury__fn__space_partition__object_contains_plane_1_0));
MR_define_label(mercury__fn__space_partition__object_contains_plane_1_0_i18);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0));
	if (((MR_Integer) MR_stackvar(1) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i2);
	}
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
MR_define_label(mercury__fn__space_partition__object_contains_plane_1_0_i16);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_localcall(mercury__fn__space_partition__object_contains_plane_1_0,
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i21),
		MR_STATIC(mercury__fn__space_partition__object_contains_plane_1_0));
MR_define_label(mercury__fn__space_partition__object_contains_plane_1_0_i21);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__fn__space_partition__object_contains_plane_1_0,
		MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i22),
		MR_STATIC(mercury__fn__space_partition__object_contains_plane_1_0));
MR_define_label(mercury__fn__space_partition__object_contains_plane_1_0_i22);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__space_partition__object_contains_plane_1_0));
	if (((MR_Integer) MR_stackvar(1) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__space_partition__object_contains_plane_1_0_i2);
	}
MR_define_label(mercury__fn__space_partition__object_contains_plane_1_0_i29);
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
MR_define_label(mercury__fn__space_partition__object_contains_plane_1_0_i2);
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate 'min_point'/3 in mode 0 */
MR_define_static(mercury__fn__space_partition__min_point_2_0);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r5 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r6 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r7 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if ((MR_word_to_float(MR_r7) > MR_word_to_float(MR_r5))) {
		MR_GOTO_LABEL(mercury__fn__space_partition__min_point_2_0_i2);
	}
	MR_r1 = MR_r6;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_r4 = MR_r3;
	MR_r3 = MR_tempr1;
	MR_r5 = MR_r7;
	if ((MR_word_to_float(MR_r1) > MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury__fn__space_partition__min_point_2_0_i4);
	}
	MR_tempr1 = MR_r2;
	MR_r2 = MR_r4;
	MR_r4 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r3 = MR_r5;
	if ((MR_word_to_float(MR_r1) > MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury__fn__space_partition__min_point_2_0_i6);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__min_point_2_0, "vector:vector/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r4;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
MR_define_label(mercury__fn__space_partition__min_point_2_0_i2);
	MR_r1 = MR_r6;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_r4 = MR_r3;
	MR_r3 = MR_tempr1;
	if ((MR_word_to_float(MR_r1) > MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury__fn__space_partition__min_point_2_0_i4);
	}
	MR_tempr1 = MR_r2;
	MR_r2 = MR_r4;
	MR_r4 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r3 = MR_r5;
	if ((MR_word_to_float(MR_r1) > MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury__fn__space_partition__min_point_2_0_i6);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__min_point_2_0, "vector:vector/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r4;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
MR_define_label(mercury__fn__space_partition__min_point_2_0_i4);
	MR_r1 = MR_r2;
	MR_r2 = MR_r4;
	MR_r4 = MR_r3;
	MR_r3 = MR_r5;
	if ((MR_word_to_float(MR_r1) > MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury__fn__space_partition__min_point_2_0_i6);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__min_point_2_0, "vector:vector/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r4;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
MR_define_label(mercury__fn__space_partition__min_point_2_0_i6);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__min_point_2_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r4;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_r2;
	MR_proceed();
/* code for predicate 'max_point'/3 in mode 0 */
MR_define_static(mercury__fn__space_partition__max_point_2_0);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r5 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r6 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r7 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if ((MR_word_to_float(MR_r7) < MR_word_to_float(MR_r5))) {
		MR_GOTO_LABEL(mercury__fn__space_partition__max_point_2_0_i2);
	}
	MR_r1 = MR_r6;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_r4 = MR_r3;
	MR_r3 = MR_tempr1;
	MR_r5 = MR_r7;
	if ((MR_word_to_float(MR_r1) < MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury__fn__space_partition__max_point_2_0_i4);
	}
	MR_tempr1 = MR_r2;
	MR_r2 = MR_r4;
	MR_r4 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r3 = MR_r5;
	if ((MR_word_to_float(MR_r1) < MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury__fn__space_partition__max_point_2_0_i6);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__max_point_2_0, "vector:vector/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r4;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
MR_define_label(mercury__fn__space_partition__max_point_2_0_i2);
	MR_r1 = MR_r6;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_r4 = MR_r3;
	MR_r3 = MR_tempr1;
	if ((MR_word_to_float(MR_r1) < MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury__fn__space_partition__max_point_2_0_i4);
	}
	MR_tempr1 = MR_r2;
	MR_r2 = MR_r4;
	MR_r4 = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r3 = MR_r5;
	if ((MR_word_to_float(MR_r1) < MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury__fn__space_partition__max_point_2_0_i6);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__max_point_2_0, "vector:vector/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r4;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
MR_define_label(mercury__fn__space_partition__max_point_2_0_i4);
	MR_r1 = MR_r2;
	MR_r2 = MR_r4;
	MR_r4 = MR_r3;
	MR_r3 = MR_r5;
	if ((MR_word_to_float(MR_r1) < MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury__fn__space_partition__max_point_2_0_i6);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__max_point_2_0, "vector:vector/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r4;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
MR_define_label(mercury__fn__space_partition__max_point_2_0_i6);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__max_point_2_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r4;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_r2;
	MR_proceed();
/* code for predicate 'find_basic_object_bounding_box'/2 in mode 0 */
MR_define_static(mercury__fn__space_partition__find_basic_object_bounding_box_1_0);
	MR_incr_sp_push_msg(1, "space_partition:find_basic_object_bounding_box/2");
	MR_stackvar(1) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i4) MR_AND
		MR_LABEL(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i5) MR_AND
		MR_LABEL(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i6) MR_AND
		MR_LABEL(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i7));
MR_define_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i4);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_space_partition__common_2);
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
MR_define_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i5);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_space_partition__common_4);
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
MR_define_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i6);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_space_partition__common_6);
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
MR_define_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i7);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i8);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__fn__space_partition__find_basic_object_bounding_box_1_0, "eval:basic_object/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_tempr1;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i4) MR_AND
		MR_LABEL(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i5) MR_AND
		MR_LABEL(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i6) MR_AND
		MR_LABEL(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i7));
	}
MR_define_label(mercury__fn__space_partition__find_basic_object_bounding_box_1_0_i8);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__find_basic_object_bounding_box_1_0, "eval:object/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_space_partition__type_ctor_info_invalid_object_0;
	MR_r2 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_STATIC(mercury__fn__space_partition__find_basic_object_bounding_box_1_0));
	}
/* code for predicate 'build_space_tree'/2 in mode 0 */
MR_define_entry(mercury__fn__space_partition__build_space_tree_1_0);
	{
	MR_Float	Max;
#define	MR_PROC_LABEL	mercury__fn__space_partition__build_space_tree_1_0
{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
Max = ML_FLOAT_MAX;;}
#line 2721 "space_partition.c"
	MR_r3 = MR_float_to_word(Max);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	Min;
#define	MR_PROC_LABEL	mercury__fn__space_partition__build_space_tree_1_0
{
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
Min = ML_FLOAT_MIN;;}
#line 2732 "space_partition.c"
	MR_r4 = MR_float_to_word(Min);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__build_space_tree_1_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = MR_r3;
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_r3;
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_r3;
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__build_space_tree_1_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 1) = MR_r4;
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 2) = MR_r4;
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 2, mercury__fn__space_partition__build_space_tree_1_0, "std_util:pair/2");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_r5;
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_r3;
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 3, mercury__fn__space_partition__build_space_tree_1_0, "space_partition:space_tree/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_localtailcall(mercury__space_partition__DeforestationIn__pred__build_space_tree__128__0_3_0,
		MR_ENTRY(mercury__fn__space_partition__build_space_tree_1_0));
/* code for predicate 'space_tree_insert'/3 in mode 0 */
MR_define_static(mercury__space_partition__space_tree_insert_3_0);
	MR_incr_sp_push_msg(6, "space_partition:space_tree_insert/3");
	MR_stackvar(6) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_stackvar(3), (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_stackvar(3), (MR_Integer) 0);
	MR_localcall(mercury__fn__space_partition__min_point_2_0,
		MR_LABEL(mercury__space_partition__space_tree_insert_3_0_i2),
		MR_STATIC(mercury__space_partition__space_tree_insert_3_0));
MR_define_label(mercury__space_partition__space_tree_insert_3_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__space_tree_insert_3_0));
	MR_r3 = MR_r1;
	MR_r1 = MR_stackvar(4);
	MR_stackvar(4) = MR_r3;
	MR_r2 = MR_stackvar(5);
	MR_localcall(mercury__fn__space_partition__max_point_2_0,
		MR_LABEL(mercury__space_partition__space_tree_insert_3_0_i3),
		MR_STATIC(mercury__space_partition__space_tree_insert_3_0));
MR_define_label(mercury__space_partition__space_tree_insert_3_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__space_tree_insert_3_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__space_partition__space_tree_insert_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_r1;
	MR_r4 = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 0)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))));
	MR_r5 = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 1)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1))));
	MR_r3 = MR_float_to_word((((MR_word_to_float(MR_r4) + MR_word_to_float(MR_r5)) * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 2)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)))) + (MR_word_to_float(MR_r4) * MR_word_to_float(MR_r5))));
	if (((MR_Integer) MR_stackvar(2) != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__space_tree_insert_3_0_i4);
	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(1), (MR_Integer) 1, mercury__space_partition__space_tree_insert_3_0, "space_partition:space_tree_node/0");
	MR_field(MR_mktag(1), MR_r4, (MR_Integer) 0) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__space_tree_insert_3_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__space_partition__space_tree_insert_3_0, "space_partition:space_tree/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r2;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r3;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_r5;
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury__space_partition__space_tree_insert_3_0_i4);
	if (((MR_Integer) MR_stackvar(2) == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__space_tree_insert_3_0_i6);
	}
	MR_r4 = MR_const_field(MR_mktag(1), MR_stackvar(2), (MR_Integer) 1);
	if (((MR_Integer) MR_r4 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__space_tree_insert_3_0_i6);
	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(1), (MR_Integer) 1, mercury__space_partition__space_tree_insert_3_0, "space_partition:space_tree_node/0");
	MR_field(MR_mktag(1), MR_r4, (MR_Integer) 0) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__space_tree_insert_3_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 0) = MR_const_field(MR_mktag(1), MR_stackvar(2), (MR_Integer) 0);
	MR_field(MR_mktag(1), MR_r5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_r6, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__space_tree_insert_3_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(1), MR_r6, (MR_Integer) 1) = MR_r5;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__space_partition__space_tree_insert_3_0, "space_partition:space_tree/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r2;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r3;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_r6;
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury__space_partition__space_tree_insert_3_0_i6);
	{
	MR_Float	Max;
#define	MR_PROC_LABEL	mercury__space_partition__space_tree_insert_3_0
{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
Max = ML_FLOAT_MAX;;}
#line 2831 "space_partition.c"
	MR_r5 = MR_float_to_word(Max);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 2, mercury__space_partition__space_tree_insert_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_r5;
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = (MR_Integer) 0;
	MR_r1 = MR_stackvar(3);
	MR_stackvar(3) = MR_r2;
	MR_stackvar(4) = MR_r3;
	MR_r2 = MR_stackvar(2);
	MR_r3 = (MR_Integer) 1;
	MR_localcall(mercury__space_partition__select_subtree_5_0,
		MR_LABEL(mercury__space_partition__space_tree_insert_3_0_i9),
		MR_STATIC(mercury__space_partition__space_tree_insert_3_0));
MR_define_label(mercury__space_partition__space_tree_insert_3_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__space_tree_insert_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_r3 = MR_stackvar(1);
	MR_localcall(mercury__space_partition__subtree_insert_4_0,
		MR_LABEL(mercury__space_partition__space_tree_insert_3_0_i10),
		MR_STATIC(mercury__space_partition__space_tree_insert_3_0));
MR_define_label(mercury__space_partition__space_tree_insert_3_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__space_tree_insert_3_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 3, mercury__space_partition__space_tree_insert_3_0, "space_partition:space_tree/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
/* code for predicate 'select_subtree'/5 in mode 0 */
MR_define_static(mercury__space_partition__select_subtree_5_0);
	MR_incr_sp_push_msg(9, "space_partition:select_subtree/5");
	MR_stackvar(9) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r2 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__select_subtree_5_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_tempr2 = MR_r1;
	MR_stackvar(1) = MR_tempr2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_tempr3 = MR_const_mask_field(MR_tempr1, (MR_Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0);
	MR_r1 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__space_partition__min_point_2_0,
		MR_LABEL(mercury__space_partition__select_subtree_5_0_i6),
		MR_STATIC(mercury__space_partition__select_subtree_5_0));
MR_define_label(mercury__space_partition__select_subtree_5_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__select_subtree_5_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(7);
	MR_stackvar(7) = MR_tempr1;
	MR_r2 = MR_stackvar(8);
	}
	MR_localcall(mercury__fn__space_partition__max_point_2_0,
		MR_LABEL(mercury__space_partition__select_subtree_5_0_i7),
		MR_STATIC(mercury__space_partition__select_subtree_5_0));
MR_define_label(mercury__space_partition__select_subtree_5_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__select_subtree_5_0));
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(7), (MR_Integer) 0)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))));
	MR_tempr2 = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(7), (MR_Integer) 1)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1))));
	MR_r5 = MR_float_to_word(((((MR_word_to_float(MR_tempr1) + MR_word_to_float(MR_tempr2)) * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(7), (MR_Integer) 2)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)))) + (MR_word_to_float(MR_tempr1) * MR_word_to_float(MR_tempr2))) - MR_word_to_float(MR_stackvar(5))));
	if ((MR_word_to_float(MR_r5) >= MR_word_to_float(MR_stackvar(6)))) {
		MR_GOTO_LABEL(mercury__space_partition__select_subtree_5_0_i8);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__space_partition__select_subtree_5_0, "std_util:pair/2");
	MR_r4 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r5;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(2);
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(4);
	MR_r3 = ((MR_Integer) MR_stackvar(2) + (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(9);
	if (((MR_Integer) MR_r2 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__select_subtree_5_0_i3);
	}
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_tempr2 = MR_r1;
	MR_stackvar(1) = MR_tempr2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_tempr3 = MR_const_mask_field(MR_tempr1, (MR_Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0);
	MR_r1 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__space_partition__min_point_2_0,
		MR_LABEL(mercury__space_partition__select_subtree_5_0_i6),
		MR_STATIC(mercury__space_partition__select_subtree_5_0));
MR_define_label(mercury__space_partition__select_subtree_5_0_i8);
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(4);
	MR_r3 = ((MR_Integer) MR_stackvar(2) + (MR_Integer) 1);
	MR_r4 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(9);
	if (((MR_Integer) MR_r2 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__select_subtree_5_0_i3);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_tempr2 = MR_r1;
	MR_stackvar(1) = MR_tempr2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_tempr3 = MR_const_mask_field(MR_tempr1, (MR_Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0);
	MR_r1 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__space_partition__min_point_2_0,
		MR_LABEL(mercury__space_partition__select_subtree_5_0_i6),
		MR_STATIC(mercury__space_partition__select_subtree_5_0));
MR_define_label(mercury__space_partition__select_subtree_5_0_i3);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
/* code for predicate 'subtree_insert'/4 in mode 0 */
MR_define_static(mercury__space_partition__subtree_insert_4_0);
	MR_incr_sp_push_msg(6, "space_partition:subtree_insert/4");
	MR_stackvar(6) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r1 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__subtree_insert_4_0_i3);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__space_partition__subtree_insert_4_0, "space_partition:space_tree_node/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r3;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__subtree_insert_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
	}
MR_define_label(mercury__space_partition__subtree_insert_4_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	if (((MR_Integer) MR_r2 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__space_partition__subtree_insert_4_0_i4);
	}
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__space_partition__subtree_insert_4_0_i7);
	}
	MR_r1 = MR_r3;
	MR_r2 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_localcall(mercury__space_partition__space_tree_insert_3_0,
		MR_LABEL(mercury__space_partition__subtree_insert_4_0_i8),
		MR_STATIC(mercury__space_partition__subtree_insert_4_0));
MR_define_label(mercury__space_partition__subtree_insert_4_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__subtree_insert_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 1, mercury__space_partition__subtree_insert_4_0, "space_partition:space_tree_node/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__subtree_insert_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
	}
MR_define_label(mercury__space_partition__subtree_insert_4_0_i7);
	MR_stackvar(1) = MR_r3;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_stackvar(2), (MR_Integer) 0), (MR_Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0);
	}
	MR_localcall(mercury__fn__space_partition__min_point_2_0,
		MR_LABEL(mercury__space_partition__subtree_insert_4_0_i9),
		MR_STATIC(mercury__space_partition__subtree_insert_4_0));
MR_define_label(mercury__space_partition__subtree_insert_4_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__subtree_insert_4_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(4);
	MR_stackvar(4) = MR_tempr1;
	MR_r2 = MR_stackvar(5);
	}
	MR_localcall(mercury__fn__space_partition__max_point_2_0,
		MR_LABEL(mercury__space_partition__subtree_insert_4_0_i10),
		MR_STATIC(mercury__space_partition__subtree_insert_4_0));
MR_define_label(mercury__space_partition__subtree_insert_4_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__subtree_insert_4_0));
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7, MR_tempr8;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__space_partition__subtree_insert_4_0, "std_util:pair/2");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 1, mercury__space_partition__subtree_insert_4_0, "space_partition:space_tree_node/0");
	MR_r3 = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__subtree_insert_4_0, "list:list/1");
	MR_r4 = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr3, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_tempr3, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_tempr4, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__subtree_insert_4_0, "list:list/1");
	MR_r5 = MR_tempr4;
	MR_field(MR_mktag(1), MR_tempr4, (MR_Integer) 0) = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr4, (MR_Integer) 1) = MR_tempr3;
	MR_tag_incr_hp_msg(MR_tempr5, MR_mktag(0), (MR_Integer) 3, mercury__space_partition__subtree_insert_4_0, "space_partition:space_tree/0");
	MR_r3 = MR_tempr5;
	MR_field(MR_mktag(0), MR_tempr5, (MR_Integer) 0) = MR_tempr1;
	MR_tempr6 = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 0)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))));
	MR_r4 = MR_tempr6;
	MR_tempr7 = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 1)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1))));
	MR_r6 = MR_tempr7;
	MR_field(MR_mktag(0), MR_tempr5, (MR_Integer) 1) = MR_float_to_word((((MR_word_to_float(MR_tempr6) + MR_word_to_float(MR_tempr7)) * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 2)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)))) + (MR_word_to_float(MR_tempr6) * MR_word_to_float(MR_tempr7))));
	MR_field(MR_mktag(0), MR_tempr5, (MR_Integer) 2) = MR_tempr4;
	MR_tag_incr_hp_msg(MR_tempr8, MR_mktag(0), (MR_Integer) 1, mercury__space_partition__subtree_insert_4_0, "space_partition:space_tree_node/0");
	MR_r2 = MR_tempr8;
	MR_field(MR_mktag(0), MR_tempr8, (MR_Integer) 0) = MR_tempr5;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__subtree_insert_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_tempr8;
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
	}
MR_define_label(mercury__space_partition__subtree_insert_4_0_i4);
	MR_r1 = MR_stackvar(3);
	MR_r2 = ((MR_Integer) MR_r2 - (MR_Integer) 1);
	MR_localcall(mercury__space_partition__subtree_insert_4_0,
		MR_LABEL(mercury__space_partition__subtree_insert_4_0_i11),
		MR_STATIC(mercury__space_partition__subtree_insert_4_0));
MR_define_label(mercury__space_partition__subtree_insert_4_0_i11);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__subtree_insert_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__space_partition__subtree_insert_4_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
	}
/* code for predicate 'intersect_bounding_box_2'/12 in mode 0 */
MR_define_static(mercury__space_partition__intersect_bounding_box_2_12_0);
	MR_r13 = MR_r1;
	{
	MR_Float	XRay;
	MR_Float	YRay;
	MR_Float	ZRay;
	MR_Float	XDir;
	MR_Float	YDir;
	MR_Float	ZDir;
	MR_Float	XMin;
	MR_Float	YMin;
	MR_Float	ZMin;
	MR_Float	XMax;
	MR_Float	YMax;
	MR_Float	ZMax;
#define	MR_PROC_LABEL	mercury__space_partition__intersect_bounding_box_2_12_0
	XRay = MR_word_to_float(MR_r13);
	YRay = MR_word_to_float(MR_r2);
	ZRay = MR_word_to_float(MR_r3);
	XDir = MR_word_to_float(MR_r4);
	YDir = MR_word_to_float(MR_r5);
	ZDir = MR_word_to_float(MR_r6);
	XMin = MR_word_to_float(MR_r7);
	YMin = MR_word_to_float(MR_r8);
	ZMin = MR_word_to_float(MR_r9);
	XMax = MR_word_to_float(MR_r10);
	YMax = MR_word_to_float(MR_r11);
	ZMax = MR_word_to_float(MR_r12);
	MR_OBTAIN_GLOBAL_LOCK("intersect_bounding_box_2");
{
#line 409 "space_partition.m"

{
	double minB[3], maxB[3];	/*box */
	double origin[3], dir[3];	/*ray */
	double coord[3];		/* hit point (not used -stayl)*/
	bool succeeded;

	minB[0] = XMin;
	minB[1] = YMin;
	minB[2] = ZMin;
	maxB[0] = XMax;
	maxB[1] = YMax;
	maxB[2] = ZMax;
	origin[0] = XRay;
	origin[1] = YRay;
	origin[2] = ZRay;
	dir[0] = XDir;
	dir[1] = YDir;
	dir[2] = ZDir;
	succeeded = HitBoundingBox(minB, maxB, origin, dir, coord);
	/*fprintf(stderr, succeeded ? "1\n" : "0\n"); */
	SUCCESS_INDICATOR = succeeded;
};}
#line 3162 "space_partition.c"
	MR_RELEASE_GLOBAL_LOCK("intersect_bounding_box_2");
if (!MR_r1) MR_GOTO_LABEL(mercury__space_partition__intersect_bounding_box_2_12_0_i2);
#undef	MR_PROC_LABEL

	}
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__space_partition__intersect_bounding_box_2_12_0_i2);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate 'traverse_space_tree_nodes'/5 in mode 0 */
MR_define_static(mercury__space_partition__traverse_space_tree_nodes_5_0);
	MR_incr_sp_push_msg(5, "space_partition:traverse_space_tree_nodes/5");
	MR_stackvar(5) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i3);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i5);
	}
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	MR_localcall(mercury__space_partition__traverse_space_tree_4_0,
		MR_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i6),
		MR_STATIC(mercury__space_partition__traverse_space_tree_nodes_5_0));
MR_define_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0));
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_r1;
	MR_r1 = MR_stackvar(4);
	if (((MR_Integer) MR_stackvar(3) == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i13);
	}
	if (((MR_Integer) MR_r4 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i11);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 2, mercury__space_partition__traverse_space_tree_nodes_5_0, "tree:tree/1");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 1) = MR_r4;
	MR_r4 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i3);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i5);
	}
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	}
	MR_localcall(mercury__space_partition__traverse_space_tree_4_0,
		MR_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i6),
		MR_STATIC(mercury__space_partition__traverse_space_tree_nodes_5_0));
MR_define_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i5);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0), (MR_Integer) 2);
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r3 = MR_stackvar(1);
	MR_r4 = MR_stackvar(2);
	MR_call_localret(MR_ENTRY(mercury__renderer__find_object_intersection_5_0),
		mercury__space_partition__traverse_space_tree_nodes_5_0_i7,
		MR_STATIC(mercury__space_partition__traverse_space_tree_nodes_5_0));
MR_define_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0));
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_r1;
	MR_r1 = MR_stackvar(4);
	if (((MR_Integer) MR_stackvar(3) == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i13);
	}
	if (((MR_Integer) MR_r4 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i10);
	}
MR_define_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i11);
	MR_r4 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(5);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i3);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i5);
	}
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	MR_localcall(mercury__space_partition__traverse_space_tree_4_0,
		MR_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i6),
		MR_STATIC(mercury__space_partition__traverse_space_tree_nodes_5_0));
MR_define_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i10);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 2, mercury__space_partition__traverse_space_tree_nodes_5_0, "tree:tree/1");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 1) = MR_r4;
	MR_r4 = MR_tempr1;
	}
MR_define_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i13);
	MR_succip = (MR_Code *) MR_stackvar(5);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i3);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i5);
	}
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	MR_localcall(mercury__space_partition__traverse_space_tree_4_0,
		MR_LABEL(mercury__space_partition__traverse_space_tree_nodes_5_0_i6),
		MR_STATIC(mercury__space_partition__traverse_space_tree_nodes_5_0));
MR_define_label(mercury__space_partition__traverse_space_tree_nodes_5_0_i3);
	MR_r1 = MR_r4;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___space_partition__scene_0_0);
	MR_incr_sp_push_msg(3, "space_partition:__Unify__/2");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_localcall(mercury____Unify___space_partition__space_tree_0_0,
		MR_LABEL(mercury____Unify___space_partition__scene_0_0_i2),
		MR_ENTRY(mercury____Unify___space_partition__scene_0_0));
MR_define_label(mercury____Unify___space_partition__scene_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___space_partition__scene_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___space_partition__scene_0_0_i1);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_object_0;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___space_partition__scene_0_0));
MR_define_label(mercury____Unify___space_partition__scene_0_0_i1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___space_partition__scene_0_0);
	MR_incr_sp_push_msg(3, "space_partition:__Compare__/3");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_localcall(mercury____Compare___space_partition__space_tree_0_0,
		MR_LABEL(mercury____Compare___space_partition__scene_0_0_i3),
		MR_ENTRY(mercury____Compare___space_partition__scene_0_0));
MR_define_label(mercury____Compare___space_partition__scene_0_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___space_partition__scene_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__scene_0_0_i7);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_object_0;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___space_partition__scene_0_0));
MR_define_label(mercury____Compare___space_partition__scene_0_0_i7);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___space_partition__invalid_transformation_0_0);
	MR_tailcall(MR_ENTRY(mercury____Unify___eval__transformation_0_0),
		MR_ENTRY(mercury____Unify___space_partition__invalid_transformation_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___space_partition__invalid_transformation_0_0);
	MR_tailcall(MR_ENTRY(mercury____Compare___eval__transformation_0_0),
		MR_ENTRY(mercury____Compare___space_partition__invalid_transformation_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___space_partition__invalid_object_0_0);
	MR_tailcall(MR_ENTRY(mercury____Unify___eval__object_0_0),
		MR_ENTRY(mercury____Unify___space_partition__invalid_object_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___space_partition__invalid_object_0_0);
	MR_tailcall(MR_ENTRY(mercury____Compare___eval__object_0_0),
		MR_ENTRY(mercury____Compare___space_partition__invalid_object_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___space_partition__normal_0_0);
	MR_tailcall(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		MR_ENTRY(mercury____Unify___space_partition__normal_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___space_partition__normal_0_0);
	MR_tailcall(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		MR_ENTRY(mercury____Compare___space_partition__normal_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___space_partition__surface_area_0_0);
	MR_r1 = (MR_word_to_float(MR_r1) == MR_word_to_float(MR_r2));
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___space_partition__surface_area_0_0);
	if ((MR_word_to_float(MR_r1) >= MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__surface_area_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___space_partition__surface_area_0_0_i2);
	if ((MR_word_to_float(MR_r1) <= MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__surface_area_0_0_i3);
	}
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Compare___space_partition__surface_area_0_0_i3);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___space_partition__space_tree_0_0);
	MR_incr_sp_push_msg(5, "space_partition:__Unify__/2");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r5 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r6 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___space_partition__space_tree_0_0_i2,
		MR_ENTRY(mercury____Unify___space_partition__space_tree_0_0));
MR_define_label(mercury____Unify___space_partition__space_tree_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___space_partition__space_tree_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___space_partition__space_tree_0_0_i1);
	}
	if ((MR_word_to_float(MR_stackvar(1)) != MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Unify___space_partition__space_tree_0_0_i1);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_space_partition__type_ctor_info_space_tree_node_0;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(4);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___space_partition__space_tree_0_0));
MR_define_label(mercury____Unify___space_partition__space_tree_0_0_i1);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___space_partition__space_tree_0_0);
	MR_incr_sp_push_msg(5, "space_partition:__Compare__/3");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r5 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r6 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___space_partition__space_tree_0_0_i3,
		MR_ENTRY(mercury____Compare___space_partition__space_tree_0_0));
MR_define_label(mercury____Compare___space_partition__space_tree_0_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___space_partition__space_tree_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__space_tree_0_0_i20);
	}
	if ((MR_word_to_float(MR_stackvar(1)) >= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__space_tree_0_0_i8);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__space_tree_0_0_i7);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___space_partition__space_tree_0_0_i8);
	if ((MR_word_to_float(MR_stackvar(1)) <= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__space_tree_0_0_i7);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__space_tree_0_0_i7);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___space_partition__space_tree_0_0_i7);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_space_partition__type_ctor_info_space_tree_node_0;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(4);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___space_partition__space_tree_0_0));
MR_define_label(mercury____Compare___space_partition__space_tree_0_0_i20);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___space_partition__space_tree_node_0_0);
	if ((MR_tag(MR_r1) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___space_partition__space_tree_node_0_0_i3);
	}
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___space_partition__space_tree_node_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Unify___space_partition__space_tree_0_0,
		MR_ENTRY(mercury____Unify___space_partition__space_tree_node_0_0));
MR_define_label(mercury____Unify___space_partition__space_tree_node_0_0_i3);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___space_partition__space_tree_node_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Unify___space_partition__space_tree_object_0_0,
		MR_ENTRY(mercury____Unify___space_partition__space_tree_node_0_0));
MR_define_label(mercury____Unify___space_partition__space_tree_node_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___space_partition__space_tree_node_0_0);
	if ((MR_tag(MR_r1) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__space_tree_node_0_0_i3);
	}
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__space_tree_node_0_0_i5);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Compare___space_partition__space_tree_0_0,
		MR_ENTRY(mercury____Compare___space_partition__space_tree_node_0_0));
MR_define_label(mercury____Compare___space_partition__space_tree_node_0_0_i5);
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___space_partition__space_tree_node_0_0_i3);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__space_tree_node_0_0_i8);
	}
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Compare___space_partition__space_tree_node_0_0_i8);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Compare___space_partition__space_tree_object_0_0,
		MR_ENTRY(mercury____Compare___space_partition__space_tree_node_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___space_partition__space_tree_object_0_0);
	MR_incr_sp_push_msg(5, "space_partition:__Unify__/2");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r5 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r6 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___space_partition__space_tree_object_0_0_i2,
		MR_ENTRY(mercury____Unify___space_partition__space_tree_object_0_0));
MR_define_label(mercury____Unify___space_partition__space_tree_object_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___space_partition__space_tree_object_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___space_partition__space_tree_object_0_0_i1);
	}
	if ((MR_word_to_float(MR_stackvar(1)) != MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Unify___space_partition__space_tree_object_0_0_i1);
	}
	MR_r1 = MR_stackvar(2);
	MR_r2 = MR_stackvar(4);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_tailcall(MR_ENTRY(mercury____Unify___eval__object_0_0),
		MR_ENTRY(mercury____Unify___space_partition__space_tree_object_0_0));
MR_define_label(mercury____Unify___space_partition__space_tree_object_0_0_i1);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___space_partition__space_tree_object_0_0);
	MR_incr_sp_push_msg(5, "space_partition:__Compare__/3");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r5 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r6 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___space_partition__space_tree_object_0_0_i3,
		MR_ENTRY(mercury____Compare___space_partition__space_tree_object_0_0));
MR_define_label(mercury____Compare___space_partition__space_tree_object_0_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___space_partition__space_tree_object_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__space_tree_object_0_0_i20);
	}
	if ((MR_word_to_float(MR_stackvar(1)) >= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__space_tree_object_0_0_i8);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__space_tree_object_0_0_i7);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___space_partition__space_tree_object_0_0_i8);
	if ((MR_word_to_float(MR_stackvar(1)) <= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__space_tree_object_0_0_i7);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__space_tree_object_0_0_i7);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___space_partition__space_tree_object_0_0_i7);
	MR_r1 = MR_stackvar(2);
	MR_r2 = MR_stackvar(4);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_tailcall(MR_ENTRY(mercury____Compare___eval__object_0_0),
		MR_ENTRY(mercury____Compare___space_partition__space_tree_object_0_0));
MR_define_label(mercury____Compare___space_partition__space_tree_object_0_0_i20);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___space_partition__bounding_box_0_0);
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r4 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_tailcall(MR_ENTRY(mercury____Unify___std_util__pair_2_0),
		MR_ENTRY(mercury____Unify___space_partition__bounding_box_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___space_partition__bounding_box_0_0);
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r4 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_tailcall(MR_ENTRY(mercury____Compare___std_util__pair_2_0),
		MR_ENTRY(mercury____Compare___space_partition__bounding_box_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___space_partition__subtree_result_0_0);
	MR_incr_sp_push_msg(5, "space_partition:__Unify__/2");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r5 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r6 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___space_partition__subtree_result_0_0_i2,
		MR_ENTRY(mercury____Unify___space_partition__subtree_result_0_0));
MR_define_label(mercury____Unify___space_partition__subtree_result_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___space_partition__subtree_result_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___space_partition__subtree_result_0_0_i1);
	}
	if ((MR_word_to_float(MR_stackvar(1)) != MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Unify___space_partition__subtree_result_0_0_i1);
	}
	MR_r1 = (MR_stackvar(2) == MR_stackvar(4));
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Unify___space_partition__subtree_result_0_0_i1);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___space_partition__subtree_result_0_0);
	MR_incr_sp_push_msg(5, "space_partition:__Compare__/3");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r5 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r6 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_vector__type_ctor_info_vector_0;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___space_partition__subtree_result_0_0_i3,
		MR_ENTRY(mercury____Compare___space_partition__subtree_result_0_0));
MR_define_label(mercury____Compare___space_partition__subtree_result_0_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___space_partition__subtree_result_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__subtree_result_0_0_i23);
	}
	if ((MR_word_to_float(MR_stackvar(1)) >= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__subtree_result_0_0_i8);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__subtree_result_0_0_i7);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___space_partition__subtree_result_0_0_i8);
	if ((MR_word_to_float(MR_stackvar(1)) <= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__subtree_result_0_0_i7);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__subtree_result_0_0_i7);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___space_partition__subtree_result_0_0_i7);
	if (((MR_Integer) MR_stackvar(2) >= (MR_Integer) MR_stackvar(4))) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__subtree_result_0_0_i18);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___space_partition__subtree_result_0_0_i18);
	if ((MR_stackvar(2) != MR_stackvar(4))) {
		MR_GOTO_LABEL(mercury____Compare___space_partition__subtree_result_0_0_i19);
	}
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___space_partition__subtree_result_0_0_i19);
	MR_r1 = (MR_Integer) 2;
MR_define_label(mercury____Compare___space_partition__subtree_result_0_0_i23);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_END_MODULE
#line 450 "space_partition.m"

Bool HitBoundingBox(double minB[3],double maxB[3], double origin[3],
		double dir[3], double coord[3])
{
	char inside = TRUE;
	char quadrant[NUMDIM];
	register int i;
	int whichPlane;
	double maxT[NUMDIM];
	double candidatePlane[NUMDIM];

	/* Find candidate planes; this loop can be avoided if
   	rays cast all from the eye(assume perpsective view) */
	for (i=0; i<NUMDIM; i++)
		if(origin[i] < minB[i]) {
			quadrant[i] = LEFT;
			candidatePlane[i] = minB[i];
			inside = FALSE;
		}else if (origin[i] > maxB[i]) {
			quadrant[i] = RIGHT;
			candidatePlane[i] = maxB[i];
			inside = FALSE;
		}else	{
			quadrant[i] = MIDDLE;
		}

	/* Ray origin inside bounding box */
	if(inside)	{
		coord = origin;
		return (TRUE);
	}


	/* Calculate T distances to candidate planes */
	for (i = 0; i < NUMDIM; i++)
		if (quadrant[i] != MIDDLE && dir[i] !=0.)
			maxT[i] = (candidatePlane[i]-origin[i]) / dir[i];
		else
			maxT[i] = -1.;

	/* Get largest of the maxT's for final choice of intersection */
	whichPlane = 0;
	for (i = 1; i < NUMDIM; i++)
		if (maxT[whichPlane] < maxT[i])
			whichPlane = i;

	/* Check final candidate actually inside box */
	if (maxT[whichPlane] < 0.) {
		return (FALSE);
	}
	for (i = 0; i < NUMDIM; i++)
		if (whichPlane != i) {
			coord[i] = origin[i] + maxT[whichPlane] *dir[i];
			if (coord[i] < minB[i] || coord[i] > maxB[i])
				return (FALSE);
		} else {
			coord[i] = candidatePlane[i];
		}
	return (TRUE);				/* ray hits box */
}
#line 3806 "space_partition.c"

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__space_partition_maybe_bunch_0(void)
{
	space_partition_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__space_partition__init(void);
void mercury__space_partition__init_type_tables(void);
void mercury__space_partition__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__space_partition__write_out_proc_statics(FILE *fp);
#endif

void mercury__space_partition__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__space_partition_maybe_bunch_0();
#endif

	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_space_partition__type_ctor_info_surface_area_0,
		space_partition__surface_area_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_space_partition__type_ctor_info_subtree_result_0,
		space_partition__subtree_result_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_space_partition__type_ctor_info_space_tree_object_0,
		space_partition__space_tree_object_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_space_partition__type_ctor_info_space_tree_node_0,
		space_partition__space_tree_node_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_space_partition__type_ctor_info_space_tree_0,
		space_partition__space_tree_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_space_partition__type_ctor_info_scene_0,
		space_partition__scene_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_space_partition__type_ctor_info_normal_0,
		space_partition__normal_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_space_partition__type_ctor_info_invalid_transformation_0,
		space_partition__invalid_transformation_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_space_partition__type_ctor_info_invalid_object_0,
		space_partition__invalid_object_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_space_partition__type_ctor_info_bounding_box_0,
		space_partition__bounding_box_0_0);
	mercury__space_partition__init_debugger();
}

void mercury__space_partition__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
	MR_register_type_ctor_info(
		&mercury_data_space_partition__type_ctor_info_surface_area_0);
	MR_register_type_ctor_info(
		&mercury_data_space_partition__type_ctor_info_subtree_result_0);
	MR_register_type_ctor_info(
		&mercury_data_space_partition__type_ctor_info_space_tree_object_0);
	MR_register_type_ctor_info(
		&mercury_data_space_partition__type_ctor_info_space_tree_node_0);
	MR_register_type_ctor_info(
		&mercury_data_space_partition__type_ctor_info_space_tree_0);
	MR_register_type_ctor_info(
		&mercury_data_space_partition__type_ctor_info_scene_0);
	MR_register_type_ctor_info(
		&mercury_data_space_partition__type_ctor_info_normal_0);
	MR_register_type_ctor_info(
		&mercury_data_space_partition__type_ctor_info_invalid_transformation_0);
	MR_register_type_ctor_info(
		&mercury_data_space_partition__type_ctor_info_invalid_object_0);
	MR_register_type_ctor_info(
		&mercury_data_space_partition__type_ctor_info_bounding_box_0);
}


void mercury__space_partition__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__space_partition__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
