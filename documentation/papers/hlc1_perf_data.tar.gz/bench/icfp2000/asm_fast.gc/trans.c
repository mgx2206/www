/*
** Automatically generated from `trans.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__trans__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "trans.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "trans.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


#include "mercury_deep_copy.h"

#ifdef CONSERVATIVE_GC
  /* for conservative GC, shallow copies suffice */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		NewVal = OldVal;					\
	} while (0)
#else
  /*
  ** Note that we need to save/restore the MR_hp register, if it
  ** is transient, before/after calling MR_deep_copy().
  */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		MR_save_transient_hp();					\
		NewVal = MR_deep_copy(&OldVal, (MR_TypeInfo) TypeInfo_for_T,\
				(const MR_Word *) SolutionsHeapPtr,	\
				MR_ENGINE(MR_eng_solutions_heap_zone)->top);\
		MR_restore_transient_hp();				\
	} while (0)
#endif


#line 62 "trans.c"
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"

#include "mercury_heap.h"	/* for MR_incr_hp_msg() etc. */
#include "mercury_misc.h"	/* for MR_fatal_error() */
#include "mercury_string.h"	/* for MR_make_aligned_string() */

#line 69 "trans.c"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_TYPECTORDESC_GUARD
#define ML_TYPECTORDESC_GUARD

/*
** Values of type `std_util:type_desc' are represented the same way as
** values of type `private_builtin:type_info' (this representation is
** documented in compiler/polymorphism.m). Some parts of the library
** (e.g. the gc initialization code) depend on this.
** The C type corresponding to these Mercury types is `MR_TypeInfo'.
**
** Values of type `std_util:type_ctor_desc' are not guaranteed to be
** represented the same way as values of type `private_builtin:type_ctor_info'.
** The representations *are* in fact identical for first order types, but they
** differ for higher order and tuple types. Instead of a type_ctor_desc
** being a structure containing a pointer to the type_ctor_info for pred/0
** or func/0 and an arity, we have a single small encoded integer. This
** integer is four times the arity, plus zero, one or two; plus zero encodes a
** tuple, plus one encodes a predicate, plus two encodes a function.
** The maximum arity that can be encoded is given by MR_MAX_VARIABLE_ARITY
** (see below).
** The C type corresponding to std_util:type_ctor_desc is `MR_TypeCtorDesc'.
*/

/*
** Declare the MR_TypeCtorDesc ADT.
**
** Note that `struct MR_TypeCtorDesc_Struct' is deliberately left undefined.
** MR_TypeCtorDesc is declared as a pointer to a dummy structure only
** in order to allow the C compiler to catch errors in which things other
** than MR_TypeCtorDescs are given as arguments to macros that depend on their
** arguments being MR_TypeCtorDescs. The actual value is either a small integer
** or a pointer to a MR_TypeCtorInfo_Struct structure, as described above.
*/
typedef struct MR_TypeCtorDesc_Struct *MR_TypeCtorDesc;

/*
** The maximum arity that can be encoded should be set to twice the maximum
** number of general purpose registers, since an predicate or function having
** more arguments that this would run out of registers when passing the input
** arguments, or the output arguments, or both.
**
** XXX When tuples were added this was reduced to be the maximum number
** of general purpose registers, to reduce the probability that the
** `small' integers for higher-order and tuple types are confused with
** type_ctor_info pointers. This still allows higher-order terms with
** 1024 arguments, which is more than ../LIMITATIONS promises.
*/
#define MR_MAX_VARIABLE_ARITY         MR_MAX_VIRTUAL_REG

/*
** Constructors for the MR_TypeCtorDesc ADT
*/

#define MR_TYPECTOR_DESC_MAKE_PRED(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4) )
#define MR_TYPECTOR_DESC_MAKE_FUNC(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4 + 1) )
#define MR_TYPECTOR_DESC_MAKE_TUPLE(Arity)                                      ( (MR_TypeCtorDesc) ((Arity) * 4 + 2) )
#define MR_TYPECTOR_DESC_MAKE_FIXED_ARITY(type_ctor_info)                       ( MR_CHECK_EXPR_TYPE(type_ctor_info, MR_TypeCtorInfo),                    (MR_TypeCtorDesc) type_ctor_info )

/*
** Access macros for the MR_TypeCtor ADT.
**
** The MR_TYPECTOR_DESC_GET_VA_* macros should only be called if
** MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns true.
** The MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO() macro
** should only be called if MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns false.
*/
#define MR_TYPECTOR_DESC_IS_VARIABLE_ARITY(T)                                   ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) <= (4 * MR_MAX_VARIABLE_ARITY + 2) )
#define MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO(T)                      ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_TypeCtorInfo) (T) )
#define MR_TYPECTOR_DESC_GET_VA_ARITY(T)                                        ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) / 4 )
#define MR_TYPECTOR_DESC_GET_VA_NAME(T)                                         ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) (((MR_Unsigned) (T) % 4 == 0)                                ? "pred"                                                              : (((MR_Unsigned) (T) % 4 == 1)                                             ? "func"                                                              : "{}" )) )
#define MR_TYPECTOR_DESC_GET_VA_MODULE_NAME(T)                                  ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) "builtin" )
#define MR_TYPECTOR_DESC_GET_VA_TYPE_CTOR_INFO(T)                               ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 ((MR_Unsigned) (T) % 4 == 0)                                                  ? MR_TYPE_CTOR_INFO_HO_PRED                                             : (((MR_Unsigned) (T) % 4 == 1)                                            ? MR_TYPE_CTOR_INFO_HO_FUNC                                             : MR_TYPE_CTOR_INFO_TUPLE ) )

#endif /* ML_TYPECTORDESC_GUARD */


#line 150 "trans.c"
#line 126 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_CONSTRUCT_INFO_GUARD
#define ML_CONSTRUCT_INFO_GUARD

typedef struct ML_Construct_Info_Struct {
    MR_ConstString          functor_name;
    MR_Integer              arity;
    const MR_PseudoTypeInfo *arg_pseudo_type_infos;
    MR_ConstString          *arg_names;
    MR_TypeCtorRep          type_ctor_rep;
    union {
        const MR_EnumFunctorDesc  *enum_functor_desc;
        const MR_NotagFunctorDesc *notag_functor_desc;
        const MR_DuFunctorDesc    *du_functor_desc;
    }                       functor_info;
} ML_Construct_Info;

#endif

extern  void            ML_type_ctor_and_args(MR_TypeInfo type_info,
                            bool collapse_equivalences,
                            MR_TypeCtorDesc *type_ctor_desc_ptr,
                            MR_Word *arg_type_info_list_ptr);
extern  int     	    ML_get_num_functors(MR_TypeInfo type_info);
extern	MR_Word		    ML_type_params_vector_to_list(int arity,
                            MR_TypeInfoParams type_params);
extern	MR_Word		    ML_arg_name_vector_to_list(int arity,
                            MR_ConstString *arg_names);
extern	MR_Word		    ML_pseudo_type_info_vector_to_type_info_list(int arity,
                            MR_TypeInfoParams type_params,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  bool    	    ML_get_functors_check_range(int functor_number,
                            MR_TypeInfo type_info,
                            ML_Construct_Info *construct_info);
extern  void    	    ML_copy_arguments_from_list_to_vector(int arity,
                            MR_Word arg_list, MR_Word term_vector);
extern  bool    	    ML_typecheck_arguments(MR_TypeInfo type_info,
                            int arity, MR_Word arg_list,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  MR_TypeInfo	    ML_make_type(int arity, MR_TypeCtorDesc type_ctor_desc,
				             MR_Word arg_type_list);

#line 196 "trans.c"
#line 170 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


extern	MR_TypeCtorDesc ML_make_type_ctor_desc(MR_TypeInfo type_info,
				MR_TypeCtorInfo type_ctor_info);


#line 204 "trans.c"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


    #include <stdio.h>
	#include "mercury_library_types.h"		/* for MR_ArrayType */

#ifdef MR_DEEP_PROFILING
    #include "mercury_deep_profiling.h"
#endif

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef	ML_EXPAND_INFO_GUARD
#define	ML_EXPAND_INFO_GUARD

typedef struct {
    int                     num_extra_args;
    MR_Word                 *arg_values;
    MR_TypeInfo             *arg_type_infos;
    bool                    can_free_arg_type_infos;
} ML_Expand_Args_Fields;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
} ML_Expand_Functor_Args_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
    bool                    limit_reached;
} ML_Expand_Functor_Args_Limit_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor_only;
} ML_Expand_Functor_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    ML_Expand_Args_Fields   args_only;
} ML_Expand_Args_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    bool                    chosen_index_exists;
    MR_Word                 *chosen_value_ptr;
    MR_TypeInfo             chosen_type_info;
} ML_Expand_Chosen_Arg_Only_Info;

    /* Prototypes */

extern  void    ML_expand_functor_args(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Args_Info *expand_info);

extern  void    ML_expand_functor_args_limit(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int max_arity,
                    ML_Expand_Functor_Args_Limit_Info *expand_info);

extern  void    ML_expand_functor_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Only_Info *expand_info);

extern  void    ML_expand_args_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Args_Only_Info *expand_info);

extern  void    ML_expand_chosen_arg_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int chosen,
                    ML_Expand_Chosen_Arg_Only_Info *expand_info);

    /*
    ** NB. ML_arg() is also used by arg_ref and new_arg_ref
    ** in store.m, in trace/mercury_trace_vars.m, and in
    ** extras/trailed_update/tr_store.m.
    */
extern  bool    ML_arg(MR_TypeInfo type_info, MR_Word *term, int arg_index,
                    MR_TypeInfo *arg_type_info_ptr, MR_Word **argument_ptr);

    /*
    ** NB. ML_named_arg_num() is used in mercury_trace_vars.c.
    */
extern  bool    ML_named_arg_num(MR_TypeInfo type_info, MR_Word *term_ptr,
                    const char *arg_name, int *arg_num_ptr);

/*
** The following macros factor out the common parts of the various
** deconstruction predicates.
*/

    /*
    ** Check for attempts to deconstruct a non-canonical type.
    ** Such deconstructions must be cc_multi, which is why we treat
    ** violations of this as runtime errors in det deconstruction
    ** predicates.
    ** (There ought to be cc_multi versions of those predicates.)
    */
#define ML_abort_if_type_is_noncanonical(ei, predname)                  do {                                                                    if ((ei).non_canonical_type) {                                          MR_fatal_error("called " predname " for a type "                    "with a user-defined equality predicate");                }                                                               } while (0)

#endif

#define ML_deconstruct_get_functor(ei, functor_field, var)              do {                                                                    MR_make_aligned_string(MR_LVALUE_CAST(MR_ConstString, var),             (ei).functor_field);                                        } while (0)

#define ML_deconstruct_get_arity(ei, var)                               do {                                                                    var = (ei).arity;                                               } while (0)

#define ML_deconstruct_get_arg_list(ei, args_field, var)                do {                                                                    int     i;                                                                                                                              var = MR_list_empty_msg(MR_PROC_LABEL);                             i = (ei).arity;                                                                                                                         while (--i >= 0) {                                                      MR_Word arg;                                                                                                                                /* Create an argument on the heap */                            MR_new_univ_on_hp(arg,                                                  (ei).args_field.arg_type_infos[i],                                  (ei).args_field.arg_values[i +                                          (ei).args_field.num_extra_args]);                                                                                                   /* Join the argument to the front of the list */                var = MR_list_cons_msg(arg, var, MR_PROC_LABEL);                }                                                               } while (0)

    /*
    ** Free any arg_type_infos allocated by the ML_expand variant.
    ** Should be called after we have used them for the last time.
    */
#define ML_deconstruct_free_allocated_arg_type_infos(ei, args_field)    do {                                                                    if ((ei).args_field.can_free_arg_type_infos) {                          MR_GC_free((ei).args_field.arg_type_infos);                     }                                                               } while (0)


#line 326 "trans.c"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"


	#include <math.h>

	/*
	** Mathematical constants.
	**
	** The maximum number of significant decimal digits which
	** can be packed into an IEEE-754 extended precision
	** floating point number is 18.  Therefore 20 significant
	** decimal digits for these constants should be plenty.
	*/

	#define	ML_FLOAT_E		2.7182818284590452354
	#define	ML_FLOAT_PI		3.1415926535897932384
	#define	ML_FLOAT_LN2		0.69314718055994530941


#line 346 "trans.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#include <string.h>
#include <stdio.h>

#include "mercury_string.h"	/* for MR_allocate_aligned_string*() etc. */
#include "mercury_tags.h"	/* for MR_list_cons*() */

#line 355 "trans.c"
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#ifdef USE_GCC_GLOBAL_REGISTERS
	/*
	** GNU C version egcs-1.1.2 crashes with `fixed or forbidden
	** register spilled' in grade asm_fast.gc.tr.debug
	** if we write this inline.
	*/
	static void MR_set_char(MR_String str, MR_Integer ind, MR_Char ch)
	{
		str[ind] = ch;
	}
#else
	#define MR_set_char(str, ind, ch) \
		((str)[ind] = (ch))
#endif

#line 373 "trans.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_DETERMINISM_GUARD
#define ML_DETERMINISM_GUARD
	/*
	** The enumeration constants in this enum must be in the same
	** order as the functors in the Mercury type `determinism'
	** defined above.
	*/
	typedef enum {
		ML_DET,
		ML_SEMIDET,
		ML_CC_MULTI,
		ML_CC_NONDET,
		ML_MULTI,
		ML_NONDET,
		ML_ERRONEOUS,
		ML_FAILURE
	} ML_Determinism;
#endif

#line 396 "trans.c"
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* protect against multiple inclusion */
#ifndef MR_HLC_EXCEPTION_GUARD
#define MR_HLC_EXCEPTION_GUARD

#ifdef MR_HIGHLEVEL_CODE

  #ifdef MR_USE_GCC_NESTED_FUNCTIONS
  	#define MR_CONT_PARAMS		MR_NestedCont cont
  	#define MR_CONT_PARAM_TYPES	MR_NestedCont
  	#define MR_CONT_ARGS		cont
  #else
  	#define MR_CONT_PARAMS		MR_Cont cont, void *cont_env
  	#define MR_CONT_PARAM_TYPES	MR_Cont, void *
  	#define MR_CONT_ARGS		cont, cont_env
  #endif

	/* det */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_0(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* semidet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_1(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_2(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_nondet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_3(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_4(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

	/* nondet */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_5(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

  #ifndef MR_AVOID_MACROS

	/* det ==> model_det */
	#define mercury__exception__builtin_catch_3_p_0 		mercury__exception__builtin_catch_model_det

	/* semidet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_1 		mercury__exception__builtin_catch_model_semi

	/* cc_multi ==> model_det */
	#define mercury__exception__builtin_catch_3_p_2 		mercury__exception__builtin_catch_model_det

	/* cc_nondet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_3 		mercury__exception__builtin_catch_model_semi

	/* multi ==> model_non */
	#define mercury__exception__builtin_catch_3_p_4 		mercury__exception__builtin_catch_model_non

	/* nondet ==> model_non */
	#define mercury__exception__builtin_catch_3_p_5 		mercury__exception__builtin_catch_model_non

  #endif /* !MR_AVOID_MACROS */

	void MR_CALL mercury__exception__builtin_throw_1_p_0(MR_Univ exception);

	void MR_CALL mercury__exception__builtin_catch_model_det(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	bool MR_CALL mercury__exception__builtin_catch_model_semi(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	void MR_CALL mercury__exception__builtin_catch_model_non(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

#endif /* MR_HIGHLEVEL_CODE */

#endif /* MR_HLC_EXCEPTION_GUARD */

#line 486 "trans.c"
#line 147 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

#ifndef MR_HIGHLEVEL_CODE
	#include <assert.h>
	#include <stdio.h>
	#include "mercury_deep_copy.h"
	#include "mercury_trace_base.h"
	#include "mercury_stack_trace.h"
	#include "mercury_layout_util.h"
	#include "mercury_deep_profiling_hand.h"

	MR_DECLARE_TYPE_CTOR_INFO_STRUCT( 			mercury_data_std_util__type_ctor_info_univ_0);
#endif

#line 501 "trans.c"
#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	extern MR_Word		ML_io_stream_names;
	extern MR_Word		ML_io_user_globals;
	#if 0
	  extern MR_Word	ML_io_ops_table;
	#endif

#line 510 "trans.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
#ifdef HAVE_SYS_STAT_H
	#include <sys/stat.h>
#endif

#line 520 "trans.c"
#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include "mercury_init.h"
#include "mercury_wrapper.h"
#include "mercury_type_info.h"
#include "mercury_library_types.h"
#include "mercury_file.h"
#include "mercury_heap.h"
#include "mercury_misc.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

#ifdef HAVE_SYS_WAIT
  #include <sys/wait.h>		/* for WIFEXITED, WEXITSTATUS, etc. */
#endif

extern MercuryFile mercury_stdin;
extern MercuryFile mercury_stdout;
extern MercuryFile mercury_stderr;
extern MercuryFile mercury_stdin_binary;
extern MercuryFile mercury_stdout_binary;
extern MercuryFile *mercury_current_text_input;
extern MercuryFile *mercury_current_text_output;
extern MercuryFile *mercury_current_binary_input;
extern MercuryFile *mercury_current_binary_output;

#define initial_io_state()		0	/* some random number */
#define update_io(r_src, r_dest)	((r_dest) = (r_src))
#define final_io_state(r)		((void)0)

void 		mercury_init_io(void);
MercuryFile*	mercury_open(const char *filename, const char *type);
void		mercury_io_error(MercuryFile* mf, const char *format, ...);
void		mercury_output_error(MercuryFile* mf);
void		mercury_print_string(MercuryFile* mf, const char *s);
void		mercury_print_binary_string(MercuryFile* mf, const char *s);
int		mercury_getc(MercuryFile* mf);
void		mercury_close(MercuryFile* mf);
int		ML_fprintf(MercuryFile* mf, const char *format, ...);

#line 566 "trans.c"
#line 106 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <fcntl.h>

	#define	MAX_TEMPNAME_TRIES	(6 * 4)

	extern long ML_io_tempnam_counter;

#line 580 "trans.c"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include <string.h>
#include <errno.h>

/*
** ML_maybe_make_err_msg(was_error, msg, procname, error_msg):
**	if `was_error' is true, then append `msg' and `strerror(errno)'
**	to give `error_msg'; otherwise, set `error_msg' to NULL.
**
** WARNING: this must only be called when the `hp' register is valid.
** That means it must only be called from procedures declared
** `will_not_call_mercury'.
**
** This is defined as a macro rather than a C function
** to avoid worrying about the `hp' register being
** invalidated by the function call.
** It also needs to be a macro because MR_incr_hp_atomic_msg()
** stringizes the procname argument.
*/
#define ML_maybe_make_err_msg(was_error, msg, procname, error_msg)	\
	do {								\
		char *errno_msg;					\
		size_t total_len;					\
		MR_Word tmp;						\
									\
		if (was_error) {					\
			errno_msg = strerror(errno);			\
			total_len = strlen(msg) + strlen(errno_msg);	\
			MR_incr_hp_atomic_msg(tmp,			\
				(total_len + sizeof(MR_Word))		\
					/ sizeof(MR_Word),		\
				procname,				\
				"string:string/0");			\
			(error_msg) = (char *)tmp;			\
			strcpy((error_msg), msg);			\
			strcat((error_msg), errno_msg);			\
		} else {						\
			(error_msg) = NULL;				\
		}							\
	} while(0)


#line 625 "trans.c"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#include <float.h>
	#include <math.h>


#line 633 "trans.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#define	ML_FLOAT_RADIX	FLT_RADIX	/* There is no DBL_RADIX. */

	#if defined USE_SINGLE_PREC_FLOAT
		#define	ML_FLOAT_MAX		FLT_MAX
		#define	ML_FLOAT_MIN		FLT_MIN
		#define	ML_FLOAT_EPSILON	FLT_EPSILON
		#define	ML_FLOAT_MANT_DIG	FLT_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	FLT_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	FLT_MAX_EXP
	#else
		#define	ML_FLOAT_MAX		DBL_MAX
		#define	ML_FLOAT_MIN		DBL_MIN
		#define	ML_FLOAT_EPSILON	DBL_EPSILON
		#define	ML_FLOAT_MANT_DIG	DBL_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	DBL_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	DBL_MAX_EXP
	#endif


#line 656 "trans.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 659 "trans.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 665 "trans.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 673 "trans.c"


static const struct mercury_data_trans__common_0_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
	MR_Word * f4;
	MR_Word * f5;
	MR_Word * f6;
	MR_Word * f7;
	MR_Word * f8;
	MR_Word * f9;
	MR_Word * f10;
	MR_Word * f11;
	MR_Word * f12;
}  mercury_data_trans__common_0;

static const struct mercury_data_trans__common_1_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_data_trans__common_1;

static const struct mercury_data_trans__common_2_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_trans__common_2;

static const struct mercury_data_trans__common_3_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_trans__common_3;

static const struct mercury_data_trans__common_4_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_trans__common_4;

static const struct mercury_data_trans__common_5_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_trans__common_5;

static const struct mercury_data_trans__common_6_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_trans__common_6;

static const struct mercury_data_trans__common_7_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_trans__common_7;
extern const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_trans_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_surface_coordinates_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_matrix_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_intersections_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_intersection_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_face_intersections_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_face_intersection_0;
extern const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_trans_0[];
static const MR_DuFunctorDesc mercury_data_trans__du_functor_desc_trans_0_0;
extern const MR_PseudoTypeInfo mercury_data_trans__field_types_trans_0_0[];
extern const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_trans_0[];
extern const MR_DuFunctorDesc * mercury_data_trans__du_stag_ordered_trans_0_0[];
extern const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_surface_coordinates_0[];
static const MR_DuFunctorDesc mercury_data_trans__du_functor_desc_surface_coordinates_0_0;
extern const MR_ConstString mercury_data_trans__field_names_surface_coordinates_0_0[];
extern const MR_PseudoTypeInfo mercury_data_trans__field_types_surface_coordinates_0_0[];
extern const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_surface_coordinates_0[];
extern const MR_DuFunctorDesc * mercury_data_trans__du_stag_ordered_surface_coordinates_0_0[];
extern const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_matrix_0[];
static const MR_DuFunctorDesc mercury_data_trans__du_functor_desc_matrix_0_0;
extern const MR_PseudoTypeInfo mercury_data_trans__field_types_matrix_0_0[];
extern const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_matrix_0[];
extern const MR_DuFunctorDesc * mercury_data_trans__du_stag_ordered_matrix_0_0[];
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_21_trans__intersection_0;
extern const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_intersection_0[];
static const MR_DuFunctorDesc mercury_data_trans__du_functor_desc_intersection_0_0;
extern const MR_ConstString mercury_data_trans__field_names_intersection_0_0[];
extern const MR_PseudoTypeInfo mercury_data_trans__field_types_intersection_0_0[];
extern const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_intersection_0[];
extern const MR_DuFunctorDesc * mercury_data_trans__du_stag_ordered_intersection_0_0[];
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_26_trans__face_intersection_0;
extern const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_face_intersection_0[];
static const MR_DuFunctorDesc mercury_data_trans__du_functor_desc_face_intersection_0_0;
extern const MR_PseudoTypeInfo mercury_data_trans__field_types_face_intersection_0_0[];
extern const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_face_intersection_0[];
extern const MR_DuFunctorDesc * mercury_data_trans__du_stag_ordered_face_intersection_0_0[];
MR_declare_static(mercury__trans__list__map__ho7__ua0_3_0);
MR_declare_label(mercury__trans__list__map__ho7__ua0_3_0_i4);
MR_declare_label(mercury__trans__list__map__ho7__ua0_3_0_i5);
MR_declare_label(mercury__trans__list__map__ho7__ua0_3_0_i3);
MR_declare_static(mercury__trans__list__map__ho6__ua0_3_0);
MR_declare_label(mercury__trans__list__map__ho6__ua0_3_0_i4);
MR_declare_label(mercury__trans__list__map__ho6__ua0_3_0_i5);
MR_declare_label(mercury__trans__list__map__ho6__ua0_3_0_i3);
MR_declare_static(mercury__trans__list__map__ho5__ua0_3_0);
MR_declare_label(mercury__trans__list__map__ho5__ua0_3_0_i4);
MR_declare_label(mercury__trans__list__map__ho5__ua0_3_0_i5);
MR_declare_label(mercury__trans__list__map__ho5__ua0_3_0_i3);
MR_declare_static(mercury__fn__trans__list__map__ho4__ua0_2_0);
MR_define_extern_entry(mercury__fn__trans__point_to_object_space_2_0);
MR_define_extern_entry(mercury__fn__trans__vector_to_object_space_2_0);
MR_define_extern_entry(mercury__fn__trans__normal_to_object_space_2_0);
MR_define_extern_entry(mercury__fn__trans__point_to_world_space_2_0);
MR_define_extern_entry(mercury__fn__trans__vector_to_world_space_2_0);
MR_define_extern_entry(mercury__fn__trans__normal_to_world_space_2_0);
MR_define_extern_entry(mercury__fn__trans__identity_0_0);
MR_define_extern_entry(mercury__fn__trans__compose_translate_4_0);
MR_define_extern_entry(mercury__fn__trans__compose_scale_4_0);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i5);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i7);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i3);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i13);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i15);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i17);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i20);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i22);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i24);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i27);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i29);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i31);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i34);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i36);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i38);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i41);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i43);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i45);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i131);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i50);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i51);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i53);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i54);
MR_declare_label(mercury__fn__trans__compose_scale_4_0_i55);
MR_define_extern_entry(mercury__fn__trans__compose_uscale_2_0);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i2);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i7);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i9);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i11);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i14);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i16);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i18);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i21);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i23);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i25);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i28);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i30);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i32);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i35);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i37);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i39);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i42);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i44);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i46);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i155);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i51);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i52);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i54);
MR_declare_label(mercury__fn__trans__compose_uscale_2_0_i55);
MR_define_extern_entry(mercury__fn__trans__compose_rotatex_2_0);
MR_declare_label(mercury__fn__trans__compose_rotatex_2_0_i4);
MR_declare_label(mercury__fn__trans__compose_rotatex_2_0_i6);
MR_declare_label(mercury__fn__trans__compose_rotatex_2_0_i8);
MR_define_extern_entry(mercury__fn__trans__compose_rotatey_2_0);
MR_declare_label(mercury__fn__trans__compose_rotatey_2_0_i4);
MR_declare_label(mercury__fn__trans__compose_rotatey_2_0_i6);
MR_declare_label(mercury__fn__trans__compose_rotatey_2_0_i8);
MR_define_extern_entry(mercury__fn__trans__compose_rotatez_2_0);
MR_declare_label(mercury__fn__trans__compose_rotatez_2_0_i4);
MR_declare_label(mercury__fn__trans__compose_rotatez_2_0_i6);
MR_declare_label(mercury__fn__trans__compose_rotatez_2_0_i8);
MR_define_extern_entry(mercury__trans__intersects_plane_6_0);
MR_declare_label(mercury__trans__intersects_plane_6_0_i2);
MR_declare_label(mercury__trans__intersects_plane_6_0_i9);
MR_declare_label(mercury__trans__intersects_plane_6_0_i11);
MR_declare_label(mercury__trans__intersects_plane_6_0_i12);
MR_declare_label(mercury__trans__intersects_plane_6_0_i14);
MR_declare_label(mercury__trans__intersects_plane_6_0_i15);
MR_declare_label(mercury__trans__intersects_plane_6_0_i16);
MR_declare_label(mercury__trans__intersects_plane_6_0_i4);
MR_define_extern_entry(mercury__trans__intersects_sphere_6_0);
MR_declare_label(mercury__trans__intersects_sphere_6_0_i2);
MR_declare_label(mercury__trans__intersects_sphere_6_0_i3);
MR_declare_label(mercury__trans__intersects_sphere_6_0_i6);
MR_declare_label(mercury__trans__intersects_sphere_6_0_i8);
MR_declare_label(mercury__trans__intersects_sphere_6_0_i9);
MR_declare_label(mercury__trans__intersects_sphere_6_0_i10);
MR_declare_label(mercury__trans__intersects_sphere_6_0_i5);
MR_define_extern_entry(mercury__trans__intersects_cube_6_0);
MR_declare_label(mercury__trans__intersects_cube_6_0_i2);
MR_declare_label(mercury__trans__intersects_cube_6_0_i3);
MR_declare_label(mercury__trans__intersects_cube_6_0_i4);
MR_declare_label(mercury__trans__intersects_cube_6_0_i5);
MR_declare_label(mercury__trans__intersects_cube_6_0_i6);
MR_declare_label(mercury__trans__intersects_cube_6_0_i7);
MR_declare_label(mercury__trans__intersects_cube_6_0_i8);
MR_declare_label(mercury__trans__intersects_cube_6_0_i9);
MR_define_extern_entry(mercury__trans__intersects_cylinder_6_0);
MR_declare_label(mercury__trans__intersects_cylinder_6_0_i2);
MR_declare_label(mercury__trans__intersects_cylinder_6_0_i3);
MR_declare_label(mercury__trans__intersects_cylinder_6_0_i4);
MR_declare_label(mercury__trans__intersects_cylinder_6_0_i5);
MR_declare_label(mercury__trans__intersects_cylinder_6_0_i6);
MR_define_extern_entry(mercury__trans__intersects_cone_6_0);
MR_declare_label(mercury__trans__intersects_cone_6_0_i2);
MR_declare_label(mercury__trans__intersects_cone_6_0_i3);
MR_declare_label(mercury__trans__intersects_cone_6_0_i4);
MR_declare_label(mercury__trans__intersects_cone_6_0_i5);
MR_define_extern_entry(mercury__trans__inside_sphere_2_0);
MR_define_extern_entry(mercury__trans__inside_plane_2_0);
MR_define_extern_entry(mercury__trans__inside_cube_2_0);
MR_declare_label(mercury__trans__inside_cube_2_0_i1);
MR_define_extern_entry(mercury__trans__inside_cylinder_2_0);
MR_declare_label(mercury__trans__inside_cylinder_2_0_i1);
MR_define_extern_entry(mercury__trans__inside_cone_2_0);
MR_declare_label(mercury__trans__inside_cone_2_0_i1);
MR_define_extern_entry(mercury__trans__show_trans_3_0);
MR_declare_label(mercury__trans__show_trans_3_0_i2);
MR_declare_label(mercury__trans__show_trans_3_0_i3);
MR_declare_label(mercury__trans__show_trans_3_0_i4);
MR_declare_label(mercury__trans__show_trans_3_0_i5);
MR_declare_label(mercury__trans__show_trans_3_0_i6);
MR_declare_label(mercury__trans__show_trans_3_0_i7);
MR_declare_label(mercury__trans__show_trans_3_0_i8);
MR_define_extern_entry(mercury__fn__trans__unit_matrix_0_0);
MR_define_extern_entry(mercury__fn__trans__transform_point_2_0);
MR_define_extern_entry(mercury__fn__trans__transform_vector_2_0);
MR_define_extern_entry(mercury__fn__trans__transform_normal_2_0);
MR_declare_static(mercury__trans__intersects_sphere_2_11_0);
MR_declare_label(mercury__trans__intersects_sphere_2_11_0_i2);
MR_declare_label(mercury__trans__intersects_sphere_2_11_0_i3);
MR_declare_label(mercury__trans__intersects_sphere_2_11_0_i4);
MR_declare_static(mercury__fn__trans__process_cube_intersections_4_0);
MR_declare_label(mercury__fn__trans__process_cube_intersections_4_0_i2);
MR_declare_label(mercury__fn__trans__process_cube_intersections_4_0_i4);
MR_declare_label(mercury__fn__trans__process_cube_intersections_4_0_i6);
MR_declare_label(mercury__fn__trans__process_cube_intersections_4_0_i8);
MR_declare_label(mercury__fn__trans__process_cube_intersections_4_0_i10);
MR_declare_label(mercury__fn__trans__process_cube_intersections_4_0_i12);
MR_declare_label(mercury__fn__trans__process_cube_intersections_4_0_i14);
MR_declare_label(mercury__fn__trans__process_cube_intersections_4_0_i21);
MR_declare_label(mercury__fn__trans__process_cube_intersections_4_0_i22);
MR_declare_static(mercury__fn__trans__z_face_intersection_8_0);
MR_declare_label(mercury__fn__trans__z_face_intersection_8_0_i2);
MR_declare_label(mercury__fn__trans__z_face_intersection_8_0_i6);
MR_declare_label(mercury__fn__trans__z_face_intersection_8_0_i8);
MR_declare_label(mercury__fn__trans__z_face_intersection_8_0_i10);
MR_declare_label(mercury__fn__trans__z_face_intersection_8_0_i21);
MR_declare_label(mercury__fn__trans__z_face_intersection_8_0_i11);
MR_declare_static(mercury__fn__trans__x_face_intersection_8_0);
MR_declare_label(mercury__fn__trans__x_face_intersection_8_0_i2);
MR_declare_label(mercury__fn__trans__x_face_intersection_8_0_i6);
MR_declare_label(mercury__fn__trans__x_face_intersection_8_0_i8);
MR_declare_label(mercury__fn__trans__x_face_intersection_8_0_i10);
MR_declare_label(mercury__fn__trans__x_face_intersection_8_0_i21);
MR_declare_label(mercury__fn__trans__x_face_intersection_8_0_i11);
MR_declare_static(mercury__fn__trans__y_face_intersection_8_0);
MR_declare_label(mercury__fn__trans__y_face_intersection_8_0_i2);
MR_declare_label(mercury__fn__trans__y_face_intersection_8_0_i6);
MR_declare_label(mercury__fn__trans__y_face_intersection_8_0_i8);
MR_declare_label(mercury__fn__trans__y_face_intersection_8_0_i10);
MR_declare_label(mercury__fn__trans__y_face_intersection_8_0_i21);
MR_declare_label(mercury__fn__trans__y_face_intersection_8_0_i11);
MR_declare_static(mercury__fn__trans__process_cylinder_intersections_4_0);
MR_declare_label(mercury__fn__trans__process_cylinder_intersections_4_0_i6);
MR_declare_label(mercury__fn__trans__process_cylinder_intersections_4_0_i8);
MR_declare_label(mercury__fn__trans__process_cylinder_intersections_4_0_i9);
MR_declare_label(mercury__fn__trans__process_cylinder_intersections_4_0_i11);
MR_declare_label(mercury__fn__trans__process_cylinder_intersections_4_0_i2);
MR_declare_label(mercury__fn__trans__process_cylinder_intersections_4_0_i13);
MR_declare_label(mercury__fn__trans__process_cylinder_intersections_4_0_i15);
MR_declare_label(mercury__fn__trans__process_cylinder_intersections_4_0_i17);
MR_declare_label(mercury__fn__trans__process_cylinder_intersections_4_0_i21);
MR_declare_label(mercury__fn__trans__process_cylinder_intersections_4_0_i22);
MR_declare_static(mercury__fn__trans__process_cone_intersections_4_0);
MR_declare_label(mercury__fn__trans__process_cone_intersections_4_0_i6);
MR_declare_label(mercury__fn__trans__process_cone_intersections_4_0_i8);
MR_declare_label(mercury__fn__trans__process_cone_intersections_4_0_i10);
MR_declare_label(mercury__fn__trans__process_cone_intersections_4_0_i11);
MR_declare_label(mercury__fn__trans__process_cone_intersections_4_0_i13);
MR_declare_label(mercury__fn__trans__process_cone_intersections_4_0_i2);
MR_declare_label(mercury__fn__trans__process_cone_intersections_4_0_i14);
MR_declare_label(mercury__fn__trans__process_cone_intersections_4_0_i16);
MR_declare_label(mercury__fn__trans__process_cone_intersections_4_0_i19);
MR_declare_label(mercury__fn__trans__process_cone_intersections_4_0_i20);
MR_declare_static(mercury__fn__trans__cylinder_intersection_7_0);
MR_declare_static(mercury__fn__trans__cone_intersection_7_0);
MR_declare_static(mercury__fn__trans__solve_quadratic_10_0);
MR_declare_label(mercury__fn__trans__solve_quadratic_10_0_i2);
MR_declare_label(mercury__fn__trans__solve_quadratic_10_0_i3);
MR_declare_label(mercury__fn__trans__solve_quadratic_10_0_i5);
MR_declare_label(mercury__fn__trans__solve_quadratic_10_0_i8);
MR_declare_label(mercury__fn__trans__solve_quadratic_10_0_i10);
MR_declare_label(mercury__fn__trans__solve_quadratic_10_0_i12);
MR_declare_label(mercury__fn__trans__solve_quadratic_10_0_i15);
MR_declare_label(mercury__fn__trans__solve_quadratic_10_0_i17);
MR_declare_label(mercury__fn__trans__solve_quadratic_10_0_i18);
MR_declare_label(mercury__fn__trans__solve_quadratic_10_0_i21);
MR_declare_static(mercury__trans__maybe_add_intersection_10_0);
MR_declare_label(mercury__trans__maybe_add_intersection_10_0_i2);
MR_declare_static(mercury__fn__trans__disc_intersection_8_0);
MR_declare_label(mercury__fn__trans__disc_intersection_8_0_i2);
MR_declare_label(mercury__fn__trans__disc_intersection_8_0_i6);
MR_declare_label(mercury__fn__trans__disc_intersection_8_0_i8);
MR_declare_label(mercury__fn__trans__disc_intersection_8_0_i10);
MR_declare_label(mercury__fn__trans__disc_intersection_8_0_i21);
MR_declare_label(mercury__fn__trans__disc_intersection_8_0_i11);
MR_declare_static(mercury__fn__trans__calc_u_2_0);
MR_declare_label(mercury__fn__trans__calc_u_2_0_i4);
MR_declare_label(mercury__fn__trans__calc_u_2_0_i6);
MR_declare_label(mercury__fn__trans__calc_u_2_0_i8);
MR_declare_label(mercury__fn__trans__calc_u_2_0_i9);
MR_declare_label(mercury__fn__trans__calc_u_2_0_i10);
MR_define_extern_entry(mercury____Unify___trans__surface_coordinates_0_0);
MR_declare_label(mercury____Unify___trans__surface_coordinates_0_0_i1);
MR_define_extern_entry(mercury____Compare___trans__surface_coordinates_0_0);
MR_declare_label(mercury____Compare___trans__surface_coordinates_0_0_i4);
MR_declare_label(mercury____Compare___trans__surface_coordinates_0_0_i3);
MR_declare_label(mercury____Compare___trans__surface_coordinates_0_0_i16);
MR_declare_label(mercury____Compare___trans__surface_coordinates_0_0_i15);
MR_declare_label(mercury____Compare___trans__surface_coordinates_0_0_i26);
MR_declare_label(mercury____Compare___trans__surface_coordinates_0_0_i27);
MR_define_extern_entry(mercury____Unify___trans__trans_0_0);
MR_declare_label(mercury____Unify___trans__trans_0_0_i1);
MR_define_extern_entry(mercury____Compare___trans__trans_0_0);
MR_declare_label(mercury____Compare___trans__trans_0_0_i3);
MR_declare_label(mercury____Compare___trans__trans_0_0_i7);
MR_define_extern_entry(mercury____Unify___trans__intersection_0_0);
MR_declare_label(mercury____Unify___trans__intersection_0_0_i2);
MR_declare_label(mercury____Unify___trans__intersection_0_0_i4);
MR_declare_label(mercury____Unify___trans__intersection_0_0_i1);
MR_define_extern_entry(mercury____Compare___trans__intersection_0_0);
MR_declare_label(mercury____Compare___trans__intersection_0_0_i4);
MR_declare_label(mercury____Compare___trans__intersection_0_0_i3);
MR_declare_label(mercury____Compare___trans__intersection_0_0_i15);
MR_declare_label(mercury____Compare___trans__intersection_0_0_i19);
MR_declare_label(mercury____Compare___trans__intersection_0_0_i23);
MR_declare_label(mercury____Compare___trans__intersection_0_0_i30);
MR_define_extern_entry(mercury____Unify___trans__intersections_0_0);
MR_define_extern_entry(mercury____Compare___trans__intersections_0_0);
MR_define_extern_entry(mercury____Unify___trans__matrix_0_0);
MR_declare_label(mercury____Unify___trans__matrix_0_0_i1);
MR_define_extern_entry(mercury____Compare___trans__matrix_0_0);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i4);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i3);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i16);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i15);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i28);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i27);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i40);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i39);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i52);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i51);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i64);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i63);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i76);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i75);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i88);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i87);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i100);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i99);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i112);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i111);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i124);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i123);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i134);
MR_declare_label(mercury____Compare___trans__matrix_0_0_i135);
MR_define_extern_entry(mercury____Unify___trans__face_intersection_0_0);
MR_declare_label(mercury____Unify___trans__face_intersection_0_0_i1);
MR_define_extern_entry(mercury____Compare___trans__face_intersection_0_0);
MR_declare_label(mercury____Compare___trans__face_intersection_0_0_i4);
MR_declare_label(mercury____Compare___trans__face_intersection_0_0_i3);
MR_declare_label(mercury____Compare___trans__face_intersection_0_0_i16);
MR_declare_label(mercury____Compare___trans__face_intersection_0_0_i15);
MR_declare_label(mercury____Compare___trans__face_intersection_0_0_i28);
MR_declare_label(mercury____Compare___trans__face_intersection_0_0_i27);
MR_declare_label(mercury____Compare___trans__face_intersection_0_0_i38);
MR_declare_label(mercury____Compare___trans__face_intersection_0_0_i39);
MR_define_extern_entry(mercury____Unify___trans__face_intersections_0_0);
MR_define_extern_entry(mercury____Compare___trans__face_intersections_0_0);

static const MR_Float mercury_float_const_1pt00000000000000 = 1.00000000000000;
static const MR_Float mercury_float_const_0pt00000000000000 = 0.00000000000000;
static const struct mercury_data_trans__common_0_struct mercury_data_trans__common_0 = {
	(MR_Word *) &mercury_float_const_1pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_1pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_1pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000
};

static const struct mercury_data_trans__common_1_struct mercury_data_trans__common_1 = {
	MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_trans__common_0),
	MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_trans__common_0)
};

static const struct mercury_data_trans__common_2_struct mercury_data_trans__common_2 = {
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_1pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000
};

static const MR_Float mercury_float_const_neg1pt00000000000000 = -1.00000000000000;
static const struct mercury_data_trans__common_3_struct mercury_data_trans__common_3 = {
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_neg1pt00000000000000
};

static const struct mercury_data_trans__common_4_struct mercury_data_trans__common_4 = {
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_1pt00000000000000
};

static const struct mercury_data_trans__common_5_struct mercury_data_trans__common_5 = {
	(MR_Word *) &mercury_float_const_neg1pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000
};

static const struct mercury_data_trans__common_6_struct mercury_data_trans__common_6 = {
	(MR_Word *) &mercury_float_const_1pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000
};

static const struct mercury_data_trans__common_7_struct mercury_data_trans__common_7 = {
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_neg1pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000
};
extern const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_trans_0[];
extern const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_trans_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_trans_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__trans_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__trans_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___trans__trans_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"trans",
	"trans",
	4,
	{ (void *) mercury_data_trans__du_name_ordered_trans_0 },
	{ (void *) mercury_data_trans__du_ptag_ordered_trans_0 },
	1,
	1
};
extern const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_surface_coordinates_0[];
extern const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_surface_coordinates_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_surface_coordinates_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__surface_coordinates_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__surface_coordinates_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___trans__surface_coordinates_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"trans",
	"surface_coordinates",
	4,
	{ (void *) mercury_data_trans__du_name_ordered_surface_coordinates_0 },
	{ (void *) mercury_data_trans__du_ptag_ordered_surface_coordinates_0 },
	1,
	1
};
extern const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_matrix_0[];
extern const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_matrix_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_matrix_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__matrix_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__matrix_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___trans__matrix_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"trans",
	"matrix",
	4,
	{ (void *) mercury_data_trans__du_name_ordered_matrix_0 },
	{ (void *) mercury_data_trans__du_ptag_ordered_matrix_0 },
	1,
	1
};
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_21_trans__intersection_0;

const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_intersections_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__intersections_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__intersections_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___trans__intersections_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"trans",
	"intersections",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_21_trans__intersection_0 },
	-1,
	-1
};
extern const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_intersection_0[];
extern const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_intersection_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_intersection_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__intersection_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__intersection_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___trans__intersection_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"trans",
	"intersection",
	4,
	{ (void *) mercury_data_trans__du_name_ordered_intersection_0 },
	{ (void *) mercury_data_trans__du_ptag_ordered_intersection_0 },
	1,
	1
};
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_26_trans__face_intersection_0;

const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_face_intersections_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__face_intersections_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__face_intersections_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___trans__face_intersections_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"trans",
	"face_intersections",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_26_trans__face_intersection_0 },
	-1,
	-1
};
extern const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_face_intersection_0[];
extern const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_face_intersection_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_face_intersection_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__face_intersection_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___trans__face_intersection_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___trans__face_intersection_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"trans",
	"face_intersection",
	4,
	{ (void *) mercury_data_trans__du_name_ordered_face_intersection_0 },
	{ (void *) mercury_data_trans__du_ptag_ordered_face_intersection_0 },
	1,
	1
};

const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_trans_0[] = {
	&mercury_data_trans__du_functor_desc_trans_0_0
};

static const MR_DuFunctorDesc mercury_data_trans__du_functor_desc_trans_0_0 = {
	"trans",
	2,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_trans__field_types_trans_0_0,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_matrix_0;

const MR_PseudoTypeInfo mercury_data_trans__field_types_trans_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_trans__type_ctor_info_matrix_0,
	(MR_PseudoTypeInfo) &mercury_data_trans__type_ctor_info_matrix_0
};

const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_trans_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_trans__du_stag_ordered_trans_0_0 }

};

const MR_DuFunctorDesc * mercury_data_trans__du_stag_ordered_trans_0_0[] = {
	&mercury_data_trans__du_functor_desc_trans_0_0

};

const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_surface_coordinates_0[] = {
	&mercury_data_trans__du_functor_desc_surface_coordinates_0_0
};

static const MR_DuFunctorDesc mercury_data_trans__du_functor_desc_surface_coordinates_0_0 = {
	"surface_coordinates",
	3,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_trans__field_types_surface_coordinates_0_0,
	mercury_data_trans__field_names_surface_coordinates_0_0,
	NULL
};

const MR_ConstString mercury_data_trans__field_names_surface_coordinates_0_0[] = {
	"face",
	"surface_u",
	"surface_v"
};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_float_0;

const MR_PseudoTypeInfo mercury_data_trans__field_types_surface_coordinates_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_surface_coordinates_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_trans__du_stag_ordered_surface_coordinates_0_0 }

};

const MR_DuFunctorDesc * mercury_data_trans__du_stag_ordered_surface_coordinates_0_0[] = {
	&mercury_data_trans__du_functor_desc_surface_coordinates_0_0

};

const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_matrix_0[] = {
	&mercury_data_trans__du_functor_desc_matrix_0_0
};

static const MR_DuFunctorDesc mercury_data_trans__du_functor_desc_matrix_0_0 = {
	"matrix",
	12,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_trans__field_types_matrix_0_0,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_trans__field_types_matrix_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_matrix_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_trans__du_stag_ordered_matrix_0_0 }

};

const MR_DuFunctorDesc * mercury_data_trans__du_stag_ordered_matrix_0_0[] = {
	&mercury_data_trans__du_functor_desc_matrix_0_0

};
extern const struct MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_intersection_0;

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_21_trans__intersection_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_PseudoTypeInfo) &mercury_data_trans__type_ctor_info_intersection_0
}};

const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_intersection_0[] = {
	&mercury_data_trans__du_functor_desc_intersection_0_0
};

static const MR_DuFunctorDesc mercury_data_trans__du_functor_desc_intersection_0_0 = {
	"intersection",
	5,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_trans__field_types_intersection_0_0,
	mercury_data_trans__field_names_intersection_0_0,
	NULL
};

const MR_ConstString mercury_data_trans__field_names_intersection_0_0[] = {
	"object_id",
	"intersection_point",
	"surface_normal",
	"surface_coordinates",
	"surface"
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_vector_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_surface_coordinates_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_surface_0;

const MR_PseudoTypeInfo mercury_data_trans__field_types_intersection_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0,
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0,
	(MR_PseudoTypeInfo) &mercury_data_trans__type_ctor_info_surface_coordinates_0,
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_surface_0
};

const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_intersection_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_trans__du_stag_ordered_intersection_0_0 }

};

const MR_DuFunctorDesc * mercury_data_trans__du_stag_ordered_intersection_0_0[] = {
	&mercury_data_trans__du_functor_desc_intersection_0_0

};
extern const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_face_intersection_0;

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_26_trans__face_intersection_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_PseudoTypeInfo) &mercury_data_trans__type_ctor_info_face_intersection_0
}};

const MR_DuFunctorDesc * mercury_data_trans__du_name_ordered_face_intersection_0[] = {
	&mercury_data_trans__du_functor_desc_face_intersection_0_0
};

static const MR_DuFunctorDesc mercury_data_trans__du_functor_desc_face_intersection_0_0 = {
	"fi",
	4,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_trans__field_types_face_intersection_0_0,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_trans__field_types_face_intersection_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

const MR_DuPtagLayout mercury_data_trans__du_ptag_ordered_face_intersection_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_trans__du_stag_ordered_face_intersection_0_0 }

};

const MR_DuFunctorDesc * mercury_data_trans__du_stag_ordered_face_intersection_0_0[] = {
	&mercury_data_trans__du_functor_desc_face_intersection_0_0

};

extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_string_0;
MR_declare_entry(mercury__exception__throw_1_0);
MR_declare_entry(mercury__fn__f_102_108_111_97_116_95_95_47_2_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data_math__type_ctor_info_domain_error_0;
static const MR_Float mercury_float_const_180pt000000000000 = 180.000000000000;
MR_declare_entry(mercury__fn__vector__unit_1_0);
MR_declare_entry(mercury__fn__math__sqrt_1_0);
MR_declare_entry(mercury__list__condense_2_0);
MR_declare_entry(mercury__list__append_3_1);
MR_declare_entry(mercury__io__format_4_0);
static const MR_Float mercury_float_const_0pt500000000000000 = 0.500000000000000;
static const MR_Float mercury_float_const_2pt00000000000000 = 2.00000000000000;
static const MR_Float mercury_float_const_4pt00000000000000 = 4.00000000000000;
static const MR_Float mercury_float_const_neg0pt500000000000000 = -0.500000000000000;
MR_declare_entry(mercury____Unify___vector__vector_0_0);
MR_declare_entry(mercury____Unify___eval__surface_0_0);
MR_declare_entry(mercury____Compare___vector__vector_0_0);
MR_declare_entry(mercury____Compare___eval__surface_0_0);
MR_declare_entry(mercury____Unify___list__list_1_0);
MR_declare_entry(mercury____Compare___list__list_1_0);

MR_BEGIN_MODULE(trans_module)
	MR_init_entry(mercury__trans__list__map__ho7__ua0_3_0);
	MR_init_label(mercury__trans__list__map__ho7__ua0_3_0_i4);
	MR_init_label(mercury__trans__list__map__ho7__ua0_3_0_i5);
	MR_init_label(mercury__trans__list__map__ho7__ua0_3_0_i3);
	MR_init_entry(mercury__trans__list__map__ho6__ua0_3_0);
	MR_init_label(mercury__trans__list__map__ho6__ua0_3_0_i4);
	MR_init_label(mercury__trans__list__map__ho6__ua0_3_0_i5);
	MR_init_label(mercury__trans__list__map__ho6__ua0_3_0_i3);
	MR_init_entry(mercury__trans__list__map__ho5__ua0_3_0);
	MR_init_label(mercury__trans__list__map__ho5__ua0_3_0_i4);
	MR_init_label(mercury__trans__list__map__ho5__ua0_3_0_i5);
	MR_init_label(mercury__trans__list__map__ho5__ua0_3_0_i3);
	MR_init_entry(mercury__fn__trans__list__map__ho4__ua0_2_0);
	MR_init_entry(mercury__fn__trans__point_to_object_space_2_0);
	MR_init_entry(mercury__fn__trans__vector_to_object_space_2_0);
	MR_init_entry(mercury__fn__trans__normal_to_object_space_2_0);
	MR_init_entry(mercury__fn__trans__point_to_world_space_2_0);
	MR_init_entry(mercury__fn__trans__vector_to_world_space_2_0);
	MR_init_entry(mercury__fn__trans__normal_to_world_space_2_0);
	MR_init_entry(mercury__fn__trans__identity_0_0);
	MR_init_entry(mercury__fn__trans__compose_translate_4_0);
	MR_init_entry(mercury__fn__trans__compose_scale_4_0);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i5);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i7);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i3);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i13);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i15);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i17);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i20);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i22);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i24);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i27);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i29);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i31);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i34);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i36);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i38);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i41);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i43);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i45);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i131);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i50);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i51);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i53);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i54);
	MR_init_label(mercury__fn__trans__compose_scale_4_0_i55);
	MR_init_entry(mercury__fn__trans__compose_uscale_2_0);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i2);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i7);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i9);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i11);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i14);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i16);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i18);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i21);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i23);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i25);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i28);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i30);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i32);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i35);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i37);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i39);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i42);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i44);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i46);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i155);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i51);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i52);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i54);
	MR_init_label(mercury__fn__trans__compose_uscale_2_0_i55);
	MR_init_entry(mercury__fn__trans__compose_rotatex_2_0);
	MR_init_label(mercury__fn__trans__compose_rotatex_2_0_i4);
	MR_init_label(mercury__fn__trans__compose_rotatex_2_0_i6);
	MR_init_label(mercury__fn__trans__compose_rotatex_2_0_i8);
	MR_init_entry(mercury__fn__trans__compose_rotatey_2_0);
	MR_init_label(mercury__fn__trans__compose_rotatey_2_0_i4);
	MR_init_label(mercury__fn__trans__compose_rotatey_2_0_i6);
	MR_init_label(mercury__fn__trans__compose_rotatey_2_0_i8);
	MR_init_entry(mercury__fn__trans__compose_rotatez_2_0);
	MR_init_label(mercury__fn__trans__compose_rotatez_2_0_i4);
	MR_init_label(mercury__fn__trans__compose_rotatez_2_0_i6);
	MR_init_label(mercury__fn__trans__compose_rotatez_2_0_i8);
	MR_init_entry(mercury__trans__intersects_plane_6_0);
	MR_init_label(mercury__trans__intersects_plane_6_0_i2);
	MR_init_label(mercury__trans__intersects_plane_6_0_i9);
	MR_init_label(mercury__trans__intersects_plane_6_0_i11);
	MR_init_label(mercury__trans__intersects_plane_6_0_i12);
	MR_init_label(mercury__trans__intersects_plane_6_0_i14);
	MR_init_label(mercury__trans__intersects_plane_6_0_i15);
	MR_init_label(mercury__trans__intersects_plane_6_0_i16);
	MR_init_label(mercury__trans__intersects_plane_6_0_i4);
	MR_init_entry(mercury__trans__intersects_sphere_6_0);
	MR_init_label(mercury__trans__intersects_sphere_6_0_i2);
	MR_init_label(mercury__trans__intersects_sphere_6_0_i3);
	MR_init_label(mercury__trans__intersects_sphere_6_0_i6);
	MR_init_label(mercury__trans__intersects_sphere_6_0_i8);
	MR_init_label(mercury__trans__intersects_sphere_6_0_i9);
	MR_init_label(mercury__trans__intersects_sphere_6_0_i10);
	MR_init_label(mercury__trans__intersects_sphere_6_0_i5);
	MR_init_entry(mercury__trans__intersects_cube_6_0);
	MR_init_label(mercury__trans__intersects_cube_6_0_i2);
	MR_init_label(mercury__trans__intersects_cube_6_0_i3);
	MR_init_label(mercury__trans__intersects_cube_6_0_i4);
	MR_init_label(mercury__trans__intersects_cube_6_0_i5);
	MR_init_label(mercury__trans__intersects_cube_6_0_i6);
	MR_init_label(mercury__trans__intersects_cube_6_0_i7);
	MR_init_label(mercury__trans__intersects_cube_6_0_i8);
	MR_init_label(mercury__trans__intersects_cube_6_0_i9);
	MR_init_entry(mercury__trans__intersects_cylinder_6_0);
	MR_init_label(mercury__trans__intersects_cylinder_6_0_i2);
	MR_init_label(mercury__trans__intersects_cylinder_6_0_i3);
	MR_init_label(mercury__trans__intersects_cylinder_6_0_i4);
	MR_init_label(mercury__trans__intersects_cylinder_6_0_i5);
	MR_init_label(mercury__trans__intersects_cylinder_6_0_i6);
	MR_init_entry(mercury__trans__intersects_cone_6_0);
	MR_init_label(mercury__trans__intersects_cone_6_0_i2);
	MR_init_label(mercury__trans__intersects_cone_6_0_i3);
	MR_init_label(mercury__trans__intersects_cone_6_0_i4);
	MR_init_label(mercury__trans__intersects_cone_6_0_i5);
	MR_init_entry(mercury__trans__inside_sphere_2_0);
	MR_init_entry(mercury__trans__inside_plane_2_0);
	MR_init_entry(mercury__trans__inside_cube_2_0);
	MR_init_label(mercury__trans__inside_cube_2_0_i1);
	MR_init_entry(mercury__trans__inside_cylinder_2_0);
	MR_init_label(mercury__trans__inside_cylinder_2_0_i1);
	MR_init_entry(mercury__trans__inside_cone_2_0);
	MR_init_label(mercury__trans__inside_cone_2_0_i1);
	MR_init_entry(mercury__trans__show_trans_3_0);
	MR_init_label(mercury__trans__show_trans_3_0_i2);
	MR_init_label(mercury__trans__show_trans_3_0_i3);
	MR_init_label(mercury__trans__show_trans_3_0_i4);
	MR_init_label(mercury__trans__show_trans_3_0_i5);
	MR_init_label(mercury__trans__show_trans_3_0_i6);
	MR_init_label(mercury__trans__show_trans_3_0_i7);
	MR_init_label(mercury__trans__show_trans_3_0_i8);
	MR_init_entry(mercury__fn__trans__unit_matrix_0_0);
	MR_init_entry(mercury__fn__trans__transform_point_2_0);
	MR_init_entry(mercury__fn__trans__transform_vector_2_0);
	MR_init_entry(mercury__fn__trans__transform_normal_2_0);
	MR_init_entry(mercury__trans__intersects_sphere_2_11_0);
	MR_init_label(mercury__trans__intersects_sphere_2_11_0_i2);
	MR_init_label(mercury__trans__intersects_sphere_2_11_0_i3);
	MR_init_label(mercury__trans__intersects_sphere_2_11_0_i4);
	MR_init_entry(mercury__fn__trans__process_cube_intersections_4_0);
	MR_init_label(mercury__fn__trans__process_cube_intersections_4_0_i2);
	MR_init_label(mercury__fn__trans__process_cube_intersections_4_0_i4);
	MR_init_label(mercury__fn__trans__process_cube_intersections_4_0_i6);
	MR_init_label(mercury__fn__trans__process_cube_intersections_4_0_i8);
	MR_init_label(mercury__fn__trans__process_cube_intersections_4_0_i10);
	MR_init_label(mercury__fn__trans__process_cube_intersections_4_0_i12);
	MR_init_label(mercury__fn__trans__process_cube_intersections_4_0_i14);
	MR_init_label(mercury__fn__trans__process_cube_intersections_4_0_i21);
	MR_init_label(mercury__fn__trans__process_cube_intersections_4_0_i22);
	MR_init_entry(mercury__fn__trans__z_face_intersection_8_0);
	MR_init_label(mercury__fn__trans__z_face_intersection_8_0_i2);
	MR_init_label(mercury__fn__trans__z_face_intersection_8_0_i6);
	MR_init_label(mercury__fn__trans__z_face_intersection_8_0_i8);
	MR_init_label(mercury__fn__trans__z_face_intersection_8_0_i10);
	MR_init_label(mercury__fn__trans__z_face_intersection_8_0_i21);
	MR_init_label(mercury__fn__trans__z_face_intersection_8_0_i11);
	MR_init_entry(mercury__fn__trans__x_face_intersection_8_0);
	MR_init_label(mercury__fn__trans__x_face_intersection_8_0_i2);
	MR_init_label(mercury__fn__trans__x_face_intersection_8_0_i6);
	MR_init_label(mercury__fn__trans__x_face_intersection_8_0_i8);
	MR_init_label(mercury__fn__trans__x_face_intersection_8_0_i10);
	MR_init_label(mercury__fn__trans__x_face_intersection_8_0_i21);
	MR_init_label(mercury__fn__trans__x_face_intersection_8_0_i11);
	MR_init_entry(mercury__fn__trans__y_face_intersection_8_0);
	MR_init_label(mercury__fn__trans__y_face_intersection_8_0_i2);
	MR_init_label(mercury__fn__trans__y_face_intersection_8_0_i6);
	MR_init_label(mercury__fn__trans__y_face_intersection_8_0_i8);
	MR_init_label(mercury__fn__trans__y_face_intersection_8_0_i10);
	MR_init_label(mercury__fn__trans__y_face_intersection_8_0_i21);
	MR_init_label(mercury__fn__trans__y_face_intersection_8_0_i11);
	MR_init_entry(mercury__fn__trans__process_cylinder_intersections_4_0);
	MR_init_label(mercury__fn__trans__process_cylinder_intersections_4_0_i6);
	MR_init_label(mercury__fn__trans__process_cylinder_intersections_4_0_i8);
	MR_init_label(mercury__fn__trans__process_cylinder_intersections_4_0_i9);
	MR_init_label(mercury__fn__trans__process_cylinder_intersections_4_0_i11);
	MR_init_label(mercury__fn__trans__process_cylinder_intersections_4_0_i2);
	MR_init_label(mercury__fn__trans__process_cylinder_intersections_4_0_i13);
	MR_init_label(mercury__fn__trans__process_cylinder_intersections_4_0_i15);
	MR_init_label(mercury__fn__trans__process_cylinder_intersections_4_0_i17);
	MR_init_label(mercury__fn__trans__process_cylinder_intersections_4_0_i21);
	MR_init_label(mercury__fn__trans__process_cylinder_intersections_4_0_i22);
	MR_init_entry(mercury__fn__trans__process_cone_intersections_4_0);
	MR_init_label(mercury__fn__trans__process_cone_intersections_4_0_i6);
	MR_init_label(mercury__fn__trans__process_cone_intersections_4_0_i8);
	MR_init_label(mercury__fn__trans__process_cone_intersections_4_0_i10);
	MR_init_label(mercury__fn__trans__process_cone_intersections_4_0_i11);
	MR_init_label(mercury__fn__trans__process_cone_intersections_4_0_i13);
	MR_init_label(mercury__fn__trans__process_cone_intersections_4_0_i2);
	MR_init_label(mercury__fn__trans__process_cone_intersections_4_0_i14);
	MR_init_label(mercury__fn__trans__process_cone_intersections_4_0_i16);
	MR_init_label(mercury__fn__trans__process_cone_intersections_4_0_i19);
	MR_init_label(mercury__fn__trans__process_cone_intersections_4_0_i20);
	MR_init_entry(mercury__fn__trans__cylinder_intersection_7_0);
	MR_init_entry(mercury__fn__trans__cone_intersection_7_0);
	MR_init_entry(mercury__fn__trans__solve_quadratic_10_0);
	MR_init_label(mercury__fn__trans__solve_quadratic_10_0_i2);
	MR_init_label(mercury__fn__trans__solve_quadratic_10_0_i3);
	MR_init_label(mercury__fn__trans__solve_quadratic_10_0_i5);
	MR_init_label(mercury__fn__trans__solve_quadratic_10_0_i8);
	MR_init_label(mercury__fn__trans__solve_quadratic_10_0_i10);
	MR_init_label(mercury__fn__trans__solve_quadratic_10_0_i12);
	MR_init_label(mercury__fn__trans__solve_quadratic_10_0_i15);
	MR_init_label(mercury__fn__trans__solve_quadratic_10_0_i17);
	MR_init_label(mercury__fn__trans__solve_quadratic_10_0_i18);
	MR_init_label(mercury__fn__trans__solve_quadratic_10_0_i21);
	MR_init_entry(mercury__trans__maybe_add_intersection_10_0);
	MR_init_label(mercury__trans__maybe_add_intersection_10_0_i2);
	MR_init_entry(mercury__fn__trans__disc_intersection_8_0);
	MR_init_label(mercury__fn__trans__disc_intersection_8_0_i2);
	MR_init_label(mercury__fn__trans__disc_intersection_8_0_i6);
	MR_init_label(mercury__fn__trans__disc_intersection_8_0_i8);
	MR_init_label(mercury__fn__trans__disc_intersection_8_0_i10);
	MR_init_label(mercury__fn__trans__disc_intersection_8_0_i21);
	MR_init_label(mercury__fn__trans__disc_intersection_8_0_i11);
	MR_init_entry(mercury__fn__trans__calc_u_2_0);
	MR_init_label(mercury__fn__trans__calc_u_2_0_i4);
	MR_init_label(mercury__fn__trans__calc_u_2_0_i6);
	MR_init_label(mercury__fn__trans__calc_u_2_0_i8);
	MR_init_label(mercury__fn__trans__calc_u_2_0_i9);
	MR_init_label(mercury__fn__trans__calc_u_2_0_i10);
	MR_init_entry(mercury____Unify___trans__surface_coordinates_0_0);
	MR_init_label(mercury____Unify___trans__surface_coordinates_0_0_i1);
	MR_init_entry(mercury____Compare___trans__surface_coordinates_0_0);
	MR_init_label(mercury____Compare___trans__surface_coordinates_0_0_i4);
	MR_init_label(mercury____Compare___trans__surface_coordinates_0_0_i3);
	MR_init_label(mercury____Compare___trans__surface_coordinates_0_0_i16);
	MR_init_label(mercury____Compare___trans__surface_coordinates_0_0_i15);
	MR_init_label(mercury____Compare___trans__surface_coordinates_0_0_i26);
	MR_init_label(mercury____Compare___trans__surface_coordinates_0_0_i27);
	MR_init_entry(mercury____Unify___trans__trans_0_0);
	MR_init_label(mercury____Unify___trans__trans_0_0_i1);
	MR_init_entry(mercury____Compare___trans__trans_0_0);
	MR_init_label(mercury____Compare___trans__trans_0_0_i3);
	MR_init_label(mercury____Compare___trans__trans_0_0_i7);
	MR_init_entry(mercury____Unify___trans__intersection_0_0);
	MR_init_label(mercury____Unify___trans__intersection_0_0_i2);
	MR_init_label(mercury____Unify___trans__intersection_0_0_i4);
	MR_init_label(mercury____Unify___trans__intersection_0_0_i1);
	MR_init_entry(mercury____Compare___trans__intersection_0_0);
	MR_init_label(mercury____Compare___trans__intersection_0_0_i4);
	MR_init_label(mercury____Compare___trans__intersection_0_0_i3);
	MR_init_label(mercury____Compare___trans__intersection_0_0_i15);
	MR_init_label(mercury____Compare___trans__intersection_0_0_i19);
	MR_init_label(mercury____Compare___trans__intersection_0_0_i23);
	MR_init_label(mercury____Compare___trans__intersection_0_0_i30);
	MR_init_entry(mercury____Unify___trans__intersections_0_0);
	MR_init_entry(mercury____Compare___trans__intersections_0_0);
	MR_init_entry(mercury____Unify___trans__matrix_0_0);
	MR_init_label(mercury____Unify___trans__matrix_0_0_i1);
	MR_init_entry(mercury____Compare___trans__matrix_0_0);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i4);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i3);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i16);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i15);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i28);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i27);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i40);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i39);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i52);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i51);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i64);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i63);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i76);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i75);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i88);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i87);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i100);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i99);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i112);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i111);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i124);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i123);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i134);
	MR_init_label(mercury____Compare___trans__matrix_0_0_i135);
	MR_init_entry(mercury____Unify___trans__face_intersection_0_0);
	MR_init_label(mercury____Unify___trans__face_intersection_0_0_i1);
	MR_init_entry(mercury____Compare___trans__face_intersection_0_0);
	MR_init_label(mercury____Compare___trans__face_intersection_0_0_i4);
	MR_init_label(mercury____Compare___trans__face_intersection_0_0_i3);
	MR_init_label(mercury____Compare___trans__face_intersection_0_0_i16);
	MR_init_label(mercury____Compare___trans__face_intersection_0_0_i15);
	MR_init_label(mercury____Compare___trans__face_intersection_0_0_i28);
	MR_init_label(mercury____Compare___trans__face_intersection_0_0_i27);
	MR_init_label(mercury____Compare___trans__face_intersection_0_0_i38);
	MR_init_label(mercury____Compare___trans__face_intersection_0_0_i39);
	MR_init_entry(mercury____Unify___trans__face_intersections_0_0);
	MR_init_entry(mercury____Compare___trans__face_intersections_0_0);
MR_BEGIN_CODE

/* code for predicate 'map__ho7__ua0'/3 in mode 0 */
MR_define_static(mercury__trans__list__map__ho7__ua0_3_0);
	if (((MR_Integer) MR_r4 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__trans__list__map__ho7__ua0_3_0_i3);
	}
	MR_incr_sp_push_msg(5, "list:map__ho7__ua0/3");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 1);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r2;
	MR_stackvar(4) = MR_r1;
	MR_r4 = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 0);
	MR_localcall(mercury__fn__trans__process_cone_intersections_4_0,
		MR_LABEL(mercury__trans__list__map__ho7__ua0_3_0_i4),
		MR_STATIC(mercury__trans__list__map__ho7__ua0_3_0));
MR_define_label(mercury__trans__list__map__ho7__ua0_3_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__list__map__ho7__ua0_3_0));
	MR_r4 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_stackvar(4);
	MR_r2 = MR_stackvar(3);
	MR_r3 = MR_stackvar(2);
	MR_localcall(mercury__trans__list__map__ho7__ua0_3_0,
		MR_LABEL(mercury__trans__list__map__ho7__ua0_3_0_i5),
		MR_STATIC(mercury__trans__list__map__ho7__ua0_3_0));
MR_define_label(mercury__trans__list__map__ho7__ua0_3_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__list__map__ho7__ua0_3_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__trans__list__map__ho7__ua0_3_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
	}
MR_define_label(mercury__trans__list__map__ho7__ua0_3_0_i3);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
/* code for predicate 'map__ho6__ua0'/3 in mode 0 */
MR_define_static(mercury__trans__list__map__ho6__ua0_3_0);
	if (((MR_Integer) MR_r4 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__trans__list__map__ho6__ua0_3_0_i3);
	}
	MR_incr_sp_push_msg(5, "list:map__ho6__ua0/3");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 1);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r2;
	MR_stackvar(4) = MR_r1;
	MR_r4 = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 0);
	MR_localcall(mercury__fn__trans__process_cylinder_intersections_4_0,
		MR_LABEL(mercury__trans__list__map__ho6__ua0_3_0_i4),
		MR_STATIC(mercury__trans__list__map__ho6__ua0_3_0));
MR_define_label(mercury__trans__list__map__ho6__ua0_3_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__list__map__ho6__ua0_3_0));
	MR_r4 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_stackvar(4);
	MR_r2 = MR_stackvar(3);
	MR_r3 = MR_stackvar(2);
	MR_localcall(mercury__trans__list__map__ho6__ua0_3_0,
		MR_LABEL(mercury__trans__list__map__ho6__ua0_3_0_i5),
		MR_STATIC(mercury__trans__list__map__ho6__ua0_3_0));
MR_define_label(mercury__trans__list__map__ho6__ua0_3_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__list__map__ho6__ua0_3_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__trans__list__map__ho6__ua0_3_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
	}
MR_define_label(mercury__trans__list__map__ho6__ua0_3_0_i3);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
/* code for predicate 'map__ho5__ua0'/3 in mode 0 */
MR_define_static(mercury__trans__list__map__ho5__ua0_3_0);
	if (((MR_Integer) MR_r4 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__trans__list__map__ho5__ua0_3_0_i3);
	}
	MR_incr_sp_push_msg(5, "list:map__ho5__ua0/3");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 1);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r2;
	MR_stackvar(4) = MR_r1;
	MR_r4 = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 0);
	MR_localcall(mercury__fn__trans__process_cube_intersections_4_0,
		MR_LABEL(mercury__trans__list__map__ho5__ua0_3_0_i4),
		MR_STATIC(mercury__trans__list__map__ho5__ua0_3_0));
MR_define_label(mercury__trans__list__map__ho5__ua0_3_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__list__map__ho5__ua0_3_0));
	MR_r4 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_stackvar(4);
	MR_r2 = MR_stackvar(3);
	MR_r3 = MR_stackvar(2);
	MR_localcall(mercury__trans__list__map__ho5__ua0_3_0,
		MR_LABEL(mercury__trans__list__map__ho5__ua0_3_0_i5),
		MR_STATIC(mercury__trans__list__map__ho5__ua0_3_0));
MR_define_label(mercury__trans__list__map__ho5__ua0_3_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__list__map__ho5__ua0_3_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__trans__list__map__ho5__ua0_3_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
	}
MR_define_label(mercury__trans__list__map__ho5__ua0_3_0_i3);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
/* code for predicate 'map__ho4__ua0'/3 in mode 0 */
MR_define_static(mercury__fn__trans__list__map__ho4__ua0_2_0);
	MR_localtailcall(mercury__trans__list__map__ho5__ua0_3_0,
		MR_STATIC(mercury__fn__trans__list__map__ho4__ua0_2_0));
/* code for predicate 'point_to_object_space'/3 in mode 0 */
MR_define_entry(mercury__fn__trans__point_to_object_space_2_0);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__point_to_object_space_2_0, "vector:vector/0");
	MR_r3 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r4 = MR_tempr2;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r5 = MR_tempr3;
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r6 = MR_tempr4;
	MR_tempr5 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r7 = MR_tempr5;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2)) * MR_word_to_float(MR_tempr5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 3))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6)) * MR_word_to_float(MR_tempr5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 7))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10)) * MR_word_to_float(MR_tempr5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 11))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'vector_to_object_space'/3 in mode 0 */
MR_define_entry(mercury__fn__trans__vector_to_object_space_2_0);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__vector_to_object_space_2_0, "vector:vector/0");
	MR_r3 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r4 = MR_tempr2;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r5 = MR_tempr3;
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r6 = MR_tempr4;
	MR_tempr5 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r7 = MR_tempr5;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2)) * MR_word_to_float(MR_tempr5))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6)) * MR_word_to_float(MR_tempr5))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10)) * MR_word_to_float(MR_tempr5))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'normal_to_object_space'/3 in mode 0 */
MR_define_entry(mercury__fn__trans__normal_to_object_space_2_0);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__normal_to_object_space_2_0, "vector:vector/0");
	MR_r3 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_tempr2;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r5 = MR_tempr3;
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r6 = MR_tempr4;
	MR_tempr5 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r7 = MR_tempr5;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8)) * MR_word_to_float(MR_tempr5))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9)) * MR_word_to_float(MR_tempr5))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10)) * MR_word_to_float(MR_tempr5))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'point_to_world_space'/3 in mode 0 */
MR_define_entry(mercury__fn__trans__point_to_world_space_2_0);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__point_to_world_space_2_0, "vector:vector/0");
	MR_r3 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_tempr2;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r5 = MR_tempr3;
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r6 = MR_tempr4;
	MR_tempr5 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r7 = MR_tempr5;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2)) * MR_word_to_float(MR_tempr5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 3))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6)) * MR_word_to_float(MR_tempr5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 7))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10)) * MR_word_to_float(MR_tempr5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 11))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'vector_to_world_space'/3 in mode 0 */
MR_define_entry(mercury__fn__trans__vector_to_world_space_2_0);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__vector_to_world_space_2_0, "vector:vector/0");
	MR_r3 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_tempr2;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r5 = MR_tempr3;
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r6 = MR_tempr4;
	MR_tempr5 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r7 = MR_tempr5;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2)) * MR_word_to_float(MR_tempr5))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6)) * MR_word_to_float(MR_tempr5))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10)) * MR_word_to_float(MR_tempr5))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'normal_to_world_space'/3 in mode 0 */
MR_define_entry(mercury__fn__trans__normal_to_world_space_2_0);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__normal_to_world_space_2_0, "vector:vector/0");
	MR_r3 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r4 = MR_tempr2;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r5 = MR_tempr3;
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r6 = MR_tempr4;
	MR_tempr5 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r7 = MR_tempr5;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8)) * MR_word_to_float(MR_tempr5))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9)) * MR_word_to_float(MR_tempr5))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2)) * MR_word_to_float(MR_tempr3)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6)) * MR_word_to_float(MR_tempr4))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10)) * MR_word_to_float(MR_tempr5))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'identity'/1 in mode 0 */
MR_define_entry(mercury__fn__trans__identity_0_0);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_trans__common_1);
	MR_proceed();
/* code for predicate 'compose_translate'/5 in mode 0 */
MR_define_entry(mercury__fn__trans__compose_translate_4_0);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_translate_4_0, "trans:matrix/0");
	MR_r5 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	MR_r6 = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 3)) + MR_word_to_float(MR_r1)));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 7)) + MR_word_to_float(MR_r2)));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 10) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 11) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 11)) + MR_word_to_float(MR_r3)));
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_translate_4_0, "trans:matrix/0");
	MR_r6 = MR_tempr3;
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1);
	MR_r7 = MR_tempr4;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 3) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 3)) - (MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0)))) - (MR_word_to_float(MR_r2) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1)))) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 2)))));
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 7) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 7)) - (MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 4)))) - (MR_word_to_float(MR_r2) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 5)))) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 6)))));
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 10) = MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 11) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr4, (MR_Integer) 11)) - (MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 8)))) - (MR_word_to_float(MR_r2) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 9)))) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 10)))));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 2, mercury__fn__trans__compose_translate_4_0, "trans:trans/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_tempr3;
	MR_proceed();
	}
/* code for predicate 'compose_scale'/5 in mode 0 */
MR_define_entry(mercury__fn__trans__compose_scale_4_0);
	MR_incr_sp_push_msg(17, "trans:compose_scale/5");
	MR_stackvar(17) = (MR_Word) MR_succip;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	if ((MR_word_to_float(MR_r1) != (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i5);
	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) MR_string_const("trans: compose_scale/7: zero scaling factor", 43);
	MR_succip = (MR_Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i5);
	if ((MR_word_to_float(MR_r2) != (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i7);
	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) MR_string_const("trans: compose_scale/7: zero scaling factor", 43);
	MR_succip = (MR_Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i7);
	if ((MR_word_to_float(MR_r3) != (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i3);
	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) MR_string_const("trans: compose_scale/7: zero scaling factor", 43);
	MR_succip = (MR_Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i3);
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_scale_4_0, "trans:matrix/0");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 0))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 1))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 2))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 3) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 3))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 4) = MR_float_to_word((MR_word_to_float(MR_r2) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 4))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 5) = MR_float_to_word((MR_word_to_float(MR_r2) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 5))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 6) = MR_float_to_word((MR_word_to_float(MR_r2) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 6))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 7) = MR_float_to_word((MR_word_to_float(MR_r2) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 7))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 8) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 8))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 9) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 9))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 10) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 10))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 11) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(4), (MR_Integer) 11))));
	MR_stackvar(16) = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 11);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 10);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 9);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 8);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 7);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 6);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 5);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 4);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 1);
	MR_r5 = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 0);
	MR_stackvar(1) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2178 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i13);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i15);
	}
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_r5;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r4 = MR_stackvar(4);
	MR_r5 = MR_stackvar(5);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_float_to_word((MR_word_to_float(MR_r5) / MR_word_to_float(MR_r1)));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2211 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i20);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i22);
	}
	MR_stackvar(6) = MR_float_to_word((MR_word_to_float(MR_stackvar(6)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2231 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i27);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i29);
	}
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(3))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2251 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i34);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i36);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2271 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i43);
	}
	MR_stackvar(10) = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2291 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i131);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i50);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(13);
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_stackvar(3))));
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i53,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i13);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_r5;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r4 = MR_stackvar(4);
	MR_r5 = MR_stackvar(5);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_float_to_word((MR_word_to_float(MR_r5) / MR_word_to_float(MR_r1)));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2331 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i20);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i22);
	}
	MR_stackvar(6) = MR_float_to_word((MR_word_to_float(MR_stackvar(6)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2351 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i27);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i29);
	}
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(3))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2371 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i34);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i36);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2391 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i43);
	}
	MR_stackvar(10) = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2411 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i131);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i50);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(13);
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_stackvar(3))));
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i53,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i15);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_scale_4_0_i17,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i17);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_scale_4_0));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2447 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i20);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i22);
	}
	MR_stackvar(6) = MR_float_to_word((MR_word_to_float(MR_stackvar(6)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2467 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i27);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i29);
	}
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(3))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2487 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i34);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i36);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2507 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i43);
	}
	MR_stackvar(10) = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2527 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i131);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i50);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(13);
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_stackvar(3))));
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i53,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i20);
	MR_stackvar(6) = MR_float_to_word((MR_word_to_float(MR_stackvar(6)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2554 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i27);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i29);
	}
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(3))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2574 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i34);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i36);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2594 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i43);
	}
	MR_stackvar(10) = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2614 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i131);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i50);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(13);
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_stackvar(3))));
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i53,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i22);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_scale_4_0_i24,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i24);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_scale_4_0));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2647 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i27);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i29);
	}
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(3))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2667 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i34);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i36);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2687 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i43);
	}
	MR_stackvar(10) = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2707 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i131);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i50);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(13);
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_stackvar(3))));
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i53,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i27);
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(3))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2734 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i34);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i36);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2754 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i43);
	}
	MR_stackvar(10) = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2774 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i131);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i50);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(13);
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_stackvar(3))));
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i53,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i29);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_scale_4_0_i31,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i31);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_scale_4_0));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2807 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i34);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i36);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2827 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i43);
	}
	MR_stackvar(10) = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2847 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i131);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i50);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(13);
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_stackvar(3))));
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i53,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i34);
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2874 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i43);
	}
	MR_stackvar(10) = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2894 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i131);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i50);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(13);
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_stackvar(3))));
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i53,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i36);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_scale_4_0_i38,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i38);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_scale_4_0));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2927 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i43);
	}
	MR_stackvar(10) = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2947 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i131);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i50);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(13);
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_stackvar(3))));
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i53,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i41);
	MR_stackvar(10) = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(2))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 2974 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i131);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i50);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(13);
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_stackvar(3))));
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i53,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i43);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_scale_4_0_i45,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i45);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_scale_4_0));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_scale_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3007 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i131);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_scale_4_0_i50);
	}
MR_define_label(mercury__fn__trans__compose_scale_4_0_i131);
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(13);
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_stackvar(3))));
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i53,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i50);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_scale_4_0_i51,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i51);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_scale_4_0));
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(13);
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i53,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i53);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_scale_4_0));
	MR_r2 = MR_stackvar(2);
	MR_stackvar(2) = MR_r1;
	MR_r1 = MR_stackvar(14);
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i54);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_scale_4_0));
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_r1;
	MR_r1 = MR_stackvar(15);
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_scale_4_0_i55,
		MR_ENTRY(mercury__fn__trans__compose_scale_4_0));
MR_define_label(mercury__fn__trans__compose_scale_4_0_i55);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_scale_4_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_scale_4_0, "trans:matrix/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_stackvar(7);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 3) = MR_stackvar(8);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 4) = MR_stackvar(9);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 5) = MR_stackvar(10);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 6) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 7) = MR_stackvar(12);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 8) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 9) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 10) = MR_r1;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 11) = MR_stackvar(16);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 2, mercury__fn__trans__compose_scale_4_0, "trans:trans/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	MR_proceed();
/* code for predicate 'compose_uscale'/3 in mode 0 */
MR_define_entry(mercury__fn__trans__compose_uscale_2_0);
	MR_incr_sp_push_msg(15, "trans:compose_uscale/3");
	MR_stackvar(15) = (MR_Word) MR_succip;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((MR_word_to_float(MR_r1) != (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i2);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) MR_string_const("trans: compose_uscale/7: zero scaling factor", 44);
	MR_succip = (MR_Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i2);
	MR_tag_incr_hp_msg(MR_stackvar(2), MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_uscale_2_0, "trans:matrix/0");
	MR_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0))));
	MR_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1))));
	MR_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 2))));
	MR_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 3) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 3))));
	MR_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 4) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 4))));
	MR_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 5) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 5))));
	MR_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 6) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 6))));
	MR_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 7) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 7))));
	MR_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 8) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 8))));
	MR_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 9) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 9))));
	MR_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 10) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 10))));
	MR_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 11) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 11))));
	MR_stackvar(14) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 11);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 10);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 9);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 8);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 7);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 6);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 5);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 4);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	MR_stackvar(1) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3125 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i7);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i9);
	}
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(3) = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / MR_word_to_float(MR_r1)));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3147 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i14);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i16);
	}
	MR_stackvar(4) = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3167 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i21);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i23);
	}
	MR_stackvar(5) = MR_float_to_word((MR_word_to_float(MR_stackvar(5)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3187 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i28);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i30);
	}
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3207 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i35);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i37);
	}
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3227 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i42);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i44);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3247 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i155);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i51);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(11) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_r2)));
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i7);
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(3) = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / MR_word_to_float(MR_r1)));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3277 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i14);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i16);
	}
	MR_stackvar(4) = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3297 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i21);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i23);
	}
	MR_stackvar(5) = MR_float_to_word((MR_word_to_float(MR_stackvar(5)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3317 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i28);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i30);
	}
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3337 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i35);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i37);
	}
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3357 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i42);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i44);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3377 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i155);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i51);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(11) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_r2)));
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i9);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_uscale_2_0_i11,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i11);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_uscale_2_0));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3411 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i14);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i16);
	}
	MR_stackvar(4) = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3431 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i21);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i23);
	}
	MR_stackvar(5) = MR_float_to_word((MR_word_to_float(MR_stackvar(5)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3451 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i28);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i30);
	}
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3471 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i35);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i37);
	}
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3491 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i42);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i44);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3511 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i155);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i51);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(11) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_r2)));
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i14);
	MR_stackvar(4) = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3539 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i21);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i23);
	}
	MR_stackvar(5) = MR_float_to_word((MR_word_to_float(MR_stackvar(5)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3559 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i28);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i30);
	}
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3579 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i35);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i37);
	}
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3599 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i42);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i44);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3619 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i155);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i51);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(11) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_r2)));
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i16);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_uscale_2_0_i18,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i18);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_uscale_2_0));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3653 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i21);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i23);
	}
	MR_stackvar(5) = MR_float_to_word((MR_word_to_float(MR_stackvar(5)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3673 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i28);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i30);
	}
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3693 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i35);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i37);
	}
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3713 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i42);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i44);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3733 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i155);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i51);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(11) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_r2)));
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i21);
	MR_stackvar(5) = MR_float_to_word((MR_word_to_float(MR_stackvar(5)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3761 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i28);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i30);
	}
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3781 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i35);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i37);
	}
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3801 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i42);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i44);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3821 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i155);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i51);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(11) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_r2)));
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i23);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_uscale_2_0_i25,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i25);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_uscale_2_0));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3855 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i28);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i30);
	}
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3875 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i35);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i37);
	}
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3895 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i42);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i44);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3915 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i155);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i51);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(11) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_r2)));
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i28);
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3943 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i35);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i37);
	}
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3963 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i42);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i44);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 3983 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i155);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i51);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(11) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_r2)));
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i30);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_uscale_2_0_i32,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i32);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_uscale_2_0));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 4017 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i35);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i37);
	}
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 4037 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i42);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i44);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 4057 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i155);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i51);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(11) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_r2)));
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i35);
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 4085 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i42);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i44);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 4105 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i155);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i51);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(11) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_r2)));
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i37);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_uscale_2_0_i39,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i39);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_uscale_2_0));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 4139 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i42);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i44);
	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 4159 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i155);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i51);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(11) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_r2)));
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i42);
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) / MR_word_to_float(MR_stackvar(1))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 4187 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i155);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i51);
	}
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(11) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_r2)));
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i44);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_uscale_2_0_i46,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i46);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_uscale_2_0));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_uscale_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 4221 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i155);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(1)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_uscale_2_0_i51);
	}
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i155);
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(11) = MR_float_to_word((MR_word_to_float(MR_stackvar(11)) / MR_word_to_float(MR_r2)));
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i51);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_uscale_2_0_i52,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i52);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_uscale_2_0));
	MR_r2 = MR_stackvar(1);
	MR_r1 = MR_stackvar(12);
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i54,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i54);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_uscale_2_0));
	MR_r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_stackvar(13);
	MR_call_localret(MR_ENTRY(mercury__fn__f_102_108_111_97_116_95_95_47_2_0),
		mercury__fn__trans__compose_uscale_2_0_i55,
		MR_ENTRY(mercury__fn__trans__compose_uscale_2_0));
MR_define_label(mercury__fn__trans__compose_uscale_2_0_i55);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_uscale_2_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_uscale_2_0, "trans:matrix/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 4) = MR_stackvar(7);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 5) = MR_stackvar(8);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 6) = MR_stackvar(9);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 7) = MR_stackvar(10);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 8) = MR_stackvar(11);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 9) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 10) = MR_r1;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 11) = MR_stackvar(14);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 2, mercury__fn__trans__compose_uscale_2_0, "trans:trans/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	MR_proceed();
/* code for predicate 'compose_rotatex'/3 in mode 0 */
MR_define_entry(mercury__fn__trans__compose_rotatex_2_0);
	{
	MR_Float	Pi;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatex_2_0
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;
;}
#line 4290 "trans.c"
	MR_r3 = MR_float_to_word(Pi);
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(4, "trans:compose_rotatex/3");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(3) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_r3)));
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatex_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 4311 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_rotatex_2_0_i4);
#undef	MR_PROC_LABEL

	}
	if (((MR_Float) 180.000000000000 == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_rotatex_2_0_i6);
	}
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / (MR_Float) 180.000000000000));
	{
	MR_Float	X;
	MR_Float	Cos;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatex_2_0
	X = MR_word_to_float(MR_r1);
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);
;}
#line 4330 "trans.c"
	MR_r2 = MR_float_to_word(Cos);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	X;
	MR_Float	Sin;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatex_2_0
	X = MR_word_to_float(MR_r1);
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);
;}
#line 4345 "trans.c"
	MR_r3 = MR_float_to_word(Sin);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatex_2_0, "trans:matrix/0");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 3);
	MR_r5 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 4);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 4) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r5)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6))));
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 5);
	MR_r8 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 5) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r8))));
	MR_r9 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 6);
	MR_r10 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 6) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r9)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r10))));
	MR_r11 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 7);
	MR_r12 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 11);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 7) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r11)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r12))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 8) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r5)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 9) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r8))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 10) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r9)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r10))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 11) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r11)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r12))));
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatex_2_0, "trans:matrix/0");
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 3);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 4) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 4);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 5);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 5) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 6) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 7);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 8) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 8);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 9);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 9) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 10) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 11) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 11);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 2, mercury__fn__trans__compose_rotatex_2_0, "trans:trans/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r5;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__fn__trans__compose_rotatex_2_0_i4);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / (MR_Float) 180.000000000000));
	{
	MR_Float	X;
	MR_Float	Cos;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatex_2_0
	X = MR_word_to_float(MR_r1);
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);
;}
#line 4408 "trans.c"
	MR_r2 = MR_float_to_word(Cos);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	X;
	MR_Float	Sin;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatex_2_0
	X = MR_word_to_float(MR_r1);
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);
;}
#line 4423 "trans.c"
	MR_r3 = MR_float_to_word(Sin);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatex_2_0, "trans:matrix/0");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 3);
	MR_r5 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 4);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 4) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r5)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6))));
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 5);
	MR_r8 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 5) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r8))));
	MR_r9 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 6);
	MR_r10 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 6) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r9)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r10))));
	MR_r11 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 7);
	MR_r12 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 11);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 7) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r11)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r12))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 8) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r5)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 9) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r8))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 10) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r9)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r10))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 11) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r11)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r12))));
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatex_2_0, "trans:matrix/0");
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 3);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 4) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 4);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 5);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 5) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 6) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 7);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 8) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 8);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 9);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 9) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 10) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 11) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 11);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 2, mercury__fn__trans__compose_rotatex_2_0, "trans:trans/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r5;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__fn__trans__compose_rotatex_2_0_i6);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_rotatex_2_0_i8,
		MR_ENTRY(mercury__fn__trans__compose_rotatex_2_0));
MR_define_label(mercury__fn__trans__compose_rotatex_2_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_rotatex_2_0));
	{
	MR_Float	X;
	MR_Float	Cos;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatex_2_0
	X = MR_word_to_float(MR_r1);
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);
;}
#line 4492 "trans.c"
	MR_r2 = MR_float_to_word(Cos);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	X;
	MR_Float	Sin;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatex_2_0
	X = MR_word_to_float(MR_r1);
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);
;}
#line 4507 "trans.c"
	MR_r3 = MR_float_to_word(Sin);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatex_2_0, "trans:matrix/0");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 3);
	MR_r5 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 4);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 4) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r5)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6))));
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 5);
	MR_r8 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 5) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r8))));
	MR_r9 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 6);
	MR_r10 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 6) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r9)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r10))));
	MR_r11 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 7);
	MR_r12 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 11);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 7) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r11)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r12))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 8) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r5)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 9) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r8))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 10) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r9)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r10))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 11) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r11)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r12))));
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatex_2_0, "trans:matrix/0");
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 3);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 4) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 4);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 5);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 5) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 6) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 7);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 8) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 8);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 9);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 9) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 10) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 11) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 11);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 2, mercury__fn__trans__compose_rotatex_2_0, "trans:trans/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r5;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate 'compose_rotatey'/3 in mode 0 */
MR_define_entry(mercury__fn__trans__compose_rotatey_2_0);
	{
	MR_Float	Pi;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatey_2_0
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;
;}
#line 4568 "trans.c"
	MR_r3 = MR_float_to_word(Pi);
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(4, "trans:compose_rotatey/3");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(3) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_r3)));
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatey_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 4589 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_rotatey_2_0_i4);
#undef	MR_PROC_LABEL

	}
	if (((MR_Float) 180.000000000000 == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_rotatey_2_0_i6);
	}
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / (MR_Float) 180.000000000000));
	{
	MR_Float	X;
	MR_Float	Cos;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatey_2_0
	X = MR_word_to_float(MR_r1);
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);
;}
#line 4608 "trans.c"
	MR_r2 = MR_float_to_word(Cos);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	X;
	MR_Float	Sin;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatey_2_0
	X = MR_word_to_float(MR_r1);
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);
;}
#line 4623 "trans.c"
	MR_r3 = MR_float_to_word(Sin);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatey_2_0, "trans:matrix/0");
	MR_r5 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r5)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6))));
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1);
	MR_r8 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r8))));
	MR_r9 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2);
	MR_r10 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r9)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r10))));
	MR_r11 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 3);
	MR_r12 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 11);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 3) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r11)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r12))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 4) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 5) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 6) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 7);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 8) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r5))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 9) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r8)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 10) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r10)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r9))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 11) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r12)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r11))));
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatey_2_0, "trans:matrix/0");
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 3);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 4);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 4) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 5) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 6) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 7);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 8);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 8) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 9) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 10) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 11) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 11);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 2, mercury__fn__trans__compose_rotatey_2_0, "trans:trans/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r5;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__fn__trans__compose_rotatey_2_0_i4);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / (MR_Float) 180.000000000000));
	{
	MR_Float	X;
	MR_Float	Cos;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatey_2_0
	X = MR_word_to_float(MR_r1);
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);
;}
#line 4686 "trans.c"
	MR_r2 = MR_float_to_word(Cos);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	X;
	MR_Float	Sin;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatey_2_0
	X = MR_word_to_float(MR_r1);
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);
;}
#line 4701 "trans.c"
	MR_r3 = MR_float_to_word(Sin);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatey_2_0, "trans:matrix/0");
	MR_r5 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r5)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6))));
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1);
	MR_r8 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r8))));
	MR_r9 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2);
	MR_r10 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r9)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r10))));
	MR_r11 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 3);
	MR_r12 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 11);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 3) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r11)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r12))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 4) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 5) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 6) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 7);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 8) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r5))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 9) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r8)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 10) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r10)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r9))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 11) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r12)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r11))));
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatey_2_0, "trans:matrix/0");
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 3);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 4);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 4) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 5) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 6) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 7);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 8);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 8) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 9) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 10) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 11) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 11);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 2, mercury__fn__trans__compose_rotatey_2_0, "trans:trans/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r5;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__fn__trans__compose_rotatey_2_0_i6);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_rotatey_2_0_i8,
		MR_ENTRY(mercury__fn__trans__compose_rotatey_2_0));
MR_define_label(mercury__fn__trans__compose_rotatey_2_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_rotatey_2_0));
	{
	MR_Float	X;
	MR_Float	Cos;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatey_2_0
	X = MR_word_to_float(MR_r1);
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);
;}
#line 4770 "trans.c"
	MR_r2 = MR_float_to_word(Cos);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	X;
	MR_Float	Sin;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatey_2_0
	X = MR_word_to_float(MR_r1);
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);
;}
#line 4785 "trans.c"
	MR_r3 = MR_float_to_word(Sin);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatey_2_0, "trans:matrix/0");
	MR_r5 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r5)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6))));
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1);
	MR_r8 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r8))));
	MR_r9 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2);
	MR_r10 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r9)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r10))));
	MR_r11 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 3);
	MR_r12 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 11);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 3) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r11)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r12))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 4) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 5) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 6) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 7);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 8) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r5))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 9) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r8)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 10) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r10)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r9))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 11) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r12)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r11))));
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatey_2_0, "trans:matrix/0");
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 3);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 4);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 4) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 5) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 6) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 7);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 8);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 8) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 9) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 10) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 11) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 11);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 2, mercury__fn__trans__compose_rotatey_2_0, "trans:trans/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r5;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate 'compose_rotatez'/3 in mode 0 */
MR_define_entry(mercury__fn__trans__compose_rotatez_2_0);
	{
	MR_Float	Pi;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatez_2_0
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;
;}
#line 4846 "trans.c"
	MR_r3 = MR_float_to_word(Pi);
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(4, "trans:compose_rotatez/3");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(3) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_r3)));
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	{
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatez_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 4867 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__compose_rotatez_2_0_i4);
#undef	MR_PROC_LABEL

	}
	if (((MR_Float) 180.000000000000 == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__compose_rotatez_2_0_i6);
	}
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / (MR_Float) 180.000000000000));
	{
	MR_Float	X;
	MR_Float	Cos;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatez_2_0
	X = MR_word_to_float(MR_r1);
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);
;}
#line 4886 "trans.c"
	MR_r2 = MR_float_to_word(Cos);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	X;
	MR_Float	Sin;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatez_2_0
	X = MR_word_to_float(MR_r1);
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);
;}
#line 4901 "trans.c"
	MR_r3 = MR_float_to_word(Sin);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatez_2_0, "trans:matrix/0");
	MR_r5 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r5)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6))));
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1);
	MR_r8 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r8))));
	MR_r9 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2);
	MR_r10 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r9)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r10))));
	MR_r11 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 3);
	MR_r12 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 7);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 3) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r11)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r12))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 4) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r5)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 5) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r8))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 6) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r9)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r10))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 7) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r11)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r12))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 8) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 9) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 10) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 11) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 11);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatez_2_0, "trans:matrix/0");
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 3);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 5);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 4) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 5) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 6) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 7);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 9);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 8) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 9) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 10) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 11) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 11);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 2, mercury__fn__trans__compose_rotatez_2_0, "trans:trans/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r5;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__fn__trans__compose_rotatez_2_0_i4);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / (MR_Float) 180.000000000000));
	{
	MR_Float	X;
	MR_Float	Cos;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatez_2_0
	X = MR_word_to_float(MR_r1);
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);
;}
#line 4964 "trans.c"
	MR_r2 = MR_float_to_word(Cos);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	X;
	MR_Float	Sin;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatez_2_0
	X = MR_word_to_float(MR_r1);
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);
;}
#line 4979 "trans.c"
	MR_r3 = MR_float_to_word(Sin);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatez_2_0, "trans:matrix/0");
	MR_r5 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r5)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6))));
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1);
	MR_r8 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r8))));
	MR_r9 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2);
	MR_r10 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r9)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r10))));
	MR_r11 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 3);
	MR_r12 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 7);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 3) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r11)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r12))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 4) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r5)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 5) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r8))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 6) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r9)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r10))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 7) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r11)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r12))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 8) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 9) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 10) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 11) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 11);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatez_2_0, "trans:matrix/0");
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 3);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 5);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 4) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 5) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 6) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 7);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 9);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 8) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 9) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 10) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 11) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 11);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 2, mercury__fn__trans__compose_rotatez_2_0, "trans:trans/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r5;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__fn__trans__compose_rotatez_2_0_i6);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__compose_rotatez_2_0_i8,
		MR_ENTRY(mercury__fn__trans__compose_rotatez_2_0));
MR_define_label(mercury__fn__trans__compose_rotatez_2_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__compose_rotatez_2_0));
	{
	MR_Float	X;
	MR_Float	Cos;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatez_2_0
	X = MR_word_to_float(MR_r1);
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);
;}
#line 5048 "trans.c"
	MR_r2 = MR_float_to_word(Cos);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	X;
	MR_Float	Sin;
#define	MR_PROC_LABEL	mercury__fn__trans__compose_rotatez_2_0
	X = MR_word_to_float(MR_r1);
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);
;}
#line 5063 "trans.c"
	MR_r3 = MR_float_to_word(Sin);
#undef	MR_PROC_LABEL

	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatez_2_0, "trans:matrix/0");
	MR_r5 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r5)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6))));
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1);
	MR_r8 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 5);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r8))));
	MR_r9 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2);
	MR_r10 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r9)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r10))));
	MR_r11 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 3);
	MR_r12 = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 7);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 3) = MR_float_to_word(((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r11)) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r12))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 4) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r5)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 5) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r8))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 6) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r9)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r10))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 7) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r11)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r12))));
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 8) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 9) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 9);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 10) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 11) = MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 11);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 12, mercury__fn__trans__compose_rotatez_2_0, "trans:matrix/0");
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 3) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 3);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 5);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 4);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 4) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 5) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 6) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 6);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 7) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 7);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 9);
	MR_r7 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 8);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 8) = MR_float_to_word(((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)) * MR_word_to_float(MR_r6)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 9) = MR_float_to_word(((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 10) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 10);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 11) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 11);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 2, mercury__fn__trans__compose_rotatez_2_0, "trans:trans/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_r5;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate 'intersects_plane'/6 in mode 0 */
MR_define_entry(mercury__trans__intersects_plane_6_0);
	MR_incr_sp_push_msg(10, "trans:intersects_plane/6");
	MR_stackvar(10) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r5;
	MR_r6 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r7 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	MR_r8 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1);
	MR_r9 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2);
	MR_stackvar(8) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 1)) * MR_word_to_float(MR_r8))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 2)) * MR_word_to_float(MR_r9))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 3))));
	MR_stackvar(4) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 4)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 5)) * MR_word_to_float(MR_r8))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 6)) * MR_word_to_float(MR_r9))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 7))));
	MR_stackvar(9) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 8)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 9)) * MR_word_to_float(MR_r8))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 10)) * MR_word_to_float(MR_r9))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 11))));
	MR_r1 = MR_r2;
	MR_r2 = MR_r4;
	MR_localcall(mercury__fn__trans__vector_to_object_space_2_0,
		MR_LABEL(mercury__trans__intersects_plane_6_0_i2),
		MR_ENTRY(mercury__trans__intersects_plane_6_0));
MR_define_label(mercury__trans__intersects_plane_6_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_plane_6_0));
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if ((MR_word_to_float(MR_stackvar(5)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__intersects_plane_6_0_i4);
	}
	MR_stackvar(7) = MR_float_to_word(((MR_Float) 0.00000000000000 - MR_word_to_float(MR_stackvar(4))));
	{
#define	MR_PROC_LABEL	mercury__trans__intersects_plane_6_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 5153 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__trans__intersects_plane_6_0_i9);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(5)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__intersects_plane_6_0_i11);
	}
	MR_r4 = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(5))));
	if ((MR_word_to_float(MR_r4) <= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__intersects_plane_6_0_i4);
	}
	MR_r1 = MR_stackvar(2);
	MR_stackvar(4) = MR_r3;
	MR_stackvar(5) = MR_r4;
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 3, mercury__trans__intersects_plane_6_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) + (MR_word_to_float(MR_stackvar(5)) * MR_word_to_float(MR_stackvar(4)))));
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) + (MR_word_to_float(MR_stackvar(5)) * MR_word_to_float(MR_stackvar(6)))));
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__fn__trans__point_to_world_space_2_0,
		MR_LABEL(mercury__trans__intersects_plane_6_0_i14),
		MR_ENTRY(mercury__trans__intersects_plane_6_0));
MR_define_label(mercury__trans__intersects_plane_6_0_i9);
	MR_r4 = MR_float_to_word((MR_word_to_float(MR_stackvar(7)) / MR_word_to_float(MR_stackvar(5))));
	if ((MR_word_to_float(MR_r4) <= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__intersects_plane_6_0_i4);
	}
	MR_r1 = MR_stackvar(2);
	MR_stackvar(4) = MR_r3;
	MR_stackvar(5) = MR_r4;
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 3, mercury__trans__intersects_plane_6_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) + (MR_word_to_float(MR_stackvar(5)) * MR_word_to_float(MR_stackvar(4)))));
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) + (MR_word_to_float(MR_stackvar(5)) * MR_word_to_float(MR_stackvar(6)))));
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__fn__trans__point_to_world_space_2_0,
		MR_LABEL(mercury__trans__intersects_plane_6_0_i14),
		MR_ENTRY(mercury__trans__intersects_plane_6_0));
MR_define_label(mercury__trans__intersects_plane_6_0_i11);
	MR_stackvar(4) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__trans__intersects_plane_6_0_i12,
		MR_ENTRY(mercury__trans__intersects_plane_6_0));
MR_define_label(mercury__trans__intersects_plane_6_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_plane_6_0));
	MR_r1 = MR_stackvar(2);
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 3, mercury__trans__intersects_plane_6_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) + (MR_word_to_float(MR_stackvar(5)) * MR_word_to_float(MR_stackvar(4)))));
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) + (MR_word_to_float(MR_stackvar(5)) * MR_word_to_float(MR_stackvar(6)))));
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__fn__trans__point_to_world_space_2_0,
		MR_LABEL(mercury__trans__intersects_plane_6_0_i14),
		MR_ENTRY(mercury__trans__intersects_plane_6_0));
MR_define_label(mercury__trans__intersects_plane_6_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_plane_6_0));
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(0), (MR_Integer) 3, mercury__trans__intersects_plane_6_0, "trans:surface_coordinates/0");
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 0) = (MR_Integer) 0;
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) + (MR_word_to_float(MR_stackvar(5)) * MR_word_to_float(MR_stackvar(4)))));
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_stackvar(9)) + (MR_word_to_float(MR_stackvar(5)) * MR_word_to_float(MR_stackvar(6)))));
	MR_r4 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_r4;
	MR_stackvar(4) = MR_r3;
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_trans__common_2);
	MR_localcall(mercury__fn__trans__vector_to_world_space_2_0,
		MR_LABEL(mercury__trans__intersects_plane_6_0_i15),
		MR_ENTRY(mercury__trans__intersects_plane_6_0));
MR_define_label(mercury__trans__intersects_plane_6_0_i15);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_plane_6_0));
	MR_call_localret(MR_ENTRY(mercury__fn__vector__unit_1_0),
		mercury__trans__intersects_plane_6_0_i16,
		MR_ENTRY(mercury__trans__intersects_plane_6_0));
MR_define_label(mercury__trans__intersects_plane_6_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_plane_6_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 5, mercury__trans__intersects_plane_6_0, "trans:intersection/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_r1;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 4) = MR_stackvar(3);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__trans__intersects_plane_6_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r2;
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	MR_proceed();
MR_define_label(mercury__trans__intersects_plane_6_0_i4);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	MR_proceed();
/* code for predicate 'intersects_sphere'/6 in mode 0 */
MR_define_entry(mercury__trans__intersects_sphere_6_0);
	MR_incr_sp_push_msg(11, "trans:intersects_sphere/6");
	MR_stackvar(11) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r5;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1);
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2);
	MR_stackvar(8) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3))));
	MR_stackvar(9) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7))));
	MR_stackvar(10) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 8)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 9)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 10)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 11))));
	MR_r1 = MR_r2;
	MR_r2 = MR_r4;
	}
	MR_localcall(mercury__fn__trans__vector_to_object_space_2_0,
		MR_LABEL(mercury__trans__intersects_sphere_6_0_i2),
		MR_ENTRY(mercury__trans__intersects_sphere_6_0));
MR_define_label(mercury__trans__intersects_sphere_6_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_sphere_6_0));
	MR_call_localret(MR_ENTRY(mercury__fn__vector__unit_1_0),
		mercury__trans__intersects_sphere_6_0_i3,
		MR_ENTRY(mercury__trans__intersects_sphere_6_0));
MR_define_label(mercury__trans__intersects_sphere_6_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_sphere_6_0));
	MR_stackvar(7) = MR_float_to_word((((((MR_Float) 0.00000000000000 - MR_word_to_float(MR_stackvar(8))) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))) + (((MR_Float) 0.00000000000000 - MR_word_to_float(MR_stackvar(9))) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)))) + (((MR_Float) 0.00000000000000 - MR_word_to_float(MR_stackvar(10))) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)))));
	MR_r2 = MR_float_to_word((((MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_stackvar(8))) + (MR_word_to_float(MR_stackvar(9)) * MR_word_to_float(MR_stackvar(9)))) + (MR_word_to_float(MR_stackvar(10)) * MR_word_to_float(MR_stackvar(10)))));
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if ((MR_word_to_float(MR_r2) <= (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__intersects_sphere_6_0_i6);
	}
	if ((MR_word_to_float(MR_stackvar(7)) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__intersects_sphere_6_0_i5);
	}
MR_define_label(mercury__trans__intersects_sphere_6_0_i6);
	MR_r1 = MR_float_to_word(((MR_Float) 1.00000000000000 - (MR_word_to_float(MR_r2) - (MR_word_to_float(MR_stackvar(7)) * MR_word_to_float(MR_stackvar(7))))));
	if ((MR_word_to_float(MR_r1) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__intersects_sphere_6_0_i5);
	}
	MR_call_localret(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		mercury__trans__intersects_sphere_6_0_i8,
		MR_ENTRY(mercury__trans__intersects_sphere_6_0));
MR_define_label(mercury__trans__intersects_sphere_6_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_sphere_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_stackvar(7);
	MR_stackvar(7) = MR_float_to_word((MR_word_to_float(MR_tempr1) + MR_word_to_float(MR_r1)));
	MR_tempr2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_float_to_word((MR_word_to_float(MR_tempr1) - MR_word_to_float(MR_tempr2)));
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(8);
	MR_r5 = MR_stackvar(9);
	MR_r6 = MR_stackvar(10);
	MR_r7 = MR_stackvar(4);
	MR_r8 = MR_stackvar(5);
	MR_r9 = MR_stackvar(6);
	MR_r10 = MR_stackvar(3);
	}
	MR_localcall(mercury__trans__intersects_sphere_2_11_0,
		MR_LABEL(mercury__trans__intersects_sphere_6_0_i9),
		MR_ENTRY(mercury__trans__intersects_sphere_6_0));
MR_define_label(mercury__trans__intersects_sphere_6_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_sphere_6_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_r2 = MR_stackvar(7);
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(8);
	MR_r5 = MR_stackvar(9);
	MR_r6 = MR_stackvar(10);
	MR_r7 = MR_stackvar(4);
	MR_r8 = MR_stackvar(5);
	MR_r9 = MR_stackvar(6);
	MR_r10 = MR_stackvar(3);
	}
	MR_localcall(mercury__trans__intersects_sphere_2_11_0,
		MR_LABEL(mercury__trans__intersects_sphere_6_0_i10),
		MR_ENTRY(mercury__trans__intersects_sphere_6_0));
MR_define_label(mercury__trans__intersects_sphere_6_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_sphere_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__trans__intersects_sphere_6_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__trans__intersects_sphere_6_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	MR_proceed();
	}
MR_define_label(mercury__trans__intersects_sphere_6_0_i5);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	MR_proceed();
/* code for predicate 'intersects_cube'/6 in mode 0 */
MR_define_entry(mercury__trans__intersects_cube_6_0);
	MR_incr_sp_push_msg(14, "trans:intersects_cube/6");
	MR_stackvar(14) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r5;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1);
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2);
	MR_stackvar(11) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3))));
	MR_stackvar(12) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7))));
	MR_stackvar(13) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 8)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 9)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 10)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 11))));
	MR_r1 = MR_r2;
	MR_r2 = MR_r4;
	}
	MR_localcall(mercury__fn__trans__vector_to_object_space_2_0,
		MR_LABEL(mercury__trans__intersects_cube_6_0_i2),
		MR_ENTRY(mercury__trans__intersects_cube_6_0));
MR_define_label(mercury__trans__intersects_cube_6_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cube_6_0));
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r1 = (MR_Integer) 0;
	MR_r2 = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_r3 = MR_stackvar(11);
	MR_r4 = MR_stackvar(12);
	MR_r5 = MR_stackvar(13);
	MR_r6 = MR_stackvar(4);
	MR_r7 = MR_stackvar(5);
	MR_r8 = MR_stackvar(6);
	MR_localcall(mercury__fn__trans__z_face_intersection_8_0,
		MR_LABEL(mercury__trans__intersects_cube_6_0_i3),
		MR_ENTRY(mercury__trans__intersects_cube_6_0));
MR_define_label(mercury__trans__intersects_cube_6_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cube_6_0));
	MR_stackvar(7) = MR_r1;
	MR_r1 = (MR_Integer) 1;
	MR_r2 = (MR_Word) &mercury_float_const_1pt00000000000000;
	MR_r3 = MR_stackvar(11);
	MR_r4 = MR_stackvar(12);
	MR_r5 = MR_stackvar(13);
	MR_r6 = MR_stackvar(4);
	MR_r7 = MR_stackvar(5);
	MR_r8 = MR_stackvar(6);
	MR_localcall(mercury__fn__trans__z_face_intersection_8_0,
		MR_LABEL(mercury__trans__intersects_cube_6_0_i4),
		MR_ENTRY(mercury__trans__intersects_cube_6_0));
MR_define_label(mercury__trans__intersects_cube_6_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cube_6_0));
	MR_stackvar(8) = MR_r1;
	MR_r1 = (MR_Integer) 2;
	MR_r2 = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_r3 = MR_stackvar(11);
	MR_r4 = MR_stackvar(12);
	MR_r5 = MR_stackvar(13);
	MR_r6 = MR_stackvar(4);
	MR_r7 = MR_stackvar(5);
	MR_r8 = MR_stackvar(6);
	MR_localcall(mercury__fn__trans__x_face_intersection_8_0,
		MR_LABEL(mercury__trans__intersects_cube_6_0_i5),
		MR_ENTRY(mercury__trans__intersects_cube_6_0));
MR_define_label(mercury__trans__intersects_cube_6_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cube_6_0));
	MR_stackvar(9) = MR_r1;
	MR_r1 = (MR_Integer) 3;
	MR_r2 = (MR_Word) &mercury_float_const_1pt00000000000000;
	MR_r3 = MR_stackvar(11);
	MR_r4 = MR_stackvar(12);
	MR_r5 = MR_stackvar(13);
	MR_r6 = MR_stackvar(4);
	MR_r7 = MR_stackvar(5);
	MR_r8 = MR_stackvar(6);
	MR_localcall(mercury__fn__trans__x_face_intersection_8_0,
		MR_LABEL(mercury__trans__intersects_cube_6_0_i6),
		MR_ENTRY(mercury__trans__intersects_cube_6_0));
MR_define_label(mercury__trans__intersects_cube_6_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cube_6_0));
	MR_stackvar(10) = MR_r1;
	MR_r1 = (MR_Integer) 4;
	MR_r2 = (MR_Word) &mercury_float_const_1pt00000000000000;
	MR_r3 = MR_stackvar(11);
	MR_r4 = MR_stackvar(12);
	MR_r5 = MR_stackvar(13);
	MR_r6 = MR_stackvar(4);
	MR_r7 = MR_stackvar(5);
	MR_r8 = MR_stackvar(6);
	MR_localcall(mercury__fn__trans__y_face_intersection_8_0,
		MR_LABEL(mercury__trans__intersects_cube_6_0_i7),
		MR_ENTRY(mercury__trans__intersects_cube_6_0));
MR_define_label(mercury__trans__intersects_cube_6_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cube_6_0));
	MR_r6 = MR_stackvar(4);
	MR_stackvar(4) = MR_r1;
	MR_r1 = (MR_Integer) 5;
	MR_r2 = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_r3 = MR_stackvar(11);
	MR_r4 = MR_stackvar(12);
	MR_r5 = MR_stackvar(13);
	MR_r7 = MR_stackvar(5);
	MR_r8 = MR_stackvar(6);
	MR_localcall(mercury__fn__trans__y_face_intersection_8_0,
		MR_LABEL(mercury__trans__intersects_cube_6_0_i8),
		MR_ENTRY(mercury__trans__intersects_cube_6_0));
MR_define_label(mercury__trans__intersects_cube_6_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cube_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__trans__intersects_cube_6_0, "list:list/1");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__trans__intersects_cube_6_0, "list:list/1");
	MR_r4 = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(1), (MR_Integer) 2, mercury__trans__intersects_cube_6_0, "list:list/1");
	MR_r3 = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr3, (MR_Integer) 0) = MR_stackvar(10);
	MR_field(MR_mktag(1), MR_tempr3, (MR_Integer) 1) = MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr4, MR_mktag(1), (MR_Integer) 2, mercury__trans__intersects_cube_6_0, "list:list/1");
	MR_r4 = MR_tempr4;
	MR_field(MR_mktag(1), MR_tempr4, (MR_Integer) 0) = MR_stackvar(9);
	MR_field(MR_mktag(1), MR_tempr4, (MR_Integer) 1) = MR_tempr3;
	MR_tag_incr_hp_msg(MR_tempr5, MR_mktag(1), (MR_Integer) 2, mercury__trans__intersects_cube_6_0, "list:list/1");
	MR_r3 = MR_tempr5;
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 1) = MR_tempr4;
	MR_tag_incr_hp_msg(MR_tempr6, MR_mktag(1), (MR_Integer) 2, mercury__trans__intersects_cube_6_0, "list:list/1");
	MR_r2 = MR_tempr6;
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 1) = MR_tempr5;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_trans__type_ctor_info_face_intersection_0;
	}
	MR_call_localret(MR_ENTRY(mercury__list__condense_2_0),
		mercury__trans__intersects_cube_6_0_i9,
		MR_ENTRY(mercury__trans__intersects_cube_6_0));
MR_define_label(mercury__trans__intersects_cube_6_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cube_6_0));
	MR_r4 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	MR_localtailcall(mercury__fn__trans__list__map__ho4__ua0_2_0,
		MR_ENTRY(mercury__trans__intersects_cube_6_0));
/* code for predicate 'intersects_cylinder'/6 in mode 0 */
MR_define_entry(mercury__trans__intersects_cylinder_6_0);
	MR_incr_sp_push_msg(11, "trans:intersects_cylinder/6");
	MR_stackvar(11) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r5;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1);
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2);
	MR_stackvar(8) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3))));
	MR_stackvar(9) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7))));
	MR_stackvar(10) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 8)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 9)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 10)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 11))));
	MR_r1 = MR_r2;
	MR_r2 = MR_r4;
	}
	MR_localcall(mercury__fn__trans__vector_to_object_space_2_0,
		MR_LABEL(mercury__trans__intersects_cylinder_6_0_i2),
		MR_ENTRY(mercury__trans__intersects_cylinder_6_0));
MR_define_label(mercury__trans__intersects_cylinder_6_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cylinder_6_0));
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r1 = (MR_Integer) 0;
	MR_r2 = MR_stackvar(8);
	MR_r3 = MR_stackvar(9);
	MR_r4 = MR_stackvar(10);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_localcall(mercury__fn__trans__cylinder_intersection_7_0,
		MR_LABEL(mercury__trans__intersects_cylinder_6_0_i3),
		MR_ENTRY(mercury__trans__intersects_cylinder_6_0));
MR_define_label(mercury__trans__intersects_cylinder_6_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cylinder_6_0));
	MR_stackvar(7) = MR_r1;
	MR_r1 = (MR_Integer) 1;
	MR_r2 = (MR_Word) &mercury_float_const_1pt00000000000000;
	MR_r3 = MR_stackvar(8);
	MR_r4 = MR_stackvar(9);
	MR_r5 = MR_stackvar(10);
	MR_r6 = MR_stackvar(4);
	MR_r7 = MR_stackvar(5);
	MR_r8 = MR_stackvar(6);
	MR_localcall(mercury__fn__trans__disc_intersection_8_0,
		MR_LABEL(mercury__trans__intersects_cylinder_6_0_i4),
		MR_ENTRY(mercury__trans__intersects_cylinder_6_0));
MR_define_label(mercury__trans__intersects_cylinder_6_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cylinder_6_0));
	MR_r6 = MR_stackvar(4);
	MR_stackvar(4) = MR_r1;
	MR_r1 = (MR_Integer) 2;
	MR_r2 = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_r3 = MR_stackvar(8);
	MR_r4 = MR_stackvar(9);
	MR_r5 = MR_stackvar(10);
	MR_r7 = MR_stackvar(5);
	MR_r8 = MR_stackvar(6);
	MR_localcall(mercury__fn__trans__disc_intersection_8_0,
		MR_LABEL(mercury__trans__intersects_cylinder_6_0_i5),
		MR_ENTRY(mercury__trans__intersects_cylinder_6_0));
MR_define_label(mercury__trans__intersects_cylinder_6_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cylinder_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__trans__intersects_cylinder_6_0, "list:list/1");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__trans__intersects_cylinder_6_0, "list:list/1");
	MR_r4 = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(1), (MR_Integer) 2, mercury__trans__intersects_cylinder_6_0, "list:list/1");
	MR_r2 = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr3, (MR_Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), MR_tempr3, (MR_Integer) 1) = MR_tempr2;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_trans__type_ctor_info_face_intersection_0;
	}
	MR_call_localret(MR_ENTRY(mercury__list__condense_2_0),
		mercury__trans__intersects_cylinder_6_0_i6,
		MR_ENTRY(mercury__trans__intersects_cylinder_6_0));
MR_define_label(mercury__trans__intersects_cylinder_6_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cylinder_6_0));
	MR_r4 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	MR_localtailcall(mercury__trans__list__map__ho6__ua0_3_0,
		MR_ENTRY(mercury__trans__intersects_cylinder_6_0));
/* code for predicate 'intersects_cone'/6 in mode 0 */
MR_define_entry(mercury__trans__intersects_cone_6_0);
	MR_incr_sp_push_msg(10, "trans:intersects_cone/6");
	MR_stackvar(10) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r5;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1);
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2);
	MR_stackvar(7) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3))));
	MR_stackvar(8) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7))));
	MR_stackvar(9) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 8)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 9)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 10)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 11))));
	MR_r1 = MR_r2;
	MR_r2 = MR_r4;
	}
	MR_localcall(mercury__fn__trans__vector_to_object_space_2_0,
		MR_LABEL(mercury__trans__intersects_cone_6_0_i2),
		MR_ENTRY(mercury__trans__intersects_cone_6_0));
MR_define_label(mercury__trans__intersects_cone_6_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cone_6_0));
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r1 = (MR_Integer) 0;
	MR_r2 = MR_stackvar(7);
	MR_r3 = MR_stackvar(8);
	MR_r4 = MR_stackvar(9);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_localcall(mercury__fn__trans__cone_intersection_7_0,
		MR_LABEL(mercury__trans__intersects_cone_6_0_i3),
		MR_ENTRY(mercury__trans__intersects_cone_6_0));
MR_define_label(mercury__trans__intersects_cone_6_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cone_6_0));
	MR_r6 = MR_stackvar(4);
	MR_stackvar(4) = MR_r1;
	MR_r1 = (MR_Integer) 1;
	MR_r2 = (MR_Word) &mercury_float_const_1pt00000000000000;
	MR_r3 = MR_stackvar(7);
	MR_r4 = MR_stackvar(8);
	MR_r5 = MR_stackvar(9);
	MR_r7 = MR_stackvar(5);
	MR_r8 = MR_stackvar(6);
	MR_localcall(mercury__fn__trans__disc_intersection_8_0,
		MR_LABEL(mercury__trans__intersects_cone_6_0_i4),
		MR_ENTRY(mercury__trans__intersects_cone_6_0));
MR_define_label(mercury__trans__intersects_cone_6_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cone_6_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_trans__type_ctor_info_face_intersection_0;
	MR_r3 = MR_stackvar(4);
	MR_call_localret(MR_ENTRY(mercury__list__append_3_1),
		mercury__trans__intersects_cone_6_0_i5,
		MR_ENTRY(mercury__trans__intersects_cone_6_0));
MR_define_label(mercury__trans__intersects_cone_6_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_cone_6_0));
	MR_r4 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	MR_localtailcall(mercury__trans__list__map__ho7__ua0_3_0,
		MR_ENTRY(mercury__trans__intersects_cone_6_0));
/* code for predicate 'inside_sphere'/2 in mode 0 */
MR_define_entry(mercury__trans__inside_sphere_2_0);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r4 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_tempr2;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r5 = MR_tempr3;
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r6 = MR_tempr4;
	MR_r3 = MR_float_to_word((((((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3))) * ((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3)))) + (((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7))) * ((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7))))) + (((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 8)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 9)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 10)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 11))) * ((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 8)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 9)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 10)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 11))))));
	MR_r1 = (MR_word_to_float(MR_r3) <= (MR_Float) 1.00000000000000);
	MR_proceed();
	}
/* code for predicate 'inside_plane'/2 in mode 0 */
MR_define_entry(mercury__trans__inside_plane_2_0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r4 = MR_tempr1;
	MR_r3 = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7))));
	MR_r1 = (MR_word_to_float(MR_r3) <= (MR_Float) 0.00000000000000);
	MR_proceed();
	}
/* code for predicate 'inside_cube'/2 in mode 0 */
MR_define_entry(mercury__trans__inside_cube_2_0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r4 = MR_tempr1;
	MR_r3 = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3))));
	if ((MR_word_to_float(MR_r3) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__inside_cube_2_0_i1);
	}
	if ((MR_word_to_float(MR_r3) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__inside_cube_2_0_i1);
	}
	MR_r2 = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 4)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 5)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 6)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 7))));
	if ((MR_word_to_float(MR_r2) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__inside_cube_2_0_i1);
	}
	if ((MR_word_to_float(MR_r2) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__inside_cube_2_0_i1);
	}
	MR_r2 = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 8)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 9)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 10)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 11))));
	if ((MR_word_to_float(MR_r2) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__inside_cube_2_0_i1);
	}
	MR_r1 = (MR_word_to_float(MR_r2) <= (MR_Float) 1.00000000000000);
	MR_proceed();
	}
MR_define_label(mercury__trans__inside_cube_2_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate 'inside_cylinder'/2 in mode 0 */
MR_define_entry(mercury__trans__inside_cylinder_2_0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r4 = MR_tempr1;
	MR_r2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r5 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r6 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r3 = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4)) * MR_word_to_float(MR_r2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5)) * MR_word_to_float(MR_r5))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6)) * MR_word_to_float(MR_r6))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7))));
	if ((MR_word_to_float(MR_r3) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__inside_cylinder_2_0_i1);
	}
	if ((MR_word_to_float(MR_r3) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__inside_cylinder_2_0_i1);
	}
	MR_r1 = MR_float_to_word(((((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0)) * MR_word_to_float(MR_r2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1)) * MR_word_to_float(MR_r5))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 2)) * MR_word_to_float(MR_r6))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 3))) * ((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0)) * MR_word_to_float(MR_r2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1)) * MR_word_to_float(MR_r5))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 2)) * MR_word_to_float(MR_r6))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 3)))) + (((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 8)) * MR_word_to_float(MR_r2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 9)) * MR_word_to_float(MR_r5))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 10)) * MR_word_to_float(MR_r6))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 11))) * ((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 8)) * MR_word_to_float(MR_r2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 9)) * MR_word_to_float(MR_r5))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 10)) * MR_word_to_float(MR_r6))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 11))))));
	MR_r1 = (MR_word_to_float(MR_r1) <= (MR_Float) 1.00000000000000);
	MR_proceed();
	}
MR_define_label(mercury__trans__inside_cylinder_2_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate 'inside_cone'/2 in mode 0 */
MR_define_entry(mercury__trans__inside_cone_2_0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r4 = MR_tempr1;
	MR_r2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r5 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r6 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r3 = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4)) * MR_word_to_float(MR_r2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5)) * MR_word_to_float(MR_r5))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6)) * MR_word_to_float(MR_r6))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7))));
	if ((MR_word_to_float(MR_r3) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__inside_cone_2_0_i1);
	}
	if ((MR_word_to_float(MR_r3) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__inside_cone_2_0_i1);
	}
	MR_r1 = MR_float_to_word((((((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0)) * MR_word_to_float(MR_r2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1)) * MR_word_to_float(MR_r5))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 2)) * MR_word_to_float(MR_r6))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 3))) * ((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0)) * MR_word_to_float(MR_r2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1)) * MR_word_to_float(MR_r5))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 2)) * MR_word_to_float(MR_r6))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 3)))) + (((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 8)) * MR_word_to_float(MR_r2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 9)) * MR_word_to_float(MR_r5))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 10)) * MR_word_to_float(MR_r6))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 11))) * ((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 8)) * MR_word_to_float(MR_r2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 9)) * MR_word_to_float(MR_r5))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 10)) * MR_word_to_float(MR_r6))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 11))))) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r3))));
	MR_r1 = (MR_word_to_float(MR_r1) <= (MR_Float) 0.00000000000000);
	MR_proceed();
	}
MR_define_label(mercury__trans__inside_cone_2_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate 'show_trans'/3 in mode 0 */
MR_define_entry(mercury__trans__show_trans_3_0);
	MR_incr_sp_push_msg(25, "trans:show_trans/3");
	MR_stackvar(25) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_tempr1;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 8);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 9);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 10);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 11);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r4 = MR_tempr2;
	MR_stackvar(13) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 3);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 7);
	MR_stackvar(21) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8);
	MR_stackvar(22) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9);
	MR_stackvar(23) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10);
	MR_stackvar(24) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 11);
	MR_r1 = (MR_Word) MR_string_const("object -> world space    world -> object space\n", 47);
	MR_r3 = MR_r2;
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	}
	MR_call_localret(MR_ENTRY(mercury__io__format_4_0),
		mercury__trans__show_trans_3_0_i2,
		MR_ENTRY(mercury__trans__show_trans_3_0));
MR_define_label(mercury__trans__show_trans_3_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__show_trans_3_0));
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7, MR_tempr8;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r4 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r5 = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0) = MR_stackvar(2);
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r6 = MR_tempr3;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_stackvar(3);
	MR_tag_incr_hp_msg(MR_tempr4, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r7 = MR_tempr4;
	MR_field(MR_mktag(0), MR_tempr4, (MR_Integer) 0) = MR_stackvar(4);
	MR_tag_incr_hp_msg(MR_tempr5, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r8 = MR_tempr5;
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 0) = MR_tempr4;
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_tempr6, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r7 = MR_tempr6;
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 0) = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 1) = MR_tempr5;
	MR_tag_incr_hp_msg(MR_tempr7, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r6 = MR_tempr7;
	MR_field(MR_mktag(1), MR_tempr7, (MR_Integer) 0) = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr7, (MR_Integer) 1) = MR_tempr6;
	MR_tag_incr_hp_msg(MR_tempr8, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r2 = MR_tempr8;
	MR_field(MR_mktag(1), MR_tempr8, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr8, (MR_Integer) 1) = MR_tempr7;
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("(%4.1f %4.1f %4.1f %4.1f)    ", 29);
	}
	MR_call_localret(MR_ENTRY(mercury__io__format_4_0),
		mercury__trans__show_trans_3_0_i3,
		MR_ENTRY(mercury__trans__show_trans_3_0));
MR_define_label(mercury__trans__show_trans_3_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__show_trans_3_0));
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7, MR_tempr8;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r4 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(13);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r5 = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0) = MR_stackvar(14);
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r6 = MR_tempr3;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_stackvar(15);
	MR_tag_incr_hp_msg(MR_tempr4, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r7 = MR_tempr4;
	MR_field(MR_mktag(0), MR_tempr4, (MR_Integer) 0) = MR_stackvar(16);
	MR_tag_incr_hp_msg(MR_tempr5, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r8 = MR_tempr5;
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 0) = MR_tempr4;
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_tempr6, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r7 = MR_tempr6;
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 0) = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 1) = MR_tempr5;
	MR_tag_incr_hp_msg(MR_tempr7, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r6 = MR_tempr7;
	MR_field(MR_mktag(1), MR_tempr7, (MR_Integer) 0) = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr7, (MR_Integer) 1) = MR_tempr6;
	MR_tag_incr_hp_msg(MR_tempr8, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r2 = MR_tempr8;
	MR_field(MR_mktag(1), MR_tempr8, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr8, (MR_Integer) 1) = MR_tempr7;
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("(%4.1f %4.1f %4.1f %4.1f)\n", 26);
	}
	MR_call_localret(MR_ENTRY(mercury__io__format_4_0),
		mercury__trans__show_trans_3_0_i4,
		MR_ENTRY(mercury__trans__show_trans_3_0));
MR_define_label(mercury__trans__show_trans_3_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__show_trans_3_0));
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7, MR_tempr8;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r4 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(5);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r5 = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0) = MR_stackvar(6);
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r6 = MR_tempr3;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_stackvar(7);
	MR_tag_incr_hp_msg(MR_tempr4, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r7 = MR_tempr4;
	MR_field(MR_mktag(0), MR_tempr4, (MR_Integer) 0) = MR_stackvar(8);
	MR_tag_incr_hp_msg(MR_tempr5, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r8 = MR_tempr5;
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 0) = MR_tempr4;
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_tempr6, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r7 = MR_tempr6;
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 0) = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 1) = MR_tempr5;
	MR_tag_incr_hp_msg(MR_tempr7, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r6 = MR_tempr7;
	MR_field(MR_mktag(1), MR_tempr7, (MR_Integer) 0) = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr7, (MR_Integer) 1) = MR_tempr6;
	MR_tag_incr_hp_msg(MR_tempr8, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r2 = MR_tempr8;
	MR_field(MR_mktag(1), MR_tempr8, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr8, (MR_Integer) 1) = MR_tempr7;
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("(%4.1f %4.1f %4.1f %4.1f)    ", 29);
	}
	MR_call_localret(MR_ENTRY(mercury__io__format_4_0),
		mercury__trans__show_trans_3_0_i5,
		MR_ENTRY(mercury__trans__show_trans_3_0));
MR_define_label(mercury__trans__show_trans_3_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__show_trans_3_0));
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7, MR_tempr8;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r4 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(17);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r5 = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0) = MR_stackvar(18);
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r6 = MR_tempr3;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_stackvar(19);
	MR_tag_incr_hp_msg(MR_tempr4, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r7 = MR_tempr4;
	MR_field(MR_mktag(0), MR_tempr4, (MR_Integer) 0) = MR_stackvar(20);
	MR_tag_incr_hp_msg(MR_tempr5, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r8 = MR_tempr5;
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 0) = MR_tempr4;
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_tempr6, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r7 = MR_tempr6;
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 0) = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 1) = MR_tempr5;
	MR_tag_incr_hp_msg(MR_tempr7, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r6 = MR_tempr7;
	MR_field(MR_mktag(1), MR_tempr7, (MR_Integer) 0) = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr7, (MR_Integer) 1) = MR_tempr6;
	MR_tag_incr_hp_msg(MR_tempr8, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r2 = MR_tempr8;
	MR_field(MR_mktag(1), MR_tempr8, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr8, (MR_Integer) 1) = MR_tempr7;
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("(%4.1f %4.1f %4.1f %4.1f)\n", 26);
	}
	MR_call_localret(MR_ENTRY(mercury__io__format_4_0),
		mercury__trans__show_trans_3_0_i6,
		MR_ENTRY(mercury__trans__show_trans_3_0));
MR_define_label(mercury__trans__show_trans_3_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__show_trans_3_0));
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7, MR_tempr8;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r4 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(9);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r5 = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0) = MR_stackvar(10);
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r6 = MR_tempr3;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_stackvar(11);
	MR_tag_incr_hp_msg(MR_tempr4, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r7 = MR_tempr4;
	MR_field(MR_mktag(0), MR_tempr4, (MR_Integer) 0) = MR_stackvar(12);
	MR_tag_incr_hp_msg(MR_tempr5, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r8 = MR_tempr5;
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 0) = MR_tempr4;
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_tempr6, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r7 = MR_tempr6;
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 0) = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 1) = MR_tempr5;
	MR_tag_incr_hp_msg(MR_tempr7, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r6 = MR_tempr7;
	MR_field(MR_mktag(1), MR_tempr7, (MR_Integer) 0) = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr7, (MR_Integer) 1) = MR_tempr6;
	MR_tag_incr_hp_msg(MR_tempr8, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r2 = MR_tempr8;
	MR_field(MR_mktag(1), MR_tempr8, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr8, (MR_Integer) 1) = MR_tempr7;
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("(%4.1f %4.1f %4.1f %4.1f)    ", 29);
	}
	MR_call_localret(MR_ENTRY(mercury__io__format_4_0),
		mercury__trans__show_trans_3_0_i7,
		MR_ENTRY(mercury__trans__show_trans_3_0));
MR_define_label(mercury__trans__show_trans_3_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__show_trans_3_0));
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7, MR_tempr8;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r4 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(21);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r5 = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0) = MR_stackvar(22);
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r6 = MR_tempr3;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_stackvar(23);
	MR_tag_incr_hp_msg(MR_tempr4, MR_mktag(0), (MR_Integer) 1, mercury__trans__show_trans_3_0, "string:poly_type/0");
	MR_r7 = MR_tempr4;
	MR_field(MR_mktag(0), MR_tempr4, (MR_Integer) 0) = MR_stackvar(24);
	MR_tag_incr_hp_msg(MR_tempr5, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r8 = MR_tempr5;
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 0) = MR_tempr4;
	MR_field(MR_mktag(1), MR_tempr5, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_tempr6, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r7 = MR_tempr6;
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 0) = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr6, (MR_Integer) 1) = MR_tempr5;
	MR_tag_incr_hp_msg(MR_tempr7, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r6 = MR_tempr7;
	MR_field(MR_mktag(1), MR_tempr7, (MR_Integer) 0) = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr7, (MR_Integer) 1) = MR_tempr6;
	MR_tag_incr_hp_msg(MR_tempr8, MR_mktag(1), (MR_Integer) 2, mercury__trans__show_trans_3_0, "list:list/1");
	MR_r2 = MR_tempr8;
	MR_field(MR_mktag(1), MR_tempr8, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr8, (MR_Integer) 1) = MR_tempr7;
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("(%4.1f %4.1f %4.1f %4.1f)\n", 26);
	}
	MR_call_localret(MR_ENTRY(mercury__io__format_4_0),
		mercury__trans__show_trans_3_0_i8,
		MR_ENTRY(mercury__trans__show_trans_3_0));
MR_define_label(mercury__trans__show_trans_3_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__show_trans_3_0));
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("( 0.0  0.0  0.0  1.0)    ( 0.0  0.0  0.0  1.0)\n", 47);
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(25);
	MR_decr_sp_pop_msg(25);
	MR_tailcall(MR_ENTRY(mercury__io__format_4_0),
		MR_ENTRY(mercury__trans__show_trans_3_0));
/* code for predicate 'unit_matrix'/1 in mode 0 */
MR_define_entry(mercury__fn__trans__unit_matrix_0_0);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_trans__common_0);
	MR_proceed();
/* code for predicate 'transform_point'/3 in mode 0 */
MR_define_entry(mercury__fn__trans__transform_point_2_0);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__transform_point_2_0, "vector:vector/0");
	MR_r3 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r4 = MR_tempr2;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r5 = MR_tempr3;
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r6 = MR_tempr4;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 5)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 6)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 7))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 8)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 9)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 10)) * MR_word_to_float(MR_tempr4))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 11))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'transform_vector'/3 in mode 0 */
MR_define_entry(mercury__fn__trans__transform_vector_2_0);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__transform_vector_2_0, "vector:vector/0");
	MR_r3 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r4 = MR_tempr2;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r5 = MR_tempr3;
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r6 = MR_tempr4;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)) * MR_word_to_float(MR_tempr4))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 5)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 6)) * MR_word_to_float(MR_tempr4))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 8)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 9)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 10)) * MR_word_to_float(MR_tempr4))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'transform_normal'/3 in mode 0 */
MR_define_entry(mercury__fn__trans__transform_normal_2_0);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__transform_normal_2_0, "vector:vector/0");
	MR_r3 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r4 = MR_tempr2;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r5 = MR_tempr3;
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r6 = MR_tempr4;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 8)) * MR_word_to_float(MR_tempr4))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 5)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 9)) * MR_word_to_float(MR_tempr4))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)) * MR_word_to_float(MR_tempr2)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 6)) * MR_word_to_float(MR_tempr3))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 10)) * MR_word_to_float(MR_tempr4))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'intersects_sphere_2'/11 in mode 0 */
MR_define_static(mercury__trans__intersects_sphere_2_11_0);
	MR_incr_sp_push_msg(7, "trans:intersects_sphere_2/11");
	MR_stackvar(7) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__trans__intersects_sphere_2_11_0, "vector:vector/0");
	MR_stackvar(6) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_r4) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r7))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r5) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r8))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_r6) + (MR_word_to_float(MR_r2) * MR_word_to_float(MR_r9))));
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(0), (MR_Integer) 3, mercury__trans__intersects_sphere_2_11_0, "vector:vector/0");
	MR_stackvar(4) = MR_tempr2;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 2)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2)))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 3))));
	MR_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 4)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 5)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 6)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2)))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 7))));
	MR_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 8)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 9)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 10)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2)))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr3, (MR_Integer) 11))));
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r10;
	MR_stackvar(5) = MR_float_to_word(((MR_Float) 0.500000000000000 * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1)) + (MR_Float) 1.00000000000000)));
	MR_r1 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	}
	MR_localcall(mercury__fn__trans__calc_u_2_0,
		MR_LABEL(mercury__trans__intersects_sphere_2_11_0_i2),
		MR_STATIC(mercury__trans__intersects_sphere_2_11_0));
MR_define_label(mercury__trans__intersects_sphere_2_11_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_sphere_2_11_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__trans__intersects_sphere_2_11_0, "trans:surface_coordinates/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_stackvar(5);
	MR_r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	MR_r2 = MR_stackvar(6);
	}
	MR_localcall(mercury__fn__trans__normal_to_world_space_2_0,
		MR_LABEL(mercury__trans__intersects_sphere_2_11_0_i3),
		MR_STATIC(mercury__trans__intersects_sphere_2_11_0));
MR_define_label(mercury__trans__intersects_sphere_2_11_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_sphere_2_11_0));
	MR_call_localret(MR_ENTRY(mercury__fn__vector__unit_1_0),
		mercury__trans__intersects_sphere_2_11_0_i4,
		MR_STATIC(mercury__trans__intersects_sphere_2_11_0));
MR_define_label(mercury__trans__intersects_sphere_2_11_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__trans__intersects_sphere_2_11_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 5, mercury__trans__intersects_sphere_2_11_0, "trans:intersection/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4) = MR_stackvar(3);
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
	}
/* code for predicate 'process_cube_intersections'/5 in mode 0 */
MR_define_static(mercury__fn__trans__process_cube_intersections_4_0);
	MR_incr_sp_push_msg(5, "trans:process_cube_intersections/5");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_r5 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 3);
	MR_r6 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 2);
	MR_r7 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1);
	MR_r8 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	if (((MR_Integer) MR_r8 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cube_intersections_4_0_i2);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cube_intersections_4_0, "vector:vector/0");
	MR_stackvar(2) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 3))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 7))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 11))));
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cube_intersections_4_0, "trans:surface_coordinates/0");
	MR_stackvar(4) = MR_tempr3;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_r8;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1) = MR_r7;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 2) = MR_r6;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_trans__common_3);
	}
	MR_localcall(mercury__fn__trans__normal_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cube_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cube_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cube_intersections_4_0_i2);
	if (((MR_Integer) MR_r8 != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cube_intersections_4_0_i4);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cube_intersections_4_0, "vector:vector/0");
	MR_stackvar(2) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 3))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 7))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 11))));
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cube_intersections_4_0, "trans:surface_coordinates/0");
	MR_stackvar(4) = MR_tempr3;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_r8;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1) = MR_r7;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 2) = MR_r6;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_trans__common_4);
	}
	MR_localcall(mercury__fn__trans__normal_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cube_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cube_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cube_intersections_4_0_i4);
	if (((MR_Integer) MR_r8 != (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cube_intersections_4_0_i6);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cube_intersections_4_0, "vector:vector/0");
	MR_stackvar(2) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 3))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 7))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 11))));
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cube_intersections_4_0, "trans:surface_coordinates/0");
	MR_stackvar(4) = MR_tempr3;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_r8;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1) = MR_r5;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 2) = MR_r6;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_trans__common_5);
	}
	MR_localcall(mercury__fn__trans__normal_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cube_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cube_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cube_intersections_4_0_i6);
	if (((MR_Integer) MR_r8 != (MR_Integer) 3)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cube_intersections_4_0_i8);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cube_intersections_4_0, "vector:vector/0");
	MR_stackvar(2) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 3))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 7))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 11))));
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cube_intersections_4_0, "trans:surface_coordinates/0");
	MR_stackvar(4) = MR_tempr3;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_r8;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1) = MR_r5;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 2) = MR_r6;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_trans__common_6);
	}
	MR_localcall(mercury__fn__trans__normal_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cube_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cube_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cube_intersections_4_0_i8);
	if (((MR_Integer) MR_r8 != (MR_Integer) 4)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cube_intersections_4_0_i10);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cube_intersections_4_0, "vector:vector/0");
	MR_stackvar(2) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 3))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 7))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 11))));
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cube_intersections_4_0, "trans:surface_coordinates/0");
	MR_stackvar(4) = MR_tempr3;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_r8;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1) = MR_r7;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 2) = MR_r5;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_trans__common_2);
	}
	MR_localcall(mercury__fn__trans__normal_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cube_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cube_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cube_intersections_4_0_i10);
	if (((MR_Integer) MR_r8 != (MR_Integer) 5)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cube_intersections_4_0_i12);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cube_intersections_4_0, "vector:vector/0");
	MR_stackvar(2) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 3))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 4)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 5)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 6)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 7))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 8)) * MR_word_to_float(MR_r7)) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 9)) * MR_word_to_float(MR_r6))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 10)) * MR_word_to_float(MR_r5))) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 11))));
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cube_intersections_4_0, "trans:surface_coordinates/0");
	MR_stackvar(4) = MR_tempr3;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 0) = MR_r8;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 1) = MR_r7;
	MR_field(MR_mktag(0), MR_tempr3, (MR_Integer) 2) = MR_r5;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_trans__common_7);
	}
	MR_localcall(mercury__fn__trans__normal_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cube_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cube_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cube_intersections_4_0_i12);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) MR_string_const("trans: intersects_cube/6: not a face!", 37);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__process_cube_intersections_4_0_i14,
		MR_STATIC(mercury__fn__trans__process_cube_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cube_intersections_4_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__process_cube_intersections_4_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_localcall(mercury__fn__trans__normal_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cube_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cube_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cube_intersections_4_0_i21);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__process_cube_intersections_4_0));
	MR_call_localret(MR_ENTRY(mercury__fn__vector__unit_1_0),
		mercury__fn__trans__process_cube_intersections_4_0_i22,
		MR_STATIC(mercury__fn__trans__process_cube_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cube_intersections_4_0_i22);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__process_cube_intersections_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 5, mercury__fn__trans__process_cube_intersections_4_0, "trans:intersection/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4) = MR_stackvar(3);
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
	}
/* code for predicate 'z_face_intersection'/9 in mode 0 */
MR_define_static(mercury__fn__trans__z_face_intersection_8_0);
	MR_incr_sp_push_msg(9, "trans:z_face_intersection/9");
	MR_stackvar(9) = (MR_Word) MR_succip;
	if ((MR_word_to_float(MR_r8) != (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__z_face_intersection_8_0_i2);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__z_face_intersection_8_0_i2);
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_r2) - MR_word_to_float(MR_r5)));
	MR_stackvar(1) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__trans__z_face_intersection_8_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 6393 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__z_face_intersection_8_0_i6);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_r8) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__z_face_intersection_8_0_i8);
	}
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(6) = MR_r7;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r4 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r8 = MR_stackvar(7);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(6) = MR_r7;
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_r8)));
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__z_face_intersection_8_0_i11);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__z_face_intersection_8_0_i6);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(6) = MR_r7;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r4 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r8 = MR_stackvar(7);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(6) = MR_r7;
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_r8)));
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__z_face_intersection_8_0_i11);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__z_face_intersection_8_0_i8);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(6) = MR_r7;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__z_face_intersection_8_0_i10,
		MR_STATIC(mercury__fn__trans__z_face_intersection_8_0));
MR_define_label(mercury__fn__trans__z_face_intersection_8_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__z_face_intersection_8_0));
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__z_face_intersection_8_0_i11);
	}
MR_define_label(mercury__fn__trans__z_face_intersection_8_0_i21);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__z_face_intersection_8_0_i11);
	MR_r2 = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_stackvar(5)))));
	if (((MR_Float) 0.00000000000000 > MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury__fn__trans__z_face_intersection_8_0_i21);
	}
	if ((MR_word_to_float(MR_r2) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__z_face_intersection_8_0_i21);
	}
	MR_r3 = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_stackvar(6)))));
	if (((MR_Float) 0.00000000000000 > MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury__fn__trans__z_face_intersection_8_0_i21);
	}
	if ((MR_word_to_float(MR_r3) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__z_face_intersection_8_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 4, mercury__fn__trans__z_face_intersection_8_0, "trans:face_intersection/0");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_r2;
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_r3;
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 3) = MR_stackvar(2);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__fn__trans__z_face_intersection_8_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
/* code for predicate 'x_face_intersection'/9 in mode 0 */
MR_define_static(mercury__fn__trans__x_face_intersection_8_0);
	MR_incr_sp_push_msg(9, "trans:x_face_intersection/9");
	MR_stackvar(9) = (MR_Word) MR_succip;
	if ((MR_word_to_float(MR_r6) != (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__x_face_intersection_8_0_i2);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__x_face_intersection_8_0_i2);
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_r2) - MR_word_to_float(MR_r3)));
	MR_stackvar(1) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__trans__x_face_intersection_8_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 6528 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__x_face_intersection_8_0_i6);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_r6) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__x_face_intersection_8_0_i8);
	}
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(6) = MR_r7;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r8 = MR_stackvar(7);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(6) = MR_r7;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_r6)));
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__x_face_intersection_8_0_i11);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__x_face_intersection_8_0_i6);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(6) = MR_r7;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r8 = MR_stackvar(7);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(6) = MR_r7;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_r6)));
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__x_face_intersection_8_0_i11);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__x_face_intersection_8_0_i8);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(6) = MR_r7;
	MR_stackvar(7) = MR_r8;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__x_face_intersection_8_0_i10,
		MR_STATIC(mercury__fn__trans__x_face_intersection_8_0));
MR_define_label(mercury__fn__trans__x_face_intersection_8_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__x_face_intersection_8_0));
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__x_face_intersection_8_0_i11);
	}
MR_define_label(mercury__fn__trans__x_face_intersection_8_0_i21);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__x_face_intersection_8_0_i11);
	MR_r2 = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_stackvar(7)))));
	if (((MR_Float) 0.00000000000000 > MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury__fn__trans__x_face_intersection_8_0_i21);
	}
	if ((MR_word_to_float(MR_r2) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__x_face_intersection_8_0_i21);
	}
	MR_r3 = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_stackvar(6)))));
	if (((MR_Float) 0.00000000000000 > MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury__fn__trans__x_face_intersection_8_0_i21);
	}
	if ((MR_word_to_float(MR_r3) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__x_face_intersection_8_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 4, mercury__fn__trans__x_face_intersection_8_0, "trans:face_intersection/0");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_r3;
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 3) = MR_r2;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__fn__trans__x_face_intersection_8_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
/* code for predicate 'y_face_intersection'/9 in mode 0 */
MR_define_static(mercury__fn__trans__y_face_intersection_8_0);
	MR_incr_sp_push_msg(9, "trans:y_face_intersection/9");
	MR_stackvar(9) = (MR_Word) MR_succip;
	if ((MR_word_to_float(MR_r7) != (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__y_face_intersection_8_0_i2);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__y_face_intersection_8_0_i2);
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_r2) - MR_word_to_float(MR_r4)));
	MR_stackvar(1) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__trans__y_face_intersection_8_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 6663 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__y_face_intersection_8_0_i6);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_r7) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__y_face_intersection_8_0_i8);
	}
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(6) = MR_r7;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r8 = MR_stackvar(7);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_r7)));
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__y_face_intersection_8_0_i11);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__y_face_intersection_8_0_i6);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(6) = MR_r7;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r8 = MR_stackvar(7);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_r7)));
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__y_face_intersection_8_0_i11);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__y_face_intersection_8_0_i8);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(7) = MR_r8;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__y_face_intersection_8_0_i10,
		MR_STATIC(mercury__fn__trans__y_face_intersection_8_0));
MR_define_label(mercury__fn__trans__y_face_intersection_8_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__y_face_intersection_8_0));
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__y_face_intersection_8_0_i11);
	}
MR_define_label(mercury__fn__trans__y_face_intersection_8_0_i21);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__y_face_intersection_8_0_i11);
	MR_r2 = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_stackvar(7)))));
	if (((MR_Float) 0.00000000000000 > MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury__fn__trans__y_face_intersection_8_0_i21);
	}
	if ((MR_word_to_float(MR_r2) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__y_face_intersection_8_0_i21);
	}
	MR_r3 = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_stackvar(5)))));
	if (((MR_Float) 0.00000000000000 > MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury__fn__trans__y_face_intersection_8_0_i21);
	}
	if ((MR_word_to_float(MR_r3) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__y_face_intersection_8_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 4, mercury__fn__trans__y_face_intersection_8_0, "trans:face_intersection/0");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_r3;
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 3) = MR_r2;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__fn__trans__y_face_intersection_8_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r4;
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
/* code for predicate 'process_cylinder_intersections'/5 in mode 0 */
MR_define_static(mercury__fn__trans__process_cylinder_intersections_4_0);
	MR_incr_sp_push_msg(10, "trans:process_cylinder_intersections/5");
	MR_stackvar(10) = (MR_Word) MR_succip;
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	if (((MR_Integer) MR_stackvar(4) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i2);
	}
	{
	MR_Float	Y;
	MR_Float	X;
	MR_Float	ATan2;
#define	MR_PROC_LABEL	mercury__fn__trans__process_cylinder_intersections_4_0
	Y = MR_word_to_float(MR_stackvar(5));
	X = MR_word_to_float(MR_stackvar(7));
{
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	ATan2 = atan2(Y, X);
;}
#line 6796 "trans.c"
	MR_r4 = MR_float_to_word(ATan2);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	Pi;
#define	MR_PROC_LABEL	mercury__fn__trans__process_cylinder_intersections_4_0
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;
;}
#line 6809 "trans.c"
	MR_r5 = MR_float_to_word(Pi);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	Pi;
#define	MR_PROC_LABEL	mercury__fn__trans__process_cylinder_intersections_4_0
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;
;}
#line 6822 "trans.c"
	MR_r6 = MR_float_to_word(Pi);
#undef	MR_PROC_LABEL

	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_r5) + MR_word_to_float(MR_r6)));
	MR_stackvar(1) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__trans__process_cylinder_intersections_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 6840 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i6);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(9)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i8);
	}
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(8) = MR_r4;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r4 = MR_stackvar(8);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r2 = MR_float_to_word((MR_word_to_float(MR_r4) / MR_word_to_float(MR_stackvar(9))));
	if ((MR_word_to_float(MR_r2) <= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i11);
	}
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cylinder_intersections_4_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 2) = MR_stackvar(7);
	MR_r4 = MR_stackvar(5);
	MR_stackvar(5) = MR_r2;
	MR_stackvar(9) = MR_stackvar(7);
	MR_stackvar(7) = MR_r4;
	MR_stackvar(8) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_r2 = MR_r3;
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__fn__trans__point_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cylinder_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cylinder_intersections_4_0_i6);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(8) = MR_r4;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r4 = MR_stackvar(8);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r2 = MR_float_to_word((MR_word_to_float(MR_r4) / MR_word_to_float(MR_stackvar(9))));
	if ((MR_word_to_float(MR_r2) <= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i11);
	}
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cylinder_intersections_4_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 2) = MR_stackvar(7);
	MR_r4 = MR_stackvar(5);
	MR_stackvar(5) = MR_r2;
	MR_stackvar(9) = MR_stackvar(7);
	MR_stackvar(7) = MR_r4;
	MR_stackvar(8) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_r2 = MR_r3;
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__fn__trans__point_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cylinder_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cylinder_intersections_4_0_i8);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__process_cylinder_intersections_4_0_i9,
		MR_STATIC(mercury__fn__trans__process_cylinder_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cylinder_intersections_4_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(2);
	if ((MR_word_to_float(MR_r2) <= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i11);
	}
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cylinder_intersections_4_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 2) = MR_stackvar(7);
	MR_r4 = MR_stackvar(5);
	MR_stackvar(5) = MR_r2;
	MR_stackvar(9) = MR_stackvar(7);
	MR_stackvar(7) = MR_r4;
	MR_stackvar(8) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_r2 = MR_r3;
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__fn__trans__point_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cylinder_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cylinder_intersections_4_0_i11);
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cylinder_intersections_4_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 2) = MR_stackvar(7);
	MR_r4 = MR_stackvar(5);
	MR_stackvar(5) = MR_float_to_word(((MR_Float) 1.00000000000000 + MR_word_to_float(MR_r2)));
	MR_stackvar(9) = MR_stackvar(7);
	MR_stackvar(7) = MR_r4;
	MR_stackvar(8) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_r2 = MR_r3;
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__fn__trans__point_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cylinder_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cylinder_intersections_4_0_i2);
	if (((MR_Integer) MR_stackvar(4) != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i13);
	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cylinder_intersections_4_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_stackvar(7);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(5) = MR_float_to_word((((MR_Float) 0.500000000000000 * MR_word_to_float(MR_stackvar(5))) + (MR_Float) 0.500000000000000));
	MR_stackvar(6) = MR_float_to_word((((MR_Float) 0.500000000000000 * MR_word_to_float(MR_stackvar(7))) + (MR_Float) 0.500000000000000));
	MR_stackvar(7) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_stackvar(8) = (MR_Word) &mercury_float_const_1pt00000000000000;
	MR_stackvar(9) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_r2 = MR_r4;
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__fn__trans__point_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cylinder_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cylinder_intersections_4_0_i13);
	if (((MR_Integer) MR_stackvar(4) != (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i15);
	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cylinder_intersections_4_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_stackvar(7);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(5) = MR_float_to_word((((MR_Float) 0.500000000000000 * MR_word_to_float(MR_stackvar(5))) + (MR_Float) 0.500000000000000));
	MR_stackvar(6) = MR_float_to_word((((MR_Float) 0.500000000000000 * MR_word_to_float(MR_stackvar(7))) + (MR_Float) 0.500000000000000));
	MR_stackvar(7) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_stackvar(8) = (MR_Word) &mercury_float_const_neg1pt00000000000000;
	MR_stackvar(9) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_r2 = MR_r4;
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__fn__trans__point_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cylinder_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cylinder_intersections_4_0_i15);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) MR_string_const("trans: intersects_cylinder/6: not a face!", 41);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__process_cylinder_intersections_4_0_i17,
		MR_STATIC(mercury__fn__trans__process_cylinder_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cylinder_intersections_4_0_i17);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__fn__trans__point_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0_i21),
		MR_STATIC(mercury__fn__trans__process_cylinder_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cylinder_intersections_4_0_i21);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cylinder_intersections_4_0, "trans:surface_coordinates/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_stackvar(6);
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cylinder_intersections_4_0, "vector:vector/0");
	MR_r4 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 0) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0)) * MR_word_to_float(MR_stackvar(7))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 4)) * MR_word_to_float(MR_stackvar(8)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 8)) * MR_word_to_float(MR_stackvar(9)))));
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 1) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1)) * MR_word_to_float(MR_stackvar(7))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 5)) * MR_word_to_float(MR_stackvar(8)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 9)) * MR_word_to_float(MR_stackvar(9)))));
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 2) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 2)) * MR_word_to_float(MR_stackvar(7))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 6)) * MR_word_to_float(MR_stackvar(8)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 10)) * MR_word_to_float(MR_stackvar(9)))));
	MR_stackvar(2) = MR_r1;
	MR_stackvar(4) = MR_r2;
	MR_r1 = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__fn__vector__unit_1_0),
		mercury__fn__trans__process_cylinder_intersections_4_0_i22,
		MR_STATIC(mercury__fn__trans__process_cylinder_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cylinder_intersections_4_0_i22);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__process_cylinder_intersections_4_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 5, mercury__fn__trans__process_cylinder_intersections_4_0, "trans:intersection/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_r1;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 4) = MR_stackvar(3);
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	MR_proceed();
/* code for predicate 'process_cone_intersections'/5 in mode 0 */
MR_define_static(mercury__fn__trans__process_cone_intersections_4_0);
	MR_incr_sp_push_msg(11, "trans:process_cone_intersections/5");
	MR_stackvar(11) = (MR_Word) MR_succip;
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	if (((MR_Integer) MR_stackvar(4) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cone_intersections_4_0_i2);
	}
	{
	MR_Float	Y;
	MR_Float	X;
	MR_Float	ATan2;
#define	MR_PROC_LABEL	mercury__fn__trans__process_cone_intersections_4_0
	Y = MR_word_to_float(MR_stackvar(5));
	X = MR_word_to_float(MR_stackvar(7));
{
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	ATan2 = atan2(Y, X);
;}
#line 7060 "trans.c"
	MR_r4 = MR_float_to_word(ATan2);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	Pi;
#define	MR_PROC_LABEL	mercury__fn__trans__process_cone_intersections_4_0
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;
;}
#line 7073 "trans.c"
	MR_r5 = MR_float_to_word(Pi);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	Pi;
#define	MR_PROC_LABEL	mercury__fn__trans__process_cone_intersections_4_0
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;
;}
#line 7086 "trans.c"
	MR_r6 = MR_float_to_word(Pi);
#undef	MR_PROC_LABEL

	}
	MR_stackvar(9) = MR_float_to_word((MR_word_to_float(MR_r5) + MR_word_to_float(MR_r6)));
	MR_stackvar(1) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__trans__process_cone_intersections_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 7104 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__process_cone_intersections_4_0_i6);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(9)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cone_intersections_4_0_i8);
	}
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(8) = MR_r4;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r4 = MR_stackvar(8);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_r4) / MR_word_to_float(MR_stackvar(9))));
	if ((MR_word_to_float(MR_r1) <= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cone_intersections_4_0_i11);
	}
	MR_stackvar(8) = MR_r1;
	MR_stackvar(9) = MR_stackvar(6);
	MR_stackvar(10) = MR_stackvar(5);
	MR_r1 = MR_float_to_word(((MR_word_to_float(MR_stackvar(5)) * MR_word_to_float(MR_stackvar(5))) + (MR_word_to_float(MR_stackvar(7)) * MR_word_to_float(MR_stackvar(7)))));
	MR_call_localret(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		mercury__fn__trans__process_cone_intersections_4_0_i13,
		MR_STATIC(mercury__fn__trans__process_cone_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cone_intersections_4_0_i6);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(8) = MR_r4;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r4 = MR_stackvar(8);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_r4) / MR_word_to_float(MR_stackvar(9))));
	if ((MR_word_to_float(MR_r1) <= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cone_intersections_4_0_i11);
	}
	MR_stackvar(8) = MR_r1;
	MR_stackvar(9) = MR_stackvar(6);
	MR_stackvar(10) = MR_stackvar(5);
	MR_r1 = MR_float_to_word(((MR_word_to_float(MR_stackvar(5)) * MR_word_to_float(MR_stackvar(5))) + (MR_word_to_float(MR_stackvar(7)) * MR_word_to_float(MR_stackvar(7)))));
	MR_call_localret(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		mercury__fn__trans__process_cone_intersections_4_0_i13,
		MR_STATIC(mercury__fn__trans__process_cone_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cone_intersections_4_0_i8);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__process_cone_intersections_4_0_i10,
		MR_STATIC(mercury__fn__trans__process_cone_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cone_intersections_4_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__process_cone_intersections_4_0));
	if ((MR_word_to_float(MR_r1) <= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cone_intersections_4_0_i11);
	}
	MR_stackvar(8) = MR_r1;
	MR_stackvar(9) = MR_stackvar(6);
	MR_stackvar(10) = MR_stackvar(5);
	MR_r1 = MR_float_to_word(((MR_word_to_float(MR_stackvar(5)) * MR_word_to_float(MR_stackvar(5))) + (MR_word_to_float(MR_stackvar(7)) * MR_word_to_float(MR_stackvar(7)))));
	MR_call_localret(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		mercury__fn__trans__process_cone_intersections_4_0_i13,
		MR_STATIC(mercury__fn__trans__process_cone_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cone_intersections_4_0_i11);
	MR_stackvar(8) = MR_float_to_word(((MR_Float) 1.00000000000000 + MR_word_to_float(MR_r1)));
	MR_stackvar(9) = MR_stackvar(6);
	MR_stackvar(10) = MR_stackvar(5);
	MR_r1 = MR_float_to_word(((MR_word_to_float(MR_stackvar(5)) * MR_word_to_float(MR_stackvar(5))) + (MR_word_to_float(MR_stackvar(7)) * MR_word_to_float(MR_stackvar(7)))));
	MR_call_localret(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		mercury__fn__trans__process_cone_intersections_4_0_i13,
		MR_STATIC(mercury__fn__trans__process_cone_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cone_intersections_4_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__process_cone_intersections_4_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cone_intersections_4_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_stackvar(7);
	MR_r3 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_stackvar(5) = MR_float_to_word(((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r3)));
	MR_stackvar(6) = MR_stackvar(7);
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__fn__trans__point_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cone_intersections_4_0_i19),
		MR_STATIC(mercury__fn__trans__process_cone_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cone_intersections_4_0_i2);
	if (((MR_Integer) MR_stackvar(4) != (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__fn__trans__process_cone_intersections_4_0_i14);
	}
	MR_tag_incr_hp_msg(MR_r4, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cone_intersections_4_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_r4, (MR_Integer) 2) = MR_stackvar(7);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(8) = MR_float_to_word((((MR_Float) 0.500000000000000 * MR_word_to_float(MR_stackvar(5))) + (MR_Float) 0.500000000000000));
	MR_stackvar(9) = MR_float_to_word((((MR_Float) 0.500000000000000 * MR_word_to_float(MR_stackvar(7))) + (MR_Float) 0.500000000000000));
	MR_stackvar(10) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_stackvar(5) = (MR_Word) &mercury_float_const_1pt00000000000000;
	MR_stackvar(6) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_r2 = MR_r4;
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__fn__trans__point_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cone_intersections_4_0_i19),
		MR_STATIC(mercury__fn__trans__process_cone_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cone_intersections_4_0_i14);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) MR_string_const("trans: intersects_cylinder/6: not a face!", 41);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__process_cone_intersections_4_0_i16,
		MR_STATIC(mercury__fn__trans__process_cone_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cone_intersections_4_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__process_cone_intersections_4_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_r1;
	MR_localcall(mercury__fn__trans__point_to_world_space_2_0,
		MR_LABEL(mercury__fn__trans__process_cone_intersections_4_0_i19),
		MR_STATIC(mercury__fn__trans__process_cone_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cone_intersections_4_0_i19);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__process_cone_intersections_4_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cone_intersections_4_0, "trans:surface_coordinates/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_stackvar(9);
	MR_tag_incr_hp_msg(MR_r3, MR_mktag(0), (MR_Integer) 3, mercury__fn__trans__process_cone_intersections_4_0, "vector:vector/0");
	MR_r4 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 0) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0)) * MR_word_to_float(MR_stackvar(10))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 4)) * MR_word_to_float(MR_stackvar(5)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 8)) * MR_word_to_float(MR_stackvar(6)))));
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 1) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1)) * MR_word_to_float(MR_stackvar(10))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 5)) * MR_word_to_float(MR_stackvar(5)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 9)) * MR_word_to_float(MR_stackvar(6)))));
	MR_field(MR_mktag(0), MR_r3, (MR_Integer) 2) = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 2)) * MR_word_to_float(MR_stackvar(10))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 6)) * MR_word_to_float(MR_stackvar(5)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 10)) * MR_word_to_float(MR_stackvar(6)))));
	MR_stackvar(2) = MR_r1;
	MR_stackvar(4) = MR_r2;
	MR_r1 = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__fn__vector__unit_1_0),
		mercury__fn__trans__process_cone_intersections_4_0_i20,
		MR_STATIC(mercury__fn__trans__process_cone_intersections_4_0));
MR_define_label(mercury__fn__trans__process_cone_intersections_4_0_i20);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__process_cone_intersections_4_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 5, mercury__fn__trans__process_cone_intersections_4_0, "trans:intersection/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_r1;
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 4) = MR_stackvar(3);
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	MR_proceed();
/* code for predicate 'cylinder_intersection'/8 in mode 0 */
MR_define_static(mercury__fn__trans__cylinder_intersection_7_0);
	MR_r8 = MR_float_to_word(((MR_word_to_float(MR_r5) * MR_word_to_float(MR_r5)) + (MR_word_to_float(MR_r7) * MR_word_to_float(MR_r7))));
	MR_r9 = MR_float_to_word(((MR_Float) 2.00000000000000 * ((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r5)) + (MR_word_to_float(MR_r4) * MR_word_to_float(MR_r7)))));
	MR_r10 = MR_float_to_word((((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r2)) + (MR_word_to_float(MR_r4) * MR_word_to_float(MR_r4))) - (MR_Float) 1.00000000000000));
	MR_localtailcall(mercury__fn__trans__solve_quadratic_10_0,
		MR_STATIC(mercury__fn__trans__cylinder_intersection_7_0));
/* code for predicate 'cone_intersection'/8 in mode 0 */
MR_define_static(mercury__fn__trans__cone_intersection_7_0);
	MR_r8 = MR_float_to_word((((MR_word_to_float(MR_r5) * MR_word_to_float(MR_r5)) + (MR_word_to_float(MR_r7) * MR_word_to_float(MR_r7))) - (MR_word_to_float(MR_r6) * MR_word_to_float(MR_r6))));
	MR_r9 = MR_float_to_word(((MR_Float) 2.00000000000000 * (((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r5)) + (MR_word_to_float(MR_r4) * MR_word_to_float(MR_r7))) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r6)))));
	MR_r10 = MR_float_to_word((((MR_word_to_float(MR_r2) * MR_word_to_float(MR_r2)) + (MR_word_to_float(MR_r4) * MR_word_to_float(MR_r4))) - (MR_word_to_float(MR_r3) * MR_word_to_float(MR_r3))));
	MR_localtailcall(mercury__fn__trans__solve_quadratic_10_0,
		MR_STATIC(mercury__fn__trans__cone_intersection_7_0));
/* code for predicate 'solve_quadratic'/11 in mode 0 */
MR_define_static(mercury__fn__trans__solve_quadratic_10_0);
	MR_incr_sp_push_msg(13, "trans:solve_quadratic/11");
	MR_stackvar(13) = (MR_Word) MR_succip;
	MR_r11 = MR_float_to_word(((MR_word_to_float(MR_r9) * MR_word_to_float(MR_r9)) - (((MR_Float) 4.00000000000000 * MR_word_to_float(MR_r8)) * MR_word_to_float(MR_r10))));
	if ((MR_word_to_float(MR_r11) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i2);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	MR_proceed();
MR_define_label(mercury__fn__trans__solve_quadratic_10_0_i2);
	if ((MR_word_to_float(MR_r9) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i3);
	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_r5;
	MR_stackvar(6) = MR_r6;
	MR_stackvar(7) = MR_r7;
	MR_stackvar(8) = MR_r8;
	MR_stackvar(9) = MR_r9;
	MR_stackvar(10) = MR_r10;
	MR_r1 = MR_r11;
	MR_stackvar(11) = (MR_Word) &mercury_float_const_neg1pt00000000000000;
	MR_stackvar(12) = (MR_Word) &mercury_float_const_neg0pt500000000000000;
	MR_call_localret(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		mercury__fn__trans__solve_quadratic_10_0_i5,
		MR_STATIC(mercury__fn__trans__solve_quadratic_10_0));
MR_define_label(mercury__fn__trans__solve_quadratic_10_0_i3);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r4;
	MR_stackvar(5) = MR_r5;
	MR_stackvar(6) = MR_r6;
	MR_stackvar(7) = MR_r7;
	MR_stackvar(8) = MR_r8;
	MR_stackvar(9) = MR_r9;
	MR_stackvar(10) = MR_r10;
	MR_r1 = MR_r11;
	MR_stackvar(11) = (MR_Word) &mercury_float_const_1pt00000000000000;
	MR_stackvar(12) = (MR_Word) &mercury_float_const_neg0pt500000000000000;
	MR_call_localret(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		mercury__fn__trans__solve_quadratic_10_0_i5,
		MR_STATIC(mercury__fn__trans__solve_quadratic_10_0));
MR_define_label(mercury__fn__trans__solve_quadratic_10_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__solve_quadratic_10_0));
	MR_r3 = MR_float_to_word((MR_word_to_float(MR_stackvar(12)) * (MR_word_to_float(MR_stackvar(9)) + (MR_word_to_float(MR_stackvar(11)) * MR_word_to_float(MR_r1)))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__solve_quadratic_10_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 7341 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i8);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(8)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i10);
	}
	MR_stackvar(9) = MR_r3;
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_r3) / MR_word_to_float(MR_stackvar(8))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__solve_quadratic_10_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 7362 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i15);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(9)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i17);
	}
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r8 = MR_stackvar(7);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(9))));
	MR_r9 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	if ((MR_word_to_float(MR_stackvar(8)) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	MR_r10 = MR_float_to_word((MR_word_to_float(MR_r4) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r7))));
	if (((MR_Float) 0.00000000000000 > MR_word_to_float(MR_r10))) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	if ((MR_word_to_float(MR_r10) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r11, MR_mktag(0), (MR_Integer) 4, mercury__fn__trans__solve_quadratic_10_0, "trans:face_intersection/0");
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 0) = MR_r2;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r3) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 2) = MR_r10;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 3) = MR_float_to_word((MR_word_to_float(MR_r5) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r8))));
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(1), (MR_Integer) 2, mercury__fn__trans__solve_quadratic_10_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r10, (MR_Integer) 0) = MR_r11;
	MR_field(MR_mktag(1), MR_r10, (MR_Integer) 1) = MR_r9;
	MR_r9 = MR_r10;
	MR_succip = (MR_Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	MR_localtailcall(mercury__trans__maybe_add_intersection_10_0,
		MR_STATIC(mercury__fn__trans__solve_quadratic_10_0));
MR_define_label(mercury__fn__trans__solve_quadratic_10_0_i8);
	MR_stackvar(9) = MR_r3;
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_r3) / MR_word_to_float(MR_stackvar(8))));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__solve_quadratic_10_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 7416 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i15);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(9)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i17);
	}
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r8 = MR_stackvar(7);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(9))));
	MR_r9 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	if ((MR_word_to_float(MR_stackvar(8)) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	MR_r10 = MR_float_to_word((MR_word_to_float(MR_r4) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r7))));
	if (((MR_Float) 0.00000000000000 > MR_word_to_float(MR_r10))) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	if ((MR_word_to_float(MR_r10) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r11, MR_mktag(0), (MR_Integer) 4, mercury__fn__trans__solve_quadratic_10_0, "trans:face_intersection/0");
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 0) = MR_r2;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r3) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 2) = MR_r10;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 3) = MR_float_to_word((MR_word_to_float(MR_r5) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r8))));
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(1), (MR_Integer) 2, mercury__fn__trans__solve_quadratic_10_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r10, (MR_Integer) 0) = MR_r11;
	MR_field(MR_mktag(1), MR_r10, (MR_Integer) 1) = MR_r9;
	MR_r9 = MR_r10;
	MR_succip = (MR_Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	MR_localtailcall(mercury__trans__maybe_add_intersection_10_0,
		MR_STATIC(mercury__fn__trans__solve_quadratic_10_0));
MR_define_label(mercury__fn__trans__solve_quadratic_10_0_i10);
	MR_stackvar(9) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__solve_quadratic_10_0_i12,
		MR_STATIC(mercury__fn__trans__solve_quadratic_10_0));
MR_define_label(mercury__fn__trans__solve_quadratic_10_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__solve_quadratic_10_0));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__solve_quadratic_10_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 7476 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i15);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(9)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i17);
	}
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r8 = MR_stackvar(7);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(9))));
	MR_r9 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	if ((MR_word_to_float(MR_stackvar(8)) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	MR_r10 = MR_float_to_word((MR_word_to_float(MR_r4) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r7))));
	if (((MR_Float) 0.00000000000000 > MR_word_to_float(MR_r10))) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	if ((MR_word_to_float(MR_r10) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r11, MR_mktag(0), (MR_Integer) 4, mercury__fn__trans__solve_quadratic_10_0, "trans:face_intersection/0");
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 0) = MR_r2;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r3) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 2) = MR_r10;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 3) = MR_float_to_word((MR_word_to_float(MR_r5) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r8))));
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(1), (MR_Integer) 2, mercury__fn__trans__solve_quadratic_10_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r10, (MR_Integer) 0) = MR_r11;
	MR_field(MR_mktag(1), MR_r10, (MR_Integer) 1) = MR_r9;
	MR_r9 = MR_r10;
	MR_succip = (MR_Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	MR_localtailcall(mercury__trans__maybe_add_intersection_10_0,
		MR_STATIC(mercury__fn__trans__solve_quadratic_10_0));
MR_define_label(mercury__fn__trans__solve_quadratic_10_0_i15);
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r8 = MR_stackvar(7);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(10)) / MR_word_to_float(MR_stackvar(9))));
	MR_r9 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	if ((MR_word_to_float(MR_stackvar(8)) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	MR_r10 = MR_float_to_word((MR_word_to_float(MR_r4) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r7))));
	if (((MR_Float) 0.00000000000000 > MR_word_to_float(MR_r10))) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	if ((MR_word_to_float(MR_r10) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r11, MR_mktag(0), (MR_Integer) 4, mercury__fn__trans__solve_quadratic_10_0, "trans:face_intersection/0");
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 0) = MR_r2;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r3) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 2) = MR_r10;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 3) = MR_float_to_word((MR_word_to_float(MR_r5) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r8))));
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(1), (MR_Integer) 2, mercury__fn__trans__solve_quadratic_10_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r10, (MR_Integer) 0) = MR_r11;
	MR_field(MR_mktag(1), MR_r10, (MR_Integer) 1) = MR_r9;
	MR_r9 = MR_r10;
	MR_succip = (MR_Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	MR_localtailcall(mercury__trans__maybe_add_intersection_10_0,
		MR_STATIC(mercury__fn__trans__solve_quadratic_10_0));
MR_define_label(mercury__fn__trans__solve_quadratic_10_0_i17);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__solve_quadratic_10_0_i18,
		MR_STATIC(mercury__fn__trans__solve_quadratic_10_0));
MR_define_label(mercury__fn__trans__solve_quadratic_10_0_i18);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__solve_quadratic_10_0));
	MR_r9 = MR_r2;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r8 = MR_stackvar(7);
	if ((MR_word_to_float(MR_stackvar(8)) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	MR_r10 = MR_float_to_word((MR_word_to_float(MR_r4) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r7))));
	if (((MR_Float) 0.00000000000000 > MR_word_to_float(MR_r10))) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	if ((MR_word_to_float(MR_r10) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__solve_quadratic_10_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r11, MR_mktag(0), (MR_Integer) 4, mercury__fn__trans__solve_quadratic_10_0, "trans:face_intersection/0");
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 0) = MR_r2;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r3) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 2) = MR_r10;
	MR_field(MR_mktag(0), MR_r11, (MR_Integer) 3) = MR_float_to_word((MR_word_to_float(MR_r5) + (MR_word_to_float(MR_stackvar(8)) * MR_word_to_float(MR_r8))));
	MR_tag_incr_hp_msg(MR_r10, MR_mktag(1), (MR_Integer) 2, mercury__fn__trans__solve_quadratic_10_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r10, (MR_Integer) 0) = MR_r11;
	MR_field(MR_mktag(1), MR_r10, (MR_Integer) 1) = MR_r9;
	MR_r9 = MR_r10;
	MR_succip = (MR_Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	MR_localtailcall(mercury__trans__maybe_add_intersection_10_0,
		MR_STATIC(mercury__fn__trans__solve_quadratic_10_0));
MR_define_label(mercury__fn__trans__solve_quadratic_10_0_i21);
	MR_succip = (MR_Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	MR_localtailcall(mercury__trans__maybe_add_intersection_10_0,
		MR_STATIC(mercury__fn__trans__solve_quadratic_10_0));
/* code for predicate 'maybe_add_intersection'/10 in mode 0 */
MR_define_static(mercury__trans__maybe_add_intersection_10_0);
	if ((MR_word_to_float(MR_r1) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__maybe_add_intersection_10_0_i2);
	}
	MR_r10 = MR_float_to_word((MR_word_to_float(MR_r4) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_r7))));
	if (((MR_Float) 0.00000000000000 > MR_word_to_float(MR_r10))) {
		MR_GOTO_LABEL(mercury__trans__maybe_add_intersection_10_0_i2);
	}
	if ((MR_word_to_float(MR_r10) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__trans__maybe_add_intersection_10_0_i2);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 4, mercury__trans__maybe_add_intersection_10_0, "trans:face_intersection/0");
	MR_r4 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r3) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_r6))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r10;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3) = MR_float_to_word((MR_word_to_float(MR_r5) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_r8))));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__trans__maybe_add_intersection_10_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_r9;
	MR_proceed();
	}
MR_define_label(mercury__trans__maybe_add_intersection_10_0_i2);
	MR_r1 = MR_r9;
	MR_proceed();
/* code for predicate 'disc_intersection'/9 in mode 0 */
MR_define_static(mercury__fn__trans__disc_intersection_8_0);
	MR_incr_sp_push_msg(9, "trans:disc_intersection/9");
	MR_stackvar(9) = (MR_Word) MR_succip;
	if ((MR_word_to_float(MR_r7) != (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__disc_intersection_8_0_i2);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__disc_intersection_8_0_i2);
	MR_stackvar(8) = MR_float_to_word((MR_word_to_float(MR_r2) - MR_word_to_float(MR_r4)));
	MR_stackvar(1) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__trans__disc_intersection_8_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 7646 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__disc_intersection_8_0_i6);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_r7) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__disc_intersection_8_0_i8);
	}
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(6) = MR_r7;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r8 = MR_stackvar(7);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_r7)));
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__disc_intersection_8_0_i11);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__disc_intersection_8_0_i6);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(6) = MR_r7;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r5 = MR_stackvar(4);
	MR_r6 = MR_stackvar(5);
	MR_r7 = MR_stackvar(6);
	MR_r8 = MR_stackvar(7);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(7) = MR_r8;
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(8)) / MR_word_to_float(MR_r7)));
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__disc_intersection_8_0_i11);
	}
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__disc_intersection_8_0_i8);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(4) = MR_r5;
	MR_stackvar(5) = MR_r6;
	MR_stackvar(7) = MR_r8;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__disc_intersection_8_0_i10,
		MR_STATIC(mercury__fn__trans__disc_intersection_8_0));
MR_define_label(mercury__fn__trans__disc_intersection_8_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__disc_intersection_8_0));
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__disc_intersection_8_0_i11);
	}
MR_define_label(mercury__fn__trans__disc_intersection_8_0_i21);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury__fn__trans__disc_intersection_8_0_i11);
	MR_r2 = MR_float_to_word((((MR_word_to_float(MR_stackvar(3)) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_stackvar(5)))) * (MR_word_to_float(MR_stackvar(3)) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_stackvar(5))))) + ((MR_word_to_float(MR_stackvar(4)) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_stackvar(7)))) * (MR_word_to_float(MR_stackvar(4)) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_stackvar(7)))))));
	if ((MR_word_to_float(MR_r2) > (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__disc_intersection_8_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 4, mercury__fn__trans__disc_intersection_8_0, "trans:face_intersection/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_stackvar(5)))));
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 3) = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) + (MR_word_to_float(MR_r1) * MR_word_to_float(MR_stackvar(7)))));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__fn__trans__disc_intersection_8_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_r2;
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
/* code for predicate 'calc_u'/3 in mode 0 */
MR_define_static(mercury__fn__trans__calc_u_2_0);
	{
	MR_Float	Y;
	MR_Float	X;
	MR_Float	ATan2;
#define	MR_PROC_LABEL	mercury__fn__trans__calc_u_2_0
	Y = MR_word_to_float(MR_r1);
	X = MR_word_to_float(MR_r2);
{
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	ATan2 = atan2(Y, X);
;}
#line 7760 "trans.c"
	MR_r3 = MR_float_to_word(ATan2);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	Pi;
#define	MR_PROC_LABEL	mercury__fn__trans__calc_u_2_0
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;
;}
#line 7773 "trans.c"
	MR_r4 = MR_float_to_word(Pi);
#undef	MR_PROC_LABEL

	}
	{
	MR_Float	Pi;
#define	MR_PROC_LABEL	mercury__fn__trans__calc_u_2_0
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;
;}
#line 7786 "trans.c"
	MR_r5 = MR_float_to_word(Pi);
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(3, "trans:calc_u/3");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(2) = MR_float_to_word((MR_word_to_float(MR_r4) + MR_word_to_float(MR_r5)));
	{
#define	MR_PROC_LABEL	mercury__fn__trans__calc_u_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 7805 "trans.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__trans__calc_u_2_0_i4);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__calc_u_2_0_i6);
	}
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_r3) / MR_word_to_float(MR_stackvar(2))));
	if ((MR_word_to_float(MR_r1) <= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__calc_u_2_0_i9);
	}
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__fn__trans__calc_u_2_0_i4);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_r3) / MR_word_to_float(MR_stackvar(2))));
	if ((MR_word_to_float(MR_r1) <= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__calc_u_2_0_i9);
	}
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__fn__trans__calc_u_2_0_i6);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__trans__calc_u_2_0_i8,
		MR_STATIC(mercury__fn__trans__calc_u_2_0));
MR_define_label(mercury__fn__trans__calc_u_2_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__trans__calc_u_2_0));
	if ((MR_word_to_float(MR_r1) > (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__trans__calc_u_2_0_i10);
	}
MR_define_label(mercury__fn__trans__calc_u_2_0_i9);
	MR_r1 = MR_float_to_word(((MR_Float) 1.00000000000000 + MR_word_to_float(MR_r1)));
MR_define_label(mercury__fn__trans__calc_u_2_0_i10);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___trans__surface_coordinates_0_0);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury____Unify___trans__surface_coordinates_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__surface_coordinates_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r1));
	MR_proceed();
	}
MR_define_label(mercury____Unify___trans__surface_coordinates_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___trans__surface_coordinates_0_0);
	MR_incr_sp_push_msg(4, "trans:__Compare__/3");
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if (((MR_Integer) MR_r2 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___trans__surface_coordinates_0_0_i4);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__surface_coordinates_0_0_i3);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___trans__surface_coordinates_0_0_i4);
	if ((MR_r2 == MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___trans__surface_coordinates_0_0_i3);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__surface_coordinates_0_0_i3);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___trans__surface_coordinates_0_0_i3);
	if ((MR_word_to_float(MR_stackvar(1)) >= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__surface_coordinates_0_0_i16);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__surface_coordinates_0_0_i15);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___trans__surface_coordinates_0_0_i16);
	if ((MR_word_to_float(MR_stackvar(1)) <= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__surface_coordinates_0_0_i15);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__surface_coordinates_0_0_i15);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___trans__surface_coordinates_0_0_i15);
	if ((MR_word_to_float(MR_stackvar(2)) >= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__surface_coordinates_0_0_i26);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___trans__surface_coordinates_0_0_i26);
	if ((MR_word_to_float(MR_stackvar(2)) <= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__surface_coordinates_0_0_i27);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___trans__surface_coordinates_0_0_i27);
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___trans__trans_0_0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	MR_r6 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 1);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 2);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 2);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 3);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 3);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 4);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 4);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 5);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 5);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 6);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 6);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 7);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 7);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 8);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 8);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 9);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 9);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 10);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 10);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 11);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 11);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_r4 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	MR_r5 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_r1))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 1);
	if ((MR_word_to_float(MR_r1) != MR_word_to_float(MR_tempr1))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 2);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 2);
	if ((MR_word_to_float(MR_r1) != MR_word_to_float(MR_tempr1))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 3);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 3);
	if ((MR_word_to_float(MR_r1) != MR_word_to_float(MR_tempr1))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 4);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 4);
	if ((MR_word_to_float(MR_r1) != MR_word_to_float(MR_tempr1))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 5);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 5);
	if ((MR_word_to_float(MR_r1) != MR_word_to_float(MR_tempr1))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 6);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 6);
	if ((MR_word_to_float(MR_r1) != MR_word_to_float(MR_tempr1))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 7);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 7);
	if ((MR_word_to_float(MR_r1) != MR_word_to_float(MR_tempr1))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 8);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 8);
	if ((MR_word_to_float(MR_r1) != MR_word_to_float(MR_tempr1))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 9);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 9);
	if ((MR_word_to_float(MR_r1) != MR_word_to_float(MR_tempr1))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 10);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 10);
	if ((MR_word_to_float(MR_r1) != MR_word_to_float(MR_tempr1))) {
		MR_GOTO_LABEL(mercury____Unify___trans__trans_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 11);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 11);
	MR_r1 = (MR_word_to_float(MR_r1) == MR_word_to_float(MR_r2));
	MR_proceed();
	}
MR_define_label(mercury____Unify___trans__trans_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___trans__trans_0_0);
	MR_incr_sp_push_msg(3, "trans:__Compare__/3");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_localcall(mercury____Compare___trans__matrix_0_0,
		MR_LABEL(mercury____Compare___trans__trans_0_0_i3),
		MR_ENTRY(mercury____Compare___trans__trans_0_0));
MR_define_label(mercury____Compare___trans__trans_0_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___trans__trans_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__trans_0_0_i7);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_localtailcall(mercury____Compare___trans__matrix_0_0,
		MR_ENTRY(mercury____Compare___trans__trans_0_0));
MR_define_label(mercury____Compare___trans__trans_0_0_i7);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___trans__intersection_0_0);
	MR_incr_sp_push_msg(7, "trans:__Unify__/2");
	MR_stackvar(7) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury____Unify___trans__intersection_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	}
	MR_call_localret(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		mercury____Unify___trans__intersection_0_0_i2,
		MR_ENTRY(mercury____Unify___trans__intersection_0_0));
MR_define_label(mercury____Unify___trans__intersection_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___trans__intersection_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___trans__intersection_0_0_i1);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(4);
	MR_call_localret(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		mercury____Unify___trans__intersection_0_0_i4,
		MR_ENTRY(mercury____Unify___trans__intersection_0_0));
MR_define_label(mercury____Unify___trans__intersection_0_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___trans__intersection_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___trans__intersection_0_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 0);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury____Unify___trans__intersection_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 1);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__intersection_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 2);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 2);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__intersection_0_0_i1);
	}
	MR_r1 = MR_stackvar(3);
	MR_r2 = MR_stackvar(6);
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_tailcall(MR_ENTRY(mercury____Unify___eval__surface_0_0),
		MR_ENTRY(mercury____Unify___trans__intersection_0_0));
	}
MR_define_label(mercury____Unify___trans__intersection_0_0_i1);
	MR_r1 = FALSE;
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___trans__intersection_0_0);
	MR_incr_sp_push_msg(9, "trans:__Compare__/3");
	MR_stackvar(9) = (MR_Word) MR_succip;
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if (((MR_Integer) MR_r2 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___trans__intersection_0_0_i4);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__intersection_0_0_i3);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury____Compare___trans__intersection_0_0_i4);
	if ((MR_r2 == MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___trans__intersection_0_0_i3);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__intersection_0_0_i3);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury____Compare___trans__intersection_0_0_i3);
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(5);
	MR_call_localret(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		mercury____Compare___trans__intersection_0_0_i15,
		MR_ENTRY(mercury____Compare___trans__intersection_0_0));
MR_define_label(mercury____Compare___trans__intersection_0_0_i15);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___trans__intersection_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__intersection_0_0_i30);
	}
	MR_r1 = MR_stackvar(2);
	MR_r2 = MR_stackvar(6);
	MR_call_localret(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		mercury____Compare___trans__intersection_0_0_i19,
		MR_ENTRY(mercury____Compare___trans__intersection_0_0));
MR_define_label(mercury____Compare___trans__intersection_0_0_i19);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___trans__intersection_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__intersection_0_0_i30);
	}
	MR_r1 = MR_stackvar(3);
	MR_r2 = MR_stackvar(7);
	MR_localcall(mercury____Compare___trans__surface_coordinates_0_0,
		MR_LABEL(mercury____Compare___trans__intersection_0_0_i23),
		MR_ENTRY(mercury____Compare___trans__intersection_0_0));
MR_define_label(mercury____Compare___trans__intersection_0_0_i23);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___trans__intersection_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__intersection_0_0_i30);
	}
	MR_r1 = MR_stackvar(4);
	MR_r2 = MR_stackvar(8);
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_tailcall(MR_ENTRY(mercury____Compare___eval__surface_0_0),
		MR_ENTRY(mercury____Compare___trans__intersection_0_0));
MR_define_label(mercury____Compare___trans__intersection_0_0_i30);
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___trans__intersections_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_trans__type_ctor_info_intersection_0;
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___trans__intersections_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___trans__intersections_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_trans__type_ctor_info_intersection_0;
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___trans__intersections_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___trans__matrix_0_0);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__matrix_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__matrix_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__matrix_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__matrix_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__matrix_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 5);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 5);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__matrix_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 6);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 6);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__matrix_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 7);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 7);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__matrix_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 8);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 8);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__matrix_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 9);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 9);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__matrix_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 10);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 10);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__matrix_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 11);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 11);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r1));
	MR_proceed();
	}
MR_define_label(mercury____Unify___trans__matrix_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___trans__matrix_0_0);
	MR_incr_sp_push_msg(22, "trans:__Compare__/3");
	MR_stackvar(22) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 11);
	MR_stackvar(21) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 10);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 9);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 8);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 7);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 6);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 5);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 4);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 11);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 10);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 9);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 8);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 7);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 6);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 5);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 4);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if ((MR_word_to_float(MR_r2) >= MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i4);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i3);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i4);
	if ((MR_word_to_float(MR_r2) <= MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i3);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i3);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i3);
	if ((MR_word_to_float(MR_stackvar(1)) >= MR_word_to_float(MR_stackvar(12)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i16);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i15);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i16);
	if ((MR_word_to_float(MR_stackvar(1)) <= MR_word_to_float(MR_stackvar(12)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i15);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i15);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i15);
	if ((MR_word_to_float(MR_stackvar(2)) >= MR_word_to_float(MR_stackvar(13)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i28);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i27);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i28);
	if ((MR_word_to_float(MR_stackvar(2)) <= MR_word_to_float(MR_stackvar(13)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i27);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i27);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i27);
	if ((MR_word_to_float(MR_stackvar(3)) >= MR_word_to_float(MR_stackvar(14)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i40);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i39);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i40);
	if ((MR_word_to_float(MR_stackvar(3)) <= MR_word_to_float(MR_stackvar(14)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i39);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i39);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i39);
	if ((MR_word_to_float(MR_stackvar(4)) >= MR_word_to_float(MR_stackvar(15)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i52);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i51);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i52);
	if ((MR_word_to_float(MR_stackvar(4)) <= MR_word_to_float(MR_stackvar(15)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i51);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i51);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i51);
	if ((MR_word_to_float(MR_stackvar(5)) >= MR_word_to_float(MR_stackvar(16)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i64);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i63);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i64);
	if ((MR_word_to_float(MR_stackvar(5)) <= MR_word_to_float(MR_stackvar(16)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i63);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i63);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i63);
	if ((MR_word_to_float(MR_stackvar(6)) >= MR_word_to_float(MR_stackvar(17)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i76);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i75);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i76);
	if ((MR_word_to_float(MR_stackvar(6)) <= MR_word_to_float(MR_stackvar(17)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i75);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i75);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i75);
	if ((MR_word_to_float(MR_stackvar(7)) >= MR_word_to_float(MR_stackvar(18)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i88);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i87);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i88);
	if ((MR_word_to_float(MR_stackvar(7)) <= MR_word_to_float(MR_stackvar(18)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i87);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i87);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i87);
	if ((MR_word_to_float(MR_stackvar(8)) >= MR_word_to_float(MR_stackvar(19)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i100);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i99);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i100);
	if ((MR_word_to_float(MR_stackvar(8)) <= MR_word_to_float(MR_stackvar(19)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i99);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i99);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i99);
	if ((MR_word_to_float(MR_stackvar(9)) >= MR_word_to_float(MR_stackvar(20)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i112);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i111);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i112);
	if ((MR_word_to_float(MR_stackvar(9)) <= MR_word_to_float(MR_stackvar(20)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i111);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i111);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i111);
	if ((MR_word_to_float(MR_stackvar(10)) >= MR_word_to_float(MR_stackvar(21)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i124);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i123);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i124);
	if ((MR_word_to_float(MR_stackvar(10)) <= MR_word_to_float(MR_stackvar(21)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i123);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i123);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i123);
	if ((MR_word_to_float(MR_stackvar(11)) >= MR_word_to_float(MR_stackvar(22)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i134);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i134);
	if ((MR_word_to_float(MR_stackvar(11)) <= MR_word_to_float(MR_stackvar(22)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__matrix_0_0_i135);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
MR_define_label(mercury____Compare___trans__matrix_0_0_i135);
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_pop_msg(22);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___trans__face_intersection_0_0);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury____Unify___trans__face_intersection_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__face_intersection_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___trans__face_intersection_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r1));
	MR_proceed();
	}
MR_define_label(mercury____Unify___trans__face_intersection_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___trans__face_intersection_0_0);
	MR_incr_sp_push_msg(6, "trans:__Compare__/3");
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if (((MR_Integer) MR_r2 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i4);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i3);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury____Compare___trans__face_intersection_0_0_i4);
	if ((MR_r2 == MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i3);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i3);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury____Compare___trans__face_intersection_0_0_i3);
	if ((MR_word_to_float(MR_stackvar(1)) >= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i16);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i15);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury____Compare___trans__face_intersection_0_0_i16);
	if ((MR_word_to_float(MR_stackvar(1)) <= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i15);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i15);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury____Compare___trans__face_intersection_0_0_i15);
	if ((MR_word_to_float(MR_stackvar(2)) >= MR_word_to_float(MR_stackvar(5)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i28);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i27);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury____Compare___trans__face_intersection_0_0_i28);
	if ((MR_word_to_float(MR_stackvar(2)) <= MR_word_to_float(MR_stackvar(5)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i27);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i27);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury____Compare___trans__face_intersection_0_0_i27);
	if ((MR_word_to_float(MR_stackvar(3)) >= MR_word_to_float(MR_stackvar(6)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i38);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury____Compare___trans__face_intersection_0_0_i38);
	if ((MR_word_to_float(MR_stackvar(3)) <= MR_word_to_float(MR_stackvar(6)))) {
		MR_GOTO_LABEL(mercury____Compare___trans__face_intersection_0_0_i39);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury____Compare___trans__face_intersection_0_0_i39);
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_pop_msg(6);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___trans__face_intersections_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_trans__type_ctor_info_face_intersection_0;
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___trans__face_intersections_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___trans__face_intersections_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_trans__type_ctor_info_face_intersection_0;
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___trans__face_intersections_0_0));
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__trans_maybe_bunch_0(void)
{
	trans_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__trans__init(void);
void mercury__trans__init_type_tables(void);
void mercury__trans__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__trans__write_out_proc_statics(FILE *fp);
#endif

void mercury__trans__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__trans_maybe_bunch_0();
#endif

	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trans__type_ctor_info_trans_0,
		trans__trans_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trans__type_ctor_info_surface_coordinates_0,
		trans__surface_coordinates_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trans__type_ctor_info_matrix_0,
		trans__matrix_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trans__type_ctor_info_intersections_0,
		trans__intersections_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trans__type_ctor_info_intersection_0,
		trans__intersection_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trans__type_ctor_info_face_intersections_0,
		trans__face_intersections_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trans__type_ctor_info_face_intersection_0,
		trans__face_intersection_0_0);
	mercury__trans__init_debugger();
}

void mercury__trans__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
	MR_register_type_ctor_info(
		&mercury_data_trans__type_ctor_info_trans_0);
	MR_register_type_ctor_info(
		&mercury_data_trans__type_ctor_info_surface_coordinates_0);
	MR_register_type_ctor_info(
		&mercury_data_trans__type_ctor_info_matrix_0);
	MR_register_type_ctor_info(
		&mercury_data_trans__type_ctor_info_intersections_0);
	MR_register_type_ctor_info(
		&mercury_data_trans__type_ctor_info_intersection_0);
	MR_register_type_ctor_info(
		&mercury_data_trans__type_ctor_info_face_intersections_0);
	MR_register_type_ctor_info(
		&mercury_data_trans__type_ctor_info_face_intersection_0);
}


void mercury__trans__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__trans__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
