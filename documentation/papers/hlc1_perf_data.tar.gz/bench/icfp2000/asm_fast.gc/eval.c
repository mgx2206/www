/*
** Automatically generated from `eval.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__eval__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "eval.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "eval.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#include <string.h>
#include <stdio.h>

#include "mercury_string.h"	/* for MR_allocate_aligned_string*() etc. */
#include "mercury_tags.h"	/* for MR_list_cons*() */

#line 41 "eval.c"
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#ifdef USE_GCC_GLOBAL_REGISTERS
	/*
	** GNU C version egcs-1.1.2 crashes with `fixed or forbidden
	** register spilled' in grade asm_fast.gc.tr.debug
	** if we write this inline.
	*/
	static void MR_set_char(MR_String str, MR_Integer ind, MR_Char ch)
	{
		str[ind] = ch;
	}
#else
	#define MR_set_char(str, ind, ch) \
		((str)[ind] = (ch))
#endif

#line 59 "eval.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_DETERMINISM_GUARD
#define ML_DETERMINISM_GUARD
	/*
	** The enumeration constants in this enum must be in the same
	** order as the functors in the Mercury type `determinism'
	** defined above.
	*/
	typedef enum {
		ML_DET,
		ML_SEMIDET,
		ML_CC_MULTI,
		ML_CC_NONDET,
		ML_MULTI,
		ML_NONDET,
		ML_ERRONEOUS,
		ML_FAILURE
	} ML_Determinism;
#endif

#line 82 "eval.c"
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* protect against multiple inclusion */
#ifndef MR_HLC_EXCEPTION_GUARD
#define MR_HLC_EXCEPTION_GUARD

#ifdef MR_HIGHLEVEL_CODE

  #ifdef MR_USE_GCC_NESTED_FUNCTIONS
  	#define MR_CONT_PARAMS		MR_NestedCont cont
  	#define MR_CONT_PARAM_TYPES	MR_NestedCont
  	#define MR_CONT_ARGS		cont
  #else
  	#define MR_CONT_PARAMS		MR_Cont cont, void *cont_env
  	#define MR_CONT_PARAM_TYPES	MR_Cont, void *
  	#define MR_CONT_ARGS		cont, cont_env
  #endif

	/* det */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_0(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* semidet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_1(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_2(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_nondet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_3(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_4(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

	/* nondet */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_5(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

  #ifndef MR_AVOID_MACROS

	/* det ==> model_det */
	#define mercury__exception__builtin_catch_3_p_0 		mercury__exception__builtin_catch_model_det

	/* semidet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_1 		mercury__exception__builtin_catch_model_semi

	/* cc_multi ==> model_det */
	#define mercury__exception__builtin_catch_3_p_2 		mercury__exception__builtin_catch_model_det

	/* cc_nondet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_3 		mercury__exception__builtin_catch_model_semi

	/* multi ==> model_non */
	#define mercury__exception__builtin_catch_3_p_4 		mercury__exception__builtin_catch_model_non

	/* nondet ==> model_non */
	#define mercury__exception__builtin_catch_3_p_5 		mercury__exception__builtin_catch_model_non

  #endif /* !MR_AVOID_MACROS */

	void MR_CALL mercury__exception__builtin_throw_1_p_0(MR_Univ exception);

	void MR_CALL mercury__exception__builtin_catch_model_det(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	bool MR_CALL mercury__exception__builtin_catch_model_semi(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	void MR_CALL mercury__exception__builtin_catch_model_non(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

#endif /* MR_HIGHLEVEL_CODE */

#endif /* MR_HLC_EXCEPTION_GUARD */

#line 172 "eval.c"
#line 147 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

#ifndef MR_HIGHLEVEL_CODE
	#include <assert.h>
	#include <stdio.h>
	#include "mercury_deep_copy.h"
	#include "mercury_trace_base.h"
	#include "mercury_stack_trace.h"
	#include "mercury_layout_util.h"
	#include "mercury_deep_profiling_hand.h"

	MR_DECLARE_TYPE_CTOR_INFO_STRUCT( 			mercury_data_std_util__type_ctor_info_univ_0);
#endif

#line 187 "eval.c"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#include <float.h>
	#include <math.h>


#line 195 "eval.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#define	ML_FLOAT_RADIX	FLT_RADIX	/* There is no DBL_RADIX. */

	#if defined USE_SINGLE_PREC_FLOAT
		#define	ML_FLOAT_MAX		FLT_MAX
		#define	ML_FLOAT_MIN		FLT_MIN
		#define	ML_FLOAT_EPSILON	FLT_EPSILON
		#define	ML_FLOAT_MANT_DIG	FLT_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	FLT_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	FLT_MAX_EXP
	#else
		#define	ML_FLOAT_MAX		DBL_MAX
		#define	ML_FLOAT_MIN		DBL_MIN
		#define	ML_FLOAT_EPSILON	DBL_EPSILON
		#define	ML_FLOAT_MANT_DIG	DBL_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	DBL_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	DBL_MAX_EXP
	#endif


#line 218 "eval.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 225 "eval.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


#include "mercury_deep_copy.h"

#ifdef CONSERVATIVE_GC
  /* for conservative GC, shallow copies suffice */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		NewVal = OldVal;					\
	} while (0)
#else
  /*
  ** Note that we need to save/restore the MR_hp register, if it
  ** is transient, before/after calling MR_deep_copy().
  */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		MR_save_transient_hp();					\
		NewVal = MR_deep_copy(&OldVal, (MR_TypeInfo) TypeInfo_for_T,\
				(const MR_Word *) SolutionsHeapPtr,	\
				MR_ENGINE(MR_eng_solutions_heap_zone)->top);\
		MR_restore_transient_hp();				\
	} while (0)
#endif


#line 255 "eval.c"
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"

#include "mercury_heap.h"	/* for MR_incr_hp_msg() etc. */
#include "mercury_misc.h"	/* for MR_fatal_error() */
#include "mercury_string.h"	/* for MR_make_aligned_string() */

#line 262 "eval.c"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_TYPECTORDESC_GUARD
#define ML_TYPECTORDESC_GUARD

/*
** Values of type `std_util:type_desc' are represented the same way as
** values of type `private_builtin:type_info' (this representation is
** documented in compiler/polymorphism.m). Some parts of the library
** (e.g. the gc initialization code) depend on this.
** The C type corresponding to these Mercury types is `MR_TypeInfo'.
**
** Values of type `std_util:type_ctor_desc' are not guaranteed to be
** represented the same way as values of type `private_builtin:type_ctor_info'.
** The representations *are* in fact identical for first order types, but they
** differ for higher order and tuple types. Instead of a type_ctor_desc
** being a structure containing a pointer to the type_ctor_info for pred/0
** or func/0 and an arity, we have a single small encoded integer. This
** integer is four times the arity, plus zero, one or two; plus zero encodes a
** tuple, plus one encodes a predicate, plus two encodes a function.
** The maximum arity that can be encoded is given by MR_MAX_VARIABLE_ARITY
** (see below).
** The C type corresponding to std_util:type_ctor_desc is `MR_TypeCtorDesc'.
*/

/*
** Declare the MR_TypeCtorDesc ADT.
**
** Note that `struct MR_TypeCtorDesc_Struct' is deliberately left undefined.
** MR_TypeCtorDesc is declared as a pointer to a dummy structure only
** in order to allow the C compiler to catch errors in which things other
** than MR_TypeCtorDescs are given as arguments to macros that depend on their
** arguments being MR_TypeCtorDescs. The actual value is either a small integer
** or a pointer to a MR_TypeCtorInfo_Struct structure, as described above.
*/
typedef struct MR_TypeCtorDesc_Struct *MR_TypeCtorDesc;

/*
** The maximum arity that can be encoded should be set to twice the maximum
** number of general purpose registers, since an predicate or function having
** more arguments that this would run out of registers when passing the input
** arguments, or the output arguments, or both.
**
** XXX When tuples were added this was reduced to be the maximum number
** of general purpose registers, to reduce the probability that the
** `small' integers for higher-order and tuple types are confused with
** type_ctor_info pointers. This still allows higher-order terms with
** 1024 arguments, which is more than ../LIMITATIONS promises.
*/
#define MR_MAX_VARIABLE_ARITY         MR_MAX_VIRTUAL_REG

/*
** Constructors for the MR_TypeCtorDesc ADT
*/

#define MR_TYPECTOR_DESC_MAKE_PRED(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4) )
#define MR_TYPECTOR_DESC_MAKE_FUNC(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4 + 1) )
#define MR_TYPECTOR_DESC_MAKE_TUPLE(Arity)                                      ( (MR_TypeCtorDesc) ((Arity) * 4 + 2) )
#define MR_TYPECTOR_DESC_MAKE_FIXED_ARITY(type_ctor_info)                       ( MR_CHECK_EXPR_TYPE(type_ctor_info, MR_TypeCtorInfo),                    (MR_TypeCtorDesc) type_ctor_info )

/*
** Access macros for the MR_TypeCtor ADT.
**
** The MR_TYPECTOR_DESC_GET_VA_* macros should only be called if
** MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns true.
** The MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO() macro
** should only be called if MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns false.
*/
#define MR_TYPECTOR_DESC_IS_VARIABLE_ARITY(T)                                   ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) <= (4 * MR_MAX_VARIABLE_ARITY + 2) )
#define MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO(T)                      ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_TypeCtorInfo) (T) )
#define MR_TYPECTOR_DESC_GET_VA_ARITY(T)                                        ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) / 4 )
#define MR_TYPECTOR_DESC_GET_VA_NAME(T)                                         ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) (((MR_Unsigned) (T) % 4 == 0)                                ? "pred"                                                              : (((MR_Unsigned) (T) % 4 == 1)                                             ? "func"                                                              : "{}" )) )
#define MR_TYPECTOR_DESC_GET_VA_MODULE_NAME(T)                                  ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) "builtin" )
#define MR_TYPECTOR_DESC_GET_VA_TYPE_CTOR_INFO(T)                               ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 ((MR_Unsigned) (T) % 4 == 0)                                                  ? MR_TYPE_CTOR_INFO_HO_PRED                                             : (((MR_Unsigned) (T) % 4 == 1)                                            ? MR_TYPE_CTOR_INFO_HO_FUNC                                             : MR_TYPE_CTOR_INFO_TUPLE ) )

#endif /* ML_TYPECTORDESC_GUARD */


#line 343 "eval.c"
#line 126 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_CONSTRUCT_INFO_GUARD
#define ML_CONSTRUCT_INFO_GUARD

typedef struct ML_Construct_Info_Struct {
    MR_ConstString          functor_name;
    MR_Integer              arity;
    const MR_PseudoTypeInfo *arg_pseudo_type_infos;
    MR_ConstString          *arg_names;
    MR_TypeCtorRep          type_ctor_rep;
    union {
        const MR_EnumFunctorDesc  *enum_functor_desc;
        const MR_NotagFunctorDesc *notag_functor_desc;
        const MR_DuFunctorDesc    *du_functor_desc;
    }                       functor_info;
} ML_Construct_Info;

#endif

extern  void            ML_type_ctor_and_args(MR_TypeInfo type_info,
                            bool collapse_equivalences,
                            MR_TypeCtorDesc *type_ctor_desc_ptr,
                            MR_Word *arg_type_info_list_ptr);
extern  int     	    ML_get_num_functors(MR_TypeInfo type_info);
extern	MR_Word		    ML_type_params_vector_to_list(int arity,
                            MR_TypeInfoParams type_params);
extern	MR_Word		    ML_arg_name_vector_to_list(int arity,
                            MR_ConstString *arg_names);
extern	MR_Word		    ML_pseudo_type_info_vector_to_type_info_list(int arity,
                            MR_TypeInfoParams type_params,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  bool    	    ML_get_functors_check_range(int functor_number,
                            MR_TypeInfo type_info,
                            ML_Construct_Info *construct_info);
extern  void    	    ML_copy_arguments_from_list_to_vector(int arity,
                            MR_Word arg_list, MR_Word term_vector);
extern  bool    	    ML_typecheck_arguments(MR_TypeInfo type_info,
                            int arity, MR_Word arg_list,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  MR_TypeInfo	    ML_make_type(int arity, MR_TypeCtorDesc type_ctor_desc,
				             MR_Word arg_type_list);

#line 389 "eval.c"
#line 170 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


extern	MR_TypeCtorDesc ML_make_type_ctor_desc(MR_TypeInfo type_info,
				MR_TypeCtorInfo type_ctor_info);


#line 397 "eval.c"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


    #include <stdio.h>
	#include "mercury_library_types.h"		/* for MR_ArrayType */

#ifdef MR_DEEP_PROFILING
    #include "mercury_deep_profiling.h"
#endif

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef	ML_EXPAND_INFO_GUARD
#define	ML_EXPAND_INFO_GUARD

typedef struct {
    int                     num_extra_args;
    MR_Word                 *arg_values;
    MR_TypeInfo             *arg_type_infos;
    bool                    can_free_arg_type_infos;
} ML_Expand_Args_Fields;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
} ML_Expand_Functor_Args_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
    bool                    limit_reached;
} ML_Expand_Functor_Args_Limit_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor_only;
} ML_Expand_Functor_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    ML_Expand_Args_Fields   args_only;
} ML_Expand_Args_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    bool                    chosen_index_exists;
    MR_Word                 *chosen_value_ptr;
    MR_TypeInfo             chosen_type_info;
} ML_Expand_Chosen_Arg_Only_Info;

    /* Prototypes */

extern  void    ML_expand_functor_args(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Args_Info *expand_info);

extern  void    ML_expand_functor_args_limit(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int max_arity,
                    ML_Expand_Functor_Args_Limit_Info *expand_info);

extern  void    ML_expand_functor_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Only_Info *expand_info);

extern  void    ML_expand_args_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Args_Only_Info *expand_info);

extern  void    ML_expand_chosen_arg_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int chosen,
                    ML_Expand_Chosen_Arg_Only_Info *expand_info);

    /*
    ** NB. ML_arg() is also used by arg_ref and new_arg_ref
    ** in store.m, in trace/mercury_trace_vars.m, and in
    ** extras/trailed_update/tr_store.m.
    */
extern  bool    ML_arg(MR_TypeInfo type_info, MR_Word *term, int arg_index,
                    MR_TypeInfo *arg_type_info_ptr, MR_Word **argument_ptr);

    /*
    ** NB. ML_named_arg_num() is used in mercury_trace_vars.c.
    */
extern  bool    ML_named_arg_num(MR_TypeInfo type_info, MR_Word *term_ptr,
                    const char *arg_name, int *arg_num_ptr);

/*
** The following macros factor out the common parts of the various
** deconstruction predicates.
*/

    /*
    ** Check for attempts to deconstruct a non-canonical type.
    ** Such deconstructions must be cc_multi, which is why we treat
    ** violations of this as runtime errors in det deconstruction
    ** predicates.
    ** (There ought to be cc_multi versions of those predicates.)
    */
#define ML_abort_if_type_is_noncanonical(ei, predname)                  do {                                                                    if ((ei).non_canonical_type) {                                          MR_fatal_error("called " predname " for a type "                    "with a user-defined equality predicate");                }                                                               } while (0)

#endif

#define ML_deconstruct_get_functor(ei, functor_field, var)              do {                                                                    MR_make_aligned_string(MR_LVALUE_CAST(MR_ConstString, var),             (ei).functor_field);                                        } while (0)

#define ML_deconstruct_get_arity(ei, var)                               do {                                                                    var = (ei).arity;                                               } while (0)

#define ML_deconstruct_get_arg_list(ei, args_field, var)                do {                                                                    int     i;                                                                                                                              var = MR_list_empty_msg(MR_PROC_LABEL);                             i = (ei).arity;                                                                                                                         while (--i >= 0) {                                                      MR_Word arg;                                                                                                                                /* Create an argument on the heap */                            MR_new_univ_on_hp(arg,                                                  (ei).args_field.arg_type_infos[i],                                  (ei).args_field.arg_values[i +                                          (ei).args_field.num_extra_args]);                                                                                                   /* Join the argument to the front of the list */                var = MR_list_cons_msg(arg, var, MR_PROC_LABEL);                }                                                               } while (0)

    /*
    ** Free any arg_type_infos allocated by the ML_expand variant.
    ** Should be called after we have used them for the last time.
    */
#define ML_deconstruct_free_allocated_arg_type_infos(ei, args_field)    do {                                                                    if ((ei).args_field.can_free_arg_type_infos) {                          MR_GC_free((ei).args_field.arg_type_infos);                     }                                                               } while (0)


#line 519 "eval.c"
#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	extern MR_Word		ML_io_stream_names;
	extern MR_Word		ML_io_user_globals;
	#if 0
	  extern MR_Word	ML_io_ops_table;
	#endif

#line 528 "eval.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
#ifdef HAVE_SYS_STAT_H
	#include <sys/stat.h>
#endif

#line 538 "eval.c"
#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include "mercury_init.h"
#include "mercury_wrapper.h"
#include "mercury_type_info.h"
#include "mercury_library_types.h"
#include "mercury_file.h"
#include "mercury_heap.h"
#include "mercury_misc.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

#ifdef HAVE_SYS_WAIT
  #include <sys/wait.h>		/* for WIFEXITED, WEXITSTATUS, etc. */
#endif

extern MercuryFile mercury_stdin;
extern MercuryFile mercury_stdout;
extern MercuryFile mercury_stderr;
extern MercuryFile mercury_stdin_binary;
extern MercuryFile mercury_stdout_binary;
extern MercuryFile *mercury_current_text_input;
extern MercuryFile *mercury_current_text_output;
extern MercuryFile *mercury_current_binary_input;
extern MercuryFile *mercury_current_binary_output;

#define initial_io_state()		0	/* some random number */
#define update_io(r_src, r_dest)	((r_dest) = (r_src))
#define final_io_state(r)		((void)0)

void 		mercury_init_io(void);
MercuryFile*	mercury_open(const char *filename, const char *type);
void		mercury_io_error(MercuryFile* mf, const char *format, ...);
void		mercury_output_error(MercuryFile* mf);
void		mercury_print_string(MercuryFile* mf, const char *s);
void		mercury_print_binary_string(MercuryFile* mf, const char *s);
int		mercury_getc(MercuryFile* mf);
void		mercury_close(MercuryFile* mf);
int		ML_fprintf(MercuryFile* mf, const char *format, ...);

#line 584 "eval.c"
#line 106 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <fcntl.h>

	#define	MAX_TEMPNAME_TRIES	(6 * 4)

	extern long ML_io_tempnam_counter;

#line 598 "eval.c"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include <string.h>
#include <errno.h>

/*
** ML_maybe_make_err_msg(was_error, msg, procname, error_msg):
**	if `was_error' is true, then append `msg' and `strerror(errno)'
**	to give `error_msg'; otherwise, set `error_msg' to NULL.
**
** WARNING: this must only be called when the `hp' register is valid.
** That means it must only be called from procedures declared
** `will_not_call_mercury'.
**
** This is defined as a macro rather than a C function
** to avoid worrying about the `hp' register being
** invalidated by the function call.
** It also needs to be a macro because MR_incr_hp_atomic_msg()
** stringizes the procname argument.
*/
#define ML_maybe_make_err_msg(was_error, msg, procname, error_msg)	\
	do {								\
		char *errno_msg;					\
		size_t total_len;					\
		MR_Word tmp;						\
									\
		if (was_error) {					\
			errno_msg = strerror(errno);			\
			total_len = strlen(msg) + strlen(errno_msg);	\
			MR_incr_hp_atomic_msg(tmp,			\
				(total_len + sizeof(MR_Word))		\
					/ sizeof(MR_Word),		\
				procname,				\
				"string:string/0");			\
			(error_msg) = (char *)tmp;			\
			strcpy((error_msg), msg);			\
			strcat((error_msg), errno_msg);			\
		} else {						\
			(error_msg) = NULL;				\
		}							\
	} while(0)


#line 643 "eval.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

#ifdef MR_HIGHLEVEL_CODE
  bool MR_CALL mercury__array__do_unify__array_1_0(
  	MR_Mercury_Type_Info type_info, MR_Box x, MR_Box y);
  bool MR_CALL mercury__array____Unify____array_1_0(
	MR_Mercury_Type_Info type_info, MR_Array x, MR_Array y);
  void MR_CALL mercury__array__do_compare__array_1_0(MR_Mercury_Type_Info
 	 type_info, MR_Comparison_Result *result, MR_Box x, MR_Box y);
  void MR_CALL mercury__array____Compare____array_1_0(MR_Mercury_Type_Info
	type_info, MR_Comparison_Result *result, MR_Array x, MR_Array y);
#endif

#line 657 "eval.c"
#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

#include "mercury_heap.h"		/* for MR_maybe_record_allocation() */
#include "mercury_library_types.h"	/* for MR_ArrayType */

#line 663 "eval.c"
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType *ML_make_array(MR_Integer size, MR_Word item);

#line 668 "eval.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType * ML_resize_array(MR_ArrayType *old_array,
					MR_Integer array_size, MR_Word item);

#line 674 "eval.c"
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType * ML_shrink_array(MR_ArrayType *old_array,
					MR_Integer array_size);

#line 680 "eval.c"
#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"

MR_ArrayType *ML_copy_array(MR_ArrayType *old_array);

#line 685 "eval.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 688 "eval.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 694 "eval.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 702 "eval.c"


static const struct mercury_data_eval__common_0_struct {
	MR_String f1;
	MR_Word * f2;
}  mercury_data_eval__common_0;

static const struct mercury_data_eval__common_1_struct {
	MR_Integer f1;
}  mercury_data_eval__common_1;

static const struct mercury_data_eval__common_2_struct {
	MR_Integer f1;
}  mercury_data_eval__common_2;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_value_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_transformation_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_surface_properties_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_surface_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_stack_env_token_exception_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_stack_env_exception_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_stack_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_program_error_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_object_id_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_object_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_light_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_id_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_global_object_counter_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_env_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_degrees_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_color_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_code_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_basic_object_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_array_0;
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_value_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_0;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_1;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_1[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_2;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_2[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_3;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_3[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_4;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_4[];
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_18_gml__token_group_0;
#ifndef MR_FO_PseudoTypeInfo_Struct2_GUARD
#define MR_FO_PseudoTypeInfo_Struct2_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct2, 2);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct2 mercury_data_tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0;
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_5;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_5[];
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_array__type_info_array_1__type0_13_eval__value_0;
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_6;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_6[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_7;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_7[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_8;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_8[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_value_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_value_0_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_value_0_1[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_value_0_2[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_value_0_3[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_transformation_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_0;
extern const MR_ConstString mercury_data_eval__field_names_transformation_0_0[];
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_1;
extern const MR_ConstString mercury_data_eval__field_names_transformation_0_1[];
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_1[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_2;
extern const MR_ConstString mercury_data_eval__field_names_transformation_0_2[];
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_2[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_3;
extern const MR_ConstString mercury_data_eval__field_names_transformation_0_3[];
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_3[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_4;
extern const MR_ConstString mercury_data_eval__field_names_transformation_0_4[];
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_4[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_5;
extern const MR_ConstString mercury_data_eval__field_names_transformation_0_5[];
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_5[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_6;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_6[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_transformation_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_transformation_0_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_transformation_0_1[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_transformation_0_2[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_transformation_0_3[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_surface_properties_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_surface_properties_0_0;
extern const MR_ConstString mercury_data_eval__field_names_surface_properties_0_0[];
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_surface_properties_0_0[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_surface_properties_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_surface_properties_0_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_surface_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_surface_0_0;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_surface_0_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_surface_0_1;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_surface_0_1[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_surface_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_surface_0_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_surface_0_1[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_stack_env_token_exception_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_stack_env_token_exception_0_0;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_stack_env_token_exception_0_0[];
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_13_eval__value_0;
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_stack_env_token_exception_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_stack_env_token_exception_0_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_stack_env_exception_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_stack_env_exception_0_0;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_stack_env_exception_0_0[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_stack_env_exception_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_stack_env_exception_0_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_program_error_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_program_error_0_0;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_program_error_0_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_program_error_0_1;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_program_error_0_1[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_program_error_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_program_error_0_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_program_error_0_1[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_object_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_object_0_0;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_object_0_0[];
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_13_eval__light_0;
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_object_0_1;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_object_0_1[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_object_0_2;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_object_0_2[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_object_0_3;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_object_0_3[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_object_0_4;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_object_0_4[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_object_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_object_0_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_object_0_1[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_object_0_2[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_object_0_3[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_light_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_light_0_0;
extern const MR_ConstString mercury_data_eval__field_names_light_0_0[];
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_light_0_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_light_0_1;
extern const MR_ConstString mercury_data_eval__field_names_light_0_1[];
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_light_0_1[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_light_0_2;
extern const MR_ConstString mercury_data_eval__field_names_light_0_2[];
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_light_0_2[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_light_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_light_0_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_light_0_1[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_light_0_2[];
extern const MR_EnumFunctorDesc * mercury_data_eval__enum_name_ordered_global_object_counter_0[];
extern const MR_EnumFunctorDesc * mercury_data_eval__enum_value_ordered_global_object_counter_0[];
static const MR_EnumFunctorDesc mercury_data_eval__enum_functor_desc_global_object_counter_0_0;
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_basic_object_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_basic_object_0_0;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_basic_object_0_0[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_basic_object_0_1;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_basic_object_0_1[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_basic_object_0_2;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_basic_object_0_2[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_basic_object_0_3;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_basic_object_0_3[];
static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_basic_object_0_4;
extern const MR_PseudoTypeInfo mercury_data_eval__field_types_basic_object_0_4[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_basic_object_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_basic_object_0_0[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_basic_object_0_1[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_basic_object_0_2[];
extern const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_basic_object_0_3[];
MR_define_extern_entry(mercury__eval__interpret_3_0);
MR_declare_label(mercury__eval__interpret_3_0_i2);
MR_declare_label(mercury__eval__interpret_3_0_i3);
MR_define_extern_entry(mercury__eval__initial_setup_4_0);
MR_declare_label(mercury__eval__initial_setup_4_0_i2);
MR_declare_label(mercury__eval__initial_setup_4_0_i3);
MR_define_extern_entry(mercury__eval__interpret_7_0);
MR_declare_label(mercury__eval__interpret_7_0_i4);
MR_declare_label(mercury__eval__interpret_7_0_i3);
MR_define_extern_entry(mercury__fn__eval__push_2_0);
MR_define_extern_entry(mercury__eval__pop_3_0);
MR_declare_label(mercury__eval__pop_3_0_i1);
MR_define_extern_entry(mercury__eval__eval_error_2_0);
MR_declare_label(mercury__eval__eval_error_2_0_i2);
MR_define_extern_entry(mercury__eval__args_3_0);
MR_declare_static(mercury__eval__do_token_group_7_0);
MR_declare_label(mercury__eval__do_token_group_7_0_i5);
MR_declare_label(mercury__eval__do_token_group_7_0_i6);
MR_declare_label(mercury__eval__do_token_group_7_0_i7);
MR_declare_label(mercury__eval__do_token_group_7_0_i8);
MR_declare_label(mercury__eval__do_token_group_7_0_i4);
MR_declare_static(mercury__eval__do_token_7_0);
MR_declare_label(mercury__eval__do_token_7_0_i4);
MR_declare_label(mercury__eval__do_token_7_0_i6);
MR_declare_label(mercury__eval__do_token_7_0_i8);
MR_declare_label(mercury__eval__do_token_7_0_i7);
MR_declare_label(mercury__eval__do_token_7_0_i10);
MR_declare_label(mercury__eval__do_token_7_0_i13);
MR_declare_label(mercury__eval__do_token_7_0_i16);
MR_declare_label(mercury__eval__do_token_7_0_i14);
MR_declare_label(mercury__eval__do_token_7_0_i17);
MR_declare_label(mercury__eval__do_token_7_0_i19);
MR_declare_label(mercury__eval__do_token_7_0_i28);
MR_declare_label(mercury__eval__do_token_7_0_i26);
MR_declare_label(mercury__eval__do_token_7_0_i21);
MR_declare_label(mercury__eval__do_token_7_0_i23);
MR_declare_label(mercury__eval__do_token_7_0_i25);
MR_declare_label(mercury__eval__do_token_7_0_i20);
MR_declare_static(mercury__eval__do_op_6_0);
MR_declare_label(mercury__eval__do_op_6_0_i3);
MR_declare_label(mercury__eval__do_op_6_0_i7);
MR_declare_label(mercury__eval__do_op_6_0_i4);
MR_declare_label(mercury__eval__do_op_6_0_i11);
MR_declare_label(mercury__eval__do_op_6_0_i17);
MR_declare_label(mercury__eval__do_op_6_0_i12);
MR_declare_label(mercury__eval__do_op_6_0_i21);
MR_declare_label(mercury__eval__do_op_6_0_i27);
MR_declare_label(mercury__eval__do_op_6_0_i22);
MR_declare_label(mercury__eval__do_op_6_0_i31);
MR_declare_label(mercury__eval__do_op_6_0_i32);
MR_declare_label(mercury__eval__do_op_6_0_i38);
MR_declare_label(mercury__eval__do_op_6_0_i42);
MR_declare_label(mercury__eval__do_op_6_0_i39);
MR_declare_label(mercury__eval__do_op_6_0_i46);
MR_declare_label(mercury__eval__do_op_6_0_i50);
MR_declare_label(mercury__eval__do_op_6_0_i47);
MR_declare_label(mercury__eval__do_op_6_0_i54);
MR_declare_label(mercury__eval__do_op_6_0_i58);
MR_declare_label(mercury__eval__do_op_6_0_i55);
MR_declare_label(mercury__eval__do_op_6_0_i62);
MR_declare_label(mercury__eval__do_op_6_0_i66);
MR_declare_label(mercury__eval__do_op_6_0_i63);
MR_declare_label(mercury__eval__do_op_6_0_i70);
MR_declare_label(mercury__eval__do_op_6_0_i74);
MR_declare_label(mercury__eval__do_op_6_0_i71);
MR_declare_label(mercury__eval__do_op_6_0_i78);
MR_declare_label(mercury__eval__do_op_6_0_i82);
MR_declare_label(mercury__eval__do_op_6_0_i79);
MR_declare_label(mercury__eval__do_op_6_0_i86);
MR_declare_label(mercury__eval__do_op_6_0_i87);
MR_declare_label(mercury__eval__do_op_6_0_i95);
MR_declare_label(mercury__eval__do_op_6_0_i104);
MR_declare_label(mercury__eval__do_op_6_0_i97);
MR_declare_label(mercury__eval__do_op_6_0_i108);
MR_declare_label(mercury__eval__do_op_6_0_i114);
MR_declare_label(mercury__eval__do_op_6_0_i109);
MR_declare_label(mercury__eval__do_op_6_0_i118);
MR_declare_label(mercury__eval__do_op_6_0_i124);
MR_declare_label(mercury__eval__do_op_6_0_i119);
MR_declare_label(mercury__eval__do_op_6_0_i128);
MR_declare_label(mercury__eval__do_op_6_0_i134);
MR_declare_label(mercury__eval__do_op_6_0_i129);
MR_declare_label(mercury__eval__do_op_6_0_i138);
MR_declare_label(mercury__eval__do_op_6_0_i142);
MR_declare_label(mercury__eval__do_op_6_0_i139);
MR_declare_label(mercury__eval__do_op_6_0_i146);
MR_declare_label(mercury__eval__do_op_6_0_i150);
MR_declare_label(mercury__eval__do_op_6_0_i147);
MR_declare_label(mercury__eval__do_op_6_0_i154);
MR_declare_label(mercury__eval__do_op_6_0_i161);
MR_declare_label(mercury__eval__do_op_6_0_i163);
MR_declare_label(mercury__eval__do_op_6_0_i155);
MR_declare_label(mercury__eval__do_op_6_0_i156);
MR_declare_label(mercury__eval__do_op_6_0_i167);
MR_declare_label(mercury__eval__do_op_6_0_i168);
MR_declare_label(mercury__eval__do_op_6_0_i174);
MR_declare_label(mercury__eval__do_op_6_0_i175);
MR_declare_label(mercury__eval__do_op_6_0_i181);
MR_declare_label(mercury__eval__do_op_6_0_i182);
MR_declare_label(mercury__eval__do_op_6_0_i188);
MR_declare_label(mercury__eval__do_op_6_0_i197);
MR_declare_label(mercury__eval__do_op_6_0_i199);
MR_declare_label(mercury__eval__do_op_6_0_i189);
MR_declare_label(mercury__eval__do_op_6_0_i202);
MR_declare_label(mercury__eval__do_op_6_0_i203);
MR_declare_label(mercury__eval__do_op_6_0_i211);
MR_declare_label(mercury__eval__do_op_6_0_i215);
MR_declare_label(mercury__eval__do_op_6_0_i212);
MR_declare_label(mercury__eval__do_op_6_0_i219);
MR_declare_label(mercury__eval__do_op_6_0_i225);
MR_declare_label(mercury__eval__do_op_6_0_i220);
MR_declare_label(mercury__eval__do_op_6_0_i229);
MR_declare_label(mercury__eval__do_op_6_0_i235);
MR_declare_label(mercury__eval__do_op_6_0_i230);
MR_declare_label(mercury__eval__do_op_6_0_i239);
MR_declare_label(mercury__eval__do_op_6_0_i240);
MR_declare_label(mercury__eval__do_op_6_0_i248);
MR_declare_label(mercury__eval__do_op_6_0_i254);
MR_declare_label(mercury__eval__do_op_6_0_i249);
MR_declare_label(mercury__eval__do_op_6_0_i258);
MR_declare_label(mercury__eval__do_op_6_0_i264);
MR_declare_label(mercury__eval__do_op_6_0_i259);
MR_declare_label(mercury__eval__do_op_6_0_i268);
MR_declare_label(mercury__eval__do_op_6_0_i274);
MR_declare_label(mercury__eval__do_op_6_0_i269);
MR_declare_label(mercury__eval__do_op_6_0_i278);
MR_declare_label(mercury__eval__do_op_6_0_i282);
MR_declare_label(mercury__eval__do_op_6_0_i279);
MR_declare_label(mercury__eval__do_op_6_0_i286);
MR_declare_label(mercury__eval__do_op_6_0_i290);
MR_declare_label(mercury__eval__do_op_6_0_i287);
MR_declare_label(mercury__eval__do_op_6_0_i294);
MR_declare_label(mercury__eval__do_op_6_0_i298);
MR_declare_label(mercury__eval__do_op_6_0_i295);
MR_declare_label(mercury__eval__do_op_6_0_i302);
MR_declare_label(mercury__eval__do_op_6_0_i303);
MR_declare_label(mercury__eval__do_op_6_0_i313);
MR_declare_label(mercury__eval__do_op_6_0_i314);
MR_declare_label(mercury__eval__do_op_6_0_i322);
MR_declare_label(mercury__eval__do_op_6_0_i326);
MR_declare_label(mercury__eval__do_op_6_0_i323);
MR_declare_label(mercury__eval__do_op_6_0_i330);
MR_declare_label(mercury__eval__do_op_6_0_i348);
MR_declare_label(mercury__eval__do_op_6_0_i349);
MR_declare_label(mercury__eval__do_op_6_0_i350);
MR_declare_label(mercury__eval__do_op_6_0_i331);
MR_declare_label(mercury__eval__do_op_6_0_i353);
MR_declare_label(mercury__eval__do_op_6_0_i359);
MR_declare_label(mercury__eval__do_op_6_0_i354);
MR_declare_label(mercury__eval__do_op_6_0_i363);
MR_declare_label(mercury__eval__do_op_6_0_i369);
MR_declare_label(mercury__eval__do_op_6_0_i364);
MR_declare_label(mercury__eval__do_op_6_0_i373);
MR_declare_label(mercury__eval__do_op_6_0_i379);
MR_declare_label(mercury__eval__do_op_6_0_i374);
MR_declare_label(mercury__eval__do_op_6_0_i383);
MR_declare_label(mercury__eval__do_op_6_0_i393);
MR_declare_label(mercury__eval__do_op_6_0_i384);
MR_declare_label(mercury__eval__do_op_6_0_i397);
MR_declare_label(mercury__eval__do_op_6_0_i401);
MR_declare_label(mercury__eval__do_op_6_0_i398);
MR_declare_label(mercury__eval__do_op_6_0_i405);
MR_declare_label(mercury__eval__do_op_6_0_i409);
MR_declare_label(mercury__eval__do_op_6_0_i406);
MR_declare_label(mercury__eval__do_op_6_0_i413);
MR_declare_label(mercury__eval__do_op_6_0_i414);
MR_declare_label(mercury__eval__do_op_6_0_i428);
MR_declare_label(mercury__eval__do_op_6_0_i432);
MR_declare_label(mercury__eval__do_op_6_0_i429);
MR_declare_label(mercury__eval__do_op_6_0_i436);
MR_declare_label(mercury__eval__do_op_6_0_i442);
MR_declare_label(mercury__eval__do_op_6_0_i437);
MR_declare_label(mercury__eval__do_op_6_0_i446);
MR_declare_label(mercury__eval__do_op_6_0_i452);
MR_declare_label(mercury__eval__do_op_6_0_i447);
MR_declare_label(mercury__eval__do_op_6_0_i456);
MR_declare_label(mercury__eval__do_op_6_0_i466);
MR_declare_label(mercury__eval__do_op_6_0_i457);
MR_declare_label(mercury__eval__do_op_6_0_i470);
MR_declare_label(mercury__eval__do_op_6_0_i471);
MR_declare_label(mercury__eval__do_op_6_0_i479);
MR_declare_label(mercury__eval__do_op_6_0_i485);
MR_declare_label(mercury__eval__do_op_6_0_i480);
MR_declare_label(mercury__eval__do_op_6_0_i487);
MR_declare_static(mercury__eval__renameObject_4_0);
MR_declare_label(mercury__eval__renameObject_4_0_i4);
MR_declare_label(mercury__eval__renameObject_4_0_i5);
MR_declare_label(mercury__eval__renameObject_4_0_i6);
MR_declare_label(mercury__eval__renameObject_4_0_i7);
MR_declare_label(mercury__eval__renameObject_4_0_i8);
MR_declare_label(mercury__eval__renameObject_4_0_i9);
MR_declare_label(mercury__eval__renameObject_4_0_i10);
MR_declare_label(mercury__eval__renameObject_4_0_i11);
MR_declare_label(mercury__eval__renameObject_4_0_i13);
MR_declare_label(mercury__eval__renameObject_4_0_i14);
MR_declare_label(mercury__eval__renameObject_4_0_i12);
MR_declare_label(mercury__eval__renameObject_4_0_i15);
MR_declare_label(mercury__eval__renameObject_4_0_i16);
MR_declare_static(mercury__eval__next_object_id_3_0);
MR_declare_label(mercury__eval__next_object_id_3_0_i2);
MR_declare_label(mercury__eval__next_object_id_3_0_i3);
MR_declare_static(mercury__eval__extra_operator_mode_2_0);
MR_declare_static(mercury__eval__do_extra_6_0);
MR_declare_static(mercury__eval__do_extra2_6_0);
MR_declare_label(mercury__eval__do_extra2_6_0_i4);
MR_declare_label(mercury__eval__do_extra2_6_0_i5);
MR_declare_label(mercury__eval__do_extra2_6_0_i9);
MR_declare_label(mercury__eval__do_extra2_6_0_i12);
MR_declare_label(mercury__eval__do_extra2_6_0_i10);
MR_declare_label(mercury__eval__do_extra2_6_0_i16);
MR_declare_label(mercury__eval__do_extra2_6_0_i17);
MR_declare_label(mercury__eval__do_extra2_6_0_i19);
MR_declare_label(mercury__eval__do_extra2_6_0_i20);
MR_declare_label(mercury__eval__do_extra2_6_0_i21);
MR_declare_label(mercury__eval__do_extra2_6_0_i23);
MR_declare_label(mercury__eval__do_extra2_6_0_i24);
MR_declare_label(mercury__eval__do_extra2_6_0_i26);
MR_declare_label(mercury__eval__do_extra2_6_0_i27);
MR_declare_label(mercury__eval__do_extra2_6_0_i29);
MR_declare_label(mercury__eval__do_extra2_6_0_i30);
MR_declare_label(mercury__eval__do_extra2_6_0_i32);
MR_declare_label(mercury__eval__do_extra2_6_0_i34);
MR_declare_label(mercury__eval__do_extra2_6_0_i39);
MR_declare_label(mercury__eval__do_extra2_6_0_i35);
MR_declare_label(mercury__eval__do_extra2_6_0_i42);
MR_declare_label(mercury__eval__do_extra2_6_0_i44);
MR_declare_label(mercury__eval__do_extra2_6_0_i45);
MR_declare_static(mercury__eval__popn_3_0);
MR_declare_label(mercury__eval__popn_3_0_i15);
MR_declare_label(mercury__eval__popn_3_0_i6);
MR_declare_label(mercury__eval__popn_3_0_i1);
MR_declare_static(mercury__eval__empty_stack_3_0);
MR_define_extern_entry(mercury____Unify___eval__value_0_0);
MR_declare_label(mercury____Unify___eval__value_0_0_i4);
MR_declare_label(mercury____Unify___eval__value_0_0_i6);
MR_declare_label(mercury____Unify___eval__value_0_0_i8);
MR_declare_label(mercury____Unify___eval__value_0_0_i10);
MR_declare_label(mercury____Unify___eval__value_0_0_i11);
MR_declare_label(mercury____Unify___eval__value_0_0_i13);
MR_declare_label(mercury____Unify___eval__value_0_0_i15);
MR_declare_label(mercury____Unify___eval__value_0_0_i19);
MR_declare_label(mercury____Unify___eval__value_0_0_i23);
MR_declare_label(mercury____Unify___eval__value_0_0_i27);
MR_declare_label(mercury____Unify___eval__value_0_0_i31);
MR_declare_label(mercury____Unify___eval__value_0_0_i1);
MR_define_extern_entry(mercury____Index___eval__value_0_0);
MR_declare_label(mercury____Index___eval__value_0_0_i4);
MR_declare_label(mercury____Index___eval__value_0_0_i5);
MR_declare_label(mercury____Index___eval__value_0_0_i6);
MR_declare_label(mercury____Index___eval__value_0_0_i7);
MR_declare_label(mercury____Index___eval__value_0_0_i8);
MR_declare_label(mercury____Index___eval__value_0_0_i9);
MR_declare_label(mercury____Index___eval__value_0_0_i10);
MR_declare_label(mercury____Index___eval__value_0_0_i11);
MR_declare_label(mercury____Index___eval__value_0_0_i12);
MR_declare_label(mercury____Index___eval__value_0_0_i13);
MR_define_extern_entry(mercury____Compare___eval__value_0_0);
MR_declare_label(mercury____Compare___eval__value_0_0_i2);
MR_declare_label(mercury____Compare___eval__value_0_0_i3);
MR_declare_label(mercury____Compare___eval__value_0_0_i4);
MR_declare_label(mercury____Compare___eval__value_0_0_i5);
MR_declare_label(mercury____Compare___eval__value_0_0_i10);
MR_declare_label(mercury____Compare___eval__value_0_0_i12);
MR_declare_label(mercury____Compare___eval__value_0_0_i16);
MR_declare_label(mercury____Compare___eval__value_0_0_i18);
MR_declare_label(mercury____Compare___eval__value_0_0_i22);
MR_declare_label(mercury____Compare___eval__value_0_0_i24);
MR_declare_label(mercury____Compare___eval__value_0_0_i70);
MR_declare_label(mercury____Compare___eval__value_0_0_i28);
MR_declare_label(mercury____Compare___eval__value_0_0_i29);
MR_declare_label(mercury____Compare___eval__value_0_0_i31);
MR_declare_label(mercury____Compare___eval__value_0_0_i74);
MR_declare_label(mercury____Compare___eval__value_0_0_i36);
MR_declare_label(mercury____Compare___eval__value_0_0_i39);
MR_declare_label(mercury____Compare___eval__value_0_0_i44);
MR_declare_label(mercury____Compare___eval__value_0_0_i47);
MR_declare_label(mercury____Compare___eval__value_0_0_i50);
MR_declare_label(mercury____Compare___eval__value_0_0_i53);
MR_declare_label(mercury____Compare___eval__value_0_0_i7);
MR_declare_label(mercury____Compare___eval__value_0_0_i59);
MR_define_extern_entry(mercury____Unify___eval__color_0_0);
MR_define_extern_entry(mercury____Compare___eval__color_0_0);
MR_define_extern_entry(mercury____Unify___eval__array_0_0);
MR_define_extern_entry(mercury____Compare___eval__array_0_0);
MR_define_extern_entry(mercury____Unify___eval__light_0_0);
MR_declare_label(mercury____Unify___eval__light_0_0_i19);
MR_declare_label(mercury____Unify___eval__light_0_0_i10);
MR_declare_label(mercury____Unify___eval__light_0_0_i12);
MR_declare_label(mercury____Unify___eval__light_0_0_i14);
MR_declare_label(mercury____Unify___eval__light_0_0_i16);
MR_declare_label(mercury____Unify___eval__light_0_0_i4);
MR_declare_label(mercury____Unify___eval__light_0_0_i6);
MR_declare_label(mercury____Unify___eval__light_0_0_i1);
MR_define_extern_entry(mercury____Compare___eval__light_0_0);
MR_declare_label(mercury____Compare___eval__light_0_0_i57);
MR_declare_label(mercury____Compare___eval__light_0_0_i15);
MR_declare_label(mercury____Compare___eval__light_0_0_i19);
MR_declare_label(mercury____Compare___eval__light_0_0_i21);
MR_declare_label(mercury____Compare___eval__light_0_0_i25);
MR_declare_label(mercury____Compare___eval__light_0_0_i29);
MR_declare_label(mercury____Compare___eval__light_0_0_i34);
MR_declare_label(mercury____Compare___eval__light_0_0_i33);
MR_declare_label(mercury____Compare___eval__light_0_0_i76);
MR_declare_label(mercury____Compare___eval__light_0_0_i44);
MR_declare_label(mercury____Compare___eval__light_0_0_i45);
MR_declare_label(mercury____Compare___eval__light_0_0_i4);
MR_declare_label(mercury____Compare___eval__light_0_0_i79);
MR_declare_label(mercury____Compare___eval__light_0_0_i7);
MR_declare_label(mercury____Compare___eval__light_0_0_i9);
MR_declare_label(mercury____Compare___eval__light_0_0_i2);
MR_define_extern_entry(mercury____Unify___eval__degrees_0_0);
MR_define_extern_entry(mercury____Compare___eval__degrees_0_0);
MR_declare_label(mercury____Compare___eval__degrees_0_0_i2);
MR_declare_label(mercury____Compare___eval__degrees_0_0_i3);
MR_define_extern_entry(mercury____Unify___eval__object_id_0_0);
MR_define_extern_entry(mercury____Compare___eval__object_id_0_0);
MR_declare_label(mercury____Compare___eval__object_id_0_0_i2);
MR_declare_label(mercury____Compare___eval__object_id_0_0_i3);
MR_define_extern_entry(mercury____Unify___eval__object_0_0);
MR_declare_label(mercury____Unify___eval__object_0_0_i4);
MR_declare_label(mercury____Unify___eval__object_0_0_i6);
MR_declare_label(mercury____Unify___eval__object_0_0_i10);
MR_declare_label(mercury____Unify___eval__object_0_0_i12);
MR_declare_label(mercury____Unify___eval__object_0_0_i16);
MR_declare_label(mercury____Unify___eval__object_0_0_i18);
MR_declare_label(mercury____Unify___eval__object_0_0_i22);
MR_declare_label(mercury____Unify___eval__object_0_0_i25);
MR_declare_label(mercury____Unify___eval__object_0_0_i23);
MR_declare_label(mercury____Unify___eval__object_0_0_i30);
MR_declare_label(mercury____Unify___eval__object_0_0_i1);
MR_define_extern_entry(mercury____Index___eval__object_0_0);
MR_declare_label(mercury____Index___eval__object_0_0_i4);
MR_declare_label(mercury____Index___eval__object_0_0_i5);
MR_declare_label(mercury____Index___eval__object_0_0_i6);
MR_declare_label(mercury____Index___eval__object_0_0_i7);
MR_declare_label(mercury____Index___eval__object_0_0_i8);
MR_define_extern_entry(mercury____Compare___eval__object_0_0);
MR_declare_label(mercury____Compare___eval__object_0_0_i4);
MR_declare_label(mercury____Compare___eval__object_0_0_i5);
MR_declare_label(mercury____Compare___eval__object_0_0_i6);
MR_declare_label(mercury____Compare___eval__object_0_0_i7);
MR_declare_label(mercury____Compare___eval__object_0_0_i8);
MR_declare_label(mercury____Compare___eval__object_0_0_i11);
MR_declare_label(mercury____Compare___eval__object_0_0_i12);
MR_declare_label(mercury____Compare___eval__object_0_0_i13);
MR_declare_label(mercury____Compare___eval__object_0_0_i14);
MR_declare_label(mercury____Compare___eval__object_0_0_i15);
MR_declare_label(mercury____Compare___eval__object_0_0_i16);
MR_declare_label(mercury____Compare___eval__object_0_0_i17);
MR_declare_label(mercury____Compare___eval__object_0_0_i22);
MR_declare_label(mercury____Compare___eval__object_0_0_i26);
MR_declare_label(mercury____Compare___eval__object_0_0_i25);
MR_declare_label(mercury____Compare___eval__object_0_0_i37);
MR_declare_label(mercury____Compare___eval__object_0_0_i43);
MR_declare_label(mercury____Compare___eval__object_0_0_i46);
MR_declare_label(mercury____Compare___eval__object_0_0_i51);
MR_declare_label(mercury____Compare___eval__object_0_0_i54);
MR_declare_label(mercury____Compare___eval__object_0_0_i59);
MR_declare_label(mercury____Compare___eval__object_0_0_i63);
MR_declare_label(mercury____Compare___eval__object_0_0_i60);
MR_declare_label(mercury____Compare___eval__object_0_0_i70);
MR_declare_label(mercury____Compare___eval__object_0_0_i19);
MR_declare_label(mercury____Compare___eval__object_0_0_i78);
MR_define_extern_entry(mercury____Unify___eval__basic_object_0_0);
MR_declare_label(mercury____Unify___eval__basic_object_0_0_i4);
MR_declare_label(mercury____Unify___eval__basic_object_0_0_i8);
MR_declare_label(mercury____Unify___eval__basic_object_0_0_i12);
MR_declare_label(mercury____Unify___eval__basic_object_0_0_i16);
MR_declare_label(mercury____Unify___eval__basic_object_0_0_i17);
MR_declare_label(mercury____Unify___eval__basic_object_0_0_i1);
MR_define_extern_entry(mercury____Index___eval__basic_object_0_0);
MR_declare_label(mercury____Index___eval__basic_object_0_0_i4);
MR_declare_label(mercury____Index___eval__basic_object_0_0_i5);
MR_declare_label(mercury____Index___eval__basic_object_0_0_i6);
MR_declare_label(mercury____Index___eval__basic_object_0_0_i7);
MR_declare_label(mercury____Index___eval__basic_object_0_0_i8);
MR_define_extern_entry(mercury____Compare___eval__basic_object_0_0);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i4);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i5);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i6);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i7);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i8);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i11);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i12);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i13);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i14);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i15);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i16);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i17);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i22);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i25);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i28);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i31);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i32);
MR_declare_label(mercury____Compare___eval__basic_object_0_0_i115);
MR_define_extern_entry(mercury____Unify___eval__transformation_0_0);
MR_declare_label(mercury____Unify___eval__transformation_0_0_i4);
MR_declare_label(mercury____Unify___eval__transformation_0_0_i6);
MR_declare_label(mercury____Unify___eval__transformation_0_0_i8);
MR_declare_label(mercury____Unify___eval__transformation_0_0_i10);
MR_declare_label(mercury____Unify___eval__transformation_0_0_i15);
MR_declare_label(mercury____Unify___eval__transformation_0_0_i13);
MR_declare_label(mercury____Unify___eval__transformation_0_0_i11);
MR_declare_label(mercury____Unify___eval__transformation_0_0_i1);
MR_define_extern_entry(mercury____Index___eval__transformation_0_0);
MR_declare_label(mercury____Index___eval__transformation_0_0_i4);
MR_declare_label(mercury____Index___eval__transformation_0_0_i5);
MR_declare_label(mercury____Index___eval__transformation_0_0_i6);
MR_declare_label(mercury____Index___eval__transformation_0_0_i7);
MR_declare_label(mercury____Index___eval__transformation_0_0_i10);
MR_declare_label(mercury____Index___eval__transformation_0_0_i9);
MR_declare_label(mercury____Index___eval__transformation_0_0_i8);
MR_define_extern_entry(mercury____Compare___eval__transformation_0_0);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i2);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i3);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i4);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i5);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i10);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i14);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i13);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i26);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i25);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i36);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i42);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i46);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i45);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i58);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i57);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i68);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i74);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i76);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i80);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i93);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i95);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i87);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i89);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i81);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i83);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i84);
MR_declare_label(mercury____Compare___eval__transformation_0_0_i7);
MR_define_extern_entry(mercury____Unify___eval__surface_0_0);
MR_declare_label(mercury____Unify___eval__surface_0_0_i5);
MR_declare_label(mercury____Unify___eval__surface_0_0_i3);
MR_declare_label(mercury____Unify___eval__surface_0_0_i10);
MR_declare_label(mercury____Unify___eval__surface_0_0_i1);
MR_define_extern_entry(mercury____Compare___eval__surface_0_0);
MR_declare_label(mercury____Compare___eval__surface_0_0_i7);
MR_declare_label(mercury____Compare___eval__surface_0_0_i5);
MR_declare_label(mercury____Compare___eval__surface_0_0_i3);
MR_declare_label(mercury____Compare___eval__surface_0_0_i13);
MR_declare_label(mercury____Compare___eval__surface_0_0_i2);
MR_define_extern_entry(mercury____Unify___eval__surface_properties_0_0);
MR_declare_label(mercury____Unify___eval__surface_properties_0_0_i2);
MR_declare_label(mercury____Unify___eval__surface_properties_0_0_i1);
MR_define_extern_entry(mercury____Compare___eval__surface_properties_0_0);
MR_declare_label(mercury____Compare___eval__surface_properties_0_0_i3);
MR_declare_label(mercury____Compare___eval__surface_properties_0_0_i8);
MR_declare_label(mercury____Compare___eval__surface_properties_0_0_i7);
MR_declare_label(mercury____Compare___eval__surface_properties_0_0_i20);
MR_declare_label(mercury____Compare___eval__surface_properties_0_0_i19);
MR_declare_label(mercury____Compare___eval__surface_properties_0_0_i30);
MR_declare_label(mercury____Compare___eval__surface_properties_0_0_i31);
MR_declare_label(mercury____Compare___eval__surface_properties_0_0_i36);
MR_define_extern_entry(mercury____Unify___eval__env_0_0);
MR_define_extern_entry(mercury____Compare___eval__env_0_0);
MR_define_extern_entry(mercury____Unify___eval__id_0_0);
MR_define_extern_entry(mercury____Compare___eval__id_0_0);
MR_declare_label(mercury____Compare___eval__id_0_0_i2);
MR_declare_label(mercury____Compare___eval__id_0_0_i3);
MR_define_extern_entry(mercury____Unify___eval__stack_0_0);
MR_define_extern_entry(mercury____Compare___eval__stack_0_0);
MR_define_extern_entry(mercury____Unify___eval__code_0_0);
MR_define_extern_entry(mercury____Compare___eval__code_0_0);
MR_define_extern_entry(mercury____Unify___eval__stack_env_exception_0_0);
MR_declare_label(mercury____Unify___eval__stack_env_exception_0_0_i2);
MR_declare_label(mercury____Unify___eval__stack_env_exception_0_0_i1);
MR_define_extern_entry(mercury____Compare___eval__stack_env_exception_0_0);
MR_declare_label(mercury____Compare___eval__stack_env_exception_0_0_i4);
MR_declare_label(mercury____Compare___eval__stack_env_exception_0_0_i3);
MR_declare_label(mercury____Compare___eval__stack_env_exception_0_0_i16);
MR_declare_label(mercury____Compare___eval__stack_env_exception_0_0_i21);
MR_define_extern_entry(mercury____Unify___eval__stack_env_token_exception_0_0);
MR_declare_label(mercury____Unify___eval__stack_env_token_exception_0_0_i2);
MR_declare_label(mercury____Unify___eval__stack_env_token_exception_0_0_i4);
MR_declare_label(mercury____Unify___eval__stack_env_token_exception_0_0_i1);
MR_define_extern_entry(mercury____Compare___eval__stack_env_token_exception_0_0);
MR_declare_label(mercury____Compare___eval__stack_env_token_exception_0_0_i4);
MR_declare_label(mercury____Compare___eval__stack_env_token_exception_0_0_i3);
MR_declare_label(mercury____Compare___eval__stack_env_token_exception_0_0_i16);
MR_declare_label(mercury____Compare___eval__stack_env_token_exception_0_0_i20);
MR_declare_label(mercury____Compare___eval__stack_env_token_exception_0_0_i26);
MR_define_extern_entry(mercury____Unify___eval__program_error_0_0);
MR_declare_label(mercury____Unify___eval__program_error_0_0_i3);
MR_declare_label(mercury____Unify___eval__program_error_0_0_i1);
MR_define_extern_entry(mercury____Compare___eval__program_error_0_0);
MR_declare_label(mercury____Compare___eval__program_error_0_0_i6);
MR_declare_label(mercury____Compare___eval__program_error_0_0_i3);
MR_declare_label(mercury____Compare___eval__program_error_0_0_i12);
MR_declare_label(mercury____Compare___eval__program_error_0_0_i36);
MR_declare_label(mercury____Compare___eval__program_error_0_0_i15);
MR_declare_label(mercury____Compare___eval__program_error_0_0_i38);
MR_declare_label(mercury____Compare___eval__program_error_0_0_i14);
MR_define_extern_entry(mercury____Unify___eval__global_object_counter_0_0);
MR_define_extern_entry(mercury____Compare___eval__global_object_counter_0_0);
MR_declare_label(mercury____Compare___eval__global_object_counter_0_0_i2);
MR_declare_label(mercury____Compare___eval__global_object_counter_0_0_i3);

static const struct mercury_data_eval__common_0_struct mercury_data_eval__common_0 = {
	MR_string_const("' is unknown", 12),
	MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0))
};

static const struct mercury_data_eval__common_1_struct mercury_data_eval__common_1 = {
	(MR_Integer) 45
};

static const struct mercury_data_eval__common_2_struct mercury_data_eval__common_2 = {
	(MR_Integer) 46
};
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_value_0[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_value_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_value_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__value_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__value_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__value_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"eval",
	"value",
	4,
	{ (void *) mercury_data_eval__du_name_ordered_value_0 },
	{ (void *) mercury_data_eval__du_ptag_ordered_value_0 },
	9,
	4
};
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_transformation_0[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_transformation_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_transformation_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__transformation_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__transformation_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__transformation_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"eval",
	"transformation",
	4,
	{ (void *) mercury_data_eval__du_name_ordered_transformation_0 },
	{ (void *) mercury_data_eval__du_ptag_ordered_transformation_0 },
	7,
	4
};
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_surface_properties_0[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_surface_properties_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_surface_properties_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__surface_properties_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__surface_properties_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__surface_properties_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"eval",
	"surface_properties",
	4,
	{ (void *) mercury_data_eval__du_name_ordered_surface_properties_0 },
	{ (void *) mercury_data_eval__du_ptag_ordered_surface_properties_0 },
	1,
	1
};
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_surface_0[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_surface_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_surface_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__surface_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__surface_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__surface_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"eval",
	"surface",
	4,
	{ (void *) mercury_data_eval__du_name_ordered_surface_0 },
	{ (void *) mercury_data_eval__du_ptag_ordered_surface_0 },
	2,
	2
};
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_stack_env_token_exception_0[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_stack_env_token_exception_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_stack_env_token_exception_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__stack_env_token_exception_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__stack_env_token_exception_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__stack_env_token_exception_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"eval",
	"stack_env_token_exception",
	4,
	{ (void *) mercury_data_eval__du_name_ordered_stack_env_token_exception_0 },
	{ (void *) mercury_data_eval__du_ptag_ordered_stack_env_token_exception_0 },
	1,
	1
};
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_stack_env_exception_0[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_stack_env_exception_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_stack_env_exception_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__stack_env_exception_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__stack_env_exception_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__stack_env_exception_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"eval",
	"stack_env_exception",
	4,
	{ (void *) mercury_data_eval__du_name_ordered_stack_env_exception_0 },
	{ (void *) mercury_data_eval__du_ptag_ordered_stack_env_exception_0 },
	1,
	1
};
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_13_eval__value_0;

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_stack_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__stack_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__stack_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__stack_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"eval",
	"stack",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_13_eval__value_0 },
	-1,
	-1
};
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_program_error_0[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_program_error_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_program_error_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__program_error_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__program_error_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__program_error_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"eval",
	"program_error",
	4,
	{ (void *) mercury_data_eval__du_name_ordered_program_error_0 },
	{ (void *) mercury_data_eval__du_ptag_ordered_program_error_0 },
	2,
	2
};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_object_id_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__object_id_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__object_id_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__object_id_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"eval",
	"object_id",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0 },
	-1,
	-1
};
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_object_0[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_object_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_object_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__object_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__object_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__object_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"eval",
	"object",
	4,
	{ (void *) mercury_data_eval__du_name_ordered_object_0 },
	{ (void *) mercury_data_eval__du_ptag_ordered_object_0 },
	5,
	4
};
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_light_0[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_light_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_light_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__light_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__light_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__light_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"eval",
	"light",
	4,
	{ (void *) mercury_data_eval__du_name_ordered_light_0 },
	{ (void *) mercury_data_eval__du_ptag_ordered_light_0 },
	3,
	3
};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_string_0;

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_id_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__id_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__id_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__id_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"eval",
	"id",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0 },
	-1,
	-1
};
extern const MR_EnumFunctorDesc * mercury_data_eval__enum_name_ordered_global_object_counter_0[];
extern const MR_EnumFunctorDesc * mercury_data_eval__enum_value_ordered_global_object_counter_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_global_object_counter_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__global_object_counter_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__global_object_counter_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__global_object_counter_0_0)),
	MR_TYPECTOR_REP_ENUM,
	NULL,
	NULL,
	"eval",
	"global_object_counter",
	4,
	{ (void *) mercury_data_eval__enum_name_ordered_global_object_counter_0 },
	{ (void *) mercury_data_eval__enum_value_ordered_global_object_counter_0 },
	1,
	-1
};
#ifndef MR_FO_PseudoTypeInfo_Struct2_GUARD
#define MR_FO_PseudoTypeInfo_Struct2_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct2, 2);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct2 mercury_data_tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0;

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_env_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__env_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__env_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__env_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"eval",
	"env",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0 },
	-1,
	-1
};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_float_0;

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_degrees_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__degrees_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__degrees_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__degrees_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"eval",
	"degrees",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0 },
	-1,
	-1
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_vector_0;

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_color_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__color_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__color_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__color_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"eval",
	"color",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0 },
	-1,
	-1
};
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_18_gml__token_group_0;

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_code_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__code_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__code_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__code_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"eval",
	"code",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_18_gml__token_group_0 },
	-1,
	-1
};
extern const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_basic_object_0[];
extern const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_basic_object_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_basic_object_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__basic_object_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__basic_object_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__basic_object_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"eval",
	"basic_object",
	4,
	{ (void *) mercury_data_eval__du_name_ordered_basic_object_0 },
	{ (void *) mercury_data_eval__du_ptag_ordered_basic_object_0 },
	5,
	4
};
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_array__type_info_array_1__type0_13_eval__value_0;

const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_array_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__array_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval__array_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval__array_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"eval",
	"array",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_array__type_info_array_1__type0_13_eval__value_0 },
	-1,
	-1
};

const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_value_0[] = {
	&mercury_data_eval__du_functor_desc_value_0_5,
	&mercury_data_eval__du_functor_desc_value_0_0,
	&mercury_data_eval__du_functor_desc_value_0_4,
	&mercury_data_eval__du_functor_desc_value_0_1,
	&mercury_data_eval__du_functor_desc_value_0_8,
	&mercury_data_eval__du_functor_desc_value_0_7,
	&mercury_data_eval__du_functor_desc_value_0_6,
	&mercury_data_eval__du_functor_desc_value_0_2,
	&mercury_data_eval__du_functor_desc_value_0_3
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_0 = {
	"boolean",
	1,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_value_0_0,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_bool__type_ctor_info_bool_0;

const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_bool__type_ctor_info_bool_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_1 = {
	"int",
	1,
	0,
	MR_SECTAG_NONE,
	1,
	0,
	1,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_value_0_1,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_1[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_2 = {
	"real",
	1,
	0,
	MR_SECTAG_NONE,
	2,
	0,
	2,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_value_0_2,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_2[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_3 = {
	"string",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	0,
	3,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_value_0_3,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_3[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_4 = {
	"closure",
	2,
	0,
	MR_SECTAG_REMOTE,
	3,
	1,
	4,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_value_0_4,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_4[] = {
	(MR_PseudoTypeInfo) &mercury_data_tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0,
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_18_gml__token_group_0
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_token_group_0;

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_18_gml__token_group_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_PseudoTypeInfo) &mercury_data_gml__type_ctor_info_token_group_0
}};
extern const struct MR_TypeCtorInfo_Struct mercury_data_tree234__type_ctor_info_tree234_2;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_value_0;

#ifndef MR_FO_PseudoTypeInfo_Struct2_GUARD
#define MR_FO_PseudoTypeInfo_Struct2_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct2, 2);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct2 mercury_data_tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0 = {
	&mercury_data_tree234__type_ctor_info_tree234_2,
{	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0,
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_value_0
}};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_5 = {
	"array",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	2,
	5,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_value_0_5,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_5[] = {
	(MR_PseudoTypeInfo) &mercury_data_array__type_info_array_1__type0_13_eval__value_0
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_array__type_ctor_info_array_1;

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_array__type_info_array_1__type0_13_eval__value_0 = {
	&mercury_data_array__type_ctor_info_array_1,
{	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_value_0
}};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_6 = {
	"point",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	3,
	6,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_value_0_6,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_6[] = {
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_7 = {
	"object",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	4,
	7,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_value_0_7,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_object_0;

const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_7[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_object_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_value_0_8 = {
	"light",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	5,
	8,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_value_0_8,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_light_0;

const MR_PseudoTypeInfo mercury_data_eval__field_types_value_0_8[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_light_0
};

const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_value_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_value_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_value_0_1 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_value_0_2 },
	{ 6, MR_SECTAG_REMOTE,
	mercury_data_eval__du_stag_ordered_value_0_3 }

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_value_0_0[] = {
	&mercury_data_eval__du_functor_desc_value_0_0

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_value_0_1[] = {
	&mercury_data_eval__du_functor_desc_value_0_1

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_value_0_2[] = {
	&mercury_data_eval__du_functor_desc_value_0_2

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_value_0_3[] = {
	&mercury_data_eval__du_functor_desc_value_0_3,
	&mercury_data_eval__du_functor_desc_value_0_4,
	&mercury_data_eval__du_functor_desc_value_0_5,
	&mercury_data_eval__du_functor_desc_value_0_6,
	&mercury_data_eval__du_functor_desc_value_0_7,
	&mercury_data_eval__du_functor_desc_value_0_8

};

const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_transformation_0[] = {
	&mercury_data_eval__du_functor_desc_transformation_0_6,
	&mercury_data_eval__du_functor_desc_transformation_0_3,
	&mercury_data_eval__du_functor_desc_transformation_0_4,
	&mercury_data_eval__du_functor_desc_transformation_0_5,
	&mercury_data_eval__du_functor_desc_transformation_0_1,
	&mercury_data_eval__du_functor_desc_transformation_0_0,
	&mercury_data_eval__du_functor_desc_transformation_0_2
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_0 = {
	"translate",
	3,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_transformation_0_0,
	mercury_data_eval__field_names_transformation_0_0,
	NULL
};

const MR_ConstString mercury_data_eval__field_names_transformation_0_0[] = {
	"tx",
	"ty",
	"tz"
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_1 = {
	"scale",
	3,
	0,
	MR_SECTAG_NONE,
	1,
	0,
	1,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_transformation_0_1,
	mercury_data_eval__field_names_transformation_0_1,
	NULL
};

const MR_ConstString mercury_data_eval__field_names_transformation_0_1[] = {
	"sx",
	"sy",
	"sz"
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_1[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_2 = {
	"uscale",
	1,
	0,
	MR_SECTAG_NONE,
	2,
	0,
	2,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_transformation_0_2,
	mercury_data_eval__field_names_transformation_0_2,
	NULL
};

const MR_ConstString mercury_data_eval__field_names_transformation_0_2[] = {
	"s"
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_2[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_3 = {
	"rotatex",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	0,
	3,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_transformation_0_3,
	mercury_data_eval__field_names_transformation_0_3,
	NULL
};

const MR_ConstString mercury_data_eval__field_names_transformation_0_3[] = {
	"rotatex_theta"
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_3[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_4 = {
	"rotatey",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	1,
	4,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_transformation_0_4,
	mercury_data_eval__field_names_transformation_0_4,
	NULL
};

const MR_ConstString mercury_data_eval__field_names_transformation_0_4[] = {
	"rotatey_theta"
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_4[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_5 = {
	"rotatez",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	2,
	5,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_transformation_0_5,
	mercury_data_eval__field_names_transformation_0_5,
	NULL
};

const MR_ConstString mercury_data_eval__field_names_transformation_0_5[] = {
	"rotatez_theta"
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_5[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_transformation_0_6 = {
	"matrix",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	3,
	6,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_transformation_0_6,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_trans__type_ctor_info_trans_0;

const MR_PseudoTypeInfo mercury_data_eval__field_types_transformation_0_6[] = {
	(MR_PseudoTypeInfo) &mercury_data_trans__type_ctor_info_trans_0
};

const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_transformation_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_transformation_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_transformation_0_1 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_transformation_0_2 },
	{ 4, MR_SECTAG_REMOTE,
	mercury_data_eval__du_stag_ordered_transformation_0_3 }

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_transformation_0_0[] = {
	&mercury_data_eval__du_functor_desc_transformation_0_0

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_transformation_0_1[] = {
	&mercury_data_eval__du_functor_desc_transformation_0_1

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_transformation_0_2[] = {
	&mercury_data_eval__du_functor_desc_transformation_0_2

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_transformation_0_3[] = {
	&mercury_data_eval__du_functor_desc_transformation_0_3,
	&mercury_data_eval__du_functor_desc_transformation_0_4,
	&mercury_data_eval__du_functor_desc_transformation_0_5,
	&mercury_data_eval__du_functor_desc_transformation_0_6

};

const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_surface_properties_0[] = {
	&mercury_data_eval__du_functor_desc_surface_properties_0_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_surface_properties_0_0 = {
	"surface_properties",
	4,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_surface_properties_0_0,
	mercury_data_eval__field_names_surface_properties_0_0,
	NULL
};

const MR_ConstString mercury_data_eval__field_names_surface_properties_0_0[] = {
	"surface_c",
	"surface_kd",
	"surface_ks",
	"surface_n"
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_surface_properties_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_surface_properties_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_surface_properties_0_0 }

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_surface_properties_0_0[] = {
	&mercury_data_eval__du_functor_desc_surface_properties_0_0

};

const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_surface_0[] = {
	&mercury_data_eval__du_functor_desc_surface_0_1,
	&mercury_data_eval__du_functor_desc_surface_0_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_surface_0_0 = {
	"surface",
	2,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_surface_0_0,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_surface_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0,
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_18_gml__token_group_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_surface_0_1 = {
	"constant",
	1,
	0,
	MR_SECTAG_NONE,
	1,
	0,
	1,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_surface_0_1,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_surface_properties_0;

const MR_PseudoTypeInfo mercury_data_eval__field_types_surface_0_1[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_surface_properties_0
};

const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_surface_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_surface_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_surface_0_1 }

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_surface_0_0[] = {
	&mercury_data_eval__du_functor_desc_surface_0_0

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_surface_0_1[] = {
	&mercury_data_eval__du_functor_desc_surface_0_1

};

const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_stack_env_token_exception_0[] = {
	&mercury_data_eval__du_functor_desc_stack_env_token_exception_0_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_stack_env_token_exception_0_0 = {
	"stack_env_token_exception",
	4,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_stack_env_token_exception_0_0,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_token_0;

const MR_PseudoTypeInfo mercury_data_eval__field_types_stack_env_token_exception_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0,
	(MR_PseudoTypeInfo) &mercury_data_tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0,
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_13_eval__value_0,
	(MR_PseudoTypeInfo) &mercury_data_gml__type_ctor_info_token_0
};

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_13_eval__value_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_value_0
}};

const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_stack_env_token_exception_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_stack_env_token_exception_0_0 }

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_stack_env_token_exception_0_0[] = {
	&mercury_data_eval__du_functor_desc_stack_env_token_exception_0_0

};

const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_stack_env_exception_0[] = {
	&mercury_data_eval__du_functor_desc_stack_env_exception_0_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_stack_env_exception_0_0 = {
	"stack_env_exception",
	3,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_stack_env_exception_0_0,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_stack_env_exception_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0,
	(MR_PseudoTypeInfo) &mercury_data_tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0,
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_13_eval__value_0
};

const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_stack_env_exception_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_stack_env_exception_0_0 }

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_stack_env_exception_0_0[] = {
	&mercury_data_eval__du_functor_desc_stack_env_exception_0_0

};

const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_program_error_0[] = {
	&mercury_data_eval__du_functor_desc_program_error_0_0,
	&mercury_data_eval__du_functor_desc_program_error_0_1
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_program_error_0_0 = {
	"program_error",
	1,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_program_error_0_0,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_program_error_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_program_error_0_1 = {
	"program_error",
	2,
	0,
	MR_SECTAG_NONE,
	1,
	0,
	1,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_program_error_0_1,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_program_error_0_1[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0,
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_13_eval__value_0
};

const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_program_error_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_program_error_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_program_error_0_1 }

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_program_error_0_0[] = {
	&mercury_data_eval__du_functor_desc_program_error_0_0

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_program_error_0_1[] = {
	&mercury_data_eval__du_functor_desc_program_error_0_1

};

const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_object_0[] = {
	&mercury_data_eval__du_functor_desc_object_0_0,
	&mercury_data_eval__du_functor_desc_object_0_4,
	&mercury_data_eval__du_functor_desc_object_0_3,
	&mercury_data_eval__du_functor_desc_object_0_1,
	&mercury_data_eval__du_functor_desc_object_0_2
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_object_0_0 = {
	"basic_object",
	3,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_object_0_0,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_basic_object_0;

const MR_PseudoTypeInfo mercury_data_eval__field_types_object_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_int_0,
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_basic_object_0,
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_13_eval__light_0
};

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_13_eval__light_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_light_0
}};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_object_0_1 = {
	"transform",
	2,
	0,
	MR_SECTAG_NONE,
	1,
	0,
	1,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_object_0_1,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_transformation_0;

const MR_PseudoTypeInfo mercury_data_eval__field_types_object_0_1[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_object_0,
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_transformation_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_object_0_2 = {
	"union",
	2,
	0,
	MR_SECTAG_NONE,
	2,
	0,
	2,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_object_0_2,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_object_0_2[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_object_0,
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_object_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_object_0_3 = {
	"intersect",
	2,
	0,
	MR_SECTAG_REMOTE,
	3,
	0,
	3,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_object_0_3,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_object_0_3[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_object_0,
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_object_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_object_0_4 = {
	"difference",
	2,
	0,
	MR_SECTAG_REMOTE,
	3,
	1,
	4,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_object_0_4,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_object_0_4[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_object_0,
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_object_0
};

const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_object_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_object_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_object_0_1 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_object_0_2 },
	{ 2, MR_SECTAG_REMOTE,
	mercury_data_eval__du_stag_ordered_object_0_3 }

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_object_0_0[] = {
	&mercury_data_eval__du_functor_desc_object_0_0

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_object_0_1[] = {
	&mercury_data_eval__du_functor_desc_object_0_1

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_object_0_2[] = {
	&mercury_data_eval__du_functor_desc_object_0_2

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_object_0_3[] = {
	&mercury_data_eval__du_functor_desc_object_0_3,
	&mercury_data_eval__du_functor_desc_object_0_4

};

const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_light_0[] = {
	&mercury_data_eval__du_functor_desc_light_0_0,
	&mercury_data_eval__du_functor_desc_light_0_1,
	&mercury_data_eval__du_functor_desc_light_0_2
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_light_0_0 = {
	"directional",
	2,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_light_0_0,
	mercury_data_eval__field_names_light_0_0,
	NULL
};

const MR_ConstString mercury_data_eval__field_names_light_0_0[] = {
	"dir",
	"directional_intensity"
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_light_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0,
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_light_0_1 = {
	"pointlight",
	2,
	0,
	MR_SECTAG_NONE,
	1,
	0,
	1,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_light_0_1,
	mercury_data_eval__field_names_light_0_1,
	NULL
};

const MR_ConstString mercury_data_eval__field_names_light_0_1[] = {
	"pointlight_pos",
	"pointlight_intensity"
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_light_0_1[] = {
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0,
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_light_0_2 = {
	"spotlight",
	5,
	0,
	MR_SECTAG_NONE,
	2,
	0,
	2,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_light_0_2,
	mercury_data_eval__field_names_light_0_2,
	NULL
};

const MR_ConstString mercury_data_eval__field_names_light_0_2[] = {
	"spotlight_pos",
	"at",
	"spotlight_intensity",
	"cutoff",
	"exp"
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_light_0_2[] = {
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0,
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0,
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_light_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_light_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_light_0_1 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_light_0_2 }

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_light_0_0[] = {
	&mercury_data_eval__du_functor_desc_light_0_0

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_light_0_1[] = {
	&mercury_data_eval__du_functor_desc_light_0_1

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_light_0_2[] = {
	&mercury_data_eval__du_functor_desc_light_0_2

};

const MR_EnumFunctorDesc * mercury_data_eval__enum_name_ordered_global_object_counter_0[] = {
	&mercury_data_eval__enum_functor_desc_global_object_counter_0_0
};

const MR_EnumFunctorDesc * mercury_data_eval__enum_value_ordered_global_object_counter_0[] = {
	&mercury_data_eval__enum_functor_desc_global_object_counter_0_0
};

static const MR_EnumFunctorDesc mercury_data_eval__enum_functor_desc_global_object_counter_0_0 = {
	"global_object_counter",
	0
};

const MR_DuFunctorDesc * mercury_data_eval__du_name_ordered_basic_object_0[] = {
	&mercury_data_eval__du_functor_desc_basic_object_0_3,
	&mercury_data_eval__du_functor_desc_basic_object_0_1,
	&mercury_data_eval__du_functor_desc_basic_object_0_2,
	&mercury_data_eval__du_functor_desc_basic_object_0_4,
	&mercury_data_eval__du_functor_desc_basic_object_0_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_basic_object_0_0 = {
	"sphere",
	1,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_basic_object_0_0,
	NULL,
	NULL
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_surface_0;

const MR_PseudoTypeInfo mercury_data_eval__field_types_basic_object_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_surface_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_basic_object_0_1 = {
	"cube",
	1,
	0,
	MR_SECTAG_NONE,
	1,
	0,
	1,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_basic_object_0_1,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_basic_object_0_1[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_surface_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_basic_object_0_2 = {
	"cylinder",
	1,
	0,
	MR_SECTAG_NONE,
	2,
	0,
	2,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_basic_object_0_2,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_basic_object_0_2[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_surface_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_basic_object_0_3 = {
	"cone",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	0,
	3,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_basic_object_0_3,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_basic_object_0_3[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_surface_0
};

static const MR_DuFunctorDesc mercury_data_eval__du_functor_desc_basic_object_0_4 = {
	"plane",
	1,
	0,
	MR_SECTAG_REMOTE,
	3,
	1,
	4,
	(MR_PseudoTypeInfo *) mercury_data_eval__field_types_basic_object_0_4,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval__field_types_basic_object_0_4[] = {
	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_surface_0
};

const MR_DuPtagLayout mercury_data_eval__du_ptag_ordered_basic_object_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_basic_object_0_0 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_basic_object_0_1 },
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval__du_stag_ordered_basic_object_0_2 },
	{ 2, MR_SECTAG_REMOTE,
	mercury_data_eval__du_stag_ordered_basic_object_0_3 }

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_basic_object_0_0[] = {
	&mercury_data_eval__du_functor_desc_basic_object_0_0

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_basic_object_0_1[] = {
	&mercury_data_eval__du_functor_desc_basic_object_0_1

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_basic_object_0_2[] = {
	&mercury_data_eval__du_functor_desc_basic_object_0_2

};

const MR_DuFunctorDesc * mercury_data_eval__du_stag_ordered_basic_object_0_3[] = {
	&mercury_data_eval__du_functor_desc_basic_object_0_3,
	&mercury_data_eval__du_functor_desc_basic_object_0_4

};

extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_string_0;
MR_declare_entry(mercury__tree234__init_1_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_int_0;
MR_declare_entry(mercury__globals__set_4_0);
MR_declare_entry(mercury__exception__throw_1_0);
static const struct mercury_const_52_struct {
	MR_Integer f1;
	MR_Integer f2;
	MR_Integer f3;
	MR_Integer f4;
	MR_Integer f5;
	MR_Integer f6;
	MR_Integer f7;
	MR_Integer f8;
	MR_Integer f9;
	MR_Integer f10;
	MR_Integer f11;
	MR_Integer f12;
	MR_Integer f13;
	MR_Integer f14;
	MR_Integer f15;
	MR_Integer f16;
	MR_Integer f17;
	MR_Integer f18;
	MR_Integer f19;
	MR_Integer f20;
	MR_Integer f21;
	MR_Integer f22;
	MR_Integer f23;
	MR_Integer f24;
	MR_Integer f25;
	MR_Integer f26;
	MR_Integer f27;
	MR_Integer f28;
	MR_Integer f29;
	MR_Integer f30;
	MR_Integer f31;
	MR_Integer f32;
	MR_Integer f33;
	MR_Integer f34;
	MR_Integer f35;
	MR_Integer f36;
	MR_Integer f37;
	MR_Integer f38;
	MR_Integer f39;
	MR_Integer f40;
	MR_Integer f41;
	MR_Integer f42;
	MR_Integer f43;
	MR_Integer f44;
	MR_Integer f45;
	MR_Integer f46;
	MR_Integer f47;
	MR_Integer f48;
	MR_Integer f49;
	MR_Integer f50;
}  mercury_const_52 = {
	(MR_Integer) 1,
	(MR_Integer) 2,
	(MR_Integer) 2,
	(MR_Integer) 1,
	(MR_Integer) 1,
	(MR_Integer) 1,
	(MR_Integer) 1,
	(MR_Integer) 1,
	(MR_Integer) 1,
	(MR_Integer) 1,
	(MR_Integer) 2,
	(MR_Integer) 2,
	(MR_Integer) 2,
	(MR_Integer) 2,
	(MR_Integer) 2,
	(MR_Integer) 1,
	(MR_Integer) 1,
	(MR_Integer) 2,
	(MR_Integer) 1,
	(MR_Integer) 1,
	(MR_Integer) 1,
	(MR_Integer) 3,
	(MR_Integer) 2,
	(MR_Integer) 1,
	(MR_Integer) 2,
	(MR_Integer) 2,
	(MR_Integer) 2,
	(MR_Integer) 2,
	(MR_Integer) 2,
	(MR_Integer) 2,
	(MR_Integer) 1,
	(MR_Integer) 1,
	(MR_Integer) 1,
	(MR_Integer) 3,
	(MR_Integer) 2,
	(MR_Integer) 1,
	(MR_Integer) 8,
	(MR_Integer) 2,
	(MR_Integer) 2,
	(MR_Integer) 2,
	(MR_Integer) 4,
	(MR_Integer) 1,
	(MR_Integer) 1,
	(MR_Integer) 5,
	(MR_Integer) 1,
	(MR_Integer) 2,
	(MR_Integer) 2,
	(MR_Integer) 4,
	(MR_Integer) 2,
	(MR_Integer) 2
};
static const struct mercury_const_4_struct {
	MR_Integer f1;
}  mercury_const_4 = {
	(MR_Integer) 1
};
static const struct mercury_const_5_struct {
	MR_Integer f1;
}  mercury_const_5 = {
	(MR_Integer) 1
};
static const struct mercury_const_6_struct {
	MR_Integer f1;
}  mercury_const_6 = {
	(MR_Integer) 1
};
static const struct mercury_const_7_struct {
	MR_Integer f1;
}  mercury_const_7 = {
	(MR_Integer) 1
};
static const struct mercury_const_8_struct {
	MR_Integer f1;
}  mercury_const_8 = {
	(MR_Integer) 1
};
static const struct mercury_const_9_struct {
	MR_Integer f1;
}  mercury_const_9 = {
	(MR_Integer) 1
};
static const struct mercury_const_10_struct {
	MR_Integer f1;
}  mercury_const_10 = {
	(MR_Integer) 1
};
static const struct mercury_const_11_struct {
	MR_Integer f1;
}  mercury_const_11 = {
	(MR_Integer) 1
};
static const struct mercury_const_12_struct {
	MR_Integer f1;
}  mercury_const_12 = {
	(MR_Integer) 1
};
static const struct mercury_const_13_struct {
	MR_Integer f1;
}  mercury_const_13 = {
	(MR_Integer) 1
};
static const struct mercury_const_14_struct {
	MR_Integer f1;
}  mercury_const_14 = {
	(MR_Integer) 1
};
static const struct mercury_const_15_struct {
	MR_Integer f1;
}  mercury_const_15 = {
	(MR_Integer) 1
};
static const struct mercury_const_16_struct {
	MR_Integer f1;
}  mercury_const_16 = {
	(MR_Integer) 1
};
static const struct mercury_const_17_struct {
	MR_Integer f1;
}  mercury_const_17 = {
	(MR_Integer) 1
};
static const struct mercury_const_18_struct {
	MR_Integer f1;
}  mercury_const_18 = {
	(MR_Integer) 1
};
static const struct mercury_const_19_struct {
	MR_Integer f1;
}  mercury_const_19 = {
	(MR_Integer) 1
};
static const struct mercury_const_20_struct {
	MR_Integer f1;
}  mercury_const_20 = {
	(MR_Integer) 1
};
static const struct mercury_const_21_struct {
	MR_Integer f1;
}  mercury_const_21 = {
	(MR_Integer) 1
};
static const struct mercury_const_22_struct {
	MR_Integer f1;
}  mercury_const_22 = {
	(MR_Integer) 1
};
static const struct mercury_const_23_struct {
	MR_Integer f1;
}  mercury_const_23 = {
	(MR_Integer) 1
};
static const struct mercury_const_24_struct {
	MR_Integer f1;
}  mercury_const_24 = {
	(MR_Integer) 1
};
static const struct mercury_const_25_struct {
	MR_Integer f1;
}  mercury_const_25 = {
	(MR_Integer) 1
};
static const struct mercury_const_26_struct {
	MR_Integer f1;
}  mercury_const_26 = {
	(MR_Integer) 1
};
static const struct mercury_const_27_struct {
	MR_Integer f1;
}  mercury_const_27 = {
	(MR_Integer) 1
};
static const struct mercury_const_28_struct {
	MR_Integer f1;
}  mercury_const_28 = {
	(MR_Integer) 1
};
static const struct mercury_const_29_struct {
	MR_Integer f1;
}  mercury_const_29 = {
	(MR_Integer) 1
};
static const struct mercury_const_30_struct {
	MR_Integer f1;
}  mercury_const_30 = {
	(MR_Integer) 1
};
static const struct mercury_const_31_struct {
	MR_Integer f1;
}  mercury_const_31 = {
	(MR_Integer) 1
};
static const struct mercury_const_32_struct {
	MR_Integer f1;
}  mercury_const_32 = {
	(MR_Integer) 1
};
static const struct mercury_const_33_struct {
	MR_Integer f1;
}  mercury_const_33 = {
	(MR_Integer) 1
};
static const struct mercury_const_34_struct {
	MR_Integer f1;
}  mercury_const_34 = {
	(MR_Integer) 1
};
static const struct mercury_const_35_struct {
	MR_Integer f1;
}  mercury_const_35 = {
	(MR_Integer) 1
};
static const struct mercury_const_36_struct {
	MR_Integer f1;
}  mercury_const_36 = {
	(MR_Integer) 1
};
static const struct mercury_const_37_struct {
	MR_Integer f1;
}  mercury_const_37 = {
	(MR_Integer) 1
};
static const struct mercury_const_38_struct {
	MR_Integer f1;
}  mercury_const_38 = {
	(MR_Integer) 0
};
static const struct mercury_const_39_struct {
	MR_Integer f1;
}  mercury_const_39 = {
	(MR_Integer) 1
};
static const struct mercury_const_40_struct {
	MR_Integer f1;
}  mercury_const_40 = {
	(MR_Integer) 1
};
static const struct mercury_const_41_struct {
	MR_Integer f1;
}  mercury_const_41 = {
	(MR_Integer) 1
};
static const struct mercury_const_42_struct {
	MR_Integer f1;
}  mercury_const_42 = {
	(MR_Integer) 1
};
static const struct mercury_const_43_struct {
	MR_Integer f1;
}  mercury_const_43 = {
	(MR_Integer) 1
};
static const struct mercury_const_44_struct {
	MR_Integer f1;
}  mercury_const_44 = {
	(MR_Integer) 1
};
static const struct mercury_const_45_struct {
	MR_Integer f1;
}  mercury_const_45 = {
	(MR_Integer) 1
};
static const struct mercury_const_46_struct {
	MR_Integer f1;
}  mercury_const_46 = {
	(MR_Integer) 1
};
static const struct mercury_const_47_struct {
	MR_Integer f1;
}  mercury_const_47 = {
	(MR_Integer) 1
};
static const struct mercury_const_48_struct {
	MR_Integer f1;
}  mercury_const_48 = {
	(MR_Integer) 1
};
static const struct mercury_const_49_struct {
	MR_Integer f1;
}  mercury_const_49 = {
	(MR_Integer) 1
};
static const struct mercury_const_50_struct {
	MR_Integer f1;
}  mercury_const_50 = {
	(MR_Integer) 1
};
static const struct mercury_const_51_struct {
	MR_Integer f1;
}  mercury_const_51 = {
	(MR_Integer) 1
};
static const struct mercury_const_53_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
	MR_Word * f4;
	MR_Word * f5;
	MR_Word * f6;
	MR_Word * f7;
	MR_Word * f8;
	MR_Word * f9;
	MR_Word * f10;
	MR_Word * f11;
	MR_Word * f12;
	MR_Word * f13;
	MR_Word * f14;
	MR_Word * f15;
	MR_Word * f16;
	MR_Word * f17;
	MR_Word * f18;
	MR_Word * f19;
	MR_Word * f20;
	MR_Word * f21;
	MR_Word * f22;
	MR_Word * f23;
	MR_Word * f24;
	MR_Word * f25;
	MR_Word * f26;
	MR_Word * f27;
	MR_Word * f28;
	MR_Word * f29;
	MR_Word * f30;
	MR_Word * f31;
	MR_Word * f32;
	MR_Word * f33;
	MR_Word * f34;
	MR_Word * f35;
	MR_Word * f36;
	MR_Word * f37;
	MR_Word * f38;
	MR_Word * f39;
	MR_Word * f40;
	MR_Word * f41;
	MR_Word * f42;
	MR_Word * f43;
	MR_Word * f44;
	MR_Word * f45;
	MR_Word * f46;
	MR_Word * f47;
	MR_Word * f48;
	MR_Word * f49;
	MR_Word * f50;
}  mercury_const_53 = {
	MR_mkword(MR_mktag(1), &mercury_const_4),
	MR_mkword(MR_mktag(1), &mercury_const_5),
	MR_mkword(MR_mktag(1), &mercury_const_6),
	MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)),
	MR_mkword(MR_mktag(1), &mercury_const_7),
	MR_mkword(MR_mktag(1), &mercury_const_8),
	MR_mkword(MR_mktag(1), &mercury_const_9),
	MR_mkword(MR_mktag(1), &mercury_const_10),
	MR_mkword(MR_mktag(1), &mercury_const_11),
	MR_mkword(MR_mktag(1), &mercury_const_12),
	MR_mkword(MR_mktag(1), &mercury_const_13),
	MR_mkword(MR_mktag(1), &mercury_const_14),
	MR_mkword(MR_mktag(1), &mercury_const_15),
	MR_mkword(MR_mktag(1), &mercury_const_16),
	MR_mkword(MR_mktag(1), &mercury_const_17),
	MR_mkword(MR_mktag(1), &mercury_const_18),
	MR_mkword(MR_mktag(1), &mercury_const_19),
	MR_mkword(MR_mktag(1), &mercury_const_20),
	MR_mkword(MR_mktag(1), &mercury_const_21),
	MR_mkword(MR_mktag(1), &mercury_const_22),
	MR_mkword(MR_mktag(1), &mercury_const_23),
	MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)),
	MR_mkword(MR_mktag(1), &mercury_const_24),
	MR_mkword(MR_mktag(1), &mercury_const_25),
	MR_mkword(MR_mktag(1), &mercury_const_26),
	MR_mkword(MR_mktag(1), &mercury_const_27),
	MR_mkword(MR_mktag(1), &mercury_const_28),
	MR_mkword(MR_mktag(1), &mercury_const_29),
	MR_mkword(MR_mktag(1), &mercury_const_30),
	MR_mkword(MR_mktag(1), &mercury_const_31),
	MR_mkword(MR_mktag(1), &mercury_const_32),
	MR_mkword(MR_mktag(1), &mercury_const_33),
	MR_mkword(MR_mktag(1), &mercury_const_34),
	MR_mkword(MR_mktag(1), &mercury_const_35),
	MR_mkword(MR_mktag(1), &mercury_const_36),
	MR_mkword(MR_mktag(1), &mercury_const_37),
	MR_mkword(MR_mktag(1), &mercury_const_38),
	MR_mkword(MR_mktag(1), &mercury_const_39),
	MR_mkword(MR_mktag(1), &mercury_const_40),
	MR_mkword(MR_mktag(1), &mercury_const_41),
	MR_mkword(MR_mktag(1), &mercury_const_42),
	MR_mkword(MR_mktag(1), &mercury_const_43),
	MR_mkword(MR_mktag(1), &mercury_const_44),
	MR_mkword(MR_mktag(1), &mercury_const_45),
	MR_mkword(MR_mktag(1), &mercury_const_46),
	MR_mkword(MR_mktag(1), &mercury_const_47),
	MR_mkword(MR_mktag(1), &mercury_const_48),
	MR_mkword(MR_mktag(1), &mercury_const_49),
	MR_mkword(MR_mktag(1), &mercury_const_50),
	MR_mkword(MR_mktag(1), &mercury_const_51)
};
MR_declare_entry(mercury__list__reverse_2_3_0);
MR_declare_entry(mercury__array__from_list_2_0);
MR_declare_entry(mercury__map__search_3_0);
MR_declare_entry(mercury__fn__string__append_list_1_0);
MR_declare_entry(mercury__tree234__set_4_1);
MR_declare_entry(mercury__fn__op__op_acos_1_0);
MR_declare_entry(mercury__fn__op__op_addi_2_0);
MR_declare_entry(mercury__fn__op__op_addf_2_0);
MR_declare_entry(mercury__fn__op__op_asin_1_0);
MR_declare_entry(mercury__fn__op__op_clampf_1_0);
MR_declare_entry(mercury__fn__op__op_cos_1_0);
MR_declare_entry(mercury__fn__op__op_divi_2_0);
MR_declare_entry(mercury__fn__op__op_divf_2_0);
MR_declare_entry(mercury__fn__op__op_eqi_2_0);
MR_declare_entry(mercury__fn__op__op_eqf_2_0);
MR_declare_entry(mercury__fn__op__op_floor_1_0);
MR_declare_entry(mercury__fn__op__op_frac_1_0);
MR_declare_entry(mercury__array__in_bounds_2_1);
MR_declare_entry(mercury__array__lookup_3_1);
MR_declare_entry(mercury__array__size_2_1);
MR_declare_entry(mercury__fn__op__op_lessi_2_0);
MR_declare_entry(mercury__fn__op__op_lessf_2_0);
MR_declare_entry(mercury__fn__op__op_modi_2_0);
MR_declare_entry(mercury__fn__op__op_muli_2_0);
MR_declare_entry(mercury__fn__op__op_mulf_2_0);
MR_declare_entry(mercury__fn__op__op_negi_1_0);
MR_declare_entry(mercury__fn__op__op_negf_1_0);
MR_declare_entry(mercury__fn__op__op_real_1_0);
MR_declare_entry(mercury__fn__transform_object__push_transformations_1_0);
MR_declare_entry(mercury__fn__space_partition__create_scene_1_0);
MR_declare_entry(mercury__renderer__render_3_0);
MR_declare_entry(mercury__fn__op__op_sin_1_0);
static const MR_Float mercury_float_const_0pt00000000000000 = 0.00000000000000;
MR_declare_entry(mercury__fn__op__op_sqrt_1_0);
MR_declare_entry(mercury__fn__op__op_subi_2_0);
MR_declare_entry(mercury__fn__op__op_subf_2_0);
MR_declare_entry(mercury__globals__get_4_0);
MR_declare_entry(mercury__do_call_closure);
MR_declare_entry(mercury____Unify___tree234__tree234_2_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_token_group_0;
MR_declare_entry(mercury____Unify___list__list_1_0);
MR_declare_entry(mercury____Unify___array__array_1_0);
MR_declare_entry(mercury____Unify___vector__vector_0_0);
MR_declare_entry(mercury____Compare___tree234__tree234_2_0);
MR_declare_entry(mercury____Compare___list__list_1_0);
MR_declare_entry(mercury____Compare___array__array_1_0);
MR_declare_entry(mercury____Compare___vector__vector_0_0);
MR_declare_entry(mercury__compare_error_0_0);
MR_declare_entry(mercury____Unify___trans__trans_0_0);
MR_declare_entry(mercury____Compare___trans__trans_0_0);
MR_declare_entry(mercury____Unify___gml__token_0_0);
MR_declare_entry(mercury____Compare___gml__token_0_0);

MR_BEGIN_MODULE(eval_module)
	MR_init_entry(mercury__eval__interpret_3_0);
	MR_init_label(mercury__eval__interpret_3_0_i2);
	MR_init_label(mercury__eval__interpret_3_0_i3);
	MR_init_entry(mercury__eval__initial_setup_4_0);
	MR_init_label(mercury__eval__initial_setup_4_0_i2);
	MR_init_label(mercury__eval__initial_setup_4_0_i3);
	MR_init_entry(mercury__eval__interpret_7_0);
	MR_init_label(mercury__eval__interpret_7_0_i4);
	MR_init_label(mercury__eval__interpret_7_0_i3);
	MR_init_entry(mercury__fn__eval__push_2_0);
	MR_init_entry(mercury__eval__pop_3_0);
	MR_init_label(mercury__eval__pop_3_0_i1);
	MR_init_entry(mercury__eval__eval_error_2_0);
	MR_init_label(mercury__eval__eval_error_2_0_i2);
	MR_init_entry(mercury__eval__args_3_0);
	MR_init_entry(mercury__eval__do_token_group_7_0);
	MR_init_label(mercury__eval__do_token_group_7_0_i5);
	MR_init_label(mercury__eval__do_token_group_7_0_i6);
	MR_init_label(mercury__eval__do_token_group_7_0_i7);
	MR_init_label(mercury__eval__do_token_group_7_0_i8);
	MR_init_label(mercury__eval__do_token_group_7_0_i4);
	MR_init_entry(mercury__eval__do_token_7_0);
	MR_init_label(mercury__eval__do_token_7_0_i4);
	MR_init_label(mercury__eval__do_token_7_0_i6);
	MR_init_label(mercury__eval__do_token_7_0_i8);
	MR_init_label(mercury__eval__do_token_7_0_i7);
	MR_init_label(mercury__eval__do_token_7_0_i10);
	MR_init_label(mercury__eval__do_token_7_0_i13);
	MR_init_label(mercury__eval__do_token_7_0_i16);
	MR_init_label(mercury__eval__do_token_7_0_i14);
	MR_init_label(mercury__eval__do_token_7_0_i17);
	MR_init_label(mercury__eval__do_token_7_0_i19);
	MR_init_label(mercury__eval__do_token_7_0_i28);
	MR_init_label(mercury__eval__do_token_7_0_i26);
	MR_init_label(mercury__eval__do_token_7_0_i21);
	MR_init_label(mercury__eval__do_token_7_0_i23);
	MR_init_label(mercury__eval__do_token_7_0_i25);
	MR_init_label(mercury__eval__do_token_7_0_i20);
	MR_init_entry(mercury__eval__do_op_6_0);
	MR_init_label(mercury__eval__do_op_6_0_i3);
	MR_init_label(mercury__eval__do_op_6_0_i7);
	MR_init_label(mercury__eval__do_op_6_0_i4);
	MR_init_label(mercury__eval__do_op_6_0_i11);
	MR_init_label(mercury__eval__do_op_6_0_i17);
	MR_init_label(mercury__eval__do_op_6_0_i12);
	MR_init_label(mercury__eval__do_op_6_0_i21);
	MR_init_label(mercury__eval__do_op_6_0_i27);
	MR_init_label(mercury__eval__do_op_6_0_i22);
	MR_init_label(mercury__eval__do_op_6_0_i31);
	MR_init_label(mercury__eval__do_op_6_0_i32);
	MR_init_label(mercury__eval__do_op_6_0_i38);
	MR_init_label(mercury__eval__do_op_6_0_i42);
	MR_init_label(mercury__eval__do_op_6_0_i39);
	MR_init_label(mercury__eval__do_op_6_0_i46);
	MR_init_label(mercury__eval__do_op_6_0_i50);
	MR_init_label(mercury__eval__do_op_6_0_i47);
	MR_init_label(mercury__eval__do_op_6_0_i54);
	MR_init_label(mercury__eval__do_op_6_0_i58);
	MR_init_label(mercury__eval__do_op_6_0_i55);
	MR_init_label(mercury__eval__do_op_6_0_i62);
	MR_init_label(mercury__eval__do_op_6_0_i66);
	MR_init_label(mercury__eval__do_op_6_0_i63);
	MR_init_label(mercury__eval__do_op_6_0_i70);
	MR_init_label(mercury__eval__do_op_6_0_i74);
	MR_init_label(mercury__eval__do_op_6_0_i71);
	MR_init_label(mercury__eval__do_op_6_0_i78);
	MR_init_label(mercury__eval__do_op_6_0_i82);
	MR_init_label(mercury__eval__do_op_6_0_i79);
	MR_init_label(mercury__eval__do_op_6_0_i86);
	MR_init_label(mercury__eval__do_op_6_0_i87);
	MR_init_label(mercury__eval__do_op_6_0_i95);
	MR_init_label(mercury__eval__do_op_6_0_i104);
	MR_init_label(mercury__eval__do_op_6_0_i97);
	MR_init_label(mercury__eval__do_op_6_0_i108);
	MR_init_label(mercury__eval__do_op_6_0_i114);
	MR_init_label(mercury__eval__do_op_6_0_i109);
	MR_init_label(mercury__eval__do_op_6_0_i118);
	MR_init_label(mercury__eval__do_op_6_0_i124);
	MR_init_label(mercury__eval__do_op_6_0_i119);
	MR_init_label(mercury__eval__do_op_6_0_i128);
	MR_init_label(mercury__eval__do_op_6_0_i134);
	MR_init_label(mercury__eval__do_op_6_0_i129);
	MR_init_label(mercury__eval__do_op_6_0_i138);
	MR_init_label(mercury__eval__do_op_6_0_i142);
	MR_init_label(mercury__eval__do_op_6_0_i139);
	MR_init_label(mercury__eval__do_op_6_0_i146);
	MR_init_label(mercury__eval__do_op_6_0_i150);
	MR_init_label(mercury__eval__do_op_6_0_i147);
	MR_init_label(mercury__eval__do_op_6_0_i154);
	MR_init_label(mercury__eval__do_op_6_0_i161);
	MR_init_label(mercury__eval__do_op_6_0_i163);
	MR_init_label(mercury__eval__do_op_6_0_i155);
	MR_init_label(mercury__eval__do_op_6_0_i156);
	MR_init_label(mercury__eval__do_op_6_0_i167);
	MR_init_label(mercury__eval__do_op_6_0_i168);
	MR_init_label(mercury__eval__do_op_6_0_i174);
	MR_init_label(mercury__eval__do_op_6_0_i175);
	MR_init_label(mercury__eval__do_op_6_0_i181);
	MR_init_label(mercury__eval__do_op_6_0_i182);
	MR_init_label(mercury__eval__do_op_6_0_i188);
	MR_init_label(mercury__eval__do_op_6_0_i197);
	MR_init_label(mercury__eval__do_op_6_0_i199);
	MR_init_label(mercury__eval__do_op_6_0_i189);
	MR_init_label(mercury__eval__do_op_6_0_i202);
	MR_init_label(mercury__eval__do_op_6_0_i203);
	MR_init_label(mercury__eval__do_op_6_0_i211);
	MR_init_label(mercury__eval__do_op_6_0_i215);
	MR_init_label(mercury__eval__do_op_6_0_i212);
	MR_init_label(mercury__eval__do_op_6_0_i219);
	MR_init_label(mercury__eval__do_op_6_0_i225);
	MR_init_label(mercury__eval__do_op_6_0_i220);
	MR_init_label(mercury__eval__do_op_6_0_i229);
	MR_init_label(mercury__eval__do_op_6_0_i235);
	MR_init_label(mercury__eval__do_op_6_0_i230);
	MR_init_label(mercury__eval__do_op_6_0_i239);
	MR_init_label(mercury__eval__do_op_6_0_i240);
	MR_init_label(mercury__eval__do_op_6_0_i248);
	MR_init_label(mercury__eval__do_op_6_0_i254);
	MR_init_label(mercury__eval__do_op_6_0_i249);
	MR_init_label(mercury__eval__do_op_6_0_i258);
	MR_init_label(mercury__eval__do_op_6_0_i264);
	MR_init_label(mercury__eval__do_op_6_0_i259);
	MR_init_label(mercury__eval__do_op_6_0_i268);
	MR_init_label(mercury__eval__do_op_6_0_i274);
	MR_init_label(mercury__eval__do_op_6_0_i269);
	MR_init_label(mercury__eval__do_op_6_0_i278);
	MR_init_label(mercury__eval__do_op_6_0_i282);
	MR_init_label(mercury__eval__do_op_6_0_i279);
	MR_init_label(mercury__eval__do_op_6_0_i286);
	MR_init_label(mercury__eval__do_op_6_0_i290);
	MR_init_label(mercury__eval__do_op_6_0_i287);
	MR_init_label(mercury__eval__do_op_6_0_i294);
	MR_init_label(mercury__eval__do_op_6_0_i298);
	MR_init_label(mercury__eval__do_op_6_0_i295);
	MR_init_label(mercury__eval__do_op_6_0_i302);
	MR_init_label(mercury__eval__do_op_6_0_i303);
	MR_init_label(mercury__eval__do_op_6_0_i313);
	MR_init_label(mercury__eval__do_op_6_0_i314);
	MR_init_label(mercury__eval__do_op_6_0_i322);
	MR_init_label(mercury__eval__do_op_6_0_i326);
	MR_init_label(mercury__eval__do_op_6_0_i323);
	MR_init_label(mercury__eval__do_op_6_0_i330);
	MR_init_label(mercury__eval__do_op_6_0_i348);
	MR_init_label(mercury__eval__do_op_6_0_i349);
	MR_init_label(mercury__eval__do_op_6_0_i350);
	MR_init_label(mercury__eval__do_op_6_0_i331);
	MR_init_label(mercury__eval__do_op_6_0_i353);
	MR_init_label(mercury__eval__do_op_6_0_i359);
	MR_init_label(mercury__eval__do_op_6_0_i354);
	MR_init_label(mercury__eval__do_op_6_0_i363);
	MR_init_label(mercury__eval__do_op_6_0_i369);
	MR_init_label(mercury__eval__do_op_6_0_i364);
	MR_init_label(mercury__eval__do_op_6_0_i373);
	MR_init_label(mercury__eval__do_op_6_0_i379);
	MR_init_label(mercury__eval__do_op_6_0_i374);
	MR_init_label(mercury__eval__do_op_6_0_i383);
	MR_init_label(mercury__eval__do_op_6_0_i393);
	MR_init_label(mercury__eval__do_op_6_0_i384);
	MR_init_label(mercury__eval__do_op_6_0_i397);
	MR_init_label(mercury__eval__do_op_6_0_i401);
	MR_init_label(mercury__eval__do_op_6_0_i398);
	MR_init_label(mercury__eval__do_op_6_0_i405);
	MR_init_label(mercury__eval__do_op_6_0_i409);
	MR_init_label(mercury__eval__do_op_6_0_i406);
	MR_init_label(mercury__eval__do_op_6_0_i413);
	MR_init_label(mercury__eval__do_op_6_0_i414);
	MR_init_label(mercury__eval__do_op_6_0_i428);
	MR_init_label(mercury__eval__do_op_6_0_i432);
	MR_init_label(mercury__eval__do_op_6_0_i429);
	MR_init_label(mercury__eval__do_op_6_0_i436);
	MR_init_label(mercury__eval__do_op_6_0_i442);
	MR_init_label(mercury__eval__do_op_6_0_i437);
	MR_init_label(mercury__eval__do_op_6_0_i446);
	MR_init_label(mercury__eval__do_op_6_0_i452);
	MR_init_label(mercury__eval__do_op_6_0_i447);
	MR_init_label(mercury__eval__do_op_6_0_i456);
	MR_init_label(mercury__eval__do_op_6_0_i466);
	MR_init_label(mercury__eval__do_op_6_0_i457);
	MR_init_label(mercury__eval__do_op_6_0_i470);
	MR_init_label(mercury__eval__do_op_6_0_i471);
	MR_init_label(mercury__eval__do_op_6_0_i479);
	MR_init_label(mercury__eval__do_op_6_0_i485);
	MR_init_label(mercury__eval__do_op_6_0_i480);
	MR_init_label(mercury__eval__do_op_6_0_i487);
	MR_init_entry(mercury__eval__renameObject_4_0);
	MR_init_label(mercury__eval__renameObject_4_0_i4);
	MR_init_label(mercury__eval__renameObject_4_0_i5);
	MR_init_label(mercury__eval__renameObject_4_0_i6);
	MR_init_label(mercury__eval__renameObject_4_0_i7);
	MR_init_label(mercury__eval__renameObject_4_0_i8);
	MR_init_label(mercury__eval__renameObject_4_0_i9);
	MR_init_label(mercury__eval__renameObject_4_0_i10);
	MR_init_label(mercury__eval__renameObject_4_0_i11);
	MR_init_label(mercury__eval__renameObject_4_0_i13);
	MR_init_label(mercury__eval__renameObject_4_0_i14);
	MR_init_label(mercury__eval__renameObject_4_0_i12);
	MR_init_label(mercury__eval__renameObject_4_0_i15);
	MR_init_label(mercury__eval__renameObject_4_0_i16);
	MR_init_entry(mercury__eval__next_object_id_3_0);
	MR_init_label(mercury__eval__next_object_id_3_0_i2);
	MR_init_label(mercury__eval__next_object_id_3_0_i3);
	MR_init_entry(mercury__eval__extra_operator_mode_2_0);
	MR_init_entry(mercury__eval__do_extra_6_0);
	MR_init_entry(mercury__eval__do_extra2_6_0);
	MR_init_label(mercury__eval__do_extra2_6_0_i4);
	MR_init_label(mercury__eval__do_extra2_6_0_i5);
	MR_init_label(mercury__eval__do_extra2_6_0_i9);
	MR_init_label(mercury__eval__do_extra2_6_0_i12);
	MR_init_label(mercury__eval__do_extra2_6_0_i10);
	MR_init_label(mercury__eval__do_extra2_6_0_i16);
	MR_init_label(mercury__eval__do_extra2_6_0_i17);
	MR_init_label(mercury__eval__do_extra2_6_0_i19);
	MR_init_label(mercury__eval__do_extra2_6_0_i20);
	MR_init_label(mercury__eval__do_extra2_6_0_i21);
	MR_init_label(mercury__eval__do_extra2_6_0_i23);
	MR_init_label(mercury__eval__do_extra2_6_0_i24);
	MR_init_label(mercury__eval__do_extra2_6_0_i26);
	MR_init_label(mercury__eval__do_extra2_6_0_i27);
	MR_init_label(mercury__eval__do_extra2_6_0_i29);
	MR_init_label(mercury__eval__do_extra2_6_0_i30);
	MR_init_label(mercury__eval__do_extra2_6_0_i32);
	MR_init_label(mercury__eval__do_extra2_6_0_i34);
	MR_init_label(mercury__eval__do_extra2_6_0_i39);
	MR_init_label(mercury__eval__do_extra2_6_0_i35);
	MR_init_label(mercury__eval__do_extra2_6_0_i42);
	MR_init_label(mercury__eval__do_extra2_6_0_i44);
	MR_init_label(mercury__eval__do_extra2_6_0_i45);
	MR_init_entry(mercury__eval__popn_3_0);
	MR_init_label(mercury__eval__popn_3_0_i15);
	MR_init_label(mercury__eval__popn_3_0_i6);
	MR_init_label(mercury__eval__popn_3_0_i1);
	MR_init_entry(mercury__eval__empty_stack_3_0);
	MR_init_entry(mercury____Unify___eval__value_0_0);
	MR_init_label(mercury____Unify___eval__value_0_0_i4);
	MR_init_label(mercury____Unify___eval__value_0_0_i6);
	MR_init_label(mercury____Unify___eval__value_0_0_i8);
	MR_init_label(mercury____Unify___eval__value_0_0_i10);
	MR_init_label(mercury____Unify___eval__value_0_0_i11);
	MR_init_label(mercury____Unify___eval__value_0_0_i13);
	MR_init_label(mercury____Unify___eval__value_0_0_i15);
	MR_init_label(mercury____Unify___eval__value_0_0_i19);
	MR_init_label(mercury____Unify___eval__value_0_0_i23);
	MR_init_label(mercury____Unify___eval__value_0_0_i27);
	MR_init_label(mercury____Unify___eval__value_0_0_i31);
	MR_init_label(mercury____Unify___eval__value_0_0_i1);
	MR_init_entry(mercury____Index___eval__value_0_0);
	MR_init_label(mercury____Index___eval__value_0_0_i4);
	MR_init_label(mercury____Index___eval__value_0_0_i5);
	MR_init_label(mercury____Index___eval__value_0_0_i6);
	MR_init_label(mercury____Index___eval__value_0_0_i7);
	MR_init_label(mercury____Index___eval__value_0_0_i8);
	MR_init_label(mercury____Index___eval__value_0_0_i9);
	MR_init_label(mercury____Index___eval__value_0_0_i10);
	MR_init_label(mercury____Index___eval__value_0_0_i11);
	MR_init_label(mercury____Index___eval__value_0_0_i12);
	MR_init_label(mercury____Index___eval__value_0_0_i13);
	MR_init_entry(mercury____Compare___eval__value_0_0);
	MR_init_label(mercury____Compare___eval__value_0_0_i2);
	MR_init_label(mercury____Compare___eval__value_0_0_i3);
	MR_init_label(mercury____Compare___eval__value_0_0_i4);
	MR_init_label(mercury____Compare___eval__value_0_0_i5);
	MR_init_label(mercury____Compare___eval__value_0_0_i10);
	MR_init_label(mercury____Compare___eval__value_0_0_i12);
	MR_init_label(mercury____Compare___eval__value_0_0_i16);
	MR_init_label(mercury____Compare___eval__value_0_0_i18);
	MR_init_label(mercury____Compare___eval__value_0_0_i22);
	MR_init_label(mercury____Compare___eval__value_0_0_i24);
	MR_init_label(mercury____Compare___eval__value_0_0_i70);
	MR_init_label(mercury____Compare___eval__value_0_0_i28);
	MR_init_label(mercury____Compare___eval__value_0_0_i29);
	MR_init_label(mercury____Compare___eval__value_0_0_i31);
	MR_init_label(mercury____Compare___eval__value_0_0_i74);
	MR_init_label(mercury____Compare___eval__value_0_0_i36);
	MR_init_label(mercury____Compare___eval__value_0_0_i39);
	MR_init_label(mercury____Compare___eval__value_0_0_i44);
	MR_init_label(mercury____Compare___eval__value_0_0_i47);
	MR_init_label(mercury____Compare___eval__value_0_0_i50);
	MR_init_label(mercury____Compare___eval__value_0_0_i53);
	MR_init_label(mercury____Compare___eval__value_0_0_i7);
	MR_init_label(mercury____Compare___eval__value_0_0_i59);
	MR_init_entry(mercury____Unify___eval__color_0_0);
	MR_init_entry(mercury____Compare___eval__color_0_0);
	MR_init_entry(mercury____Unify___eval__array_0_0);
	MR_init_entry(mercury____Compare___eval__array_0_0);
	MR_init_entry(mercury____Unify___eval__light_0_0);
	MR_init_label(mercury____Unify___eval__light_0_0_i19);
	MR_init_label(mercury____Unify___eval__light_0_0_i10);
	MR_init_label(mercury____Unify___eval__light_0_0_i12);
	MR_init_label(mercury____Unify___eval__light_0_0_i14);
	MR_init_label(mercury____Unify___eval__light_0_0_i16);
	MR_init_label(mercury____Unify___eval__light_0_0_i4);
	MR_init_label(mercury____Unify___eval__light_0_0_i6);
	MR_init_label(mercury____Unify___eval__light_0_0_i1);
	MR_init_entry(mercury____Compare___eval__light_0_0);
	MR_init_label(mercury____Compare___eval__light_0_0_i57);
	MR_init_label(mercury____Compare___eval__light_0_0_i15);
	MR_init_label(mercury____Compare___eval__light_0_0_i19);
	MR_init_label(mercury____Compare___eval__light_0_0_i21);
	MR_init_label(mercury____Compare___eval__light_0_0_i25);
	MR_init_label(mercury____Compare___eval__light_0_0_i29);
	MR_init_label(mercury____Compare___eval__light_0_0_i34);
	MR_init_label(mercury____Compare___eval__light_0_0_i33);
	MR_init_label(mercury____Compare___eval__light_0_0_i76);
	MR_init_label(mercury____Compare___eval__light_0_0_i44);
	MR_init_label(mercury____Compare___eval__light_0_0_i45);
	MR_init_label(mercury____Compare___eval__light_0_0_i4);
	MR_init_label(mercury____Compare___eval__light_0_0_i79);
	MR_init_label(mercury____Compare___eval__light_0_0_i7);
	MR_init_label(mercury____Compare___eval__light_0_0_i9);
	MR_init_label(mercury____Compare___eval__light_0_0_i2);
	MR_init_entry(mercury____Unify___eval__degrees_0_0);
	MR_init_entry(mercury____Compare___eval__degrees_0_0);
	MR_init_label(mercury____Compare___eval__degrees_0_0_i2);
	MR_init_label(mercury____Compare___eval__degrees_0_0_i3);
	MR_init_entry(mercury____Unify___eval__object_id_0_0);
	MR_init_entry(mercury____Compare___eval__object_id_0_0);
	MR_init_label(mercury____Compare___eval__object_id_0_0_i2);
	MR_init_label(mercury____Compare___eval__object_id_0_0_i3);
	MR_init_entry(mercury____Unify___eval__object_0_0);
	MR_init_label(mercury____Unify___eval__object_0_0_i4);
	MR_init_label(mercury____Unify___eval__object_0_0_i6);
	MR_init_label(mercury____Unify___eval__object_0_0_i10);
	MR_init_label(mercury____Unify___eval__object_0_0_i12);
	MR_init_label(mercury____Unify___eval__object_0_0_i16);
	MR_init_label(mercury____Unify___eval__object_0_0_i18);
	MR_init_label(mercury____Unify___eval__object_0_0_i22);
	MR_init_label(mercury____Unify___eval__object_0_0_i25);
	MR_init_label(mercury____Unify___eval__object_0_0_i23);
	MR_init_label(mercury____Unify___eval__object_0_0_i30);
	MR_init_label(mercury____Unify___eval__object_0_0_i1);
	MR_init_entry(mercury____Index___eval__object_0_0);
	MR_init_label(mercury____Index___eval__object_0_0_i4);
	MR_init_label(mercury____Index___eval__object_0_0_i5);
	MR_init_label(mercury____Index___eval__object_0_0_i6);
	MR_init_label(mercury____Index___eval__object_0_0_i7);
	MR_init_label(mercury____Index___eval__object_0_0_i8);
	MR_init_entry(mercury____Compare___eval__object_0_0);
	MR_init_label(mercury____Compare___eval__object_0_0_i4);
	MR_init_label(mercury____Compare___eval__object_0_0_i5);
	MR_init_label(mercury____Compare___eval__object_0_0_i6);
	MR_init_label(mercury____Compare___eval__object_0_0_i7);
	MR_init_label(mercury____Compare___eval__object_0_0_i8);
	MR_init_label(mercury____Compare___eval__object_0_0_i11);
	MR_init_label(mercury____Compare___eval__object_0_0_i12);
	MR_init_label(mercury____Compare___eval__object_0_0_i13);
	MR_init_label(mercury____Compare___eval__object_0_0_i14);
	MR_init_label(mercury____Compare___eval__object_0_0_i15);
	MR_init_label(mercury____Compare___eval__object_0_0_i16);
	MR_init_label(mercury____Compare___eval__object_0_0_i17);
	MR_init_label(mercury____Compare___eval__object_0_0_i22);
	MR_init_label(mercury____Compare___eval__object_0_0_i26);
	MR_init_label(mercury____Compare___eval__object_0_0_i25);
	MR_init_label(mercury____Compare___eval__object_0_0_i37);
	MR_init_label(mercury____Compare___eval__object_0_0_i43);
	MR_init_label(mercury____Compare___eval__object_0_0_i46);
	MR_init_label(mercury____Compare___eval__object_0_0_i51);
	MR_init_label(mercury____Compare___eval__object_0_0_i54);
	MR_init_label(mercury____Compare___eval__object_0_0_i59);
	MR_init_label(mercury____Compare___eval__object_0_0_i63);
	MR_init_label(mercury____Compare___eval__object_0_0_i60);
	MR_init_label(mercury____Compare___eval__object_0_0_i70);
	MR_init_label(mercury____Compare___eval__object_0_0_i19);
	MR_init_label(mercury____Compare___eval__object_0_0_i78);
	MR_init_entry(mercury____Unify___eval__basic_object_0_0);
	MR_init_label(mercury____Unify___eval__basic_object_0_0_i4);
	MR_init_label(mercury____Unify___eval__basic_object_0_0_i8);
	MR_init_label(mercury____Unify___eval__basic_object_0_0_i12);
	MR_init_label(mercury____Unify___eval__basic_object_0_0_i16);
	MR_init_label(mercury____Unify___eval__basic_object_0_0_i17);
	MR_init_label(mercury____Unify___eval__basic_object_0_0_i1);
	MR_init_entry(mercury____Index___eval__basic_object_0_0);
	MR_init_label(mercury____Index___eval__basic_object_0_0_i4);
	MR_init_label(mercury____Index___eval__basic_object_0_0_i5);
	MR_init_label(mercury____Index___eval__basic_object_0_0_i6);
	MR_init_label(mercury____Index___eval__basic_object_0_0_i7);
	MR_init_label(mercury____Index___eval__basic_object_0_0_i8);
	MR_init_entry(mercury____Compare___eval__basic_object_0_0);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i4);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i5);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i6);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i7);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i8);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i11);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i12);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i13);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i14);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i15);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i16);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i17);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i22);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i25);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i28);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i31);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i32);
	MR_init_label(mercury____Compare___eval__basic_object_0_0_i115);
	MR_init_entry(mercury____Unify___eval__transformation_0_0);
	MR_init_label(mercury____Unify___eval__transformation_0_0_i4);
	MR_init_label(mercury____Unify___eval__transformation_0_0_i6);
	MR_init_label(mercury____Unify___eval__transformation_0_0_i8);
	MR_init_label(mercury____Unify___eval__transformation_0_0_i10);
	MR_init_label(mercury____Unify___eval__transformation_0_0_i15);
	MR_init_label(mercury____Unify___eval__transformation_0_0_i13);
	MR_init_label(mercury____Unify___eval__transformation_0_0_i11);
	MR_init_label(mercury____Unify___eval__transformation_0_0_i1);
	MR_init_entry(mercury____Index___eval__transformation_0_0);
	MR_init_label(mercury____Index___eval__transformation_0_0_i4);
	MR_init_label(mercury____Index___eval__transformation_0_0_i5);
	MR_init_label(mercury____Index___eval__transformation_0_0_i6);
	MR_init_label(mercury____Index___eval__transformation_0_0_i7);
	MR_init_label(mercury____Index___eval__transformation_0_0_i10);
	MR_init_label(mercury____Index___eval__transformation_0_0_i9);
	MR_init_label(mercury____Index___eval__transformation_0_0_i8);
	MR_init_entry(mercury____Compare___eval__transformation_0_0);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i2);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i3);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i4);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i5);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i10);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i14);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i13);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i26);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i25);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i36);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i42);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i46);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i45);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i58);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i57);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i68);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i74);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i76);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i80);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i93);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i95);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i87);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i89);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i81);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i83);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i84);
	MR_init_label(mercury____Compare___eval__transformation_0_0_i7);
	MR_init_entry(mercury____Unify___eval__surface_0_0);
	MR_init_label(mercury____Unify___eval__surface_0_0_i5);
	MR_init_label(mercury____Unify___eval__surface_0_0_i3);
	MR_init_label(mercury____Unify___eval__surface_0_0_i10);
	MR_init_label(mercury____Unify___eval__surface_0_0_i1);
	MR_init_entry(mercury____Compare___eval__surface_0_0);
	MR_init_label(mercury____Compare___eval__surface_0_0_i7);
	MR_init_label(mercury____Compare___eval__surface_0_0_i5);
	MR_init_label(mercury____Compare___eval__surface_0_0_i3);
	MR_init_label(mercury____Compare___eval__surface_0_0_i13);
	MR_init_label(mercury____Compare___eval__surface_0_0_i2);
	MR_init_entry(mercury____Unify___eval__surface_properties_0_0);
	MR_init_label(mercury____Unify___eval__surface_properties_0_0_i2);
	MR_init_label(mercury____Unify___eval__surface_properties_0_0_i1);
	MR_init_entry(mercury____Compare___eval__surface_properties_0_0);
	MR_init_label(mercury____Compare___eval__surface_properties_0_0_i3);
	MR_init_label(mercury____Compare___eval__surface_properties_0_0_i8);
	MR_init_label(mercury____Compare___eval__surface_properties_0_0_i7);
	MR_init_label(mercury____Compare___eval__surface_properties_0_0_i20);
	MR_init_label(mercury____Compare___eval__surface_properties_0_0_i19);
	MR_init_label(mercury____Compare___eval__surface_properties_0_0_i30);
	MR_init_label(mercury____Compare___eval__surface_properties_0_0_i31);
	MR_init_label(mercury____Compare___eval__surface_properties_0_0_i36);
	MR_init_entry(mercury____Unify___eval__env_0_0);
	MR_init_entry(mercury____Compare___eval__env_0_0);
	MR_init_entry(mercury____Unify___eval__id_0_0);
	MR_init_entry(mercury____Compare___eval__id_0_0);
	MR_init_label(mercury____Compare___eval__id_0_0_i2);
	MR_init_label(mercury____Compare___eval__id_0_0_i3);
	MR_init_entry(mercury____Unify___eval__stack_0_0);
	MR_init_entry(mercury____Compare___eval__stack_0_0);
	MR_init_entry(mercury____Unify___eval__code_0_0);
	MR_init_entry(mercury____Compare___eval__code_0_0);
	MR_init_entry(mercury____Unify___eval__stack_env_exception_0_0);
	MR_init_label(mercury____Unify___eval__stack_env_exception_0_0_i2);
	MR_init_label(mercury____Unify___eval__stack_env_exception_0_0_i1);
	MR_init_entry(mercury____Compare___eval__stack_env_exception_0_0);
	MR_init_label(mercury____Compare___eval__stack_env_exception_0_0_i4);
	MR_init_label(mercury____Compare___eval__stack_env_exception_0_0_i3);
	MR_init_label(mercury____Compare___eval__stack_env_exception_0_0_i16);
	MR_init_label(mercury____Compare___eval__stack_env_exception_0_0_i21);
	MR_init_entry(mercury____Unify___eval__stack_env_token_exception_0_0);
	MR_init_label(mercury____Unify___eval__stack_env_token_exception_0_0_i2);
	MR_init_label(mercury____Unify___eval__stack_env_token_exception_0_0_i4);
	MR_init_label(mercury____Unify___eval__stack_env_token_exception_0_0_i1);
	MR_init_entry(mercury____Compare___eval__stack_env_token_exception_0_0);
	MR_init_label(mercury____Compare___eval__stack_env_token_exception_0_0_i4);
	MR_init_label(mercury____Compare___eval__stack_env_token_exception_0_0_i3);
	MR_init_label(mercury____Compare___eval__stack_env_token_exception_0_0_i16);
	MR_init_label(mercury____Compare___eval__stack_env_token_exception_0_0_i20);
	MR_init_label(mercury____Compare___eval__stack_env_token_exception_0_0_i26);
	MR_init_entry(mercury____Unify___eval__program_error_0_0);
	MR_init_label(mercury____Unify___eval__program_error_0_0_i3);
	MR_init_label(mercury____Unify___eval__program_error_0_0_i1);
	MR_init_entry(mercury____Compare___eval__program_error_0_0);
	MR_init_label(mercury____Compare___eval__program_error_0_0_i6);
	MR_init_label(mercury____Compare___eval__program_error_0_0_i3);
	MR_init_label(mercury____Compare___eval__program_error_0_0_i12);
	MR_init_label(mercury____Compare___eval__program_error_0_0_i36);
	MR_init_label(mercury____Compare___eval__program_error_0_0_i15);
	MR_init_label(mercury____Compare___eval__program_error_0_0_i38);
	MR_init_label(mercury____Compare___eval__program_error_0_0_i14);
	MR_init_entry(mercury____Unify___eval__global_object_counter_0_0);
	MR_init_entry(mercury____Compare___eval__global_object_counter_0_0);
	MR_init_label(mercury____Compare___eval__global_object_counter_0_0_i2);
	MR_init_label(mercury____Compare___eval__global_object_counter_0_0_i3);
MR_BEGIN_CODE

/* code for predicate 'interpret'/3 in mode 0 */
MR_define_entry(mercury__eval__interpret_3_0);
	MR_incr_sp_push_msg(2, "eval:interpret/3");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_localcall(mercury__eval__initial_setup_4_0,
		MR_LABEL(mercury__eval__interpret_3_0_i2),
		MR_ENTRY(mercury__eval__interpret_3_0));
MR_define_label(mercury__eval__interpret_3_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__interpret_3_0));
	MR_r4 = MR_r3;
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_localcall(mercury__eval__interpret_7_0,
		MR_LABEL(mercury__eval__interpret_3_0_i3),
		MR_ENTRY(mercury__eval__interpret_3_0));
MR_define_label(mercury__eval__interpret_3_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__interpret_3_0));
	MR_r1 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate 'initial_setup'/4 in mode 0 */
MR_define_entry(mercury__eval__initial_setup_4_0);
	MR_incr_sp_push_msg(2, "eval:initial_setup/4");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_call_localret(MR_ENTRY(mercury__tree234__init_1_0),
		mercury__eval__initial_setup_4_0_i2,
		MR_ENTRY(mercury__eval__initial_setup_4_0));
MR_define_label(mercury__eval__initial_setup_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__initial_setup_4_0));
	MR_r5 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_global_object_counter_0;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = (MR_Integer) 0;
	MR_r4 = (MR_Integer) 1;
	MR_call_localret(MR_ENTRY(mercury__globals__set_4_0),
		mercury__eval__initial_setup_4_0_i3,
		MR_ENTRY(mercury__eval__initial_setup_4_0));
MR_define_label(mercury__eval__initial_setup_4_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__initial_setup_4_0));
	MR_r3 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate 'interpret'/7 in mode 0 */
MR_define_entry(mercury__eval__interpret_7_0);
	MR_incr_sp_push_msg(2, "eval:interpret/7");
	MR_stackvar(2) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__interpret_7_0_i3);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__eval__do_token_group_7_0,
		MR_LABEL(mercury__eval__interpret_7_0_i4),
		MR_ENTRY(mercury__eval__interpret_7_0));
MR_define_label(mercury__eval__interpret_7_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__interpret_7_0));
	MR_r4 = MR_r3;
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__interpret_7_0_i3);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__eval__do_token_group_7_0,
		MR_LABEL(mercury__eval__interpret_7_0_i4),
		MR_ENTRY(mercury__eval__interpret_7_0));
MR_define_label(mercury__eval__interpret_7_0_i3);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_r3 = MR_r4;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate 'push'/3 in mode 0 */
MR_define_entry(mercury__fn__eval__push_2_0);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__fn__eval__push_2_0, "list:list/1");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r2;
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'pop'/3 in mode 0 */
MR_define_entry(mercury__eval__pop_3_0);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__pop_3_0_i1);
	}
	MR_r2 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__eval__pop_3_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate 'eval_error'/2 in mode 0 */
MR_define_entry(mercury__eval__eval_error_2_0);
	if (((MR_Integer) MR_r2 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__eval_error_2_0_i2);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__eval_error_2_0, "eval:stack_env_exception/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) MR_string_const("empty stack during evaluation", 29);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r2;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_stack_env_exception_0;
	MR_r2 = MR_tempr1;
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_ENTRY(mercury__eval__eval_error_2_0));
	}
MR_define_label(mercury__eval__eval_error_2_0_i2);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__eval__eval_error_2_0, "eval:program_error/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = (MR_Word) MR_string_const("type error during evalutation", 29);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r2;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_program_error_0;
	MR_r2 = MR_tempr1;
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_ENTRY(mercury__eval__eval_error_2_0));
	}
/* code for predicate 'args'/3 in mode 0 */
MR_define_entry(mercury__eval__args_3_0);
	MR_r3 = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(0), MR_mkword(MR_mktag(0), &mercury_const_52), MR_r1);
	MR_r2 = MR_const_field(MR_mktag(0), MR_mkword(MR_mktag(0), &mercury_const_53), MR_r3);
	MR_proceed();
/* code for predicate 'do_token_group'/7 in mode 0 */
MR_define_static(mercury__eval__do_token_group_7_0);
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_token_group_7_0_i4);
	}
	MR_incr_sp_push_msg(4, "eval:do_token_group/7");
	MR_stackvar(4) = (MR_Word) MR_succip;
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_token_group_7_0_i5);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__eval__do_token_7_0,
		MR_STATIC(mercury__eval__do_token_group_7_0));
MR_define_label(mercury__eval__do_token_group_7_0_i5);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_r3 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_localcall(mercury__eval__interpret_7_0,
		MR_LABEL(mercury__eval__do_token_group_7_0_i6),
		MR_STATIC(mercury__eval__do_token_group_7_0));
MR_define_label(mercury__eval__do_token_group_7_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_token_group_7_0));
	MR_stackvar(3) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r3 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_call_localret(MR_ENTRY(mercury__list__reverse_2_3_0),
		mercury__eval__do_token_group_7_0_i7,
		MR_STATIC(mercury__eval__do_token_group_7_0));
MR_define_label(mercury__eval__do_token_group_7_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_token_group_7_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_call_localret(MR_ENTRY(mercury__array__from_list_2_0),
		mercury__eval__do_token_group_7_0_i8,
		MR_STATIC(mercury__eval__do_token_group_7_0));
MR_define_label(mercury__eval__do_token_group_7_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_token_group_7_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_token_group_7_0, "eval:value/0");
	MR_r4 = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 2;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_token_group_7_0, "list:list/1");
	MR_r2 = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_stackvar(2);
	MR_r1 = MR_stackvar(1);
	MR_r3 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
	}
MR_define_label(mercury__eval__do_token_group_7_0_i4);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 3, mercury__eval__do_token_group_7_0, "eval:value/0");
	MR_r5 = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_r2;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 2) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_token_group_7_0, "list:list/1");
	MR_r6 = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_r3;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr2;
	MR_r3 = MR_r4;
	MR_proceed();
	}
/* code for predicate 'do_token'/7 in mode 0 */
MR_define_static(mercury__eval__do_token_7_0);
	MR_incr_sp_push_msg(5, "eval:do_token/7");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury__eval__do_token_7_0_i4) MR_AND
		MR_LABEL(mercury__eval__do_token_7_0_i6) MR_AND
		MR_LABEL(mercury__eval__do_token_7_0_i13) MR_AND
		MR_LABEL(mercury__eval__do_token_7_0_i19));
MR_define_label(mercury__eval__do_token_7_0_i4);
	MR_stackvar(1) = MR_r2;
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__eval__do_op_6_0,
		MR_LABEL(mercury__eval__do_token_7_0_i28),
		MR_STATIC(mercury__eval__do_token_7_0));
MR_define_label(mercury__eval__do_token_7_0_i6);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_tempr1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r3 = MR_stackvar(1);
	MR_r4 = MR_tempr1;
	}
	MR_call_localret(MR_ENTRY(mercury__map__search_3_0),
		mercury__eval__do_token_7_0_i8,
		MR_STATIC(mercury__eval__do_token_7_0));
MR_define_label(mercury__eval__do_token_7_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_token_7_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__eval__do_token_7_0_i7);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_token_7_0, "list:list/1");
	MR_r5 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r2;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_stackvar(2);
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_tempr1;
	MR_r3 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
	}
MR_define_label(mercury__eval__do_token_7_0_i7);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_token_7_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(1), (MR_Word *) &mercury_data_eval__common_0);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_token_7_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = (MR_Word) MR_string_const("identifier `", 12);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_tempr1;
	}
	MR_call_localret(MR_ENTRY(mercury__fn__string__append_list_1_0),
		mercury__eval__do_token_7_0_i10,
		MR_STATIC(mercury__eval__do_token_7_0));
MR_define_label(mercury__eval__do_token_7_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_token_7_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 1, mercury__eval__do_token_7_0, "eval:program_error/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_program_error_0;
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__eval__do_token_7_0_i17,
		MR_STATIC(mercury__eval__do_token_7_0));
MR_define_label(mercury__eval__do_token_7_0_i13);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_token_7_0_i14);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_stackvar(3) = MR_r4;
	MR_r6 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_stackvar(2) = MR_r3;
	MR_r3 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r4 = MR_const_field(MR_mktag(2), MR_r6, (MR_Integer) 0);
	MR_r5 = MR_const_field(MR_mktag(1), MR_stackvar(2), (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__tree234__set_4_1),
		mercury__eval__do_token_7_0_i16,
		MR_STATIC(mercury__eval__do_token_7_0));
MR_define_label(mercury__eval__do_token_7_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_token_7_0));
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury__eval__do_token_7_0_i14);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 4, mercury__eval__do_token_7_0, "eval:stack_env_token_exception/0");
	MR_r5 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) MR_string_const("empty stack", 11);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r3;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3) = MR_r1;
	MR_stackvar(3) = MR_r4;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_stack_env_token_exception_0;
	MR_r2 = MR_tempr1;
	}
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__eval__do_token_7_0_i17,
		MR_STATIC(mercury__eval__do_token_7_0));
MR_define_label(mercury__eval__do_token_7_0_i17);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_token_7_0));
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_r1;
	MR_r3 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury__eval__do_token_7_0_i19);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__eval__do_token_7_0_i20);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__eval__do_token_7_0_i21);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury__eval__do_token_7_0_i26);
	}
	MR_stackvar(1) = MR_r2;
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_localcall(mercury__eval__do_extra_6_0,
		MR_LABEL(mercury__eval__do_token_7_0_i28),
		MR_STATIC(mercury__eval__do_token_7_0));
MR_define_label(mercury__eval__do_token_7_0_i28);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_token_7_0));
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury__eval__do_token_7_0_i26);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_token_7_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 0;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_r3;
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_token_7_0_i25),
		MR_STATIC(mercury__eval__do_token_7_0));
MR_define_label(mercury__eval__do_token_7_0_i21);
	MR_r5 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__eval__do_token_7_0_i23);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_token_7_0, "eval:value/0");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(3) = MR_r4;
	MR_r2 = MR_r3;
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_token_7_0_i25),
		MR_STATIC(mercury__eval__do_token_7_0));
MR_define_label(mercury__eval__do_token_7_0_i23);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_token_7_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_r1, (MR_Integer) 0) = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(3) = MR_r4;
	MR_r2 = MR_r3;
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_token_7_0_i25),
		MR_STATIC(mercury__eval__do_token_7_0));
MR_define_label(mercury__eval__do_token_7_0_i25);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_token_7_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_r3 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury__eval__do_token_7_0_i20);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 1, mercury__eval__do_token_7_0, "eval:value/0");
	MR_r6 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_token_7_0, "list:list/1");
	MR_r7 = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_r3;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr2;
	MR_r3 = MR_r4;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
	}
/* code for predicate 'do_op'/6 in mode 0 */
MR_define_static(mercury__eval__do_op_6_0);
	MR_incr_sp_push_msg(10, "eval:do_op/6");
	MR_stackvar(10) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_r1,
		MR_LABEL(mercury__eval__do_op_6_0_i3) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i11) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i21) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i31) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i38) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i46) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i54) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i62) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i70) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i78) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i86) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i95) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i108) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i118) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i128) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i138) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i146) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i154) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i167) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i174) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i181) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i188) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i202) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i211) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i219) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i229) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i239) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i248) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i258) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i268) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i278) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i286) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i294) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i302) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i313) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i322) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i330) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i353) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i363) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i373) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i383) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i397) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i405) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i413) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i428) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i436) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i446) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i456) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i470) MR_AND
		MR_LABEL(mercury__eval__do_op_6_0_i479));
MR_define_label(mercury__eval__do_op_6_0_i3);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i4);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i4);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_acos_1_0),
		mercury__eval__do_op_6_0_i7,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i4);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i11);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i12);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i12);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i12);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i12);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r7, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_addi_2_0),
		mercury__eval__do_op_6_0_i17,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i17);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i12);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i21);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i22);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i22);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i22);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i22);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r7, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_addf_2_0),
		mercury__eval__do_op_6_0_i27,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i27);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i22);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i31);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i32);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i32);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 2);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	}
	MR_localcall(mercury__eval__interpret_7_0,
		MR_LABEL(mercury__eval__do_op_6_0_i199),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i32);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i38);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i39);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i39);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_asin_1_0),
		mercury__eval__do_op_6_0_i42,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i42);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i39);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i46);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i47);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i47);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_clampf_1_0),
		mercury__eval__do_op_6_0_i50,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i50);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i47);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i54);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i55);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i55);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_r4;
	}
	MR_localcall(mercury__eval__next_object_id_3_0,
		MR_LABEL(mercury__eval__do_op_6_0_i58),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i58);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:surface/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(2);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:basic_object/0");
	MR_field(MR_mktag(3), MR_tempr2, (MR_Integer) 0) = (MR_Integer) 0;
	MR_field(MR_mktag(3), MR_tempr2, (MR_Integer) 1) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i55);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i62);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i63);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i63);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_cos_1_0),
		mercury__eval__do_op_6_0_i66,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i66);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i63);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i70);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i71);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i71);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_r4;
	}
	MR_localcall(mercury__eval__next_object_id_3_0,
		MR_LABEL(mercury__eval__do_op_6_0_i74),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i74);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:surface/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(2);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:basic_object/0");
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i71);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i78);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i79);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i79);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_r4;
	}
	MR_localcall(mercury__eval__next_object_id_3_0,
		MR_LABEL(mercury__eval__do_op_6_0_i82),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i82);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:surface/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(2);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:basic_object/0");
	MR_field(MR_mktag(2), MR_tempr2, (MR_Integer) 0) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i79);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i86);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i87);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i87);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i87);
	}
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	MR_r7 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i87);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 3, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(3), MR_r7, (MR_Integer) 1);
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 2) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_stackvar(3) = MR_r4;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i87);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i95);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i97);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i97);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r7 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	if (((MR_Integer) MR_r7 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i97);
	}
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i97);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i97);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_r2 = MR_r7;
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_divi_2_0),
		mercury__eval__do_op_6_0_i104,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i104);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i97);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i108);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i109);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i109);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i109);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i109);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r7, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_divf_2_0),
		mercury__eval__do_op_6_0_i114,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i114);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i109);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i118);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i119);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i119);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i119);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i119);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r7, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_eqi_2_0),
		mercury__eval__do_op_6_0_i124,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i124);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i119);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i128);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i129);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i129);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i129);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i129);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r7, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_eqf_2_0),
		mercury__eval__do_op_6_0_i134,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i134);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i129);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i138);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i139);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i139);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_floor_1_0),
		mercury__eval__do_op_6_0_i142,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i142);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i139);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i146);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i147);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i147);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_frac_1_0),
		mercury__eval__do_op_6_0_i150,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i150);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i147);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i154);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i156);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i156);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i156);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	MR_r7 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 2)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i156);
	}
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), MR_r7, (MR_Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r2 = MR_stackvar(5);
	MR_r3 = MR_stackvar(4);
	}
	MR_call_localret(MR_ENTRY(mercury__array__in_bounds_2_1),
		mercury__eval__do_op_6_0_i161,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i161);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i155);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r2 = MR_stackvar(5);
	MR_r3 = MR_stackvar(4);
	MR_call_localret(MR_ENTRY(mercury__array__lookup_3_1),
		mercury__eval__do_op_6_0_i163,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i163);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	MR_r2 = MR_stackvar(6);
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i155);
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
MR_define_label(mercury__eval__do_op_6_0_i156);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i167);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i168);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i168);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_r1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1), (MR_Integer) 0);
	MR_stackvar(3) = MR_r4;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i168);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i174);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i175);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i175);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_r1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1), (MR_Integer) 1);
	MR_stackvar(3) = MR_r4;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i175);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i181);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i182);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i182);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_r1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1), (MR_Integer) 2);
	MR_stackvar(3) = MR_r4;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i182);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i188);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i189);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i189);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i189);
	}
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	MR_r7 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i189);
	}
	MR_r8 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	if (((MR_Integer) MR_r8 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i189);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r8, (MR_Integer) 0);
	if ((MR_tag(MR_r6) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i189);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i197);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 2);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r8, (MR_Integer) 1);
	}
	MR_localcall(mercury__eval__interpret_7_0,
		MR_LABEL(mercury__eval__do_op_6_0_i199),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i197);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r7, (MR_Integer) 2);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r7, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r8, (MR_Integer) 1);
	MR_localcall(mercury__eval__interpret_7_0,
		MR_LABEL(mercury__eval__do_op_6_0_i199),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i199);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	MR_proceed();
MR_define_label(mercury__eval__do_op_6_0_i189);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i202);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i203);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i203);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i203);
	}
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	MR_r7 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i203);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 3, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 0;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(3), MR_r7, (MR_Integer) 1);
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 2) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_stackvar(3) = MR_r4;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i203);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i211);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i212);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 2)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i212);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r2 = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	}
	MR_call_localret(MR_ENTRY(mercury__array__size_2_1),
		mercury__eval__do_op_6_0_i215,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i215);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i212);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i219);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i220);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i220);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i220);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i220);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r7, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_lessi_2_0),
		mercury__eval__do_op_6_0_i225,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i225);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i220);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i229);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i230);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i230);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i230);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i230);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r7, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_lessf_2_0),
		mercury__eval__do_op_6_0_i235,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i235);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i230);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i239);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i240);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i240);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i240);
	}
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	MR_r7 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i240);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:light/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(3), MR_r7, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 5;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_stackvar(3) = MR_r4;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i240);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i248);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i249);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i249);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i249);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i249);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r7, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_modi_2_0),
		mercury__eval__do_op_6_0_i254,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i254);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i249);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i258);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i259);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i259);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i259);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i259);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r7, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_muli_2_0),
		mercury__eval__do_op_6_0_i264,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i264);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i259);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i268);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i269);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i269);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i269);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i269);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r7, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_mulf_2_0),
		mercury__eval__do_op_6_0_i274,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i274);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i269);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i278);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i279);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i279);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_negi_1_0),
		mercury__eval__do_op_6_0_i282,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i282);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i279);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i286);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i287);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i287);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_negf_1_0),
		mercury__eval__do_op_6_0_i290,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i290);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i287);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i294);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i295);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i295);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_r4;
	}
	MR_localcall(mercury__eval__next_object_id_3_0,
		MR_LABEL(mercury__eval__do_op_6_0_i298),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i298);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:surface/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(2);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:basic_object/0");
	MR_field(MR_mktag(3), MR_tempr2, (MR_Integer) 0) = (MR_Integer) 1;
	MR_field(MR_mktag(3), MR_tempr2, (MR_Integer) 1) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i295);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i302);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i303);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i303);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i303);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i303);
	}
	MR_r8 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	if (((MR_Integer) MR_r8 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i303);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r8, (MR_Integer) 0);
	if ((MR_tag(MR_r6) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i303);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__do_op_6_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(2), MR_r6, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(2), MR_r7, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 3;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_stackvar(3) = MR_r4;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r8, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i303);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i313);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i314);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i314);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i314);
	}
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	MR_r7 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i314);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:light/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(3), MR_r7, (MR_Integer) 1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 5;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_stackvar(3) = MR_r4;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i314);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i322);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i323);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i323);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_real_1_0),
		mercury__eval__do_op_6_0_i326,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i326);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i323);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i330);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_r8 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	if (((MR_Integer) MR_r8 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r8, (MR_Integer) 0);
	if ((MR_tag(MR_r6) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_r9 = MR_const_field(MR_mktag(1), MR_r8, (MR_Integer) 1);
	if (((MR_Integer) MR_r9 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_r8 = MR_const_field(MR_mktag(1), MR_r9, (MR_Integer) 0);
	if ((MR_tag(MR_r8) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_r10 = MR_const_field(MR_mktag(1), MR_r9, (MR_Integer) 1);
	if (((MR_Integer) MR_r10 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_r9 = MR_const_field(MR_mktag(1), MR_r10, (MR_Integer) 0);
	if ((MR_tag(MR_r9) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_r11 = MR_const_field(MR_mktag(1), MR_r10, (MR_Integer) 1);
	if (((MR_Integer) MR_r11 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r11, (MR_Integer) 0);
	MR_r10 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_r12 = MR_const_field(MR_mktag(1), MR_r11, (MR_Integer) 1);
	if (((MR_Integer) MR_r12 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r12, (MR_Integer) 0);
	MR_r11 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 2)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_r13 = MR_const_field(MR_mktag(1), MR_r12, (MR_Integer) 1);
	if (((MR_Integer) MR_r13 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r13, (MR_Integer) 0);
	MR_r12 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i331);
	}
	MR_stackvar(1) = MR_r4;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_r7, (MR_Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(2), MR_r8, (MR_Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), MR_r9, (MR_Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(3), MR_r11, (MR_Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(3), MR_r12, (MR_Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(1), MR_r13, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r10, (MR_Integer) 1);
	}
	MR_call_localret(MR_ENTRY(mercury__fn__transform_object__push_transformations_1_0),
		mercury__eval__do_op_6_0_i348,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i348);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	MR_call_localret(MR_ENTRY(mercury__fn__space_partition__create_scene_1_0),
		mercury__eval__do_op_6_0_i349,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i349);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 8, mercury__eval__do_op_6_0, "renderer:render_params/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 5) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 6) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 7) = MR_stackvar(2);
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_call_localret(MR_ENTRY(mercury__renderer__render_3_0),
		mercury__eval__do_op_6_0_i350,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i350);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(9);
	MR_succip = (MR_Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	MR_proceed();
MR_define_label(mercury__eval__do_op_6_0_i331);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i353);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i354);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i354);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i354);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	MR_r7 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i354);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r7, (MR_Integer) 1);
	MR_r2 = MR_r4;
	}
	MR_localcall(mercury__eval__renameObject_4_0,
		MR_LABEL(mercury__eval__do_op_6_0_i359),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i359);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:transformation/0");
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 0;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr2;
	MR_stackvar(3) = MR_r2;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i354);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i363);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i364);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i364);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i364);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	MR_r7 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i364);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r7, (MR_Integer) 1);
	MR_r2 = MR_r4;
	}
	MR_localcall(mercury__eval__renameObject_4_0,
		MR_LABEL(mercury__eval__do_op_6_0_i369),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i369);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:transformation/0");
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr2;
	MR_stackvar(3) = MR_r2;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i364);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i373);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i374);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i374);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i374);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	MR_r7 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i374);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r7, (MR_Integer) 1);
	MR_r2 = MR_r4;
	}
	MR_localcall(mercury__eval__renameObject_4_0,
		MR_LABEL(mercury__eval__do_op_6_0_i379),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i379);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:transformation/0");
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 2;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr2;
	MR_stackvar(3) = MR_r2;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i374);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i383);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i384);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i384);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i384);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i384);
	}
	MR_r8 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	if (((MR_Integer) MR_r8 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i384);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r8, (MR_Integer) 0);
	if ((MR_tag(MR_r6) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i384);
	}
	MR_r9 = MR_const_field(MR_mktag(1), MR_r8, (MR_Integer) 1);
	if (((MR_Integer) MR_r9 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i384);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r9, (MR_Integer) 0);
	MR_r8 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i384);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), MR_r7, (MR_Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), MR_r6, (MR_Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_r9, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r8, (MR_Integer) 1);
	MR_r2 = MR_r4;
	}
	MR_localcall(mercury__eval__renameObject_4_0,
		MR_LABEL(mercury__eval__do_op_6_0_i393),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i393);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 3, mercury__eval__do_op_6_0, "eval:transformation/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 2) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr2;
	MR_stackvar(3) = MR_r2;
	MR_r2 = MR_stackvar(4);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i384);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i397);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i398);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i398);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_sin_1_0),
		mercury__eval__do_op_6_0_i401,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i401);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i398);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i405);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i406);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i406);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = MR_r4;
	}
	MR_localcall(mercury__eval__next_object_id_3_0,
		MR_LABEL(mercury__eval__do_op_6_0_i409),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i409);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:surface/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(2);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(0), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:basic_object/0");
	MR_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i406);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i413);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i414);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i414);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i414);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i414);
	}
	MR_r8 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	if (((MR_Integer) MR_r8 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i414);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r8, (MR_Integer) 0);
	MR_r6 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i414);
	}
	MR_r9 = MR_const_field(MR_mktag(1), MR_r8, (MR_Integer) 1);
	if (((MR_Integer) MR_r9 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i414);
	}
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r9, (MR_Integer) 0);
	MR_r8 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i414);
	}
	MR_r10 = MR_const_field(MR_mktag(1), MR_r9, (MR_Integer) 1);
	if (((MR_Integer) MR_r10 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i414);
	}
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r10, (MR_Integer) 0);
	MR_r9 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i414);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 5, mercury__eval__do_op_6_0, "eval:light/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(3), MR_r9, (MR_Integer) 1);
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(3), MR_r8, (MR_Integer) 1);
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 2) = MR_const_field(MR_mktag(3), MR_r6, (MR_Integer) 1);
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 3) = MR_const_field(MR_mktag(2), MR_r7, (MR_Integer) 0);
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 4) = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 5;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_stackvar(3) = MR_r4;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r10, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i414);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i428);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i429);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i429);
	}
	MR_r1 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	if ((MR_word_to_float(MR_r1) < (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i429);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_sqrt_1_0),
		mercury__eval__do_op_6_0_i432,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i432);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i429);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i436);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i437);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i437);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i437);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i437);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r7, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_subi_2_0),
		mercury__eval__do_op_6_0_i442,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i442);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i437);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_r3 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_eval__common_1);
	MR_localcall(mercury__eval__empty_stack_3_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i446);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i447);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i447);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i447);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i447);
	}
	MR_stackvar(3) = MR_r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r7, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury__fn__op__op_subf_2_0),
		mercury__eval__do_op_6_0_i452,
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i452);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_stackvar(1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i447);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_r3 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_eval__common_2);
	MR_localcall(mercury__eval__empty_stack_3_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i456);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i457);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i457);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i457);
	}
	MR_r7 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	if ((MR_tag(MR_r7) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i457);
	}
	MR_r8 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	if (((MR_Integer) MR_r8 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i457);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r8, (MR_Integer) 0);
	if ((MR_tag(MR_r6) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i457);
	}
	MR_r9 = MR_const_field(MR_mktag(1), MR_r8, (MR_Integer) 1);
	if (((MR_Integer) MR_r9 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i457);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r9, (MR_Integer) 0);
	MR_r8 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i457);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), MR_r7, (MR_Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), MR_r6, (MR_Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_r9, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r8, (MR_Integer) 1);
	MR_r2 = MR_r4;
	}
	MR_localcall(mercury__eval__renameObject_4_0,
		MR_LABEL(mercury__eval__do_op_6_0_i466),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i466);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__do_op_6_0, "eval:transformation/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr2;
	MR_stackvar(3) = MR_r2;
	MR_r2 = MR_stackvar(4);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i457);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i470);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i471);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_r5 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i471);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i471);
	}
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	MR_r7 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i471);
	}
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(3), MR_r7, (MR_Integer) 1);
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_stackvar(3) = MR_r4;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i471);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i479);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i480);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i480);
	}
	MR_r6 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	if (((MR_Integer) MR_r6 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i480);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 0);
	MR_r7 = MR_tempr1;
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury__eval__do_op_6_0_i480);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r5, (MR_Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r6, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r7, (MR_Integer) 1);
	MR_r2 = MR_r4;
	}
	MR_localcall(mercury__eval__renameObject_4_0,
		MR_LABEL(mercury__eval__do_op_6_0_i485),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i485);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_op_6_0, "eval:transformation/0");
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:object/0");
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 1) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_op_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr2;
	MR_stackvar(3) = MR_r2;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i480);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_op_6_0_i487),
		MR_STATIC(mercury__eval__do_op_6_0));
MR_define_label(mercury__eval__do_op_6_0_i487);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_op_6_0));
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	MR_proceed();
/* code for predicate 'renameObject'/4 in mode 0 */
MR_define_static(mercury__eval__renameObject_4_0);
	MR_incr_sp_push_msg(3, "eval:renameObject/4");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury__eval__renameObject_4_0_i4) MR_AND
		MR_LABEL(mercury__eval__renameObject_4_0_i6) MR_AND
		MR_LABEL(mercury__eval__renameObject_4_0_i8) MR_AND
		MR_LABEL(mercury__eval__renameObject_4_0_i11));
MR_define_label(mercury__eval__renameObject_4_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_r2;
	MR_localcall(mercury__eval__next_object_id_3_0,
		MR_LABEL(mercury__eval__renameObject_4_0_i5),
		MR_STATIC(mercury__eval__renameObject_4_0));
MR_define_label(mercury__eval__renameObject_4_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__renameObject_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__renameObject_4_0, "eval:object/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_stackvar(2);
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
MR_define_label(mercury__eval__renameObject_4_0_i6);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__eval__renameObject_4_0,
		MR_LABEL(mercury__eval__renameObject_4_0_i7),
		MR_STATIC(mercury__eval__renameObject_4_0));
MR_define_label(mercury__eval__renameObject_4_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__renameObject_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__eval__renameObject_4_0, "eval:object/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_stackvar(1);
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
MR_define_label(mercury__eval__renameObject_4_0_i8);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__eval__renameObject_4_0,
		MR_LABEL(mercury__eval__renameObject_4_0_i9),
		MR_STATIC(mercury__eval__renameObject_4_0));
MR_define_label(mercury__eval__renameObject_4_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__renameObject_4_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__eval__renameObject_4_0,
		MR_LABEL(mercury__eval__renameObject_4_0_i10),
		MR_STATIC(mercury__eval__renameObject_4_0));
MR_define_label(mercury__eval__renameObject_4_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__renameObject_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 2, mercury__eval__renameObject_4_0, "eval:object/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
MR_define_label(mercury__eval__renameObject_4_0_i11);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__eval__renameObject_4_0_i12);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_localcall(mercury__eval__renameObject_4_0,
		MR_LABEL(mercury__eval__renameObject_4_0_i13),
		MR_STATIC(mercury__eval__renameObject_4_0));
MR_define_label(mercury__eval__renameObject_4_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__renameObject_4_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__eval__renameObject_4_0,
		MR_LABEL(mercury__eval__renameObject_4_0_i14),
		MR_STATIC(mercury__eval__renameObject_4_0));
MR_define_label(mercury__eval__renameObject_4_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__renameObject_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 3, mercury__eval__renameObject_4_0, "eval:object/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 0;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
MR_define_label(mercury__eval__renameObject_4_0_i12);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_localcall(mercury__eval__renameObject_4_0,
		MR_LABEL(mercury__eval__renameObject_4_0_i15),
		MR_STATIC(mercury__eval__renameObject_4_0));
MR_define_label(mercury__eval__renameObject_4_0_i15);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__renameObject_4_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__eval__renameObject_4_0,
		MR_LABEL(mercury__eval__renameObject_4_0_i16),
		MR_STATIC(mercury__eval__renameObject_4_0));
MR_define_label(mercury__eval__renameObject_4_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__renameObject_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 3, mercury__eval__renameObject_4_0, "eval:object/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
/* code for predicate 'next_object_id'/3 in mode 0 */
MR_define_static(mercury__eval__next_object_id_3_0);
	MR_incr_sp_push_msg(2, "eval:next_object_id/3");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_r4 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_global_object_counter_0;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = (MR_Integer) 0;
	MR_call_localret(MR_ENTRY(mercury__globals__get_4_0),
		mercury__eval__next_object_id_3_0_i2,
		MR_STATIC(mercury__eval__next_object_id_3_0));
MR_define_label(mercury__eval__next_object_id_3_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__next_object_id_3_0));
	MR_stackvar(1) = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_global_object_counter_0;
	MR_r5 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_int_0;
	MR_r3 = (MR_Integer) 0;
	MR_r4 = ((MR_Integer) MR_stackvar(1) + (MR_Integer) 1);
	MR_call_localret(MR_ENTRY(mercury__globals__set_4_0),
		mercury__eval__next_object_id_3_0_i3,
		MR_STATIC(mercury__eval__next_object_id_3_0));
MR_define_label(mercury__eval__next_object_id_3_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__next_object_id_3_0));
	MR_r6 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_r6;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate 'extra_operator_mode'/2 in mode 0 */
MR_define_static(mercury__eval__extra_operator_mode_2_0);
	MR_incr_sp_push_msg(1, "eval:extra_operator_mode/2");
	MR_stackvar(1) = (MR_Word) MR_succip;
	{
	MR_Word	A;
	MR_Word	B;
#define	MR_PROC_LABEL	mercury__eval__extra_operator_mode_2_0
	A = MR_r1;
	MR_save_registers();
	MR_OBTAIN_GLOBAL_LOCK("extra_operator_mode");
{
#line 605 "eval.m"
B = A;}
#line 6727 "eval.c"
	MR_RELEASE_GLOBAL_LOCK("extra_operator_mode");
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r1 = B;
#undef	MR_PROC_LABEL

	}
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
/* code for predicate 'do_extra'/6 in mode 0 */
MR_define_static(mercury__eval__do_extra_6_0);
	MR_incr_sp_push_msg(4, "eval:do_extra/6");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	{
	MR_Word	A;
	MR_Word	B;
#define	MR_PROC_LABEL	mercury__eval__do_extra_6_0
	A = MR_r1;
	MR_save_registers();
	MR_OBTAIN_GLOBAL_LOCK("extra_operator_mode");
{
#line 605 "eval.m"
B = A;}
#line 6756 "eval.c"
	MR_RELEASE_GLOBAL_LOCK("extra_operator_mode");
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r1 = B;
#undef	MR_PROC_LABEL

	}
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury__eval__do_extra2_6_0,
		MR_STATIC(mercury__eval__do_extra_6_0));
/* code for predicate 'do_extra2'/6 in mode 0 */
MR_define_static(mercury__eval__do_extra2_6_0);
	MR_incr_sp_push_msg(4, "eval:do_extra2/6");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury__eval__do_extra2_6_0_i4) MR_AND
		MR_LABEL(mercury__eval__do_extra2_6_0_i9) MR_AND
		MR_LABEL(mercury__eval__do_extra2_6_0_i16) MR_AND
		MR_LABEL(mercury__eval__do_extra2_6_0_i19));
MR_define_label(mercury__eval__do_extra2_6_0_i4);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_extra2_6_0_i5);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__eval__do_extra2_6_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_r3;
	MR_r2 = MR_r4;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__eval__do_extra2_6_0_i5);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i42),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i9);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__popn_3_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i12),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_extra2_6_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__eval__do_extra2_6_0_i10);
	}
	MR_r1 = MR_r2;
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__eval__do_extra2_6_0_i10);
	MR_r2 = MR_stackvar(1);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_stackvar(2);
	MR_tempr2 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr2;
	MR_r1 = MR_r2;
	MR_r2 = MR_tempr1;
	}
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i42),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i16);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_r1 = MR_r4;
	MR_localcall(mercury__eval__next_object_id_3_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i17),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i17);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_extra2_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_extra2_6_0, "eval:surface/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(0), (MR_Integer) 1, mercury__eval__do_extra2_6_0, "eval:basic_object/0");
	MR_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__do_extra2_6_0, "eval:object/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_extra2_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_stackvar(3) = MR_r2;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i42),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i19);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0),
		MR_LABEL(mercury__eval__do_extra2_6_0_i20) MR_AND
		MR_LABEL(mercury__eval__do_extra2_6_0_i23) MR_AND
		MR_LABEL(mercury__eval__do_extra2_6_0_i26) MR_AND
		MR_LABEL(mercury__eval__do_extra2_6_0_i29) MR_AND
		MR_LABEL(mercury__eval__do_extra2_6_0_i32) MR_AND
		MR_LABEL(mercury__eval__do_extra2_6_0_i34) MR_AND
		MR_LABEL(mercury__eval__do_extra2_6_0_i44));
MR_define_label(mercury__eval__do_extra2_6_0_i20);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_r4;
	MR_localcall(mercury__eval__next_object_id_3_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i21),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i21);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_extra2_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_extra2_6_0, "eval:surface/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_extra2_6_0, "eval:basic_object/0");
	MR_field(MR_mktag(3), MR_tempr2, (MR_Integer) 0) = (MR_Integer) 1;
	MR_field(MR_mktag(3), MR_tempr2, (MR_Integer) 1) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__do_extra2_6_0, "eval:object/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_extra2_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_stackvar(3) = MR_r2;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i42),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i23);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_r4;
	MR_localcall(mercury__eval__next_object_id_3_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i24),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i24);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_extra2_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_extra2_6_0, "eval:surface/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_extra2_6_0, "eval:basic_object/0");
	MR_field(MR_mktag(3), MR_tempr2, (MR_Integer) 0) = (MR_Integer) 0;
	MR_field(MR_mktag(3), MR_tempr2, (MR_Integer) 1) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__do_extra2_6_0, "eval:object/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_extra2_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_stackvar(3) = MR_r2;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i42),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i26);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_r4;
	MR_localcall(mercury__eval__next_object_id_3_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i27),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i27);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_extra2_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_extra2_6_0, "eval:surface/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_extra2_6_0, "eval:basic_object/0");
	MR_field(MR_mktag(1), MR_tempr2, (MR_Integer) 0) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__do_extra2_6_0, "eval:object/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_extra2_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_stackvar(3) = MR_r2;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i42),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i29);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_r4;
	MR_localcall(mercury__eval__next_object_id_3_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i30),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i30);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_extra2_6_0));
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval__do_extra2_6_0, "eval:surface/0");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(2), (MR_Integer) 1, mercury__eval__do_extra2_6_0, "eval:basic_object/0");
	MR_field(MR_mktag(2), MR_tempr2, (MR_Integer) 0) = MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__eval__do_extra2_6_0, "eval:object/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_extra2_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 0) = (MR_Integer) 4;
	MR_field(MR_mktag(3), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_stackvar(3) = MR_r2;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i42),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i32);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 2, mercury__eval__do_extra2_6_0, "eval:value/0");
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 3;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_r3;
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i42),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i34);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__do_extra2_6_0_i35);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__eval__do_extra2_6_0_i35);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	if (((MR_Integer) MR_tempr1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__eval__do_extra2_6_0_i39);
	}
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	}
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i42),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i39);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_localcall(mercury__fn__eval__push_2_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i42),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i35);
	MR_stackvar(3) = MR_r4;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval__eval_error_2_0,
		MR_LABEL(mercury__eval__do_extra2_6_0_i42),
		MR_STATIC(mercury__eval__do_extra2_6_0));
MR_define_label(mercury__eval__do_extra2_6_0_i42);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_extra2_6_0));
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury__eval__do_extra2_6_0_i44);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r6 = MR_r4;
	MR_r4 = MR_r2;
	MR_r5 = MR_r3;
	MR_r2 = (MR_Integer) 3;
	MR_r3 = (MR_Integer) 3;
	MR_set_prof_ho_caller_proc(MR_STATIC(mercury__eval__do_extra2_6_0));
	MR_noprof_call_localret(MR_ENTRY(mercury__do_call_closure),
		mercury__eval__do_extra2_6_0_i45);
MR_define_label(mercury__eval__do_extra2_6_0_i45);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval__do_extra2_6_0));
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate 'popn'/3 in mode 0 */
MR_define_static(mercury__eval__popn_3_0);
	MR_incr_sp_push_msg(1, "eval:popn/3");
	MR_stackvar(1) = (MR_Word) MR_succip;
MR_define_label(mercury__eval__popn_3_0_i15);
	while (1) {
	if (((MR_Integer) MR_r1 <= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__eval__popn_3_0_i6);
	}
	if (((MR_Integer) MR_r2 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__popn_3_0_i1);
	}
	MR_r1 = ((MR_Integer) MR_r1 - (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	if (((MR_Integer) MR_r1 <= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__eval__popn_3_0_i6);
	}
	if (((MR_Integer) MR_r2 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval__popn_3_0_i1);
	}
	MR_r1 = ((MR_Integer) MR_r1 - (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	/* continue */ } /* end while */
MR_define_label(mercury__eval__popn_3_0_i6);
	MR_r1 = TRUE;
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
MR_define_label(mercury__eval__popn_3_0_i1);
	MR_r1 = FALSE;
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
/* code for predicate 'empty_stack'/3 in mode 0 */
MR_define_static(mercury__eval__empty_stack_3_0);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 4, mercury__eval__empty_stack_3_0, "eval:stack_env_token_exception/0");
	MR_r4 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) MR_string_const("empty stack", 11);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r2;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_stack_env_token_exception_0;
	MR_r2 = MR_tempr1;
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_STATIC(mercury__eval__empty_stack_3_0));
	}
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__value_0_0);
	MR_incr_sp_push_msg(3, "eval:__Unify__/2");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Unify___eval__value_0_0_i4) MR_AND
		MR_LABEL(mercury____Unify___eval__value_0_0_i6) MR_AND
		MR_LABEL(mercury____Unify___eval__value_0_0_i8) MR_AND
		MR_LABEL(mercury____Unify___eval__value_0_0_i10));
MR_define_label(mercury____Unify___eval__value_0_0_i4);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___eval__value_0_0_i1);
	}
	MR_r4 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r5 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r1 = (MR_r4 == MR_r5);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Unify___eval__value_0_0_i6);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___eval__value_0_0_i1);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r6 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_r1 = (MR_r5 == MR_r6);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Unify___eval__value_0_0_i8);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Unify___eval__value_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 0);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r4));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Unify___eval__value_0_0_i10);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0),
		MR_LABEL(mercury____Unify___eval__value_0_0_i11) MR_AND
		MR_LABEL(mercury____Unify___eval__value_0_0_i13) MR_AND
		MR_LABEL(mercury____Unify___eval__value_0_0_i19) MR_AND
		MR_LABEL(mercury____Unify___eval__value_0_0_i23) MR_AND
		MR_LABEL(mercury____Unify___eval__value_0_0_i27) MR_AND
		MR_LABEL(mercury____Unify___eval__value_0_0_i31));
MR_define_label(mercury____Unify___eval__value_0_0_i11);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__value_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_r1 = (strcmp((char *)MR_r3, (char *)MR_r4) == 0);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Unify___eval__value_0_0_i13);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__value_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 2);
	MR_r5 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r6 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r3 = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(3), MR_r6, (MR_Integer) 1);
	MR_call_localret(MR_ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___eval__value_0_0_i15,
		MR_ENTRY(mercury____Unify___eval__value_0_0));
MR_define_label(mercury____Unify___eval__value_0_0_i15);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__value_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__value_0_0_i1);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___eval__value_0_0));
MR_define_label(mercury____Unify___eval__value_0_0_i19);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 2)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__value_0_0_i1);
	}
	MR_r4 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r5 = MR_r2;
	MR_r2 = MR_const_field(MR_mktag(3), MR_r4, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(3), MR_r5, (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___array__array_1_0),
		MR_ENTRY(mercury____Unify___eval__value_0_0));
MR_define_label(mercury____Unify___eval__value_0_0_i23);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__value_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		MR_ENTRY(mercury____Unify___eval__value_0_0));
MR_define_label(mercury____Unify___eval__value_0_0_i27);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__value_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_localtailcall(mercury____Unify___eval__object_0_0,
		MR_ENTRY(mercury____Unify___eval__value_0_0));
MR_define_label(mercury____Unify___eval__value_0_0_i31);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 5)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__value_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_localtailcall(mercury____Unify___eval__light_0_0,
		MR_ENTRY(mercury____Unify___eval__value_0_0));
MR_define_label(mercury____Unify___eval__value_0_0_i1);
	MR_r1 = FALSE;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate '__Index__'/2 in mode 0 */
MR_define_entry(mercury____Index___eval__value_0_0);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Index___eval__value_0_0_i4) MR_AND
		MR_LABEL(mercury____Index___eval__value_0_0_i5) MR_AND
		MR_LABEL(mercury____Index___eval__value_0_0_i6) MR_AND
		MR_LABEL(mercury____Index___eval__value_0_0_i7));
MR_define_label(mercury____Index___eval__value_0_0_i4);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Index___eval__value_0_0_i5);
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Index___eval__value_0_0_i6);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Index___eval__value_0_0_i7);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0),
		MR_LABEL(mercury____Index___eval__value_0_0_i8) MR_AND
		MR_LABEL(mercury____Index___eval__value_0_0_i9) MR_AND
		MR_LABEL(mercury____Index___eval__value_0_0_i10) MR_AND
		MR_LABEL(mercury____Index___eval__value_0_0_i11) MR_AND
		MR_LABEL(mercury____Index___eval__value_0_0_i12) MR_AND
		MR_LABEL(mercury____Index___eval__value_0_0_i13));
MR_define_label(mercury____Index___eval__value_0_0_i8);
	MR_r1 = (MR_Integer) 3;
	MR_proceed();
MR_define_label(mercury____Index___eval__value_0_0_i9);
	MR_r1 = (MR_Integer) 4;
	MR_proceed();
MR_define_label(mercury____Index___eval__value_0_0_i10);
	MR_r1 = (MR_Integer) 5;
	MR_proceed();
MR_define_label(mercury____Index___eval__value_0_0_i11);
	MR_r1 = (MR_Integer) 6;
	MR_proceed();
MR_define_label(mercury____Index___eval__value_0_0_i12);
	MR_r1 = (MR_Integer) 7;
	MR_proceed();
MR_define_label(mercury____Index___eval__value_0_0_i13);
	MR_r1 = (MR_Integer) 8;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__value_0_0);
	MR_incr_sp_push_msg(4, "eval:__Compare__/3");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_localcall(mercury____Index___eval__value_0_0,
		MR_LABEL(mercury____Compare___eval__value_0_0_i2),
		MR_ENTRY(mercury____Compare___eval__value_0_0));
MR_define_label(mercury____Compare___eval__value_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__value_0_0));
	MR_stackvar(3) = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_localcall(mercury____Index___eval__value_0_0,
		MR_LABEL(mercury____Compare___eval__value_0_0_i3),
		MR_ENTRY(mercury____Compare___eval__value_0_0));
MR_define_label(mercury____Compare___eval__value_0_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__value_0_0));
	if (((MR_Integer) MR_stackvar(3) >= (MR_Integer) MR_r1)) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i4);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___eval__value_0_0_i4);
	if (((MR_Integer) MR_stackvar(3) <= (MR_Integer) MR_r1)) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i5);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___eval__value_0_0_i5);
	MR_r4 = MR_stackvar(1);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r4),
		MR_LABEL(mercury____Compare___eval__value_0_0_i10) MR_AND
		MR_LABEL(mercury____Compare___eval__value_0_0_i16) MR_AND
		MR_LABEL(mercury____Compare___eval__value_0_0_i22) MR_AND
		MR_LABEL(mercury____Compare___eval__value_0_0_i28));
MR_define_label(mercury____Compare___eval__value_0_0_i10);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i7);
	}
	MR_r5 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_r6 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	if (((MR_Integer) MR_r6 >= (MR_Integer) MR_r5)) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i12);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___eval__value_0_0_i12);
	if ((MR_r6 != MR_r5)) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i70);
	}
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___eval__value_0_0_i16);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i7);
	}
	MR_r5 = MR_const_field(MR_mktag(1), MR_stackvar(2), (MR_Integer) 0);
	MR_r6 = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 0);
	if (((MR_Integer) MR_r6 >= (MR_Integer) MR_r5)) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i18);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___eval__value_0_0_i18);
	if ((MR_r6 != MR_r5)) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i70);
	}
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___eval__value_0_0_i22);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i7);
	}
	MR_r3 = MR_const_field(MR_mktag(2), MR_stackvar(2), (MR_Integer) 0);
	MR_r5 = MR_const_field(MR_mktag(2), MR_r4, (MR_Integer) 0);
	if ((MR_word_to_float(MR_r5) >= MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i24);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___eval__value_0_0_i24);
	if ((MR_word_to_float(MR_r5) <= MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i74);
	}
MR_define_label(mercury____Compare___eval__value_0_0_i70);
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___eval__value_0_0_i28);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_const_field(MR_mktag(3), MR_r4, (MR_Integer) 0),
		MR_LABEL(mercury____Compare___eval__value_0_0_i29) MR_AND
		MR_LABEL(mercury____Compare___eval__value_0_0_i36) MR_AND
		MR_LABEL(mercury____Compare___eval__value_0_0_i44) MR_AND
		MR_LABEL(mercury____Compare___eval__value_0_0_i47) MR_AND
		MR_LABEL(mercury____Compare___eval__value_0_0_i50) MR_AND
		MR_LABEL(mercury____Compare___eval__value_0_0_i53));
MR_define_label(mercury____Compare___eval__value_0_0_i29);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i7);
	}
	MR_r3 = MR_const_field(MR_mktag(3), MR_r4, (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	{
	MR_Integer	Res;
	MR_String	S1;
	MR_String	S2;
#define	MR_PROC_LABEL	mercury____Compare___eval__value_0_0
	S1 = (MR_String) MR_r3;
	S2 = (MR_String) MR_r4;
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);;}
#line 7403 "eval.c"
	MR_r3 = Res;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r3 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i31);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___eval__value_0_0_i31);
	if (((MR_Integer) MR_r3 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i70);
	}
MR_define_label(mercury____Compare___eval__value_0_0_i74);
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___eval__value_0_0_i36);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i7);
	}
	MR_r5 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 2);
	MR_r6 = MR_const_field(MR_mktag(3), MR_r4, (MR_Integer) 2);
	MR_stackvar(1) = MR_r6;
	MR_r7 = MR_stackvar(2);
	MR_stackvar(2) = MR_r5;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r3 = MR_const_field(MR_mktag(3), MR_r4, (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(3), MR_r7, (MR_Integer) 1);
	MR_call_localret(MR_ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___eval__value_0_0_i39,
		MR_ENTRY(mercury____Compare___eval__value_0_0));
MR_define_label(mercury____Compare___eval__value_0_0_i39);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__value_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i59);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___eval__value_0_0));
MR_define_label(mercury____Compare___eval__value_0_0_i44);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 2)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i7);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r2 = MR_const_field(MR_mktag(3), MR_r4, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury____Compare___array__array_1_0),
		MR_ENTRY(mercury____Compare___eval__value_0_0));
MR_define_label(mercury____Compare___eval__value_0_0_i47);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i7);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r4, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		MR_ENTRY(mercury____Compare___eval__value_0_0));
MR_define_label(mercury____Compare___eval__value_0_0_i50);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 4)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i7);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r4, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury____Compare___eval__object_0_0,
		MR_ENTRY(mercury____Compare___eval__value_0_0));
MR_define_label(mercury____Compare___eval__value_0_0_i53);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 5)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__value_0_0_i7);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r4, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_localtailcall(mercury____Compare___eval__light_0_0,
		MR_ENTRY(mercury____Compare___eval__value_0_0));
MR_define_label(mercury____Compare___eval__value_0_0_i7);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury__compare_error_0_0),
		MR_ENTRY(mercury____Compare___eval__value_0_0));
MR_define_label(mercury____Compare___eval__value_0_0_i59);
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__color_0_0);
	MR_tailcall(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		MR_ENTRY(mercury____Unify___eval__color_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__color_0_0);
	MR_tailcall(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		MR_ENTRY(mercury____Compare___eval__color_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__array_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_tailcall(MR_ENTRY(mercury____Unify___array__array_1_0),
		MR_ENTRY(mercury____Unify___eval__array_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__array_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_tailcall(MR_ENTRY(mercury____Compare___array__array_1_0),
		MR_ENTRY(mercury____Compare___eval__array_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__light_0_0);
	MR_incr_sp_push_msg(9, "eval:__Unify__/2");
	MR_stackvar(9) = (MR_Word) MR_succip;
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___eval__light_0_0_i4);
	}
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Unify___eval__light_0_0_i10);
	}
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___eval__light_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		mercury____Unify___eval__light_0_0_i19,
		MR_ENTRY(mercury____Unify___eval__light_0_0));
MR_define_label(mercury____Unify___eval__light_0_0_i19);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__light_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__light_0_0_i1);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_tailcall(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		MR_ENTRY(mercury____Unify___eval__light_0_0));
MR_define_label(mercury____Unify___eval__light_0_0_i10);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Unify___eval__light_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 4);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		mercury____Unify___eval__light_0_0_i12,
		MR_ENTRY(mercury____Unify___eval__light_0_0));
MR_define_label(mercury____Unify___eval__light_0_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__light_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__light_0_0_i1);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(5);
	MR_call_localret(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		mercury____Unify___eval__light_0_0_i14,
		MR_ENTRY(mercury____Unify___eval__light_0_0));
MR_define_label(mercury____Unify___eval__light_0_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__light_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__light_0_0_i1);
	}
	MR_r1 = MR_stackvar(2);
	MR_r2 = MR_stackvar(6);
	MR_call_localret(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		mercury____Unify___eval__light_0_0_i16,
		MR_ENTRY(mercury____Unify___eval__light_0_0));
MR_define_label(mercury____Unify___eval__light_0_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__light_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__light_0_0_i1);
	}
	if ((MR_word_to_float(MR_stackvar(3)) != MR_word_to_float(MR_stackvar(7)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__light_0_0_i1);
	}
	MR_r1 = (MR_word_to_float(MR_stackvar(4)) == MR_word_to_float(MR_stackvar(8)));
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury____Unify___eval__light_0_0_i4);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___eval__light_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		mercury____Unify___eval__light_0_0_i6,
		MR_ENTRY(mercury____Unify___eval__light_0_0));
MR_define_label(mercury____Unify___eval__light_0_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__light_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__light_0_0_i1);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_tailcall(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		MR_ENTRY(mercury____Unify___eval__light_0_0));
MR_define_label(mercury____Unify___eval__light_0_0_i1);
	MR_r1 = FALSE;
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__light_0_0);
	MR_incr_sp_push_msg(9, "eval:__Compare__/3");
	MR_stackvar(9) = (MR_Word) MR_succip;
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i4);
	}
	if ((MR_tag(MR_r1) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i15);
	}
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i76);
	}
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i76);
	}
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		mercury____Compare___eval__light_0_0_i57,
		MR_ENTRY(mercury____Compare___eval__light_0_0));
MR_define_label(mercury____Compare___eval__light_0_0_i57);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__light_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i2);
	}
	MR_r1 = MR_stackvar(2);
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_tailcall(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		MR_ENTRY(mercury____Compare___eval__light_0_0));
MR_define_label(mercury____Compare___eval__light_0_0_i15);
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i79);
	}
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i19);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury____Compare___eval__light_0_0_i19);
	MR_stackvar(8) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 4);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		mercury____Compare___eval__light_0_0_i21,
		MR_ENTRY(mercury____Compare___eval__light_0_0));
MR_define_label(mercury____Compare___eval__light_0_0_i21);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__light_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i2);
	}
	MR_r1 = MR_stackvar(8);
	MR_r2 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		mercury____Compare___eval__light_0_0_i25,
		MR_ENTRY(mercury____Compare___eval__light_0_0));
MR_define_label(mercury____Compare___eval__light_0_0_i25);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__light_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i2);
	}
	MR_r1 = MR_stackvar(7);
	MR_r2 = MR_stackvar(2);
	MR_call_localret(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		mercury____Compare___eval__light_0_0_i29,
		MR_ENTRY(mercury____Compare___eval__light_0_0));
MR_define_label(mercury____Compare___eval__light_0_0_i29);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__light_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i2);
	}
	if ((MR_word_to_float(MR_stackvar(6)) >= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i34);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i33);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury____Compare___eval__light_0_0_i34);
	if ((MR_word_to_float(MR_stackvar(6)) <= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i33);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i33);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury____Compare___eval__light_0_0_i33);
	if ((MR_word_to_float(MR_stackvar(5)) >= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i44);
	}
MR_define_label(mercury____Compare___eval__light_0_0_i76);
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury____Compare___eval__light_0_0_i44);
	if ((MR_word_to_float(MR_stackvar(5)) <= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i45);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury____Compare___eval__light_0_0_i45);
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury____Compare___eval__light_0_0_i4);
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i7);
	}
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i76);
	}
MR_define_label(mercury____Compare___eval__light_0_0_i79);
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
MR_define_label(mercury____Compare___eval__light_0_0_i7);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		mercury____Compare___eval__light_0_0_i9,
		MR_ENTRY(mercury____Compare___eval__light_0_0));
MR_define_label(mercury____Compare___eval__light_0_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__light_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__light_0_0_i2);
	}
	MR_r1 = MR_stackvar(2);
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_tailcall(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		MR_ENTRY(mercury____Compare___eval__light_0_0));
MR_define_label(mercury____Compare___eval__light_0_0_i2);
	MR_succip = (MR_Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__degrees_0_0);
	MR_r1 = (MR_word_to_float(MR_r1) == MR_word_to_float(MR_r2));
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__degrees_0_0);
	if ((MR_word_to_float(MR_r1) >= MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury____Compare___eval__degrees_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___eval__degrees_0_0_i2);
	if ((MR_word_to_float(MR_r1) <= MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury____Compare___eval__degrees_0_0_i3);
	}
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Compare___eval__degrees_0_0_i3);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__object_id_0_0);
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__object_id_0_0);
	if (((MR_Integer) MR_r1 >= (MR_Integer) MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_id_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___eval__object_id_0_0_i2);
	if ((MR_r1 != MR_r2)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_id_0_0_i3);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___eval__object_id_0_0_i3);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__object_0_0);
	MR_incr_sp_push_msg(3, "eval:__Unify__/2");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Unify___eval__object_0_0_i4) MR_AND
		MR_LABEL(mercury____Unify___eval__object_0_0_i10) MR_AND
		MR_LABEL(mercury____Unify___eval__object_0_0_i16) MR_AND
		MR_LABEL(mercury____Unify___eval__object_0_0_i22));
MR_define_label(mercury____Unify___eval__object_0_0_i4);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___eval__object_0_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((MR_tempr1 != MR_tempr2)) {
		MR_GOTO_LABEL(mercury____Unify___eval__object_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	}
	MR_localcall(mercury____Unify___eval__basic_object_0_0,
		MR_LABEL(mercury____Unify___eval__object_0_0_i6),
		MR_ENTRY(mercury____Unify___eval__object_0_0));
MR_define_label(mercury____Unify___eval__object_0_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__object_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__object_0_0_i1);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_light_0;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___eval__object_0_0));
MR_define_label(mercury____Unify___eval__object_0_0_i10);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___eval__object_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_localcall(mercury____Unify___eval__object_0_0,
		MR_LABEL(mercury____Unify___eval__object_0_0_i12),
		MR_ENTRY(mercury____Unify___eval__object_0_0));
MR_define_label(mercury____Unify___eval__object_0_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__object_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__object_0_0_i1);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_localtailcall(mercury____Unify___eval__transformation_0_0,
		MR_ENTRY(mercury____Unify___eval__object_0_0));
MR_define_label(mercury____Unify___eval__object_0_0_i16);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Unify___eval__object_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 0);
	MR_localcall(mercury____Unify___eval__object_0_0,
		MR_LABEL(mercury____Unify___eval__object_0_0_i18),
		MR_ENTRY(mercury____Unify___eval__object_0_0));
MR_define_label(mercury____Unify___eval__object_0_0_i18);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__object_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__object_0_0_i1);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Unify___eval__object_0_0_i4) MR_AND
		MR_LABEL(mercury____Unify___eval__object_0_0_i10) MR_AND
		MR_LABEL(mercury____Unify___eval__object_0_0_i16) MR_AND
		MR_LABEL(mercury____Unify___eval__object_0_0_i22));
MR_define_label(mercury____Unify___eval__object_0_0_i22);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Unify___eval__object_0_0_i23);
	}
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__object_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_localcall(mercury____Unify___eval__object_0_0,
		MR_LABEL(mercury____Unify___eval__object_0_0_i25),
		MR_ENTRY(mercury____Unify___eval__object_0_0));
MR_define_label(mercury____Unify___eval__object_0_0_i25);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__object_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__object_0_0_i1);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Unify___eval__object_0_0_i4) MR_AND
		MR_LABEL(mercury____Unify___eval__object_0_0_i10) MR_AND
		MR_LABEL(mercury____Unify___eval__object_0_0_i16) MR_AND
		MR_LABEL(mercury____Unify___eval__object_0_0_i22));
MR_define_label(mercury____Unify___eval__object_0_0_i23);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__object_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_localcall(mercury____Unify___eval__object_0_0,
		MR_LABEL(mercury____Unify___eval__object_0_0_i30),
		MR_ENTRY(mercury____Unify___eval__object_0_0));
MR_define_label(mercury____Unify___eval__object_0_0_i30);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__object_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__object_0_0_i1);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Unify___eval__object_0_0_i4) MR_AND
		MR_LABEL(mercury____Unify___eval__object_0_0_i10) MR_AND
		MR_LABEL(mercury____Unify___eval__object_0_0_i16) MR_AND
		MR_LABEL(mercury____Unify___eval__object_0_0_i22));
MR_define_label(mercury____Unify___eval__object_0_0_i1);
	MR_r1 = FALSE;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate '__Index__'/2 in mode 0 */
MR_define_entry(mercury____Index___eval__object_0_0);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Index___eval__object_0_0_i4) MR_AND
		MR_LABEL(mercury____Index___eval__object_0_0_i5) MR_AND
		MR_LABEL(mercury____Index___eval__object_0_0_i6) MR_AND
		MR_LABEL(mercury____Index___eval__object_0_0_i7));
MR_define_label(mercury____Index___eval__object_0_0_i4);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Index___eval__object_0_0_i5);
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Index___eval__object_0_0_i6);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Index___eval__object_0_0_i7);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Index___eval__object_0_0_i8);
	}
	MR_r1 = (MR_Integer) 3;
	MR_proceed();
MR_define_label(mercury____Index___eval__object_0_0_i8);
	MR_r1 = (MR_Integer) 4;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__object_0_0);
	MR_incr_sp_push_msg(5, "eval:__Compare__/3");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Compare___eval__object_0_0_i4) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i5) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i6) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i7));
MR_define_label(mercury____Compare___eval__object_0_0_i4);
	MR_r3 = (MR_Integer) 0;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r2),
		MR_LABEL(mercury____Compare___eval__object_0_0_i11) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i12) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i13) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i14));
MR_define_label(mercury____Compare___eval__object_0_0_i5);
	MR_r3 = (MR_Integer) 1;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r2),
		MR_LABEL(mercury____Compare___eval__object_0_0_i11) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i12) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i13) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i14));
MR_define_label(mercury____Compare___eval__object_0_0_i6);
	MR_r3 = (MR_Integer) 2;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r2),
		MR_LABEL(mercury____Compare___eval__object_0_0_i11) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i12) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i13) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i14));
MR_define_label(mercury____Compare___eval__object_0_0_i7);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i8);
	}
	MR_r3 = (MR_Integer) 3;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r2),
		MR_LABEL(mercury____Compare___eval__object_0_0_i11) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i12) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i13) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i14));
MR_define_label(mercury____Compare___eval__object_0_0_i8);
	MR_r3 = (MR_Integer) 4;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r2),
		MR_LABEL(mercury____Compare___eval__object_0_0_i11) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i12) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i13) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i14));
MR_define_label(mercury____Compare___eval__object_0_0_i11);
	MR_r4 = (MR_Integer) 0;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i16);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__object_0_0_i12);
	MR_r4 = (MR_Integer) 1;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i16);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__object_0_0_i13);
	MR_r4 = (MR_Integer) 2;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i16);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__object_0_0_i14);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i15);
	}
	MR_r4 = (MR_Integer) 3;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i16);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__object_0_0_i15);
	MR_r4 = (MR_Integer) 4;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i16);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__object_0_0_i16);
	if (((MR_Integer) MR_r3 <= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i17);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__object_0_0_i17);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Compare___eval__object_0_0_i22) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i43) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i51) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i59));
MR_define_label(mercury____Compare___eval__object_0_0_i22);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i19);
	}
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if (((MR_Integer) MR_r2 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i26);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i25);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__object_0_0_i26);
	if ((MR_r2 == MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i25);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i25);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__object_0_0_i25);
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(3);
	MR_localcall(mercury____Compare___eval__basic_object_0_0,
		MR_LABEL(mercury____Compare___eval__object_0_0_i37),
		MR_ENTRY(mercury____Compare___eval__object_0_0));
MR_define_label(mercury____Compare___eval__object_0_0_i37);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__object_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i78);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_light_0;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(4);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___eval__object_0_0));
MR_define_label(mercury____Compare___eval__object_0_0_i43);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i19);
	}
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_localcall(mercury____Compare___eval__object_0_0,
		MR_LABEL(mercury____Compare___eval__object_0_0_i46),
		MR_ENTRY(mercury____Compare___eval__object_0_0));
MR_define_label(mercury____Compare___eval__object_0_0_i46);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__object_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i78);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_localtailcall(mercury____Compare___eval__transformation_0_0,
		MR_ENTRY(mercury____Compare___eval__object_0_0));
MR_define_label(mercury____Compare___eval__object_0_0_i51);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i19);
	}
	MR_stackvar(2) = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 0);
	MR_localcall(mercury____Compare___eval__object_0_0,
		MR_LABEL(mercury____Compare___eval__object_0_0_i54),
		MR_ENTRY(mercury____Compare___eval__object_0_0));
MR_define_label(mercury____Compare___eval__object_0_0_i54);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__object_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i78);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Compare___eval__object_0_0_i4) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i5) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i6) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i7));
MR_define_label(mercury____Compare___eval__object_0_0_i59);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i60);
	}
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i19);
	}
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_localcall(mercury____Compare___eval__object_0_0,
		MR_LABEL(mercury____Compare___eval__object_0_0_i63),
		MR_ENTRY(mercury____Compare___eval__object_0_0));
MR_define_label(mercury____Compare___eval__object_0_0_i63);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__object_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i78);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Compare___eval__object_0_0_i4) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i5) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i6) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i7));
MR_define_label(mercury____Compare___eval__object_0_0_i60);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i19);
	}
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_localcall(mercury____Compare___eval__object_0_0,
		MR_LABEL(mercury____Compare___eval__object_0_0_i70),
		MR_ENTRY(mercury____Compare___eval__object_0_0));
MR_define_label(mercury____Compare___eval__object_0_0_i70);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__object_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__object_0_0_i78);
	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Compare___eval__object_0_0_i4) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i5) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i6) MR_AND
		MR_LABEL(mercury____Compare___eval__object_0_0_i7));
MR_define_label(mercury____Compare___eval__object_0_0_i19);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_tailcall(MR_ENTRY(mercury__compare_error_0_0),
		MR_ENTRY(mercury____Compare___eval__object_0_0));
MR_define_label(mercury____Compare___eval__object_0_0_i78);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__basic_object_0_0);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Unify___eval__basic_object_0_0_i4) MR_AND
		MR_LABEL(mercury____Unify___eval__basic_object_0_0_i8) MR_AND
		MR_LABEL(mercury____Unify___eval__basic_object_0_0_i12) MR_AND
		MR_LABEL(mercury____Unify___eval__basic_object_0_0_i16));
MR_define_label(mercury____Unify___eval__basic_object_0_0_i4);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___eval__basic_object_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Unify___eval__surface_0_0,
		MR_ENTRY(mercury____Unify___eval__basic_object_0_0));
MR_define_label(mercury____Unify___eval__basic_object_0_0_i8);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___eval__basic_object_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Unify___eval__surface_0_0,
		MR_ENTRY(mercury____Unify___eval__basic_object_0_0));
MR_define_label(mercury____Unify___eval__basic_object_0_0_i12);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Unify___eval__basic_object_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Unify___eval__surface_0_0,
		MR_ENTRY(mercury____Unify___eval__basic_object_0_0));
MR_define_label(mercury____Unify___eval__basic_object_0_0_i16);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Unify___eval__basic_object_0_0_i17);
	}
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__basic_object_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_localtailcall(mercury____Unify___eval__surface_0_0,
		MR_ENTRY(mercury____Unify___eval__basic_object_0_0));
MR_define_label(mercury____Unify___eval__basic_object_0_0_i17);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__basic_object_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_localtailcall(mercury____Unify___eval__surface_0_0,
		MR_ENTRY(mercury____Unify___eval__basic_object_0_0));
MR_define_label(mercury____Unify___eval__basic_object_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Index__'/2 in mode 0 */
MR_define_entry(mercury____Index___eval__basic_object_0_0);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Index___eval__basic_object_0_0_i4) MR_AND
		MR_LABEL(mercury____Index___eval__basic_object_0_0_i5) MR_AND
		MR_LABEL(mercury____Index___eval__basic_object_0_0_i6) MR_AND
		MR_LABEL(mercury____Index___eval__basic_object_0_0_i7));
MR_define_label(mercury____Index___eval__basic_object_0_0_i4);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Index___eval__basic_object_0_0_i5);
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Index___eval__basic_object_0_0_i6);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Index___eval__basic_object_0_0_i7);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Index___eval__basic_object_0_0_i8);
	}
	MR_r1 = (MR_Integer) 3;
	MR_proceed();
MR_define_label(mercury____Index___eval__basic_object_0_0_i8);
	MR_r1 = (MR_Integer) 4;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__basic_object_0_0);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i4) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i5) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i6) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i7));
MR_define_label(mercury____Compare___eval__basic_object_0_0_i4);
	MR_r3 = (MR_Integer) 0;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r2),
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i11) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i12) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i13) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i14));
MR_define_label(mercury____Compare___eval__basic_object_0_0_i5);
	MR_r3 = (MR_Integer) 1;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r2),
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i11) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i12) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i13) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i14));
MR_define_label(mercury____Compare___eval__basic_object_0_0_i6);
	MR_r3 = (MR_Integer) 2;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r2),
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i11) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i12) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i13) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i14));
MR_define_label(mercury____Compare___eval__basic_object_0_0_i7);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i8);
	}
	MR_r3 = (MR_Integer) 3;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r2),
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i11) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i12) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i13) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i14));
MR_define_label(mercury____Compare___eval__basic_object_0_0_i8);
	MR_r3 = (MR_Integer) 4;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r2),
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i11) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i12) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i13) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i14));
MR_define_label(mercury____Compare___eval__basic_object_0_0_i11);
	MR_r4 = (MR_Integer) 0;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i16);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___eval__basic_object_0_0_i12);
	MR_r4 = (MR_Integer) 1;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i16);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___eval__basic_object_0_0_i13);
	MR_r4 = (MR_Integer) 2;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i16);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___eval__basic_object_0_0_i14);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i15);
	}
	MR_r4 = (MR_Integer) 3;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i16);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___eval__basic_object_0_0_i15);
	MR_r4 = (MR_Integer) 4;
	if (((MR_Integer) MR_r3 >= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i16);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___eval__basic_object_0_0_i16);
	if (((MR_Integer) MR_r3 <= (MR_Integer) MR_r4)) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i17);
	}
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Compare___eval__basic_object_0_0_i17);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i22) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i25) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i28) MR_AND
		MR_LABEL(mercury____Compare___eval__basic_object_0_0_i31));
MR_define_label(mercury____Compare___eval__basic_object_0_0_i22);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i115);
	}
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Compare___eval__surface_0_0,
		MR_ENTRY(mercury____Compare___eval__basic_object_0_0));
MR_define_label(mercury____Compare___eval__basic_object_0_0_i25);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i115);
	}
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Compare___eval__surface_0_0,
		MR_ENTRY(mercury____Compare___eval__basic_object_0_0));
MR_define_label(mercury____Compare___eval__basic_object_0_0_i28);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i115);
	}
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Compare___eval__surface_0_0,
		MR_ENTRY(mercury____Compare___eval__basic_object_0_0));
MR_define_label(mercury____Compare___eval__basic_object_0_0_i31);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i32);
	}
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i115);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_localtailcall(mercury____Compare___eval__surface_0_0,
		MR_ENTRY(mercury____Compare___eval__basic_object_0_0));
MR_define_label(mercury____Compare___eval__basic_object_0_0_i32);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__basic_object_0_0_i115);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_localtailcall(mercury____Compare___eval__surface_0_0,
		MR_ENTRY(mercury____Compare___eval__basic_object_0_0));
MR_define_label(mercury____Compare___eval__basic_object_0_0_i115);
	MR_tailcall(MR_ENTRY(mercury__compare_error_0_0),
		MR_ENTRY(mercury____Compare___eval__basic_object_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__transformation_0_0);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Unify___eval__transformation_0_0_i4) MR_AND
		MR_LABEL(mercury____Unify___eval__transformation_0_0_i6) MR_AND
		MR_LABEL(mercury____Unify___eval__transformation_0_0_i8) MR_AND
		MR_LABEL(mercury____Unify___eval__transformation_0_0_i10));
MR_define_label(mercury____Unify___eval__transformation_0_0_i4);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r4));
	MR_proceed();
	}
MR_define_label(mercury____Unify___eval__transformation_0_0_i6);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 2);
	MR_r4 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 2);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r4));
	MR_proceed();
	}
MR_define_label(mercury____Unify___eval__transformation_0_0_i8);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 0);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r4));
	MR_proceed();
MR_define_label(mercury____Unify___eval__transformation_0_0_i10);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i11);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i13);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i15);
	}
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i1);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_tailcall(MR_ENTRY(mercury____Unify___trans__trans_0_0),
		MR_ENTRY(mercury____Unify___eval__transformation_0_0));
MR_define_label(mercury____Unify___eval__transformation_0_0_i15);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 2)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r4));
	MR_proceed();
MR_define_label(mercury____Unify___eval__transformation_0_0_i13);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r4));
	MR_proceed();
MR_define_label(mercury____Unify___eval__transformation_0_0_i11);
	if (!(((MR_tag(MR_r2) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) == (MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__transformation_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r4));
	MR_proceed();
MR_define_label(mercury____Unify___eval__transformation_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Index__'/2 in mode 0 */
MR_define_entry(mercury____Index___eval__transformation_0_0);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury____Index___eval__transformation_0_0_i4) MR_AND
		MR_LABEL(mercury____Index___eval__transformation_0_0_i5) MR_AND
		MR_LABEL(mercury____Index___eval__transformation_0_0_i6) MR_AND
		MR_LABEL(mercury____Index___eval__transformation_0_0_i7));
MR_define_label(mercury____Index___eval__transformation_0_0_i4);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Index___eval__transformation_0_0_i5);
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Index___eval__transformation_0_0_i6);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Index___eval__transformation_0_0_i7);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Index___eval__transformation_0_0_i8);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Index___eval__transformation_0_0_i9);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Index___eval__transformation_0_0_i10);
	}
	MR_r1 = (MR_Integer) 6;
	MR_proceed();
MR_define_label(mercury____Index___eval__transformation_0_0_i10);
	MR_r1 = (MR_Integer) 5;
	MR_proceed();
MR_define_label(mercury____Index___eval__transformation_0_0_i9);
	MR_r1 = (MR_Integer) 4;
	MR_proceed();
MR_define_label(mercury____Index___eval__transformation_0_0_i8);
	MR_r1 = (MR_Integer) 3;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__transformation_0_0);
	MR_incr_sp_push_msg(5, "eval:__Compare__/3");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_localcall(mercury____Index___eval__transformation_0_0,
		MR_LABEL(mercury____Compare___eval__transformation_0_0_i2),
		MR_ENTRY(mercury____Compare___eval__transformation_0_0));
MR_define_label(mercury____Compare___eval__transformation_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__transformation_0_0));
	MR_stackvar(3) = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_localcall(mercury____Index___eval__transformation_0_0,
		MR_LABEL(mercury____Compare___eval__transformation_0_0_i3),
		MR_ENTRY(mercury____Compare___eval__transformation_0_0));
MR_define_label(mercury____Compare___eval__transformation_0_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__transformation_0_0));
	if (((MR_Integer) MR_stackvar(3) >= (MR_Integer) MR_r1)) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i4);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i4);
	if (((MR_Integer) MR_stackvar(3) <= (MR_Integer) MR_r1)) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i5);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i5);
	MR_r3 = MR_stackvar(1);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r3),
		MR_LABEL(mercury____Compare___eval__transformation_0_0_i10) MR_AND
		MR_LABEL(mercury____Compare___eval__transformation_0_0_i42) MR_AND
		MR_LABEL(mercury____Compare___eval__transformation_0_0_i74) MR_AND
		MR_LABEL(mercury____Compare___eval__transformation_0_0_i80));
MR_define_label(mercury____Compare___eval__transformation_0_0_i10);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i7);
	}
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2);
	MR_r5 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1);
	MR_r6 = MR_const_field(MR_mktag(0), MR_stackvar(2), (MR_Integer) 0);
	MR_r7 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	if ((MR_word_to_float(MR_r7) >= MR_word_to_float(MR_r6))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i14);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i13);
	}
	MR_stackvar(1) = MR_r5;
	MR_stackvar(2) = MR_r4;
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i14);
	if ((MR_word_to_float(MR_r7) <= MR_word_to_float(MR_r6))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i13);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i13);
	}
	MR_stackvar(1) = MR_r5;
	MR_stackvar(2) = MR_r4;
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i13);
	if ((MR_word_to_float(MR_r5) >= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i26);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i25);
	}
	MR_stackvar(2) = MR_r4;
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i26);
	if ((MR_word_to_float(MR_r5) <= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i25);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i25);
	}
	MR_stackvar(2) = MR_r4;
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i25);
	if ((MR_word_to_float(MR_r4) >= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i36);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i36);
	if ((MR_word_to_float(MR_r4) <= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i84);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i42);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i7);
	}
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_stackvar(2), (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_stackvar(2), (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 2);
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r6 = MR_const_field(MR_mktag(1), MR_stackvar(2), (MR_Integer) 0);
	MR_r7 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_word_to_float(MR_r7) >= MR_word_to_float(MR_r6))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i46);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i45);
	}
	MR_stackvar(1) = MR_r5;
	MR_stackvar(2) = MR_r4;
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i46);
	if ((MR_word_to_float(MR_r7) <= MR_word_to_float(MR_r6))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i45);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i45);
	}
	MR_stackvar(1) = MR_r5;
	MR_stackvar(2) = MR_r4;
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i45);
	if ((MR_word_to_float(MR_r5) >= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i58);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i57);
	}
	MR_stackvar(2) = MR_r4;
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i58);
	if ((MR_word_to_float(MR_r5) <= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i57);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i57);
	}
	MR_stackvar(2) = MR_r4;
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i57);
	if ((MR_word_to_float(MR_r4) >= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i68);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i68);
	if ((MR_word_to_float(MR_r4) <= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i84);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i74);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i7);
	}
	MR_r4 = MR_const_field(MR_mktag(2), MR_stackvar(2), (MR_Integer) 0);
	MR_r5 = MR_const_field(MR_mktag(2), MR_r3, (MR_Integer) 0);
	if ((MR_word_to_float(MR_r5) >= MR_word_to_float(MR_r4))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i76);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i76);
	if ((MR_word_to_float(MR_r5) <= MR_word_to_float(MR_r4))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i84);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i80);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 0) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i81);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 0) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i87);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 0) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i93);
	}
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 3)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i7);
	}
	MR_r1 = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_tailcall(MR_ENTRY(mercury____Compare___trans__trans_0_0),
		MR_ENTRY(mercury____Compare___eval__transformation_0_0));
MR_define_label(mercury____Compare___eval__transformation_0_0_i93);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 2)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i7);
	}
	MR_r4 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_r5 = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 1);
	if ((MR_word_to_float(MR_r5) >= MR_word_to_float(MR_r4))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i95);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i95);
	if ((MR_word_to_float(MR_r5) <= MR_word_to_float(MR_r4))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i84);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i87);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i7);
	}
	MR_r4 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_r5 = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 1);
	if ((MR_word_to_float(MR_r5) >= MR_word_to_float(MR_r4))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i89);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i89);
	if ((MR_word_to_float(MR_r5) <= MR_word_to_float(MR_r4))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i84);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i81);
	if (!(((MR_tag(MR_stackvar(2)) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 0) == (MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i7);
	}
	MR_r4 = MR_const_field(MR_mktag(3), MR_stackvar(2), (MR_Integer) 1);
	MR_r5 = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 1);
	if ((MR_word_to_float(MR_r5) >= MR_word_to_float(MR_r4))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i83);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i83);
	if ((MR_word_to_float(MR_r5) <= MR_word_to_float(MR_r4))) {
		MR_GOTO_LABEL(mercury____Compare___eval__transformation_0_0_i84);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i84);
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__transformation_0_0_i7);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_tailcall(MR_ENTRY(mercury__compare_error_0_0),
		MR_ENTRY(mercury____Compare___eval__transformation_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__surface_0_0);
	MR_incr_sp_push_msg(7, "eval:__Unify__/2");
	MR_stackvar(7) = (MR_Word) MR_succip;
	if ((MR_tag(MR_r1) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___eval__surface_0_0_i3);
	}
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___eval__surface_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r5 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r6 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___eval__surface_0_0_i5,
		MR_ENTRY(mercury____Unify___eval__surface_0_0));
MR_define_label(mercury____Unify___eval__surface_0_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__surface_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__surface_0_0_i1);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___eval__surface_0_0));
MR_define_label(mercury____Unify___eval__surface_0_0_i3);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___eval__surface_0_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r3 = MR_tempr1;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 3);
	MR_tempr2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_r4 = MR_tempr2;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 3);
	MR_r1 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_tempr2, (MR_Integer) 0);
	}
	MR_call_localret(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		mercury____Unify___eval__surface_0_0_i10,
		MR_ENTRY(mercury____Unify___eval__surface_0_0));
MR_define_label(mercury____Unify___eval__surface_0_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__surface_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__surface_0_0_i1);
	}
	if ((MR_word_to_float(MR_stackvar(1)) != MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__surface_0_0_i1);
	}
	if ((MR_word_to_float(MR_stackvar(2)) != MR_word_to_float(MR_stackvar(5)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__surface_0_0_i1);
	}
	MR_r1 = (MR_word_to_float(MR_stackvar(3)) == MR_word_to_float(MR_stackvar(6)));
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
MR_define_label(mercury____Unify___eval__surface_0_0_i1);
	MR_r1 = FALSE;
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__surface_0_0);
	if ((MR_tag(MR_r1) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_0_0_i3);
	}
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_0_0_i5);
	}
	MR_incr_sp_push_msg(3, "eval:__Compare__/3");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r5 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r6 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___eval__surface_0_0_i7,
		MR_ENTRY(mercury____Compare___eval__surface_0_0));
MR_define_label(mercury____Compare___eval__surface_0_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__surface_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_0_0_i2);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___eval__surface_0_0));
MR_define_label(mercury____Compare___eval__surface_0_0_i5);
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___eval__surface_0_0_i3);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_0_0_i13);
	}
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Compare___eval__surface_0_0_i13);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_localtailcall(mercury____Compare___eval__surface_properties_0_0,
		MR_ENTRY(mercury____Compare___eval__surface_0_0));
MR_define_label(mercury____Compare___eval__surface_0_0_i2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__surface_properties_0_0);
	MR_incr_sp_push_msg(7, "eval:__Unify__/2");
	MR_stackvar(7) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		mercury____Unify___eval__surface_properties_0_0_i2,
		MR_ENTRY(mercury____Unify___eval__surface_properties_0_0));
MR_define_label(mercury____Unify___eval__surface_properties_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__surface_properties_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__surface_properties_0_0_i1);
	}
	if ((MR_word_to_float(MR_stackvar(1)) != MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__surface_properties_0_0_i1);
	}
	if ((MR_word_to_float(MR_stackvar(2)) != MR_word_to_float(MR_stackvar(5)))) {
		MR_GOTO_LABEL(mercury____Unify___eval__surface_properties_0_0_i1);
	}
	MR_r1 = (MR_word_to_float(MR_stackvar(3)) == MR_word_to_float(MR_stackvar(6)));
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
MR_define_label(mercury____Unify___eval__surface_properties_0_0_i1);
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__surface_properties_0_0);
	MR_incr_sp_push_msg(7, "eval:__Compare__/3");
	MR_stackvar(7) = (MR_Word) MR_succip;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		mercury____Compare___eval__surface_properties_0_0_i3,
		MR_ENTRY(mercury____Compare___eval__surface_properties_0_0));
MR_define_label(mercury____Compare___eval__surface_properties_0_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__surface_properties_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_properties_0_0_i36);
	}
	if ((MR_word_to_float(MR_stackvar(1)) >= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_properties_0_0_i8);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_properties_0_0_i7);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
MR_define_label(mercury____Compare___eval__surface_properties_0_0_i8);
	if ((MR_word_to_float(MR_stackvar(1)) <= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_properties_0_0_i7);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_properties_0_0_i7);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
MR_define_label(mercury____Compare___eval__surface_properties_0_0_i7);
	if ((MR_word_to_float(MR_stackvar(2)) >= MR_word_to_float(MR_stackvar(5)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_properties_0_0_i20);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_properties_0_0_i19);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
MR_define_label(mercury____Compare___eval__surface_properties_0_0_i20);
	if ((MR_word_to_float(MR_stackvar(2)) <= MR_word_to_float(MR_stackvar(5)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_properties_0_0_i19);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_properties_0_0_i19);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
MR_define_label(mercury____Compare___eval__surface_properties_0_0_i19);
	if ((MR_word_to_float(MR_stackvar(3)) >= MR_word_to_float(MR_stackvar(6)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_properties_0_0_i30);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
MR_define_label(mercury____Compare___eval__surface_properties_0_0_i30);
	if ((MR_word_to_float(MR_stackvar(3)) <= MR_word_to_float(MR_stackvar(6)))) {
		MR_GOTO_LABEL(mercury____Compare___eval__surface_properties_0_0_i31);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
MR_define_label(mercury____Compare___eval__surface_properties_0_0_i31);
	MR_r1 = (MR_Integer) 0;
MR_define_label(mercury____Compare___eval__surface_properties_0_0_i36);
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__env_0_0);
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r4 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_tailcall(MR_ENTRY(mercury____Unify___tree234__tree234_2_0),
		MR_ENTRY(mercury____Unify___eval__env_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__env_0_0);
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r4 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_tailcall(MR_ENTRY(mercury____Compare___tree234__tree234_2_0),
		MR_ENTRY(mercury____Compare___eval__env_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__id_0_0);
	MR_r1 = (strcmp((char *)MR_r1, (char *)MR_r2) == 0);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__id_0_0);
	{
	MR_Integer	Res;
	MR_String	S1;
	MR_String	S2;
#define	MR_PROC_LABEL	mercury____Compare___eval__id_0_0
	S1 = (MR_String) MR_r1;
	S2 = (MR_String) MR_r2;
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);;}
#line 9202 "eval.c"
	MR_r2 = Res;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r2 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__id_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___eval__id_0_0_i2);
	if (((MR_Integer) MR_r2 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__id_0_0_i3);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___eval__id_0_0_i3);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__stack_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___eval__stack_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__stack_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___eval__stack_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__code_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___eval__code_0_0));
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__code_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_group_0;
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___eval__code_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__stack_env_exception_0_0);
	MR_incr_sp_push_msg(3, "eval:__Unify__/2");
	MR_stackvar(3) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((strcmp((char *)MR_tempr1, (char *)MR_tempr2) != 0)) {
		MR_GOTO_LABEL(mercury____Unify___eval__stack_env_exception_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r5 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r6 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 1);
	}
	MR_call_localret(MR_ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___eval__stack_env_exception_0_0_i2,
		MR_ENTRY(mercury____Unify___eval__stack_env_exception_0_0));
MR_define_label(mercury____Unify___eval__stack_env_exception_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__stack_env_exception_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__stack_env_exception_0_0_i1);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___eval__stack_env_exception_0_0));
MR_define_label(mercury____Unify___eval__stack_env_exception_0_0_i1);
	MR_r1 = FALSE;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__stack_env_exception_0_0);
	MR_incr_sp_push_msg(5, "eval:__Compare__/3");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	{
	MR_Integer	Res;
	MR_String	S1;
	MR_String	S2;
#define	MR_PROC_LABEL	mercury____Compare___eval__stack_env_exception_0_0
	S1 = (MR_String) MR_r3;
	S2 = (MR_String) MR_r4;
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);;}
#line 9309 "eval.c"
	MR_r2 = Res;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r2 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__stack_env_exception_0_0_i4);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__stack_env_exception_0_0_i3);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__stack_env_exception_0_0_i4);
	if (((MR_Integer) MR_r2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__stack_env_exception_0_0_i3);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__stack_env_exception_0_0_i3);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval__stack_env_exception_0_0_i3);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r3 = MR_stackvar(1);
	MR_r4 = MR_stackvar(3);
	MR_call_localret(MR_ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___eval__stack_env_exception_0_0_i16,
		MR_ENTRY(mercury____Compare___eval__stack_env_exception_0_0));
MR_define_label(mercury____Compare___eval__stack_env_exception_0_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__stack_env_exception_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__stack_env_exception_0_0_i21);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(4);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___eval__stack_env_exception_0_0));
MR_define_label(mercury____Compare___eval__stack_env_exception_0_0_i21);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__stack_env_token_exception_0_0);
	MR_incr_sp_push_msg(5, "eval:__Unify__/2");
	MR_stackvar(5) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((strcmp((char *)MR_tempr1, (char *)MR_tempr2) != 0)) {
		MR_GOTO_LABEL(mercury____Unify___eval__stack_env_token_exception_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_r5 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r6 = MR_r2;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 1);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 1);
	}
	MR_call_localret(MR_ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___eval__stack_env_token_exception_0_0_i2,
		MR_ENTRY(mercury____Unify___eval__stack_env_token_exception_0_0));
MR_define_label(mercury____Unify___eval__stack_env_token_exception_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__stack_env_token_exception_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__stack_env_token_exception_0_0_i1);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(3);
	MR_call_localret(MR_ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___eval__stack_env_token_exception_0_0_i4,
		MR_ENTRY(mercury____Unify___eval__stack_env_token_exception_0_0));
MR_define_label(mercury____Unify___eval__stack_env_token_exception_0_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval__stack_env_token_exception_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval__stack_env_token_exception_0_0_i1);
	}
	MR_r1 = MR_stackvar(2);
	MR_r2 = MR_stackvar(4);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_tailcall(MR_ENTRY(mercury____Unify___gml__token_0_0),
		MR_ENTRY(mercury____Unify___eval__stack_env_token_exception_0_0));
MR_define_label(mercury____Unify___eval__stack_env_token_exception_0_0_i1);
	MR_r1 = FALSE;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__stack_env_token_exception_0_0);
	MR_incr_sp_push_msg(7, "eval:__Compare__/3");
	MR_stackvar(7) = (MR_Word) MR_succip;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	{
	MR_Integer	Res;
	MR_String	S1;
	MR_String	S2;
#define	MR_PROC_LABEL	mercury____Compare___eval__stack_env_token_exception_0_0
	S1 = (MR_String) MR_r3;
	S2 = (MR_String) MR_r4;
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);;}
#line 9433 "eval.c"
	MR_r2 = Res;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r2 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__stack_env_token_exception_0_0_i4);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__stack_env_token_exception_0_0_i3);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
MR_define_label(mercury____Compare___eval__stack_env_token_exception_0_0_i4);
	if (((MR_Integer) MR_r2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__stack_env_token_exception_0_0_i3);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__stack_env_token_exception_0_0_i3);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
MR_define_label(mercury____Compare___eval__stack_env_token_exception_0_0_i3);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r3 = MR_stackvar(1);
	MR_r4 = MR_stackvar(4);
	MR_call_localret(MR_ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___eval__stack_env_token_exception_0_0_i16,
		MR_ENTRY(mercury____Compare___eval__stack_env_token_exception_0_0));
MR_define_label(mercury____Compare___eval__stack_env_token_exception_0_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__stack_env_token_exception_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__stack_env_token_exception_0_0_i26);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(5);
	MR_call_localret(MR_ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___eval__stack_env_token_exception_0_0_i20,
		MR_ENTRY(mercury____Compare___eval__stack_env_token_exception_0_0));
MR_define_label(mercury____Compare___eval__stack_env_token_exception_0_0_i20);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval__stack_env_token_exception_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__stack_env_token_exception_0_0_i26);
	}
	MR_r1 = MR_stackvar(3);
	MR_r2 = MR_stackvar(6);
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_tailcall(MR_ENTRY(mercury____Compare___gml__token_0_0),
		MR_ENTRY(mercury____Compare___eval__stack_env_token_exception_0_0));
MR_define_label(mercury____Compare___eval__stack_env_token_exception_0_0_i26);
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__program_error_0_0);
	if ((MR_tag(MR_r1) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___eval__program_error_0_0_i3);
	}
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Unify___eval__program_error_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r1 = (strcmp((char *)MR_r3, (char *)MR_r1) == 0);
	MR_proceed();
MR_define_label(mercury____Unify___eval__program_error_0_0_i3);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury____Unify___eval__program_error_0_0_i1);
	}
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	if ((strcmp((char *)MR_tempr1, (char *)MR_tempr2) != 0)) {
		MR_GOTO_LABEL(mercury____Unify___eval__program_error_0_0_i1);
	}
	MR_r4 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r5 = MR_r2;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r5, (MR_Integer) 1);
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___eval__program_error_0_0));
	}
MR_define_label(mercury____Unify___eval__program_error_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__program_error_0_0);
	MR_incr_sp_push_msg(3, "eval:__Compare__/3");
	MR_stackvar(3) = (MR_Word) MR_succip;
	if ((MR_tag(MR_r1) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___eval__program_error_0_0_i3);
	}
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___eval__program_error_0_0_i36);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	{
	MR_Integer	Res;
	MR_String	S1;
	MR_String	S2;
#define	MR_PROC_LABEL	mercury____Compare___eval__program_error_0_0
	S1 = (MR_String) MR_r3;
	S2 = (MR_String) MR_r4;
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);;}
#line 9549 "eval.c"
	MR_r2 = Res;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r2 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__program_error_0_0_i6);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Compare___eval__program_error_0_0_i6);
	if (((MR_Integer) MR_r2 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__program_error_0_0_i38);
	}
	MR_r1 = (MR_Integer) 0;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Compare___eval__program_error_0_0_i3);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury____Compare___eval__program_error_0_0_i12);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Compare___eval__program_error_0_0_i12);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	{
	MR_Integer	Res;
	MR_String	S1;
	MR_String	S2;
#define	MR_PROC_LABEL	mercury____Compare___eval__program_error_0_0
	S1 = (MR_String) MR_r3;
	S2 = (MR_String) MR_r4;
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);;}
#line 9592 "eval.c"
	MR_r2 = Res;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r2 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__program_error_0_0_i15);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__program_error_0_0_i14);
	}
MR_define_label(mercury____Compare___eval__program_error_0_0_i36);
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Compare___eval__program_error_0_0_i15);
	if (((MR_Integer) MR_r2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__program_error_0_0_i14);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval__program_error_0_0_i14);
	}
MR_define_label(mercury____Compare___eval__program_error_0_0_i38);
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Compare___eval__program_error_0_0_i14);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___eval__program_error_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval__global_object_counter_0_0);
	MR_r1 = (MR_r1 == MR_r2);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval__global_object_counter_0_0);
	MR_r3 = MR_r2;
	MR_r2 = MR_r1;
	if (((MR_Integer) MR_r2 >= (MR_Integer) MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___eval__global_object_counter_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___eval__global_object_counter_0_0_i2);
	if ((MR_r2 != MR_r3)) {
		MR_GOTO_LABEL(mercury____Compare___eval__global_object_counter_0_0_i3);
	}
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
MR_define_label(mercury____Compare___eval__global_object_counter_0_0_i3);
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__eval_maybe_bunch_0(void)
{
	eval_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__eval__init(void);
void mercury__eval__init_type_tables(void);
void mercury__eval__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__eval__write_out_proc_statics(FILE *fp);
#endif

void mercury__eval__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__eval_maybe_bunch_0();
#endif

	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_value_0,
		eval__value_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_transformation_0,
		eval__transformation_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_surface_properties_0,
		eval__surface_properties_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_surface_0,
		eval__surface_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_stack_env_token_exception_0,
		eval__stack_env_token_exception_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_stack_env_exception_0,
		eval__stack_env_exception_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_stack_0,
		eval__stack_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_program_error_0,
		eval__program_error_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_object_id_0,
		eval__object_id_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_object_0,
		eval__object_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_light_0,
		eval__light_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_id_0,
		eval__id_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_global_object_counter_0,
		eval__global_object_counter_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_env_0,
		eval__env_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_degrees_0,
		eval__degrees_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_color_0,
		eval__color_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_code_0,
		eval__code_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_basic_object_0,
		eval__basic_object_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval__type_ctor_info_array_0,
		eval__array_0_0);
	mercury__eval__init_debugger();
}

void mercury__eval__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_value_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_transformation_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_surface_properties_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_surface_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_stack_env_token_exception_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_stack_env_exception_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_stack_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_program_error_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_object_id_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_object_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_light_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_id_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_global_object_counter_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_env_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_degrees_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_color_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_code_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_basic_object_0);
	MR_register_type_ctor_info(
		&mercury_data_eval__type_ctor_info_array_0);
}


void mercury__eval__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__eval__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
