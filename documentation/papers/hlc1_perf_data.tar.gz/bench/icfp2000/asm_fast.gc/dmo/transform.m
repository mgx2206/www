:- module transform.

:- interface.

:- import_module vec, float, ray.

:- type transform.

:- func '*'(transform, transform) = transform.

:- func transform_vec(transform, vec) = vec.
:- func transform_ray(transform, ray) = ray.

:- func inverse(transform) = transform.

:- func scale(vec) = transform.
:- func translate(vec) = transform.
:- func rotateX(float) = transform.
:- func rotateY(float) = transform.
:- func rotateZ(float) = transform.

:- implementation.

:- import_module math.

:- type transform ---> transform(matH, matH).

:- type vecH 
	---> vecH(float, float, float, float).
:- type matH 
	---> matH(vecH, vecH, vecH, vecH).


transform_vec(transform(matH(A, B, C, D), _), V) = 
		vec(vecH(dot(U, A), dot(U, B), dot(U, C), dot(U, D))) :-
	U = vecH(V).

transform_ray(T, R) = 
	ray(transform_vec(T, origin(R)), 
		transform_vec(no_translate(T), dir(R))).

scale(vec(ScaleX, ScaleY, ScaleZ)) = transform(Forward, Reverse) :-
	Forward = diagonal(vecH(ScaleX, ScaleY, ScaleZ, 1.0)),
	Reverse = diagonal(vecH(1.0/ScaleX, 1.0/ScaleY, 1.0/ScaleZ, 1.0)).

translate(Trans) = transform(Forward, Reverse) :-
	Forward = translate_2(Trans),
	Reverse = translate_2(-Trans).

:- func translate_2(vec) = matH.

translate_2(vec(X, Y, Z)) = 
	matH(
		vecH(1.0, 0.0, 0.0, X),
		vecH(0.0, 1.0, 0.0, Y),
		vecH(0.0, 0.0, 1.0, Z),
		vecH(0.0, 0.0, 0.0, 1.0)
	).

rotateX(Theta) = transform(Forward, Reverse) :-
	Forward = rotateX_2(Theta),
	Reverse = rotateX_2(-Theta).

:- func rotateX_2(float) = matH.

rotateX_2(Theta) =
	matH(
		vecH(1.0,        0.0,         0.0, 0.0),
		vecH(0.0, cos(Theta), -sin(Theta), 0.0),
		vecH(0.0, sin(Theta),  cos(Theta), 0.0),
		vecH(0.0,        0.0,         0.0, 1.0)
	).

rotateY(Theta) = transform(Forward, Reverse) :-
	Forward = rotateY_2(Theta),
	Reverse = rotateY_2(-Theta).

:- func rotateY_2(float) = matH.

rotateY_2(Theta) =
	matH(
		vecH( cos(Theta), 0.0, sin(Theta), 0.0),
		vecH(        0.0, 1.0,        0.0, 0.0),
		vecH(-sin(Theta), 0.0, cos(Theta), 0.0),
		vecH(        0.0, 0.0,        0.0, 1.0)
	).

rotateZ(Theta) = transform(Forward, Reverse) :-
	Forward = rotateZ_2(Theta),
	Reverse = rotateZ_2(-Theta).

:- func rotateZ_2(float) = matH.

rotateZ_2(Theta) =
	matH(
		vecH(cos(Theta), -sin(Theta), 0.0, 0.0),
		vecH(sin(Theta),  cos(Theta), 0.0, 0.0),
		vecH(       0.0,         0.0, 1.0, 0.0),
		vecH(       0.0,         0.0, 0.0, 1.0)
	).

transform(FA, RA) * transform(FB, RB) = transform(Forward, Reverse) :-
	Forward = mult(FA, FB),
	Reverse = mult(RB, RA).

inverse(transform(Forward, Reverse)) = transform(Reverse, Forward).

:- func no_translate(transform) = transform.

no_translate(transform(Forward, Reverse)) =
	transform(no_trans(Forward), no_trans(Reverse)).

:- func no_trans(matH) = matH.

no_trans(matH(	vecH(A, B, C, _),
		vecH(E, F, G, _),
		vecH(I, J, K, _),
		vecH(_, _, _, _)
	)) =
	matH(	vecH(A, B, C, 0.0),
		vecH(E, F, G, 0.0),
		vecH(I, J, K, 0.0),
		vecH(0.0, 0.0, 0.0, 1.0)
	).

:- func vecH(vec) = vecH.

vecH(vec(X, Y, Z)) = vecH(X, Y, Z, 1.0).

:- func vec(vecH) = vec.

vec(vecH(X, Y, Z, W)) = vec(X/W, Y/W, Z/W).

:- func transpose(matH) = matH.

transpose(matH( vecH(A, B, C, D), 
		vecH(E, F, G, H), 
		vecH(I, J, K, L),
		vecH(M, N, O, P)
	)) =
	matH(	vecH(A, E, I, M),
		vecH(B, F, J, N),
		vecH(C, G, K, O),
		vecH(D, H, L, P)
	).

:- func diagonal(vecH) = matH.

diagonal(vecH(X, Y, Z, W)) =
	matH(
		vecH(X, 0.0, 0.0, 0.0),
		vecH(0.0, Y, 0.0, 0.0),
		vecH(0.0, 0.0, Z, 0.0),
		vecH(0.0, 0.0, 0.0, W)
	).

:- func identity = matH.

identity = diagonal(vecH(1.0, 1.0, 1.0, 1.0)).

:- func dot(vecH, vecH) = float.

dot(vecH(Xa, Ya, Za, Wa), vecH(Xb, Yb, Zb, Wb)) = 
	Xa*Xb + Ya*Yb + Za*Zb + Wa*Wb.

:- func mult(matH, matH) = matH.

mult(V, U) = 
	matH(
		vecH(dot(V1,U1), dot(V2,U1), dot(V3,U1), dot(V4,U1)),
		vecH(dot(V1,U2), dot(V2,U2), dot(V3,U2), dot(V4,U2)),
		vecH(dot(V1,U3), dot(V2,U3), dot(V3,U3), dot(V4,U3)),
		vecH(dot(V1,U4), dot(V2,U4), dot(V3,U4), dot(V4,U4))
	) :-
	matH(V1, V2, V3, V4) = transpose(V),
	matH(U1, U2, U3, U4) = U.
