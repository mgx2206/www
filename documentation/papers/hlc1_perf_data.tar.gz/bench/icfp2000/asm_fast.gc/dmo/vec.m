:- module vec.
% a 3D vector module.

:- interface.

:- import_module float, std_util.

:- type vec	--->	vec(float, float, float).

:- func '+'(vec, vec) = vec.

:- func '-'(vec, vec) = vec.

:- func '-'(vec) = vec.

:- func dot(vec, vec) = float.

:- func cross(vec, vec) = vec.

:- func mag(vec) = float.

	% The square of the magnitude.
:- func mag2(vec) = float.

:- func unit(vec) = vec.

:- func scale(float, vec) = vec.

:- func angle(vec, vec) = float.

	% Project vector onto XY plane.
:- func projectXY(vec) = vec.

:- func projectXZ(vec) = vec.

:- func projectZY(vec) = vec.

	% Return a pair containing the X and Y coords of the vector.
:- func xy(vec) = pair(float).

:- func xz(vec) = pair(float).

:- func zy(vec) = pair(float).

	% Some useful constants.
:- func zero = vec.
:- func i = vec.
:- func j = vec.
:- func k = vec.

:- implementation.

:- import_module math.

vec(Ax, Ay, Az) + vec(Bx, By, Bz) = vec(Ax+Bx, Ay+By, Az+Bz).

vec(Ax, Ay, Az) - vec(Bx, By, Bz) = vec(Ax-Bx, Ay-By, Az-Bz).

-vec(X, Y, Z) = vec(-X, -Y, -Z).

dot(vec(Ax, Ay, Az), vec(Bx, By, Bz)) = Ax*Bx + Ay*By + Az*Bz.

cross(vec(Ax, Ay, Az), vec(Bx, By, Bz)) = vec(Cx, Cy, Cz) :-
	Cx = Ay*Bz - Az*By,
	Cy = Az*Bx - Ax*Bz,
	Cz = Ax*By - Ay*Bx.

mag(V) = math__sqrt(mag2(V)).

mag2(vec(Ax, Ay, Az)) = Ax*Ax + Ay*Ay + Az*Az.

unit(vec(Ax, Ay, Az)) = vec(Ax/Mag, Ay/Mag, Az/Mag) :-
	Mag = mag(vec(Ax, Ay, Az)).

scale(S, vec(Ax, Ay, Az)) = vec(S*Ax, S*Ay, S*Az).

% calculate angle between 2 vectors
angle(V1, V2) = math__acos(dot(V1, V2) / mag(V1) / mag(V2)).

projectXY(vec(X, Y, _)) = vec(X, Y, 0.0).

projectXZ(vec(X, _, Z)) = vec(X, 0.0, Z).

projectZY(vec(_, Y, Z)) = vec(0.0, Y, Z).

xy(vec(X, Y, _)) = X - Y.

xz(vec(X, _, Z)) = X - Z.

zy(vec(_, Y, Z)) = Z - Y.

zero = vec(0.0, 0.0, 0.0).
i = vec(1.0, 0.0, 0.0).
j = vec(0.0, 1.0, 0.0).
k = vec(0.0, 0.0, 1.0).
