:- module ppm_read.

:- interface.

:- import_module int, io.

:- type ppm.

:- type pixel.

:- func pixel(int, int, int) = pixel.
:- mode pixel(in, in, in) = out is det.
:- mode pixel(out, out, out) = in is det.

:- pred read_ppm(ppm, io__state, io__state).
:- mode read_ppm(out, di, uo) is det.

:- pred write_ppm(ppm, io__state, io__state).
:- mode write_ppm(in, di, uo) is det.

:- pred make_ppm(int, int, int, pixel, ppm).
:- mode make_ppm(in, in, in, in, out) is det.

:- pred ppm_read__dimensions(ppm, int, int, int).
:- mode ppm_read__dimensions(in, out, out, out) is det.

:- pred get_pixel(ppm, int, int, pixel).
:- mode get_pixel(in, in, in, out) is det.

:- pred set_pixel(ppm, int, int, pixel, ppm) is det.
:- mode set_pixel(in, in, in, in, out) is det.

:- implementation.

%------------------------------------------------------------------------------%

:- import_module char, list, map, require, string, array.

:- type pixel == int.

:- type ppm
	--->	ppm(
			int,
			int,
			int,
			array(pixel)
		).

:- pragma c_code(pixel(R::in, G::in, B::in) = (C::out),"
	C = ((R & 0xff) << 16) | ((G & 0xff) << 8) | (B & 0xff);
").

:- pragma c_code(pixel(R::out, G::out, B::out) = (C::in),"
	R = (C >> 16) & 0xff;
	G = (C >> 8) & 0xff;
	B = C & 0xff;
").

%------------------------------------------------------------------------------%

ppm_read__dimensions(PPM, Wdth, Hght, Dpth) :-
	PPM = ppm(Wdth, Hght, Dpth, _Map).

get_pixel(PPM, X, Y, Col) :-
	PPM = ppm(Xmax, _Ymax, _Dpth, Map),
	Z = X + (Y*Xmax),
%	string__format("get: (%d, %d) out of bounds (%d, %d) - linear address: %d",
%		[i(X), i(Y), i(Xmax), i(Ymax), i(Z)], Str),
%	req(((pred) is semidet :-
%		Z >= 0,
%		Z < Xmax*Ymax
%	), Str),
	array__lookup(Map, Z, Col).

set_pixel(PPM0, X, Y, Col, PPM) :-
	PPM0 = ppm(Xmax, Ymax, Dpth, Map0),
	Z = X + (Y*Xmax),
%	string__format("set: (%d, %d) out of bounds (%d, %d) - linear address: %d",
%		[i(X), i(Y), i(Xmax), i(Ymax), i(Z)], Str),
%	req(((pred) is semidet :-
%		Z >= 0,
%		Z < Xmax*Ymax
%	), Str),
	make_uniq(Map0, Map1),
	array__set(Map1, Z, Col, Map),
	PPM  = ppm(Xmax, Ymax, Dpth, Map).

:- pred req(pred, string).
:- mode req((pred) is semidet, in) is det.

req(Pred, Str) :-
	( call(Pred) ->
		true
	;
		error(Str)
	).

:- pred make_uniq(array(pixel), array(pixel)).
:- mode make_uniq(in, array_uo) is det.
:- pragma c_code(make_uniq(A::in, B::array_uo), "B = A;").

%------------------------------------------------------------------------------%

make_ppm(Wdth, Hght, Dpth, InitCol, PPM) :-
	array__init((Wdth+1)*(Hght+1), InitCol, PixMap),
	PPM = ppm(Wdth, Hght, Dpth, PixMap).

%------------------------------------------------------------------------------%

read_ppm(PPM) -->
	io__stderr_stream(StdErr),
	read_header,
	io__write_string(StdErr, "read header.\n"),
	read_dimensions(Wdth, Hght, Dpth),
	io__format(StdErr, "read dimensions (%d, %d, %d).\n",
		[i(Wdth), i(Hght), i(Dpth)]),
	{ array__init((Wdth+1)*(Hght+1), pixel(0, 0, 0), PixMap0) },
	{ PPM0 = ppm(Wdth, Hght, Dpth, PixMap0) },
	read_pixels(0, Wdth, 0, Hght, PPM0, PPM).

:- pred read_header(io__state, io__state).
:- mode read_header(di, uo) is det.

read_header -->
	io__read_word(Res),
	( { Res = ok(['P','3']) } ->
		[]
	;
		{ error("not a ppm") }
	).

:- pred read_dimensions(int, int, int, io__state, io__state).
:- mode read_dimensions(out, out, out, di, uo) is det.

read_dimensions(Wdth, Hght, Dpth) -->
	io__read_word(Res0),
	io__read_word(Res1),
	io__read_word(Res2),
	(
		{ Res0 = ok(Chars0), string__from_char_list(Chars0, Str0) },
		{ string__to_int(Str0, Int0) },
		{ Res1 = ok(Chars1), string__from_char_list(Chars1, Str1) },
		{ string__to_int(Str1, Int1) },
		{ Res2 = ok(Chars2), string__from_char_list(Chars2, Str2) },
		{ string__to_int(Str2, Int2) }
	->
		{ Wdth = Int0 },
		{ Hght = Int1 },
		{ Dpth = Int2 }
	;
		{ error("bad dimensions format") }
	).

:- pred read_pixels(int, int, int, int, ppm, ppm, io__state, io__state).
:- mode read_pixels(in, in, in, in, in, out, di, uo) is det.

read_pixels(X, Wdth, Y, Hght, PPM0, PPM) -->
	( { X  >= Wdth } ->
		% io__stderr_stream(StdErr),
		% { string__format("finished row %d\n", [i(Y)], Str) },
		% io__write_string(StdErr, Str),
		read_pixels(0, Wdth, Y+1, Hght, PPM0, PPM)
	; { Y >= Hght } ->
		{ PPM = PPM0 }
	;
		read_pixel(R, G, B),
		{ set_pixel(PPM0, X, Y, pixel(R, G, B), PPM1) },
		read_pixels(X+1, Wdth, Y, Hght, PPM1, PPM)
	).

:- pred read_pixel(int, int, int, io__state, io__state).
:- mode read_pixel(out, out, out, di, uo) is det.

read_pixel(R, G, B) -->
	io__read_word(Res0),
	io__read_word(Res1),
	io__read_word(Res2),
	(
		{ Res0 = ok(Chars0), string__from_char_list(Chars0, Str0) },
		{ string__to_int(Str0, Int0) },
		{ Res1 = ok(Chars1), string__from_char_list(Chars1, Str1) },
		{ string__to_int(Str1, Int1) },
		{ Res2 = ok(Chars2), string__from_char_list(Chars2, Str2) },
		{ string__to_int(Str2, Int2) }
	->
		{ R = Int0 },
		{ G = Int1 },
		{ B = Int2 }
	;
		{ error("bad pixel format") }
	).


%------------------------------------------------------------------------------%

write_ppm(PPM) -->
	write_header,
	{ PPM = ppm(Wdth, Hght, Dpth, _) },
	write_dimensions(Wdth, Hght, Dpth),
	write_pixels(0, Wdth, 0, Hght, PPM).

:- pred write_header(io__state, io__state).
:- mode write_header(di, uo) is det.

write_header -->
	io__write_string("P3\n").

:- pred write_dimensions(int, int, int, io__state, io__state).
:- mode write_dimensions(in, in, in, di, uo) is det.

write_dimensions(Wdth, Hght, Dpth) -->
	{ string__format("%d %d\n%d\n", [i(Wdth), i(Hght), i(Dpth)], Str) },
	io__write_string(Str).

:- pred write_pixels(int, int, int, int, ppm, io__state, io__state).
:- mode write_pixels(in, in, in, in, in, di, uo) is det.

write_pixels(X, Wdth, Y, Hght, PPM) -->
	( { X  >= Wdth } ->
		write_pixels(0, Wdth, Y+1, Hght, PPM)
	; { Y >= Hght } ->
		[]
	;
		{ get_pixel(PPM, X, Y, Pix) },
		{ Pix = pixel(R, G, B) },
		io__write_int(R), io__write_string(" "),
		io__write_int(G), io__write_string(" "),
		io__write_int(B), io__write_string("\n"),
		% { string__format("%d %d %d\n", [i(R), i(G), i(B)], Str) },
		% io__write_string(Str),
		write_pixels(X+1, Wdth, Y, Hght, PPM)
	).

%------------------------------------------------------------------------------%

