:- module shade.
:- interface.

:- import_module scene, ray, colour, vec, float, object.

	% Lights are modelled as points.
:- type light
	--->	light(
			float,	% Power in range [0.0, 1.0].
			vec	% Position of light.
		).

:- pred shade(scene, ray, ray, float, attributes, colour).
:- mode shade(in(scene), in, in, in, in, out) is det.

:- implementation.

:- import_module trace, list, math.

shade(Scene, Ray, Intersection, Contribution, Attributes, Colour) :-
	( Contribution =< minimum_contribution ->
		Colour = black
	;
		Colour0 = colour(Attributes),
		Ambient = scale(ambient(Scene), Colour0),
		/*
		list__map(shade_from_light(Scene, Ray, Intersection, Colour0),
			lights(Scene), Colours),
		list__foldl(add_colours, Colours, Ambient, Colour1),
		*/
		/*
		list__foldl((pred(L::in, C0::in, C::out) is det :-
			    shade_from_light(Scene, Ray, Intersection, Colour0,
				L, C1),
			    C = C0 + C1), 
			lights(Scene), Ambient, Colour1),
		*/
		shade_from_lights(Scene, Ray, Intersection, Colour0,
			lights(Scene), Ambient, Colour1),

		% Recursive ray-tracing for reflections.
		ReflectionCoeff = reflection(Attributes),
		(
			ReflectionCoeff * Contribution > minimum_contribution,
			ReflectionRay = reflect(Ray, Intersection),
			trace_ray(ReflectionRay, objects(Scene),
				ReflectIntersection, ReflectAttrs)
		->
			shade(Scene, ReflectionRay, ReflectIntersection,
				ReflectionCoeff * Contribution,
				ReflectAttrs, ReflectColour),
			Colour2 = Colour1 +
					scale(ReflectionCoeff, ReflectColour)
		;
			Colour2 = Colour1
		),

		Colour = Colour2

		/*
		% Now do refraction for transparent objects.
		Transmission = transmission(Attributes),
		( Transmission > 0.0 ->
			( dot(dir(Ray), dir(Intersection)) < 0.0 ->
				% Entering object.

			;
				% Leaving object
			)
		*/
	).


:- pred shade_from_lights(scene, ray, ray, colour, list(light), colour, colour).
:- mode shade_from_lights(in(scene), in, in, in, in, in, out) is det.

shade_from_lights(_, _, _, _, [], C, C).
shade_from_lights(Scene, Ray, Intersection, Colour0, [L | Ls], C0, C) :-
	shade_from_light(Scene, Ray, Intersection, Colour0, L, C1),
	shade_from_lights(Scene, Ray, Intersection, Colour0, Ls, C0 + C1, C).

:- pred shade_from_light(scene, ray, ray, colour, light, colour).
:- mode shade_from_light(in(scene), in, in, in, in, out) is det.

shade_from_light(Scene, Ray, Intersection, Colour0,
		light(LightPower, LightPosition), Colour) :-
	Point = origin(Intersection),
	Normal = dir(Intersection),
	L = unit(LightPosition - Point),
	Cos = dot(L, Normal),
	(
		% Make sure light is in front of face, not behind it.
		Cos > 0.0,

		% Make sure there are no objects between us and the light.
		\+ ( 
			intersection(ray(Point, L), objects(Scene), Int, _),
			mag2(origin(Int) - Point) < mag2(LightPosition - Point)
		)
	->
		Lambertian = scale(LightPower * Cos, Colour0),
		R = scale(2.0 * Cos, Normal) - L,
		Dot = dot(R, dir(Ray)),
		(
			( Dot =< 0.0 ; spec_coeff(Scene) =< 0.0 )
		->
			Specular = black
		;
			Specular = scale(
				spec_coeff(Scene) * pow(Dot, spec_exp(Scene)),
				white)
		),
		Colour = Lambertian + Specular
	;
		Colour = black
	).

:- func minimum_contribution = float.

minimum_contribution = 1.0 / 255.0.

:- func reflect(ray, ray) = ray.

reflect(Incident, Normal) = ray(origin(Normal), Dir) :-
	X = dot(dir(Incident), dir(Normal)),
	Dir = dir(Incident) + scale(-2.0 * X, dir(Normal)).
