:- module colour.

:- interface.

:- import_module float.

:- type colour ---> rgb(float, float, float).
		% rgb(Red, Green, Blue)

:- func default_colour = colour.
:- func white = colour.
:- func black = colour.
:- func red = colour.
:- func green = colour.
:- func blue = colour.
:- func cyan = colour.
:- func magenta = colour.
:- func yellow = colour.
:- func grey = colour.

	% Specify colour in HSV.
:- func hsv(float, float, float) = colour.

	% Add two colours together
:- func '+'(colour, colour) = colour.
:- pred add_colours(colour::in, colour::in, colour::out) is det.

	% Multiply a colour by a float.
:- func scale(float, colour) = colour.

:- implementation.

:- import_module require.

default_colour = white.
white = 	rgb(1.0, 1.0, 1.0).
black = 	rgb(0.0, 0.0, 0.0).
red = 		rgb(1.0, 0.0, 0.0).
green =		rgb(0.0, 1.0, 0.0).
blue =		rgb(0.0, 0.0, 1.0).
cyan =		rgb(0.0, 1.0, 1.0).
magenta =	rgb(1.0, 0.0, 1.0).
yellow =	rgb(1.0, 1.0, 0.0).
grey =		rgb(0.5, 0.5, 0.5).

	% This algorithm from Foley, et al, p 593.
hsv(H, S, V) =
		( S =< 0.0 ->
			rgb(V, V, V)
		;
			RGB
		) :-
	H1 = ( H >= 360.0 -> 0.0 ; H / 60.0 ),
	I = floor_to_int(H1),
	F = H1 - float(I),
	P = V * (1.0 - S),
	Q = V * (1.0 - S*F),
	T = V * (1.0 - S*(1.0 - F)),
	RGB = 
		( I = 0 -> 	rgb(V, T, P)
		; I = 1 -> 	rgb(Q, V, P)
		; I = 2 -> 	rgb(P, V, T)
		; I = 3 -> 	rgb(P, Q, V)
		; I = 4 -> 	rgb(T, P, V)
		; I = 5 -> 	rgb(V, P, Q)
		;
			error("Error converting HSV to RGB")
		).

rgb(Ra, Ga, Ba) + rgb(Rb, Gb, Bb) = 
		rgb(range(Ra + Rb), range(Ga + Gb), range(Ba + Bb)).

add_colours(C0, C1, C0 + C1).

scale(F, rgb(R, G, B)) = rgb(range(F * R), range(F * G), range(F * B)).

:- func range(float) = float.

range(F) =
	( F < 0.0 ->
		0.0
	; F > 1.0 ->
		1.0
	;
		F
	).

:- func error(string) = _.
:- mode error(in) = unused is erroneous.

error(Message) = _ :- error(Message).
