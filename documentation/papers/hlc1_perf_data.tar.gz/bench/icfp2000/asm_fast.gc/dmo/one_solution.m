%-----------------------------------------------------------------------------%
:- module one_solution.
	% This module contains predicates/functions that are potentially
	% unsafe if used improperly; there is no compile-time or even
	% run-time checking for these predicates/functions.
	% Beware that misuse of this module may lead to unsound results.
	% If you lie to the compiler, the compiler will get its revenge!

%-----------------------------------------------------------------------------%
:- interface.

	% A call to `promise_one_solution(Pred)' constitutes a promise
	% on the part of the caller that `Pred' has at most one
	% solution, i.e. that
	%       not some [X1, X2] (Pred(X1), Pred(X2), X1 \= X2).
	%
	% `promise_one_solution(Pred)' presumes that this assumption is
	% satisfied, and returns the X for which Pred(X) is true
	% (by assumption, there can be only one such X).
	%
:- func promise_only_solution(pred(T)) = T.
:- mode promise_only_solution(pred(out) is cc_multi) = out is det.
:- mode promise_only_solution(pred(out) is cc_nondet) = out is semidet.

%-----------------------------------------------------------------------------%
:- implementation.

promise_only_solution(Pred) = OutVal :-
	call(cc_cast(Pred), OutVal).

:- func cc_cast(pred(T)) = pred(T).
:- mode cc_cast(pred(out) is cc_nondet) = out(pred(out) is semidet) is det.
:- mode cc_cast(pred(out) is cc_multi) = out(pred(out) is det) is det.

:- pragma c_code(cc_cast(X::(pred(out) is cc_multi)) =
			(Y::out(pred(out) is det)),
		will_not_call_mercury,
		"Y = X;").
:- pragma c_code(cc_cast(X::(pred(out) is cc_nondet)) =
			(Y::out(pred(out) is semidet)),
		will_not_call_mercury,
		"Y = X;").

%-----------------------------------------------------------------------------%
