:- module trace.
:- interface.

:- import_module ray, object, list.

	% Return the intersection ray and colour of the first object that
	% the incident ray hits.
:- pred trace_ray(ray, list(object), ray, attributes).
:- mode trace_ray(in, in(list_skel(object)), out, out) is semidet.

	% Non-deterministically return an intersection between the incident
	% ray and an object.
:- pred intersection(ray, list(object), ray, attributes).
:- mode intersection(in, in(list_skel(object)), out, out) is nondet.

:- implementation.

:- import_module vec, one_solution, assoc_list, std_util, float.

trace_ray(Ray, Objects, Intersection, Attr) :-
	promise_only_solution(pred(Sol::out) is cc_multi :-
		unsorted_aggregate(
			maybe_intersection(Ray, Objects),
			closest(origin(Ray)),
			no, Sol)
		) = yes(Intersection - Attr).


intersection(Ray, Objects, Intersection, Attr) :-
	my_list_member(Object, Objects),
	Object(intersect(Ray, Intersection, Attr)).

	% XXX polymophic mode -- hopefully eventually to be placed in 
	% list.m.
:- pred my_list_member(T, list(T)).
:- mode my_list_member(out(I), in(list_skel(I))) is nondet.

my_list_member(X, [X | _]).
my_list_member(X, [_ | Xs]) :- my_list_member(X, Xs).

:- pred maybe_intersection(ray, list(object), maybe(pair(ray, attributes))).
:- mode maybe_intersection(in, in(list_skel(object)), out) is multi.

maybe_intersection(Ray, Objects, MaybeSolution) :-
	( intersection(Ray, Objects, Intersection, Attr) ->
		MaybeSolution = yes(Intersection - Attr)
	;
		MaybeSolution = no
	).

:- pred closest(vec, maybe(pair(ray, attributes)), maybe(pair(ray, attributes)),
		maybe(pair(ray, attributes))).
:- mode closest(in, in, in, out) is det.

closest(_, no, Solution, Solution).
closest(_, yes(Solution), no, yes(Solution)).
closest(Camera, yes(I0 - A0), yes(I1 - A1), yes(I - A)) :-
	compare(Res, mag2(origin(I0) - Camera), mag2(origin(I1) - Camera)),
	(
		Res = (<),
		I = I0, A = A0
	;
		Res = (>),
		I = I1, A = A1
	;
		% If the two objects are the same distance from the camera,
		% then we can't just pick either because that would mean
		% the call to `promise_only_solution', above, would be a lie.
		% We need some other way of selecting which object to used that
		% is not based on the order that the solutions were computed in.
		Res = (=),
		compare(Res2, A0 - I0, A1 - I1),
		(
			Res2 = (<),
			I = I1, A = A1
		;
			Res2 = (>),
			I = I0, A = A0
		;
			% If both objects have exactly the same intersection ray
			% and attributes then it really is ok to just
			% arbitrarily pick one.
			Res2 = (=),
			I = I0, A = A0
		)
	).
