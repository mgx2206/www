:- module scene.
:- interface.

:- import_module object, float, colour, shade, list.

:- type scene.

	% XXX abstract insts would be nice here.
:- inst scene
	--->	scene(
			list_skel(object),
			ground,
			ground,
			ground,
			ground,
			ground,
			ground
		).

:- func scene__init(list(object), list(light), float, float, float, float,
		colour) = scene.
:- mode scene__init(in(list_skel(object)), in, in, in, in, in, in)
		= out(scene) is det.

:- func objects(scene::in(scene)) =
		(list(object)::out(list_skel(object))) is det.

:- func lights(scene::in(scene)) = (list(light)::out) is det.
:- func ambient(scene::in(scene)) = (float::out) is det.
:- func spec_coeff(scene::in(scene)) = (float::out) is det.
:- func spec_exp(scene::in(scene)) = (float::out) is det.
:- func focal_length(scene::in(scene)) = (float::out) is det.
:- func background(scene::in(scene)) = (colour::out) is det.

:- implementation.

:- type scene
	--->	scene(
			list(object),	% objects
			list(light),	% light sources
			float,		% ambient illumination
			float,		% coefficient of specular reflection
			float,		% exponent of specular reflection
			float,		% focal length of pin-hole camera
			colour		% background colour
		).

scene__init(Objects, Lights, Ambient, SpecCoeff, SpecExp, FocalLength,
		Background) =
	scene(Objects, Lights, Ambient, SpecCoeff, SpecExp, FocalLength,
		Background).

objects(scene(Objects, _, _, _, _, _, _)) = Objects.
lights(scene(_, Lights, _, _, _, _, _)) = Lights.
ambient(scene(_, _, Ambient, _, _, _, _)) = Ambient.
spec_coeff(scene(_, _, _, SpecCoeff, _, _, _)) = SpecCoeff.
spec_exp(scene(_, _, _, _, SpecExp, _, _)) = SpecExp.
focal_length(scene(_, _, _, _, _, FocalLength, _)) = FocalLength.
background(scene(_, _, _, _, _, _, Background)) = Background.
