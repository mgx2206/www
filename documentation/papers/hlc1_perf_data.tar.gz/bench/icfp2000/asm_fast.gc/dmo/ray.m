:- module ray.

:- interface.

:- import_module vec.

:- interface.

:- type ray.

:- func ray(vec, vec) = ray.

:- func origin(ray) = vec.

:- func dir(ray) = vec.

:- implementation.

:- type ray
	---> r(
			vec,	% origin
			vec	% direction
		).

ray(Origin, Dir) = r(Origin, unit(Dir)).
origin(r(Origin, _)) = Origin.
dir(r(_, Dir)) = Dir.
