:- module ray_tracer.
:- interface.
:- import_module io.

:- pred main(io__state::di, io__state::uo) is det.

:- implementation.

:- import_module scene, ppm, trace, object, ray, vec, colour, transform, shade.
:- import_module list, int, float, math, ppm_read.

main -->
	read_ppm(PPM),
	{ X = 200, Y = 200 },
	ppm_write_header(X, Y),
	generate_image(0, X, 0, Y, scene(PPM)).

:- pred generate_image(int, int, int, int, scene, io__state, io__state).
:- mode generate_image(in, in, in, in, in(scene), di, uo) is det.

generate_image(X, MaxX, Y, MaxY, Scene) -->
	( { Y >= MaxY } ->
		[]
	; { X >= MaxX } ->
		generate_image(0, MaxX, Y+1, MaxY, Scene)
	;
		{ Ray = ray(zero, 
			ray_dir(focal_length(Scene), X, MaxX, Y, MaxY)) },
		(
			{ trace_ray(Ray, objects(Scene), Intersection, Attr) }
		->
			{ shade(Scene, Ray, Intersection, 1.0, Attr, Colour) },
			ppm_write_pixel(Colour)
		;
			ppm_write_pixel(background(Scene))
		),
		generate_image(X+1, MaxX, Y, MaxY, Scene)
	).

:- func scene(ppm::in) = (scene::out(scene)) is det.

scene(PPM) = scene__init(objects(PPM), lights, 0.0, 0.4, 2.0,
	focal_length, black).

:- func objects(ppm) = list(object).
:- mode objects(in) = out(list_skel(object)).

/*
objects(_) = [transform(Trans, Sphere), Plane] :-
	%Plane = with_colour(green, plane(ray(scale(-150.0, j), j))),
	Plane = checker_board(k, 100.0, grey, white, ray(scale(-150.0, j), j)),
	Sphere = rainbow_sphere(scale(-2500.0, k), 250.0),
	Trans = scale(i+scale(1.5, j)+k) * rotateZ(pi/4.0).
*/

/*
objects(PPM) = [Plane, Sphere, Ball, Cube] :-
	Plane0 = picture(PPM, 300.0, -k, ray(scale(-150.0, j), j)),
	Plane = difference(Plane0,
		rainbow_sphere(vec(0.0, -150.0, -2000.0), 300.0)),
	Sphere0 = sphere(scale(-2500.0, k)+scale(150.0, j), 250.0),
	Sphere = with_attribute(colour(rgb(0.2, 0.2, 0.2)) * reflection(0.8),
		Sphere0),
	%HemiSphere = intersection(Sphere, 
	%	plane(ray(scale(-2500.0, k), scale(0.1, k)-i))),
	Ball = with_colour(green, sphere(scale(2500.0, k), 2499.0)),

	Cube0 = with_colour(blue, cube(vec(-1117.0, -100.0, -1117.0), 50.0)),
	Cube = transform(rotateY(-pi/4.0), Cube0).
*/
objects(_) = [Cone, Plane] :-
	Pscale = 1.0,
	Cone0 = cone(Pscale, Pscale, vec(0.0, -50.0, -1000.0)),
	Cone = with_attribute(colour(scale(0.4, green)) * reflection(0.8),
		Cone0),
	/*
	Pscale = 0.01,
	Parabola0 = parabola(Pscale, Pscale, vec(0.0, -50.0, -1000.0)),
	Parabola = with_attribute(colour(scale(0.4, green)) * reflection(0.8),
		Parabola0),
	*/
	/*
	Ball0 = sphere(zero, 50.0),
	Ball1 = transform(scale(vec(2.0, 1.0, 2.0)) * 
			translate(vec(0.0, -100.0, -1000.0)), Ball0),
	Ball = with_attribute(colour(scale(0.4, blue)) * reflection(0.8),
			Ball1),
	*/
	Plane = checker_board(k, 100.0, red, white, ray(scale(-150.0, j), j)).
	/*
	Mirror = with_attribute(colour(black) * reflection(0.8),
			plane(ray(k, -k))).
	*/

/*
objects(_) = [Cube] :-
	PScale = 1.0/25.0,
	Parabola0 = parabola(PScale, PScale, scale(-50.0, j)),
	Parabola = with_attribute(colour(black) * reflection(0.8), Parabola0),
	Cube0 = difference(cube(zero, 50.0), Parabola),
	SmallCube = with_colour(yellow, cube(zero, 10.0)),
	Cube1 = union(Cube0, SmallCube),
	Cube = transform(rotateY(pi/4.0) * rotateX(pi/3.0) * translate(Pos),
		Cube1).
*/

:- func focal_length = float.

focal_length = 500.0.

:- func ray_dir(float, int, int, int, int) = vec.

ray_dir(Foc, X, MaxX, Y, MaxY) =
	unit(vec(float(X) - float(MaxX)/2.0, float(MaxY)/2.0 - float(Y), -Foc)).

:- func lights = list(light).

lights = [
		light(0.7, vec(10000.0, 10000.0, -100.0)),
		light(0.7, vec(-10000.0, 10000.0, -100.0))
	].
