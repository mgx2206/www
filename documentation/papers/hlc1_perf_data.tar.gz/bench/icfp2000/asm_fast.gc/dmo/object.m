:- module object.

:- interface.

:- import_module ray, vec, float, colour, transform, ppm_read, list.

		% Objects can respond to two types of request.
		% If an `intersect' request is made, the intersections between
		% the given ray and the surface(s) of the object are returned
		% nondeterministically.
		% If an `inside' request is made, the call will succeed iff
		% the point given is inside the object.
		%
		% XXX when partially instantiated modes are implemented,
		% object_request and object_result should be combined into
		% a single argument:
		% :- type object == pred(obj_req).
		% :- inst object = (pred(obj_req) is nondet).
		% :- type obj_req
		%	--->	intersect(ray, ray, attributes)
		%	;	inside(vec).
		% :- inst obj_req
		%	--->	intersect(ground, free, free)
		%	;	inside(ground).
		% :- mode obj_req :: obj_req -> ground.
		% 
		% Alternatively, when existential types are fully implemented
		% object could be made into a typeclass with intersect and 
		% inside methods.

:- type object == pred(object_request).
:- inst object = (pred(object_request) is nondet).

:- type object_request
	--->	intersect(
			ray,	     % Intersection of object surface with ray.
			ray,	     % ray(IntersectionPoint, SurfaceNormal)
			attributes   % Object attributes at IntersectionPoint.
		)
	;	inside(vec).	% Is position vector inside object?

:- inst object_request
	--->	intersect(ground, free_alias, free_alias)
	;	inside(ground).

:- mode object_request :: object_request -> ground.

:- pred sphere(vec, float, object_request).
:- mode sphere(in, in, object_request) is nondet.

:- pred half_space(ray, object_request).
:- mode half_space(in, object_request) is nondet.

:- pred parabola(float, float, vec, object_request).
:- mode parabola(in, in, in, object_request) is nondet.

:- pred cone(float, float, vec, object_request).
:- mode cone(in, in, in, object_request) is nondet.

:- pred plane(ray, object_request).
:- mode plane(in, object_request) is nondet.

:- pred cylinder(float, vec, float, object_request).
:- mode cylinder(in, in, in, object_request) is nondet.

:- pred triangle(vec, vec, vec, object_request).
:- mode triangle(in, in, in, object_request) is nondet.

:- pred with_colour(colour, object, object_request).
:- mode with_colour(in, in(object), object_request) is nondet.

:- pred transform(transform, object, object_request).
:- mode transform(in, in(object), object_request) is nondet.

:- pred rainbow_sphere(vec, float, object_request).
:- mode rainbow_sphere(in, in, object_request) is nondet.

:- pred checker_board(vec, float, colour, colour, ray, object_request).
:- mode checker_board(in, in, in, in, in, object_request) is nondet.

:- pred picture(ppm, float, vec, ray, object_request).
:- mode picture(in, in, in, in, object_request) is nondet.

:- pred union(object, object, object_request).
:- mode union(in(object), in(object), object_request) is nondet.

:- pred difference(object, object, object_request).
:- mode difference(in(object), in(object), object_request) is nondet.

:- pred intersection(object, object, object_request).
:- mode intersection(in(object), in(object), object_request) is nondet.

:- func union_list(list(object)) = object.
:- mode union_list(in(list_skel(object))) = out(object) is det.

:- func intersection_list(list(object)) = object.
:- mode intersection_list(in(list_skel(object))) = out(object) is det.

:- pred inverse(object, object_request).
:- mode inverse(in(object), object_request) is nondet.

:- func cube(vec, float) = object.
:- mode cube(in, in) = out(object) is det.

:- pred with_attribute(func(attributes) = attributes, 
		object, object_request).
:- mode with_attribute(func(in) = out is det, in(object), object_request)
		is nondet.

:- pred with_attributes(attributes, object, object_request).
:- mode with_attributes(in, in(object), object_request) is nondet.

:- type attributes
	--->	attributes(
			colour,		% intrinsic colour
			float,		% coefficient of specular reflection
			float,		% exponent of specular reflection
			float,		% transmission coefficient
			float,		% refractive index
			float		% reflection
		).

:- func colour(colour, attributes) = attributes.
:- func colour(attributes) = colour.
:- func spec_coeff(float, attributes) = attributes.
:- func spec_coeff(attributes) = float.
:- func spec_exp(float, attributes) = attributes.
:- func spec_exp(attributes) = float.
:- func transmission(float, attributes) = attributes.
:- func transmission(attributes) = float.
:- func refraction(float, attributes) = attributes.
:- func refraction(attributes) = float.
:- func reflection(float, attributes) = attributes.
:- func reflection(attributes) = float.

:- func default_attributes = attributes.

:- func '*'(func(X) = Y, func(Y) = Z, X) = Z.
:- mode '*'(func(in) = out is det, func(in) = out is det, in) = out is det.

:- implementation.

:- import_module std_util, math, int.

sphere(Centre, Radius, intersect(Ray, ray(Intersection, Intersection - Centre),
		default_attributes)) :-
        U = origin(Ray) - Centre,
        D = dir(Ray),
        A = dot(D, D),
        B = 2.0 * dot(D, U),
        C = dot(U, U) - Radius*Radius,
        solve_quadratic(A, B, C, Dist),

	% The point should be in front of the camera.
	gt_epsilon(Dist),
	Intersection = origin(Ray) + scale(Dist, dir(Ray)).

sphere(Centre, Radius, inside(Point)) :-
	mag(Point - Centre) =< Radius.

	% XXX A ray should only intersect at most once with a plane so
	% planes (and the surface of half-spaces) are really semidet.
	% It would be nice to be able to pass a semidet closure where a
	% nondet closure is expected, then we wouldn't need the nondet
	% wrapper around these objects.
half_space(NormalRay, Request) :-
	half_space_2(NormalRay, Request).

:- pred half_space_2(ray, object_request).
:- mode half_space_2(in, object_request) is semidet.

half_space_2(NormalRay, intersect(Ray, 
		ray(Intersection, Normal), default_attributes)) :-

	% The surface of a half-space is a plane described by NormalRay.
	% We want to intersect Ray with this plane.
	Normal = dir(NormalRay),
	Denom = dot(dir(Ray), Normal),

	% Fail if ray and plane are parallel.
	Denom \= 0.0,

	ObservationPoint = origin(Ray),

	% Calculate distance of plane from observation point.
	Dist = (dot(origin(NormalRay), Normal) - dot(ObservationPoint, Normal))
		/ Denom,

	% Fail if intersection is behind us.
	gt_epsilon(Dist),

	Intersection = ObservationPoint + scale(Dist, dir(Ray)).

half_space_2(NormalRay, inside(Point)) :-
	dot(dir(NormalRay), Point - origin(NormalRay)) =< 0.0.

parabola(XScale, ZScale, TurningPoint,
	intersect(Ray, ray(Intersection, Normal), default_attributes)) :-

	origin(Ray) - TurningPoint = vec(Ux, Uy, Uz),
	dir(Ray) = vec(Dx, Dy, Dz),
	A = XScale*Dx*Dx + ZScale*Dz*Dz,
	B = 2.0*Dx*Ux*XScale + 2.0*Dz*Uz*ZScale - Dy,
	C = XScale*Ux*Ux + ZScale*Uz*Uz - Uy,

        solve_quadratic(A, B, C, Dist),
	gt_epsilon(Dist),

	Intersection = origin(Ray) + scale(Dist, dir(Ray)),
	Intersection - TurningPoint = vec(Gx, _, Gz),
	Normal = vec(2.0*XScale*Gx, -1.0, 2.0*ZScale*Gz).

parabola(XScale, ZScale, TurningPoint, inside(Point)) :-
	vec(Dx, Dy, Dz) = Point - TurningPoint,
	Dy >= XScale * Dx * Dx + ZScale * Dz * Dz.

cone(XScale, ZScale, Vertex,
	intersect(Ray, ray(Intersection, Normal), default_attributes)) :-

        origin(Ray) - Vertex = vec(Ux, Uy, Uz),
        dir(Ray) = vec(Dx, Dy, Dz),
        A = XScale*Dx*Dx + ZScale*Dz*Dz - Dy*Dy,
        B = 2.0 * (XScale*Ux*Dx + ZScale*Uz*Dz - Uy*Dy),
        C = XScale*Ux*Ux + ZScale*Uz*Uz - Uy*Uy,
        solve_quadratic(A, B, C, Dist),
        gt_epsilon(Dist),

        Intersection = origin(Ray) + scale(Dist, dir(Ray)),
        Intersection - Vertex = vec(Gx, Gy, Gz),
        Normal = vec(XScale*Gx, Gy, ZScale*Gz).

cone(XScale, ZScale, Vertex, inside(Point)) :-
        Point - Vertex = vec(Vx, Vy, Vz),
        Vy*Vy >= XScale*Vx*Vx + ZScale*Vz*Vz.

cylinder(XScale, Centre, Radius,
	intersect(Ray, ray(Intersection, Normal), default_attributes)) :-
        
        origin(Ray) - Centre = vec(Ux, _, Uz),
        dir(Ray) = vec(Dx, _, Dz),
        A = XScale*Dx*Dx + Dz*Dz,
        B = 2.0 * (XScale*Ux*Dx + Uz*Dz),
        C = XScale*Ux*Ux + Uz*Uz - Radius*Radius,
        solve_quadratic(A, B, C, Dist),
        gt_epsilon(Dist),

        Intersection = origin(Ray) + scale(Dist, dir(Ray)),
        Intersection - Centre = vec(Gx, _, Gz),
        Normal = vec(2.0*XScale*Gx, 0.0, 2.0*Gz).

cylinder(XScale, Centre, Radius, inside(Point)) :-
        Point - Centre = vec(Vx, _, Vz),
        Radius*Radius >= XScale*Vx*Vx + Vz*Vz.

	% Intersecting with a plane is the same as intersecting with the surface
	% of a half-space.  Planes have no thickness so inside requests should
	% always fail.
plane(NormalRay, Request) :-
	Request = intersect(_, _, _),
	half_space(NormalRay, Request).

triangle(P0, P1, P2, Request) :-
	plane(ray(P0, cross(P1 - P0, P2 - P0)), Request),
	Request = intersect(_Ray, IntersectionRay, _Attr),
	point_in_triangle(origin(IntersectionRay), P0, P1, P2).

:- pred point_in_triangle(vec, vec, vec, vec).
:- mode point_in_triangle(in, in, in, in) is semidet.

point_in_triangle(Point, P0, P1, P2) :-
	( non_zero_area(projectXY(P0), projectXY(P1), projectXY(P2)) ->
		point_in_triangle_2(xy(Point), xy(P0), xy(P1), xy(P2))
	; non_zero_area(projectXZ(P0), projectXZ(P1), projectXZ(P2)) ->
		point_in_triangle_2(xz(Point), xz(P0), xz(P1), xz(P2))
	; non_zero_area(projectZY(P0), projectZY(P1), projectZY(P2)) ->
		point_in_triangle_2(zy(Point), zy(P0), zy(P1), zy(P2))
	;
		% Triangle has 0 area
		Point = P0
	).

:- pred point_in_triangle_2(pair(float), pair(float), pair(float), pair(float)).
:- mode point_in_triangle_2(in, in, in, in) is semidet.

point_in_triangle_2(Xp - Yp, X0 - Y0, X1 - Y1, X2 - Y2) :-

	Denom = -Yp*X1 + Yp*X2 + X1*Y0 - X2*Y0 + Xp*Y1 - X0*Y1 - Xp*Y2 + X0*Y2,
	Denom \= 0.0,

	T = (X1*Y0 - X2*Y0 - X0*Y1 + X2*Y1 + X0*Y2 - X1*Y2) / Denom,
	T >= 1.0,

	R = (Yp*X0 - Yp*X1 - Xp*Y0 +X1*Y0 + Xp*Y1 - X0*Y1) / Denom,
	R >= 0.0,
	R =< 1.0.

:- pred non_zero_area(vec, vec, vec).
:- mode non_zero_area(in, in, in) is semidet.

non_zero_area(P0, P1, P2) :-
	cross(P0 - P1, P2 - P1) \= zero.

with_colour(Colour, Object, Request) :-
	with_attribute(colour(Colour), Object, Request).

transform(Transform, Object, intersect(Ray, IntersectionRay, Attr)) :-
	Object(intersect(transform_ray(inverse(Transform), Ray),
		Intersect0, Attr)),
	IntersectionRay = transform_ray(Transform, Intersect0).
transform(Transform, Object, inside(Point)) :-
	Object(inside(transform_vec(inverse(Transform), Point))).

rainbow_sphere(Centre, Radius, intersect(Ray, Intersection, Attributes)) :-
	sphere(Centre, Radius, intersect(Ray, Intersection, Attributes0)),
	Hue = acos(dot(k, dir(Intersection))) * 360.0/pi,
	Colour = hsv(Hue, 1.0, 1.0),
	Attributes = colour(Colour, Attributes0).
rainbow_sphere(Centre, Radius, inside(Point)) :-
	sphere(Centre, Radius, inside(Point)).

:- pred gt_epsilon(float::in) is semidet.

gt_epsilon(F) :-
	F > 1e-6.

checker_board(AlignmentVec, SquareSize, Colour0, Colour1, NormalRay, 
		intersect(Ray, Intersection, Attr)) :-
	plane(NormalRay, intersect(Ray, Intersection, Attr0)),
	Alignment = unit(AlignmentVec),
	Point = origin(IntersectionRay),
	XDist = dot(Alignment, Point),
	YDist = dot(cross(Alignment, dir(IntersectionRay)), Point),

	XSquare = floor_to_int(XDist / SquareSize) mod 2,
	YSquare = floor_to_int(YDist / SquareSize) mod 2,

	( XSquare + YSquare = 1 ->
		Colour = Colour1
	;
		Colour = Colour0
	),
	Attr = colour(Colour, Attr0).
checker_board(_, _, _, _, NormalRay, inside(Point)) :-
	plane(NormalRay, inside(Point)).

picture(PPM, Scale, AlignmentVec, NormalRay, 
		intersect(Ray, Intersection, Attr)) :-
	plane(NormalRay, intersect(Ray, Intersection, Attr0)),
	Alignment = unit(AlignmentVec),
	Point = origin(IntersectionRay),
	XDist = dot(Alignment, Point),
	YDist = dot(cross(Alignment, dir(IntersectionRay)), Point),

	dimensions(PPM, Width, Height, _Depth),
	Xp0 = round_to_int(XDist * float(Width) / Scale),
	Xp = ((Xp0 mod Width) + Width) mod Width,
	Yp0 = round_to_int(YDist * float(Height) / Scale),
	Yp = ((Yp0 mod Height) + Height) mod Height,

	get_pixel(PPM, Xp, Yp, pixel(Ri, Gi, Bi)),

	Colour = rgb(float(Ri)/255.0, float(Gi)/255.0, float(Bi)/255.0),
	Attr = colour(Colour, Attr0).
picture(_, _, _, NormalRay, inside(Point)) :-
	plane(NormalRay, inside(Point)).

union(ObjectA, ObjectB, inside(Point)) :-
	( ObjectA(inside(Point))
	; ObjectB(inside(Point))
	).

union(ObjectA, ObjectB, Request) :-
	Request = intersect(_, IntRay, _),
	(
		ObjectA(Request),
		\+ ObjectB(inside(origin(IntRay)))
	;
		ObjectB(Request),
		\+ ObjectA(inside(origin(IntRay)))
	).

difference(ObjectA, ObjectB, Request) :-
	intersection(ObjectA, inverse(ObjectB), Request).

intersection(ObjectA, ObjectB, inside(Point)) :-
	ObjectA(inside(Point)),
	ObjectB(inside(Point)).

intersection(ObjectA, ObjectB, Request) :-
	Request = intersect(_, IntRay, _),
	(
		ObjectA(Request),
		ObjectB(inside(origin(IntRay)))
	;
		ObjectB(Request),
		ObjectA(inside(origin(IntRay)))
	).

union_list([]) = (pred(_::object_request) is nondet :- fail).
union_list([Object | Objects]) =
	union_list_2(Objects, Object).

:- func union_list_2(list(object), object) = object.
:- mode union_list_2(in(list_skel(object)), in(object)) =
		out(object) is det.

union_list_2([], Obj) = Obj.
union_list_2([Obj | Objs], AccObj0) = 
		union_list_2(Objs, union(Obj, AccObj0)).

intersection_list([]) = (pred(_::object_request) is nondet :- fail).
intersection_list([Object | Objects]) =
	intersection_list_2(Objects, Object).

:- func intersection_list_2(list(object), object) = object.
:- mode intersection_list_2(in(list_skel(object)), in(object)) =
		out(object) is det.

intersection_list_2([], Obj) = Obj.
intersection_list_2([Obj | Objs], AccObj0) = 
		intersection_list_2(Objs, intersection(Obj, AccObj0)).

inverse(Object, inside(Point)) :-
	\+ Object(inside(Point)).

	% To get the inverse of an object, negate the surface normal vector.
inverse(Object, intersect(Ray, IntersectionRay, Attributes)) :-
	Object(intersect(Ray, IntersectionRay0, Attributes)),
	IntersectionRay = ray(origin(IntersectionRay0), -dir(IntersectionRay0)).

cube(Centre, Width) = intersection_list(CubeSides) :-
	Side = side(Centre, Width),
	CubeSides = [
		Side(i),
		Side(-i),
		Side(j),
		Side(-j),
		Side(k),
		Side(-k)
	].

:- func side(vec, float, vec) = object.
:- mode side(in, in, in) = out(object) is det.

side(Centre, Width, Dir) = half_space(ray(Centre + scale(Width, Dir), Dir)).

with_attribute(F, Object, Request) :-
	(
		Request = intersect(Ray0, Ray, Attr),
		Object(intersect(Ray0, Ray1, Attr0)),
		Ray = Ray1,
		Attr = F(Attr0)
	;
		Request = inside(_),
		Object(Request)
	).

with_attribute(F, Object, intersect(Ray, IntRay, Attr)) :-
	Object(intersect(Ray, IntRay0, Attr0)),
	IntRay = IntRay0,
	Attr = F(Attr0).
with_attributes(_, Object, inside(Point)) :-
	Object(inside(Point)).

with_attributes(Attributes, Object, intersect(Ray, IntRay, Attributes)) :-
	Object(intersect(Ray, IntRay0, _)),
	IntRay = IntRay0.
with_attributes(_, Object, inside(Point)) :-
	Object(inside(Point)).

colour(A, attributes(_, B, C, D, E, F)) = attributes(A, B, C, D, E, F).
spec_coeff(B, attributes(A, _, C, D, E, F)) = attributes(A, B, C, D, E, F).
spec_exp(C, attributes(A, B, _, D, E, F)) = attributes(A, B, C, D, E, F).
transmission(D, attributes(A, B, C, _, E, F)) = attributes(A, B, C, D, E, F).
refraction(E, attributes(A, B, C, D, _, F)) = attributes(A, B, C, D, E, F).
reflection(F, attributes(A, B, C, D, E, _)) = attributes(A, B, C, D, E, F).

colour(attributes(A, _, _, _, _, _)) = A.
spec_coeff(attributes(_, B, _, _, _, _)) = B.
spec_exp(attributes(_, _, C, _, _, _)) = C.
transmission(attributes(_, _, _, D, _, _)) = D.
refraction(attributes(_, _, _, _, E, _)) = E.
reflection(attributes(_, _, _, _, _, F)) = F.

default_attributes = attributes(default_colour, 0.4, 2.0, 0.0, 1.0, 0.0).

'*'(F0, F1, X) = F1(F0(X)).

        % solve_quadratic(A, B, C, X) <=> AX^2 + BX + C = 0.
:- pred solve_quadratic(float, float, float, float).
:- mode solve_quadratic(in, in, in, out) is nondet.

solve_quadratic(A, B, C, X) :-
        D = B*B - 4.0*A*C,
        ( D = 0.0 ->
                X = -B / (2.0*A)
        ;
                D > 0.0,
                (
                        X = (-B + sqrt(D)) / (2.0*A)
                ;
                        X = (-B - sqrt(D)) / (2.0*A)
                )
        ).
