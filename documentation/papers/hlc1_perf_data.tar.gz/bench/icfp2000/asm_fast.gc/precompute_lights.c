/*
** Automatically generated from `precompute_lights.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__precompute_lights__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "precompute_lights.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "precompute_lights.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 39 "precompute_lights.c"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#include <float.h>
	#include <math.h>


#line 47 "precompute_lights.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#define	ML_FLOAT_RADIX	FLT_RADIX	/* There is no DBL_RADIX. */

	#if defined USE_SINGLE_PREC_FLOAT
		#define	ML_FLOAT_MAX		FLT_MAX
		#define	ML_FLOAT_MIN		FLT_MIN
		#define	ML_FLOAT_EPSILON	FLT_EPSILON
		#define	ML_FLOAT_MANT_DIG	FLT_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	FLT_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	FLT_MAX_EXP
	#else
		#define	ML_FLOAT_MAX		DBL_MAX
		#define	ML_FLOAT_MIN		DBL_MIN
		#define	ML_FLOAT_EPSILON	DBL_EPSILON
		#define	ML_FLOAT_MANT_DIG	DBL_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	DBL_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	DBL_MAX_EXP
	#endif


#line 70 "precompute_lights.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_DETERMINISM_GUARD
#define ML_DETERMINISM_GUARD
	/*
	** The enumeration constants in this enum must be in the same
	** order as the functors in the Mercury type `determinism'
	** defined above.
	*/
	typedef enum {
		ML_DET,
		ML_SEMIDET,
		ML_CC_MULTI,
		ML_CC_NONDET,
		ML_MULTI,
		ML_NONDET,
		ML_ERRONEOUS,
		ML_FAILURE
	} ML_Determinism;
#endif

#line 93 "precompute_lights.c"
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* protect against multiple inclusion */
#ifndef MR_HLC_EXCEPTION_GUARD
#define MR_HLC_EXCEPTION_GUARD

#ifdef MR_HIGHLEVEL_CODE

  #ifdef MR_USE_GCC_NESTED_FUNCTIONS
  	#define MR_CONT_PARAMS		MR_NestedCont cont
  	#define MR_CONT_PARAM_TYPES	MR_NestedCont
  	#define MR_CONT_ARGS		cont
  #else
  	#define MR_CONT_PARAMS		MR_Cont cont, void *cont_env
  	#define MR_CONT_PARAM_TYPES	MR_Cont, void *
  	#define MR_CONT_ARGS		cont, cont_env
  #endif

	/* det */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_0(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* semidet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_1(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_2(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_nondet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_3(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_4(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

	/* nondet */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_5(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

  #ifndef MR_AVOID_MACROS

	/* det ==> model_det */
	#define mercury__exception__builtin_catch_3_p_0 		mercury__exception__builtin_catch_model_det

	/* semidet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_1 		mercury__exception__builtin_catch_model_semi

	/* cc_multi ==> model_det */
	#define mercury__exception__builtin_catch_3_p_2 		mercury__exception__builtin_catch_model_det

	/* cc_nondet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_3 		mercury__exception__builtin_catch_model_semi

	/* multi ==> model_non */
	#define mercury__exception__builtin_catch_3_p_4 		mercury__exception__builtin_catch_model_non

	/* nondet ==> model_non */
	#define mercury__exception__builtin_catch_3_p_5 		mercury__exception__builtin_catch_model_non

  #endif /* !MR_AVOID_MACROS */

	void MR_CALL mercury__exception__builtin_throw_1_p_0(MR_Univ exception);

	void MR_CALL mercury__exception__builtin_catch_model_det(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	bool MR_CALL mercury__exception__builtin_catch_model_semi(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	void MR_CALL mercury__exception__builtin_catch_model_non(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

#endif /* MR_HIGHLEVEL_CODE */

#endif /* MR_HLC_EXCEPTION_GUARD */

#line 183 "precompute_lights.c"
#line 147 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

#ifndef MR_HIGHLEVEL_CODE
	#include <assert.h>
	#include <stdio.h>
	#include "mercury_deep_copy.h"
	#include "mercury_trace_base.h"
	#include "mercury_stack_trace.h"
	#include "mercury_layout_util.h"
	#include "mercury_deep_profiling_hand.h"

	MR_DECLARE_TYPE_CTOR_INFO_STRUCT( 			mercury_data_std_util__type_ctor_info_univ_0);
#endif

#line 198 "precompute_lights.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


#include "mercury_deep_copy.h"

#ifdef CONSERVATIVE_GC
  /* for conservative GC, shallow copies suffice */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		NewVal = OldVal;					\
	} while (0)
#else
  /*
  ** Note that we need to save/restore the MR_hp register, if it
  ** is transient, before/after calling MR_deep_copy().
  */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		MR_save_transient_hp();					\
		NewVal = MR_deep_copy(&OldVal, (MR_TypeInfo) TypeInfo_for_T,\
				(const MR_Word *) SolutionsHeapPtr,	\
				MR_ENGINE(MR_eng_solutions_heap_zone)->top);\
		MR_restore_transient_hp();				\
	} while (0)
#endif


#line 228 "precompute_lights.c"
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"

#include "mercury_heap.h"	/* for MR_incr_hp_msg() etc. */
#include "mercury_misc.h"	/* for MR_fatal_error() */
#include "mercury_string.h"	/* for MR_make_aligned_string() */

#line 235 "precompute_lights.c"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_TYPECTORDESC_GUARD
#define ML_TYPECTORDESC_GUARD

/*
** Values of type `std_util:type_desc' are represented the same way as
** values of type `private_builtin:type_info' (this representation is
** documented in compiler/polymorphism.m). Some parts of the library
** (e.g. the gc initialization code) depend on this.
** The C type corresponding to these Mercury types is `MR_TypeInfo'.
**
** Values of type `std_util:type_ctor_desc' are not guaranteed to be
** represented the same way as values of type `private_builtin:type_ctor_info'.
** The representations *are* in fact identical for first order types, but they
** differ for higher order and tuple types. Instead of a type_ctor_desc
** being a structure containing a pointer to the type_ctor_info for pred/0
** or func/0 and an arity, we have a single small encoded integer. This
** integer is four times the arity, plus zero, one or two; plus zero encodes a
** tuple, plus one encodes a predicate, plus two encodes a function.
** The maximum arity that can be encoded is given by MR_MAX_VARIABLE_ARITY
** (see below).
** The C type corresponding to std_util:type_ctor_desc is `MR_TypeCtorDesc'.
*/

/*
** Declare the MR_TypeCtorDesc ADT.
**
** Note that `struct MR_TypeCtorDesc_Struct' is deliberately left undefined.
** MR_TypeCtorDesc is declared as a pointer to a dummy structure only
** in order to allow the C compiler to catch errors in which things other
** than MR_TypeCtorDescs are given as arguments to macros that depend on their
** arguments being MR_TypeCtorDescs. The actual value is either a small integer
** or a pointer to a MR_TypeCtorInfo_Struct structure, as described above.
*/
typedef struct MR_TypeCtorDesc_Struct *MR_TypeCtorDesc;

/*
** The maximum arity that can be encoded should be set to twice the maximum
** number of general purpose registers, since an predicate or function having
** more arguments that this would run out of registers when passing the input
** arguments, or the output arguments, or both.
**
** XXX When tuples were added this was reduced to be the maximum number
** of general purpose registers, to reduce the probability that the
** `small' integers for higher-order and tuple types are confused with
** type_ctor_info pointers. This still allows higher-order terms with
** 1024 arguments, which is more than ../LIMITATIONS promises.
*/
#define MR_MAX_VARIABLE_ARITY         MR_MAX_VIRTUAL_REG

/*
** Constructors for the MR_TypeCtorDesc ADT
*/

#define MR_TYPECTOR_DESC_MAKE_PRED(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4) )
#define MR_TYPECTOR_DESC_MAKE_FUNC(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4 + 1) )
#define MR_TYPECTOR_DESC_MAKE_TUPLE(Arity)                                      ( (MR_TypeCtorDesc) ((Arity) * 4 + 2) )
#define MR_TYPECTOR_DESC_MAKE_FIXED_ARITY(type_ctor_info)                       ( MR_CHECK_EXPR_TYPE(type_ctor_info, MR_TypeCtorInfo),                    (MR_TypeCtorDesc) type_ctor_info )

/*
** Access macros for the MR_TypeCtor ADT.
**
** The MR_TYPECTOR_DESC_GET_VA_* macros should only be called if
** MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns true.
** The MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO() macro
** should only be called if MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns false.
*/
#define MR_TYPECTOR_DESC_IS_VARIABLE_ARITY(T)                                   ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) <= (4 * MR_MAX_VARIABLE_ARITY + 2) )
#define MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO(T)                      ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_TypeCtorInfo) (T) )
#define MR_TYPECTOR_DESC_GET_VA_ARITY(T)                                        ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) / 4 )
#define MR_TYPECTOR_DESC_GET_VA_NAME(T)                                         ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) (((MR_Unsigned) (T) % 4 == 0)                                ? "pred"                                                              : (((MR_Unsigned) (T) % 4 == 1)                                             ? "func"                                                              : "{}" )) )
#define MR_TYPECTOR_DESC_GET_VA_MODULE_NAME(T)                                  ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) "builtin" )
#define MR_TYPECTOR_DESC_GET_VA_TYPE_CTOR_INFO(T)                               ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 ((MR_Unsigned) (T) % 4 == 0)                                                  ? MR_TYPE_CTOR_INFO_HO_PRED                                             : (((MR_Unsigned) (T) % 4 == 1)                                            ? MR_TYPE_CTOR_INFO_HO_FUNC                                             : MR_TYPE_CTOR_INFO_TUPLE ) )

#endif /* ML_TYPECTORDESC_GUARD */


#line 316 "precompute_lights.c"
#line 126 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_CONSTRUCT_INFO_GUARD
#define ML_CONSTRUCT_INFO_GUARD

typedef struct ML_Construct_Info_Struct {
    MR_ConstString          functor_name;
    MR_Integer              arity;
    const MR_PseudoTypeInfo *arg_pseudo_type_infos;
    MR_ConstString          *arg_names;
    MR_TypeCtorRep          type_ctor_rep;
    union {
        const MR_EnumFunctorDesc  *enum_functor_desc;
        const MR_NotagFunctorDesc *notag_functor_desc;
        const MR_DuFunctorDesc    *du_functor_desc;
    }                       functor_info;
} ML_Construct_Info;

#endif

extern  void            ML_type_ctor_and_args(MR_TypeInfo type_info,
                            bool collapse_equivalences,
                            MR_TypeCtorDesc *type_ctor_desc_ptr,
                            MR_Word *arg_type_info_list_ptr);
extern  int     	    ML_get_num_functors(MR_TypeInfo type_info);
extern	MR_Word		    ML_type_params_vector_to_list(int arity,
                            MR_TypeInfoParams type_params);
extern	MR_Word		    ML_arg_name_vector_to_list(int arity,
                            MR_ConstString *arg_names);
extern	MR_Word		    ML_pseudo_type_info_vector_to_type_info_list(int arity,
                            MR_TypeInfoParams type_params,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  bool    	    ML_get_functors_check_range(int functor_number,
                            MR_TypeInfo type_info,
                            ML_Construct_Info *construct_info);
extern  void    	    ML_copy_arguments_from_list_to_vector(int arity,
                            MR_Word arg_list, MR_Word term_vector);
extern  bool    	    ML_typecheck_arguments(MR_TypeInfo type_info,
                            int arity, MR_Word arg_list,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  MR_TypeInfo	    ML_make_type(int arity, MR_TypeCtorDesc type_ctor_desc,
				             MR_Word arg_type_list);

#line 362 "precompute_lights.c"
#line 170 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


extern	MR_TypeCtorDesc ML_make_type_ctor_desc(MR_TypeInfo type_info,
				MR_TypeCtorInfo type_ctor_info);


#line 370 "precompute_lights.c"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


    #include <stdio.h>
	#include "mercury_library_types.h"		/* for MR_ArrayType */

#ifdef MR_DEEP_PROFILING
    #include "mercury_deep_profiling.h"
#endif

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef	ML_EXPAND_INFO_GUARD
#define	ML_EXPAND_INFO_GUARD

typedef struct {
    int                     num_extra_args;
    MR_Word                 *arg_values;
    MR_TypeInfo             *arg_type_infos;
    bool                    can_free_arg_type_infos;
} ML_Expand_Args_Fields;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
} ML_Expand_Functor_Args_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
    bool                    limit_reached;
} ML_Expand_Functor_Args_Limit_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor_only;
} ML_Expand_Functor_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    ML_Expand_Args_Fields   args_only;
} ML_Expand_Args_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    bool                    chosen_index_exists;
    MR_Word                 *chosen_value_ptr;
    MR_TypeInfo             chosen_type_info;
} ML_Expand_Chosen_Arg_Only_Info;

    /* Prototypes */

extern  void    ML_expand_functor_args(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Args_Info *expand_info);

extern  void    ML_expand_functor_args_limit(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int max_arity,
                    ML_Expand_Functor_Args_Limit_Info *expand_info);

extern  void    ML_expand_functor_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Only_Info *expand_info);

extern  void    ML_expand_args_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Args_Only_Info *expand_info);

extern  void    ML_expand_chosen_arg_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int chosen,
                    ML_Expand_Chosen_Arg_Only_Info *expand_info);

    /*
    ** NB. ML_arg() is also used by arg_ref and new_arg_ref
    ** in store.m, in trace/mercury_trace_vars.m, and in
    ** extras/trailed_update/tr_store.m.
    */
extern  bool    ML_arg(MR_TypeInfo type_info, MR_Word *term, int arg_index,
                    MR_TypeInfo *arg_type_info_ptr, MR_Word **argument_ptr);

    /*
    ** NB. ML_named_arg_num() is used in mercury_trace_vars.c.
    */
extern  bool    ML_named_arg_num(MR_TypeInfo type_info, MR_Word *term_ptr,
                    const char *arg_name, int *arg_num_ptr);

/*
** The following macros factor out the common parts of the various
** deconstruction predicates.
*/

    /*
    ** Check for attempts to deconstruct a non-canonical type.
    ** Such deconstructions must be cc_multi, which is why we treat
    ** violations of this as runtime errors in det deconstruction
    ** predicates.
    ** (There ought to be cc_multi versions of those predicates.)
    */
#define ML_abort_if_type_is_noncanonical(ei, predname)                  do {                                                                    if ((ei).non_canonical_type) {                                          MR_fatal_error("called " predname " for a type "                    "with a user-defined equality predicate");                }                                                               } while (0)

#endif

#define ML_deconstruct_get_functor(ei, functor_field, var)              do {                                                                    MR_make_aligned_string(MR_LVALUE_CAST(MR_ConstString, var),             (ei).functor_field);                                        } while (0)

#define ML_deconstruct_get_arity(ei, var)                               do {                                                                    var = (ei).arity;                                               } while (0)

#define ML_deconstruct_get_arg_list(ei, args_field, var)                do {                                                                    int     i;                                                                                                                              var = MR_list_empty_msg(MR_PROC_LABEL);                             i = (ei).arity;                                                                                                                         while (--i >= 0) {                                                      MR_Word arg;                                                                                                                                /* Create an argument on the heap */                            MR_new_univ_on_hp(arg,                                                  (ei).args_field.arg_type_infos[i],                                  (ei).args_field.arg_values[i +                                          (ei).args_field.num_extra_args]);                                                                                                   /* Join the argument to the front of the list */                var = MR_list_cons_msg(arg, var, MR_PROC_LABEL);                }                                                               } while (0)

    /*
    ** Free any arg_type_infos allocated by the ML_expand variant.
    ** Should be called after we have used them for the last time.
    */
#define ML_deconstruct_free_allocated_arg_type_infos(ei, args_field)    do {                                                                    if ((ei).args_field.can_free_arg_type_infos) {                          MR_GC_free((ei).args_field.arg_type_infos);                     }                                                               } while (0)


#line 492 "precompute_lights.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 495 "precompute_lights.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 501 "precompute_lights.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 509 "precompute_lights.c"


static const struct mercury_data_precompute_lights__common_0_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_precompute_lights__common_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_precompute_lights__type_ctor_info_bounding_sphere_0;
extern const MR_DuFunctorDesc * mercury_data_precompute_lights__du_name_ordered_bounding_sphere_0[];
static const MR_DuFunctorDesc mercury_data_precompute_lights__du_functor_desc_bounding_sphere_0_0;
extern const MR_ConstString mercury_data_precompute_lights__field_names_bounding_sphere_0_0[];
extern const MR_PseudoTypeInfo mercury_data_precompute_lights__field_types_bounding_sphere_0_0[];
extern const MR_DuPtagLayout mercury_data_precompute_lights__du_ptag_ordered_bounding_sphere_0[];
extern const MR_DuFunctorDesc * mercury_data_precompute_lights__du_stag_ordered_bounding_sphere_0_0[];
MR_declare_static(mercury__precompute_lights__list__filter__ho9__ua0_4_0);
MR_declare_label(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i4);
MR_declare_label(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i7);
MR_declare_label(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i5);
MR_declare_label(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i3);
MR_declare_static(mercury__precompute_lights__list__filter__ho8__ua0_4_0);
MR_declare_label(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i4);
MR_declare_label(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i7);
MR_declare_label(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i5);
MR_declare_label(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i3);
MR_declare_static(mercury__precompute_lights__list__map__ho6__ua0_3_0);
MR_declare_label(mercury__precompute_lights__list__map__ho6__ua0_3_0_i4);
MR_declare_label(mercury__precompute_lights__list__map__ho6__ua0_3_0_i5);
MR_declare_label(mercury__precompute_lights__list__map__ho6__ua0_3_0_i3);
MR_declare_static(mercury__precompute_lights__list__map__ho4__ua0_3_0);
MR_declare_label(mercury__precompute_lights__list__map__ho4__ua0_3_0_i4);
MR_declare_label(mercury__precompute_lights__list__map__ho4__ua0_3_0_i5);
MR_declare_label(mercury__precompute_lights__list__map__ho4__ua0_3_0_i3);
MR_declare_static(mercury__precompute_lights__list__map__ho7_3_0);
MR_declare_label(mercury__precompute_lights__list__map__ho7_3_0_i4);
MR_declare_label(mercury__precompute_lights__list__map__ho7_3_0_i5);
MR_declare_label(mercury__precompute_lights__list__map__ho7_3_0_i3);
MR_declare_static(mercury__precompute_lights__list__map__ho5_3_0);
MR_declare_label(mercury__precompute_lights__list__map__ho5_3_0_i4);
MR_declare_label(mercury__precompute_lights__list__map__ho5_3_0_i5);
MR_declare_label(mercury__precompute_lights__list__map__ho5_3_0_i3);
MR_declare_static(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0);
MR_declare_label(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0_i4);
MR_declare_label(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0_i3);
MR_declare_label(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0_i5);
MR_define_extern_entry(mercury__precompute_lights__scene_list_2_0);
MR_declare_label(mercury__precompute_lights__scene_list_2_0_i2);
MR_declare_label(mercury__precompute_lights__scene_list_2_0_i3);
MR_declare_label(mercury__precompute_lights__scene_list_2_0_i4);
MR_declare_label(mercury__precompute_lights__scene_list_2_0_i5);
MR_define_extern_entry(mercury__precompute_lights__pre_compute_lighting_4_0);
MR_declare_label(mercury__precompute_lights__pre_compute_lighting_4_0_i2);
MR_declare_label(mercury__precompute_lights__pre_compute_lighting_4_0_i3);
MR_declare_static(mercury__precompute_lights__space_tree_node_list_2_0);
MR_declare_label(mercury__precompute_lights__space_tree_node_list_2_0_i4);
MR_declare_label(mercury__precompute_lights__space_tree_node_list_2_0_i3);
MR_declare_static(mercury__precompute_lights__object_list_2_0);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i4);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i5);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i7);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i12);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i13);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i14);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i15);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i10);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i17);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i18);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i21);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i23);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i22);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i26);
MR_declare_label(mercury__precompute_lights__object_list_2_0_i27);
MR_define_extern_entry(mercury__precompute_lights__traverse_part_4_0);
MR_declare_label(mercury__precompute_lights__traverse_part_4_0_i2);
MR_define_extern_entry(mercury__precompute_lights__traverse_objects_4_0);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i4);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i5);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i7);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i8);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i9);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i10);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i12);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i15);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i19);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i20);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i21);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i22);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i24);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i25);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i23);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i26);
MR_declare_label(mercury__precompute_lights__traverse_objects_4_0_i27);
MR_declare_static(mercury__precompute_lights__calc_light_list_5_0);
MR_declare_label(mercury__precompute_lights__calc_light_list_5_0_i5);
MR_declare_label(mercury__precompute_lights__calc_light_list_5_0_i7);
MR_declare_label(mercury__precompute_lights__calc_light_list_5_0_i8);
MR_declare_label(mercury__precompute_lights__calc_light_list_5_0_i4);
MR_declare_label(mercury__precompute_lights__calc_light_list_5_0_i10);
MR_declare_label(mercury__precompute_lights__calc_light_list_5_0_i11);
MR_declare_label(mercury__precompute_lights__calc_light_list_5_0_i12);
MR_declare_label(mercury__precompute_lights__calc_light_list_5_0_i13);
MR_declare_static(mercury__precompute_lights__is_clear_4_0);
MR_declare_label(mercury__precompute_lights__is_clear_4_0_i2);
MR_declare_label(mercury__precompute_lights__is_clear_4_0_i3);
MR_declare_static(mercury__precompute_lights__single_is_clear_4_0);
MR_declare_label(mercury__precompute_lights__single_is_clear_4_0_i23);
MR_declare_label(mercury__precompute_lights__single_is_clear_4_0_i10);
MR_declare_label(mercury__precompute_lights__single_is_clear_4_0_i11);
MR_declare_label(mercury__precompute_lights__single_is_clear_4_0_i13);
MR_declare_label(mercury__precompute_lights__single_is_clear_4_0_i4);
MR_declare_label(mercury__precompute_lights__single_is_clear_4_0_i14);
MR_declare_label(mercury__precompute_lights__single_is_clear_4_0_i17);
MR_declare_label(mercury__precompute_lights__single_is_clear_4_0_i18);
MR_declare_label(mercury__precompute_lights__single_is_clear_4_0_i15);
MR_declare_label(mercury__precompute_lights__single_is_clear_4_0_i1);
MR_declare_static(mercury__fn__precompute_lights__bounding_sphere_1_0);
MR_declare_label(mercury__fn__precompute_lights__bounding_sphere_1_0_i2);
MR_declare_label(mercury__fn__precompute_lights__bounding_sphere_1_0_i11);
MR_declare_label(mercury__fn__precompute_lights__bounding_sphere_1_0_i7);
MR_define_extern_entry(mercury____Unify___precompute_lights__bounding_sphere_0_0);
MR_declare_label(mercury____Unify___precompute_lights__bounding_sphere_0_0_i2);
MR_declare_label(mercury____Unify___precompute_lights__bounding_sphere_0_0_i1);
MR_define_extern_entry(mercury____Compare___precompute_lights__bounding_sphere_0_0);
MR_declare_label(mercury____Compare___precompute_lights__bounding_sphere_0_0_i3);
MR_declare_label(mercury____Compare___precompute_lights__bounding_sphere_0_0_i6);
MR_declare_label(mercury____Compare___precompute_lights__bounding_sphere_0_0_i7);
MR_declare_label(mercury____Compare___precompute_lights__bounding_sphere_0_0_i10);

static const MR_Float mercury_float_const_0pt00000000000000 = 0.00000000000000;
static const struct mercury_data_precompute_lights__common_0_struct mercury_data_precompute_lights__common_0 = {
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000
};
extern const MR_DuFunctorDesc * mercury_data_precompute_lights__du_name_ordered_bounding_sphere_0[];
extern const MR_DuPtagLayout mercury_data_precompute_lights__du_ptag_ordered_bounding_sphere_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_precompute_lights__type_ctor_info_bounding_sphere_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___precompute_lights__bounding_sphere_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___precompute_lights__bounding_sphere_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___precompute_lights__bounding_sphere_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"precompute_lights",
	"bounding_sphere",
	4,
	{ (void *) mercury_data_precompute_lights__du_name_ordered_bounding_sphere_0 },
	{ (void *) mercury_data_precompute_lights__du_ptag_ordered_bounding_sphere_0 },
	1,
	1
};

const MR_DuFunctorDesc * mercury_data_precompute_lights__du_name_ordered_bounding_sphere_0[] = {
	&mercury_data_precompute_lights__du_functor_desc_bounding_sphere_0_0
};

static const MR_DuFunctorDesc mercury_data_precompute_lights__du_functor_desc_bounding_sphere_0_0 = {
	"bsphere",
	2,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_precompute_lights__field_types_bounding_sphere_0_0,
	mercury_data_precompute_lights__field_names_bounding_sphere_0_0,
	NULL
};

const MR_ConstString mercury_data_precompute_lights__field_names_bounding_sphere_0_0[] = {
	"centre",
	"radius"
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_vector_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_float_0;

const MR_PseudoTypeInfo mercury_data_precompute_lights__field_types_bounding_sphere_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

const MR_DuPtagLayout mercury_data_precompute_lights__du_ptag_ordered_bounding_sphere_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_precompute_lights__du_stag_ordered_bounding_sphere_0_0 }

};

const MR_DuFunctorDesc * mercury_data_precompute_lights__du_stag_ordered_bounding_sphere_0_0[] = {
	&mercury_data_precompute_lights__du_functor_desc_bounding_sphere_0_0

};

MR_declare_entry(mercury__list__condense_2_0);
MR_declare_entry(mercury__list__append_3_1);
MR_declare_entry(mercury__fn__space_partition__find_object_bounding_box_1_0);
MR_declare_entry(mercury__fn__renderer__maybe_transformation_to_trans_1_0);
MR_declare_entry(mercury__fn__space_partition__transform_bounding_box_2_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_string_0;
MR_declare_entry(mercury__exception__throw_1_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_light_0;
MR_declare_entry(mercury__list__length_2_3_0);
static const MR_Float mercury_float_const_2pt00000000000000 = 2.00000000000000;
MR_declare_entry(mercury__fn__renderer__light_unit_vector_2_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data_math__type_ctor_info_domain_error_0;
MR_declare_entry(mercury__fn__vector__project_2_0);
MR_declare_entry(mercury__fn__vector__dot_2_0);
MR_declare_entry(mercury__fn__vector__mag_1_0);
static const MR_Float mercury_float_const_0pt500000000000000 = 0.500000000000000;
MR_declare_entry(mercury__fn__math__sqrt_1_0);
MR_declare_entry(mercury____Unify___vector__vector_0_0);
MR_declare_entry(mercury____Compare___vector__vector_0_0);

MR_BEGIN_MODULE(precompute_lights_module)
	MR_init_entry(mercury__precompute_lights__list__filter__ho9__ua0_4_0);
	MR_init_label(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i4);
	MR_init_label(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i7);
	MR_init_label(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i5);
	MR_init_label(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i3);
	MR_init_entry(mercury__precompute_lights__list__filter__ho8__ua0_4_0);
	MR_init_label(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i4);
	MR_init_label(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i7);
	MR_init_label(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i5);
	MR_init_label(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i3);
	MR_init_entry(mercury__precompute_lights__list__map__ho6__ua0_3_0);
	MR_init_label(mercury__precompute_lights__list__map__ho6__ua0_3_0_i4);
	MR_init_label(mercury__precompute_lights__list__map__ho6__ua0_3_0_i5);
	MR_init_label(mercury__precompute_lights__list__map__ho6__ua0_3_0_i3);
	MR_init_entry(mercury__precompute_lights__list__map__ho4__ua0_3_0);
	MR_init_label(mercury__precompute_lights__list__map__ho4__ua0_3_0_i4);
	MR_init_label(mercury__precompute_lights__list__map__ho4__ua0_3_0_i5);
	MR_init_label(mercury__precompute_lights__list__map__ho4__ua0_3_0_i3);
	MR_init_entry(mercury__precompute_lights__list__map__ho7_3_0);
	MR_init_label(mercury__precompute_lights__list__map__ho7_3_0_i4);
	MR_init_label(mercury__precompute_lights__list__map__ho7_3_0_i5);
	MR_init_label(mercury__precompute_lights__list__map__ho7_3_0_i3);
	MR_init_entry(mercury__precompute_lights__list__map__ho5_3_0);
	MR_init_label(mercury__precompute_lights__list__map__ho5_3_0_i4);
	MR_init_label(mercury__precompute_lights__list__map__ho5_3_0_i5);
	MR_init_label(mercury__precompute_lights__list__map__ho5_3_0_i3);
	MR_init_entry(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0);
	MR_init_label(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0_i4);
	MR_init_label(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0_i3);
	MR_init_label(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0_i5);
	MR_init_entry(mercury__precompute_lights__scene_list_2_0);
	MR_init_label(mercury__precompute_lights__scene_list_2_0_i2);
	MR_init_label(mercury__precompute_lights__scene_list_2_0_i3);
	MR_init_label(mercury__precompute_lights__scene_list_2_0_i4);
	MR_init_label(mercury__precompute_lights__scene_list_2_0_i5);
	MR_init_entry(mercury__precompute_lights__pre_compute_lighting_4_0);
	MR_init_label(mercury__precompute_lights__pre_compute_lighting_4_0_i2);
	MR_init_label(mercury__precompute_lights__pre_compute_lighting_4_0_i3);
	MR_init_entry(mercury__precompute_lights__space_tree_node_list_2_0);
	MR_init_label(mercury__precompute_lights__space_tree_node_list_2_0_i4);
	MR_init_label(mercury__precompute_lights__space_tree_node_list_2_0_i3);
	MR_init_entry(mercury__precompute_lights__object_list_2_0);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i4);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i5);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i7);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i12);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i13);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i14);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i15);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i10);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i17);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i18);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i21);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i23);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i22);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i26);
	MR_init_label(mercury__precompute_lights__object_list_2_0_i27);
	MR_init_entry(mercury__precompute_lights__traverse_part_4_0);
	MR_init_label(mercury__precompute_lights__traverse_part_4_0_i2);
	MR_init_entry(mercury__precompute_lights__traverse_objects_4_0);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i4);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i5);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i7);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i8);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i9);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i10);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i12);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i15);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i19);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i20);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i21);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i22);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i24);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i25);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i23);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i26);
	MR_init_label(mercury__precompute_lights__traverse_objects_4_0_i27);
	MR_init_entry(mercury__precompute_lights__calc_light_list_5_0);
	MR_init_label(mercury__precompute_lights__calc_light_list_5_0_i5);
	MR_init_label(mercury__precompute_lights__calc_light_list_5_0_i7);
	MR_init_label(mercury__precompute_lights__calc_light_list_5_0_i8);
	MR_init_label(mercury__precompute_lights__calc_light_list_5_0_i4);
	MR_init_label(mercury__precompute_lights__calc_light_list_5_0_i10);
	MR_init_label(mercury__precompute_lights__calc_light_list_5_0_i11);
	MR_init_label(mercury__precompute_lights__calc_light_list_5_0_i12);
	MR_init_label(mercury__precompute_lights__calc_light_list_5_0_i13);
	MR_init_entry(mercury__precompute_lights__is_clear_4_0);
	MR_init_label(mercury__precompute_lights__is_clear_4_0_i2);
	MR_init_label(mercury__precompute_lights__is_clear_4_0_i3);
	MR_init_entry(mercury__precompute_lights__single_is_clear_4_0);
	MR_init_label(mercury__precompute_lights__single_is_clear_4_0_i23);
	MR_init_label(mercury__precompute_lights__single_is_clear_4_0_i10);
	MR_init_label(mercury__precompute_lights__single_is_clear_4_0_i11);
	MR_init_label(mercury__precompute_lights__single_is_clear_4_0_i13);
	MR_init_label(mercury__precompute_lights__single_is_clear_4_0_i4);
	MR_init_label(mercury__precompute_lights__single_is_clear_4_0_i14);
	MR_init_label(mercury__precompute_lights__single_is_clear_4_0_i17);
	MR_init_label(mercury__precompute_lights__single_is_clear_4_0_i18);
	MR_init_label(mercury__precompute_lights__single_is_clear_4_0_i15);
	MR_init_label(mercury__precompute_lights__single_is_clear_4_0_i1);
	MR_init_entry(mercury__fn__precompute_lights__bounding_sphere_1_0);
	MR_init_label(mercury__fn__precompute_lights__bounding_sphere_1_0_i2);
	MR_init_label(mercury__fn__precompute_lights__bounding_sphere_1_0_i11);
	MR_init_label(mercury__fn__precompute_lights__bounding_sphere_1_0_i7);
	MR_init_entry(mercury____Unify___precompute_lights__bounding_sphere_0_0);
	MR_init_label(mercury____Unify___precompute_lights__bounding_sphere_0_0_i2);
	MR_init_label(mercury____Unify___precompute_lights__bounding_sphere_0_0_i1);
	MR_init_entry(mercury____Compare___precompute_lights__bounding_sphere_0_0);
	MR_init_label(mercury____Compare___precompute_lights__bounding_sphere_0_0_i3);
	MR_init_label(mercury____Compare___precompute_lights__bounding_sphere_0_0_i6);
	MR_init_label(mercury____Compare___precompute_lights__bounding_sphere_0_0_i7);
	MR_init_label(mercury____Compare___precompute_lights__bounding_sphere_0_0_i10);
MR_BEGIN_CODE

/* code for predicate 'filter__ho9__ua0'/4 in mode 0 */
MR_define_static(mercury__precompute_lights__list__filter__ho9__ua0_4_0);
	if (((MR_Integer) MR_r4 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i3);
	}
	MR_incr_sp_push_msg(5, "list:filter__ho9__ua0/4");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 0);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r2;
	MR_stackvar(4) = MR_r1;
	MR_r4 = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 1);
	MR_localcall(mercury__precompute_lights__list__filter__ho9__ua0_4_0,
		MR_LABEL(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i4),
		MR_STATIC(mercury__precompute_lights__list__filter__ho9__ua0_4_0));
MR_define_label(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__list__filter__ho9__ua0_4_0));
	MR_r3 = MR_stackvar(2);
	MR_stackvar(2) = MR_r1;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	MR_r1 = MR_stackvar(4);
	MR_r4 = MR_stackvar(1);
	}
	MR_localcall(mercury__precompute_lights__single_is_clear_4_0,
		MR_LABEL(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i7),
		MR_STATIC(mercury__precompute_lights__list__filter__ho9__ua0_4_0));
MR_define_label(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__list__filter__ho9__ua0_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i5);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__precompute_lights__list__filter__ho9__ua0_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(2);
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i5);
	MR_r1 = MR_stackvar(2);
	MR_r2 = MR_stackvar(3);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__precompute_lights__list__filter__ho9__ua0_4_0, "list:list/1");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r2;
	MR_r2 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
	}
MR_define_label(mercury__precompute_lights__list__filter__ho9__ua0_4_0_i3);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
/* code for predicate 'filter__ho8__ua0'/4 in mode 0 */
MR_define_static(mercury__precompute_lights__list__filter__ho8__ua0_4_0);
	if (((MR_Integer) MR_r4 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i3);
	}
	MR_incr_sp_push_msg(5, "list:filter__ho8__ua0/4");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 0);
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r2;
	MR_stackvar(4) = MR_r1;
	MR_r4 = MR_const_field(MR_mktag(1), MR_r4, (MR_Integer) 1);
	MR_localcall(mercury__precompute_lights__list__filter__ho8__ua0_4_0,
		MR_LABEL(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i4),
		MR_STATIC(mercury__precompute_lights__list__filter__ho8__ua0_4_0));
MR_define_label(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__list__filter__ho8__ua0_4_0));
	MR_r3 = MR_stackvar(2);
	MR_stackvar(2) = MR_r1;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	MR_r1 = MR_stackvar(4);
	MR_r4 = MR_stackvar(1);
	}
	MR_localcall(mercury__precompute_lights__is_clear_4_0,
		MR_LABEL(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i7),
		MR_STATIC(mercury__precompute_lights__list__filter__ho8__ua0_4_0));
MR_define_label(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__list__filter__ho8__ua0_4_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i5);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__precompute_lights__list__filter__ho8__ua0_4_0, "list:list/1");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_stackvar(2);
	MR_r2 = MR_stackvar(3);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i5);
	MR_r1 = MR_stackvar(2);
	MR_r2 = MR_stackvar(3);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__precompute_lights__list__filter__ho8__ua0_4_0, "list:list/1");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r2;
	MR_r2 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
	}
MR_define_label(mercury__precompute_lights__list__filter__ho8__ua0_4_0_i3);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
/* code for predicate 'map__ho6__ua0'/3 in mode 0 */
MR_define_static(mercury__precompute_lights__list__map__ho6__ua0_3_0);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__precompute_lights__list__map__ho6__ua0_3_0_i3);
	}
	MR_incr_sp_push_msg(4, "list:map__ho6__ua0/3");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r1;
	MR_r3 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_localcall(mercury__precompute_lights__traverse_objects_4_0,
		MR_LABEL(mercury__precompute_lights__list__map__ho6__ua0_3_0_i4),
		MR_STATIC(mercury__precompute_lights__list__map__ho6__ua0_3_0));
MR_define_label(mercury__precompute_lights__list__map__ho6__ua0_3_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__list__map__ho6__ua0_3_0));
	MR_r3 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_stackvar(3);
	MR_r2 = MR_stackvar(2);
	MR_localcall(mercury__precompute_lights__list__map__ho6__ua0_3_0,
		MR_LABEL(mercury__precompute_lights__list__map__ho6__ua0_3_0_i5),
		MR_STATIC(mercury__precompute_lights__list__map__ho6__ua0_3_0));
MR_define_label(mercury__precompute_lights__list__map__ho6__ua0_3_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__list__map__ho6__ua0_3_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__precompute_lights__list__map__ho6__ua0_3_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
	}
MR_define_label(mercury__precompute_lights__list__map__ho6__ua0_3_0_i3);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
/* code for predicate 'map__ho4__ua0'/3 in mode 0 */
MR_define_static(mercury__precompute_lights__list__map__ho4__ua0_3_0);
	if (((MR_Integer) MR_r3 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__precompute_lights__list__map__ho4__ua0_3_0_i3);
	}
	MR_incr_sp_push_msg(4, "list:map__ho4__ua0/3");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r1;
	MR_r3 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_localcall(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0,
		MR_LABEL(mercury__precompute_lights__list__map__ho4__ua0_3_0_i4),
		MR_STATIC(mercury__precompute_lights__list__map__ho4__ua0_3_0));
MR_define_label(mercury__precompute_lights__list__map__ho4__ua0_3_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__list__map__ho4__ua0_3_0));
	MR_r3 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_stackvar(3);
	MR_r2 = MR_stackvar(2);
	MR_localcall(mercury__precompute_lights__list__map__ho4__ua0_3_0,
		MR_LABEL(mercury__precompute_lights__list__map__ho4__ua0_3_0_i5),
		MR_STATIC(mercury__precompute_lights__list__map__ho4__ua0_3_0));
MR_define_label(mercury__precompute_lights__list__map__ho4__ua0_3_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__list__map__ho4__ua0_3_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__precompute_lights__list__map__ho4__ua0_3_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_proceed();
	}
MR_define_label(mercury__precompute_lights__list__map__ho4__ua0_3_0_i3);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
/* code for predicate 'map__ho7'/3 in mode 0 */
MR_define_static(mercury__precompute_lights__list__map__ho7_3_0);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__precompute_lights__list__map__ho7_3_0_i3);
	}
	MR_incr_sp_push_msg(2, "list:map__ho7/3");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__precompute_lights__object_list_2_0,
		MR_LABEL(mercury__precompute_lights__list__map__ho7_3_0_i4),
		MR_STATIC(mercury__precompute_lights__list__map__ho7_3_0));
MR_define_label(mercury__precompute_lights__list__map__ho7_3_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__list__map__ho7_3_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__precompute_lights__list__map__ho7_3_0,
		MR_LABEL(mercury__precompute_lights__list__map__ho7_3_0_i5),
		MR_STATIC(mercury__precompute_lights__list__map__ho7_3_0));
MR_define_label(mercury__precompute_lights__list__map__ho7_3_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__list__map__ho7_3_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__precompute_lights__list__map__ho7_3_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
	}
MR_define_label(mercury__precompute_lights__list__map__ho7_3_0_i3);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
/* code for predicate 'map__ho5'/3 in mode 0 */
MR_define_static(mercury__precompute_lights__list__map__ho5_3_0);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__precompute_lights__list__map__ho5_3_0_i3);
	}
	MR_incr_sp_push_msg(2, "list:map__ho5/3");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__precompute_lights__space_tree_node_list_2_0,
		MR_LABEL(mercury__precompute_lights__list__map__ho5_3_0_i4),
		MR_STATIC(mercury__precompute_lights__list__map__ho5_3_0));
MR_define_label(mercury__precompute_lights__list__map__ho5_3_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__list__map__ho5_3_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__precompute_lights__list__map__ho5_3_0,
		MR_LABEL(mercury__precompute_lights__list__map__ho5_3_0_i5),
		MR_STATIC(mercury__precompute_lights__list__map__ho5_3_0));
MR_define_label(mercury__precompute_lights__list__map__ho5_3_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__list__map__ho5_3_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__precompute_lights__list__map__ho5_3_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
	}
MR_define_label(mercury__precompute_lights__list__map__ho5_3_0_i3);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_proceed();
/* code for predicate 'IntroducedFrom__pred__traverse_part__127__1'/4 in mode 0 */
MR_define_static(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0);
	MR_incr_sp_push_msg(3, "precompute_lights:IntroducedFrom__pred__traverse_part__127__1/4");
	MR_stackvar(3) = (MR_Word) MR_succip;
	if ((MR_tag(MR_r3) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0_i3);
	}
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	}
	MR_localcall(mercury__precompute_lights__list__map__ho4__ua0_3_0,
		MR_LABEL(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0_i4),
		MR_STATIC(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0));
MR_define_label(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0, "space_partition:space_tree/0");
	MR_r4 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 1, mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0, "space_partition:space_tree_node/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
MR_define_label(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0_i3);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	}
	MR_localcall(mercury__precompute_lights__traverse_objects_4_0,
		MR_LABEL(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0_i5),
		MR_STATIC(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0));
MR_define_label(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0, "space_partition:space_tree_object/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 1, mercury__precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_0, "space_partition:space_tree_node/0");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
/* code for predicate 'scene_list'/2 in mode 0 */
MR_define_entry(mercury__precompute_lights__scene_list_2_0);
	MR_incr_sp_push_msg(2, "precompute_lights:scene_list/2");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_localcall(mercury__precompute_lights__list__map__ho7_3_0,
		MR_LABEL(mercury__precompute_lights__scene_list_2_0_i2),
		MR_ENTRY(mercury__precompute_lights__scene_list_2_0));
MR_define_label(mercury__precompute_lights__scene_list_2_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__scene_list_2_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_precompute_lights__type_ctor_info_bounding_sphere_0;
	MR_call_localret(MR_ENTRY(mercury__list__condense_2_0),
		mercury__precompute_lights__scene_list_2_0_i3,
		MR_ENTRY(mercury__precompute_lights__scene_list_2_0));
MR_define_label(mercury__precompute_lights__scene_list_2_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__scene_list_2_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	}
	MR_localcall(mercury__precompute_lights__list__map__ho5_3_0,
		MR_LABEL(mercury__precompute_lights__scene_list_2_0_i4),
		MR_ENTRY(mercury__precompute_lights__scene_list_2_0));
MR_define_label(mercury__precompute_lights__scene_list_2_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__scene_list_2_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_precompute_lights__type_ctor_info_bounding_sphere_0;
	MR_call_localret(MR_ENTRY(mercury__list__condense_2_0),
		mercury__precompute_lights__scene_list_2_0_i5,
		MR_ENTRY(mercury__precompute_lights__scene_list_2_0));
MR_define_label(mercury__precompute_lights__scene_list_2_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__scene_list_2_0));
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_precompute_lights__type_ctor_info_bounding_sphere_0;
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_tailcall(MR_ENTRY(mercury__list__append_3_1),
		MR_ENTRY(mercury__precompute_lights__scene_list_2_0));
/* code for predicate 'pre_compute_lighting'/4 in mode 0 */
MR_define_entry(mercury__precompute_lights__pre_compute_lighting_4_0);
	MR_incr_sp_push_msg(6, "precompute_lights:pre_compute_lighting/4");
	MR_stackvar(6) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_r3 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	}
	MR_localcall(mercury__precompute_lights__list__map__ho4__ua0_3_0,
		MR_LABEL(mercury__precompute_lights__pre_compute_lighting_4_0_i2),
		MR_ENTRY(mercury__precompute_lights__pre_compute_lighting_4_0));
MR_define_label(mercury__precompute_lights__pre_compute_lighting_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__pre_compute_lighting_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__precompute_lights__pre_compute_lighting_4_0, "space_partition:space_tree/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	}
	MR_localcall(mercury__precompute_lights__list__map__ho6__ua0_3_0,
		MR_LABEL(mercury__precompute_lights__pre_compute_lighting_4_0_i3),
		MR_ENTRY(mercury__precompute_lights__pre_compute_lighting_4_0));
MR_define_label(mercury__precompute_lights__pre_compute_lighting_4_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__pre_compute_lighting_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__precompute_lights__pre_compute_lighting_4_0, "space_partition:scene/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
	}
/* code for predicate 'space_tree_node_list'/2 in mode 0 */
MR_define_static(mercury__precompute_lights__space_tree_node_list_2_0);
	if ((MR_tag(MR_r1) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__precompute_lights__space_tree_node_list_2_0_i3);
	}
	MR_incr_sp_push_msg(1, "precompute_lights:space_tree_node_list/2");
	MR_stackvar(1) = (MR_Word) MR_succip;
	MR_r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0), (MR_Integer) 2);
	MR_localcall(mercury__precompute_lights__list__map__ho5_3_0,
		MR_LABEL(mercury__precompute_lights__space_tree_node_list_2_0_i4),
		MR_STATIC(mercury__precompute_lights__space_tree_node_list_2_0));
MR_define_label(mercury__precompute_lights__space_tree_node_list_2_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__space_tree_node_list_2_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_precompute_lights__type_ctor_info_bounding_sphere_0;
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_tailcall(MR_ENTRY(mercury__list__condense_2_0),
		MR_STATIC(mercury__precompute_lights__space_tree_node_list_2_0));
MR_define_label(mercury__precompute_lights__space_tree_node_list_2_0_i3);
	MR_r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0), (MR_Integer) 2);
	MR_localtailcall(mercury__precompute_lights__object_list_2_0,
		MR_STATIC(mercury__precompute_lights__space_tree_node_list_2_0));
/* code for predicate 'object_list'/2 in mode 0 */
MR_define_static(mercury__precompute_lights__object_list_2_0);
	MR_incr_sp_push_msg(2, "precompute_lights:object_list/2");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury__precompute_lights__object_list_2_0_i4) MR_AND
		MR_LABEL(mercury__precompute_lights__object_list_2_0_i7) MR_AND
		MR_LABEL(mercury__precompute_lights__object_list_2_0_i17) MR_AND
		MR_LABEL(mercury__precompute_lights__object_list_2_0_i21));
MR_define_label(mercury__precompute_lights__object_list_2_0_i4);
	MR_call_localret(MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0),
		mercury__precompute_lights__object_list_2_0_i5,
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
MR_define_label(mercury__precompute_lights__object_list_2_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__object_list_2_0));
	MR_localcall(mercury__fn__precompute_lights__bounding_sphere_1_0,
		MR_LABEL(mercury__precompute_lights__object_list_2_0_i15),
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
MR_define_label(mercury__precompute_lights__object_list_2_0_i7);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__precompute_lights__object_list_2_0_i10);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0),
		mercury__precompute_lights__object_list_2_0_i12,
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
MR_define_label(mercury__precompute_lights__object_list_2_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__object_list_2_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__precompute_lights__object_list_2_0, "std_util:maybe/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_tempr1;
	}
	MR_call_localret(MR_ENTRY(mercury__fn__renderer__maybe_transformation_to_trans_1_0),
		mercury__precompute_lights__object_list_2_0_i13,
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
MR_define_label(mercury__precompute_lights__object_list_2_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__object_list_2_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0),
		mercury__precompute_lights__object_list_2_0_i14,
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
MR_define_label(mercury__precompute_lights__object_list_2_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__object_list_2_0));
	MR_localcall(mercury__fn__precompute_lights__bounding_sphere_1_0,
		MR_LABEL(mercury__precompute_lights__object_list_2_0_i15),
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
MR_define_label(mercury__precompute_lights__object_list_2_0_i15);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__object_list_2_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__precompute_lights__object_list_2_0, "list:list/1");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_r1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
	}
MR_define_label(mercury__precompute_lights__object_list_2_0_i10);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) MR_string_const("object_list can't handle complex transform objects!", 51);
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
MR_define_label(mercury__precompute_lights__object_list_2_0_i17);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__precompute_lights__object_list_2_0,
		MR_LABEL(mercury__precompute_lights__object_list_2_0_i18),
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
MR_define_label(mercury__precompute_lights__object_list_2_0_i18);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__object_list_2_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__precompute_lights__object_list_2_0,
		MR_LABEL(mercury__precompute_lights__object_list_2_0_i27),
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
MR_define_label(mercury__precompute_lights__object_list_2_0_i21);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__precompute_lights__object_list_2_0_i22);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_localcall(mercury__precompute_lights__object_list_2_0,
		MR_LABEL(mercury__precompute_lights__object_list_2_0_i23),
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
MR_define_label(mercury__precompute_lights__object_list_2_0_i23);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__object_list_2_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__precompute_lights__object_list_2_0,
		MR_LABEL(mercury__precompute_lights__object_list_2_0_i27),
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
MR_define_label(mercury__precompute_lights__object_list_2_0_i22);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_localcall(mercury__precompute_lights__object_list_2_0,
		MR_LABEL(mercury__precompute_lights__object_list_2_0_i26),
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
MR_define_label(mercury__precompute_lights__object_list_2_0_i26);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__object_list_2_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	}
	MR_localcall(mercury__precompute_lights__object_list_2_0,
		MR_LABEL(mercury__precompute_lights__object_list_2_0_i27),
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
MR_define_label(mercury__precompute_lights__object_list_2_0_i27);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__object_list_2_0));
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_precompute_lights__type_ctor_info_bounding_sphere_0;
	MR_r2 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_tailcall(MR_ENTRY(mercury__list__append_3_1),
		MR_STATIC(mercury__precompute_lights__object_list_2_0));
/* code for predicate 'traverse_part'/4 in mode 0 */
MR_define_entry(mercury__precompute_lights__traverse_part_4_0);
	MR_incr_sp_push_msg(3, "precompute_lights:traverse_part/4");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_r2;
	MR_r2 = MR_r3;
	MR_r3 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	}
	MR_localcall(mercury__precompute_lights__list__map__ho4__ua0_3_0,
		MR_LABEL(mercury__precompute_lights__traverse_part_4_0_i2),
		MR_ENTRY(mercury__precompute_lights__traverse_part_4_0));
MR_define_label(mercury__precompute_lights__traverse_part_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__traverse_part_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__precompute_lights__traverse_part_4_0, "space_partition:space_tree/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
/* code for predicate 'traverse_objects'/4 in mode 0 */
MR_define_entry(mercury__precompute_lights__traverse_objects_4_0);
	MR_incr_sp_push_msg(6, "precompute_lights:traverse_objects/4");
	MR_stackvar(6) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r3),
		MR_LABEL(mercury__precompute_lights__traverse_objects_4_0_i4) MR_AND
		MR_LABEL(mercury__precompute_lights__traverse_objects_4_0_i12) MR_AND
		MR_LABEL(mercury__precompute_lights__traverse_objects_4_0_i19) MR_AND
		MR_LABEL(mercury__precompute_lights__traverse_objects_4_0_i22));
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1);
	MR_stackvar(4) = MR_tempr1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0);
	if (!(((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 1)))) {
		MR_GOTO_LABEL(mercury__precompute_lights__traverse_objects_4_0_i5);
	}
	MR_r1 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
	}
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i5);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_r1 = MR_r3;
	MR_call_localret(MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0),
		mercury__precompute_lights__traverse_objects_4_0_i7,
		MR_ENTRY(mercury__precompute_lights__traverse_objects_4_0));
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__traverse_objects_4_0));
	MR_localcall(mercury__fn__precompute_lights__bounding_sphere_1_0,
		MR_LABEL(mercury__precompute_lights__traverse_objects_4_0_i8),
		MR_ENTRY(mercury__precompute_lights__traverse_objects_4_0));
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__traverse_objects_4_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_r3 = MR_stackvar(1);
	MR_r4 = MR_stackvar(2);
	}
	MR_localcall(mercury__precompute_lights__list__filter__ho8__ua0_4_0,
		MR_LABEL(mercury__precompute_lights__traverse_objects_4_0_i9),
		MR_ENTRY(mercury__precompute_lights__traverse_objects_4_0));
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__traverse_objects_4_0));
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_light_0;
	MR_r2 = MR_stackvar(5);
	MR_call_localret(MR_ENTRY(mercury__list__append_3_1),
		mercury__precompute_lights__traverse_objects_4_0_i10,
		MR_ENTRY(mercury__precompute_lights__traverse_objects_4_0));
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__traverse_objects_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__precompute_lights__traverse_objects_4_0, "eval:object/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
	}
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i12);
	MR_r5 = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 0);
	if ((MR_tag(MR_r5) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__precompute_lights__traverse_objects_4_0_i15);
	}
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__precompute_lights__traverse_objects_4_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r3 = MR_r1;
	MR_r1 = MR_r5;
	MR_r4 = MR_r2;
	MR_r2 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_localtailcall(mercury__precompute_lights__calc_light_list_5_0,
		MR_ENTRY(mercury__precompute_lights__traverse_objects_4_0));
	}
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i15);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) MR_string_const("traverse_objects can't handle complex transform objects!", 56);
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_ENTRY(mercury__precompute_lights__traverse_objects_4_0));
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i19);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(2), MR_r3, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(2), MR_r3, (MR_Integer) 0);
	MR_localcall(mercury__precompute_lights__traverse_objects_4_0,
		MR_LABEL(mercury__precompute_lights__traverse_objects_4_0_i20),
		MR_ENTRY(mercury__precompute_lights__traverse_objects_4_0));
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i20);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__traverse_objects_4_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	}
	MR_localcall(mercury__precompute_lights__traverse_objects_4_0,
		MR_LABEL(mercury__precompute_lights__traverse_objects_4_0_i21),
		MR_ENTRY(mercury__precompute_lights__traverse_objects_4_0));
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i21);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__traverse_objects_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 2, mercury__precompute_lights__traverse_objects_4_0, "eval:object/0");
	MR_r5 = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
	}
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i22);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__precompute_lights__traverse_objects_4_0_i23);
	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 2);
	MR_r3 = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 1);
	MR_localcall(mercury__precompute_lights__traverse_objects_4_0,
		MR_LABEL(mercury__precompute_lights__traverse_objects_4_0_i24),
		MR_ENTRY(mercury__precompute_lights__traverse_objects_4_0));
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i24);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__traverse_objects_4_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	}
	MR_localcall(mercury__precompute_lights__traverse_objects_4_0,
		MR_LABEL(mercury__precompute_lights__traverse_objects_4_0_i25),
		MR_ENTRY(mercury__precompute_lights__traverse_objects_4_0));
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i25);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__traverse_objects_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 3, mercury__precompute_lights__traverse_objects_4_0, "eval:object/0");
	MR_r4 = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 0;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
	}
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i23);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 2);
	MR_r3 = MR_const_field(MR_mktag(3), MR_r3, (MR_Integer) 1);
	MR_localcall(mercury__precompute_lights__traverse_objects_4_0,
		MR_LABEL(mercury__precompute_lights__traverse_objects_4_0_i26),
		MR_ENTRY(mercury__precompute_lights__traverse_objects_4_0));
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i26);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__traverse_objects_4_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	}
	MR_localcall(mercury__precompute_lights__traverse_objects_4_0,
		MR_LABEL(mercury__precompute_lights__traverse_objects_4_0_i27),
		MR_ENTRY(mercury__precompute_lights__traverse_objects_4_0));
MR_define_label(mercury__precompute_lights__traverse_objects_4_0_i27);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__traverse_objects_4_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 3, mercury__precompute_lights__traverse_objects_4_0, "eval:object/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
	}
/* code for predicate 'calc_light_list'/5 in mode 0 */
MR_define_static(mercury__precompute_lights__calc_light_list_5_0);
	MR_incr_sp_push_msg(7, "precompute_lights:calc_light_list/5");
	MR_stackvar(7) = (MR_Word) MR_succip;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(5) = MR_tempr1;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if (((MR_tag(MR_tempr1) == MR_mktag((MR_Integer) 3)) && ((MR_Integer) MR_const_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) == (MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__precompute_lights__calc_light_list_5_0_i13);
	}
	if (((MR_Integer) MR_r2 != (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__precompute_lights__calc_light_list_5_0_i5);
	}
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	}
	MR_call_localret(MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0),
		mercury__precompute_lights__calc_light_list_5_0_i4,
		MR_STATIC(mercury__precompute_lights__calc_light_list_5_0));
MR_define_label(mercury__precompute_lights__calc_light_list_5_0_i5);
	MR_stackvar(1) = MR_r2;
	MR_stackvar(2) = MR_r3;
	MR_stackvar(3) = MR_r4;
	MR_call_localret(MR_ENTRY(mercury__fn__space_partition__find_object_bounding_box_1_0),
		mercury__precompute_lights__calc_light_list_5_0_i7,
		MR_STATIC(mercury__precompute_lights__calc_light_list_5_0));
MR_define_label(mercury__precompute_lights__calc_light_list_5_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__calc_light_list_5_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__renderer__maybe_transformation_to_trans_1_0),
		mercury__precompute_lights__calc_light_list_5_0_i8,
		MR_STATIC(mercury__precompute_lights__calc_light_list_5_0));
MR_define_label(mercury__precompute_lights__calc_light_list_5_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__calc_light_list_5_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__fn__space_partition__transform_bounding_box_2_0),
		mercury__precompute_lights__calc_light_list_5_0_i4,
		MR_STATIC(mercury__precompute_lights__calc_light_list_5_0));
MR_define_label(mercury__precompute_lights__calc_light_list_5_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__calc_light_list_5_0));
	MR_localcall(mercury__fn__precompute_lights__bounding_sphere_1_0,
		MR_LABEL(mercury__precompute_lights__calc_light_list_5_0_i10),
		MR_STATIC(mercury__precompute_lights__calc_light_list_5_0));
MR_define_label(mercury__precompute_lights__calc_light_list_5_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__calc_light_list_5_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_r3 = MR_stackvar(2);
	MR_r4 = MR_stackvar(3);
	}
	MR_localcall(mercury__precompute_lights__list__filter__ho8__ua0_4_0,
		MR_LABEL(mercury__precompute_lights__calc_light_list_5_0_i11),
		MR_STATIC(mercury__precompute_lights__calc_light_list_5_0));
MR_define_label(mercury__precompute_lights__calc_light_list_5_0_i11);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__calc_light_list_5_0));
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_light_0;
	MR_r2 = MR_stackvar(6);
	MR_call_localret(MR_ENTRY(mercury__list__append_3_1),
		mercury__precompute_lights__calc_light_list_5_0_i12,
		MR_STATIC(mercury__precompute_lights__calc_light_list_5_0));
MR_define_label(mercury__precompute_lights__calc_light_list_5_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__calc_light_list_5_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__precompute_lights__calc_light_list_5_0, "eval:object/0");
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	}
MR_define_label(mercury__precompute_lights__calc_light_list_5_0_i13);
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
/* code for predicate 'is_clear'/4 in mode 0 */
MR_define_static(mercury__precompute_lights__is_clear_4_0);
	MR_incr_sp_push_msg(1, "precompute_lights:is_clear/4");
	MR_stackvar(1) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r4;
	MR_r4 = MR_r3;
	MR_r3 = MR_tempr1;
	}
	MR_localcall(mercury__precompute_lights__list__filter__ho9__ua0_4_0,
		MR_LABEL(mercury__precompute_lights__is_clear_4_0_i2),
		MR_STATIC(mercury__precompute_lights__is_clear_4_0));
MR_define_label(mercury__precompute_lights__is_clear_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__is_clear_4_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_precompute_lights__type_ctor_info_bounding_sphere_0;
	MR_r3 = (MR_Integer) 0;
	MR_call_localret(MR_ENTRY(mercury__list__length_2_3_0),
		mercury__precompute_lights__is_clear_4_0_i3,
		MR_STATIC(mercury__precompute_lights__is_clear_4_0));
MR_define_label(mercury__precompute_lights__is_clear_4_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__is_clear_4_0));
	MR_r1 = ((MR_Integer) MR_r1 <= (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
/* code for predicate 'single_is_clear'/4 in mode 0 */
MR_define_static(mercury__precompute_lights__single_is_clear_4_0);
	MR_incr_sp_push_msg(7, "precompute_lights:single_is_clear/4");
	MR_stackvar(7) = (MR_Word) MR_succip;
	MR_tag_incr_hp_msg(MR_stackvar(5), MR_mktag(0), (MR_Integer) 3, mercury__precompute_lights__single_is_clear_4_0, "vector:vector/0");
	MR_r5 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 0)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))));
	MR_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 1)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1))));
	MR_field(MR_mktag(0), MR_stackvar(5), (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 2)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2))));
	if ((MR_tag(MR_r3) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__precompute_lights__single_is_clear_4_0_i4);
	}
	if ((MR_tag(MR_r3) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__precompute_lights__single_is_clear_4_0_i4);
	}
	{
	MR_Float	Max;
#define	MR_PROC_LABEL	mercury__precompute_lights__single_is_clear_4_0
{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
Max = ML_FLOAT_MAX;;}
#line 1787 "precompute_lights.c"
	MR_r5 = MR_float_to_word(Max);
#undef	MR_PROC_LABEL

	}
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1);
	MR_stackvar(1) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__precompute_lights__single_is_clear_4_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1805 "precompute_lights.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__precompute_lights__single_is_clear_4_0_i23);
#undef	MR_PROC_LABEL

	}
	if (((MR_Float) 2.00000000000000 == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__precompute_lights__single_is_clear_4_0_i10);
	}
MR_define_label(mercury__precompute_lights__single_is_clear_4_0_i23);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_stackvar(6) = MR_r5;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(3);
	MR_r5 = MR_stackvar(6);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_r2;
	MR_r1 = MR_r3;
	MR_stackvar(3) = MR_float_to_word((MR_word_to_float(MR_r5) / (MR_Float) 2.00000000000000));
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_precompute_lights__common_0);
	MR_call_localret(MR_ENTRY(mercury__fn__renderer__light_unit_vector_2_0),
		mercury__precompute_lights__single_is_clear_4_0_i13,
		MR_STATIC(mercury__precompute_lights__single_is_clear_4_0));
MR_define_label(mercury__precompute_lights__single_is_clear_4_0_i10);
	MR_stackvar(2) = MR_r2;
	MR_stackvar(3) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__precompute_lights__single_is_clear_4_0_i11,
		MR_STATIC(mercury__precompute_lights__single_is_clear_4_0));
MR_define_label(mercury__precompute_lights__single_is_clear_4_0_i11);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__single_is_clear_4_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(3);
	MR_call_localret(MR_ENTRY(mercury__fn__renderer__light_unit_vector_2_0),
		mercury__precompute_lights__single_is_clear_4_0_i13,
		MR_STATIC(mercury__precompute_lights__single_is_clear_4_0));
MR_define_label(mercury__precompute_lights__single_is_clear_4_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__single_is_clear_4_0));
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 3, mercury__precompute_lights__single_is_clear_4_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_float_to_word(((MR_word_to_float(MR_stackvar(3)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0))));
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_stackvar(3)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1))) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1))));
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 2) = MR_float_to_word(((MR_word_to_float(MR_stackvar(3)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2))) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2))));
	MR_r1 = MR_stackvar(5);
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__vector__project_2_0),
		mercury__precompute_lights__single_is_clear_4_0_i14,
		MR_STATIC(mercury__precompute_lights__single_is_clear_4_0));
MR_define_label(mercury__precompute_lights__single_is_clear_4_0_i4);
	MR_tag_incr_hp_msg(MR_r5, MR_mktag(0), (MR_Integer) 3, mercury__precompute_lights__single_is_clear_4_0, "vector:vector/0");
	MR_r6 = MR_const_mask_field(MR_r3, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 0)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 1)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1))));
	MR_field(MR_mktag(0), MR_r5, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r6, (MR_Integer) 2)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2))));
	MR_stackvar(2) = MR_r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1);
	MR_r1 = MR_stackvar(5);
	MR_r2 = MR_r5;
	MR_stackvar(1) = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__fn__vector__project_2_0),
		mercury__precompute_lights__single_is_clear_4_0_i14,
		MR_STATIC(mercury__precompute_lights__single_is_clear_4_0));
MR_define_label(mercury__precompute_lights__single_is_clear_4_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__single_is_clear_4_0));
	MR_r2 = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))) * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0)))) + ((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1))) * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1))))) + ((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2))) * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2))))));
	MR_r3 = MR_float_to_word(((MR_word_to_float(MR_stackvar(2)) + MR_word_to_float(MR_stackvar(4))) * (MR_word_to_float(MR_stackvar(2)) + MR_word_to_float(MR_stackvar(4)))));
	if ((MR_word_to_float(MR_r2) > MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury__precompute_lights__single_is_clear_4_0_i15);
	}
	MR_r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_call_localret(MR_ENTRY(mercury__fn__vector__dot_2_0),
		mercury__precompute_lights__single_is_clear_4_0_i17,
		MR_STATIC(mercury__precompute_lights__single_is_clear_4_0));
MR_define_label(mercury__precompute_lights__single_is_clear_4_0_i17);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__single_is_clear_4_0));
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__precompute_lights__single_is_clear_4_0_i1);
	}
	MR_r1 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__fn__vector__mag_1_0),
		mercury__precompute_lights__single_is_clear_4_0_i18,
		MR_STATIC(mercury__precompute_lights__single_is_clear_4_0));
MR_define_label(mercury__precompute_lights__single_is_clear_4_0_i18);
	MR_update_prof_current_proc(MR_LABEL(mercury__precompute_lights__single_is_clear_4_0));
	MR_r2 = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) + MR_word_to_float(MR_stackvar(2))));
	MR_r1 = (MR_word_to_float(MR_r1) > MR_word_to_float(MR_r2));
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_proceed();
MR_define_label(mercury__precompute_lights__single_is_clear_4_0_i15);
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_r1 = TRUE;
	MR_proceed();
MR_define_label(mercury__precompute_lights__single_is_clear_4_0_i1);
	MR_succip = (MR_Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate 'bounding_sphere'/2 in mode 0 */
MR_define_static(mercury__fn__precompute_lights__bounding_sphere_1_0);
	MR_incr_sp_push_msg(3, "precompute_lights:bounding_sphere/2");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_tag_incr_hp_msg(MR_stackvar(1), MR_mktag(0), (MR_Integer) 3, mercury__fn__precompute_lights__bounding_sphere_1_0, "vector:vector/0");
	MR_r2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0) = MR_float_to_word(((MR_Float) 0.500000000000000 * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0)) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0)))));
	MR_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1) = MR_float_to_word(((MR_Float) 0.500000000000000 * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1)) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1)))));
	MR_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2) = MR_float_to_word(((MR_Float) 0.500000000000000 * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2)) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2)))));
	MR_r1 = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0))) * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 0)))) + ((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1))) * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 1))))) + ((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2))) * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r3, (MR_Integer) 2))))));
	MR_call_localret(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		mercury__fn__precompute_lights__bounding_sphere_1_0_i2,
		MR_STATIC(mercury__fn__precompute_lights__bounding_sphere_1_0));
MR_define_label(mercury__fn__precompute_lights__bounding_sphere_1_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__precompute_lights__bounding_sphere_1_0));
	MR_stackvar(2) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__precompute_lights__bounding_sphere_1_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1935 "precompute_lights.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__precompute_lights__bounding_sphere_1_0_i11);
#undef	MR_PROC_LABEL

	}
	if (((MR_Float) 2.00000000000000 == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__precompute_lights__bounding_sphere_1_0_i7);
	}
MR_define_label(mercury__fn__precompute_lights__bounding_sphere_1_0_i11);
	MR_r1 = MR_stackvar(2);
	MR_tag_incr_hp_msg(MR_r2, MR_mktag(0), (MR_Integer) 2, mercury__fn__precompute_lights__bounding_sphere_1_0, "precompute_lights:bounding_sphere/0");
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r2, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r1) / (MR_Float) 2.00000000000000));
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__fn__precompute_lights__bounding_sphere_1_0_i7);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_STATIC(mercury__fn__precompute_lights__bounding_sphere_1_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___precompute_lights__bounding_sphere_0_0);
	MR_incr_sp_push_msg(3, "precompute_lights:__Unify__/2");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Unify___vector__vector_0_0),
		mercury____Unify___precompute_lights__bounding_sphere_0_0_i2,
		MR_ENTRY(mercury____Unify___precompute_lights__bounding_sphere_0_0));
MR_define_label(mercury____Unify___precompute_lights__bounding_sphere_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___precompute_lights__bounding_sphere_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___precompute_lights__bounding_sphere_0_0_i1);
	}
	MR_r1 = (MR_word_to_float(MR_stackvar(1)) == MR_word_to_float(MR_stackvar(2)));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Unify___precompute_lights__bounding_sphere_0_0_i1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___precompute_lights__bounding_sphere_0_0);
	MR_incr_sp_push_msg(3, "precompute_lights:__Compare__/3");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_call_localret(MR_ENTRY(mercury____Compare___vector__vector_0_0),
		mercury____Compare___precompute_lights__bounding_sphere_0_0_i3,
		MR_ENTRY(mercury____Compare___precompute_lights__bounding_sphere_0_0));
MR_define_label(mercury____Compare___precompute_lights__bounding_sphere_0_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___precompute_lights__bounding_sphere_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___precompute_lights__bounding_sphere_0_0_i10);
	}
	if ((MR_word_to_float(MR_stackvar(1)) >= MR_word_to_float(MR_stackvar(2)))) {
		MR_GOTO_LABEL(mercury____Compare___precompute_lights__bounding_sphere_0_0_i6);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Compare___precompute_lights__bounding_sphere_0_0_i6);
	if ((MR_word_to_float(MR_stackvar(1)) <= MR_word_to_float(MR_stackvar(2)))) {
		MR_GOTO_LABEL(mercury____Compare___precompute_lights__bounding_sphere_0_0_i7);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury____Compare___precompute_lights__bounding_sphere_0_0_i7);
	MR_r1 = (MR_Integer) 0;
MR_define_label(mercury____Compare___precompute_lights__bounding_sphere_0_0_i10);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__precompute_lights_maybe_bunch_0(void)
{
	precompute_lights_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__precompute_lights__init(void);
void mercury__precompute_lights__init_type_tables(void);
void mercury__precompute_lights__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__precompute_lights__write_out_proc_statics(FILE *fp);
#endif

void mercury__precompute_lights__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__precompute_lights_maybe_bunch_0();
#endif

	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_precompute_lights__type_ctor_info_bounding_sphere_0,
		precompute_lights__bounding_sphere_0_0);
	mercury__precompute_lights__init_debugger();
}

void mercury__precompute_lights__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
	MR_register_type_ctor_info(
		&mercury_data_precompute_lights__type_ctor_info_bounding_sphere_0);
}


void mercury__precompute_lights__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__precompute_lights__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
