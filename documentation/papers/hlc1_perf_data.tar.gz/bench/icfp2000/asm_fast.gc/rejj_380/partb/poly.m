%-----------------------------------------------------------------------------%
%
% 433-380 Project, part B
% Robert Jeschofnik (rejj), 55572
%
% poly.m
%
% Written in Mercury, because C sucks.
%
% Polys are shaded, then projected into 2D, then clipped to the image plane.
% Then the scanlines for each face are generated, and drawn into the image
% buffer. Finally, the image is flushed to stdout.
%
%-----------------------------------------------------------------------------%

:- module poly.

:- interface.

:- include_module poly__image, poly__transform, poly__zbuffer, poly__lighting.
:- import_module float, int, list, array, io, std_util.
:- import_module poly__image, poly__zbuffer, poly__lighting.

% The instantiation for a unique polyhedron
:- inst uniq_polyhedron == unique(polyhedron(uniq_array, ground)).

:- mode polyhedron_di == di(uniq_polyhedron).
:- mode polyhedron_uo == out(uniq_polyhedron).
:- mode polyhedron_ui == in(uniq_polyhedron).

% The instantiation for a world of unique polyhedrons (The entire scene)
:- inst world_uniq_polys == uniq_array(uniq_polyhedron).

:- mode world_di == di(world_uniq_polys).
:- mode world_uo == out(world_uniq_polys).
:- mode world_ui == in(world_uniq_polys).

%-----------------------------------------------------------------------------%

% The type for a vertex in 3D space. Holds it's X, Y, Z coordinates.
% NOTE: Make this an ADT, in it's own module.
% or just put all the polyhedron stuff in it's own module.. vertex, face, etc
%
% vertex(X, Y, Z)
:- type vertex --->
	vertex(float, float, float).

% A face of the polyhedron is a list of the verticies, given as indicies into
% the vertex_array, along with the colour.
:- type face --->
	face(colour, list(int)).

% The type for the polyhedron itself. Groups together the verticies and the
% faces.
% polyhedron(Verts, Faces)
:- type polyhedron --->
	polyhedron(array(vertex), list(face)).

% The type that encapsulates the entire world. For part a, this is just a list
% of all the polyhedrons in it. This will be expanded to include light sources
% and the ambient light level in part b.
:- type world == array(polyhedron).


% Types handy for passing around the scale, rotate, and translate transforms
% for each object as listed in the scene description format.


% scale(Sx, Sy, Sz)
:- type scale --->
	scale(float, float, float).

% rotate(Rx, Ry, Rz)
:- type rotate --->
	rotate(float, float, float).

% translate(Tx, Ty, Tz)
:- type translate --->
	translate(float, float, float).

% Type to bundle all the transforms together. Encapsulates all the 3D
% transforms to be applied to any given object.
% transform(Scale factor, Rotation, Translation)
:- type transform --->
	transform(scale, rotate, translate).

% Colours are represented as floats between 0.0 and 1.0 internally, and only
% converted to ints of the range 0 - 255 as they are output to the image file.
% colour(Red, Green, Blue)
:- type colour --->
	colour(float, float, float).

% A light is represented by it's intensity, which is stored as a float, and it's
% position, which is stored as a vertex.
:- type light --->
	light(float, vertex, colour).

% A scanline is a list of X-intercepts.
:- type scanline == list(pair(int, float)).

%-----------------------------------------------------------------------------%

%:- pred poly__translate(translate, polyhedron, polyhedron).
%:- mode poly__translate(in, polyhedron_di, polyhedron_uo) is det.

:- pred poly__project(float, int, int, polyhedron, polyhedron).
:- mode poly__project(in, in, in, polyhedron_di, polyhedron_uo) is det.

:- pred poly__draw(int, int, float, polyhedron, zbuffer, zbuffer, image, image).
:- mode poly__draw(in, in, in, polyhedron_ui, array_di, array_uo, array_di, array_uo) is det.

:- pred poly__draw_scene(float, int, int, float, array(light), array(polyhedron), zbuffer, zbuffer, image, image, io__state, io__state).
:- mode poly__draw_scene(in, in, in, in, array_ui, array_ui, array_di, array_uo, array_di, array_uo, di, uo) is det.

%-----------------------------------------------------------------------------%

:- implementation.

:- import_module require, string.


:- pred do_proj(int, int, int, int, float, int, int, array(vertex), array(vertex)).
:- mode do_proj(in, in, in, in, in, in, in, array_di, array_uo) is det.

:- pred make_scanlines(int, int, array(vertex), int, int, array(scanline), array(scanline)).
:- mode make_scanlines(in, in, array_ui, in, in, array_di, array_uo) is det.

:- pred trace_edge(int, int, int, int, int, int, float, float, int, array(scanline), array(scanline)).
:- mode trace_edge(in, in, in, in, in, in, in, in, in, array_di, array_uo) is det.

:- pred draw_hline(int, int, float, float, int, int, colour, zbuffer, zbuffer, image, image).
:- mode draw_hline(in, in, in, in, in, in, in, array_di, array_uo, array_di, array_uo) is det.

:- pred make_face(array(vertex), list(int), int, array(vertex), array(vertex)).
:- mode make_face(array_ui, in, in, array_di, array_uo) is det.

:- pred draw_scanlines(int, int, array(scanline), int, colour, zbuffer, zbuffer, image, image).
:- mode draw_scanlines(in, in, array_ui, in, in, array_di, array_uo, array_di, array_uo) is det.

:- pred draw_one_scanline(scanline, int, int, colour, zbuffer, zbuffer, image, image).
:- mode draw_one_scanline(in, in, in, in, array_di, array_uo, array_di, array_uo) is det.

:- pred do_draw_scene(float, int, int, int, int, float, array(light), world, zbuffer, zbuffer, image, image).
:- mode do_draw_scene(in, in, in, in, in, in, array_ui, array_ui, array_di, array_uo, array_di, array_uo) is det.

:- pred check_x_on_screen(int, int).
:- mode check_x_on_screen(in, in) is semidet.

%-----------------------------------------------------------------------------%

% Project a polygon from 3D to 2D.
poly__project(Focal, Width, Height, polyhedron(Vs_3D, Fs), polyhedron(Vs_2D, Fs)) :-
	Xoff = Width div 2,
	Yoff = Height div 2,
	Vs0 = Vs_3D,
	array__size(Vs0, NV),
	do_proj(Xoff, Yoff, Width, Height, Focal, NV, 0, Vs0, Vs_2D).


% Recursively project each vertex in the given array of vertices from 3D to
% 2D
do_proj(Xoff, Yoff, Width, Height, Focal, NV, Elem, Vs_3D, Vs_2D) :-
	(
	    Elem < NV
	->
	    array__lookup(Vs_3D, Elem, vertex(X0, Y0, Z)),
	    X_proj0 = (X0 * Focal) / Z,
	    X_proj = X_proj0 * -1.0,
	    X = float(Xoff) + X_proj,
	    Y = float(Yoff) + ((Y0 * Focal) / Z),
	    
	    % The projected coordinates lie in the Z = 1 plane, but the
	    % original depth is still needed for other calculations, (ie Z
	    % buffer) so it is maintained. Drawing will only look at the X and Y
	    % elements.
	    array__set(Vs_3D, Elem, vertex(X, Y, Z), Vs0),
	    do_proj(Xoff, Yoff, Width, Height, Focal, NV, Elem + 1, Vs0, Vs_2D)
	;
	    % No more verticies left to project
	    Vs_2D = Vs_3D
	).


% Draws the projected polyhedron into the image
poly__draw(Width, Height, Ambient, polyhedron(Vs, Fs), Zbuf_in, Zbuf_out, Image_in, Image_out) :-
	(
	    Fs = [],
	    Image_out = Image_in,
	    Zbuf_out = Zbuf_in
	;
	    Fs = [face(Colour, Vlist) | Faces],
	    list__length(Vlist, Length),
	    array__init(Height, [], ScanLines_init),
	    array__init(Length, vertex(0.0, 0.0, 0.0), Poly_init),

	    % Generate the face
	    make_face(Vs, Vlist, 0, Poly_init, Poly),
	    
	    % Generate the scanlines for this face
	    make_scanlines(Width, Height, Poly, Length, 0, ScanLines_init, ScanLines),
	    
	    % Render the face into the image buffer
	    draw_scanlines(Width, Height, ScanLines, 0, Colour, Zbuf_in, Zbuf0, Image_in, Image0),

	    % Recursively draw the rest of the faces in this polyhedron
	    poly__draw(Width, Height, Ambient, polyhedron(Vs, Faces), Zbuf0, Zbuf_out, Image0, Image_out)
	).


% Generate the face given by the list of verticies (Face)
make_face(ObjVs, Face, Elem, PolyVs_in, PolyVs_out) :-
	(
	    Face = [],
	    PolyVs_in = PolyVs_out
	;
	    Face = [Vert | Verts],
	    array__lookup(ObjVs, Vert, V),
	    array__set(PolyVs_in, Elem, V, PolyVs0),
	    make_face(ObjVs, Verts, Elem + 1, PolyVs0, PolyVs_out)
	).
	    

% Generate the horizontal lines that make up one face.
% If part of the polygon lies behind or at Z = 0, the scanlines at that
% position are not generated.
make_scanlines(Width, Height, Poly, Size, Elem, ScanLines0, ScanLines) :-
	(
	    Elem < (Size -1)
	->
	    % Lookup the two verticies to make the current edge
	    array__lookup(Poly, Elem, vertex(X1, Y1, Z1)),
	    array__lookup(Poly, Elem + 1, vertex(X2, Y2, Z2)),

	    % If either of the Z values are positive, the entire edge
	    % must be behind the camera, since in this assignment the assumption
	    % is made that no objects can intersect the Z=0 plane.
	    % If this is the case, don't even bother tracing along it
	    (	
		Z1 >= 0.0
	    ->
		ScanLines = ScanLines0
	    ;
		(
		    Z2 >= 0.0
		->
		    ScanLines = ScanLines0
		;
		    % The image is digital, so the floating point representation
		    % for coordinates must be rounded off to integers
		    round_to_int(X1) = X1i,
		    round_to_int(Y1) = Y1i,
		    round_to_int(X2) = X2i,
		    round_to_int(Y2) = Y2i,

		    % Ensure that the edge is traced from the vertex with the
		    % smaller Y to that with the larger Y.
		    (	
			Y1i < Y2i
		    ->
			DeltaZ = (Z2 - Z1) / float(Y2i - Y1i),
			trace_edge(Width, Height, X1i, Y1i, X2i, Y2i, Z1, DeltaZ, Y1i, ScanLines0, ScanLines1)
		    ;
			DeltaZ = (Z1 - Z2) / float(Y1i - Y2i),
			trace_edge(Width, Height, X2i, Y2i, X1i, Y1i, Z2, DeltaZ, Y2i, ScanLines0, ScanLines1)
		    ),

		    % Make the rest of the scanlines for this face
		    make_scanlines(Width, Height, Poly, Size, Elem + 1, ScanLines1, ScanLines) 
		)
	    )
	;
	    
	    (	
		Elem = (Size - 1)
	    ->	
		% The final egde is between the last and the first verticies
		array__lookup(Poly, Elem, vertex(X1, Y1, Z1)),
		array__lookup(Poly, 0, vertex(X2, Y2, Z2)),

		% Make sure the edge is not behind the camera
		(   
		    Z1 >= 0.0
		->  
		    ScanLines = ScanLines0
		;   
		    (	
			Z2 >= 0.0
		    ->	
			ScanLines = ScanLines0
		    ;
		        % The image is digital, so the floating point
		        % representation for coordinates must be rounded off to
			% integers
			round_to_int(X1) = X1i,
			round_to_int(Y1) = Y1i,
			round_to_int(X2) = X2i,
			round_to_int(Y2) = Y2i,

			% Make sure the edge is traced bottom to top
			(   
			    Y1i < Y2i
			->
			    DeltaZ = (Z2 - Z1) / float(Y2i - Y1i),
			    trace_edge(Width, Height, X1i, Y1i, X2i, Y2i, Z1, DeltaZ, Y1i, ScanLines0, ScanLines)
			;
			    DeltaZ = (Z1 - Z2) / float(Y1i - Y2i),
			    trace_edge(Width, Height, X2i, Y2i, X1i, Y1i, Z2, DeltaZ, Y2i, ScanLines0, ScanLines)
			)
		    )
		)
	    ;	
		% There are no more edges to trace
		ScanLines = ScanLines0
	    )
	).


% Trace along the line from (X1, Y1) to (X2, Y2) finding the X intersections
% for each integer value of Y along the line. These are used as the endpoints
% for the scanlines
trace_edge(Width, Height, X1, Y1, X2, Y2, Z, DeltaZ, CurrY, ScanLines0, ScanLines) :-
	(   
	    % Check if the edge is horizontal. If it is, don't bother tracing
	    % along it.
	    Y2 = Y1
	->
	    ScanLines = ScanLines0
	;
	    (
		CurrY >= 0
	    ->
		(   
		    CurrY < Y2,
		    CurrY < Height
		->  
		    % Find the X for the current Y
		    X = ((CurrY - Y1) * (X2 - X1) div (Y2 - Y1)) + X1,
		    
		    array__lookup(ScanLines0, CurrY, Line),
		    array__set(ScanLines0, CurrY, [(X - Z) | Line], ScanLines1),

		    % Continue tracing, one pixel further in the Y direction
		    trace_edge(Width, Height, X1, Y1, X2, Y2, Z + DeltaZ, DeltaZ, CurrY + 1, ScanLines1, ScanLines)
		;   
		    ScanLines = ScanLines0
		)
	    ;
		trace_edge(Width, Height, X1, Y1, X2, Y2, Z + DeltaZ, DeltaZ, CurrY + 1, ScanLines0, ScanLines)
	    )
	).

% Render the scanlines into the image buffer.
draw_scanlines(Width, Height, ScanLines, Y, Colour, Zbuf_in, Zbuf_out, Image_in, Image_out) :-
	(   
	    Y < Height
	->
	    array__lookup(ScanLines, Y, ScanLine0),

	    % Sort the X intercepts at this scanline, to ensure that
	    % they can just be read left to right.
	    list__sort(ScanLine0, ScanLine),
	    
	    draw_one_scanline(ScanLine, Y, Width, Colour, Zbuf_in, Zbuf0, Image_in, Image0),
	    draw_scanlines(Width, Height, ScanLines, Y + 1, Colour, Zbuf0, Zbuf_out, Image0, Image_out)
	;
	    % No more scanlines to draw
	    Image_out = Image_in,
	    Zbuf_out = Zbuf_in
	).

% Draw a single scanline into the image. If there are (at least) two
% coordinates stored in the list, a horizontal line is drawn between these
% two points.
draw_one_scanline(ScanLine, Y, Width, Colour, Zbuf_in, Zbuf_out, Image_in, Image_out) :-
	(
	    % If the scanline is empty, there is nothing to do
	    ScanLine = [],
	    Image_out = Image_in,
	    Zbuf_out = Zbuf_in
	;
	    ScanLine = [(X1 - Z1) | Xs0],
	    (
		% This case should never occour - it is if there is only
		% one X intercept for a given scanline.
		% It is required however, to keep the compiler happy, since
		% it thinks the test with ScanLine = [(X1-Z1), (X2-Z2) | Rest]
		% could fail.
		Xs0 = [],
		Image_out = Image_in,
		Zbuf_out = Zbuf_in
	    ;
		% The second of the pair of intercepts
		Xs0 = [(X2 - Z2) | Xs],
		DeltaZ = (Z2 - Z1) / float(X2 - X1),

		% Draw a line between these two points
		draw_hline(X1, X2, Z1, DeltaZ, Y, Width, Colour, Zbuf_in, Zbuf0, Image_in, Image0),

		% Keep going with the rest of the intercepts on this scanline
		draw_one_scanline(Xs, Y, Width, Colour, Zbuf0, Zbuf_out, Image0, Image_out)
	    )
	).

% Draw a horizontal line between X1 and X2, at height Y
draw_hline(X1, X2, Z, DeltaZ, Y, Width, Colour, Zbuf_in, Zbuf_out, Image_in, Image_out) :-
	(   
	    X1 < X2
	->
	    (
		% Make sure that the pixel is actually on the screen
		check_x_on_screen(Width, X1)
	    ->
		(
		    % Check to see if there is nothing closer allready drawn
		    % at this pixel
		    poly__zbuffer__check(Width, X1, Y, Z, Zbuf_in)
		->
		    % Update the Zbuffer and draw the pixel into the image
		    % buffer
		    array__set(Image_in, (Y * Width) + X1, Colour, Image0),
		    poly__zbuffer__set(Width, X1, Y, Z, Zbuf_in, Zbuf0),

		    % Move on to the next pixel
		    draw_hline(X1 + 1, X2, Z + DeltaZ, DeltaZ, Y, Width, Colour, Zbuf0, Zbuf_out, Image0, Image_out)
		;
		    % there was something in the Zbuffer that was closer than
		    % this pixel, draw nothing and move along
		    draw_hline(X1 + 1, X2, Z + DeltaZ, DeltaZ, Y, Width, Colour, Zbuf_in, Zbuf_out, Image_in, Image_out)
		)
	    ;
		% This pixel was not inside the image, move along to the next
		draw_hline(X1 + 1, X2, Z + DeltaZ, DeltaZ, Y, Width, Colour, Zbuf_in, Zbuf_out, Image_in, Image_out)
	    )
	;
	    % Finished drawing the line
	    Image_in = Image_out,
	    Zbuf_out = Zbuf_in
	).


% Simple check for whether a given X is inside the image or not
check_x_on_screen(Width, X) :-
	X >= 0,
	X < Width.


% Draw the whole scene.
poly__draw_scene(Focal, Width, Height, Ambient, Lights, Scene, Zbuf_in, Zbuf_out, Image_in, Image_out) -->
	{ array__size(Scene, NumPolys) },
	{ do_draw_scene(Focal, Width, Height, NumPolys, 0, Ambient, Lights, Scene, Zbuf_in, Zbuf_out, Image_in, Image_out) },
	poly__image__draw_image(Width, Height, Image_out).


% Recursively draw each polyhedron into the image buffer.
do_draw_scene(Focal, Width, Height, NumPolys, CurrPoly, Ambient, Lights, Scene, Zbuf_in, Zbuf_out, Image_in, Image_out) :-
	(
	    CurrPoly < NumPolys
	->
	    array__lookup(Scene, CurrPoly, Poly3D),
	    poly__lighting__shade_poly(Lights, Ambient, u_p(Poly3D), PolyShaded),
	    poly__project(Focal, Width, Height, PolyShaded, Poly2D),
	    poly__draw(Width, Height, Ambient, Poly2D, Zbuf_in, Zbuf0, Image_in, Image0),
	    do_draw_scene(Focal, Width, Height, NumPolys, CurrPoly + 1, Ambient, Lights, Scene, Zbuf0, Zbuf_out, Image0, Image_out)
	;
	    Image_out = Image_in,
	    Zbuf_out = Zbuf_in
	).


% This is a nasty hack to ensure uniqueness of an array. This is required
% because nested unique modes are currently not supported by the Mercury
% compiler.
% Thanks to Tom Conway for this.
:- func u(array(T)) = array(T).
:- mode (u(in) = array_uo) is det.

:- pragma c_code(u(A::in) = (B::array_uo),
		 [will_not_call_mercury, thread_safe],
		 "B = A;"
		 ).

% Same as above, but for polyhedrons.
:- func u_p(polyhedron) = polyhedron.
:- mode (u_p(in) = polyhedron_uo) is det.

:- pragma c_code(u_p(A::in) = (B::polyhedron_uo),
		 [will_not_call_mercury, thread_safe],
		 "B = A;"
		 ).
