%-----------------------------------------------------------------------------%
%
% 433-380 Project, part B
% Robert Jeschofnik (rejj), 55572
%
% poly.lighting.m
%
% Written in Mercury, because C sucks.
%
% This module calculates all the shading calculations required to implement
% the effect of lights shinging on the polyhedrons.
%
%-----------------------------------------------------------------------------%

:- module poly__lighting.

:- interface.

:- pred poly__lighting__shade_face(array(vertex), array(light), float, colour, colour).
:- mode poly__lighting__shade_face(array_ui, array_ui, in, in, out) is det.

:- pred poly__lighting__shade_poly(array(light), float, polyhedron, polyhedron).
:- mode poly__lighting__shade_poly(array_ui, in, polyhedron_di, polyhedron_uo) is det.

:- pred clip(float, float).
:- mode clip(in, out) is det.

:- pred do_shade_face(vertex, vertex, array(light), int, int, float, float, float, float, float, float).
:- mode do_shade_face(in, in, array_ui, in, in, in, in, in, out, out, out) is det.

:- pred calc_intensity(vertex, vertex, light, float, float, float).
:- mode calc_intensity(in, in, in, out, out, out) is det.

:- func fix_normal(vertex) = vertex.
:- mode fix_normal(in) = out is det.

:- func dot_product(vertex, vertex) = float.
:- mode dot_product(in, in) = out is det.

:- func cross_product(vertex, vertex) = vertex.
:- mode cross_product(in, in) = out is det.

:- func unit_vector(vertex) = vertex.
:- mode unit_vector(in) = out is det.

%-----------------------------------------------------------------------------%

:- implementation.

:- import_module math.


% Clip the given to the range 0.0 - 1.0. This is used for both the dot product
% (to ensure it is not negative), and for the overall intensity of light
% striking a face.
clip(Intensity_in, Intensity) :-
	(
	    Intensity_in > 1.0
	->
	    Intensity = 1.0
	;
	    (
		Intensity_in < 0.0
	    ->
		Intensity = 0.0
	    ;
		Intensity = Intensity_in
	    )
	).

% Recursively shade every face in the given polyhedron.
poly__lighting__shade_poly(Lights, Ambient, Poly_in, Poly_out) :-
	Poly_in = polyhedron(Vs, Fs),
	(
	    % there are no more faces left
	    Fs = [],
	    Poly_out = Poly_in
	;
	    Fs = [face(Colour0, Vlist) | Faces],
	    list__length(Vlist, Length),
	    array__init(Length, vertex(0.0, 0.0, 0.0), Face_init),

	    % Generate the face and shade it
	    make_face(Vs, Vlist, 0, Face_init, Face),
	    shade_face(Face, Lights, Ambient, Colour0, Colour),

	    % "Vs0" is required in the returned polyhedron since if just
	    % "Vs" is used, the compiler thinks the unification of the
	    % returned polyhedron with (Vs, Faces0) can fail.
	    poly__lighting__shade_poly(Lights, Ambient, polyhedron(Vs, Faces), polyhedron(Vs0, Faces0)),
	    Poly_out = polyhedron(Vs0, [face(Colour, Vlist) | Faces0])
	).

% Shade one face of a polyhedron. Given the face, the lights, ambient value,
% and defined colour of the face, this calculates the `actual' colour.
% Note, this implements coloured lighting since it was so trivial to do. :)
poly__lighting__shade_face(Poly, Lights, Ambient, Colour0, Colour) :-
	array__size(Lights, NumLights),
	(
	    NumLights > 0
	->
	    % Get the first three verticies in the face
	    array__lookup(Poly, 0, vertex(X1, Y1, Z1)),
	    array__lookup(Poly, 1, vertex(X2, Y2, Z2)),
	    array__lookup(Poly, 2, vertex(X3, Y3, Z3)),

	    % Make the vectors representing the two edges they define
	    Vector1 = vertex(X2 - X1, Y2 - Y1, Z2 - Z1),
	    Vector2 = vertex(X3 - X2, Y3 - Y2, Z3 - Z2),
	    V1 = unit_vector(Vector1),
	    V2 = unit_vector(Vector2),

	    % Calculate the intensity of light on this face, given these two
	    % edges as vectors
	    do_shade_face(V1, V2, Lights, 0, NumLights, 0.0, 0.0, 0.0, IR0, IG0, IB0)
	;
	    % If there are no lights, then the intensity is (obviously) zero.
	    IR0 = 0.0,
	    IG0 = 0.0,
	    IB0 = 0.0
	),

	% add the ambient lighting to the total light hitting this face
	IR = IR0 + Ambient,
	IG = IG0 + Ambient,
	IB = IB0 + Ambient,

	% Clip the intensity of light hitting the face to the range 0 - 1
	clip(IR, RedInt),
	clip(IG, GreenInt),
	clip(IB, BlueInt),

	% Multiply the face colours by the intensity of the light
	Colour0 = colour(R0, G0, B0),
	R = R0 * RedInt,
	G = G0 * GreenInt,
	B = B0 * BlueInt,
	Colour = colour(R, G, B).

% Given two vectors and the array of lights, recursively calculate the effect
% of the lights on the plane defined by the vectors.
do_shade_face(V1, V2, Lights, Elem, NumLights, IR_in, IG_in, IB_in, IR, IG, IB) :-
	(
	    Elem < NumLights
	->
	    % Look up the current light and calculate its effect
	    array__lookup(Lights, Elem, Light),
	    calc_intensity(V1, V2, Light, IR0, IG0, IB0),

	    % Add it to the total amount of light hitting the face
	    IR1 = IR0 + IR_in,
	    IG1 = IG0 + IG_in,
	    IB1 = IB0 + IB_in,

	    % move on to the next light
	    do_shade_face(V1, V2, Lights, Elem +1, NumLights, IR1, IG1, IB1, IR, IG, IB)
	;
	    % There are no more lights left
	    IR = IR_in,
	    IG = IG_in,
	    IB = IB_in
	).


% Calculate the intensity of the given light on the face defined by the given
% vectors.
calc_intensity(V1, V2, Light, IR, IG, IB) :-
	Light = light(I, LightV, colour(R, G, B)),
	Normal = cross_product(V1, V2),
	DotProduct0 = dot_product(unit_vector(fix_normal(Normal)), unit_vector(LightV)),

	% Make sure the dot product is between 0.0 and 1.0
	clip(DotProduct0, DotProduct),
	IR = I * R * DotProduct,
	IG = I * G * DotProduct,
	IB = I * B * DotProduct.


% If the Z component of the calculated normal is more than 90 degrees away
% from the viewer, then al the components need to be flipped so that the
% normal points (more or less) at the viewer. This means that a face does
% not have a front or back, thus backface removal is impossible.
fix_normal(Normal) = Fixed :-
	Normal = vertex(X, Y, Z),
	(
	    Z < 0.0
	->
	    Fixed = vertex(-X, -Y, -Z)
	;
	    Fixed = vertex(X, Y, Z)
	).


% Find the dot product of two unit vectors.
dot_product(vertex(X1, Y1, Z1), vertex(X2, Y2, Z2)) = Product :-
	Product = X1*X2 + Y1*Y2 + Z1*Z2.


% Find the cross product of two unit vectors.
cross_product(vertex(X1, Y1, Z1), vertex(X2, Y2, Z2)) = vertex(X, Y, Z) :-
	X = Y1*Z2 - Z1*Y2,
	Y = Z1*X2 - X1*Z2,
	Z = X1*Y2 - Y1*X2.


% Find the unit vector in the same direction as the given non-zero vector.
unit_vector(vertex(X1, Y1, Z1)) = vertex(X, Y, Z) :-
	Magnitude = math__sqrt(X1*X1 + Y1*Y1 + Z1*Z1),
	X = X1 / Magnitude,
	Y = Y1 / Magnitude,
	Z = Z1 / Magnitude.
