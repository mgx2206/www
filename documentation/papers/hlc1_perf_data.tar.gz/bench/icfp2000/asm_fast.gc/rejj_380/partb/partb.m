%-----------------------------------------------------------------------------%
%
% 433-380 Project, part B.
% Robert Jeschofnik (rejj), 55572
%
% partb.m
%
% Written in Mercury, because C sucks.
%
% Reads in a scene description, and all the objects described therein.
% The objects are then rendered to an image buffer, which is then output
% to stdout in PPM format.
%
% The method of choice for rendering polygons in this program is by forming
% horizontal scanlines for each face, then drawing each of these in turn.
% This program implements lighting in the form of (white) ambient light, and
% (optionally) coloured lights.
%
%-----------------------------------------------------------------------------%

:- module partb.

:- interface.

:- import_module io.

:- pred main(io__state::di, io__state::uo) is det.

%-----------------------------------------------------------------------------%

:- implementation.

:- import_module char, int, float, string, list, array, require.
:- import_module poly, poly__image, poly__zbuffer, handle_input.

:- pred perform_rendering(float, int, int, io__state, io__state).
:- mode perform_rendering(in, in, in, di, uo) is det.

:- func default_ambient = float.
:- mode default_ambient = out is det.

%-----------------------------------------------------------------------------%

main -->
	io__command_line_arguments(Args),
	(
	    {sanity_check_args(Args, Focal, Width, Height)}
	->  
	    perform_rendering(Focal, Width, Height)
	;
	    display_usage
	).

% Read in the scene description, and then draw the scene.
perform_rendering(Focal, Width, Height) -->
	{ array__make_empty_array(Scene0) },
	{ array__make_empty_array(Lights0) },
	read_scene_desc(Scene0, Scene, default_ambient, Ambient, Lights0, Lights),
	{ poly__image__init(Width, Height, Image0) },
	{ poly__zbuffer__init(Width, Height, Zbuf0) },
	poly__draw_scene(Focal, Width, Height, Ambient, Lights, Scene, Zbuf0, _Zbuf, Image0, _Image).


% the default is to have no ambient light
default_ambient = 0.0.
