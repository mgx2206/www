%-----------------------------------------------------------------------------%
%
% 433-380 Project, part B
% Robert Jeschofnik (rejj), 55572
%
% handle_input.m
%
% Written in Mercury, because C sucks.
%
% This module handles all the input - it grabs the command line args, and
% parses the scene description (and described .OFF) file(s), returning the
% scene.
% Also read in are descriptions of the lighting in the scene (both ambient
% and light sources).
% Any line starting with a hash mark (#) are comments, and are ignored.
%
%-----------------------------------------------------------------------------%

:- module handle_input.

:- interface.

:- import_module io, string, list, float, int, array.
:- import_module poly.

:- pred sanity_check_args(list(string), float, int, int).
:- mode sanity_check_args(in, out, out, out) is semidet.

:- pred display_usage(io__state, io__state).
:- mode display_usage(di, uo) is det.

:- pred read_scene_desc(array(polyhedron), array(polyhedron), float, float, array(light), array(light), io__state, io__state).
:- mode read_scene_desc(array_di, array_uo, in, out, array_di, array_uo, di, uo) is det.

%-----------------------------------------------------------------------------%

:- implementation.

:- import_module char, require, array.
:- import_module poly, poly__transform, word.

:- pred check_io_result(io__result(list(char)), pred(T), pred(list(char),T), T).
:- mode check_io_result(in, pred(out) is det, pred(in, out) is det, out) is det.

:- pred display_error_handler(T).
:- mode display_error_handler(out) is det.

:- pred display_error is erroneous.

:- pred convert_to_float(list(char), float).
:- mode convert_to_float(in, out) is det.

:- pred convert_to_int(list(char), int).
:- mode convert_to_int(in, out) is det.

:- pred convert_to_string(list(char), string).
:- mode convert_to_string(in, out) is det.

:- pred do_nothing_handler(list(char), int).
:- mode do_nothing_handler(in, out) is det.

:- pred read_off_line(string, transform, io__state, io__state).
:- mode read_off_line(out, out, di, uo) is det.

:- pred read_off_file(string, polyhedron, io__state, io__state).
:- mode read_off_file(in, polyhedron_uo, di, uo) is det.

:- pred read_verticies(io__input_stream, int, int, array(vertex), array(vertex), io__state, io__state).
:- mode read_verticies(in, in, in, array_di, array_uo, di, uo) is det.

:- pred read_faces(io__input_stream, int, int, list(face), list(face), io__state, io__state).
:- mode read_faces(in, in, in, in, out, di, uo) is det.

:- pred read_one_face(io__input_stream, int, int, list(int), list(int),io__state, io__state).
:- mode read_one_face(in, in, in, in, out, di, uo) is det.

%-----------------------------------------------------------------------------%

% Simplistic checking of the command line arguments. Succeeds if there were
% three parameters on the command line, and they were valid representations of
% a float and two ints respectively.
sanity_check_args(Args, Focal, Width, Height) :-
	Args = [S_Focal, S_Width, S_Height],
	string__to_float(S_Focal, Focal),
	string__to_int(S_Width, Width),
	string__to_int(S_Height, Height).

% Displays the usage information for the program. Called if the program was
% invoked with incorrect arguments.
display_usage -->
	io__stderr_stream(Stderr),
	io__progname("parta", Name),
	io__print(Stderr, "Usage: "),
	io__print(Stderr, Name),
	io__print(Stderr, " focal-length width height"),
	io__nl(Stderr).

% This is the predicate to read the scene description file from stdin.
% Currently, only lines describing OFF files are valid
read_scene_desc(Scene_in, Scene_out, Amb_in, Amb_out, Lights_in, Lights_out) -->
	io__read_word(Result),
	(
	    { Result = error(Error) },
	    { io__error_message(Error, Msg) },
	    { error(Msg) }
	;
	    { Result = eof },
	    { Scene_out = Scene_in },
	    { Amb_out = Amb_in },
	    { Lights_out = Lights_in }
	;
	    { Result = ok(Word) },
	    (
		% If the first word is "off", then this is an `off-line'
		{ Word = ['o','f','f'] }
	    ->	
		read_off_line(Name, Trans),
		read_off_file(Name, Poly0),

		% Perform the 3D transform specified on this line
		{ poly__transform__transform(Poly0, Trans, Poly) },
		{ array__size(Scene_in, Size) },
		{ array__resize(Scene_in, Size + 1, Poly, Scene0) },
		{ Amb0 = Amb_in },
		{ Lights0 = Lights_in }
	    ;
		(
		    % If the first word is "ambient", then this is an
		    % `ambient' line
		    { Word = ['a', 'm', 'b', 'i', 'e', 'n', 't'] }
		->
		    read_ambient_line(Amb0),
		    { Scene0 = Scene_in },
		    { Lights0 = Lights_in }
		;
		    (
			% If the first word is "light", then this is a `light'
			% line
			{ Word = ['l', 'i', 'g', 'h', 't'] }
		    ->
			read_light_line(Light),
			{ array__size(Lights_in, Size) },
			{ array__resize(Lights_in, Size + 1, Light, Lights0) },
			{ Scene0 = Scene_in },
			{ Amb0 = Amb_in }
		    ;
			(
			    % Any line starting with a hash mark is a comment,
			    % and is ignored
			    { Word = ['#' | _] }
			->
			    io__read_line(_),
			    { Scene0 = Scene_in },
			    { Amb0 = Amb_in },
			    { Lights0 = Lights_in}
			;
			    { error("Invalid line in scene description") }
			)
		    )
		)
	    ),
	    % continue on, read the next line
	    read_scene_desc(Scene0, Scene_out, Amb0, Amb_out, Lights0, Lights_out)
	).

% Read in one "off" line. Reads in the filename and the transformations to apply
% to the described polyhedron.
read_off_line(Name, Trans) -->
	% Read the file name
	io__read_word(R_Name),
	{ check_io_result(R_Name, display_error_handler, convert_to_string, Name) },

	% Read the six transformations
	io__read_word(R_Sx),
	{ check_io_result(R_Sx, display_error_handler, convert_to_float, Sx) },

	io__read_word(R_Sy),
	{ check_io_result(R_Sy, display_error_handler, convert_to_float, Sy) },
	
	io__read_word(R_Sz),
	{ check_io_result(R_Sz, display_error_handler, convert_to_float, Sz) },
	
	io__read_word(R_Rx),
	{ check_io_result(R_Rx, display_error_handler, convert_to_float, Rx) },
	
	io__read_word(R_Ry),
	{ check_io_result(R_Ry, display_error_handler, convert_to_float, Ry) },
	
	io__read_word(R_Rz),
	{ check_io_result(R_Rz, display_error_handler, convert_to_float, Rz) },
	
	io__read_word(R_Tx),
	{ check_io_result(R_Tx, display_error_handler, convert_to_float, Tx) },
	
	io__read_word(R_Ty),
	{ check_io_result(R_Ty, display_error_handler, convert_to_float, Ty) },
	
	io__read_word(R_Tz),
	{ check_io_result(R_Tz, display_error_handler, convert_to_float, Tz) },

	% Group them together into a transform type
	{ S = scale(Sx, Sy, Sz) },
	{ R = rotate(Rx, Ry, Rz) },
	{ T = translate(Tx, Ty, Tz) },
	{ Trans = transform(S, R, T) }.

:- pred read_ambient_line(float, io__state, io__state).
:- mode read_ambient_line(out, di, uo) is det.

% Read in the ambient light value.
read_ambient_line(Ambient) -->
	io__read_word(R_Amb),
	{ check_io_result(R_Amb, display_error_handler, convert_to_float, Ambient0) },
	{ (
	      Ambient0 > 1.0
	  ->  
	      Ambient = 1.0
	  ;   
	      Ambient = Ambient0
	  ) }.

:- pred read_light_line(light, io__state, io__state).
:- mode read_light_line(out, di, uo) is det.

% Reads in a light from the scene description file. The first field is the
% lights intensity, the next three are its position.
read_light_line(Light) -->
	io__read_word(R_I),
	{ check_io_result(R_I, display_error_handler, convert_to_float, I) },
	io__read_word(R_X),
	io__read_word(R_Y),
	io__read_word(R_Z),
	{ check_io_result(R_X, display_error_handler, convert_to_float, X) },
	{ check_io_result(R_Y, display_error_handler, convert_to_float, Y) },
	{ check_io_result(R_Z, display_error_handler, convert_to_float, Z) },
	io__read_line_as_string(ColRes),
	{ get_colour(ColRes, Colour) },
	{ Light = light(I, vertex(X, Y, Z), Colour) }.
		      
% This higher order predicate takes an io__result and predicates to handle the
% eof and ok cases, and performs the correct action. This is to clean up all
% the io error checking throughout this module - it removes the need to have
% this code duplicated wherever a word is read in.
check_io_result(Res, EOF_Handler, OK_Handler, Output) :-
	(
	    Res = error(Error),
	    io__error_message(Error, Msg),
	    error(Msg)
	;
	    Res = eof,
	    EOF_Handler(Output)
	;
	    Res = ok(OK_Word),
	    OK_Handler(OK_Word, Output)
	).


% This predicate has an (unused) output so that it can be used as an EOF_Handler
% in check_io_result/4
display_error_handler(_) :-
	display_error.

% Display an error message due to invalid input, and terminate execution
display_error :-
	error("Invalid line in scene description").

% Convert a list of characters to a float
convert_to_float(Word, F) :-
	string__from_char_list(Word, S_F),
	(   
	    string__to_float(S_F, F0)
	->  
	    F = F0
	;
	    display_error
	).

% Convert a list of characters to a string
% This pred is needed since the library function string__from_char_list/2 has
% multiple modes, and a predicate can only be used as a higher order constant
% if it has exactly one mode.
convert_to_string(Word, S) :-
	string__from_char_list(Word, S).

% Convert a list of characters to an int
convert_to_int(Word, I) :-
	string__from_char_list(Word, S_I),
	(
	    string__to_int(S_I, I0)
	->
	    I = I0
	;
	    display_error
	).

% This is the handler for check_io_result/4 that does nothing.
do_nothing_handler(_, NothingOut) :-
	NothingOut = 0.

% Read in an OFF file, saving the described object in Poly.
% First calls the perl script "stripcom.pl" to remove any comments from the
% file, then parses as normal.
% Note, the optional colour information is ignored if present
read_off_file(Name, Poly) -->
	{ string__append("stripcom.pl < ", Name, Command0) },
	% I think it is fairly safe to assume that there will not be a file
	% called "tempout.tempout" in the current directory
	{ string__append(Command0, " > tempout.tempout", Command) },
	io__call_system(Command, _),
	io__open_input("tempout.tempout", SeeRes),
	(
	    { SeeRes = error(Error) },
	    { io__error_message(Error, Message) },
	    { error(Message) }
	;
	    { SeeRes = ok(File) },
	    
	    % Read in the "OFF" magic header from the file and ignore it
	    io__read_word(File, OFFRes),
	    { check_io_result(OFFRes, display_error_handler, do_nothing_handler, _) },
	    % Read the number of verticies
	    io__read_word(File, NVRes),
	    { check_io_result(NVRes, display_error_handler, convert_to_int, NV) },
	    % Read the number of faces
	    io__read_word(File, NFRes),
	    { check_io_result(NFRes, display_error_handler, convert_to_int, NF) },
	    % Read the number of edges, and ignore it
	    io__read_word(File, NERes),
	    { check_io_result(NERes, display_error_handler, do_nothing_handler, _) },
	    { array__init(NV, vertex(0.0, 0.0, 0.0), Verts_init) },
	    read_verticies(File, NV, 0, Verts_init, Verts),
	    read_faces(File, NF, 0, [], Faces),
	    { Poly = polyhedron(Verts, Faces) },

	    % Remove the temporary file created
	    io__call_system("rm -f tempout.tempout", _)
	).

% Read in the verticies from the OFF file. Stores them in an array in the order
% they are read in.
read_verticies(File, NV, CurrV, Verts_in, Verts_out) -->
	(
	    { CurrV < NV }
	->
	    io__read_word(File, XRes),
	    io__read_word(File, YRes),
	    io__read_word(File, ZRes),
	    { check_io_result(XRes, display_error_handler, convert_to_float, X) },
	    { check_io_result(YRes, display_error_handler, convert_to_float, Y) },
	    { check_io_result(ZRes, display_error_handler, convert_to_float, Z) },
	    { array__set(Verts_in, CurrV, vertex(X, Y, Z), Verts0) },
	    read_verticies(File, NV, CurrV + 1, Verts0, Verts_out)
	;
	    { Verts_out = Verts_in }
	).

% Read in the faces from the OFF file. They are stored in a list.
% Any colour information in this section of the file is ignored.
read_faces(File, NF, CurrF, Faces_in, Faces_out) -->
	(
	    { CurrF < NF }
	->
	    io__read_word(File, NumVRes),
	    { check_io_result(NumVRes, display_error_handler, convert_to_int, NumV) },
	    % Read in one face from the file
	    read_one_face(File, NumV, 0, [], Vlist),
	    
	    % Read the rest of the line and extract the colour info from it.
	    io__read_line_as_string(File, ColRes),
	    { get_colour(ColRes, Colour) },
	    
	    { Faces0 = [face(Colour, Vlist) | Faces_in] },
	    read_faces(File, NF, CurrF + 1, Faces0, Faces_out)
	;
	    { Faces_out = Faces_in }
	).

% Read in one face from the file. The faces are read number by number, and
% stored in a list.
read_one_face(File, NumV, CurrV, Face_in, Face_out) -->
	(
	    { CurrV < NumV }
	->
	    io__read_word(File, VRes),
	    { check_io_result(VRes, display_error_handler, convert_to_int, V) },
	    { list__append(Face_in, [V], Face0) },
	    read_one_face(File, NumV, CurrV + 1, Face0, Face_out)
	;
	    { Face_out = Face_in }
	).

:- pred get_colour(io__result(string), colour).
:- mode get_colour(in, out) is det.

% Extract the (optional) colour information from a line describing a face.
get_colour(ColRes, Colour) :-
	(
	    ColRes = error(Error),
	    io__error_message(Error, Msg),
	    error(Msg)
	;
	    % There was no more input, this was probably the last face in the
	    % file, default to colour white.
	    ColRes = eof,
	    Colour = colour(1.0, 1.0, 1.0)
	;
	    ColRes = ok(ColString),
	    read_colour_string(ColString, Colour)
	).

:- pred read_colour_string(string, colour).
:- mode read_colour_string(in, out) is det.

% Read the colours out of the string. If there were either three ints or floats,
% it gives back the colour that they detail, otherwise it defaults to white.
read_colour_string(ColString, Colour) :-
	(   
	    % Check if there are three ints
	    read_three_vals(colour_from_int, ColString, Col0)
	->
	    Colour = Col0
	;
	    (
		% Else check if there are three floats
		read_three_vals(colour_from_float, ColString, Col0)
	    ->
		Colour = Col0
	    ;
		% If neither of the above cases, use the default colour (White)
		Colour = colour(1.0, 1.0, 1.0)
	    )
	).

:- pred colour_from_int(string, float).
:- mode colour_from_int(in, out) is semidet.

% Convert a list of chars representing an int (between 0 and 255) to a float
% between 0 and 1.
% Fails if the list was not a valid representation of an int
colour_from_int(Word, C) :-
	string__to_int(Word, I),
	C = float(I) / 255.0.

:- pred colour_from_float(string, float).
:- mode colour_from_float(in, out) is semidet.

% Converts a list of chars to a float if it is a valid representation.
% Fails otherwise
colour_from_float(Word, C) :-
	string__to_float(Word, C).

:- pred read_three_vals(pred(string, float), string, colour).
:- mode read_three_vals(pred(in, out) is semidet, in, out) is semidet.

% Read in three numbers from the given string, using the provided conversion
% predicate to convert them to integers.
% Succeeds if three numbers could be read, and returns a colour with the three
% numbers as the R, G, B components, or fails if three numbers could not be
% read.
read_three_vals(Convert, ColString, Colour) :-
	% Read the three white spaced delimited numbers
	read_word_from_string(ColString, ColRed, ColString0),
	read_word_from_string(ColString0, ColGreen, ColString1),
	read_word_from_string(ColString1, ColBlue, _ColString2),

	% Unpack the io__results returned from read_word_from_string/3
	ColRed = ok(R0),
	ColGreen = ok(G0),
	ColBlue = ok(B0),

	string__from_char_list(R0, R1),
	string__from_char_list(G0, G1),
	string__from_char_list(B0, B1),

	% Convert them to integers using the given conversion predicate.
	Convert(R1, R),
	Convert(B1, B),
	Convert(G1, G),

	Colour = colour(R, G, B).
