%-----------------------------------------------------------------------------%
%
% 433-380 Project, part B.
% Robert Jeschofnik (rejj), 55572
%
% f_matrix.m
%
% Written in Mercury, because C sucks.
%
% Implements a matrix of floating point numbers.
% Matricies multiply on the left.
%
%-----------------------------------------------------------------------------%

:- module f_matrix.

:- interface.

:- import_module array.

:- inst uniq_f_matrix == unique(f_matrix(ground, ground, uniq_array)).

:- mode f_matrix_di == di(uniq_f_matrix).
:- mode f_matrix_uo == out(uniq_f_matrix).
:- mode f_matrix_ui == in(uniq_f_matrix).

:- type f_matrix.

:- pred f_matrix__init(int, int, f_matrix).
:- mode f_matrix__init(in, in, f_matrix_uo) is det.

:- pred f_matrix__set(int, int, float, f_matrix, f_matrix).
:- mode f_matrix__set(in, in, in, f_matrix_di, f_matrix_uo) is det.

:- pred f_matrix__lookup(int, int, f_matrix, float).
:- mode f_matrix__lookup(in, in, f_matrix_ui, out) is det.

:- pred f_matrix__mul(f_matrix, f_matrix, f_matrix).
:- mode f_matrix__mul(in, in, f_matrix_uo) is det.

%-----------------------------------------------------------------------------%

:- implementation.

:- import_module array, float, int.

:- type f_matrix --->
	f_matrix(
		 int,		% M
		 int,		% N
		 array(float)	% the elements of the matrix
		).

%-----------------------------------------------------------------------------%

:- pred do_mul(array(float), array(float), int, int, int, int, int, f_matrix, f_matrix).
:- mode do_mul(in, in, in, in, in, in, in, f_matrix_di, f_matrix_uo) is det.

:- pred mul_row_by_col(array(float), array(float), int, int, int, int, float).
:- mode mul_row_by_col(in, in, in, in, in, in, out) is det.


% Create a new f_matrix of size MxN, with all elements initilised to 0.0
f_matrix__init(M, N, Matrix) :-
	array__init(M * N, 0.0, Array),
	Matrix = f_matrix(M, N, Array).

% Set element (I, J) in the f_matrix to Val.
% If (I, J) is not a valid index to the matrix, the behaviour is undefined
f_matrix__set(I, J, Val, M_in, M_out) :-
	M_in = f_matrix(M, N, Array0),
	Location = I * N + J,
	array__set(Array0, Location, Val, Array),
	M_out = f_matrix(M, N, Array).

% Lookup element (I, J) in the f_matrix.
% If (I, J) is not a valid index to the matrix, the behaviour is undefined
f_matrix__lookup(I, J, f_matrix(_M, N, Array), Elem) :-
	array__lookup(Array, (I * N) + J, Elem).

% Perform matrix multiplication on the two specified matricies.
% If N1 \= M2, the behaviour is undefined.
f_matrix__mul(f_matrix(M1, N1, Array1),f_matrix(_M2, N2, Array2), M) :-
	% for completeness, should put a check here..
	% if N1 \= M2, then error
	f_matrix__init(M1, N2, M_init),
	do_mul(Array1, Array2, 0, 0, M1, N2, N1, M_init, M).

% Recursively multiply each row in Array1 by each column in Array2
do_mul(Array1, Array2, Row, Col, NumRows, NumCols, Size, M_in, M_out) :-
	(
	    Row < NumRows
	->
	    (	
		Col < NumCols
	    ->	
		mul_row_by_col(Array1, Array2, Row, Col, Size, 0, Sum),
		f_matrix__set(Row, Col, Sum, M_in, M0),
		do_mul(Array1, Array2, Row, Col + 1, NumRows, NumCols, Size, M0, M_out)
	    ;	
		do_mul(Array1, Array2, Row + 1, 0, NumRows, NumCols, Size, M_in, M_out)
	    )
	;
	    M_out = M_in
	).

% Recursively multiply each element in Row of Array1 by each element in Col of
% Array2, summing the results.
mul_row_by_col(Array1, Array2, Row, Col, Size, Elem, Sum) :-
	(
	    Elem < Size
	->
	    mul_row_by_col(Array1, Array2, Row, Col, Size, Elem + 1, Sum0),
	    array__lookup(Array1, Row * Size + Elem, I),
	    array__lookup(Array2, Elem * Size + Col, J),
	    S = I * J,
	    Sum = S + Sum0
	;
	    Sum = 0.0
	).
