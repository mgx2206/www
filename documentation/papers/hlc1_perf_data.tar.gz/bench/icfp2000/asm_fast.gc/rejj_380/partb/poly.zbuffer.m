%-----------------------------------------------------------------------------%
%
% 433-380 Project, Part B
% Robert Jeschofnik (rejj), 55572
%
% poly__zbuffer.m
%
% Written in Mercury, because C sucks.
%
% This module details the workings of the Z buffer, used to ensure that the
% pixels drawn in the image are the ones that you can actually "see", ie, those
% which have Z values closest to the camera.
%
%-----------------------------------------------------------------------------%

:- module poly__zbuffer.

:- interface.

:- type zbuffer == array(float).

%-----------------------------------------------------------------------------%

:- pred poly__zbuffer__init(int, int, zbuffer).
:- mode poly__zbuffer__init(in, in, array_uo) is det.

:- pred poly__zbuffer__check(int, int, int, float, zbuffer).
:- mode poly__zbuffer__check(in, in, in, in, array_ui) is semidet.

:- pred poly__zbuffer__set(int, int, int, float, zbuffer, zbuffer).
:- mode poly__zbuffer__set(in, in, in, in, array_di, array_uo) is det.

%-----------------------------------------------------------------------------%

:- implementation.


% Create the Zbuffer and initilise it to `infinite' depth. This is represented
% as the minimum value of an integer on the machine the program is being run
% on (Since -ve Z is into the screen).
poly__zbuffer__init(Width, Height, Zbuffer) :-
	array__init(Width * Height, inf_depth, Zbuffer).


% Check the given pixel in the Zbuffer. Succeeds if the given depth is greater
% than (closer to the viewer) the existing entry, or fails if it is smaller
% (further away).
poly__zbuffer__check(Width, X, Y, Z, Zbuffer) :-
	array__lookup(Zbuffer, (Y * Width) + X, ZbufZ),
	Z >= ZbufZ.


% Set the element (X, Y) in the Zbuffer to new value Z.
poly__zbuffer__set(Width, X, Y, Z, Zbuf_in, Zbuf_out) :-
	array__set(Zbuf_in, (Y * Width) + X, Z, Zbuf_out).


:- func inf_depth = float.
:- mode inf_depth = out.

% Representation of infinite depth.
inf_depth = -999999999.0.