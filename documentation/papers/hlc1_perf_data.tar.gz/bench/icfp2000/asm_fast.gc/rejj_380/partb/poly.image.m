%-----------------------------------------------------------------------------$
%
% 433-380 Project, part B
% Robert Jeschofnik (rejj), 55572
%
% poly.image.m
%
% Written in Mercury, because C sucks.
%
% This submodule handles the task of drawing the image file itself.
%
%-----------------------------------------------------------------------------%

:- module image.

:- interface.

% Type to represent the image that is being drawn. It is a two dimensional
% array of integers, representing the X and Y locations for every pixel
% (and their value)
:- type image == array(colour).

%-----------------------------------------------------------------------------%

:- pred poly__image__init(int, int, image).
:- mode poly__image__init(in, in, array_uo) is det.

:- pred poly__image__draw_image(int, int, image, io__state, io__state).
:- mode poly__image__draw_image(in, in, array_ui, di, uo) is det.

%-----------------------------------------------------------------------------%

:- implementation.

:- pred do_image_draw(int, int, int, int, image, io__state, io__state).
:- mode do_image_draw(in, in, in, in, in, di, uo) is det.


% Create the empty image buffer
poly__image__init(Width, Height, Image) :-
	array__init(Width * Height, colour(0.0, 0.0, 0.0), Image).

% Print out the header information for the PPM format, then output the image
% buffer.
poly__image__draw_image(Width, Height, Image) -->
	io__print("P6"),
	io__print(" "),
	io__write(Width),
	io__print(" "),
	io__write(Height),
	io__print(" "),
	io__write(255),
	io__nl,
	do_image_draw(Width, Height, 0, 0, Image).


% Output the image buffer in binary format. There are three bytes for every
% pixel (Red, Green, Blue). These bytes are just streamed to stdout.
do_image_draw(Width, Height, X, Y, Image) -->
	(   
	    { Y < Height }
	->
	    (
		{ X < Width }
	    ->
		{ array__lookup(Image, (Y * Width) + X, colour(R0, G0, B0)) },

		{ R = round_to_int(R0 * 255.0) },
		{ G = round_to_int(G0 * 255.0) },
		{ B = round_to_int(B0 * 255.0) },
		
		io__write_byte(R),
		io__write_byte(G),
		io__write_byte(B),
		do_image_draw(Width, Height, X + 1, Y, Image)
	    ;
		do_image_draw(Width, Height, 0, Y + 1, Image)
	    )
	;
	    % The empty list is used to represent an empty clause in a DCG
	    []
	).
