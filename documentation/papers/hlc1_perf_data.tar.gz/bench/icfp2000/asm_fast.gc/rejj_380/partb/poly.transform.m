%-----------------------------------------------------------------------------$
%
% 433-380 Project, part B
% Robert Jeschofnik (rejj), 55572
%
% poly.transform.m
%
% Written in Mercury, because C sucks.
%
% This module details the application of 3D transforms on polyhedra.
% Scaling, Rotation, and Translation are performed via matrix multiplication.
% To achieve this, the vertecies are converted to `homogeneous' coordinates.
% Once transformed, they are returned as cartesian points in 3D space.
%
%-----------------------------------------------------------------------------%

:- module poly__transform.

:- interface.

:- pred poly__transform__transform(polyhedron, transform, polyhedron).
:- mode poly__transform__transform(polyhedron_di, in, polyhedron_uo) is det.

%-----------------------------------------------------------------------------%

:- implementation.

:- import_module math, f_matrix.

:- pred do_transform(f_matrix, int, int, array(vertex), array(vertex)).
:- mode do_transform(in, in, in, array_di, array_uo) is det.

:- pred vert_to_homo(vertex, float, f_matrix).
:- mode vert_to_homo(in, in, f_matrix_uo) is det.

:- pred make_scale_matrix(scale, f_matrix).
:- mode make_scale_matrix(in, f_matrix_uo) is det.

:- pred make_translate_matrix(translate, f_matrix).
:- mode make_translate_matrix(in, f_matrix_uo) is det.

:- pred make_rotate_matrix(rotate, f_matrix).
:- mode make_rotate_matrix(in, f_matrix_uo) is det.

:- pred make_rotate_x_matrix(float, f_matrix).
:- mode make_rotate_x_matrix(in, f_matrix_uo) is det.

:- pred make_rotate_y_matrix(float, f_matrix).
:- mode make_rotate_y_matrix(in, f_matrix_uo) is det.

:- pred make_rotate_z_matrix(float, f_matrix).
:- mode make_rotate_z_matrix(in, f_matrix_uo) is det.

:- func deg_to_rad(float) = float.
:- mode deg_to_rad(in) = out is det.

:- pred make_transform_matrix(transform, f_matrix).
:- mode make_transform_matrix(in, f_matrix_uo) is det.

%-----------------------------------------------------------------------------%

% Perform the given 3D transformation on the given polyhedron
poly__transform__transform(polyhedron(Vs_in, Fs), Transform, polyhedron(Vs_out, Fs)) :-
	make_transform_matrix(Transform, TMatrix),
	array__size(Vs_in, NV),
	do_transform(TMatrix, NV, 0, Vs_in, Vs_out).


% Recursively transform each vertex in the polyhedron
do_transform(TMatrix, NV, Elem, Vs_in, Vs_out) :-
	(
	    Elem < NV
	->
	    % Convert the vertex from cartesian to homogeneous coordinates
	    array__lookup(Vs_in, Elem, Vertex),
	    vert_to_homo(Vertex, 1.0, VMatrix),

	    % Perform the transform
	    f_matrix__mul(VMatrix, TMatrix, NewVMatrix),

	    % Extract the cartesian coordinates back from the homogeneous
	    % matrix.
	    % Note, W=1, so there is no need to divide by W
	    f_matrix__lookup(0, 0, NewVMatrix, X),
	    f_matrix__lookup(0, 1, NewVMatrix, Y),
	    f_matrix__lookup(0, 2, NewVMatrix, Z),

	    % update this vertex and move on to the next
	    array__set(Vs_in, Elem, vertex(X, Y, Z), Vs0),
	    do_transform(TMatrix, NV, Elem + 1, Vs0, Vs_out)
	;
	    Vs_out = Vs_in
	).
	

% Convert a cartesian point to homogeneous coordinates.
vert_to_homo(vertex(X, Y, Z), W, VMatrix) :-
	f_matrix__init(1, 4, VM_init),
	call((pred(f_matrix_di, f_matrix_uo) is det -->
	      f_matrix__set(0, 0, X/W),
	      f_matrix__set(0, 1, Y/W),
	      f_matrix__set(0, 2, Z/W),
	      f_matrix__set(0, 3, W)
	     ), VM_init, VMatrix).

% Build the matrix representing the given scaling factors.
make_scale_matrix(scale(Sx, Sy, Sz), SMatrix) :-
	f_matrix__init(4, 4, SM_init),
	call((pred(f_matrix_di, f_matrix_uo) is det -->
	      f_matrix__set(0, 0, Sx),
	      f_matrix__set(1, 1, Sy),
	      f_matrix__set(2, 2, Sz),
	      f_matrix__set(3, 3, 1.0)
	     ), SM_init, SMatrix).

% Build the matrix representing the given translation.
make_translate_matrix(translate(Tx, Ty, Tz), TMatrix) :-
	f_matrix__init(4, 4, TM_init),
	call((pred(f_matrix_di, f_matrix_uo) is det -->
	      f_matrix__set(0, 0, 1.0),
	      f_matrix__set(1, 1, 1.0),
	      f_matrix__set(2, 2, 1.0),
	      f_matrix__set(3, 0, Tx),
	      f_matrix__set(3, 1, Ty),
	      f_matrix__set(3, 2, Tz),
	      f_matrix__set(3, 3, 1.0)
	     ), TM_init, TMatrix).

% Build the matrix representing the given rotation.
make_rotate_matrix(rotate(Rx, Ry, Rz), RMatrix) :-
	make_rotate_x_matrix(Rx, RMx),
	make_rotate_y_matrix(Ry, RMy),
	make_rotate_z_matrix(Rz, RMz),
	f_matrix__mul(RMx, RMy, RMxy),
	f_matrix__mul(RMxy, RMz, RMatrix).

% The matrix representing the rotation about the X axis
make_rotate_x_matrix(Rx_D, RxMatrix) :-
	Rx = deg_to_rad(Rx_D),
	Cosx = cos(Rx),
	Sinx = sin(Rx),
	f_matrix__init(4, 4, RxM_init),
	call((pred(f_matrix_di, f_matrix_uo) is det -->
	      f_matrix__set(0, 0, 1.0),
	      f_matrix__set(1, 1, Cosx),
	      f_matrix__set(1, 2, Sinx),
	      f_matrix__set(2, 1, -Sinx),
	      f_matrix__set(2, 2, Cosx),
	      f_matrix__set(3, 3, 1.0)
	     ), RxM_init, RxMatrix).

% The matrix representing the rotation about the Y axis
make_rotate_y_matrix(Ry_D, RyMatrix) :-
	Ry = deg_to_rad(Ry_D),
	Cosy = cos(Ry),
	Siny = sin(Ry),
	f_matrix__init(4, 4, RyM_init),
	call((pred(f_matrix_di, f_matrix_uo) is det -->
	      f_matrix__set(0, 0, Cosy),
	      f_matrix__set(0, 2, -Siny),
	      f_matrix__set(1, 1, 1.0),
	      f_matrix__set(2, 0, Siny),
	      f_matrix__set(2, 2, Cosy),
	      f_matrix__set(3, 3, 1.0)
	     ), RyM_init, RyMatrix).

% The matrix representing the rotation about the Z axis
make_rotate_z_matrix(Rz_D, RzMatrix) :-
	Rz = deg_to_rad(Rz_D),
	Cosz = cos(Rz),
	Sinz = sin(Rz),
	f_matrix__init(4, 4, RzM_init),
	call((pred(f_matrix_di, f_matrix_uo) is det -->
	      f_matrix__set(0, 0, Cosz),
	      f_matrix__set(0, 1, Sinz),
	      f_matrix__set(1, 0, -Sinz),
	      f_matrix__set(1, 1, Cosz),
	      f_matrix__set(2, 2, 1.0),
	      f_matrix__set(3, 3, 1.0)
	     ), RzM_init, RzMatrix).

% Convert degrees to radians.
deg_to_rad(Deg) = Rad :-
	Rad = Deg * pi / 180.0.

% Build the matrix representing the overall 3D transform to be applied to the
% polyhedron.
make_transform_matrix(transform(Scale, Rotate, Translate), TransMatrix) :-
	make_scale_matrix(Scale, SMatrix),
	make_rotate_matrix(Rotate, RMatrix),
	make_translate_matrix(Translate, TMatrix),
	f_matrix__mul(SMatrix, RMatrix, SRMatrix),
	f_matrix__mul(SRMatrix, TMatrix, TransMatrix).


% This is a nasty hack to ensure uniqueness of an f_matrix. This is required
% because nested unique modes are currently not supported by the Mercury
% compiler.
% Thanks to Tom Conway for this.
:- func u_fm(f_matrix) = f_matrix.
:- mode (u_fm(in) = f_matrix_uo) is det.

:- pragma c_code(u_fm(A::in) = (B::f_matrix_uo),
		 [will_not_call_mercury, thread_safe],
		 "B = A;"
		 ).
