%-----------------------------------------------------------------------------%
%
% Read a whitespace delimited word from a string or list of characters.
%
%-----------------------------------------------------------------------------%

:- module word.

:- interface.

:- import_module io, string, char, list.

  % reads a whitespace delimited word from the specified string.
  % read_word_from_string(String, Word, Rest) will read the first word from
  % `String' and bind it as `Word', and give back the remainder of the string
  % as `Rest'.
  %
  % NOTE: the returned io__result will never be `error(_)'
:- pred read_word_from_string(string, io__result(list(char)), string).
:- mode read_word_from_string(in, out, out) is det.

  % reads a whitespace delimited word from the specified list of chars.
  % read_word_from_list(List, Word, Rest) will read the first word from
  % `List' and bind it as `Word', and give back the remainder of the list
  % as `Rest'.
  %
  % NOTE: the returned io__result will never be `error(_)'
:- pred read_word_from_list(list(char), io__result(list(char)), list(char)).
:- mode read_word_from_list(in, out, out) is det.

%-----------------------------------------------------------------------------%
%-----------------------------------------------------------------------------%

:- implementation.


read_word_from_string(String, Result, Rest) :-
	string__to_char_list(String, List0),
	ignore_leading_whitespace(List0, List),
	read_word_from_list2(List, Word, ListRest),
	string__from_char_list(ListRest, Rest),
	(
	    Word = [],
	    Result = eof
	;
	    Word = [_ | _],
	    Result = ok(Word)
	).


read_word_from_list(List, Result, Rest) :-
	ignore_leading_whitespace(List, List0),
	read_word_from_list2(List0, Word, Rest),
	(
	    Word = [],
	    Result = eof
	;
	    Word = [_ | _],
	    Result = ok(Word)
	).

  % Ignore any leading whitespace chararters in the given list of chars.
:- pred ignore_leading_whitespace(list(char), list(char)).
:- mode ignore_leading_whitespace(in, out) is det.

ignore_leading_whitespace([], []).
ignore_leading_whitespace([Char | Chars], List) :-
	(
	    char__is_whitespace(Char)
	->
	    ignore_leading_whitespace(Chars, List)
	;
	    List = [Char | Chars]
	).


  % Read a whitespace delimited word from the given list of characters, in
  % which the first charater is not a whitespace.
:- pred read_word_from_list2(list(char), list(char), list(char)).
:- mode read_word_from_list2(in, out, out) is det.

read_word_from_list2([], [], []).
read_word_from_list2([Char | Chars], Word, Rest) :-
	(
	    char__is_whitespace(Char)
	->
	    Word = [],
	    Rest = [Char | Chars]
	;
	    read_word_from_list2(Chars, Word0, Rest),
	    Word = [Char | Word0]
	).


