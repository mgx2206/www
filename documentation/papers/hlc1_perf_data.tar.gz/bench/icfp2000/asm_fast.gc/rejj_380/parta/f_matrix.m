%-----------------------------------------------------------------------------%
%
% Float Matrix
%
%-----------------------------------------------------------------------------%

:- module f_matrix.

:- interface.

:- import_module array.

:- inst uniq_f_matrix == unique(f_matrix(ground, ground, uniq_array)).

:- mode f_matrix_di == di(uniq_f_matrix).
:- mode f_matrix_uo == out(uniq_f_matrix).
:- mode f_matrix_ui == in(uniq_f_matrix).

:- type f_matrix.

:- pred f_matrix__init(int, int, f_matrix).
:- mode f_matrix__init(in, in, f_matrix_uo) is det.

:- pred f_matrix__set(int, int, float, f_matrix, f_matrix).
:- mode f_matrix__set(in, in, in, f_matrix_di, f_matrix_uo) is det.

:- pred f_matrix__mul(f_matrix, f_matrix, f_matrix).
:- mode f_matrix__mul(in, in, f_matrix_uo) is det.

%-----------------------------------------------------------------------------%

:- implementation.

:- import_module array, float, int.

:- type f_matrix --->
	f_matrix(
		 int,		% M
		 int,		% N
		 array(float)	% the elements of the matrix
		).

%-----------------------------------------------------------------------------%

:- pred f_matrix__do_mul(array(float), array(float), int, int, int, f_matrix, f_matrix).
:- mode f_matrix__do_mul(in, in, in, in, in, f_matrix_di, f_matrix_uo) is det.

:- pred f_matrix__mul_row_by_col(array(float), array(float), int, int, int, int, float).
:- mode f_matrix__mul_row_by_col(in, in, in, in, in, in, out) is det.

f_matrix__init(M, N, Matrix) :-
	array__init(M * N, 0.0, Array),
	Matrix = f_matrix(M, N, Array).

f_matrix__set(I, J, Val, M_in, M_out) :-
	M_in = f_matrix(M, N, Array0),
	Location = I * N + J,
	array__set(Array0, Location, Val, Array),
	M_out = f_matrix(M, N, Array).

f_matrix__mul(M_in1, M_in2, M) :-
	M_in1 = f_matrix(M1, N1, Array1),
	M_in2 = f_matrix(M2, N2, Array2),
	% for completeness, should put a check here..
	% if N1 \= M2, then error
	f_matrix__init(M1, N2, M_init),
	f_matrix__do_mul(Array1, Array2, 0, 0, N1, M_init, M).

f_matrix__do_mul(Array1, Array2, Row, Col, Size, M_in, M_out) :-
	(
	    Row < Size
	->
	    (	
		Col < Size
	    ->	
		f_matrix__mul_row_by_col(Array1, Array2, Row, Col, Size, 0, Sum),
		f_matrix__set(Row, Col, Sum, M_in, M0),
		f_matrix__do_mul(Array1, Array2, Row, Col + 1, Size, M0, M_out)
	    ;	
		f_matrix__do_mul(Array1, Array2, Row + 1, 0, Size, M_in, M_out)
	    )
	;
	    M_out = M_in
	).

f_matrix__mul_row_by_col(Array1, Array2, Row, Col, Size, Elem, Sum) :-
	(
	    Elem < Size
	->
	    f_matrix__mul_row_by_col(Array1, Array2, Row, Col, Size, Elem + 1, Sum0),
	    array__lookup(Array1, Row * Size + Elem, I),
	    array__lookup(Array2, Elem * Size + Col, J),
	    S = I * J,
	    Sum = S + Sum0
	;
	    Sum = 0.0
	).
	



