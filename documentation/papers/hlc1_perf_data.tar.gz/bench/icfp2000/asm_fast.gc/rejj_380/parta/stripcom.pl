#!/usr/local/bin/perl
#  Trivial comment-stripping filter (anything from # to end of line)
#  Also strips all-blank lines (including empty lines)

while(<STDIN>) {
    chomp;
    s/\#.*$//;			# Strip comments
    print("$_\n") unless /^\s*$/;	# Skip if now all whitespace
}

exit( close(STDOUT) ? 0 : 1 );
