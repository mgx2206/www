%-----------------------------------------------------------------------------$
%
% 433-380 Project, part A
% Robert Jeschofnik (rejj), 55572
%
% poly.m
%
% Written in Mercury, because C sucks.
%
% This module contains all the predicates dealing with drawing the polys.
% (basically, everything except for input, which is in handle_input.m)
%
% Polys are projected into 2D, then clipped to the image plane. Then the
% scanlines for each face are generated, and drawn into the image buffer.
% Finally, the image is flushed to stdout.
%
%-----------------------------------------------------------------------------%

:- module poly.

:- interface.

:- import_module float, int, list, array, io.

% The instantiation for a unique polyhedron
:- inst uniq_polyhedron == unique(polyhedron(uniq_array, ground)).

:- mode polyhedron_di == di(uniq_polyhedron).
:- mode polyhedron_uo == out(uniq_polyhedron).
:- mode polyhedron_ui == in(uniq_polyhedron).

% The instantiation for a world of unique polyhedrons (The entire scene)
:- inst world_uniq_polys == uniq_array(uniq_polyhedron).

:- mode world_di == di(world_uniq_polys).
:- mode world_uo == out(world_uniq_polys).
:- mode world_ui == in(world_uniq_polys).

% The type for a vertex in 3D space. Holds it's X, Y, Z coordinates.
% NOTE: Make this an ADT, in it's own module.
% or just put all the polyhedron stuff in it's own module.. vertex, face, etc
%
% vertex(X, Y, Z)
:- type vertex --->
	vertex(float, float, float).

% A polehedron is made up of a group of verticies, organised into faces. The
% verticies are stored in an array.
% :- type vertex_array == array(vertex).

% A face of the polyhedron is a list of the verticies, given as indicies into
% the vertex_array.
:- type face == list(int).

% The type for the polyhedron itself. Groups together the verticies and the
% faces.
% polyhedron(Verts, Faces)
:- type polyhedron --->
	polyhedron(array(vertex), list(face)).

% The type that encapsulates the entire world. For part a, this is just a list
% of all the polyhedrons in it. This will be expanded to include light sources
% and the ambient light level in part b.
:- type world == array(polyhedron).


% Types handy for passing around the scale, rotate, and translate transforms
% for each object as listed in the scene description format.


% scale(Sx, Sy, Sz)
:- type scale --->
	scale(float, float, float).

% rotate(Rx, Ry, Rz)
:- type rotate --->
	rotate(float, float, float).

% translate(Tx, Ty, Tz)
:- type translate --->
	translate(float, float, float).

% Type to bundle all the transforms together. Encapsulates all the 3D
% transforms to be applied to any given object.
% transform(Scale factor, Rotation, Translation)
:- type transform --->
	transform(scale, rotate, translate).

% Type to represent the image that is being drawn. It is a two dimensional
% array of integers, representing the X and Y locations for every pixel
% (and their value)
%:- type image == array(array(colour)).
:- type image == array(colour).

% colour(Red, Green, Blue)
:- type colour --->
	colour(int, int, int).

%-----------------------------------------------------------------------------%

:- pred poly__translate(translate, polyhedron, polyhedron).
:- mode poly__translate(in, polyhedron_di, polyhedron_uo) is det.

:- pred poly__project(float, int, int, polyhedron, polyhedron).
:- mode poly__project(in, in, in, polyhedron_di, polyhedron_uo) is det.

:- pred poly__draw(int, int, polyhedron, image, image).
:- mode poly__draw(in, in, polyhedron_ui, array_di, array_uo) is det.

:- pred poly__image_init(int, int, image).
:- mode poly__image_init(in, in, array_uo) is det.

:- pred poly__image_draw(int, int, image, io__state, io__state).
:- mode poly__image_draw(in, in, array_ui, di, uo) is det.

:- pred poly__draw_scene(float, int, int, world, image, image, io__state, io__state).
:- mode poly__draw_scene(in, in, in, array_ui, array_di, array_uo, di, uo) is det.

%-----------------------------------------------------------------------------%

:- implementation.

:- import_module require, string.


:- pred do_trans(float, float, float, int, int, array(vertex), array(vertex)).
:- mode do_trans(in, in, in, in, in, array_di, array_uo) is det.

:- pred do_proj(int, int, int, int, float, int, int, array(vertex), array(vertex)).
:- mode do_proj(in, in, in, in, in, in, in, array_di, array_uo) is det.

:- pred clip(int, int, float, float, float, float).
:- mode clip(in, in, in, in, out, out) is det.

:- pred make_scanlines(array(vertex), int, int, array(list(int)), array(list(int))).
:- mode make_scanlines(array_ui, in, in, array_di, array_uo) is det.

:- pred trace_edge(int, int, int, int, int, array(list(int)), array(list(int))).
:- mode trace_edge(in, in, in, in, in, array_di, array_uo) is det.

:- pred draw_hline(int, int, int, int, image, image).
:- mode draw_hline(in, in, in, in, array_di, array_uo) is det.

:- pred make_face(array(vertex), list(int), int, array(vertex), array(vertex)).
:- mode make_face(array_ui, in, in, array_di, array_uo) is det.

:- pred draw_scanlines(int, int, array(list(int)), int, image, image).
:- mode draw_scanlines(in, in, array_ui, in, array_di, array_uo) is det.

:- pred draw_one_scanline(list(int), int, int, image, image).
:- mode draw_one_scanline(in, in, in, array_di, array_uo) is det.

:- pred do_image_draw(int, int, int, int, image, io__state, io__state).
:- mode do_image_draw(in, in, in, in, in, di, uo) is det.

:- pred do_draw_scene(float, int, int, int, int, world, image, image, io__state, io__state).
:- mode do_draw_scene(in, in, in, in, in, array_ui, array_di, array_uo, di, uo) is det.

% Perform a translation on a polyhedron, giving back the new polyhedron.
% Utilises destructive update to minimise memory usage.
poly__translate(translate(Tx, Ty, Tz), polyhedron(Vs_in, Fs), polyhedron(Vs_out, Fs)) :-
	array__size(Vs_in, NV),
	do_trans(Tx, Ty, Tz, NV, 0, Vs_in, Vs_out).


% Recursively translate each vertex in the given array of verticies.
do_trans(Tx, Ty, Tz, NV, Elem, Vs_in, Vs_out) :-
	(
	    Elem < NV
	->
	    array__lookup(Vs_in, Elem, vertex(X0, Y0, Z0)),
	    X = X0 + Tx,
	    Y = Y0 + Ty,
	    Z = Z0 + Tz,
	    array__set(Vs_in, Elem, vertex(X, Y, Z), Vs_in0),
	    do_trans(Tx, Ty, Tz, NV, Elem + 1, Vs_in0, Vs_out)
	;
	    Vs_out = Vs_in
	).

% Project a polygon from 3D to 2D.
poly__project(Focal, Width, Height, polyhedron(Vs_3D, Fs), polyhedron(Vs_2D, Fs)) :-
	Xoff = Width div 2,
	Yoff = Height div 2,
	Vs0 = Vs_3D,
	array__size(Vs0, NV),
	do_proj(Xoff, Yoff, Width, Height, Focal, NV, 0, Vs0, Vs_2D).

% Recursively project each vertex in the given array of vertices from 3D to
% 2D
do_proj(Xoff, Yoff, Width, Height, Focal, NV, Elem, Vs_3D, Vs_2D) :-
	(
	    Elem < NV
	->
	    array__lookup(Vs_3D, Elem, vertex(X0, Y0, Z)),
	    X_proj0 = (X0 * Focal) / Z,
	    X_proj = X_proj0 * -1.0,
	    X1 = float(Xoff) + X_proj,
	    Y1 = float(Yoff) + ((Y0 * Focal) / Z),

	    clip(Width, Height, X1, Y1, X, Y),
	    
	    % The projected coordinates lie in the Z = 1 plane, but the
	    % original depth is still needed for other calculations, (in part
	    % b) so it is maintained. Drawing will only look at the X and Y
	    % elements.
	    array__set(Vs_3D, Elem, vertex(X, Y, Z), Vs0),
	    do_proj(Xoff, Yoff, Width, Height, Focal, NV, Elem + 1, Vs0, Vs_2D)
	;
	    Vs_2D = Vs_3D
	).

% Clip X0 and Y0 to the image plane.
clip(Width, Height, X0, Y0, X, Y) :-
	W = float(Width),
	H = float(Height),
	(   
	    X0 < 0.0
	->
	    X = 0.0
	;
	    (
		X0 > W
	    ->
		X = W
	    ;
		X = X0
	    )
	),

	(
	    Y0 < 0.0
	->
	    Y = 0.0
	;
	    (
		Y0 > H
	    ->
		Y = H
	    ;
		Y = Y0
	    )
	).

% Draws the projected polyhedron into the image
poly__draw(Width, Height, polyhedron(Vs, Fs), Image_in, Image_out) :-
	(
	    Fs = [],
	    Image_out = Image_in
	;
	    Fs = [Face | Faces],
	    list__length(Face, Length),
	    array__init(Height, [0, 0], ScanLines_init),
	    array__init(Length, vertex(0.0, 0.0, 0.0), Poly_init),

	    % Generate the face
	    make_face(Vs, Face, 0, Poly_init, Poly),

	    % Generate the scanlines for this face
	    make_scanlines(Poly, Length, 0, ScanLines_init, ScanLines),

	    % Render the face into the image buffer
	    draw_scanlines(Width, Height, ScanLines, 0, Image_in, Image0),

	    % Recursively draw the rest of the faces in this polyhedron
	    poly__draw(Width, Height, polyhedron(Vs, Faces), Image0, Image_out)
	).

% Generate the face given by the list of verticies (Face)
make_face(ObjVs, Face, Elem, PolyVs_in, PolyVs_out) :-
	(
	    Face = [],
	    PolyVs_in = PolyVs_out
	;
	    Face = [Vert | Verts],
	    array__lookup(ObjVs, Vert, V),
	    array__set(PolyVs_in, Elem, V, PolyVs0),
	    make_face(ObjVs, Verts, Elem + 1, PolyVs0, PolyVs_out)
	).
	    

% Generate the horizontal lines that make up one face.
% If part of the polygon lies behind or at Z = 0, the scanlines at that
% position are not generated.
make_scanlines(Poly, Size, Elem, ScanLines0, ScanLines) :-
	(
	    Elem < (Size -1)
	->
	    array__lookup(Poly, Elem, vertex(X1, Y1, Z1)),
	    array__lookup(Poly, Elem + 1, vertex(X2, Y2, Z2)),
	    (
		Z1 >= 0.0
	    ->
		ScanLines = ScanLines0
	    ;
		(
		    Z2 >= 0.0
		->
		    ScanLines = ScanLines0
		;
		    round_to_int(X1) = X1i,
		    round_to_int(Y1) = Y1i,
		    round_to_int(X2) = X2i,
		    round_to_int(Y2) = Y2i,
		    (	
			Y1i < Y2i
		    ->	
			trace_edge(X1i, Y1i, X2i, Y2i, Y1i, ScanLines0, ScanLines1)
		    ;	
			trace_edge(X2i, Y2i, X1i, Y1i, Y2i, ScanLines0, ScanLines1)
		    ),
		    make_scanlines(Poly, Size, Elem + 1, ScanLines1, ScanLines) 
		)
	    )
	;
	    (	
		Elem = (Size - 1)
	    ->	
		% The final egde is between the last and the first verticies
		array__lookup(Poly, Elem, vertex(X1, Y1, Z1)),
		array__lookup(Poly, 0, vertex(X2, Y2, Z2)),
		(   
		    Z1 >= 0.0
		->  
		    ScanLines = ScanLines0
		;   
		    (	
			Z2 >= 0.0
		    ->	
			ScanLines = ScanLines0
		    ;	
			round_to_int(X1) = X1i,
			round_to_int(Y1) = Y1i,
			round_to_int(X2) = X2i,
			round_to_int(Y2) = Y2i,
			(   
			    Y1i < Y2i
			->  
			    trace_edge(X1i, Y1i, X2i, Y2i, Y1i, ScanLines0, ScanLines)
			;   
			    trace_edge(X2i, Y2i, X1i, Y1i, Y2i, ScanLines0, ScanLines)
			)
		    )
		)
	    ;	
		% There are no more edges to trace
		ScanLines = ScanLines0
	    )
	).
		
% Trace along the line from (X1, Y1) to (X2, Y2) finding the X intersections
% for each integer value of Y along the line. These are used as the endpoints
% for the scanlines
trace_edge(X1, Y1, X2, Y2, CurrY, ScanLines0, ScanLines) :-
	(   
	    % Check if the edge is horizontal. If it is, don't bother tracing
	    % along it.
	    Y2 = Y1
	->
	    ScanLines = ScanLines0
	;
	    (
		CurrY < Y2
	    ->
		% Find the X for the current Y
		X = ((CurrY - Y1) * (X2 - X1) div (Y2 - Y1)) + X1,
		
		array__lookup(ScanLines0, CurrY, Line),
		array__set(ScanLines0, CurrY, [X | Line], ScanLines1),
		trace_edge(X1, Y1, X2, Y2, CurrY + 1, ScanLines1, ScanLines)
	    ;
		ScanLines = ScanLines0
	    )
	).

% Render the scanlines into the image buffer.
draw_scanlines(Width, Height, ScanLines, Y, Image_in, Image_out) :-
	(   
	    Y < Height
	->
	    array__lookup(ScanLines, Y, ScanLine0),
	    list__sort(ScanLine0, ScanLine),
	    draw_one_scanline(ScanLine, Y, Width, Image_in, Image0),
	    draw_scanlines(Width, Height, ScanLines, Y + 1, Image0, Image_out)
	;
	    Image_out = Image_in
	).

% Draw a single scanline into the image. If there are (at least) two
% coordinates stored in the list, a horizontal line is drawn between these
% two points.
draw_one_scanline(ScanLine, Y, Width, Image_in, Image_out) :-
	(   
	    ScanLine = [],
	    Image_out = Image_in
	;
	    ScanLine = [X1 | Xs0],
	    (
		Xs0 = [],
		Image_out = Image_in
	    ;
		Xs0 = [X2 | Xs],
		draw_hline(X1, X2, Y, Width, Image_in, Image0),
		draw_one_scanline(Xs, Y, Width, Image0, Image_out)
	    )
	).

% Draw a horizontal line between X1 and X2, at height Y
draw_hline(X1, X2, Y, Width, Image_in, Image_out) :-
	(   
	    X1 < X2
	->
	    array__set(Image_in, (Y * Width) + X1, colour(255, 255, 255), Image0),
	    draw_hline(X1 + 1, X2, Y, Width, Image0, Image_out)
	;
	    Image_in = Image_out
	).

% Create the empty image buffer
poly__image_init(Width, Height, Image) :-
	array__init(Width * Height, colour(0, 0, 0), Image).

% Print out the header information for the PPM format, then output the image
% buffer.
poly__image_draw(Width, Height, Image) -->
	io__print("P6"),
	io__print(" "),
	io__write(Width),
	io__print(" "),
	io__write(Height),
	io__print(" "),
	io__write(255),
	io__nl,
	do_image_draw(Width, Height, 0, 0, Image).

% Output the image buffer in binary format. There are three bytes for every
% pixel (Red, Green, Blue). These bytes are just streamed to stdout.
do_image_draw(Width, Height, X, Y, Image) -->
	(   
	    { Y < Height }
	->
	    (
		{ X < Width }
	    ->
		{ array__lookup(Image, (Y * Width) + X, colour(R, G, B)) },
		io__write_byte(R),
		io__write_byte(G),
		io__write_byte(B),
		do_image_draw(Width, Height, X + 1, Y, Image)
	    ;
		do_image_draw(Width, Height, 0, Y + 1, Image)
	    )
	;
	    % The empty list is used to represent an empty clause in a DCG
	    []
	).

% Draw the whole scene.
poly__draw_scene(Focal, Width, Height, Scene, Image_in, Image_out) -->
	{ array__size(Scene, NumPolys) },
	do_draw_scene(Focal, Width, Height, NumPolys, 0, Scene, Image_in, Image_out),
	poly__image_draw(Width, Height, Image_out).


% Recursively draw each polyhedron into the image buffer.
do_draw_scene(Focal, Width, Height, NumPolys, CurrPoly, Scene, Image_in, Image_out) -->
	(
	    { CurrPoly < NumPolys }
	->
	    { array__lookup(Scene, CurrPoly, Poly3D) },
	    { poly__project(Focal, Width, Height, u_p(Poly3D), Poly2D) },
	    { poly__draw(Width, Height, Poly2D, Image_in, Image0) },
	    do_draw_scene(Focal, Width, Height, NumPolys, CurrPoly + 1, Scene, Image0, Image_out)
	;
	    { Image_out = Image_in }
	).


% This is a nasty hack to ensure uniqueness of an array. This is required
% because nested unique modes are currently not supported by the Mercury
% compiler.
% Thanks to Tom Conway for this.
:- func u(array(T)) = array(T).
:- mode (u(in) = array_uo) is det.

:- pragma c_code(u(A::in) = (B::array_uo),
		 [will_not_call_mercury, thread_safe],
		 "B = A;"
		 ).

% Same as above, but for polyhedrons.
:- func u_p(polyhedron) = polyhedron.
:- mode (u_p(in) = polyhedron_uo) is det.

:- pragma c_code(u_p(A::in) = (B::polyhedron_uo),
		 [will_not_call_mercury, thread_safe],
		 "B = A;"
		 ).
