%-----------------------------------------------------------------------------%
%
% 433-380 Project, part A.
% Robert Jeschofnik (rejj), 55572
%
% parta.m
%
% Written in Mercury, because C sucks.
%
% Reads in a scene description, and all the objects described therein.
% The objects are then rendered to an image buffer, which is then output
% to stdout in PPM format.
%
% The method of choice for rendering polygons in this program is by forming
% horizontal scanlines for each face, then drawing each of these in turn.
%
%-----------------------------------------------------------------------------%

:- module parta.

:- interface.

:- import_module io.

:- pred main(io__state::di, io__state::uo) is det.

%-----------------------------------------------------------------------------%

:- implementation.

:- import_module char, int, float, string, list, array, require.
:- import_module poly, handle_input.

:- pred perform_rendering(float, int, int, io__state, io__state).
:- mode perform_rendering(in, in, in, di, uo) is det.

%-----------------------------------------------------------------------------%

main -->
	io__command_line_arguments(Args),
	(
	    {sanity_check_args(Args, Focal, Width, Height)}
	->  
	    perform_rendering(Focal, Width, Height)
	;
	    display_usage
	).

% Read in the scene description, and then draw the scene.
perform_rendering(Focal, Width, Height) -->
	{ array__make_empty_array(Scene0) },
	read_scene_desc(Scene0, Scene),
	{ poly__image_init(Width, Height, Image0) },
	poly__draw_scene(Focal, Width, Height, Scene, Image0, _Image).








