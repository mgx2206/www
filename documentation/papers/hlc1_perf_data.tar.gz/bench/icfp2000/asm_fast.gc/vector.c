/*
** Automatically generated from `vector.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__vector__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "vector.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "vector.c"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"


	#include <math.h>

	/*
	** Mathematical constants.
	**
	** The maximum number of significant decimal digits which
	** can be packed into an IEEE-754 extended precision
	** floating point number is 18.  Therefore 20 significant
	** decimal digits for these constants should be plenty.
	*/

	#define	ML_FLOAT_E		2.7182818284590452354
	#define	ML_FLOAT_PI		3.1415926535897932384
	#define	ML_FLOAT_LN2		0.69314718055994530941


#line 52 "vector.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


#include "mercury_deep_copy.h"

#ifdef CONSERVATIVE_GC
  /* for conservative GC, shallow copies suffice */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		NewVal = OldVal;					\
	} while (0)
#else
  /*
  ** Note that we need to save/restore the MR_hp register, if it
  ** is transient, before/after calling MR_deep_copy().
  */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		MR_save_transient_hp();					\
		NewVal = MR_deep_copy(&OldVal, (MR_TypeInfo) TypeInfo_for_T,\
				(const MR_Word *) SolutionsHeapPtr,	\
				MR_ENGINE(MR_eng_solutions_heap_zone)->top);\
		MR_restore_transient_hp();				\
	} while (0)
#endif


#line 82 "vector.c"
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"

#include "mercury_heap.h"	/* for MR_incr_hp_msg() etc. */
#include "mercury_misc.h"	/* for MR_fatal_error() */
#include "mercury_string.h"	/* for MR_make_aligned_string() */

#line 89 "vector.c"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_TYPECTORDESC_GUARD
#define ML_TYPECTORDESC_GUARD

/*
** Values of type `std_util:type_desc' are represented the same way as
** values of type `private_builtin:type_info' (this representation is
** documented in compiler/polymorphism.m). Some parts of the library
** (e.g. the gc initialization code) depend on this.
** The C type corresponding to these Mercury types is `MR_TypeInfo'.
**
** Values of type `std_util:type_ctor_desc' are not guaranteed to be
** represented the same way as values of type `private_builtin:type_ctor_info'.
** The representations *are* in fact identical for first order types, but they
** differ for higher order and tuple types. Instead of a type_ctor_desc
** being a structure containing a pointer to the type_ctor_info for pred/0
** or func/0 and an arity, we have a single small encoded integer. This
** integer is four times the arity, plus zero, one or two; plus zero encodes a
** tuple, plus one encodes a predicate, plus two encodes a function.
** The maximum arity that can be encoded is given by MR_MAX_VARIABLE_ARITY
** (see below).
** The C type corresponding to std_util:type_ctor_desc is `MR_TypeCtorDesc'.
*/

/*
** Declare the MR_TypeCtorDesc ADT.
**
** Note that `struct MR_TypeCtorDesc_Struct' is deliberately left undefined.
** MR_TypeCtorDesc is declared as a pointer to a dummy structure only
** in order to allow the C compiler to catch errors in which things other
** than MR_TypeCtorDescs are given as arguments to macros that depend on their
** arguments being MR_TypeCtorDescs. The actual value is either a small integer
** or a pointer to a MR_TypeCtorInfo_Struct structure, as described above.
*/
typedef struct MR_TypeCtorDesc_Struct *MR_TypeCtorDesc;

/*
** The maximum arity that can be encoded should be set to twice the maximum
** number of general purpose registers, since an predicate or function having
** more arguments that this would run out of registers when passing the input
** arguments, or the output arguments, or both.
**
** XXX When tuples were added this was reduced to be the maximum number
** of general purpose registers, to reduce the probability that the
** `small' integers for higher-order and tuple types are confused with
** type_ctor_info pointers. This still allows higher-order terms with
** 1024 arguments, which is more than ../LIMITATIONS promises.
*/
#define MR_MAX_VARIABLE_ARITY         MR_MAX_VIRTUAL_REG

/*
** Constructors for the MR_TypeCtorDesc ADT
*/

#define MR_TYPECTOR_DESC_MAKE_PRED(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4) )
#define MR_TYPECTOR_DESC_MAKE_FUNC(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4 + 1) )
#define MR_TYPECTOR_DESC_MAKE_TUPLE(Arity)                                      ( (MR_TypeCtorDesc) ((Arity) * 4 + 2) )
#define MR_TYPECTOR_DESC_MAKE_FIXED_ARITY(type_ctor_info)                       ( MR_CHECK_EXPR_TYPE(type_ctor_info, MR_TypeCtorInfo),                    (MR_TypeCtorDesc) type_ctor_info )

/*
** Access macros for the MR_TypeCtor ADT.
**
** The MR_TYPECTOR_DESC_GET_VA_* macros should only be called if
** MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns true.
** The MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO() macro
** should only be called if MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns false.
*/
#define MR_TYPECTOR_DESC_IS_VARIABLE_ARITY(T)                                   ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) <= (4 * MR_MAX_VARIABLE_ARITY + 2) )
#define MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO(T)                      ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_TypeCtorInfo) (T) )
#define MR_TYPECTOR_DESC_GET_VA_ARITY(T)                                        ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) / 4 )
#define MR_TYPECTOR_DESC_GET_VA_NAME(T)                                         ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) (((MR_Unsigned) (T) % 4 == 0)                                ? "pred"                                                              : (((MR_Unsigned) (T) % 4 == 1)                                             ? "func"                                                              : "{}" )) )
#define MR_TYPECTOR_DESC_GET_VA_MODULE_NAME(T)                                  ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) "builtin" )
#define MR_TYPECTOR_DESC_GET_VA_TYPE_CTOR_INFO(T)                               ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 ((MR_Unsigned) (T) % 4 == 0)                                                  ? MR_TYPE_CTOR_INFO_HO_PRED                                             : (((MR_Unsigned) (T) % 4 == 1)                                            ? MR_TYPE_CTOR_INFO_HO_FUNC                                             : MR_TYPE_CTOR_INFO_TUPLE ) )

#endif /* ML_TYPECTORDESC_GUARD */


#line 170 "vector.c"
#line 126 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_CONSTRUCT_INFO_GUARD
#define ML_CONSTRUCT_INFO_GUARD

typedef struct ML_Construct_Info_Struct {
    MR_ConstString          functor_name;
    MR_Integer              arity;
    const MR_PseudoTypeInfo *arg_pseudo_type_infos;
    MR_ConstString          *arg_names;
    MR_TypeCtorRep          type_ctor_rep;
    union {
        const MR_EnumFunctorDesc  *enum_functor_desc;
        const MR_NotagFunctorDesc *notag_functor_desc;
        const MR_DuFunctorDesc    *du_functor_desc;
    }                       functor_info;
} ML_Construct_Info;

#endif

extern  void            ML_type_ctor_and_args(MR_TypeInfo type_info,
                            bool collapse_equivalences,
                            MR_TypeCtorDesc *type_ctor_desc_ptr,
                            MR_Word *arg_type_info_list_ptr);
extern  int     	    ML_get_num_functors(MR_TypeInfo type_info);
extern	MR_Word		    ML_type_params_vector_to_list(int arity,
                            MR_TypeInfoParams type_params);
extern	MR_Word		    ML_arg_name_vector_to_list(int arity,
                            MR_ConstString *arg_names);
extern	MR_Word		    ML_pseudo_type_info_vector_to_type_info_list(int arity,
                            MR_TypeInfoParams type_params,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  bool    	    ML_get_functors_check_range(int functor_number,
                            MR_TypeInfo type_info,
                            ML_Construct_Info *construct_info);
extern  void    	    ML_copy_arguments_from_list_to_vector(int arity,
                            MR_Word arg_list, MR_Word term_vector);
extern  bool    	    ML_typecheck_arguments(MR_TypeInfo type_info,
                            int arity, MR_Word arg_list,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  MR_TypeInfo	    ML_make_type(int arity, MR_TypeCtorDesc type_ctor_desc,
				             MR_Word arg_type_list);

#line 216 "vector.c"
#line 170 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


extern	MR_TypeCtorDesc ML_make_type_ctor_desc(MR_TypeInfo type_info,
				MR_TypeCtorInfo type_ctor_info);


#line 224 "vector.c"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


    #include <stdio.h>
	#include "mercury_library_types.h"		/* for MR_ArrayType */

#ifdef MR_DEEP_PROFILING
    #include "mercury_deep_profiling.h"
#endif

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef	ML_EXPAND_INFO_GUARD
#define	ML_EXPAND_INFO_GUARD

typedef struct {
    int                     num_extra_args;
    MR_Word                 *arg_values;
    MR_TypeInfo             *arg_type_infos;
    bool                    can_free_arg_type_infos;
} ML_Expand_Args_Fields;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
} ML_Expand_Functor_Args_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
    bool                    limit_reached;
} ML_Expand_Functor_Args_Limit_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor_only;
} ML_Expand_Functor_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    ML_Expand_Args_Fields   args_only;
} ML_Expand_Args_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    bool                    chosen_index_exists;
    MR_Word                 *chosen_value_ptr;
    MR_TypeInfo             chosen_type_info;
} ML_Expand_Chosen_Arg_Only_Info;

    /* Prototypes */

extern  void    ML_expand_functor_args(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Args_Info *expand_info);

extern  void    ML_expand_functor_args_limit(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int max_arity,
                    ML_Expand_Functor_Args_Limit_Info *expand_info);

extern  void    ML_expand_functor_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Only_Info *expand_info);

extern  void    ML_expand_args_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Args_Only_Info *expand_info);

extern  void    ML_expand_chosen_arg_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int chosen,
                    ML_Expand_Chosen_Arg_Only_Info *expand_info);

    /*
    ** NB. ML_arg() is also used by arg_ref and new_arg_ref
    ** in store.m, in trace/mercury_trace_vars.m, and in
    ** extras/trailed_update/tr_store.m.
    */
extern  bool    ML_arg(MR_TypeInfo type_info, MR_Word *term, int arg_index,
                    MR_TypeInfo *arg_type_info_ptr, MR_Word **argument_ptr);

    /*
    ** NB. ML_named_arg_num() is used in mercury_trace_vars.c.
    */
extern  bool    ML_named_arg_num(MR_TypeInfo type_info, MR_Word *term_ptr,
                    const char *arg_name, int *arg_num_ptr);

/*
** The following macros factor out the common parts of the various
** deconstruction predicates.
*/

    /*
    ** Check for attempts to deconstruct a non-canonical type.
    ** Such deconstructions must be cc_multi, which is why we treat
    ** violations of this as runtime errors in det deconstruction
    ** predicates.
    ** (There ought to be cc_multi versions of those predicates.)
    */
#define ML_abort_if_type_is_noncanonical(ei, predname)                  do {                                                                    if ((ei).non_canonical_type) {                                          MR_fatal_error("called " predname " for a type "                    "with a user-defined equality predicate");                }                                                               } while (0)

#endif

#define ML_deconstruct_get_functor(ei, functor_field, var)              do {                                                                    MR_make_aligned_string(MR_LVALUE_CAST(MR_ConstString, var),             (ei).functor_field);                                        } while (0)

#define ML_deconstruct_get_arity(ei, var)                               do {                                                                    var = (ei).arity;                                               } while (0)

#define ML_deconstruct_get_arg_list(ei, args_field, var)                do {                                                                    int     i;                                                                                                                              var = MR_list_empty_msg(MR_PROC_LABEL);                             i = (ei).arity;                                                                                                                         while (--i >= 0) {                                                      MR_Word arg;                                                                                                                                /* Create an argument on the heap */                            MR_new_univ_on_hp(arg,                                                  (ei).args_field.arg_type_infos[i],                                  (ei).args_field.arg_values[i +                                          (ei).args_field.num_extra_args]);                                                                                                   /* Join the argument to the front of the list */                var = MR_list_cons_msg(arg, var, MR_PROC_LABEL);                }                                                               } while (0)

    /*
    ** Free any arg_type_infos allocated by the ML_expand variant.
    ** Should be called after we have used them for the last time.
    */
#define ML_deconstruct_free_allocated_arg_type_infos(ei, args_field)    do {                                                                    if ((ei).args_field.can_free_arg_type_infos) {                          MR_GC_free((ei).args_field.arg_type_infos);                     }                                                               } while (0)


#line 346 "vector.c"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#include <float.h>
	#include <math.h>


#line 354 "vector.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#define	ML_FLOAT_RADIX	FLT_RADIX	/* There is no DBL_RADIX. */

	#if defined USE_SINGLE_PREC_FLOAT
		#define	ML_FLOAT_MAX		FLT_MAX
		#define	ML_FLOAT_MIN		FLT_MIN
		#define	ML_FLOAT_EPSILON	FLT_EPSILON
		#define	ML_FLOAT_MANT_DIG	FLT_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	FLT_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	FLT_MAX_EXP
	#else
		#define	ML_FLOAT_MAX		DBL_MAX
		#define	ML_FLOAT_MIN		DBL_MIN
		#define	ML_FLOAT_EPSILON	DBL_EPSILON
		#define	ML_FLOAT_MANT_DIG	DBL_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	DBL_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	DBL_MAX_EXP
	#endif


#line 377 "vector.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 380 "vector.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 386 "vector.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 394 "vector.c"


static const struct mercury_data_vector__common_0_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_vector__common_0;

static const struct mercury_data_vector__common_1_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_vector__common_1;

static const struct mercury_data_vector__common_2_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_vector__common_2;

static const struct mercury_data_vector__common_3_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
}  mercury_data_vector__common_3;
extern const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_vector_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_real_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_position_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_point_0;
extern const MR_DuFunctorDesc * mercury_data_vector__du_name_ordered_vector_0[];
static const MR_DuFunctorDesc mercury_data_vector__du_functor_desc_vector_0_0;
extern const MR_PseudoTypeInfo mercury_data_vector__field_types_vector_0_0[];
extern const MR_DuPtagLayout mercury_data_vector__du_ptag_ordered_vector_0[];
extern const MR_DuFunctorDesc * mercury_data_vector__du_stag_ordered_vector_0_0[];
MR_define_extern_entry(mercury__fn__f_118_101_99_116_111_114_95_95_43_2_0);
MR_define_extern_entry(mercury__fn__f_118_101_99_116_111_114_95_95_45_2_0);
MR_define_extern_entry(mercury__fn__f_118_101_99_116_111_114_95_95_45_1_0);
MR_define_extern_entry(mercury__fn__vector__dot_2_0);
MR_define_extern_entry(mercury__fn__vector__positive_dot_2_0);
MR_declare_label(mercury__fn__vector__positive_dot_2_0_i2);
MR_define_extern_entry(mercury__fn__vector__cross_2_0);
MR_define_extern_entry(mercury__fn__vector__mag_1_0);
MR_define_extern_entry(mercury__fn__vector__mag2_1_0);
MR_define_extern_entry(mercury__fn__vector__distance_squared_2_0);
MR_define_extern_entry(mercury__fn__vector__unit_1_0);
MR_declare_label(mercury__fn__vector__unit_1_0_i2);
MR_declare_label(mercury__fn__vector__unit_1_0_i5);
MR_declare_label(mercury__fn__vector__unit_1_0_i7);
MR_declare_label(mercury__fn__vector__unit_1_0_i9);
MR_declare_label(mercury__fn__vector__unit_1_0_i12);
MR_declare_label(mercury__fn__vector__unit_1_0_i14);
MR_declare_label(mercury__fn__vector__unit_1_0_i16);
MR_declare_label(mercury__fn__vector__unit_1_0_i41);
MR_declare_label(mercury__fn__vector__unit_1_0_i21);
MR_define_extern_entry(mercury__fn__vector__scale_2_0);
MR_define_extern_entry(mercury__fn__vector__angle_2_0);
MR_declare_label(mercury__fn__vector__angle_2_0_i2);
MR_declare_label(mercury__fn__vector__angle_2_0_i20);
MR_declare_label(mercury__fn__vector__angle_2_0_i7);
MR_declare_label(mercury__fn__vector__angle_2_0_i9);
MR_declare_label(mercury__fn__vector__angle_2_0_i10);
MR_declare_label(mercury__fn__vector__angle_2_0_i22);
MR_declare_label(mercury__fn__vector__angle_2_0_i15);
MR_declare_label(mercury__fn__vector__angle_2_0_i17);
MR_define_extern_entry(mercury__fn__vector__project_2_0);
MR_declare_label(mercury__fn__vector__project_2_0_i2);
MR_declare_label(mercury__fn__vector__project_2_0_i5);
MR_declare_label(mercury__fn__vector__project_2_0_i7);
MR_declare_label(mercury__fn__vector__project_2_0_i9);
MR_declare_label(mercury__fn__vector__project_2_0_i12);
MR_declare_label(mercury__fn__vector__project_2_0_i14);
MR_declare_label(mercury__fn__vector__project_2_0_i16);
MR_declare_label(mercury__fn__vector__project_2_0_i41);
MR_declare_label(mercury__fn__vector__project_2_0_i21);
MR_define_extern_entry(mercury__fn__vector__projectXY_1_0);
MR_define_extern_entry(mercury__fn__vector__projectXZ_1_0);
MR_define_extern_entry(mercury__fn__vector__projectZY_1_0);
MR_define_extern_entry(mercury__fn__vector__xy_1_0);
MR_define_extern_entry(mercury__fn__vector__xz_1_0);
MR_define_extern_entry(mercury__fn__vector__zy_1_0);
MR_define_extern_entry(mercury__fn__vector__zero_0_0);
MR_define_extern_entry(mercury__fn__vector__i_0_0);
MR_define_extern_entry(mercury__fn__vector__j_0_0);
MR_define_extern_entry(mercury__fn__vector__k_0_0);
MR_define_extern_entry(mercury__fn__vector__real_epsilon_0_0);
MR_define_extern_entry(mercury__fn__vector__real_max_0_0);
MR_define_extern_entry(mercury____Unify___vector__real_0_0);
MR_define_extern_entry(mercury____Compare___vector__real_0_0);
MR_declare_label(mercury____Compare___vector__real_0_0_i2);
MR_declare_label(mercury____Compare___vector__real_0_0_i3);
MR_define_extern_entry(mercury____Unify___vector__vector_0_0);
MR_declare_label(mercury____Unify___vector__vector_0_0_i1);
MR_define_extern_entry(mercury____Compare___vector__vector_0_0);
MR_declare_label(mercury____Compare___vector__vector_0_0_i4);
MR_declare_label(mercury____Compare___vector__vector_0_0_i3);
MR_declare_label(mercury____Compare___vector__vector_0_0_i16);
MR_declare_label(mercury____Compare___vector__vector_0_0_i15);
MR_declare_label(mercury____Compare___vector__vector_0_0_i26);
MR_declare_label(mercury____Compare___vector__vector_0_0_i27);
MR_define_extern_entry(mercury____Unify___vector__position_0_0);
MR_declare_label(mercury____Unify___vector__position_0_0_i1);
MR_define_extern_entry(mercury____Compare___vector__position_0_0);
MR_define_extern_entry(mercury____Unify___vector__point_0_0);
MR_declare_label(mercury____Unify___vector__point_0_0_i1);
MR_define_extern_entry(mercury____Compare___vector__point_0_0);

static const MR_Float mercury_float_const_0pt00000000000000 = 0.00000000000000;
static const struct mercury_data_vector__common_0_struct mercury_data_vector__common_0 = {
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000
};

static const MR_Float mercury_float_const_1pt00000000000000 = 1.00000000000000;
static const struct mercury_data_vector__common_1_struct mercury_data_vector__common_1 = {
	(MR_Word *) &mercury_float_const_1pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000
};

static const struct mercury_data_vector__common_2_struct mercury_data_vector__common_2 = {
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_1pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000
};

static const struct mercury_data_vector__common_3_struct mercury_data_vector__common_3 = {
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_1pt00000000000000
};
extern const MR_DuFunctorDesc * mercury_data_vector__du_name_ordered_vector_0[];
extern const MR_DuPtagLayout mercury_data_vector__du_ptag_ordered_vector_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_vector_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___vector__vector_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___vector__vector_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___vector__vector_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"vector",
	"vector",
	4,
	{ (void *) mercury_data_vector__du_name_ordered_vector_0 },
	{ (void *) mercury_data_vector__du_ptag_ordered_vector_0 },
	1,
	1
};
extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_float_0;

const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_real_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___vector__real_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___vector__real_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___vector__real_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"vector",
	"real",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0 },
	-1,
	-1
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_vector_0;

const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_position_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___vector__position_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___vector__position_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___vector__position_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"vector",
	"position",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0 },
	-1,
	-1
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_vector_0;

const struct MR_TypeCtorInfo_Struct mercury_data_vector__type_ctor_info_point_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___vector__point_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___vector__point_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___vector__point_0_0)),
	MR_TYPECTOR_REP_EQUIV_GROUND,
	NULL,
	NULL,
	"vector",
	"point",
	4,
	{ 0 },
	{ (void *) (MR_PseudoTypeInfo) &mercury_data_vector__type_ctor_info_vector_0 },
	-1,
	-1
};

const MR_DuFunctorDesc * mercury_data_vector__du_name_ordered_vector_0[] = {
	&mercury_data_vector__du_functor_desc_vector_0_0
};

static const MR_DuFunctorDesc mercury_data_vector__du_functor_desc_vector_0_0 = {
	"point",
	3,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_vector__field_types_vector_0_0,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_vector__field_types_vector_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0,
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_float_0
};

const MR_DuPtagLayout mercury_data_vector__du_ptag_ordered_vector_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_vector__du_stag_ordered_vector_0_0 }

};

const MR_DuFunctorDesc * mercury_data_vector__du_stag_ordered_vector_0_0[] = {
	&mercury_data_vector__du_functor_desc_vector_0_0

};

MR_declare_entry(mercury__fn__math__sqrt_1_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data_math__type_ctor_info_domain_error_0;
MR_declare_entry(mercury__exception__throw_1_0);
MR_declare_entry(mercury__fn__math__acos_1_0);

MR_BEGIN_MODULE(vector_module)
	MR_init_entry(mercury__fn__f_118_101_99_116_111_114_95_95_43_2_0);
	MR_init_entry(mercury__fn__f_118_101_99_116_111_114_95_95_45_2_0);
	MR_init_entry(mercury__fn__f_118_101_99_116_111_114_95_95_45_1_0);
	MR_init_entry(mercury__fn__vector__dot_2_0);
	MR_init_entry(mercury__fn__vector__positive_dot_2_0);
	MR_init_label(mercury__fn__vector__positive_dot_2_0_i2);
	MR_init_entry(mercury__fn__vector__cross_2_0);
	MR_init_entry(mercury__fn__vector__mag_1_0);
	MR_init_entry(mercury__fn__vector__mag2_1_0);
	MR_init_entry(mercury__fn__vector__distance_squared_2_0);
	MR_init_entry(mercury__fn__vector__unit_1_0);
	MR_init_label(mercury__fn__vector__unit_1_0_i2);
	MR_init_label(mercury__fn__vector__unit_1_0_i5);
	MR_init_label(mercury__fn__vector__unit_1_0_i7);
	MR_init_label(mercury__fn__vector__unit_1_0_i9);
	MR_init_label(mercury__fn__vector__unit_1_0_i12);
	MR_init_label(mercury__fn__vector__unit_1_0_i14);
	MR_init_label(mercury__fn__vector__unit_1_0_i16);
	MR_init_label(mercury__fn__vector__unit_1_0_i41);
	MR_init_label(mercury__fn__vector__unit_1_0_i21);
	MR_init_entry(mercury__fn__vector__scale_2_0);
	MR_init_entry(mercury__fn__vector__angle_2_0);
	MR_init_label(mercury__fn__vector__angle_2_0_i2);
	MR_init_label(mercury__fn__vector__angle_2_0_i20);
	MR_init_label(mercury__fn__vector__angle_2_0_i7);
	MR_init_label(mercury__fn__vector__angle_2_0_i9);
	MR_init_label(mercury__fn__vector__angle_2_0_i10);
	MR_init_label(mercury__fn__vector__angle_2_0_i22);
	MR_init_label(mercury__fn__vector__angle_2_0_i15);
	MR_init_label(mercury__fn__vector__angle_2_0_i17);
	MR_init_entry(mercury__fn__vector__project_2_0);
	MR_init_label(mercury__fn__vector__project_2_0_i2);
	MR_init_label(mercury__fn__vector__project_2_0_i5);
	MR_init_label(mercury__fn__vector__project_2_0_i7);
	MR_init_label(mercury__fn__vector__project_2_0_i9);
	MR_init_label(mercury__fn__vector__project_2_0_i12);
	MR_init_label(mercury__fn__vector__project_2_0_i14);
	MR_init_label(mercury__fn__vector__project_2_0_i16);
	MR_init_label(mercury__fn__vector__project_2_0_i41);
	MR_init_label(mercury__fn__vector__project_2_0_i21);
	MR_init_entry(mercury__fn__vector__projectXY_1_0);
	MR_init_entry(mercury__fn__vector__projectXZ_1_0);
	MR_init_entry(mercury__fn__vector__projectZY_1_0);
	MR_init_entry(mercury__fn__vector__xy_1_0);
	MR_init_entry(mercury__fn__vector__xz_1_0);
	MR_init_entry(mercury__fn__vector__zy_1_0);
	MR_init_entry(mercury__fn__vector__zero_0_0);
	MR_init_entry(mercury__fn__vector__i_0_0);
	MR_init_entry(mercury__fn__vector__j_0_0);
	MR_init_entry(mercury__fn__vector__k_0_0);
	MR_init_entry(mercury__fn__vector__real_epsilon_0_0);
	MR_init_entry(mercury__fn__vector__real_max_0_0);
	MR_init_entry(mercury____Unify___vector__real_0_0);
	MR_init_entry(mercury____Compare___vector__real_0_0);
	MR_init_label(mercury____Compare___vector__real_0_0_i2);
	MR_init_label(mercury____Compare___vector__real_0_0_i3);
	MR_init_entry(mercury____Unify___vector__vector_0_0);
	MR_init_label(mercury____Unify___vector__vector_0_0_i1);
	MR_init_entry(mercury____Compare___vector__vector_0_0);
	MR_init_label(mercury____Compare___vector__vector_0_0_i4);
	MR_init_label(mercury____Compare___vector__vector_0_0_i3);
	MR_init_label(mercury____Compare___vector__vector_0_0_i16);
	MR_init_label(mercury____Compare___vector__vector_0_0_i15);
	MR_init_label(mercury____Compare___vector__vector_0_0_i26);
	MR_init_label(mercury____Compare___vector__vector_0_0_i27);
	MR_init_entry(mercury____Unify___vector__position_0_0);
	MR_init_label(mercury____Unify___vector__position_0_0_i1);
	MR_init_entry(mercury____Compare___vector__position_0_0);
	MR_init_entry(mercury____Unify___vector__point_0_0);
	MR_init_label(mercury____Unify___vector__point_0_0_i1);
	MR_init_entry(mercury____Compare___vector__point_0_0);
MR_BEGIN_CODE

/* code for predicate '+'/3 in mode 0 */
MR_define_entry(mercury__fn__f_118_101_99_116_111_114_95_95_43_2_0);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__f_118_101_99_116_111_114_95_95_43_2_0, "vector:vector/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0)) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)) + MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate '-'/3 in mode 0 */
MR_define_entry(mercury__fn__f_118_101_99_116_111_114_95_95_45_2_0);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__f_118_101_99_116_111_114_95_95_45_2_0, "vector:vector/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate '-'/2 in mode 0 */
MR_define_entry(mercury__fn__f_118_101_99_116_111_114_95_95_45_1_0);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__f_118_101_99_116_111_114_95_95_45_1_0, "vector:vector/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word(((MR_Float) 0.00000000000000 - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word(((MR_Float) 0.00000000000000 - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word(((MR_Float) 0.00000000000000 - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'dot'/3 in mode 0 */
MR_define_entry(mercury__fn__vector__dot_2_0);
	MR_r1 = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2)))));
	MR_proceed();
/* code for predicate 'positive_dot'/3 in mode 0 */
MR_define_entry(mercury__fn__vector__positive_dot_2_0);
	MR_r3 = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2)))));
	if ((MR_word_to_float(MR_r3) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__positive_dot_2_0_i2);
	}
	MR_r1 = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_proceed();
MR_define_label(mercury__fn__vector__positive_dot_2_0_i2);
	MR_r1 = MR_r3;
	MR_proceed();
/* code for predicate 'cross'/3 in mode 0 */
MR_define_entry(mercury__fn__vector__cross_2_0);
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5, MR_tempr6, MR_tempr7;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__cross_2_0, "vector:vector/0");
	MR_r3 = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r4 = MR_tempr2;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r5 = MR_tempr3;
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r6 = MR_tempr4;
	MR_tempr5 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_r7 = MR_tempr5;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word(((MR_word_to_float(MR_tempr2) * MR_word_to_float(MR_tempr3)) - (MR_word_to_float(MR_tempr4) * MR_word_to_float(MR_tempr5))));
	MR_tempr6 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r8 = MR_tempr6;
	MR_tempr7 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r2 = MR_tempr7;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word(((MR_word_to_float(MR_tempr4) * MR_word_to_float(MR_tempr6)) - (MR_word_to_float(MR_tempr7) * MR_word_to_float(MR_tempr3))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word(((MR_word_to_float(MR_tempr7) * MR_word_to_float(MR_tempr5)) - (MR_word_to_float(MR_tempr2) * MR_word_to_float(MR_tempr6))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'mag'/2 in mode 0 */
MR_define_entry(mercury__fn__vector__mag_1_0);
	MR_r1 = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)))));
	MR_tailcall(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		MR_ENTRY(mercury__fn__vector__mag_1_0));
/* code for predicate 'mag2'/2 in mode 0 */
MR_define_entry(mercury__fn__vector__mag2_1_0);
	MR_r1 = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)))));
	MR_proceed();
/* code for predicate 'distance_squared'/3 in mode 0 */
MR_define_entry(mercury__fn__vector__distance_squared_2_0);
	MR_r1 = MR_float_to_word(((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0))) * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0)))) + ((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1))) * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1))))) + ((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2))) * (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2)) - MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2))))));
	MR_proceed();
/* code for predicate 'unit'/2 in mode 0 */
MR_define_entry(mercury__fn__vector__unit_1_0);
	MR_incr_sp_push_msg(5, "vector:unit/2");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_float_to_word((((MR_word_to_float(MR_stackvar(1)) * MR_word_to_float(MR_stackvar(1))) + (MR_word_to_float(MR_stackvar(2)) * MR_word_to_float(MR_stackvar(2)))) + (MR_word_to_float(MR_stackvar(3)) * MR_word_to_float(MR_stackvar(3)))));
	MR_call_localret(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		mercury__fn__vector__unit_1_0_i2,
		MR_ENTRY(mercury__fn__vector__unit_1_0));
MR_define_label(mercury__fn__vector__unit_1_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__vector__unit_1_0));
	MR_stackvar(4) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__vector__unit_1_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 826 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i5);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(4)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i7);
	}
	MR_r1 = MR_stackvar(4);
	MR_stackvar(4) = MR_r1;
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(1)) / MR_word_to_float(MR_r1)));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__unit_1_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 848 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i12);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(4)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i14);
	}
	MR_stackvar(2) = MR_float_to_word((MR_word_to_float(MR_stackvar(2)) / MR_word_to_float(MR_stackvar(4))));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__unit_1_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 868 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(4)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__unit_1_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / MR_word_to_float(MR_stackvar(4))));
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury__fn__vector__unit_1_0_i5);
	MR_r1 = MR_stackvar(4);
	MR_stackvar(4) = MR_r1;
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(1)) / MR_word_to_float(MR_r1)));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__unit_1_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 898 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i12);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(4)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i14);
	}
	MR_stackvar(2) = MR_float_to_word((MR_word_to_float(MR_stackvar(2)) / MR_word_to_float(MR_stackvar(4))));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__unit_1_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 918 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(4)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__unit_1_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / MR_word_to_float(MR_stackvar(4))));
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury__fn__vector__unit_1_0_i7);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__vector__unit_1_0_i9,
		MR_ENTRY(mercury__fn__vector__unit_1_0));
MR_define_label(mercury__fn__vector__unit_1_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__vector__unit_1_0));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__unit_1_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 952 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i12);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(4)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i14);
	}
	MR_stackvar(2) = MR_float_to_word((MR_word_to_float(MR_stackvar(2)) / MR_word_to_float(MR_stackvar(4))));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__unit_1_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 972 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(4)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__unit_1_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / MR_word_to_float(MR_stackvar(4))));
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury__fn__vector__unit_1_0_i12);
	MR_stackvar(2) = MR_float_to_word((MR_word_to_float(MR_stackvar(2)) / MR_word_to_float(MR_stackvar(4))));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__unit_1_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1000 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(4)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__unit_1_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / MR_word_to_float(MR_stackvar(4))));
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury__fn__vector__unit_1_0_i14);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__vector__unit_1_0_i16,
		MR_ENTRY(mercury__fn__vector__unit_1_0));
MR_define_label(mercury__fn__vector__unit_1_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__vector__unit_1_0));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__unit_1_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1034 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(4)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__unit_1_0_i21);
	}
MR_define_label(mercury__fn__vector__unit_1_0_i41);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__unit_1_0, "vector:vector/0");
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / MR_word_to_float(MR_stackvar(4))));
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury__fn__vector__unit_1_0_i21);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_ENTRY(mercury__fn__vector__unit_1_0));
/* code for predicate 'scale'/3 in mode 0 */
MR_define_entry(mercury__fn__vector__scale_2_0);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__scale_2_0, "vector:vector/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1))));
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2))));
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'angle'/3 in mode 0 */
MR_define_entry(mercury__fn__vector__angle_2_0);
	MR_incr_sp_push_msg(4, "vector:angle/3");
	MR_stackvar(4) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r2;
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r5 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(2) = MR_float_to_word((((MR_word_to_float(MR_r3) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0))) + (MR_word_to_float(MR_r4) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1)))) + (MR_word_to_float(MR_r5) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2)))));
	MR_r1 = MR_float_to_word((((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r3)) + (MR_word_to_float(MR_r4) * MR_word_to_float(MR_r4))) + (MR_word_to_float(MR_r5) * MR_word_to_float(MR_r5))));
	MR_call_localret(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		mercury__fn__vector__angle_2_0_i2,
		MR_ENTRY(mercury__fn__vector__angle_2_0));
MR_define_label(mercury__fn__vector__angle_2_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__vector__angle_2_0));
	MR_stackvar(3) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__vector__angle_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1096 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__angle_2_0_i20);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(3)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__angle_2_0_i7);
	}
MR_define_label(mercury__fn__vector__angle_2_0_i20);
	MR_r1 = MR_stackvar(3);
	MR_r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_stackvar(2)) / MR_word_to_float(MR_r1)));
	MR_r1 = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2)) * MR_word_to_float(MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2)))));
	MR_call_localret(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		mercury__fn__vector__angle_2_0_i10,
		MR_ENTRY(mercury__fn__vector__angle_2_0));
MR_define_label(mercury__fn__vector__angle_2_0_i7);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__vector__angle_2_0_i9,
		MR_ENTRY(mercury__fn__vector__angle_2_0));
MR_define_label(mercury__fn__vector__angle_2_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__vector__angle_2_0));
	MR_call_localret(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		mercury__fn__vector__angle_2_0_i10,
		MR_ENTRY(mercury__fn__vector__angle_2_0));
MR_define_label(mercury__fn__vector__angle_2_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__vector__angle_2_0));
	MR_stackvar(2) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__vector__angle_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1137 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__angle_2_0_i22);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(2)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__angle_2_0_i15);
	}
MR_define_label(mercury__fn__vector__angle_2_0_i22);
	MR_r1 = MR_stackvar(2);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(1)) / MR_word_to_float(MR_r1)));
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury__fn__math__acos_1_0),
		MR_ENTRY(mercury__fn__vector__angle_2_0));
MR_define_label(mercury__fn__vector__angle_2_0_i15);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__vector__angle_2_0_i17,
		MR_ENTRY(mercury__fn__vector__angle_2_0));
MR_define_label(mercury__fn__vector__angle_2_0_i17);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__vector__angle_2_0));
	MR_succip = (MR_Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	MR_tailcall(MR_ENTRY(mercury__fn__math__acos_1_0),
		MR_ENTRY(mercury__fn__vector__angle_2_0));
/* code for predicate 'project'/3 in mode 0 */
MR_define_entry(mercury__fn__vector__project_2_0);
	MR_incr_sp_push_msg(6, "vector:project/3");
	MR_stackvar(6) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r1 = MR_float_to_word((((MR_word_to_float(MR_stackvar(2)) * MR_word_to_float(MR_stackvar(2))) + (MR_word_to_float(MR_stackvar(3)) * MR_word_to_float(MR_stackvar(3)))) + (MR_word_to_float(MR_stackvar(4)) * MR_word_to_float(MR_stackvar(4)))));
	MR_call_localret(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		mercury__fn__vector__project_2_0_i2,
		MR_ENTRY(mercury__fn__vector__project_2_0));
MR_define_label(mercury__fn__vector__project_2_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__vector__project_2_0));
	MR_stackvar(5) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__vector__project_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1190 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i5);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(5)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i7);
	}
	MR_r1 = MR_stackvar(5);
	MR_stackvar(5) = MR_r1;
	MR_stackvar(2) = MR_float_to_word((MR_word_to_float(MR_stackvar(2)) / MR_word_to_float(MR_r1)));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__project_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1212 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i12);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(5)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i14);
	}
	MR_stackvar(3) = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / MR_word_to_float(MR_stackvar(5))));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__project_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1232 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(5)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__project_2_0, "vector:vector/0");
	MR_r2 = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) / MR_word_to_float(MR_stackvar(5))));
	MR_r3 = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0)) * MR_word_to_float(MR_stackvar(2))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1)) * MR_word_to_float(MR_stackvar(3)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2)) * MR_word_to_float(MR_r2))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_stackvar(2))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_stackvar(3))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r2)));
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury__fn__vector__project_2_0_i5);
	MR_r1 = MR_stackvar(5);
	MR_stackvar(5) = MR_r1;
	MR_stackvar(2) = MR_float_to_word((MR_word_to_float(MR_stackvar(2)) / MR_word_to_float(MR_r1)));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__project_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1264 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i12);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(5)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i14);
	}
	MR_stackvar(3) = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / MR_word_to_float(MR_stackvar(5))));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__project_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1284 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(5)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__project_2_0, "vector:vector/0");
	MR_r2 = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) / MR_word_to_float(MR_stackvar(5))));
	MR_r3 = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0)) * MR_word_to_float(MR_stackvar(2))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1)) * MR_word_to_float(MR_stackvar(3)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2)) * MR_word_to_float(MR_r2))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_stackvar(2))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_stackvar(3))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r2)));
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury__fn__vector__project_2_0_i7);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__vector__project_2_0_i9,
		MR_ENTRY(mercury__fn__vector__project_2_0));
MR_define_label(mercury__fn__vector__project_2_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__vector__project_2_0));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__project_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1320 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i12);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(5)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i14);
	}
	MR_stackvar(3) = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / MR_word_to_float(MR_stackvar(5))));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__project_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1340 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(5)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__project_2_0, "vector:vector/0");
	MR_r2 = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) / MR_word_to_float(MR_stackvar(5))));
	MR_r3 = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0)) * MR_word_to_float(MR_stackvar(2))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1)) * MR_word_to_float(MR_stackvar(3)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2)) * MR_word_to_float(MR_r2))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_stackvar(2))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_stackvar(3))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r2)));
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury__fn__vector__project_2_0_i12);
	MR_stackvar(3) = MR_float_to_word((MR_word_to_float(MR_stackvar(3)) / MR_word_to_float(MR_stackvar(5))));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__project_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1370 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(5)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i21);
	}
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__project_2_0, "vector:vector/0");
	MR_r2 = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) / MR_word_to_float(MR_stackvar(5))));
	MR_r3 = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0)) * MR_word_to_float(MR_stackvar(2))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1)) * MR_word_to_float(MR_stackvar(3)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2)) * MR_word_to_float(MR_r2))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_stackvar(2))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_stackvar(3))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r2)));
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury__fn__vector__project_2_0_i14);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_call_localret(MR_ENTRY(mercury__exception__throw_1_0),
		mercury__fn__vector__project_2_0_i16,
		MR_ENTRY(mercury__fn__vector__project_2_0));
MR_define_label(mercury__fn__vector__project_2_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__vector__project_2_0));
	{
#define	MR_PROC_LABEL	mercury__fn__vector__project_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 1406 "vector.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i41);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_stackvar(5)) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__vector__project_2_0_i21);
	}
MR_define_label(mercury__fn__vector__project_2_0_i41);
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__project_2_0, "vector:vector/0");
	MR_r2 = MR_float_to_word((MR_word_to_float(MR_stackvar(4)) / MR_word_to_float(MR_stackvar(5))));
	MR_r3 = MR_float_to_word((((MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 0)) * MR_word_to_float(MR_stackvar(2))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 1)) * MR_word_to_float(MR_stackvar(3)))) + (MR_word_to_float(MR_const_field(MR_mktag(0), MR_stackvar(1), (MR_Integer) 2)) * MR_word_to_float(MR_r2))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 0) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_stackvar(2))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 1) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_stackvar(3))));
	MR_field(MR_mktag(0), MR_r1, (MR_Integer) 2) = MR_float_to_word((MR_word_to_float(MR_r3) * MR_word_to_float(MR_r2)));
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
MR_define_label(mercury__fn__vector__project_2_0_i21);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_ENTRY(mercury__fn__vector__project_2_0));
/* code for predicate 'projectXY'/2 in mode 0 */
MR_define_entry(mercury__fn__vector__projectXY_1_0);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__projectXY_1_0, "vector:vector/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'projectXZ'/2 in mode 0 */
MR_define_entry(mercury__fn__vector__projectXZ_1_0);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__projectXZ_1_0, "vector:vector/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'projectZY'/2 in mode 0 */
MR_define_entry(mercury__fn__vector__projectZY_1_0);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 3, mercury__fn__vector__projectZY_1_0, "vector:vector/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'xy'/2 in mode 0 */
MR_define_entry(mercury__fn__vector__xy_1_0);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__fn__vector__xy_1_0, "std_util:pair/2");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'xz'/2 in mode 0 */
MR_define_entry(mercury__fn__vector__xz_1_0);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__fn__vector__xz_1_0, "std_util:pair/2");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'zy'/2 in mode 0 */
MR_define_entry(mercury__fn__vector__zy_1_0);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (MR_Integer) 2, mercury__fn__vector__zy_1_0, "std_util:pair/2");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_tempr1;
	MR_proceed();
	}
/* code for predicate 'zero'/1 in mode 0 */
MR_define_entry(mercury__fn__vector__zero_0_0);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_vector__common_0);
	MR_proceed();
/* code for predicate 'i'/1 in mode 0 */
MR_define_entry(mercury__fn__vector__i_0_0);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_vector__common_1);
	MR_proceed();
/* code for predicate 'j'/1 in mode 0 */
MR_define_entry(mercury__fn__vector__j_0_0);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_vector__common_2);
	MR_proceed();
/* code for predicate 'k'/1 in mode 0 */
MR_define_entry(mercury__fn__vector__k_0_0);
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_vector__common_3);
	MR_proceed();
/* code for predicate 'real_epsilon'/1 in mode 0 */
MR_define_entry(mercury__fn__vector__real_epsilon_0_0);
	{
	MR_Float	Eps;
#define	MR_PROC_LABEL	mercury__fn__vector__real_epsilon_0_0
{
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
Eps = ML_FLOAT_EPSILON;;}
#line 1524 "vector.c"
	MR_r1 = MR_float_to_word(Eps);
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'real_max'/1 in mode 0 */
MR_define_entry(mercury__fn__vector__real_max_0_0);
	{
	MR_Float	Max;
#define	MR_PROC_LABEL	mercury__fn__vector__real_max_0_0
{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
Max = ML_FLOAT_MAX;;}
#line 1538 "vector.c"
	MR_r1 = MR_float_to_word(Max);
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___vector__real_0_0);
	MR_r1 = (MR_word_to_float(MR_r1) == MR_word_to_float(MR_r2));
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___vector__real_0_0);
	if ((MR_word_to_float(MR_r1) >= MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury____Compare___vector__real_0_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury____Compare___vector__real_0_0_i2);
	if ((MR_word_to_float(MR_r1) <= MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury____Compare___vector__real_0_0_i3);
	}
	MR_r1 = (MR_Integer) 2;
	MR_proceed();
MR_define_label(mercury____Compare___vector__real_0_0_i3);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___vector__vector_0_0);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___vector__vector_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___vector__vector_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r1));
	MR_proceed();
	}
MR_define_label(mercury____Unify___vector__vector_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___vector__vector_0_0);
	MR_incr_sp_push_msg(4, "vector:__Compare__/3");
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	if ((MR_word_to_float(MR_r2) >= MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury____Compare___vector__vector_0_0_i4);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___vector__vector_0_0_i3);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___vector__vector_0_0_i4);
	if ((MR_word_to_float(MR_r2) <= MR_word_to_float(MR_r3))) {
		MR_GOTO_LABEL(mercury____Compare___vector__vector_0_0_i3);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___vector__vector_0_0_i3);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___vector__vector_0_0_i3);
	if ((MR_word_to_float(MR_stackvar(1)) >= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___vector__vector_0_0_i16);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___vector__vector_0_0_i15);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___vector__vector_0_0_i16);
	if ((MR_word_to_float(MR_stackvar(1)) <= MR_word_to_float(MR_stackvar(3)))) {
		MR_GOTO_LABEL(mercury____Compare___vector__vector_0_0_i15);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___vector__vector_0_0_i15);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___vector__vector_0_0_i15);
	if ((MR_word_to_float(MR_stackvar(2)) >= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___vector__vector_0_0_i26);
	}
	MR_r1 = (MR_Integer) 1;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___vector__vector_0_0_i26);
	if ((MR_word_to_float(MR_stackvar(2)) <= MR_word_to_float(MR_stackvar(4)))) {
		MR_GOTO_LABEL(mercury____Compare___vector__vector_0_0_i27);
	}
	MR_r1 = (MR_Integer) 2;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
MR_define_label(mercury____Compare___vector__vector_0_0_i27);
	MR_r1 = (MR_Integer) 0;
	MR_decr_sp_pop_msg(4);
	MR_proceed();
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___vector__position_0_0);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___vector__position_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___vector__position_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r1));
	MR_proceed();
	}
MR_define_label(mercury____Unify___vector__position_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___vector__position_0_0);
	MR_localtailcall(mercury____Compare___vector__vector_0_0,
		MR_ENTRY(mercury____Compare___vector__position_0_0));
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___vector__point_0_0);
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___vector__point_0_0_i1);
	}
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	if ((MR_word_to_float(MR_tempr1) != MR_word_to_float(MR_tempr2))) {
		MR_GOTO_LABEL(mercury____Unify___vector__point_0_0_i1);
	}
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_r1 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r1 = (MR_word_to_float(MR_r3) == MR_word_to_float(MR_r1));
	MR_proceed();
	}
MR_define_label(mercury____Unify___vector__point_0_0_i1);
	MR_r1 = FALSE;
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___vector__point_0_0);
	MR_localtailcall(mercury____Compare___vector__vector_0_0,
		MR_ENTRY(mercury____Compare___vector__point_0_0));
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__vector_maybe_bunch_0(void)
{
	vector_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__vector__init(void);
void mercury__vector__init_type_tables(void);
void mercury__vector__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__vector__write_out_proc_statics(FILE *fp);
#endif

void mercury__vector__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__vector_maybe_bunch_0();
#endif

	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_vector__type_ctor_info_vector_0,
		vector__vector_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_vector__type_ctor_info_real_0,
		vector__real_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_vector__type_ctor_info_position_0,
		vector__position_0_0);
	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_vector__type_ctor_info_point_0,
		vector__point_0_0);
	mercury__vector__init_debugger();
}

void mercury__vector__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
	MR_register_type_ctor_info(
		&mercury_data_vector__type_ctor_info_vector_0);
	MR_register_type_ctor_info(
		&mercury_data_vector__type_ctor_info_real_0);
	MR_register_type_ctor_info(
		&mercury_data_vector__type_ctor_info_position_0);
	MR_register_type_ctor_info(
		&mercury_data_vector__type_ctor_info_point_0);
}


void mercury__vector__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__vector__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
