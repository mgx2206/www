/*
** Automatically generated from `op.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__op__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "op.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "op.c"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"


	#include <math.h>

	/*
	** Mathematical constants.
	**
	** The maximum number of significant decimal digits which
	** can be packed into an IEEE-754 extended precision
	** floating point number is 18.  Therefore 20 significant
	** decimal digits for these constants should be plenty.
	*/

	#define	ML_FLOAT_E		2.7182818284590452354
	#define	ML_FLOAT_PI		3.1415926535897932384
	#define	ML_FLOAT_LN2		0.69314718055994530941


#line 52 "op.c"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#include <float.h>
	#include <math.h>


#line 60 "op.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#define	ML_FLOAT_RADIX	FLT_RADIX	/* There is no DBL_RADIX. */

	#if defined USE_SINGLE_PREC_FLOAT
		#define	ML_FLOAT_MAX		FLT_MAX
		#define	ML_FLOAT_MIN		FLT_MIN
		#define	ML_FLOAT_EPSILON	FLT_EPSILON
		#define	ML_FLOAT_MANT_DIG	FLT_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	FLT_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	FLT_MAX_EXP
	#else
		#define	ML_FLOAT_MAX		DBL_MAX
		#define	ML_FLOAT_MIN		DBL_MIN
		#define	ML_FLOAT_EPSILON	DBL_EPSILON
		#define	ML_FLOAT_MANT_DIG	DBL_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	DBL_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	DBL_MAX_EXP
	#endif


#line 83 "op.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 90 "op.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 93 "op.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 99 "op.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 107 "op.c"

MR_define_extern_entry(mercury__fn__op__op_acos_1_0);
MR_declare_label(mercury__fn__op__op_acos_1_0_i2);
MR_define_extern_entry(mercury__fn__op__op_addi_2_0);
MR_define_extern_entry(mercury__fn__op__op_addf_2_0);
MR_define_extern_entry(mercury__fn__op__op_asin_1_0);
MR_declare_label(mercury__fn__op__op_asin_1_0_i2);
MR_define_extern_entry(mercury__fn__op__op_clampf_1_0);
MR_declare_label(mercury__fn__op__op_clampf_1_0_i2);
MR_declare_label(mercury__fn__op__op_clampf_1_0_i5);
MR_define_extern_entry(mercury__fn__op__op_cos_1_0);
MR_declare_label(mercury__fn__op__op_cos_1_0_i2);
MR_define_extern_entry(mercury__fn__op__op_divi_2_0);
MR_declare_label(mercury__fn__op__op_divi_2_0_i10);
MR_declare_label(mercury__fn__op__op_divi_2_0_i6);
MR_define_extern_entry(mercury__fn__op__op_divf_2_0);
MR_declare_label(mercury__fn__op__op_divf_2_0_i10);
MR_declare_label(mercury__fn__op__op_divf_2_0_i6);
MR_define_extern_entry(mercury__fn__op__op_eqi_2_0);
MR_declare_label(mercury__fn__op__op_eqi_2_0_i2);
MR_define_extern_entry(mercury__fn__op__op_eqf_2_0);
MR_declare_label(mercury__fn__op__op_eqf_2_0_i2);
MR_define_extern_entry(mercury__fn__op__op_floor_1_0);
MR_define_extern_entry(mercury__fn__op__op_frac_1_0);
MR_declare_label(mercury__fn__op__op_frac_1_0_i2);
MR_define_extern_entry(mercury__fn__op__op_lessi_2_0);
MR_declare_label(mercury__fn__op__op_lessi_2_0_i2);
MR_define_extern_entry(mercury__fn__op__op_lessf_2_0);
MR_declare_label(mercury__fn__op__op_lessf_2_0_i2);
MR_define_extern_entry(mercury__fn__op__op_modi_2_0);
MR_define_extern_entry(mercury__fn__op__op_muli_2_0);
MR_define_extern_entry(mercury__fn__op__op_mulf_2_0);
MR_define_extern_entry(mercury__fn__op__op_negi_1_0);
MR_define_extern_entry(mercury__fn__op__op_negf_1_0);
MR_define_extern_entry(mercury__fn__op__op_real_1_0);
MR_define_extern_entry(mercury__fn__op__op_sin_1_0);
MR_declare_label(mercury__fn__op__op_sin_1_0_i2);
MR_define_extern_entry(mercury__fn__op__op_sqrt_1_0);
MR_define_extern_entry(mercury__fn__op__op_subi_2_0);
MR_define_extern_entry(mercury__fn__op__op_subf_2_0);
MR_define_extern_entry(mercury__fn__op__radians_1_0);
MR_declare_label(mercury__fn__op__radians_1_0_i11);
MR_declare_label(mercury__fn__op__radians_1_0_i6);
MR_define_extern_entry(mercury__fn__op__degrees_1_0);
MR_declare_label(mercury__fn__op__degrees_1_0_i11);
MR_declare_label(mercury__fn__op__degrees_1_0_i6);

MR_declare_entry(mercury__fn__math__acos_1_0);
MR_declare_entry(mercury__fn__math__asin_1_0);
static const MR_Float mercury_float_const_0pt00000000000000 = 0.00000000000000;
static const MR_Float mercury_float_const_1pt00000000000000 = 1.00000000000000;
extern const struct MR_TypeCtorInfo_Struct mercury_data_math__type_ctor_info_domain_error_0;
MR_declare_entry(mercury__exception__throw_1_0);
MR_declare_entry(mercury__fn__math__sqrt_1_0);
static const MR_Float mercury_float_const_180pt000000000000 = 180.000000000000;

MR_BEGIN_MODULE(op_module)
	MR_init_entry(mercury__fn__op__op_acos_1_0);
	MR_init_label(mercury__fn__op__op_acos_1_0_i2);
	MR_init_entry(mercury__fn__op__op_addi_2_0);
	MR_init_entry(mercury__fn__op__op_addf_2_0);
	MR_init_entry(mercury__fn__op__op_asin_1_0);
	MR_init_label(mercury__fn__op__op_asin_1_0_i2);
	MR_init_entry(mercury__fn__op__op_clampf_1_0);
	MR_init_label(mercury__fn__op__op_clampf_1_0_i2);
	MR_init_label(mercury__fn__op__op_clampf_1_0_i5);
	MR_init_entry(mercury__fn__op__op_cos_1_0);
	MR_init_label(mercury__fn__op__op_cos_1_0_i2);
	MR_init_entry(mercury__fn__op__op_divi_2_0);
	MR_init_label(mercury__fn__op__op_divi_2_0_i10);
	MR_init_label(mercury__fn__op__op_divi_2_0_i6);
	MR_init_entry(mercury__fn__op__op_divf_2_0);
	MR_init_label(mercury__fn__op__op_divf_2_0_i10);
	MR_init_label(mercury__fn__op__op_divf_2_0_i6);
	MR_init_entry(mercury__fn__op__op_eqi_2_0);
	MR_init_label(mercury__fn__op__op_eqi_2_0_i2);
	MR_init_entry(mercury__fn__op__op_eqf_2_0);
	MR_init_label(mercury__fn__op__op_eqf_2_0_i2);
	MR_init_entry(mercury__fn__op__op_floor_1_0);
	MR_init_entry(mercury__fn__op__op_frac_1_0);
	MR_init_label(mercury__fn__op__op_frac_1_0_i2);
	MR_init_entry(mercury__fn__op__op_lessi_2_0);
	MR_init_label(mercury__fn__op__op_lessi_2_0_i2);
	MR_init_entry(mercury__fn__op__op_lessf_2_0);
	MR_init_label(mercury__fn__op__op_lessf_2_0_i2);
	MR_init_entry(mercury__fn__op__op_modi_2_0);
	MR_init_entry(mercury__fn__op__op_muli_2_0);
	MR_init_entry(mercury__fn__op__op_mulf_2_0);
	MR_init_entry(mercury__fn__op__op_negi_1_0);
	MR_init_entry(mercury__fn__op__op_negf_1_0);
	MR_init_entry(mercury__fn__op__op_real_1_0);
	MR_init_entry(mercury__fn__op__op_sin_1_0);
	MR_init_label(mercury__fn__op__op_sin_1_0_i2);
	MR_init_entry(mercury__fn__op__op_sqrt_1_0);
	MR_init_entry(mercury__fn__op__op_subi_2_0);
	MR_init_entry(mercury__fn__op__op_subf_2_0);
	MR_init_entry(mercury__fn__op__radians_1_0);
	MR_init_label(mercury__fn__op__radians_1_0_i11);
	MR_init_label(mercury__fn__op__radians_1_0_i6);
	MR_init_entry(mercury__fn__op__degrees_1_0);
	MR_init_label(mercury__fn__op__degrees_1_0_i11);
	MR_init_label(mercury__fn__op__degrees_1_0_i6);
MR_BEGIN_CODE

/* code for predicate 'op_acos'/2 in mode 0 */
MR_define_entry(mercury__fn__op__op_acos_1_0);
	MR_incr_sp_push_msg(1, "op:op_acos/2");
	MR_stackvar(1) = (MR_Word) MR_succip;
	MR_call_localret(MR_ENTRY(mercury__fn__math__acos_1_0),
		mercury__fn__op__op_acos_1_0_i2,
		MR_ENTRY(mercury__fn__op__op_acos_1_0));
MR_define_label(mercury__fn__op__op_acos_1_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__op__op_acos_1_0));
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_localtailcall(mercury__fn__op__degrees_1_0,
		MR_ENTRY(mercury__fn__op__op_acos_1_0));
/* code for predicate 'op_addi'/3 in mode 0 */
MR_define_entry(mercury__fn__op__op_addi_2_0);
	MR_r1 = ((MR_Integer) MR_r1 + (MR_Integer) MR_r2);
	MR_proceed();
/* code for predicate 'op_addf'/3 in mode 0 */
MR_define_entry(mercury__fn__op__op_addf_2_0);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_r1) + MR_word_to_float(MR_r2)));
	MR_proceed();
/* code for predicate 'op_asin'/2 in mode 0 */
MR_define_entry(mercury__fn__op__op_asin_1_0);
	MR_incr_sp_push_msg(1, "op:op_asin/2");
	MR_stackvar(1) = (MR_Word) MR_succip;
	MR_call_localret(MR_ENTRY(mercury__fn__math__asin_1_0),
		mercury__fn__op__op_asin_1_0_i2,
		MR_ENTRY(mercury__fn__op__op_asin_1_0));
MR_define_label(mercury__fn__op__op_asin_1_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__op__op_asin_1_0));
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_localtailcall(mercury__fn__op__degrees_1_0,
		MR_ENTRY(mercury__fn__op__op_asin_1_0));
/* code for predicate 'op_clampf'/2 in mode 0 */
MR_define_entry(mercury__fn__op__op_clampf_1_0);
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__op__op_clampf_1_0_i2);
	}
	MR_r1 = (MR_Word) &mercury_float_const_0pt00000000000000;
	MR_proceed();
MR_define_label(mercury__fn__op__op_clampf_1_0_i2);
	if ((MR_word_to_float(MR_r1) <= (MR_Float) 1.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__op__op_clampf_1_0_i5);
	}
	MR_r1 = (MR_Word) &mercury_float_const_1pt00000000000000;
MR_define_label(mercury__fn__op__op_clampf_1_0_i5);
	MR_proceed();
/* code for predicate 'op_cos'/2 in mode 0 */
MR_define_entry(mercury__fn__op__op_cos_1_0);
	MR_incr_sp_push_msg(1, "op:op_cos/2");
	MR_stackvar(1) = (MR_Word) MR_succip;
	MR_localcall(mercury__fn__op__radians_1_0,
		MR_LABEL(mercury__fn__op__op_cos_1_0_i2),
		MR_ENTRY(mercury__fn__op__op_cos_1_0));
MR_define_label(mercury__fn__op__op_cos_1_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__op__op_cos_1_0));
	{
	MR_Float	X;
	MR_Float	Cos;
#define	MR_PROC_LABEL	mercury__fn__op__op_cos_1_0
	X = MR_word_to_float(MR_r1);
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);
;}
#line 279 "op.c"
	MR_r1 = MR_float_to_word(Cos);
#undef	MR_PROC_LABEL

	}
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
/* code for predicate 'op_divi'/3 in mode 0 */
MR_define_entry(mercury__fn__op__op_divi_2_0);
	MR_incr_sp_push_msg(3, "op:op_divi/3");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__op__op_divi_2_0
{
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 303 "op.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__op__op_divi_2_0_i10);
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__op__op_divi_2_0_i6);
	}
MR_define_label(mercury__fn__op__op_divi_2_0_i10);
	MR_stackvar(2) = MR_r2;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r1 = ((MR_Integer) MR_r1 / (MR_Integer) MR_r2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__fn__op__op_divi_2_0_i6);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("int:'//'", 8);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_ENTRY(mercury__fn__op__op_divi_2_0));
/* code for predicate 'op_divf'/3 in mode 0 */
MR_define_entry(mercury__fn__op__op_divf_2_0);
	MR_incr_sp_push_msg(3, "op:op_divf/3");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	{
#define	MR_PROC_LABEL	mercury__fn__op__op_divf_2_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 342 "op.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__op__op_divf_2_0_i10);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_r2) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__op__op_divf_2_0_i6);
	}
MR_define_label(mercury__fn__op__op_divf_2_0_i10);
	MR_stackvar(2) = MR_r2;
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_r1) / MR_word_to_float(MR_r2)));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__fn__op__op_divf_2_0_i6);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_ENTRY(mercury__fn__op__op_divf_2_0));
/* code for predicate 'op_eqi'/3 in mode 0 */
MR_define_entry(mercury__fn__op__op_eqi_2_0);
	if ((MR_r1 != MR_r2)) {
		MR_GOTO_LABEL(mercury__fn__op__op_eqi_2_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury__fn__op__op_eqi_2_0_i2);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
/* code for predicate 'op_eqf'/3 in mode 0 */
MR_define_entry(mercury__fn__op__op_eqf_2_0);
	if ((MR_word_to_float(MR_r1) != MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury__fn__op__op_eqf_2_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury__fn__op__op_eqf_2_0_i2);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
/* code for predicate 'op_floor'/2 in mode 0 */
MR_define_entry(mercury__fn__op__op_floor_1_0);
	{
	MR_Float	X;
	MR_Integer	Floor;
#define	MR_PROC_LABEL	mercury__fn__op__op_floor_1_0
	X = MR_word_to_float(MR_r1);
{
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

	Floor = (MR_Integer) floor(X);
;}
#line 397 "op.c"
	MR_r1 = Floor;
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'op_frac'/2 in mode 0 */
MR_define_entry(mercury__fn__op__op_frac_1_0);
	if ((MR_word_to_float(MR_r1) >= (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__op__op_frac_1_0_i2);
	}
	{
	MR_Float	Num;
	MR_Float	Ceil;
#define	MR_PROC_LABEL	mercury__fn__op__op_frac_1_0
	Num = MR_word_to_float(MR_r1);
{
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Ceil = ceil(Num);
;}
#line 418 "op.c"
	MR_r2 = MR_float_to_word(Ceil);
#undef	MR_PROC_LABEL

	}
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_r1) - MR_word_to_float(MR_r2)));
	MR_proceed();
MR_define_label(mercury__fn__op__op_frac_1_0_i2);
	{
	MR_Float	Num;
	MR_Float	Floor;
#define	MR_PROC_LABEL	mercury__fn__op__op_frac_1_0
	Num = MR_word_to_float(MR_r1);
{
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Floor = floor(Num);
;}
#line 436 "op.c"
	MR_r2 = MR_float_to_word(Floor);
#undef	MR_PROC_LABEL

	}
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_r1) - MR_word_to_float(MR_r2)));
	MR_proceed();
/* code for predicate 'op_lessi'/3 in mode 0 */
MR_define_entry(mercury__fn__op__op_lessi_2_0);
	if (((MR_Integer) MR_r1 >= (MR_Integer) MR_r2)) {
		MR_GOTO_LABEL(mercury__fn__op__op_lessi_2_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury__fn__op__op_lessi_2_0_i2);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
/* code for predicate 'op_lessf'/3 in mode 0 */
MR_define_entry(mercury__fn__op__op_lessf_2_0);
	if ((MR_word_to_float(MR_r1) >= MR_word_to_float(MR_r2))) {
		MR_GOTO_LABEL(mercury__fn__op__op_lessf_2_0_i2);
	}
	MR_r1 = (MR_Integer) 1;
	MR_proceed();
MR_define_label(mercury__fn__op__op_lessf_2_0_i2);
	MR_r1 = (MR_Integer) 0;
	MR_proceed();
/* code for predicate 'op_modi'/3 in mode 0 */
MR_define_entry(mercury__fn__op__op_modi_2_0);
	MR_r1 = ((MR_Integer) MR_r1 % (MR_Integer) MR_r2);
	MR_proceed();
/* code for predicate 'op_muli'/3 in mode 0 */
MR_define_entry(mercury__fn__op__op_muli_2_0);
	MR_r1 = ((MR_Integer) MR_r1 * (MR_Integer) MR_r2);
	MR_proceed();
/* code for predicate 'op_mulf'/3 in mode 0 */
MR_define_entry(mercury__fn__op__op_mulf_2_0);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_r2)));
	MR_proceed();
/* code for predicate 'op_negi'/2 in mode 0 */
MR_define_entry(mercury__fn__op__op_negi_1_0);
	MR_r1 = ((MR_Integer) 0 - (MR_Integer) MR_r1);
	MR_proceed();
/* code for predicate 'op_negf'/2 in mode 0 */
MR_define_entry(mercury__fn__op__op_negf_1_0);
	MR_r1 = MR_float_to_word(((MR_Float) 0.00000000000000 - MR_word_to_float(MR_r1)));
	MR_proceed();
/* code for predicate 'op_real'/2 in mode 0 */
MR_define_entry(mercury__fn__op__op_real_1_0);
	{
	MR_Integer	IntVal;
	MR_Float	FloatVal;
#define	MR_PROC_LABEL	mercury__fn__op__op_real_1_0
	IntVal = MR_r1;
	MR_OBTAIN_GLOBAL_LOCK("to_float");
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	FloatVal = IntVal;
;}
#line 496 "op.c"
	MR_RELEASE_GLOBAL_LOCK("to_float");
	MR_r1 = MR_float_to_word(FloatVal);
#undef	MR_PROC_LABEL

	}
	MR_proceed();
/* code for predicate 'op_sin'/2 in mode 0 */
MR_define_entry(mercury__fn__op__op_sin_1_0);
	MR_incr_sp_push_msg(1, "op:op_sin/2");
	MR_stackvar(1) = (MR_Word) MR_succip;
	MR_localcall(mercury__fn__op__radians_1_0,
		MR_LABEL(mercury__fn__op__op_sin_1_0_i2),
		MR_ENTRY(mercury__fn__op__op_sin_1_0));
MR_define_label(mercury__fn__op__op_sin_1_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__op__op_sin_1_0));
	{
	MR_Float	X;
	MR_Float	Sin;
#define	MR_PROC_LABEL	mercury__fn__op__op_sin_1_0
	X = MR_word_to_float(MR_r1);
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);
;}
#line 522 "op.c"
	MR_r1 = MR_float_to_word(Sin);
#undef	MR_PROC_LABEL

	}
	MR_succip = (MR_Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	MR_proceed();
/* code for predicate 'op_sqrt'/2 in mode 0 */
MR_define_entry(mercury__fn__op__op_sqrt_1_0);
	MR_tailcall(MR_ENTRY(mercury__fn__math__sqrt_1_0),
		MR_ENTRY(mercury__fn__op__op_sqrt_1_0));
/* code for predicate 'op_subi'/3 in mode 0 */
MR_define_entry(mercury__fn__op__op_subi_2_0);
	MR_r1 = ((MR_Integer) MR_r1 - (MR_Integer) MR_r2);
	MR_proceed();
/* code for predicate 'op_subf'/3 in mode 0 */
MR_define_entry(mercury__fn__op__op_subf_2_0);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_r1) - MR_word_to_float(MR_r2)));
	MR_proceed();
/* code for predicate 'radians'/2 in mode 0 */
MR_define_entry(mercury__fn__op__radians_1_0);
	{
	MR_Float	Pi;
#define	MR_PROC_LABEL	mercury__fn__op__radians_1_0
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;
;}
#line 552 "op.c"
	MR_r3 = MR_float_to_word(Pi);
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(2, "op:radians/2");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_r1) * MR_word_to_float(MR_r3)));
	{
#define	MR_PROC_LABEL	mercury__fn__op__radians_1_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 571 "op.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__op__radians_1_0_i11);
#undef	MR_PROC_LABEL

	}
	if (((MR_Float) 180.000000000000 == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__op__radians_1_0_i6);
	}
MR_define_label(mercury__fn__op__radians_1_0_i11);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(1)) / (MR_Float) 180.000000000000));
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
MR_define_label(mercury__fn__op__radians_1_0_i6);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_ENTRY(mercury__fn__op__radians_1_0));
/* code for predicate 'degrees'/2 in mode 0 */
MR_define_entry(mercury__fn__op__degrees_1_0);
	{
	MR_Float	Pi;
#define	MR_PROC_LABEL	mercury__fn__op__degrees_1_0
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;
;}
#line 601 "op.c"
	MR_r3 = MR_float_to_word(Pi);
#undef	MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(3, "op:degrees/2");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_float_to_word((MR_word_to_float(MR_r1) * (MR_Float) 180.000000000000));
	{
#define	MR_PROC_LABEL	mercury__fn__op__degrees_1_0
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif
;}
#line 620 "op.c"
if (!MR_r1) MR_GOTO_LABEL(mercury__fn__op__degrees_1_0_i11);
#undef	MR_PROC_LABEL

	}
	if ((MR_word_to_float(MR_r3) == (MR_Float) 0.00000000000000)) {
		MR_GOTO_LABEL(mercury__fn__op__degrees_1_0_i6);
	}
MR_define_label(mercury__fn__op__degrees_1_0_i11);
	MR_r1 = MR_float_to_word((MR_word_to_float(MR_stackvar(1)) / MR_word_to_float(MR_r3)));
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__fn__op__degrees_1_0_i6);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_math__type_ctor_info_domain_error_0;
	MR_r2 = (MR_Word) MR_string_const("float:'/'", 9);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury__exception__throw_1_0),
		MR_ENTRY(mercury__fn__op__degrees_1_0));
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__op_maybe_bunch_0(void)
{
	op_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__op__init(void);
void mercury__op__init_type_tables(void);
void mercury__op__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__op__write_out_proc_statics(FILE *fp);
#endif

void mercury__op__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__op_maybe_bunch_0();
#endif

	mercury__op__init_debugger();
}

void mercury__op__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}


void mercury__op__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__op__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
