/*
** Automatically generated from `eval_util.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__eval_util__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "eval_util.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "eval_util.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#include <string.h>
#include <stdio.h>

#include "mercury_string.h"	/* for MR_allocate_aligned_string*() etc. */
#include "mercury_tags.h"	/* for MR_list_cons*() */

#line 41 "eval_util.c"
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#ifdef USE_GCC_GLOBAL_REGISTERS
	/*
	** GNU C version egcs-1.1.2 crashes with `fixed or forbidden
	** register spilled' in grade asm_fast.gc.tr.debug
	** if we write this inline.
	*/
	static void MR_set_char(MR_String str, MR_Integer ind, MR_Char ch)
	{
		str[ind] = ch;
	}
#else
	#define MR_set_char(str, ind, ch) \
		((str)[ind] = (ch))
#endif

#line 59 "eval_util.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_DETERMINISM_GUARD
#define ML_DETERMINISM_GUARD
	/*
	** The enumeration constants in this enum must be in the same
	** order as the functors in the Mercury type `determinism'
	** defined above.
	*/
	typedef enum {
		ML_DET,
		ML_SEMIDET,
		ML_CC_MULTI,
		ML_CC_NONDET,
		ML_MULTI,
		ML_NONDET,
		ML_ERRONEOUS,
		ML_FAILURE
	} ML_Determinism;
#endif

#line 82 "eval_util.c"
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* protect against multiple inclusion */
#ifndef MR_HLC_EXCEPTION_GUARD
#define MR_HLC_EXCEPTION_GUARD

#ifdef MR_HIGHLEVEL_CODE

  #ifdef MR_USE_GCC_NESTED_FUNCTIONS
  	#define MR_CONT_PARAMS		MR_NestedCont cont
  	#define MR_CONT_PARAM_TYPES	MR_NestedCont
  	#define MR_CONT_ARGS		cont
  #else
  	#define MR_CONT_PARAMS		MR_Cont cont, void *cont_env
  	#define MR_CONT_PARAM_TYPES	MR_Cont, void *
  	#define MR_CONT_ARGS		cont, cont_env
  #endif

	/* det */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_0(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* semidet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_1(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_2(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_nondet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_3(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_4(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

	/* nondet */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_5(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

  #ifndef MR_AVOID_MACROS

	/* det ==> model_det */
	#define mercury__exception__builtin_catch_3_p_0 		mercury__exception__builtin_catch_model_det

	/* semidet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_1 		mercury__exception__builtin_catch_model_semi

	/* cc_multi ==> model_det */
	#define mercury__exception__builtin_catch_3_p_2 		mercury__exception__builtin_catch_model_det

	/* cc_nondet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_3 		mercury__exception__builtin_catch_model_semi

	/* multi ==> model_non */
	#define mercury__exception__builtin_catch_3_p_4 		mercury__exception__builtin_catch_model_non

	/* nondet ==> model_non */
	#define mercury__exception__builtin_catch_3_p_5 		mercury__exception__builtin_catch_model_non

  #endif /* !MR_AVOID_MACROS */

	void MR_CALL mercury__exception__builtin_throw_1_p_0(MR_Univ exception);

	void MR_CALL mercury__exception__builtin_catch_model_det(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	bool MR_CALL mercury__exception__builtin_catch_model_semi(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	void MR_CALL mercury__exception__builtin_catch_model_non(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

#endif /* MR_HIGHLEVEL_CODE */

#endif /* MR_HLC_EXCEPTION_GUARD */

#line 172 "eval_util.c"
#line 147 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

#ifndef MR_HIGHLEVEL_CODE
	#include <assert.h>
	#include <stdio.h>
	#include "mercury_deep_copy.h"
	#include "mercury_trace_base.h"
	#include "mercury_stack_trace.h"
	#include "mercury_layout_util.h"
	#include "mercury_deep_profiling_hand.h"

	MR_DECLARE_TYPE_CTOR_INFO_STRUCT( 			mercury_data_std_util__type_ctor_info_univ_0);
#endif

#line 187 "eval_util.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 194 "eval_util.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


#include "mercury_deep_copy.h"

#ifdef CONSERVATIVE_GC
  /* for conservative GC, shallow copies suffice */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		NewVal = OldVal;					\
	} while (0)
#else
  /*
  ** Note that we need to save/restore the MR_hp register, if it
  ** is transient, before/after calling MR_deep_copy().
  */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		MR_save_transient_hp();					\
		NewVal = MR_deep_copy(&OldVal, (MR_TypeInfo) TypeInfo_for_T,\
				(const MR_Word *) SolutionsHeapPtr,	\
				MR_ENGINE(MR_eng_solutions_heap_zone)->top);\
		MR_restore_transient_hp();				\
	} while (0)
#endif


#line 224 "eval_util.c"
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"

#include "mercury_heap.h"	/* for MR_incr_hp_msg() etc. */
#include "mercury_misc.h"	/* for MR_fatal_error() */
#include "mercury_string.h"	/* for MR_make_aligned_string() */

#line 231 "eval_util.c"
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_TYPECTORDESC_GUARD
#define ML_TYPECTORDESC_GUARD

/*
** Values of type `std_util:type_desc' are represented the same way as
** values of type `private_builtin:type_info' (this representation is
** documented in compiler/polymorphism.m). Some parts of the library
** (e.g. the gc initialization code) depend on this.
** The C type corresponding to these Mercury types is `MR_TypeInfo'.
**
** Values of type `std_util:type_ctor_desc' are not guaranteed to be
** represented the same way as values of type `private_builtin:type_ctor_info'.
** The representations *are* in fact identical for first order types, but they
** differ for higher order and tuple types. Instead of a type_ctor_desc
** being a structure containing a pointer to the type_ctor_info for pred/0
** or func/0 and an arity, we have a single small encoded integer. This
** integer is four times the arity, plus zero, one or two; plus zero encodes a
** tuple, plus one encodes a predicate, plus two encodes a function.
** The maximum arity that can be encoded is given by MR_MAX_VARIABLE_ARITY
** (see below).
** The C type corresponding to std_util:type_ctor_desc is `MR_TypeCtorDesc'.
*/

/*
** Declare the MR_TypeCtorDesc ADT.
**
** Note that `struct MR_TypeCtorDesc_Struct' is deliberately left undefined.
** MR_TypeCtorDesc is declared as a pointer to a dummy structure only
** in order to allow the C compiler to catch errors in which things other
** than MR_TypeCtorDescs are given as arguments to macros that depend on their
** arguments being MR_TypeCtorDescs. The actual value is either a small integer
** or a pointer to a MR_TypeCtorInfo_Struct structure, as described above.
*/
typedef struct MR_TypeCtorDesc_Struct *MR_TypeCtorDesc;

/*
** The maximum arity that can be encoded should be set to twice the maximum
** number of general purpose registers, since an predicate or function having
** more arguments that this would run out of registers when passing the input
** arguments, or the output arguments, or both.
**
** XXX When tuples were added this was reduced to be the maximum number
** of general purpose registers, to reduce the probability that the
** `small' integers for higher-order and tuple types are confused with
** type_ctor_info pointers. This still allows higher-order terms with
** 1024 arguments, which is more than ../LIMITATIONS promises.
*/
#define MR_MAX_VARIABLE_ARITY         MR_MAX_VIRTUAL_REG

/*
** Constructors for the MR_TypeCtorDesc ADT
*/

#define MR_TYPECTOR_DESC_MAKE_PRED(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4) )
#define MR_TYPECTOR_DESC_MAKE_FUNC(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4 + 1) )
#define MR_TYPECTOR_DESC_MAKE_TUPLE(Arity)                                      ( (MR_TypeCtorDesc) ((Arity) * 4 + 2) )
#define MR_TYPECTOR_DESC_MAKE_FIXED_ARITY(type_ctor_info)                       ( MR_CHECK_EXPR_TYPE(type_ctor_info, MR_TypeCtorInfo),                    (MR_TypeCtorDesc) type_ctor_info )

/*
** Access macros for the MR_TypeCtor ADT.
**
** The MR_TYPECTOR_DESC_GET_VA_* macros should only be called if
** MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns true.
** The MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO() macro
** should only be called if MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns false.
*/
#define MR_TYPECTOR_DESC_IS_VARIABLE_ARITY(T)                                   ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) <= (4 * MR_MAX_VARIABLE_ARITY + 2) )
#define MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO(T)                      ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_TypeCtorInfo) (T) )
#define MR_TYPECTOR_DESC_GET_VA_ARITY(T)                                        ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) / 4 )
#define MR_TYPECTOR_DESC_GET_VA_NAME(T)                                         ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) (((MR_Unsigned) (T) % 4 == 0)                                ? "pred"                                                              : (((MR_Unsigned) (T) % 4 == 1)                                             ? "func"                                                              : "{}" )) )
#define MR_TYPECTOR_DESC_GET_VA_MODULE_NAME(T)                                  ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) "builtin" )
#define MR_TYPECTOR_DESC_GET_VA_TYPE_CTOR_INFO(T)                               ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 ((MR_Unsigned) (T) % 4 == 0)                                                  ? MR_TYPE_CTOR_INFO_HO_PRED                                             : (((MR_Unsigned) (T) % 4 == 1)                                            ? MR_TYPE_CTOR_INFO_HO_FUNC                                             : MR_TYPE_CTOR_INFO_TUPLE ) )

#endif /* ML_TYPECTORDESC_GUARD */


#line 312 "eval_util.c"
#line 126 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_CONSTRUCT_INFO_GUARD
#define ML_CONSTRUCT_INFO_GUARD

typedef struct ML_Construct_Info_Struct {
    MR_ConstString          functor_name;
    MR_Integer              arity;
    const MR_PseudoTypeInfo *arg_pseudo_type_infos;
    MR_ConstString          *arg_names;
    MR_TypeCtorRep          type_ctor_rep;
    union {
        const MR_EnumFunctorDesc  *enum_functor_desc;
        const MR_NotagFunctorDesc *notag_functor_desc;
        const MR_DuFunctorDesc    *du_functor_desc;
    }                       functor_info;
} ML_Construct_Info;

#endif

extern  void            ML_type_ctor_and_args(MR_TypeInfo type_info,
                            bool collapse_equivalences,
                            MR_TypeCtorDesc *type_ctor_desc_ptr,
                            MR_Word *arg_type_info_list_ptr);
extern  int     	    ML_get_num_functors(MR_TypeInfo type_info);
extern	MR_Word		    ML_type_params_vector_to_list(int arity,
                            MR_TypeInfoParams type_params);
extern	MR_Word		    ML_arg_name_vector_to_list(int arity,
                            MR_ConstString *arg_names);
extern	MR_Word		    ML_pseudo_type_info_vector_to_type_info_list(int arity,
                            MR_TypeInfoParams type_params,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  bool    	    ML_get_functors_check_range(int functor_number,
                            MR_TypeInfo type_info,
                            ML_Construct_Info *construct_info);
extern  void    	    ML_copy_arguments_from_list_to_vector(int arity,
                            MR_Word arg_list, MR_Word term_vector);
extern  bool    	    ML_typecheck_arguments(MR_TypeInfo type_info,
                            int arity, MR_Word arg_list,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  MR_TypeInfo	    ML_make_type(int arity, MR_TypeCtorDesc type_ctor_desc,
				             MR_Word arg_type_list);

#line 358 "eval_util.c"
#line 170 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


extern	MR_TypeCtorDesc ML_make_type_ctor_desc(MR_TypeInfo type_info,
				MR_TypeCtorInfo type_ctor_info);


#line 366 "eval_util.c"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


    #include <stdio.h>
	#include "mercury_library_types.h"		/* for MR_ArrayType */

#ifdef MR_DEEP_PROFILING
    #include "mercury_deep_profiling.h"
#endif

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef	ML_EXPAND_INFO_GUARD
#define	ML_EXPAND_INFO_GUARD

typedef struct {
    int                     num_extra_args;
    MR_Word                 *arg_values;
    MR_TypeInfo             *arg_type_infos;
    bool                    can_free_arg_type_infos;
} ML_Expand_Args_Fields;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
} ML_Expand_Functor_Args_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
    bool                    limit_reached;
} ML_Expand_Functor_Args_Limit_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor_only;
} ML_Expand_Functor_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    ML_Expand_Args_Fields   args_only;
} ML_Expand_Args_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    bool                    chosen_index_exists;
    MR_Word                 *chosen_value_ptr;
    MR_TypeInfo             chosen_type_info;
} ML_Expand_Chosen_Arg_Only_Info;

    /* Prototypes */

extern  void    ML_expand_functor_args(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Args_Info *expand_info);

extern  void    ML_expand_functor_args_limit(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int max_arity,
                    ML_Expand_Functor_Args_Limit_Info *expand_info);

extern  void    ML_expand_functor_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Only_Info *expand_info);

extern  void    ML_expand_args_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Args_Only_Info *expand_info);

extern  void    ML_expand_chosen_arg_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int chosen,
                    ML_Expand_Chosen_Arg_Only_Info *expand_info);

    /*
    ** NB. ML_arg() is also used by arg_ref and new_arg_ref
    ** in store.m, in trace/mercury_trace_vars.m, and in
    ** extras/trailed_update/tr_store.m.
    */
extern  bool    ML_arg(MR_TypeInfo type_info, MR_Word *term, int arg_index,
                    MR_TypeInfo *arg_type_info_ptr, MR_Word **argument_ptr);

    /*
    ** NB. ML_named_arg_num() is used in mercury_trace_vars.c.
    */
extern  bool    ML_named_arg_num(MR_TypeInfo type_info, MR_Word *term_ptr,
                    const char *arg_name, int *arg_num_ptr);

/*
** The following macros factor out the common parts of the various
** deconstruction predicates.
*/

    /*
    ** Check for attempts to deconstruct a non-canonical type.
    ** Such deconstructions must be cc_multi, which is why we treat
    ** violations of this as runtime errors in det deconstruction
    ** predicates.
    ** (There ought to be cc_multi versions of those predicates.)
    */
#define ML_abort_if_type_is_noncanonical(ei, predname)                  do {                                                                    if ((ei).non_canonical_type) {                                          MR_fatal_error("called " predname " for a type "                    "with a user-defined equality predicate");                }                                                               } while (0)

#endif

#define ML_deconstruct_get_functor(ei, functor_field, var)              do {                                                                    MR_make_aligned_string(MR_LVALUE_CAST(MR_ConstString, var),             (ei).functor_field);                                        } while (0)

#define ML_deconstruct_get_arity(ei, var)                               do {                                                                    var = (ei).arity;                                               } while (0)

#define ML_deconstruct_get_arg_list(ei, args_field, var)                do {                                                                    int     i;                                                                                                                              var = MR_list_empty_msg(MR_PROC_LABEL);                             i = (ei).arity;                                                                                                                         while (--i >= 0) {                                                      MR_Word arg;                                                                                                                                /* Create an argument on the heap */                            MR_new_univ_on_hp(arg,                                                  (ei).args_field.arg_type_infos[i],                                  (ei).args_field.arg_values[i +                                          (ei).args_field.num_extra_args]);                                                                                                   /* Join the argument to the front of the list */                var = MR_list_cons_msg(arg, var, MR_PROC_LABEL);                }                                                               } while (0)

    /*
    ** Free any arg_type_infos allocated by the ML_expand variant.
    ** Should be called after we have used them for the last time.
    */
#define ML_deconstruct_free_allocated_arg_type_infos(ei, args_field)    do {                                                                    if ((ei).args_field.can_free_arg_type_infos) {                          MR_GC_free((ei).args_field.arg_type_infos);                     }                                                               } while (0)


#line 488 "eval_util.c"
#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	extern MR_Word		ML_io_stream_names;
	extern MR_Word		ML_io_user_globals;
	#if 0
	  extern MR_Word	ML_io_ops_table;
	#endif

#line 497 "eval_util.c"
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
#ifdef HAVE_SYS_STAT_H
	#include <sys/stat.h>
#endif

#line 507 "eval_util.c"
#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include "mercury_init.h"
#include "mercury_wrapper.h"
#include "mercury_type_info.h"
#include "mercury_library_types.h"
#include "mercury_file.h"
#include "mercury_heap.h"
#include "mercury_misc.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

#ifdef HAVE_SYS_WAIT
  #include <sys/wait.h>		/* for WIFEXITED, WEXITSTATUS, etc. */
#endif

extern MercuryFile mercury_stdin;
extern MercuryFile mercury_stdout;
extern MercuryFile mercury_stderr;
extern MercuryFile mercury_stdin_binary;
extern MercuryFile mercury_stdout_binary;
extern MercuryFile *mercury_current_text_input;
extern MercuryFile *mercury_current_text_output;
extern MercuryFile *mercury_current_binary_input;
extern MercuryFile *mercury_current_binary_output;

#define initial_io_state()		0	/* some random number */
#define update_io(r_src, r_dest)	((r_dest) = (r_src))
#define final_io_state(r)		((void)0)

void 		mercury_init_io(void);
MercuryFile*	mercury_open(const char *filename, const char *type);
void		mercury_io_error(MercuryFile* mf, const char *format, ...);
void		mercury_output_error(MercuryFile* mf);
void		mercury_print_string(MercuryFile* mf, const char *s);
void		mercury_print_binary_string(MercuryFile* mf, const char *s);
int		mercury_getc(MercuryFile* mf);
void		mercury_close(MercuryFile* mf);
int		ML_fprintf(MercuryFile* mf, const char *format, ...);

#line 553 "eval_util.c"
#line 106 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <fcntl.h>

	#define	MAX_TEMPNAME_TRIES	(6 * 4)

	extern long ML_io_tempnam_counter;

#line 567 "eval_util.c"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include <string.h>
#include <errno.h>

/*
** ML_maybe_make_err_msg(was_error, msg, procname, error_msg):
**	if `was_error' is true, then append `msg' and `strerror(errno)'
**	to give `error_msg'; otherwise, set `error_msg' to NULL.
**
** WARNING: this must only be called when the `hp' register is valid.
** That means it must only be called from procedures declared
** `will_not_call_mercury'.
**
** This is defined as a macro rather than a C function
** to avoid worrying about the `hp' register being
** invalidated by the function call.
** It also needs to be a macro because MR_incr_hp_atomic_msg()
** stringizes the procname argument.
*/
#define ML_maybe_make_err_msg(was_error, msg, procname, error_msg)	\
	do {								\
		char *errno_msg;					\
		size_t total_len;					\
		MR_Word tmp;						\
									\
		if (was_error) {					\
			errno_msg = strerror(errno);			\
			total_len = strlen(msg) + strlen(errno_msg);	\
			MR_incr_hp_atomic_msg(tmp,			\
				(total_len + sizeof(MR_Word))		\
					/ sizeof(MR_Word),		\
				procname,				\
				"string:string/0");			\
			(error_msg) = (char *)tmp;			\
			strcpy((error_msg), msg);			\
			strcat((error_msg), errno_msg);			\
		} else {						\
			(error_msg) = NULL;				\
		}							\
	} while(0)


#line 612 "eval_util.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 615 "eval_util.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 621 "eval_util.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 629 "eval_util.c"


static const struct mercury_data_eval_util__common_0_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Integer f3;
	MR_Word * f4;
	MR_Word * f5;
	MR_Word * f6;
	MR_Word * f7;
}  mercury_data_eval_util__common_0;

static const struct mercury_data_eval_util__common_1_struct {
	MR_Word * f1;
	MR_Code * f2;
	MR_Integer f3;
}  mercury_data_eval_util__common_1;
static const MR_User_Closure_Id
mercury_data__closure_layout__mercury__eval_util__write_env_3_0_1;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval_util__type_ctor_info_unequal_stacks_exception_0;
extern const MR_DuFunctorDesc * mercury_data_eval_util__du_name_ordered_unequal_stacks_exception_0[];
static const MR_DuFunctorDesc mercury_data_eval_util__du_functor_desc_unequal_stacks_exception_0_0;
extern const MR_PseudoTypeInfo mercury_data_eval_util__field_types_unequal_stacks_exception_0_0[];
#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_13_eval__value_0;
extern const MR_DuPtagLayout mercury_data_eval_util__du_ptag_ordered_unequal_stacks_exception_0[];
extern const MR_DuFunctorDesc * mercury_data_eval_util__du_stag_ordered_unequal_stacks_exception_0_0[];
MR_declare_static(mercury__eval_util__list__foldl__ho10_4_0);
MR_declare_label(mercury__eval_util__list__foldl__ho10_4_0_i13);
MR_declare_label(mercury__eval_util__list__foldl__ho10_4_0_i3);
MR_declare_static(mercury__eval_util__list__foldl__ho5_4_0);
MR_declare_label(mercury__eval_util__list__foldl__ho5_4_0_i4);
MR_declare_label(mercury__eval_util__list__foldl__ho5_4_0_i3);
MR_define_extern_entry(mercury__eval_util__write_env_3_0);
MR_define_extern_entry(mercury__eval_util__write_stack_3_0);
MR_define_extern_entry(mercury__eval_util__write_nice_exception_3_0);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i2);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i3);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i5);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i7);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i8);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i9);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i10);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i11);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i12);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i4);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i15);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i17);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i18);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i19);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i20);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i14);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i23);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i25);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i26);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i27);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i28);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i29);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i30);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i22);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i33);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i35);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i32);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i38);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i37);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i42);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i45);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i41);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i48);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i51);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i52);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i53);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i47);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i56);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i58);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i55);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i68);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i69);
MR_declare_label(mercury__eval_util__write_nice_exception_3_0_i70);
MR_define_extern_entry(mercury__eval_util__write_prog_4_0);
MR_declare_label(mercury__eval_util__write_prog_4_0_i4);
MR_declare_label(mercury__eval_util__write_prog_4_0_i3);
MR_define_extern_entry(mercury__eval_util__write_env_entry_4_0);
MR_declare_label(mercury__eval_util__write_env_entry_4_0_i2);
MR_declare_label(mercury__eval_util__write_env_entry_4_0_i3);
MR_declare_label(mercury__eval_util__write_env_entry_4_0_i4);
MR_define_extern_entry(mercury__eval_util__write_stack_entry_3_0);
MR_declare_label(mercury__eval_util__write_stack_entry_3_0_i2);
MR_declare_label(mercury__eval_util__write_stack_entry_3_0_i3);
MR_declare_label(mercury__eval_util__write_stack_entry_3_0_i4);
MR_define_extern_entry(mercury__eval_util__write_group_4_0);
MR_declare_label(mercury__eval_util__write_group_4_0_i12);
MR_declare_label(mercury__eval_util__write_group_4_0_i13);
MR_declare_label(mercury__eval_util__write_group_4_0_i14);
MR_declare_label(mercury__eval_util__write_group_4_0_i8);
MR_declare_label(mercury__eval_util__write_group_4_0_i9);
MR_declare_label(mercury__eval_util__write_group_4_0_i10);
MR_declare_label(mercury__eval_util__write_group_4_0_i11);
MR_declare_label(mercury__eval_util__write_group_4_0_i4);
MR_declare_label(mercury__eval_util__write_group_4_0_i5);
MR_declare_label(mercury__eval_util__write_group_4_0_i6);
MR_declare_label(mercury__eval_util__write_group_4_0_i7);
MR_declare_static(mercury__eval_util__indent_3_0);
MR_declare_label(mercury__eval_util__indent_3_0_i2);
MR_define_extern_entry(mercury____Unify___eval_util__unequal_stacks_exception_0_0);
MR_declare_label(mercury____Unify___eval_util__unequal_stacks_exception_0_0_i2);
MR_declare_label(mercury____Unify___eval_util__unequal_stacks_exception_0_0_i1);
MR_define_extern_entry(mercury____Compare___eval_util__unequal_stacks_exception_0_0);
MR_declare_label(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i4);
MR_declare_label(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i3);
MR_declare_label(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i16);
MR_declare_label(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i21);

extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_string_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_value_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_eval_util__common_0_struct mercury_data_eval_util__common_0 = {
	(MR_Word *) &mercury_data__closure_layout__mercury__eval_util__write_env_3_0_1,
	0,
	4,
	(MR_Word *) &mercury_data___type_ctor_info_string_0,
	(MR_Word *) &mercury_data_eval__type_ctor_info_value_0,
	(MR_Word *) &mercury_data_io__type_ctor_info_state_0,
	(MR_Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_eval_util__common_1_struct mercury_data_eval_util__common_1 = {
	MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_eval_util__common_0),
	MR_ENTRY(mercury__eval_util__write_env_entry_4_0),
	(MR_Integer) 0
};

static const MR_User_Closure_Id
mercury_data__closure_layout__mercury__eval_util__write_env_3_0_1 = {
	{
	MR_PREDICATE,
	"eval_util",
	"eval_util",
	"write_env_entry",
	4,
	0
	},
	"eval_util",
	"",
	0,
	""
};
extern const MR_DuFunctorDesc * mercury_data_eval_util__du_name_ordered_unequal_stacks_exception_0[];
extern const MR_DuPtagLayout mercury_data_eval_util__du_ptag_ordered_unequal_stacks_exception_0[];

const struct MR_TypeCtorInfo_Struct mercury_data_eval_util__type_ctor_info_unequal_stacks_exception_0 = {
	0,
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval_util__unequal_stacks_exception_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Unify___eval_util__unequal_stacks_exception_0_0)),
	MR_MAYBE_STATIC_CODE(MR_ENTRY(mercury____Compare___eval_util__unequal_stacks_exception_0_0)),
	MR_TYPECTOR_REP_DU,
	NULL,
	NULL,
	"eval_util",
	"unequal_stacks_exception",
	4,
	{ (void *) mercury_data_eval_util__du_name_ordered_unequal_stacks_exception_0 },
	{ (void *) mercury_data_eval_util__du_ptag_ordered_unequal_stacks_exception_0 },
	1,
	1
};

const MR_DuFunctorDesc * mercury_data_eval_util__du_name_ordered_unequal_stacks_exception_0[] = {
	&mercury_data_eval_util__du_functor_desc_unequal_stacks_exception_0_0
};

static const MR_DuFunctorDesc mercury_data_eval_util__du_functor_desc_unequal_stacks_exception_0_0 = {
	"unequal_stacks_exception",
	3,
	0,
	MR_SECTAG_NONE,
	0,
	0,
	0,
	(MR_PseudoTypeInfo *) mercury_data_eval_util__field_types_unequal_stacks_exception_0_0,
	NULL,
	NULL
};

const MR_PseudoTypeInfo mercury_data_eval_util__field_types_unequal_stacks_exception_0_0[] = {
	(MR_PseudoTypeInfo) &mercury_data___type_ctor_info_string_0,
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_13_eval__value_0,
	(MR_PseudoTypeInfo) &mercury_data_list__type_info_list_1__type0_13_eval__value_0
};
extern const struct MR_TypeCtorInfo_Struct mercury_data_list__type_ctor_info_list_1;

#ifndef MR_FO_PseudoTypeInfo_Struct1_GUARD
#define MR_FO_PseudoTypeInfo_Struct1_GUARD
MR_FIRST_ORDER_PSEUDOTYPEINFO_STRUCT(MR_FO_PseudoTypeInfo_Struct1, 1);
#endif
static const struct MR_FO_PseudoTypeInfo_Struct1 mercury_data_list__type_info_list_1__type0_13_eval__value_0 = {
	&mercury_data_list__type_ctor_info_list_1,
{	(MR_PseudoTypeInfo) &mercury_data_eval__type_ctor_info_value_0
}};

const MR_DuPtagLayout mercury_data_eval_util__du_ptag_ordered_unequal_stacks_exception_0[] = {
	{ 1, MR_SECTAG_NONE,
	mercury_data_eval_util__du_stag_ordered_unequal_stacks_exception_0_0 }

};

const MR_DuFunctorDesc * mercury_data_eval_util__du_stag_ordered_unequal_stacks_exception_0_0[] = {
	&mercury_data_eval_util__du_functor_desc_unequal_stacks_exception_0_0

};

extern const struct MR_TypeCtorInfo_Struct mercury_data___type_ctor_info_string_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_value_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_io__type_ctor_info_state_0;
MR_declare_entry(mercury__tree234__foldl_4_2);
MR_declare_entry(mercury__io__stderr_stream_3_0);
MR_declare_entry(mercury__io__set_output_stream_4_0);
MR_declare_entry(mercury__std_util__univ_to_type_2_0);
MR_declare_entry(mercury__io__write_string_3_0);
MR_declare_entry(mercury__io__nl_2_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_stack_env_exception_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_stack_env_token_exception_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_token_0;
MR_declare_entry(mercury__io__write_3_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_parse_error_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_gml__type_ctor_info_lexer_error_0;
MR_declare_entry(mercury__io__format_4_0);
extern const struct MR_TypeCtorInfo_Struct mercury_data_eval__type_ctor_info_program_error_0;
extern const struct MR_TypeCtorInfo_Struct mercury_data_std_util__type_ctor_info_univ_0;
MR_declare_entry(mercury__std_util__type_to_univ_2_1);
MR_declare_entry(mercury__ops__max_priority_1_0);
MR_declare_entry(mercury__io__write_univ_4_0);
MR_declare_entry(mercury__fn__pprint__to_doc_2_0);
MR_declare_entry(mercury__fn__pprint__best_3_0);
MR_declare_entry(mercury____Unify___list__list_1_0);
MR_declare_entry(mercury____Compare___list__list_1_0);

MR_BEGIN_MODULE(eval_util_module)
	MR_init_entry(mercury__eval_util__list__foldl__ho10_4_0);
	MR_init_label(mercury__eval_util__list__foldl__ho10_4_0_i13);
	MR_init_label(mercury__eval_util__list__foldl__ho10_4_0_i3);
	MR_init_entry(mercury__eval_util__list__foldl__ho5_4_0);
	MR_init_label(mercury__eval_util__list__foldl__ho5_4_0_i4);
	MR_init_label(mercury__eval_util__list__foldl__ho5_4_0_i3);
	MR_init_entry(mercury__eval_util__write_env_3_0);
	MR_init_entry(mercury__eval_util__write_stack_3_0);
	MR_init_entry(mercury__eval_util__write_nice_exception_3_0);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i2);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i3);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i5);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i7);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i8);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i9);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i10);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i11);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i12);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i4);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i15);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i17);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i18);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i19);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i20);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i14);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i23);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i25);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i26);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i27);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i28);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i29);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i30);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i22);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i33);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i35);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i32);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i38);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i37);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i42);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i45);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i41);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i48);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i51);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i52);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i53);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i47);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i56);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i58);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i55);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i68);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i69);
	MR_init_label(mercury__eval_util__write_nice_exception_3_0_i70);
	MR_init_entry(mercury__eval_util__write_prog_4_0);
	MR_init_label(mercury__eval_util__write_prog_4_0_i4);
	MR_init_label(mercury__eval_util__write_prog_4_0_i3);
	MR_init_entry(mercury__eval_util__write_env_entry_4_0);
	MR_init_label(mercury__eval_util__write_env_entry_4_0_i2);
	MR_init_label(mercury__eval_util__write_env_entry_4_0_i3);
	MR_init_label(mercury__eval_util__write_env_entry_4_0_i4);
	MR_init_entry(mercury__eval_util__write_stack_entry_3_0);
	MR_init_label(mercury__eval_util__write_stack_entry_3_0_i2);
	MR_init_label(mercury__eval_util__write_stack_entry_3_0_i3);
	MR_init_label(mercury__eval_util__write_stack_entry_3_0_i4);
	MR_init_entry(mercury__eval_util__write_group_4_0);
	MR_init_label(mercury__eval_util__write_group_4_0_i12);
	MR_init_label(mercury__eval_util__write_group_4_0_i13);
	MR_init_label(mercury__eval_util__write_group_4_0_i14);
	MR_init_label(mercury__eval_util__write_group_4_0_i8);
	MR_init_label(mercury__eval_util__write_group_4_0_i9);
	MR_init_label(mercury__eval_util__write_group_4_0_i10);
	MR_init_label(mercury__eval_util__write_group_4_0_i11);
	MR_init_label(mercury__eval_util__write_group_4_0_i4);
	MR_init_label(mercury__eval_util__write_group_4_0_i5);
	MR_init_label(mercury__eval_util__write_group_4_0_i6);
	MR_init_label(mercury__eval_util__write_group_4_0_i7);
	MR_init_entry(mercury__eval_util__indent_3_0);
	MR_init_label(mercury__eval_util__indent_3_0_i2);
	MR_init_entry(mercury____Unify___eval_util__unequal_stacks_exception_0_0);
	MR_init_label(mercury____Unify___eval_util__unequal_stacks_exception_0_0_i2);
	MR_init_label(mercury____Unify___eval_util__unequal_stacks_exception_0_0_i1);
	MR_init_entry(mercury____Compare___eval_util__unequal_stacks_exception_0_0);
	MR_init_label(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i4);
	MR_init_label(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i3);
	MR_init_label(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i16);
	MR_init_label(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i21);
MR_BEGIN_CODE

/* code for predicate 'foldl__ho10'/4 in mode 0 */
MR_define_static(mercury__eval_util__list__foldl__ho10_4_0);
	MR_incr_sp_push_msg(2, "list:foldl__ho10/4");
	MR_stackvar(2) = (MR_Word) MR_succip;
MR_define_label(mercury__eval_util__list__foldl__ho10_4_0_i13);
	while (1) {
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval_util__list__foldl__ho10_4_0_i3);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__list__foldl__ho10_4_0
	Message = (MR_String) MR_r3;
	IO0 = MR_r2;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 983 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval_util__list__foldl__ho10_4_0_i3);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__list__foldl__ho10_4_0
	Message = (MR_String) MR_r3;
	IO0 = MR_r2;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 1012 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	/* continue */ } /* end while */
MR_define_label(mercury__eval_util__list__foldl__ho10_4_0_i3);
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate 'foldl__ho5'/4 in mode 0 */
MR_define_static(mercury__eval_util__list__foldl__ho5_4_0);
	MR_incr_sp_push_msg(2, "list:foldl__ho5/4");
	MR_stackvar(2) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval_util__list__foldl__ho5_4_0_i3);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__eval_util__write_stack_entry_3_0,
		MR_LABEL(mercury__eval_util__list__foldl__ho5_4_0_i4),
		MR_STATIC(mercury__eval_util__list__foldl__ho5_4_0));
MR_define_label(mercury__eval_util__list__foldl__ho5_4_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__list__foldl__ho5_4_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval_util__list__foldl__ho5_4_0_i3);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__eval_util__write_stack_entry_3_0,
		MR_LABEL(mercury__eval_util__list__foldl__ho5_4_0_i4),
		MR_STATIC(mercury__eval_util__list__foldl__ho5_4_0));
MR_define_label(mercury__eval_util__list__foldl__ho5_4_0_i3);
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate 'write_env'/3 in mode 0 */
MR_define_entry(mercury__eval_util__write_env_3_0);
	MR_incr_sp_push_msg(2, "eval_util:write_env/3");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__write_env_3_0
	Message = (MR_String) (MR_Word) MR_string_const("Environment:\n", 13);
	IO0 = MR_r2;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 1077 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r6 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r3 = (MR_Word) (MR_Word *) &mercury_data_io__type_ctor_info_state_0;
	MR_r4 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_eval_util__common_1);
	MR_r5 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_tailcall(MR_ENTRY(mercury__tree234__foldl_4_2),
		MR_ENTRY(mercury__eval_util__write_env_3_0));
/* code for predicate 'write_stack'/3 in mode 0 */
MR_define_entry(mercury__eval_util__write_stack_3_0);
	MR_incr_sp_push_msg(2, "eval_util:write_stack/3");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__write_stack_3_0
	Message = (MR_String) (MR_Word) MR_string_const("Stack:\n", 7);
	IO0 = MR_r2;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 1113 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_localtailcall(mercury__eval_util__list__foldl__ho5_4_0,
		MR_ENTRY(mercury__eval_util__write_stack_3_0));
/* code for predicate 'write_nice_exception'/3 in mode 0 */
MR_define_entry(mercury__eval_util__write_nice_exception_3_0);
	MR_incr_sp_push_msg(6, "eval_util:write_nice_exception/3");
	MR_stackvar(6) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r1;
	MR_r1 = MR_r2;
	MR_call_localret(MR_ENTRY(mercury__io__stderr_stream_3_0),
		mercury__eval_util__write_nice_exception_3_0_i2,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_call_localret(MR_ENTRY(mercury__io__set_output_stream_4_0),
		mercury__eval_util__write_nice_exception_3_0_i3,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_stackvar(2) = MR_r1;
	MR_stackvar(3) = MR_r2;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval_util__type_ctor_info_unequal_stacks_exception_0;
	MR_r2 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__eval_util__write_nice_exception_3_0_i5,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__eval_util__write_nice_exception_3_0_i4);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r3 = MR_tempr1;
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	MR_r1 = (MR_Word) MR_string_const("Exception: ", 11);
	}
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i7,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i8,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i8);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_call_localret(MR_ENTRY(mercury__io__nl_2_0),
		mercury__eval_util__write_nice_exception_3_0_i9,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("Unoptimized ", 12);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i10,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(3);
	MR_localcall(mercury__eval_util__write_stack_3_0,
		MR_LABEL(mercury__eval_util__write_nice_exception_3_0_i11),
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i11);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const("Optimized ", 10);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i12,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(4);
	MR_localcall(mercury__eval_util__write_stack_3_0,
		MR_LABEL(mercury__eval_util__write_nice_exception_3_0_i68),
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i4);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_stack_env_exception_0;
	MR_r2 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__eval_util__write_nice_exception_3_0_i15,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i15);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__eval_util__write_nice_exception_3_0_i14);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r3 = MR_tempr1;
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	MR_r1 = (MR_Word) MR_string_const("Exception: ", 11);
	}
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i17,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i17);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(3);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i18,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i18);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_call_localret(MR_ENTRY(mercury__io__nl_2_0),
		mercury__eval_util__write_nice_exception_3_0_i19,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i19);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_localcall(mercury__eval_util__write_env_3_0,
		MR_LABEL(mercury__eval_util__write_nice_exception_3_0_i20),
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i20);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(4);
	MR_localcall(mercury__eval_util__write_stack_3_0,
		MR_LABEL(mercury__eval_util__write_nice_exception_3_0_i68),
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i14);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_stack_env_token_exception_0;
	MR_r2 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__eval_util__write_nice_exception_3_0_i23,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i23);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__eval_util__write_nice_exception_3_0_i22);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 3);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r2;
	MR_r3 = MR_tempr1;
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_r1 = (MR_Word) MR_string_const("Exception at token ", 19);
	}
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i25,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i25);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_0;
	MR_r2 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__io__write_3_0),
		mercury__eval_util__write_nice_exception_3_0_i26,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i26);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_string_const(" : ", 3);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i27,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i27);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(3);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i28,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i28);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_call_localret(MR_ENTRY(mercury__io__nl_2_0),
		mercury__eval_util__write_nice_exception_3_0_i29,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i29);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(5);
	MR_localcall(mercury__eval_util__write_env_3_0,
		MR_LABEL(mercury__eval_util__write_nice_exception_3_0_i30),
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i30);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(4);
	MR_localcall(mercury__eval_util__write_stack_3_0,
		MR_LABEL(mercury__eval_util__write_nice_exception_3_0_i68),
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i22);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_parse_error_0;
	MR_r2 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__eval_util__write_nice_exception_3_0_i33,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i33);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__eval_util__write_nice_exception_3_0_i32);
	}
	MR_stackvar(1) = MR_r2;
	MR_r1 = (MR_Word) MR_string_const("Parse error: ", 13);
	MR_r2 = MR_stackvar(3);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i35,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i35);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i68,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i32);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_lexer_error_0;
	MR_r2 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__eval_util__write_nice_exception_3_0_i38,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i38);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__eval_util__write_nice_exception_3_0_i37);
	}
	{
	MR_Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 1, mercury__eval_util__write_nice_exception_3_0, "string:poly_type/0");
	MR_r4 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_tag_incr_hp_msg(MR_tempr2, MR_mktag(2), (MR_Integer) 1, mercury__eval_util__write_nice_exception_3_0, "string:poly_type/0");
	MR_r5 = MR_tempr2;
	MR_field(MR_mktag(2), MR_tempr2, (MR_Integer) 0) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_tag_incr_hp_msg(MR_tempr3, MR_mktag(1), (MR_Integer) 2, mercury__eval_util__write_nice_exception_3_0, "list:list/1");
	MR_r6 = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr3, (MR_Integer) 0) = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr3, (MR_Integer) 1) = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_tag_incr_hp_msg(MR_tempr4, MR_mktag(1), (MR_Integer) 2, mercury__eval_util__write_nice_exception_3_0, "list:list/1");
	MR_r2 = MR_tempr4;
	MR_field(MR_mktag(1), MR_tempr4, (MR_Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr4, (MR_Integer) 1) = MR_tempr3;
	MR_r1 = (MR_Word) MR_string_const("Line %d: lexical error: %s ", 27);
	MR_r3 = MR_stackvar(3);
	}
	MR_call_localret(MR_ENTRY(mercury__io__format_4_0),
		mercury__eval_util__write_nice_exception_3_0_i68,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i37);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_program_error_0;
	MR_r2 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__eval_util__write_nice_exception_3_0_i42,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i42);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__eval_util__write_nice_exception_3_0_i41);
	}
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 0))) {
		MR_GOTO_LABEL(mercury__eval_util__write_nice_exception_3_0_i41);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r1 = (MR_Word) MR_string_const("Program error: ", 15);
	MR_r2 = MR_stackvar(3);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i45,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i45);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i68,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i41);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_program_error_0;
	MR_r2 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__eval_util__write_nice_exception_3_0_i48,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i48);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__eval_util__write_nice_exception_3_0_i47);
	}
	if ((MR_tag(MR_r2) != MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval_util__write_nice_exception_3_0_i47);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_r3 = MR_r2;
	MR_r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_r3, (MR_Integer) 1);
	MR_r1 = (MR_Word) MR_string_const("Program error: ", 15);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i51,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i51);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i52,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i52);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_call_localret(MR_ENTRY(mercury__io__nl_2_0),
		mercury__eval_util__write_nice_exception_3_0_i53,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i53);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(3);
	MR_localcall(mercury__eval_util__write_stack_3_0,
		MR_LABEL(mercury__eval_util__write_nice_exception_3_0_i68),
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i47);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data___type_ctor_info_string_0;
	MR_r2 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__eval_util__write_nice_exception_3_0_i56,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i56);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury__eval_util__write_nice_exception_3_0_i55);
	}
	MR_stackvar(1) = MR_r2;
	MR_r1 = (MR_Word) MR_string_const("Error: ", 7);
	MR_r2 = MR_stackvar(3);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i58,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i58);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__io__write_string_3_0),
		mercury__eval_util__write_nice_exception_3_0_i68,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i55);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(3);
	MR_call_localret(MR_ENTRY(mercury__io__write_3_0),
		mercury__eval_util__write_nice_exception_3_0_i68,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i68);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_call_localret(MR_ENTRY(mercury__io__nl_2_0),
		mercury__eval_util__write_nice_exception_3_0_i69,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i69);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_call_localret(MR_ENTRY(mercury__io__set_output_stream_4_0),
		mercury__eval_util__write_nice_exception_3_0_i70,
		MR_ENTRY(mercury__eval_util__write_nice_exception_3_0));
MR_define_label(mercury__eval_util__write_nice_exception_3_0_i70);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_nice_exception_3_0));
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	MR_proceed();
/* code for predicate 'write_prog'/4 in mode 0 */
MR_define_entry(mercury__eval_util__write_prog_4_0);
	MR_incr_sp_push_msg(3, "eval_util:write_prog/4");
	MR_stackvar(3) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r2 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval_util__write_prog_4_0_i3);
	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_localcall(mercury__eval_util__write_group_4_0,
		MR_LABEL(mercury__eval_util__write_prog_4_0_i4),
		MR_ENTRY(mercury__eval_util__write_prog_4_0));
MR_define_label(mercury__eval_util__write_prog_4_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_prog_4_0));
	{
	MR_Char	Character;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__write_prog_4_0
	Character = (MR_Integer) 10;
	IO0 = MR_r1;
	MR_save_registers();
{
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	if (MR_PUTCH(*mercury_current_text_output, Character) < 0) {
		mercury_output_error(mercury_current_text_output);
	}
	if (Character == '\n') {
		MR_line_number(*mercury_current_text_output)++;
	}
	update_io(IO0, IO);
;}
#line 1531 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = MR_stackvar(1);
	MR_r2 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	if (((MR_Integer) MR_r2 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__eval_util__write_prog_4_0_i3);
	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_localcall(mercury__eval_util__write_group_4_0,
		MR_LABEL(mercury__eval_util__write_prog_4_0_i4),
		MR_ENTRY(mercury__eval_util__write_prog_4_0));
MR_define_label(mercury__eval_util__write_prog_4_0_i3);
	MR_r1 = MR_r3;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate 'write_env_entry'/4 in mode 0 */
MR_define_entry(mercury__eval_util__write_env_entry_4_0);
	MR_incr_sp_push_msg(3, "eval_util:write_env_entry/4");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r2;
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__write_env_entry_4_0
	Message = (MR_String) MR_r1;
	IO0 = MR_r3;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 1575 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__write_env_entry_4_0
	Message = (MR_String) (MR_Word) MR_string_const("\t: ", 3);
	IO0 = MR_r3;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 1597 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_r3;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_call_localret(MR_ENTRY(mercury__std_util__type_to_univ_2_1),
		mercury__eval_util__write_env_entry_4_0_i2,
		MR_ENTRY(mercury__eval_util__write_env_entry_4_0));
MR_define_label(mercury__eval_util__write_env_entry_4_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_env_entry_4_0));
	MR_stackvar(2) = MR_r1;
	MR_call_localret(MR_ENTRY(mercury__ops__max_priority_1_0),
		mercury__eval_util__write_env_entry_4_0_i3,
		MR_ENTRY(mercury__eval_util__write_env_entry_4_0));
MR_define_label(mercury__eval_util__write_env_entry_4_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_env_entry_4_0));
	MR_r4 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_r2 = ((MR_Integer) MR_r4 + (MR_Integer) 1);
	MR_r3 = MR_stackvar(1);
	MR_call_localret(MR_ENTRY(mercury__io__write_univ_4_0),
		mercury__eval_util__write_env_entry_4_0_i4,
		MR_ENTRY(mercury__eval_util__write_env_entry_4_0));
MR_define_label(mercury__eval_util__write_env_entry_4_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_env_entry_4_0));
	{
	MR_Char	Character;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__write_env_entry_4_0
	Character = (MR_Integer) 10;
	IO0 = MR_r1;
	MR_save_registers();
{
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	if (MR_PUTCH(*mercury_current_text_output, Character) < 0) {
		mercury_output_error(mercury_current_text_output);
	}
	if (Character == '\n') {
		MR_line_number(*mercury_current_text_output)++;
	}
	update_io(IO0, IO);
;}
#line 1647 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate 'write_stack_entry'/3 in mode 0 */
MR_define_entry(mercury__eval_util__write_stack_entry_3_0);
	MR_incr_sp_push_msg(2, "eval_util:write_stack_entry/3");
	MR_stackvar(2) = (MR_Word) MR_succip;
	MR_stackvar(1) = MR_r2;
	MR_r3 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r2 = (MR_Integer) 3;
	MR_call_localret(MR_ENTRY(mercury__fn__pprint__to_doc_2_0),
		mercury__eval_util__write_stack_entry_3_0_i2,
		MR_ENTRY(mercury__eval_util__write_stack_entry_3_0));
MR_define_label(mercury__eval_util__write_stack_entry_3_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_stack_entry_3_0));
	MR_r3 = MR_r1;
	MR_r1 = (MR_Integer) 80;
	MR_r2 = (MR_Integer) 0;
	MR_call_localret(MR_ENTRY(mercury__fn__pprint__best_3_0),
		mercury__eval_util__write_stack_entry_3_0_i3,
		MR_ENTRY(mercury__eval_util__write_stack_entry_3_0));
MR_define_label(mercury__eval_util__write_stack_entry_3_0_i3);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_stack_entry_3_0));
	MR_r2 = MR_stackvar(1);
	MR_localcall(mercury__eval_util__list__foldl__ho10_4_0,
		MR_LABEL(mercury__eval_util__write_stack_entry_3_0_i4),
		MR_ENTRY(mercury__eval_util__write_stack_entry_3_0));
MR_define_label(mercury__eval_util__write_stack_entry_3_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_stack_entry_3_0));
	{
	MR_Char	Character;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__write_stack_entry_3_0
	Character = (MR_Integer) 10;
	IO0 = MR_r1;
	MR_save_registers();
{
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	if (MR_PUTCH(*mercury_current_text_output, Character) < 0) {
		mercury_output_error(mercury_current_text_output);
	}
	if (Character == '\n') {
		MR_line_number(*mercury_current_text_output)++;
	}
	update_io(IO0, IO);
;}
#line 1704 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate 'write_group'/4 in mode 0 */
MR_define_entry(mercury__eval_util__write_group_4_0);
	MR_incr_sp_push_msg(3, "eval_util:write_group/4");
	MR_stackvar(3) = (MR_Word) MR_succip;
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 1))) {
		MR_GOTO_LABEL(mercury__eval_util__write_group_4_0_i4);
	}
	if ((MR_tag(MR_r2) == MR_mktag((MR_Integer) 2))) {
		MR_GOTO_LABEL(mercury__eval_util__write_group_4_0_i8);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval_util__indent_3_0,
		MR_LABEL(mercury__eval_util__write_group_4_0_i12),
		MR_ENTRY(mercury__eval_util__write_group_4_0));
MR_define_label(mercury__eval_util__write_group_4_0_i12);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_group_4_0));
	MR_r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_gml__type_ctor_info_token_0;
	MR_call_localret(MR_ENTRY(mercury__std_util__type_to_univ_2_1),
		mercury__eval_util__write_group_4_0_i13,
		MR_ENTRY(mercury__eval_util__write_group_4_0));
MR_define_label(mercury__eval_util__write_group_4_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_group_4_0));
	MR_stackvar(2) = MR_r1;
	MR_call_localret(MR_ENTRY(mercury__ops__max_priority_1_0),
		mercury__eval_util__write_group_4_0_i14,
		MR_ENTRY(mercury__eval_util__write_group_4_0));
MR_define_label(mercury__eval_util__write_group_4_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_group_4_0));
	MR_r4 = MR_r1;
	MR_r1 = MR_stackvar(2);
	MR_r2 = ((MR_Integer) MR_r4 + (MR_Integer) 1);
	MR_r3 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury__io__write_univ_4_0),
		MR_ENTRY(mercury__eval_util__write_group_4_0));
MR_define_label(mercury__eval_util__write_group_4_0_i8);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval_util__indent_3_0,
		MR_LABEL(mercury__eval_util__write_group_4_0_i9),
		MR_ENTRY(mercury__eval_util__write_group_4_0));
MR_define_label(mercury__eval_util__write_group_4_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_group_4_0));
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__write_group_4_0
	Message = (MR_String) (MR_Word) MR_string_const("[\n", 2);
	IO0 = MR_r1;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 1777 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = ((MR_Integer) MR_stackvar(1) + (MR_Integer) 1);
	MR_r2 = MR_stackvar(2);
	MR_localcall(mercury__eval_util__write_prog_4_0,
		MR_LABEL(mercury__eval_util__write_group_4_0_i10),
		MR_ENTRY(mercury__eval_util__write_group_4_0));
MR_define_label(mercury__eval_util__write_group_4_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_group_4_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_localcall(mercury__eval_util__indent_3_0,
		MR_LABEL(mercury__eval_util__write_group_4_0_i11),
		MR_ENTRY(mercury__eval_util__write_group_4_0));
MR_define_label(mercury__eval_util__write_group_4_0_i11);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_group_4_0));
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__write_group_4_0
	Message = (MR_String) (MR_Word) MR_string_const("]", 1);
	IO0 = MR_r1;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 1813 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
MR_define_label(mercury__eval_util__write_group_4_0_i4);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_r2 = MR_r3;
	MR_localcall(mercury__eval_util__indent_3_0,
		MR_LABEL(mercury__eval_util__write_group_4_0_i5),
		MR_ENTRY(mercury__eval_util__write_group_4_0));
MR_define_label(mercury__eval_util__write_group_4_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_group_4_0));
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__write_group_4_0
	Message = (MR_String) (MR_Word) MR_string_const("{\n", 2);
	IO0 = MR_r1;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 1847 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r3 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = ((MR_Integer) MR_stackvar(1) + (MR_Integer) 1);
	MR_r2 = MR_stackvar(2);
	MR_localcall(mercury__eval_util__write_prog_4_0,
		MR_LABEL(mercury__eval_util__write_group_4_0_i6),
		MR_ENTRY(mercury__eval_util__write_group_4_0));
MR_define_label(mercury__eval_util__write_group_4_0_i6);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_group_4_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_localcall(mercury__eval_util__indent_3_0,
		MR_LABEL(mercury__eval_util__write_group_4_0_i7),
		MR_ENTRY(mercury__eval_util__write_group_4_0));
MR_define_label(mercury__eval_util__write_group_4_0_i7);
	MR_update_prof_current_proc(MR_LABEL(mercury__eval_util__write_group_4_0));
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__write_group_4_0
	Message = (MR_String) (MR_Word) MR_string_const("}", 1);
	IO0 = MR_r1;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 1883 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r1 = IO;
#undef	MR_PROC_LABEL

	}
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate 'indent'/3 in mode 0 */
MR_define_static(mercury__eval_util__indent_3_0);
	MR_incr_sp_push_msg(2, "eval_util:indent/3");
	MR_stackvar(2) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__eval_util__indent_3_0_i2);
	}
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
MR_define_label(mercury__eval_util__indent_3_0_i2);
	while (1) {
	MR_stackvar(1) = MR_r1;
	{
	MR_String	Message;
	MR_Word	IO0;
	MR_Word	IO;
#define	MR_PROC_LABEL	mercury__eval_util__indent_3_0
	Message = (MR_String) (MR_Word) MR_string_const("   ", 3);
	IO0 = MR_r2;
	MR_save_registers();
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);
;}
#line 1922 "eval_util.c"
#ifndef CONSERVATIVE_GC
	MR_restore_registers();
#endif
	MR_r2 = IO;
#undef	MR_PROC_LABEL

	}
	MR_r1 = ((MR_Integer) MR_stackvar(1) - (MR_Integer) 1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	if (((MR_Integer) MR_r1 != (MR_Integer) 0))
		continue;
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
	break; } /* end while */
/* code for predicate '__Unify__'/2 in mode 0 */
MR_define_entry(mercury____Unify___eval_util__unequal_stacks_exception_0_0);
	MR_incr_sp_push_msg(3, "eval_util:__Unify__/2");
	MR_stackvar(3) = (MR_Word) MR_succip;
	{
	MR_Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	if ((strcmp((char *)MR_tempr1, (char *)MR_tempr2) != 0)) {
		MR_GOTO_LABEL(mercury____Unify___eval_util__unequal_stacks_exception_0_0_i1);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_r4 = MR_r1;
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r5 = MR_r2;
	MR_r2 = MR_const_field(MR_mktag(0), MR_r4, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r5, (MR_Integer) 1);
	}
	MR_call_localret(MR_ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___eval_util__unequal_stacks_exception_0_0_i2,
		MR_ENTRY(mercury____Unify___eval_util__unequal_stacks_exception_0_0));
MR_define_label(mercury____Unify___eval_util__unequal_stacks_exception_0_0_i2);
	MR_update_prof_current_proc(MR_LABEL(mercury____Unify___eval_util__unequal_stacks_exception_0_0));
	if (!(MR_r1)) {
		MR_GOTO_LABEL(mercury____Unify___eval_util__unequal_stacks_exception_0_0_i1);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(2);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_tailcall(MR_ENTRY(mercury____Unify___list__list_1_0),
		MR_ENTRY(mercury____Unify___eval_util__unequal_stacks_exception_0_0));
MR_define_label(mercury____Unify___eval_util__unequal_stacks_exception_0_0_i1);
	MR_r1 = FALSE;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
/* code for predicate '__Compare__'/3 in mode 0 */
MR_define_entry(mercury____Compare___eval_util__unequal_stacks_exception_0_0);
	MR_incr_sp_push_msg(5, "eval_util:__Compare__/3");
	MR_stackvar(5) = (MR_Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_const_field(MR_mktag(0), MR_r2, (MR_Integer) 0);
	{
	MR_Integer	Res;
	MR_String	S1;
	MR_String	S2;
#define	MR_PROC_LABEL	mercury____Compare___eval_util__unequal_stacks_exception_0_0
	S1 = (MR_String) MR_r3;
	S2 = (MR_String) MR_r4;
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);;}
#line 1998 "eval_util.c"
	MR_r2 = Res;
#undef	MR_PROC_LABEL

	}
	if (((MR_Integer) MR_r2 >= (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i4);
	}
	if (((MR_Integer) 1 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i3);
	}
	MR_r1 = (MR_Integer) 1;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i4);
	if (((MR_Integer) MR_r2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i3);
	}
	if (((MR_Integer) 2 == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i3);
	}
	MR_r1 = (MR_Integer) 2;
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_define_label(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i3);
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r2 = MR_stackvar(1);
	MR_r3 = MR_stackvar(3);
	MR_call_localret(MR_ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___eval_util__unequal_stacks_exception_0_0_i16,
		MR_ENTRY(mercury____Compare___eval_util__unequal_stacks_exception_0_0));
MR_define_label(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury____Compare___eval_util__unequal_stacks_exception_0_0));
	if (((MR_Integer) MR_r1 != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i21);
	}
	MR_r1 = (MR_Word) (MR_Word *) &mercury_data_eval__type_ctor_info_value_0;
	MR_r2 = MR_stackvar(2);
	MR_r3 = MR_stackvar(4);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_tailcall(MR_ENTRY(mercury____Compare___list__list_1_0),
		MR_ENTRY(mercury____Compare___eval_util__unequal_stacks_exception_0_0));
MR_define_label(mercury____Compare___eval_util__unequal_stacks_exception_0_0_i21);
	MR_succip = (MR_Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	MR_proceed();
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__eval_util_maybe_bunch_0(void)
{
	eval_util_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__eval_util__init(void);
void mercury__eval_util__init_type_tables(void);
void mercury__eval_util__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__eval_util__write_out_proc_statics(FILE *fp);
#endif

void mercury__eval_util__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__eval_util_maybe_bunch_0();
#endif

	MR_INIT_TYPE_CTOR_INFO(
		mercury_data_eval_util__type_ctor_info_unequal_stacks_exception_0,
		eval_util__unequal_stacks_exception_0_0);
	mercury__eval_util__init_debugger();
}

void mercury__eval_util__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
	MR_register_type_ctor_info(
		&mercury_data_eval_util__type_ctor_info_unequal_stacks_exception_0);
}


void mercury__eval_util__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__eval_util__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
