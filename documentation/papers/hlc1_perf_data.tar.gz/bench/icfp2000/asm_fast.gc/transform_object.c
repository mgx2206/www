/*
** Automatically generated from `transform_object.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__transform_object__init
ENDINIT
*/

#include "mercury_imp.h"
#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 25 "transform_object.c"
#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 32 "transform_object.c"
#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_DETERMINISM_GUARD
#define ML_DETERMINISM_GUARD
	/*
	** The enumeration constants in this enum must be in the same
	** order as the functors in the Mercury type `determinism'
	** defined above.
	*/
	typedef enum {
		ML_DET,
		ML_SEMIDET,
		ML_CC_MULTI,
		ML_CC_NONDET,
		ML_MULTI,
		ML_NONDET,
		ML_ERRONEOUS,
		ML_FAILURE
	} ML_Determinism;
#endif

#line 55 "transform_object.c"
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

/* protect against multiple inclusion */
#ifndef MR_HLC_EXCEPTION_GUARD
#define MR_HLC_EXCEPTION_GUARD

#ifdef MR_HIGHLEVEL_CODE

  #ifdef MR_USE_GCC_NESTED_FUNCTIONS
  	#define MR_CONT_PARAMS		MR_NestedCont cont
  	#define MR_CONT_PARAM_TYPES	MR_NestedCont
  	#define MR_CONT_ARGS		cont
  #else
  	#define MR_CONT_PARAMS		MR_Cont cont, void *cont_env
  	#define MR_CONT_PARAM_TYPES	MR_Cont, void *
  	#define MR_CONT_ARGS		cont, cont_env
  #endif

	/* det */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_0(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* semidet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_1(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_2(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* cc_nondet */
	bool MR_CALL
	mercury__exception__builtin_catch_3_p_3(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output);

	/* multi */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_4(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

	/* nondet */
	void MR_CALL
	mercury__exception__builtin_catch_3_p_5(MR_Mercury_Type_Info type_info,
		MR_Pred pred, MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

  #ifndef MR_AVOID_MACROS

	/* det ==> model_det */
	#define mercury__exception__builtin_catch_3_p_0 		mercury__exception__builtin_catch_model_det

	/* semidet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_1 		mercury__exception__builtin_catch_model_semi

	/* cc_multi ==> model_det */
	#define mercury__exception__builtin_catch_3_p_2 		mercury__exception__builtin_catch_model_det

	/* cc_nondet ==> model_semi */
	#define mercury__exception__builtin_catch_3_p_3 		mercury__exception__builtin_catch_model_semi

	/* multi ==> model_non */
	#define mercury__exception__builtin_catch_3_p_4 		mercury__exception__builtin_catch_model_non

	/* nondet ==> model_non */
	#define mercury__exception__builtin_catch_3_p_5 		mercury__exception__builtin_catch_model_non

  #endif /* !MR_AVOID_MACROS */

	void MR_CALL mercury__exception__builtin_throw_1_p_0(MR_Univ exception);

	void MR_CALL mercury__exception__builtin_catch_model_det(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	bool MR_CALL mercury__exception__builtin_catch_model_semi(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output);
	void MR_CALL mercury__exception__builtin_catch_model_non(
		MR_Mercury_Type_Info type_info, MR_Pred pred,
		MR_Pred handler_pred, MR_Box *output,
		MR_CONT_PARAMS);

#endif /* MR_HIGHLEVEL_CODE */

#endif /* MR_HLC_EXCEPTION_GUARD */

#line 145 "transform_object.c"
#line 147 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

#ifndef MR_HIGHLEVEL_CODE
	#include <assert.h>
	#include <stdio.h>
	#include "mercury_deep_copy.h"
	#include "mercury_trace_base.h"
	#include "mercury_stack_trace.h"
	#include "mercury_layout_util.h"
	#include "mercury_deep_profiling_hand.h"

	MR_DECLARE_TYPE_CTOR_INFO_STRUCT( 			mercury_data_std_util__type_ctor_info_univ_0);
#endif

#line 160 "transform_object.c"
#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 163 "transform_object.c"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 169 "transform_object.c"
#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif

#line 177 "transform_object.c"


static const struct mercury_data_transform_object__common_0_struct {
	MR_Word * f1;
	MR_Word * f2;
	MR_Word * f3;
	MR_Word * f4;
	MR_Word * f5;
	MR_Word * f6;
	MR_Word * f7;
	MR_Word * f8;
	MR_Word * f9;
	MR_Word * f10;
	MR_Word * f11;
	MR_Word * f12;
}  mercury_data_transform_object__common_0;

static const struct mercury_data_transform_object__common_1_struct {
	MR_Word * f1;
	MR_Word * f2;
}  mercury_data_transform_object__common_1;
MR_declare_static(mercury__transform_object__list__foldl__ho3_4_0);
MR_declare_label(mercury__transform_object__list__foldl__ho3_4_0_i4);
MR_declare_label(mercury__transform_object__list__foldl__ho3_4_0_i3);
MR_define_extern_entry(mercury__fn__transform_object__push_transformations_1_0);
MR_define_extern_entry(mercury__fn__transform_object__push_trans_2_0);
MR_declare_label(mercury__fn__transform_object__push_trans_2_0_i4);
MR_declare_label(mercury__fn__transform_object__push_trans_2_0_i5);
MR_declare_label(mercury__fn__transform_object__push_trans_2_0_i6);
MR_declare_label(mercury__fn__transform_object__push_trans_2_0_i8);
MR_declare_label(mercury__fn__transform_object__push_trans_2_0_i9);
MR_declare_label(mercury__fn__transform_object__push_trans_2_0_i10);
MR_declare_label(mercury__fn__transform_object__push_trans_2_0_i11);
MR_declare_label(mercury__fn__transform_object__push_trans_2_0_i13);
MR_declare_label(mercury__fn__transform_object__push_trans_2_0_i14);
MR_declare_label(mercury__fn__transform_object__push_trans_2_0_i12);
MR_declare_label(mercury__fn__transform_object__push_trans_2_0_i15);
MR_declare_label(mercury__fn__transform_object__push_trans_2_0_i16);
MR_declare_static(mercury__fn__transform_object__compose_transformation_2_0);
MR_declare_label(mercury__fn__transform_object__compose_transformation_2_0_i4);
MR_declare_label(mercury__fn__transform_object__compose_transformation_2_0_i6);
MR_declare_label(mercury__fn__transform_object__compose_transformation_2_0_i8);
MR_declare_label(mercury__fn__transform_object__compose_transformation_2_0_i10);
MR_declare_label(mercury__fn__transform_object__compose_transformation_2_0_i15);
MR_declare_label(mercury__fn__transform_object__compose_transformation_2_0_i13);
MR_declare_label(mercury__fn__transform_object__compose_transformation_2_0_i11);

static const MR_Float mercury_float_const_1pt00000000000000 = 1.00000000000000;
static const MR_Float mercury_float_const_0pt00000000000000 = 0.00000000000000;
static const struct mercury_data_transform_object__common_0_struct mercury_data_transform_object__common_0 = {
	(MR_Word *) &mercury_float_const_1pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_1pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000,
	(MR_Word *) &mercury_float_const_1pt00000000000000,
	(MR_Word *) &mercury_float_const_0pt00000000000000
};

static const struct mercury_data_transform_object__common_1_struct mercury_data_transform_object__common_1 = {
	MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_transform_object__common_0),
	MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_transform_object__common_0)
};

MR_declare_entry(mercury__fn__trans__compose_translate_4_0);
MR_declare_entry(mercury__fn__trans__compose_scale_4_0);
MR_declare_entry(mercury__fn__trans__compose_uscale_2_0);
MR_declare_entry(mercury__require__error_1_0);
MR_declare_entry(mercury__fn__trans__compose_rotatez_2_0);
MR_declare_entry(mercury__fn__trans__compose_rotatey_2_0);
MR_declare_entry(mercury__fn__trans__compose_rotatex_2_0);

MR_BEGIN_MODULE(transform_object_module)
	MR_init_entry(mercury__transform_object__list__foldl__ho3_4_0);
	MR_init_label(mercury__transform_object__list__foldl__ho3_4_0_i4);
	MR_init_label(mercury__transform_object__list__foldl__ho3_4_0_i3);
	MR_init_entry(mercury__fn__transform_object__push_transformations_1_0);
	MR_init_entry(mercury__fn__transform_object__push_trans_2_0);
	MR_init_label(mercury__fn__transform_object__push_trans_2_0_i4);
	MR_init_label(mercury__fn__transform_object__push_trans_2_0_i5);
	MR_init_label(mercury__fn__transform_object__push_trans_2_0_i6);
	MR_init_label(mercury__fn__transform_object__push_trans_2_0_i8);
	MR_init_label(mercury__fn__transform_object__push_trans_2_0_i9);
	MR_init_label(mercury__fn__transform_object__push_trans_2_0_i10);
	MR_init_label(mercury__fn__transform_object__push_trans_2_0_i11);
	MR_init_label(mercury__fn__transform_object__push_trans_2_0_i13);
	MR_init_label(mercury__fn__transform_object__push_trans_2_0_i14);
	MR_init_label(mercury__fn__transform_object__push_trans_2_0_i12);
	MR_init_label(mercury__fn__transform_object__push_trans_2_0_i15);
	MR_init_label(mercury__fn__transform_object__push_trans_2_0_i16);
	MR_init_entry(mercury__fn__transform_object__compose_transformation_2_0);
	MR_init_label(mercury__fn__transform_object__compose_transformation_2_0_i4);
	MR_init_label(mercury__fn__transform_object__compose_transformation_2_0_i6);
	MR_init_label(mercury__fn__transform_object__compose_transformation_2_0_i8);
	MR_init_label(mercury__fn__transform_object__compose_transformation_2_0_i10);
	MR_init_label(mercury__fn__transform_object__compose_transformation_2_0_i15);
	MR_init_label(mercury__fn__transform_object__compose_transformation_2_0_i13);
	MR_init_label(mercury__fn__transform_object__compose_transformation_2_0_i11);
MR_BEGIN_CODE

/* code for predicate 'foldl__ho3'/4 in mode 0 */
MR_define_static(mercury__transform_object__list__foldl__ho3_4_0);
	MR_incr_sp_push_msg(2, "list:foldl__ho3/4");
	MR_stackvar(2) = (MR_Word) MR_succip;
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__transform_object__list__foldl__ho3_4_0_i3);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__fn__transform_object__compose_transformation_2_0,
		MR_LABEL(mercury__transform_object__list__foldl__ho3_4_0_i4),
		MR_STATIC(mercury__transform_object__list__foldl__ho3_4_0));
MR_define_label(mercury__transform_object__list__foldl__ho3_4_0_i4);
	MR_update_prof_current_proc(MR_LABEL(mercury__transform_object__list__foldl__ho3_4_0));
	MR_r2 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_succip = (MR_Code *) MR_stackvar(2);
	if (((MR_Integer) MR_r1 == (MR_Integer) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0)))) {
		MR_GOTO_LABEL(mercury__transform_object__list__foldl__ho3_4_0_i3);
	}
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 1);
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_localcall(mercury__fn__transform_object__compose_transformation_2_0,
		MR_LABEL(mercury__transform_object__list__foldl__ho3_4_0_i4),
		MR_STATIC(mercury__transform_object__list__foldl__ho3_4_0));
MR_define_label(mercury__transform_object__list__foldl__ho3_4_0_i3);
	MR_r1 = MR_r2;
	MR_succip = (MR_Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	MR_proceed();
/* code for predicate 'push_transformations'/2 in mode 0 */
MR_define_entry(mercury__fn__transform_object__push_transformations_1_0);
	MR_r2 = MR_r1;
	MR_r1 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) MR_mkbody((MR_Integer) 0));
	MR_localtailcall(mercury__fn__transform_object__push_trans_2_0,
		MR_ENTRY(mercury__fn__transform_object__push_transformations_1_0));
/* code for predicate 'push_trans'/3 in mode 0 */
MR_define_entry(mercury__fn__transform_object__push_trans_2_0);
	MR_incr_sp_push_msg(3, "transform_object:push_trans/3");
	MR_stackvar(3) = (MR_Word) MR_succip;
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r2),
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i4) MR_AND
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i6) MR_AND
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i8) MR_AND
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i11));
MR_define_label(mercury__fn__transform_object__push_trans_2_0_i4);
	MR_stackvar(1) = MR_r2;
	MR_r2 = (MR_Word) MR_mkword(MR_mktag(0), (MR_Word *) &mercury_data_transform_object__common_1);
	MR_localcall(mercury__transform_object__list__foldl__ho3_4_0,
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i5),
		MR_ENTRY(mercury__fn__transform_object__push_trans_2_0));
MR_define_label(mercury__fn__transform_object__push_trans_2_0_i5);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__transform_object__push_trans_2_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 2, mercury__fn__transform_object__push_trans_2_0, "eval:transformation/0");
	MR_r2 = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 3;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_tag_incr_hp_msg(MR_r1, MR_mktag(1), (MR_Integer) 2, mercury__fn__transform_object__push_trans_2_0, "eval:object/0");
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_r1, (MR_Integer) 1) = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
MR_define_label(mercury__fn__transform_object__push_trans_2_0_i6);
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (MR_Integer) 2, mercury__fn__transform_object__push_trans_2_0, "list:list/1");
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 0) = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 1);
	MR_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_r2 = MR_const_field(MR_mktag(1), MR_r2, (MR_Integer) 0);
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r2),
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i4) MR_AND
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i6) MR_AND
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i8) MR_AND
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i11));
	}
MR_define_label(mercury__fn__transform_object__push_trans_2_0_i8);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 1);
	MR_r2 = MR_const_field(MR_mktag(2), MR_r2, (MR_Integer) 0);
	MR_localcall(mercury__fn__transform_object__push_trans_2_0,
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i9),
		MR_ENTRY(mercury__fn__transform_object__push_trans_2_0));
MR_define_label(mercury__fn__transform_object__push_trans_2_0_i9);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__transform_object__push_trans_2_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__fn__transform_object__push_trans_2_0,
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i10),
		MR_ENTRY(mercury__fn__transform_object__push_trans_2_0));
MR_define_label(mercury__fn__transform_object__push_trans_2_0_i10);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__transform_object__push_trans_2_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (MR_Integer) 2, mercury__fn__transform_object__push_trans_2_0, "eval:object/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), MR_tempr1, (MR_Integer) 1) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
MR_define_label(mercury__fn__transform_object__push_trans_2_0_i11);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 0) != (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__transform_object__push_trans_2_0_i12);
	}
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 2);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_localcall(mercury__fn__transform_object__push_trans_2_0,
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i13),
		MR_ENTRY(mercury__fn__transform_object__push_trans_2_0));
MR_define_label(mercury__fn__transform_object__push_trans_2_0_i13);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__transform_object__push_trans_2_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__fn__transform_object__push_trans_2_0,
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i14),
		MR_ENTRY(mercury__fn__transform_object__push_trans_2_0));
MR_define_label(mercury__fn__transform_object__push_trans_2_0_i14);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__transform_object__push_trans_2_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 3, mercury__fn__transform_object__push_trans_2_0, "eval:object/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 0;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
MR_define_label(mercury__fn__transform_object__push_trans_2_0_i12);
	MR_stackvar(1) = MR_r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 2);
	MR_r2 = MR_const_field(MR_mktag(3), MR_r2, (MR_Integer) 1);
	MR_localcall(mercury__fn__transform_object__push_trans_2_0,
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i15),
		MR_ENTRY(mercury__fn__transform_object__push_trans_2_0));
MR_define_label(mercury__fn__transform_object__push_trans_2_0_i15);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__transform_object__push_trans_2_0));
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_r2 = MR_stackvar(2);
	}
	MR_localcall(mercury__fn__transform_object__push_trans_2_0,
		MR_LABEL(mercury__fn__transform_object__push_trans_2_0_i16),
		MR_ENTRY(mercury__fn__transform_object__push_trans_2_0));
MR_define_label(mercury__fn__transform_object__push_trans_2_0_i16);
	MR_update_prof_current_proc(MR_LABEL(mercury__fn__transform_object__push_trans_2_0));
	{
	MR_Word MR_tempr1;
	MR_tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (MR_Integer) 3, mercury__fn__transform_object__push_trans_2_0, "eval:object/0");
	MR_r3 = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 0) = (MR_Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (MR_Integer) 2) = MR_r1;
	MR_r1 = MR_tempr1;
	MR_succip = (MR_Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	MR_proceed();
	}
/* code for predicate 'compose_transformation'/3 in mode 0 */
MR_define_static(mercury__fn__transform_object__compose_transformation_2_0);
	MR_COMPUTED_GOTO((MR_Unsigned) MR_tag(MR_r1),
		MR_LABEL(mercury__fn__transform_object__compose_transformation_2_0_i4) MR_AND
		MR_LABEL(mercury__fn__transform_object__compose_transformation_2_0_i6) MR_AND
		MR_LABEL(mercury__fn__transform_object__compose_transformation_2_0_i8) MR_AND
		MR_LABEL(mercury__fn__transform_object__compose_transformation_2_0_i10));
MR_define_label(mercury__fn__transform_object__compose_transformation_2_0_i4);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r5 = MR_tempr1;
	MR_r1 = MR_const_field(MR_mktag(0), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_r2;
	MR_r2 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(0), MR_tempr1, (MR_Integer) 2);
	MR_tailcall(MR_ENTRY(mercury__fn__trans__compose_translate_4_0),
		MR_STATIC(mercury__fn__transform_object__compose_transformation_2_0));
	}
MR_define_label(mercury__fn__transform_object__compose_transformation_2_0_i6);
	{
	MR_Word MR_tempr1;
	MR_tempr1 = MR_r1;
	MR_r5 = MR_tempr1;
	MR_r1 = MR_const_field(MR_mktag(1), MR_r1, (MR_Integer) 0);
	MR_r4 = MR_r2;
	MR_r2 = MR_const_field(MR_mktag(1), MR_tempr1, (MR_Integer) 1);
	MR_r3 = MR_const_field(MR_mktag(1), MR_tempr1, (MR_Integer) 2);
	MR_tailcall(MR_ENTRY(mercury__fn__trans__compose_scale_4_0),
		MR_STATIC(mercury__fn__transform_object__compose_transformation_2_0));
	}
MR_define_label(mercury__fn__transform_object__compose_transformation_2_0_i8);
	MR_r1 = MR_const_field(MR_mktag(2), MR_r1, (MR_Integer) 0);
	MR_tailcall(MR_ENTRY(mercury__fn__trans__compose_uscale_2_0),
		MR_STATIC(mercury__fn__transform_object__compose_transformation_2_0));
MR_define_label(mercury__fn__transform_object__compose_transformation_2_0_i10);
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 0)) {
		MR_GOTO_LABEL(mercury__fn__transform_object__compose_transformation_2_0_i11);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 1)) {
		MR_GOTO_LABEL(mercury__fn__transform_object__compose_transformation_2_0_i13);
	}
	if (((MR_Integer) MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 0) == (MR_Integer) 2)) {
		MR_GOTO_LABEL(mercury__fn__transform_object__compose_transformation_2_0_i15);
	}
	MR_r1 = (MR_Word) MR_string_const("compose_transformation: this shouldn't happen??? i think???", 59);
	MR_tailcall(MR_ENTRY(mercury__require__error_1_0),
		MR_STATIC(mercury__fn__transform_object__compose_transformation_2_0));
MR_define_label(mercury__fn__transform_object__compose_transformation_2_0_i15);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_tailcall(MR_ENTRY(mercury__fn__trans__compose_rotatez_2_0),
		MR_STATIC(mercury__fn__transform_object__compose_transformation_2_0));
MR_define_label(mercury__fn__transform_object__compose_transformation_2_0_i13);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_tailcall(MR_ENTRY(mercury__fn__trans__compose_rotatey_2_0),
		MR_STATIC(mercury__fn__transform_object__compose_transformation_2_0));
MR_define_label(mercury__fn__transform_object__compose_transformation_2_0_i11);
	MR_r1 = MR_const_field(MR_mktag(3), MR_r1, (MR_Integer) 1);
	MR_tailcall(MR_ENTRY(mercury__fn__trans__compose_rotatex_2_0),
		MR_STATIC(mercury__fn__transform_object__compose_transformation_2_0));
MR_END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__transform_object_maybe_bunch_0(void)
{
	transform_object_module();
}

#endif

/* suppress gcc -Wmissing-decls warnings */
void mercury__transform_object__init(void);
void mercury__transform_object__init_type_tables(void);
void mercury__transform_object__init_debugger(void);
#ifdef MR_DEEP_PROFILING
void mercury__transform_object__write_out_proc_statics(FILE *fp);
#endif

void mercury__transform_object__init(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
	mercury__transform_object_maybe_bunch_0();
#endif

	mercury__transform_object__init_debugger();
}

void mercury__transform_object__init_type_tables(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}


void mercury__transform_object__init_debugger(void)
{
	static bool done = FALSE;
	if (done) {
		return;
	}
	done = TRUE;
}

#ifdef MR_DEEP_PROFILING

void mercury__transform_object__write_out_proc_statics(FILE *fp)
{
}

#endif

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
