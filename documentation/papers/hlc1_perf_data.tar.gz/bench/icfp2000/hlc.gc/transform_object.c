/*
** Automatically generated from `transform_object.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module transform_object. */
/* :- implementation. */

#include "transform_object.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.enum.h"
#include "eval.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "globals.h"
#include "gml.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "op.h"
#include "mercury.ops.h"
#include "peephole.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "renderer.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "space_partition.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.term.h"
#include "mercury.time.h"
#include "trans.h"
#include "transform_object.h"
#include "tree.h"
#include "mercury.tree234.h"
#include "vector.h"



#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL transform_object__foldl__ho3_4_p_in__list_0(
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word transform_object__HeadVar__2_2,
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word transform_object__HeadVar__3_3,
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * transform_object__HeadVar__4_4);
#line 78 "transform_object.m"
static MR_Word MR_CALL transform_object__compose_transformation_3_f_0(
#line 78 "transform_object.m"
  MR_Word transform_object__HeadVar__1_1,
#line 78 "transform_object.m"
  MR_Word transform_object__HeadVar__2_2);
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_1;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_2;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_3;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_4;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_5;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_6;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_7;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_8;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_9;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_10;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_11;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_12;
#line 43 "trans.opt"
static /* final */ const MR_Box transform_object__const_1_0_13_I_2_38[12];
#line 30 "trans.opt"
static /* final */ const MR_Box transform_object__const_1_0_14_V_32_32[2];




#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL transform_object__foldl__ho3_4_p_in__list_0(
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word transform_object__HeadVar__2_2,
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word transform_object__HeadVar__3_3,
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * transform_object__HeadVar__4_4)
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    /* tailcall optimized into a loop */
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  loop_top:;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      bool transform_object__succeeded;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Word transform_object__H_8_8;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Word transform_object__T_9_9;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Word transform_object__Acc1_12_12;

#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      if ((transform_object__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        *transform_object__HeadVar__4_4 = transform_object__HeadVar__3_3;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      else
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 150 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          transform_object__H_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), transform_object__HeadVar__2_2, (MR_Integer) 0)));
#line 150 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          transform_object__T_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), transform_object__HeadVar__2_2, (MR_Integer) 1)));
#line 159 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          {
#line 159 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            transform_object__Acc1_12_12 = transform_object__compose_transformation_3_f_0(transform_object__H_8_8, transform_object__HeadVar__3_3);
          }
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          {
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            /* direct tailcall eliminated */
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            {
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_Word transform_object__HeadVar__2__tmp_copy_2 = transform_object__T_9_9;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_Word transform_object__HeadVar__3__tmp_copy_3 = transform_object__Acc1_12_12;

#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              transform_object__HeadVar__2_2 = transform_object__HeadVar__2__tmp_copy_2;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              transform_object__HeadVar__3_3 = transform_object__HeadVar__3__tmp_copy_3;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            }
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            goto loop_top;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 78 "transform_object.m"
static MR_Word MR_CALL transform_object__compose_transformation_3_f_0(
#line 78 "transform_object.m"
  MR_Word transform_object__HeadVar__1_1,
#line 78 "transform_object.m"
  MR_Word transform_object__HeadVar__2_2)
#line 78 "transform_object.m"
{
#line 80 "transform_object.m"
  {
#line 80 "transform_object.m"
    bool transform_object__succeeded;
#line 80 "transform_object.m"
    MR_Word transform_object__HeadVar__3_3;

#line 80 "transform_object.m"
#line 80 "transform_object.m"
    switch (MR_tag((MR_Word) transform_object__HeadVar__1_1)) {
#line 80 "transform_object.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 80 "transform_object.m"
      case (MR_Integer) 3:
#line 80 "transform_object.m"
#line 80 "transform_object.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), transform_object__HeadVar__1_1, (MR_Integer) 0)))) {
#line 80 "transform_object.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 80 "transform_object.m"
          case (MR_Integer) 0:
            {
              MR_Float transform_object__X_14 = MR_unbox_float((MR_hl_field(MR_mktag(3), transform_object__HeadVar__1_1, (MR_Integer) 1)));

#line 83 "transform_object.m"
              {
#line 83 "transform_object.m"
                return transform_object__HeadVar__3_3 = trans__compose_rotatex_3_f_0(transform_object__X_14, transform_object__HeadVar__2_2);
              }
            }
#line 80 "transform_object.m"
            break;
#line 80 "transform_object.m"
          case (MR_Integer) 1:
            {
              MR_Float transform_object__Y_16 = MR_unbox_float((MR_hl_field(MR_mktag(3), transform_object__HeadVar__1_1, (MR_Integer) 1)));

#line 84 "transform_object.m"
              {
#line 84 "transform_object.m"
                return transform_object__HeadVar__3_3 = trans__compose_rotatey_3_f_0(transform_object__Y_16, transform_object__HeadVar__2_2);
              }
            }
#line 80 "transform_object.m"
            break;
#line 80 "transform_object.m"
          case (MR_Integer) 2:
            {
              MR_Float transform_object__Z_18 = MR_unbox_float((MR_hl_field(MR_mktag(3), transform_object__HeadVar__1_1, (MR_Integer) 1)));

#line 85 "transform_object.m"
              {
#line 85 "transform_object.m"
                return transform_object__HeadVar__3_3 = trans__compose_rotatez_3_f_0(transform_object__Z_18, transform_object__HeadVar__2_2);
              }
            }
#line 80 "transform_object.m"
            break;
#line 80 "transform_object.m"
          case (MR_Integer) 3:
            {
              MR_String transform_object__V_23_23 = (MR_String) "compose_transformation: this shouldn't happen??? i think???";

#line 87 "transform_object.m"
              {
#line 87 "transform_object.m"
                mercury__require__error_1_p_0(transform_object__V_23_23);
              }
            }
#line 80 "transform_object.m"
            break;
#line 80 "transform_object.m"
        }
#line 80 "transform_object.m"
        break;
#line 80 "transform_object.m"
      case (MR_Integer) 0:
        {
          MR_Float transform_object__X_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), transform_object__HeadVar__1_1, (MR_Integer) 0)));
          MR_Float transform_object__Y_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), transform_object__HeadVar__1_1, (MR_Integer) 1)));
          MR_Float transform_object__Z_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), transform_object__HeadVar__1_1, (MR_Integer) 2)));

#line 80 "transform_object.m"
          {
#line 80 "transform_object.m"
            return transform_object__HeadVar__3_3 = trans__compose_translate_5_f_0(transform_object__X_4, transform_object__Y_5, transform_object__Z_6, transform_object__HeadVar__2_2);
          }
        }
#line 80 "transform_object.m"
        break;
#line 80 "transform_object.m"
      case (MR_Integer) 1:
        {
          MR_Float transform_object__X_8 = MR_unbox_float((MR_hl_field(MR_mktag(1), transform_object__HeadVar__1_1, (MR_Integer) 0)));
          MR_Float transform_object__Y_9 = MR_unbox_float((MR_hl_field(MR_mktag(1), transform_object__HeadVar__1_1, (MR_Integer) 1)));
          MR_Float transform_object__Z_10 = MR_unbox_float((MR_hl_field(MR_mktag(1), transform_object__HeadVar__1_1, (MR_Integer) 2)));

#line 81 "transform_object.m"
          {
#line 81 "transform_object.m"
            return transform_object__HeadVar__3_3 = trans__compose_scale_5_f_0(transform_object__X_8, transform_object__Y_9, transform_object__Z_10, transform_object__HeadVar__2_2);
          }
        }
#line 80 "transform_object.m"
        break;
#line 80 "transform_object.m"
      case (MR_Integer) 2:
        {
          MR_Float transform_object__X_12 = MR_unbox_float((MR_hl_field(MR_mktag(2), transform_object__HeadVar__1_1, (MR_Integer) 0)));

#line 82 "transform_object.m"
          {
#line 82 "transform_object.m"
            return transform_object__HeadVar__3_3 = trans__compose_uscale_3_f_0(transform_object__X_12, transform_object__HeadVar__2_2);
          }
        }
#line 80 "transform_object.m"
        break;
#line 80 "transform_object.m"
    }
#line 80 "transform_object.m"
    return transform_object__HeadVar__3_3;
#line 80 "transform_object.m"
  }
#line 78 "transform_object.m"
}
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_1 = (MR_Float) 1.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_2 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_3 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_4 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_5 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_6 = (MR_Float) 1.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_7 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_8 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_9 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_10 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_11 = (MR_Float) 1.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float transform_object__float_1_0_12 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Box transform_object__const_1_0_13_I_2_38[12] = {
		(MR_Box) &transform_object__float_1_0_1,
		(MR_Box) &transform_object__float_1_0_2,
		(MR_Box) &transform_object__float_1_0_3,
		(MR_Box) &transform_object__float_1_0_4,
		(MR_Box) &transform_object__float_1_0_5,
		(MR_Box) &transform_object__float_1_0_6,
		(MR_Box) &transform_object__float_1_0_7,
		(MR_Box) &transform_object__float_1_0_8,
		(MR_Box) &transform_object__float_1_0_9,
		(MR_Box) &transform_object__float_1_0_10,
		(MR_Box) &transform_object__float_1_0_11,
		(MR_Box) &transform_object__float_1_0_12};
#line 30 "trans.opt"
static /* final */ const MR_Box transform_object__const_1_0_14_V_32_32[2] = {
		((MR_Box) (&transform_object__const_1_0_13_I_2_38)),
		((MR_Box) (&transform_object__const_1_0_13_I_2_38))};

#line 49 "transform_object.m"
MR_Word MR_CALL transform_object__push_trans_3_f_0(
#line 49 "transform_object.m"
  MR_Word transform_object__HeadVar__1_1,
#line 49 "transform_object.m"
  MR_Word transform_object__HeadVar__2_2)
#line 49 "transform_object.m"
{
#line 51 "transform_object.m"
  {
#line 51 "transform_object.m"
    /* tailcall optimized into a loop */
#line 51 "transform_object.m"
  loop_top:;
#line 51 "transform_object.m"
    {
#line 51 "transform_object.m"
      bool transform_object__succeeded;
#line 51 "transform_object.m"
      MR_Word transform_object__HeadVar__3_3;

#line 51 "transform_object.m"
#line 51 "transform_object.m"
      switch (MR_tag((MR_Word) transform_object__HeadVar__2_2)) {
#line 51 "transform_object.m"
        default: /*NOTREACHED*/ MR_assert(0);
#line 51 "transform_object.m"
        case (MR_Integer) 3:
#line 51 "transform_object.m"
#line 51 "transform_object.m"
          switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), transform_object__HeadVar__2_2, (MR_Integer) 0)))) {
#line 51 "transform_object.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 51 "transform_object.m"
            case (MR_Integer) 0:
              {
                MR_Word transform_object__Object1_26 = ((MR_Word) (MR_hl_field(MR_mktag(3), transform_object__HeadVar__2_2, (MR_Integer) 1)));
                MR_Word transform_object__Object2_27 = ((MR_Word) (MR_hl_field(MR_mktag(3), transform_object__HeadVar__2_2, (MR_Integer) 2)));
                MR_Word transform_object__V_28_28;
                MR_Word transform_object__V_29_29;

#line 65 "transform_object.m"
                {
#line 65 "transform_object.m"
                  transform_object__V_28_28 = transform_object__push_trans_3_f_0(transform_object__HeadVar__1_1, transform_object__Object1_26);
                }
#line 65 "transform_object.m"
                {
#line 65 "transform_object.m"
                  transform_object__V_29_29 = transform_object__push_trans_3_f_0(transform_object__HeadVar__1_1, transform_object__Object2_27);
                }
#line 64 "transform_object.m"
                {
#line 64 "transform_object.m"
                  transform_object__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "intersect"));
#line 64 "transform_object.m"
                  MR_hl_field(MR_mktag(3), transform_object__HeadVar__3_3, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 0));
#line 64 "transform_object.m"
                  MR_hl_field(MR_mktag(3), transform_object__HeadVar__3_3, 1) = ((MR_Box) (transform_object__V_28_28));
#line 64 "transform_object.m"
                  MR_hl_field(MR_mktag(3), transform_object__HeadVar__3_3, 2) = ((MR_Box) (transform_object__V_29_29));
#line 64 "transform_object.m"
                }
              }
#line 51 "transform_object.m"
              break;
#line 51 "transform_object.m"
            case (MR_Integer) 1:
              {
                MR_Word transform_object__Object1_21 = ((MR_Word) (MR_hl_field(MR_mktag(3), transform_object__HeadVar__2_2, (MR_Integer) 1)));
                MR_Word transform_object__Object2_22 = ((MR_Word) (MR_hl_field(MR_mktag(3), transform_object__HeadVar__2_2, (MR_Integer) 2)));
                MR_Word transform_object__V_23_23;
                MR_Word transform_object__V_24_24;

#line 62 "transform_object.m"
                {
#line 62 "transform_object.m"
                  transform_object__V_23_23 = transform_object__push_trans_3_f_0(transform_object__HeadVar__1_1, transform_object__Object1_21);
                }
#line 62 "transform_object.m"
                {
#line 62 "transform_object.m"
                  transform_object__V_24_24 = transform_object__push_trans_3_f_0(transform_object__HeadVar__1_1, transform_object__Object2_22);
                }
#line 61 "transform_object.m"
                {
#line 61 "transform_object.m"
                  transform_object__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "difference"));
#line 61 "transform_object.m"
                  MR_hl_field(MR_mktag(3), transform_object__HeadVar__3_3, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 1));
#line 61 "transform_object.m"
                  MR_hl_field(MR_mktag(3), transform_object__HeadVar__3_3, 1) = ((MR_Box) (transform_object__V_23_23));
#line 61 "transform_object.m"
                  MR_hl_field(MR_mktag(3), transform_object__HeadVar__3_3, 2) = ((MR_Box) (transform_object__V_24_24));
#line 61 "transform_object.m"
                }
              }
#line 51 "transform_object.m"
              break;
#line 51 "transform_object.m"
          }
#line 51 "transform_object.m"
          break;
#line 51 "transform_object.m"
        case (MR_Integer) 0:
          {
            MR_Word transform_object__V_9_9;
            MR_Word transform_object__V_10_10;
            MR_Word transform_object__V_32_32 = (MR_Word) &transform_object__const_1_0_14_V_32_32;
            MR_Word transform_object__I_2_38 = (MR_Word) &transform_object__const_1_0_13_I_2_38;
            MR_Float transform_object__V_2_40 = (MR_Float) 1.00000000000000;
            MR_Float transform_object__V_3_41 = (MR_Float) 0.00000000000000;
            MR_Float transform_object__V_4_42 = (MR_Float) 0.00000000000000;
            MR_Float transform_object__V_5_43 = (MR_Float) 0.00000000000000;
            MR_Float transform_object__V_6_44 = (MR_Float) 0.00000000000000;
            MR_Float transform_object__V_7_45 = (MR_Float) 1.00000000000000;
            MR_Float transform_object__V_8_46 = (MR_Float) 0.00000000000000;
            MR_Float transform_object__V_9_47 = (MR_Float) 0.00000000000000;
            MR_Float transform_object__V_10_48 = (MR_Float) 0.00000000000000;
            MR_Float transform_object__V_11_49 = (MR_Float) 0.00000000000000;
            MR_Float transform_object__V_12_50 = (MR_Float) 1.00000000000000;
            MR_Float transform_object__V_13_51 = (MR_Float) 0.00000000000000;

#line 162 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            {
#line 162 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              transform_object__foldl__ho3_4_p_in__list_0(transform_object__HeadVar__1_1, transform_object__V_32_32, &transform_object__V_10_10);
            }
#line 52 "transform_object.m"
            {
#line 52 "transform_object.m"
              transform_object__V_9_9 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "matrix"));
#line 52 "transform_object.m"
              MR_hl_field(MR_mktag(3), transform_object__V_9_9, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 3));
#line 52 "transform_object.m"
              MR_hl_field(MR_mktag(3), transform_object__V_9_9, 1) = ((MR_Box) (transform_object__V_10_10));
#line 52 "transform_object.m"
            }
#line 51 "transform_object.m"
            {
#line 51 "transform_object.m"
              transform_object__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "transform"));
#line 51 "transform_object.m"
              MR_hl_field(MR_mktag(1), transform_object__HeadVar__3_3, 0) = ((MR_Box) (transform_object__HeadVar__2_2));
#line 51 "transform_object.m"
              MR_hl_field(MR_mktag(1), transform_object__HeadVar__3_3, 1) = ((MR_Box) (transform_object__V_9_9));
#line 51 "transform_object.m"
            }
          }
#line 51 "transform_object.m"
          break;
#line 51 "transform_object.m"
        case (MR_Integer) 1:
          {
            MR_Word transform_object__Obj_12 = ((MR_Word) (MR_hl_field(MR_mktag(1), transform_object__HeadVar__2_2, (MR_Integer) 0)));
            MR_Word transform_object__T_13 = ((MR_Word) (MR_hl_field(MR_mktag(1), transform_object__HeadVar__2_2, (MR_Integer) 1)));
            MR_Word transform_object__V_14_14;

#line 56 "transform_object.m"
            {
#line 56 "transform_object.m"
              transform_object__V_14_14 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 56 "transform_object.m"
              MR_hl_field(MR_mktag(1), transform_object__V_14_14, 0) = ((MR_Box) (transform_object__T_13));
#line 56 "transform_object.m"
              MR_hl_field(MR_mktag(1), transform_object__V_14_14, 1) = ((MR_Box) (transform_object__HeadVar__1_1));
#line 56 "transform_object.m"
            }
#line 55 "transform_object.m"
            {
#line 55 "transform_object.m"
              /* direct tailcall eliminated */
#line 55 "transform_object.m"
              {
#line 55 "transform_object.m"
                MR_Word transform_object__HeadVar__1__tmp_copy_1 = transform_object__V_14_14;
#line 55 "transform_object.m"
                MR_Word transform_object__HeadVar__2__tmp_copy_2 = transform_object__Obj_12;

#line 55 "transform_object.m"
                transform_object__HeadVar__1_1 = transform_object__HeadVar__1__tmp_copy_1;
#line 55 "transform_object.m"
                transform_object__HeadVar__2_2 = transform_object__HeadVar__2__tmp_copy_2;
#line 55 "transform_object.m"
              }
#line 55 "transform_object.m"
              goto loop_top;
#line 55 "transform_object.m"
            }
          }
#line 51 "transform_object.m"
          break;
#line 51 "transform_object.m"
        case (MR_Integer) 2:
          {
            MR_Word transform_object__Object1_16 = ((MR_Word) (MR_hl_field(MR_mktag(2), transform_object__HeadVar__2_2, (MR_Integer) 0)));
            MR_Word transform_object__Object2_17 = ((MR_Word) (MR_hl_field(MR_mktag(2), transform_object__HeadVar__2_2, (MR_Integer) 1)));
            MR_Word transform_object__V_18_18;
            MR_Word transform_object__V_19_19;

#line 59 "transform_object.m"
            {
#line 59 "transform_object.m"
              transform_object__V_18_18 = transform_object__push_trans_3_f_0(transform_object__HeadVar__1_1, transform_object__Object1_16);
            }
#line 59 "transform_object.m"
            {
#line 59 "transform_object.m"
              transform_object__V_19_19 = transform_object__push_trans_3_f_0(transform_object__HeadVar__1_1, transform_object__Object2_17);
            }
#line 58 "transform_object.m"
            {
#line 58 "transform_object.m"
              transform_object__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "union"));
#line 58 "transform_object.m"
              MR_hl_field(MR_mktag(2), transform_object__HeadVar__3_3, 0) = ((MR_Box) (transform_object__V_18_18));
#line 58 "transform_object.m"
              MR_hl_field(MR_mktag(2), transform_object__HeadVar__3_3, 1) = ((MR_Box) (transform_object__V_19_19));
#line 58 "transform_object.m"
            }
          }
#line 51 "transform_object.m"
          break;
#line 51 "transform_object.m"
      }
#line 51 "transform_object.m"
      return transform_object__HeadVar__3_3;
#line 51 "transform_object.m"
    }
#line 51 "transform_object.m"
  }
#line 49 "transform_object.m"
}

#line 19 "transform_object.m"
MR_Word MR_CALL transform_object__push_transformations_2_f_0(
#line 19 "transform_object.m"
  MR_Word transform_object__HeadVar__1_1)
#line 19 "transform_object.m"
{
  {
    bool transform_object__succeeded;
    MR_Word transform_object__HeadVar__2_2;
    MR_Word transform_object__V_4_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));

#line 33 "transform_object.m"
    {
#line 33 "transform_object.m"
      return transform_object__HeadVar__2_2 = transform_object__push_trans_3_f_0(transform_object__V_4_4, transform_object__HeadVar__1_1);
    }
    return transform_object__HeadVar__2_2;
  }
#line 19 "transform_object.m"
}

void mercury__transform_object__init(void)
{
}

void mercury__transform_object__init_type_tables(void)
{
}

void mercury__transform_object__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module transform_object. */
