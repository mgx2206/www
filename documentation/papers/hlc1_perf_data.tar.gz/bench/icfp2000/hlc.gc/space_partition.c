/*
** Automatically generated from `space_partition.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module space_partition. */
/* :- implementation. */

#include "space_partition.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.enum.h"
#include "eval.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "globals.h"
#include "gml.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "op.h"
#include "mercury.ops.h"
#include "peephole.h"
#include "precompute_lights.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "renderer.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "space_partition.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.term.h"
#include "mercury.time.h"
#include "trans.h"
#include "transform_object.h"
#include "tree.h"
#include "mercury.tree234.h"
#include "vector.h"



static const MR_DuFunctorDescPtr space_partition__space_partition__du_name_ordered_subtree_result_0[1];
static const MR_DuFunctorDesc space_partition__space_partition__du_functor_desc_subtree_result_0_0;
static const MR_PseudoTypeInfo space_partition__space_partition__field_types_subtree_result_0_0[3];
static const MR_FO_PseudoTypeInfo_Struct2 space_partition__std_util__type_info_pair_2__type0_16_vector__vector_0__type0_16_vector__vector_0;
static const MR_DuPtagLayout space_partition__space_partition__du_ptag_ordered_subtree_result_0[1];
static const MR_DuFunctorDescPtr space_partition__space_partition__du_stag_ordered_subtree_result_0_0[1];
static const MR_DuFunctorDescPtr space_partition__space_partition__du_name_ordered_space_tree_object_0[1];
static const MR_DuFunctorDesc space_partition__space_partition__du_functor_desc_space_tree_object_0_0;
static const MR_PseudoTypeInfo space_partition__space_partition__field_types_space_tree_object_0_0[3];
static const MR_DuPtagLayout space_partition__space_partition__du_ptag_ordered_space_tree_object_0[1];
static const MR_DuFunctorDescPtr space_partition__space_partition__du_stag_ordered_space_tree_object_0_0[1];
static const MR_DuFunctorDescPtr space_partition__space_partition__du_name_ordered_space_tree_node_0[2];
static const MR_DuFunctorDesc space_partition__space_partition__du_functor_desc_space_tree_node_0_0;
static const MR_PseudoTypeInfo space_partition__space_partition__field_types_space_tree_node_0_0[1];
static const MR_DuFunctorDesc space_partition__space_partition__du_functor_desc_space_tree_node_0_1;
static const MR_PseudoTypeInfo space_partition__space_partition__field_types_space_tree_node_0_1[1];
static const MR_DuPtagLayout space_partition__space_partition__du_ptag_ordered_space_tree_node_0[2];
static const MR_DuFunctorDescPtr space_partition__space_partition__du_stag_ordered_space_tree_node_0_0[1];
static const MR_DuFunctorDescPtr space_partition__space_partition__du_stag_ordered_space_tree_node_0_1[1];
static const MR_DuFunctorDescPtr space_partition__space_partition__du_name_ordered_space_tree_0[1];
static const MR_DuFunctorDesc space_partition__space_partition__du_functor_desc_space_tree_0_0;
static const MR_PseudoTypeInfo space_partition__space_partition__field_types_space_tree_0_0[3];
static const MR_FO_PseudoTypeInfo_Struct1 space_partition__list__type_info_list_1__type0_34_space_partition__space_tree_node_0;
static const MR_DuPtagLayout space_partition__space_partition__du_ptag_ordered_space_tree_0[1];
static const MR_DuFunctorDescPtr space_partition__space_partition__du_stag_ordered_space_tree_0_0[1];
static const MR_DuFunctorDescPtr space_partition__space_partition__du_name_ordered_scene_0[1];
static const MR_DuFunctorDesc space_partition__space_partition__du_functor_desc_scene_0_0;
static const MR_PseudoTypeInfo space_partition__space_partition__field_types_scene_0_0[2];
static const MR_FO_PseudoTypeInfo_Struct1 space_partition__list__type_info_list_1__type0_14_eval__object_0;
static const MR_DuPtagLayout space_partition__space_partition__du_ptag_ordered_scene_0[1];
static const MR_DuFunctorDescPtr space_partition__space_partition__du_stag_ordered_scene_0_0[1];
static const MR_NotagFunctorDesc space_partition__space_partition__notag_functor_desc_invalid_transformation_0;
static const MR_NotagFunctorDesc space_partition__space_partition__notag_functor_desc_invalid_object_0;
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL space_partition__map__ho6__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word space_partition__V_15_15,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word space_partition__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * space_partition__HeadVar__3_3);
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
static void MR_CALL space_partition__DeforestationIn__pred__build_space_tree__128__0_3_p_0(
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word space_partition__HeadVar__1_1,
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word * space_partition__HeadVar__2_2,
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word space_partition__Tree0_11);
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL space_partition__map__ho7_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word space_partition__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * space_partition__HeadVar__3_3);
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL space_partition__foldl__ho3_4_p_in__list_0(
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word space_partition__HeadVar__2_2,
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word space_partition__HeadVar__3_3,
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * space_partition__HeadVar__4_4);
#line 253 "space_partition.m"
static MR_Word MR_CALL space_partition__IntroducedFrom__func__build_space_tree__253__2_2_f_0(
#line 253 "space_partition.m"
  MR_Word space_partition__V_19_19);
#line 511 "space_partition.m"
static void MR_CALL space_partition__traverse_space_tree_nodes_5_p_0(
#line 511 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 511 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 511 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3,
#line 511 "space_partition.m"
  MR_Word space_partition__HeadVar__4_4,
#line 511 "space_partition.m"
  MR_Word * space_partition__HeadVar__5_5);
#line 402 "space_partition.m"
static bool MR_CALL space_partition__intersect_bounding_box_2_12_p_0(
#line 402 "space_partition.m"
  MR_Float space_partition__XRay_1,
#line 402 "space_partition.m"
  MR_Float space_partition__YRay_2,
#line 402 "space_partition.m"
  MR_Float space_partition__ZRay_3,
#line 402 "space_partition.m"
  MR_Float space_partition__XDir_4,
#line 402 "space_partition.m"
  MR_Float space_partition__YDir_5,
#line 402 "space_partition.m"
  MR_Float space_partition__ZDir_6,
#line 402 "space_partition.m"
  MR_Float space_partition__XMin_7,
#line 402 "space_partition.m"
  MR_Float space_partition__YMin_8,
#line 402 "space_partition.m"
  MR_Float space_partition__ZMin_9,
#line 402 "space_partition.m"
  MR_Float space_partition__XMax_10,
#line 402 "space_partition.m"
  MR_Float space_partition__YMax_11,
#line 402 "space_partition.m"
  MR_Float space_partition__ZMax_12);
#line 349 "space_partition.m"
static void MR_CALL space_partition__subtree_insert_4_p_0(
#line 349 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 349 "space_partition.m"
  MR_Integer space_partition__HeadVar__2_2,
#line 349 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3,
#line 349 "space_partition.m"
  MR_Word * space_partition__HeadVar__4_4);
#line 326 "space_partition.m"
static void MR_CALL space_partition__select_subtree_5_p_0(
#line 326 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 326 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 326 "space_partition.m"
  MR_Integer space_partition__HeadVar__3_3,
#line 326 "space_partition.m"
  MR_Word space_partition__HeadVar__4_4,
#line 326 "space_partition.m"
  MR_Integer * space_partition__HeadVar__5_5);
#line 293 "space_partition.m"
static void MR_CALL space_partition__space_tree_insert_3_p_0(
#line 293 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 293 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 293 "space_partition.m"
  MR_Word * space_partition__HeadVar__3_3);
#line 184 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_1;
#line 184 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_2;
#line 184 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_3;
#line 184 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_4_V_4_4[3];
#line 184 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_5;
#line 184 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_6;
#line 184 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_7;
#line 184 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_8_V_5_5[3];
#line 183 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_9_HeadVar__2_2[2];
#line 187 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_10;
#line 187 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_11;
#line 187 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_12;
#line 187 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_13_V_13_13[3];
#line 187 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_14;
#line 187 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_15;
#line 187 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_16;
#line 187 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_17_V_14_14[3];
#line 186 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_18_HeadVar__2_2[2];
#line 190 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_19;
#line 190 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_20;
#line 190 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_21;
#line 190 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_22_V_22_22[3];
#line 190 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_23;
#line 190 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_24;
#line 190 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_25;
#line 190 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_26_V_23_23[3];
#line 189 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_27_HeadVar__2_2[2];
#line 181 "space_partition.m"
static MR_Word MR_CALL space_partition__find_basic_object_bounding_box_2_f_0(
#line 181 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1);
#line 161 "space_partition.m"
static MR_Word MR_CALL space_partition__max_point_3_f_0(
#line 161 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 161 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2);
#line 156 "space_partition.m"
static MR_Word MR_CALL space_partition__min_point_3_f_0(
#line 156 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 156 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2);
#line 127 "space_partition.m"
static MR_Word MR_CALL space_partition__object_contains_plane_2_f_0(
#line 127 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1);

#line 450 "space_partition.m"

Bool HitBoundingBox(double minB[3],double maxB[3], double origin[3],
		double dir[3], double coord[3])
{
	char inside = TRUE;
	char quadrant[NUMDIM];
	register int i;
	int whichPlane;
	double maxT[NUMDIM];
	double candidatePlane[NUMDIM];

	/* Find candidate planes; this loop can be avoided if
   	rays cast all from the eye(assume perpsective view) */
	for (i=0; i<NUMDIM; i++)
		if(origin[i] < minB[i]) {
			quadrant[i] = LEFT;
			candidatePlane[i] = minB[i];
			inside = FALSE;
		}else if (origin[i] > maxB[i]) {
			quadrant[i] = RIGHT;
			candidatePlane[i] = maxB[i];
			inside = FALSE;
		}else	{
			quadrant[i] = MIDDLE;
		}

	/* Ray origin inside bounding box */
	if(inside)	{
		coord = origin;
		return (TRUE);
	}


	/* Calculate T distances to candidate planes */
	for (i = 0; i < NUMDIM; i++)
		if (quadrant[i] != MIDDLE && dir[i] !=0.)
			maxT[i] = (candidatePlane[i]-origin[i]) / dir[i];
		else
			maxT[i] = -1.;

	/* Get largest of the maxT's for final choice of intersection */
	whichPlane = 0;
	for (i = 1; i < NUMDIM; i++)
		if (maxT[whichPlane] < maxT[i])
			whichPlane = i;

	/* Check final candidate actually inside box */
	if (maxT[whichPlane] < 0.) {
		return (FALSE);
	}
	for (i = 0; i < NUMDIM; i++)
		if (whichPlane != i) {
			coord[i] = origin[i] + maxT[whichPlane] *dir[i];
			if (coord[i] < minB[i] || coord[i] > maxB[i])
				return (FALSE);
		} else {
			coord[i] = candidatePlane[i];
		}
	return (TRUE);				/* ray hits box */
}

const MR_TypeCtorInfo_Struct space_partition__space_partition__type_ctor_info_surface_area_0 = {
		(MR_Integer) 0,
		((MR_Box) (space_partition____Unify____surface_area_0_0)),
		((MR_Box) (space_partition____Unify____surface_area_0_0)),
		((MR_Box) (space_partition____Compare____surface_area_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "space_partition",
		(MR_String) "surface_area",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&mercury__builtin____type_ctor_info_float_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct space_partition__space_partition__type_ctor_info_subtree_result_0 = {
		(MR_Integer) 0,
		((MR_Box) (space_partition____Unify____subtree_result_0_0)),
		((MR_Box) (space_partition____Unify____subtree_result_0_0)),
		((MR_Box) (space_partition____Compare____subtree_result_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "space_partition",
		(MR_String) "subtree_result",
		(MR_Integer) 4,
		{
		(MR_Box) space_partition__space_partition__du_name_ordered_subtree_result_0},
		{
		(MR_Box) space_partition__space_partition__du_ptag_ordered_subtree_result_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct space_partition__space_partition__type_ctor_info_space_tree_object_0 = {
		(MR_Integer) 0,
		((MR_Box) (space_partition____Unify____space_tree_object_0_0)),
		((MR_Box) (space_partition____Unify____space_tree_object_0_0)),
		((MR_Box) (space_partition____Compare____space_tree_object_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "space_partition",
		(MR_String) "space_tree_object",
		(MR_Integer) 4,
		{
		(MR_Box) space_partition__space_partition__du_name_ordered_space_tree_object_0},
		{
		(MR_Box) space_partition__space_partition__du_ptag_ordered_space_tree_object_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct space_partition__space_partition__type_ctor_info_space_tree_node_0 = {
		(MR_Integer) 0,
		((MR_Box) (space_partition____Unify____space_tree_node_0_0)),
		((MR_Box) (space_partition____Unify____space_tree_node_0_0)),
		((MR_Box) (space_partition____Compare____space_tree_node_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "space_partition",
		(MR_String) "space_tree_node",
		(MR_Integer) 4,
		{
		(MR_Box) space_partition__space_partition__du_name_ordered_space_tree_node_0},
		{
		(MR_Box) space_partition__space_partition__du_ptag_ordered_space_tree_node_0},
		(MR_Integer) 2,
		(MR_Integer) 2};
const MR_TypeCtorInfo_Struct space_partition__space_partition__type_ctor_info_space_tree_0 = {
		(MR_Integer) 0,
		((MR_Box) (space_partition____Unify____space_tree_0_0)),
		((MR_Box) (space_partition____Unify____space_tree_0_0)),
		((MR_Box) (space_partition____Compare____space_tree_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "space_partition",
		(MR_String) "space_tree",
		(MR_Integer) 4,
		{
		(MR_Box) space_partition__space_partition__du_name_ordered_space_tree_0},
		{
		(MR_Box) space_partition__space_partition__du_ptag_ordered_space_tree_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct space_partition__space_partition__type_ctor_info_scene_0 = {
		(MR_Integer) 0,
		((MR_Box) (space_partition____Unify____scene_0_0)),
		((MR_Box) (space_partition____Unify____scene_0_0)),
		((MR_Box) (space_partition____Compare____scene_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "space_partition",
		(MR_String) "scene",
		(MR_Integer) 4,
		{
		(MR_Box) space_partition__space_partition__du_name_ordered_scene_0},
		{
		(MR_Box) space_partition__space_partition__du_ptag_ordered_scene_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct space_partition__space_partition__type_ctor_info_normal_0 = {
		(MR_Integer) 0,
		((MR_Box) (space_partition____Unify____normal_0_0)),
		((MR_Box) (space_partition____Unify____normal_0_0)),
		((MR_Box) (space_partition____Compare____normal_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "space_partition",
		(MR_String) "normal",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&vector__vector__type_ctor_info_vector_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct space_partition__space_partition__type_ctor_info_invalid_transformation_0 = {
		(MR_Integer) 0,
		((MR_Box) (space_partition____Unify____invalid_transformation_0_0)),
		((MR_Box) (space_partition____Unify____invalid_transformation_0_0)),
		((MR_Box) (space_partition____Compare____invalid_transformation_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_NOTAG_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "space_partition",
		(MR_String) "invalid_transformation",
		(MR_Integer) 4,
		{
		(MR_Box) (&space_partition__space_partition__notag_functor_desc_invalid_transformation_0)},
		{
		(MR_Box) (&space_partition__space_partition__notag_functor_desc_invalid_transformation_0)},
		(MR_Integer) 1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct space_partition__space_partition__type_ctor_info_invalid_object_0 = {
		(MR_Integer) 0,
		((MR_Box) (space_partition____Unify____invalid_object_0_0)),
		((MR_Box) (space_partition____Unify____invalid_object_0_0)),
		((MR_Box) (space_partition____Compare____invalid_object_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_NOTAG_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "space_partition",
		(MR_String) "invalid_object",
		(MR_Integer) 4,
		{
		(MR_Box) (&space_partition__space_partition__notag_functor_desc_invalid_object_0)},
		{
		(MR_Box) (&space_partition__space_partition__notag_functor_desc_invalid_object_0)},
		(MR_Integer) 1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct space_partition__space_partition__type_ctor_info_bounding_box_0 = {
		(MR_Integer) 0,
		((MR_Box) (space_partition____Unify____bounding_box_0_0)),
		((MR_Box) (space_partition____Unify____bounding_box_0_0)),
		((MR_Box) (space_partition____Compare____bounding_box_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "space_partition",
		(MR_String) "bounding_box",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&space_partition__std_util__type_info_pair_2__type0_16_vector__vector_0__type0_16_vector__vector_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
static const MR_DuFunctorDescPtr space_partition__space_partition__du_name_ordered_subtree_result_0[1] = {
		(&space_partition__space_partition__du_functor_desc_subtree_result_0_0)};
static const MR_DuFunctorDesc space_partition__space_partition__du_functor_desc_subtree_result_0_0 = {
		(MR_String) "subtree_result",
		(MR_Integer) 3,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		space_partition__space_partition__field_types_subtree_result_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo space_partition__space_partition__field_types_subtree_result_0_0[3] = {
		(MR_PseudoTypeInfo) (&space_partition__std_util__type_info_pair_2__type0_16_vector__vector_0__type0_16_vector__vector_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0)};
static const MR_FO_PseudoTypeInfo_Struct2 space_partition__std_util__type_info_pair_2__type0_16_vector__vector_0__type0_16_vector__vector_0 = {
		(&mercury__std_util__std_util__type_ctor_info_pair_2),
		{
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0),
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0)}};
static const MR_DuPtagLayout space_partition__space_partition__du_ptag_ordered_subtree_result_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		space_partition__space_partition__du_stag_ordered_subtree_result_0_0}};
static const MR_DuFunctorDescPtr space_partition__space_partition__du_stag_ordered_subtree_result_0_0[1] = {
		(&space_partition__space_partition__du_functor_desc_subtree_result_0_0)};
static const MR_DuFunctorDescPtr space_partition__space_partition__du_name_ordered_space_tree_object_0[1] = {
		(&space_partition__space_partition__du_functor_desc_space_tree_object_0_0)};
static const MR_DuFunctorDesc space_partition__space_partition__du_functor_desc_space_tree_object_0_0 = {
		(MR_String) "space_tree_object",
		(MR_Integer) 3,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		space_partition__space_partition__field_types_space_tree_object_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo space_partition__space_partition__field_types_space_tree_object_0_0[3] = {
		(MR_PseudoTypeInfo) (&space_partition__std_util__type_info_pair_2__type0_16_vector__vector_0__type0_16_vector__vector_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_object_0)};
static const MR_DuPtagLayout space_partition__space_partition__du_ptag_ordered_space_tree_object_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		space_partition__space_partition__du_stag_ordered_space_tree_object_0_0}};
static const MR_DuFunctorDescPtr space_partition__space_partition__du_stag_ordered_space_tree_object_0_0[1] = {
		(&space_partition__space_partition__du_functor_desc_space_tree_object_0_0)};
static const MR_DuFunctorDescPtr space_partition__space_partition__du_name_ordered_space_tree_node_0[2] = {
		(&space_partition__space_partition__du_functor_desc_space_tree_node_0_1),
		(&space_partition__space_partition__du_functor_desc_space_tree_node_0_0)};
static const MR_DuFunctorDesc space_partition__space_partition__du_functor_desc_space_tree_node_0_0 = {
		(MR_String) "node",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		space_partition__space_partition__field_types_space_tree_node_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo space_partition__space_partition__field_types_space_tree_node_0_0[1] = {
		(MR_PseudoTypeInfo) (&space_partition__space_partition__type_ctor_info_space_tree_0)};
static const MR_DuFunctorDesc space_partition__space_partition__du_functor_desc_space_tree_node_0_1 = {
		(MR_String) "leaf",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		space_partition__space_partition__field_types_space_tree_node_0_1,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo space_partition__space_partition__field_types_space_tree_node_0_1[1] = {
		(MR_PseudoTypeInfo) (&space_partition__space_partition__type_ctor_info_space_tree_object_0)};
static const MR_DuPtagLayout space_partition__space_partition__du_ptag_ordered_space_tree_node_0[2] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		space_partition__space_partition__du_stag_ordered_space_tree_node_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		space_partition__space_partition__du_stag_ordered_space_tree_node_0_1}};
static const MR_DuFunctorDescPtr space_partition__space_partition__du_stag_ordered_space_tree_node_0_0[1] = {
		(&space_partition__space_partition__du_functor_desc_space_tree_node_0_0)};
static const MR_DuFunctorDescPtr space_partition__space_partition__du_stag_ordered_space_tree_node_0_1[1] = {
		(&space_partition__space_partition__du_functor_desc_space_tree_node_0_1)};
static const MR_DuFunctorDescPtr space_partition__space_partition__du_name_ordered_space_tree_0[1] = {
		(&space_partition__space_partition__du_functor_desc_space_tree_0_0)};
static const MR_DuFunctorDesc space_partition__space_partition__du_functor_desc_space_tree_0_0 = {
		(MR_String) "space_tree",
		(MR_Integer) 3,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		space_partition__space_partition__field_types_space_tree_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo space_partition__space_partition__field_types_space_tree_0_0[3] = {
		(MR_PseudoTypeInfo) (&space_partition__std_util__type_info_pair_2__type0_16_vector__vector_0__type0_16_vector__vector_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&space_partition__list__type_info_list_1__type0_34_space_partition__space_tree_node_0)};
static const MR_FO_PseudoTypeInfo_Struct1 space_partition__list__type_info_list_1__type0_34_space_partition__space_tree_node_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&space_partition__space_partition__type_ctor_info_space_tree_node_0)}};
static const MR_DuPtagLayout space_partition__space_partition__du_ptag_ordered_space_tree_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		space_partition__space_partition__du_stag_ordered_space_tree_0_0}};
static const MR_DuFunctorDescPtr space_partition__space_partition__du_stag_ordered_space_tree_0_0[1] = {
		(&space_partition__space_partition__du_functor_desc_space_tree_0_0)};
static const MR_DuFunctorDescPtr space_partition__space_partition__du_name_ordered_scene_0[1] = {
		(&space_partition__space_partition__du_functor_desc_scene_0_0)};
static const MR_DuFunctorDesc space_partition__space_partition__du_functor_desc_scene_0_0 = {
		(MR_String) "scene",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		space_partition__space_partition__field_types_scene_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo space_partition__space_partition__field_types_scene_0_0[2] = {
		(MR_PseudoTypeInfo) (&space_partition__space_partition__type_ctor_info_space_tree_0),
		(MR_PseudoTypeInfo) (&space_partition__list__type_info_list_1__type0_14_eval__object_0)};
static const MR_FO_PseudoTypeInfo_Struct1 space_partition__list__type_info_list_1__type0_14_eval__object_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_object_0)}};
static const MR_DuPtagLayout space_partition__space_partition__du_ptag_ordered_scene_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		space_partition__space_partition__du_stag_ordered_scene_0_0}};
static const MR_DuFunctorDescPtr space_partition__space_partition__du_stag_ordered_scene_0_0[1] = {
		(&space_partition__space_partition__du_functor_desc_scene_0_0)};
static const MR_NotagFunctorDesc space_partition__space_partition__notag_functor_desc_invalid_transformation_0 = {
		(MR_String) "invalid_transformation",
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_transformation_0),
		(MR_Box) NULL};
static const MR_NotagFunctorDesc space_partition__space_partition__notag_functor_desc_invalid_object_0 = {
		(MR_String) "invalid_object",
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_object_0),
		(MR_Box) NULL};

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL space_partition__map__ho6__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word space_partition__V_15_15,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word space_partition__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * space_partition__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool space_partition__succeeded;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((space_partition__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *space_partition__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
        MR_Word space_partition__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__2_2, (MR_Integer) 0)));
        MR_Word space_partition__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word space_partition__H_8_8;
        MR_Word space_partition__T_9_9;

#line 85 "space_partition.m"
        {
#line 85 "space_partition.m"
          space_partition__H_8_8 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "transform"));
#line 85 "space_partition.m"
          MR_hl_field(MR_mktag(1), space_partition__H_8_8, 0) = ((MR_Box) (space_partition__H0_6_6));
#line 85 "space_partition.m"
          MR_hl_field(MR_mktag(1), space_partition__H_8_8, 1) = ((MR_Box) (space_partition__V_15_15));
#line 85 "space_partition.m"
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          space_partition__map__ho6__ua0_3_p_in__list_0(space_partition__V_15_15, space_partition__T0_7_7, &space_partition__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *space_partition__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *space_partition__HeadVar__3_3, 0) = ((MR_Box) (space_partition__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *space_partition__HeadVar__3_3, 1) = ((MR_Box) (space_partition__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
static void MR_CALL space_partition__DeforestationIn__pred__build_space_tree__128__0_3_p_0(
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word space_partition__HeadVar__1_1,
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word * space_partition__HeadVar__2_2,
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  MR_Word space_partition__Tree0_11)
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
{
  {
    bool space_partition__succeeded;

    if ((space_partition__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *space_partition__HeadVar__2_2 = space_partition__Tree0_11;
    else
      {
        MR_Word space_partition__H0_6_53 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__1_1, (MR_Integer) 0)));
        MR_Word space_partition__T0_7_54 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__1_1, (MR_Integer) 1)));
        MR_Word space_partition__H_8_55;
        MR_Word space_partition__T_9_56;
        MR_Word space_partition__Acc1_12_98;

#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          space_partition__H_8_55 = space_partition__IntroducedFrom__func__build_space_tree__253__2_2_f_0(space_partition__H0_6_53);
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          space_partition__map__ho7_3_p_in__list_0(space_partition__T0_7_54, &space_partition__T_9_56);
        }
#line 151 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 151 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          space_partition__space_tree_insert_3_p_0(space_partition__H_8_55, space_partition__Tree0_11, &space_partition__Acc1_12_98);
        }
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          space_partition__foldl__ho3_4_p_in__list_0(space_partition__T_9_56, space_partition__Acc1_12_98, space_partition__HeadVar__2_2);
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          return;
        }
      }
  }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
}

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL space_partition__map__ho7_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word space_partition__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * space_partition__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool space_partition__succeeded;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word space_partition__H0_6_6;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word space_partition__T0_7_7;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word space_partition__H_8_8;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word space_partition__T_9_9;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((space_partition__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *space_partition__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        space_partition__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__2_2, (MR_Integer) 0)));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        space_partition__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__2_2, (MR_Integer) 1)));
#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          space_partition__H_8_8 = space_partition__IntroducedFrom__func__build_space_tree__253__2_2_f_0(space_partition__H0_6_6);
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          space_partition__map__ho7_3_p_in__list_0(space_partition__T0_7_7, &space_partition__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *space_partition__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *space_partition__HeadVar__3_3, 0) = ((MR_Box) (space_partition__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *space_partition__HeadVar__3_3, 1) = ((MR_Box) (space_partition__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL space_partition__foldl__ho3_4_p_in__list_0(
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word space_partition__HeadVar__2_2,
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word space_partition__HeadVar__3_3,
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * space_partition__HeadVar__4_4)
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    /* tailcall optimized into a loop */
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  loop_top:;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      bool space_partition__succeeded;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Word space_partition__H_8_8;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Word space_partition__T_9_9;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Word space_partition__Acc1_12_12;

#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      if ((space_partition__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        *space_partition__HeadVar__4_4 = space_partition__HeadVar__3_3;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      else
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 150 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          space_partition__H_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__2_2, (MR_Integer) 0)));
#line 150 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          space_partition__T_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__2_2, (MR_Integer) 1)));
#line 151 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          {
#line 151 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            space_partition__space_tree_insert_3_p_0(space_partition__H_8_8, space_partition__HeadVar__3_3, &space_partition__Acc1_12_12);
          }
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          {
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            /* direct tailcall eliminated */
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            {
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_Word space_partition__HeadVar__2__tmp_copy_2 = space_partition__T_9_9;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_Word space_partition__HeadVar__3__tmp_copy_3 = space_partition__Acc1_12_12;

#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              space_partition__HeadVar__2_2 = space_partition__HeadVar__2__tmp_copy_2;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              space_partition__HeadVar__3_3 = space_partition__HeadVar__3__tmp_copy_3;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            }
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            goto loop_top;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 253 "space_partition.m"
static MR_Word MR_CALL space_partition__IntroducedFrom__func__build_space_tree__253__2_2_f_0(
#line 253 "space_partition.m"
  MR_Word space_partition__V_19_19)
#line 253 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__V_18_18;
    MR_Word space_partition__BBox_14;
    MR_Float space_partition__ObjSurfaceArea_15;
    MR_Float space_partition__X1_33;
    MR_Float space_partition__Y1_34;
    MR_Float space_partition__Z1_35;
    MR_Float space_partition__X2_36;
    MR_Float space_partition__Y2_37;
    MR_Float space_partition__Z2_38;
    MR_Float space_partition__L_39;
    MR_Float space_partition__M_40;
    MR_Float space_partition__N_41;
    MR_Word space_partition__V_42_42;
    MR_Word space_partition__V_43_43;
    MR_Float space_partition__V_44_44;
    MR_Float space_partition__V_45_45;
    MR_Float space_partition__V_46_46;

#line 255 "space_partition.m"
    {
#line 255 "space_partition.m"
      space_partition__BBox_14 = space_partition__find_object_bounding_box_2_f_0(space_partition__V_19_19);
    }
#line 378 "space_partition.m"
    space_partition__V_42_42 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__BBox_14, (MR_Integer) 0)));
#line 378 "space_partition.m"
    space_partition__V_43_43 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__BBox_14, (MR_Integer) 1)));
#line 377 "space_partition.m"
    space_partition__X1_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_42_42, (MR_Integer) 0)));
#line 377 "space_partition.m"
    space_partition__Y1_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_42_42, (MR_Integer) 1)));
#line 377 "space_partition.m"
    space_partition__Z1_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_42_42, (MR_Integer) 2)));
#line 377 "space_partition.m"
    space_partition__X2_36 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_43_43, (MR_Integer) 0)));
#line 377 "space_partition.m"
    space_partition__Y2_37 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_43_43, (MR_Integer) 1)));
#line 377 "space_partition.m"
    space_partition__Z2_38 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_43_43, (MR_Integer) 2)));
#line 379 "space_partition.m"
    space_partition__L_39 = (space_partition__X1_33 - space_partition__X2_36);
#line 380 "space_partition.m"
    space_partition__M_40 = (space_partition__Y1_34 - space_partition__Y2_37);
#line 378 "space_partition.m"
    space_partition__V_46_46 = (space_partition__L_39 + space_partition__M_40);
#line 378 "space_partition.m"
    space_partition__V_45_45 = (space_partition__L_39 * space_partition__M_40);
#line 381 "space_partition.m"
    space_partition__N_41 = (space_partition__Z1_35 - space_partition__Z2_38);
#line 378 "space_partition.m"
    space_partition__V_44_44 = (space_partition__V_46_46 * space_partition__N_41);
#line 378 "space_partition.m"
    space_partition__ObjSurfaceArea_15 = (space_partition__V_44_44 + space_partition__V_45_45);
#line 253 "space_partition.m"
    {
#line 253 "space_partition.m"
      space_partition__V_18_18 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "space_tree_object");
#line 253 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__V_18_18, 0) = ((MR_Box) (space_partition__BBox_14));
#line 253 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__V_18_18, 1) = MR_box_float(space_partition__ObjSurfaceArea_15);
#line 253 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__V_18_18, 2) = ((MR_Box) (space_partition__V_19_19));
#line 253 "space_partition.m"
    }
    return space_partition__V_18_18;
  }
#line 253 "space_partition.m"
}

#line 319 "space_partition.m"
void MR_CALL space_partition____Compare____subtree_result_0_0(
#line 319 "space_partition.m"
  MR_Word * space_partition__HeadVar__1_1,
#line 319 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 319 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3)
#line 319 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float space_partition__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
    MR_Integer space_partition__V_6_6 = ((MR_Integer) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word space_partition__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float space_partition__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 1)));
    MR_Integer space_partition__V_9_9 = ((MR_Integer) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 2)));
#line 319 "space_partition.m"
    MR_Word space_partition__V_10_10;
    MR_Word space_partition__TypeInfo_12_12 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);
    MR_Word space_partition__TypeInfo_13_13 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);

#line 319 "space_partition.m"
    {
#line 319 "space_partition.m"
      mercury__std_util____Compare____pair_2_0(space_partition__TypeInfo_12_12, space_partition__TypeInfo_13_13, &space_partition__V_10_10, space_partition__V_4_4, space_partition__V_7_7);
    }
#line 319 "space_partition.m"
    space_partition__succeeded = (space_partition__V_10_10 == (MR_Integer) 0);
#line 319 "space_partition.m"
    space_partition__succeeded = !(space_partition__succeeded);
#line 319 "space_partition.m"
    if (space_partition__succeeded)
#line 319 "space_partition.m"
      *space_partition__HeadVar__1_1 = space_partition__V_10_10;
#line 319 "space_partition.m"
    else
#line 319 "space_partition.m"
      {
#line 319 "space_partition.m"
        MR_Word space_partition__V_11_11;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        space_partition__succeeded = (space_partition__V_5_5 < space_partition__V_8_8);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (space_partition__succeeded)
          {
            MR_Word space_partition__V_24_24 = (MR_Integer) 1;

#line 319 "space_partition.m"
            space_partition__succeeded = (space_partition__V_24_24 == (MR_Integer) 0);
#line 319 "space_partition.m"
            space_partition__succeeded = !(space_partition__succeeded);
            if (space_partition__succeeded)
              {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                space_partition__V_11_11 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                space_partition__succeeded = TRUE;
              }
          }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            space_partition__succeeded = (space_partition__V_5_5 > space_partition__V_8_8);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (space_partition__succeeded)
              {
                MR_Word space_partition__V_25_25 = (MR_Integer) 2;

#line 319 "space_partition.m"
                space_partition__succeeded = (space_partition__V_25_25 == (MR_Integer) 0);
#line 319 "space_partition.m"
                space_partition__succeeded = !(space_partition__succeeded);
                if (space_partition__succeeded)
                  {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    space_partition__V_11_11 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    space_partition__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
              {
                MR_Word space_partition__V_26_26 = (MR_Integer) 0;

#line 319 "space_partition.m"
                space_partition__succeeded = (space_partition__V_26_26 == (MR_Integer) 0);
#line 319 "space_partition.m"
                space_partition__succeeded = !(space_partition__succeeded);
                if (space_partition__succeeded)
                  {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    space_partition__V_11_11 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    space_partition__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 319 "space_partition.m"
        if (space_partition__succeeded)
#line 319 "space_partition.m"
          *space_partition__HeadVar__1_1 = space_partition__V_11_11;
#line 319 "space_partition.m"
        else
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            space_partition__succeeded = (space_partition__V_6_6 < space_partition__V_9_9);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (space_partition__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              *space_partition__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                space_partition__succeeded = (space_partition__V_6_6 == space_partition__V_9_9);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (space_partition__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *space_partition__HeadVar__1_1 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *space_partition__HeadVar__1_1 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 319 "space_partition.m"
      }
  }
#line 319 "space_partition.m"
}

#line 319 "space_partition.m"
bool MR_CALL space_partition____Unify____subtree_result_0_0(
#line 319 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 319 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2)
#line 319 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float space_partition__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 1)));
    MR_Integer space_partition__V_5_5 = ((MR_Integer) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 2)));
    MR_Word space_partition__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float space_partition__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
    MR_Integer space_partition__V_8_8 = ((MR_Integer) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word space_partition__TypeInfo_9_9 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);
    MR_Word space_partition__TypeInfo_10_10 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);

    {
      space_partition__succeeded = mercury__std_util____Unify____pair_2_0(space_partition__TypeInfo_9_9, space_partition__TypeInfo_10_10, space_partition__V_3_3, space_partition__V_6_6);
    }
    if (space_partition__succeeded)
      {
        space_partition__succeeded = (space_partition__V_4_4 == space_partition__V_7_7);
        if (space_partition__succeeded)
          space_partition__succeeded = (space_partition__V_5_5 == space_partition__V_8_8);
      }
    return space_partition__succeeded;
  }
#line 319 "space_partition.m"
}

#line 56 "space_partition.m"
void MR_CALL space_partition____Compare____bounding_box_0_0(
#line 56 "space_partition.m"
  MR_Word * space_partition__HeadVar__1_1,
#line 56 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 56 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3)
#line 56 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__conv1_HeadVar__2_2 = (MR_Word) space_partition__HeadVar__2_2;
    MR_Word space_partition__conv2_HeadVar__3_3 = (MR_Word) space_partition__HeadVar__3_3;
    MR_Word space_partition__TypeInfo_4_4 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);
    MR_Word space_partition__TypeInfo_5_5 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);

#line 56 "space_partition.m"
    {
#line 56 "space_partition.m"
      mercury__std_util____Compare____pair_2_0(space_partition__TypeInfo_4_4, space_partition__TypeInfo_5_5, space_partition__HeadVar__1_1, space_partition__conv1_HeadVar__2_2, space_partition__conv2_HeadVar__3_3);
#line 56 "space_partition.m"
      return;
    }
  }
#line 56 "space_partition.m"
}

#line 56 "space_partition.m"
bool MR_CALL space_partition____Unify____bounding_box_0_0(
#line 56 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 56 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2)
#line 56 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__conv1_HeadVar__1_1 = (MR_Word) space_partition__HeadVar__1_1;
    MR_Word space_partition__conv2_HeadVar__2_2 = (MR_Word) space_partition__HeadVar__2_2;
    MR_Word space_partition__TypeInfo_3_3 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);
    MR_Word space_partition__TypeInfo_4_4 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);

#line 56 "space_partition.m"
    {
#line 56 "space_partition.m"
      space_partition__succeeded = mercury__std_util____Unify____pair_2_0(space_partition__TypeInfo_3_3, space_partition__TypeInfo_4_4, space_partition__conv1_HeadVar__1_1, space_partition__conv2_HeadVar__2_2);
    }
    if (space_partition__succeeded)
      space_partition__succeeded = TRUE;
    return space_partition__succeeded;
  }
#line 56 "space_partition.m"
}

#line 45 "space_partition.m"
void MR_CALL space_partition____Compare____space_tree_object_0_0(
#line 45 "space_partition.m"
  MR_Word * space_partition__HeadVar__1_1,
#line 45 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 45 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3)
#line 45 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float space_partition__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word space_partition__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word space_partition__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float space_partition__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 1)));
    MR_Word space_partition__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 2)));
#line 45 "space_partition.m"
    MR_Word space_partition__V_10_10;
    MR_Word space_partition__TypeInfo_12_12 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);
    MR_Word space_partition__TypeInfo_13_13 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);

#line 45 "space_partition.m"
    {
#line 45 "space_partition.m"
      mercury__std_util____Compare____pair_2_0(space_partition__TypeInfo_12_12, space_partition__TypeInfo_13_13, &space_partition__V_10_10, space_partition__V_4_4, space_partition__V_7_7);
    }
#line 45 "space_partition.m"
    space_partition__succeeded = (space_partition__V_10_10 == (MR_Integer) 0);
#line 45 "space_partition.m"
    space_partition__succeeded = !(space_partition__succeeded);
#line 45 "space_partition.m"
    if (space_partition__succeeded)
#line 45 "space_partition.m"
      *space_partition__HeadVar__1_1 = space_partition__V_10_10;
#line 45 "space_partition.m"
    else
#line 45 "space_partition.m"
      {
#line 45 "space_partition.m"
        MR_Word space_partition__V_11_11;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        space_partition__succeeded = (space_partition__V_5_5 < space_partition__V_8_8);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (space_partition__succeeded)
          {
            MR_Word space_partition__V_21_21 = (MR_Integer) 1;

#line 45 "space_partition.m"
            space_partition__succeeded = (space_partition__V_21_21 == (MR_Integer) 0);
#line 45 "space_partition.m"
            space_partition__succeeded = !(space_partition__succeeded);
            if (space_partition__succeeded)
              {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                space_partition__V_11_11 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                space_partition__succeeded = TRUE;
              }
          }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            space_partition__succeeded = (space_partition__V_5_5 > space_partition__V_8_8);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (space_partition__succeeded)
              {
                MR_Word space_partition__V_22_22 = (MR_Integer) 2;

#line 45 "space_partition.m"
                space_partition__succeeded = (space_partition__V_22_22 == (MR_Integer) 0);
#line 45 "space_partition.m"
                space_partition__succeeded = !(space_partition__succeeded);
                if (space_partition__succeeded)
                  {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    space_partition__V_11_11 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    space_partition__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
              {
                MR_Word space_partition__V_23_23 = (MR_Integer) 0;

#line 45 "space_partition.m"
                space_partition__succeeded = (space_partition__V_23_23 == (MR_Integer) 0);
#line 45 "space_partition.m"
                space_partition__succeeded = !(space_partition__succeeded);
                if (space_partition__succeeded)
                  {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    space_partition__V_11_11 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    space_partition__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 45 "space_partition.m"
        if (space_partition__succeeded)
#line 45 "space_partition.m"
          *space_partition__HeadVar__1_1 = space_partition__V_11_11;
#line 45 "space_partition.m"
        else
#line 45 "space_partition.m"
          {
#line 45 "space_partition.m"
            eval____Compare____object_0_0(space_partition__HeadVar__1_1, space_partition__V_6_6, space_partition__V_9_9);
#line 45 "space_partition.m"
            return;
          }
#line 45 "space_partition.m"
      }
  }
#line 45 "space_partition.m"
}

#line 45 "space_partition.m"
bool MR_CALL space_partition____Unify____space_tree_object_0_0(
#line 45 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 45 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2)
#line 45 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float space_partition__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word space_partition__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 2)));
    MR_Word space_partition__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float space_partition__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word space_partition__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word space_partition__TypeInfo_9_9 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);
    MR_Word space_partition__TypeInfo_10_10 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);

    {
      space_partition__succeeded = mercury__std_util____Unify____pair_2_0(space_partition__TypeInfo_9_9, space_partition__TypeInfo_10_10, space_partition__V_3_3, space_partition__V_6_6);
    }
    if (space_partition__succeeded)
      {
        space_partition__succeeded = (space_partition__V_4_4 == space_partition__V_7_7);
        if (space_partition__succeeded)
          {
            return space_partition__succeeded = eval____Unify____object_0_0(space_partition__V_5_5, space_partition__V_8_8);
          }
      }
    return space_partition__succeeded;
  }
#line 45 "space_partition.m"
}

#line 35 "space_partition.m"
void MR_CALL space_partition____Compare____space_tree_node_0_0(
#line 35 "space_partition.m"
  MR_Word * space_partition__HeadVar__1_1,
#line 35 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 35 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3)
#line 35 "space_partition.m"
{
#line 35 "space_partition.m"
  {
#line 35 "space_partition.m"
    bool space_partition__succeeded;
#line 35 "space_partition.m"
    MR_Word space_partition__V_14_14;
#line 35 "space_partition.m"
    MR_Word space_partition__V_15_15;

#line 35 "space_partition.m"
    if ((MR_tag((MR_Word) space_partition__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
      {
#line 35 "space_partition.m"
        MR_Word space_partition__V_5_5;

#line 35 "space_partition.m"
        space_partition__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
#line 35 "space_partition.m"
        if ((MR_tag((MR_Word) space_partition__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
          {
#line 35 "space_partition.m"
            space_partition__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 0)));
#line 35 "space_partition.m"
            {
#line 35 "space_partition.m"
              space_partition____Compare____space_tree_0_0(space_partition__HeadVar__1_1, space_partition__V_15_15, space_partition__V_5_5);
#line 35 "space_partition.m"
              return;
            }
          }
#line 35 "space_partition.m"
        else
#line 35 "space_partition.m"
          *space_partition__HeadVar__1_1 = (MR_Integer) 1;
      }
#line 35 "space_partition.m"
    else
#line 35 "space_partition.m"
      {
#line 35 "space_partition.m"
        MR_Word space_partition__V_7_7;

#line 35 "space_partition.m"
        space_partition__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__2_2, (MR_Integer) 0)));
#line 35 "space_partition.m"
        if ((MR_tag((MR_Word) space_partition__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
#line 35 "space_partition.m"
          *space_partition__HeadVar__1_1 = (MR_Integer) 2;
#line 35 "space_partition.m"
        else
#line 35 "space_partition.m"
          {
#line 35 "space_partition.m"
            space_partition__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__3_3, (MR_Integer) 0)));
#line 35 "space_partition.m"
            {
#line 35 "space_partition.m"
              space_partition____Compare____space_tree_object_0_0(space_partition__HeadVar__1_1, space_partition__V_14_14, space_partition__V_7_7);
#line 35 "space_partition.m"
              return;
            }
#line 35 "space_partition.m"
          }
#line 35 "space_partition.m"
      }
#line 35 "space_partition.m"
  }
#line 35 "space_partition.m"
}

#line 35 "space_partition.m"
bool MR_CALL space_partition____Unify____space_tree_node_0_0(
#line 35 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 35 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2)
#line 35 "space_partition.m"
{
#line 35 "space_partition.m"
  {
#line 35 "space_partition.m"
    bool space_partition__succeeded;
#line 35 "space_partition.m"
    MR_Word space_partition__V_3_3;
#line 35 "space_partition.m"
    MR_Word space_partition__V_4_4;
#line 35 "space_partition.m"
    MR_Word space_partition__V_5_5;
#line 35 "space_partition.m"
    MR_Word space_partition__V_6_6;

#line 35 "space_partition.m"
    if ((MR_tag((MR_Word) space_partition__HeadVar__1_1) == MR_mktag((MR_Integer) 0)))
      {
#line 35 "space_partition.m"
        space_partition__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
#line 35 "space_partition.m"
        space_partition__succeeded = (MR_tag((MR_Word) space_partition__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
#line 35 "space_partition.m"
        if ((MR_tag((MR_Word) space_partition__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 35 "space_partition.m"
          space_partition__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
        if (space_partition__succeeded)
          {
            return space_partition__succeeded = space_partition____Unify____space_tree_0_0(space_partition__V_3_3, space_partition__V_4_4);
          }
      }
#line 35 "space_partition.m"
    else
#line 35 "space_partition.m"
      {
#line 35 "space_partition.m"
        space_partition__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__1_1, (MR_Integer) 0)));
#line 35 "space_partition.m"
        space_partition__succeeded = (MR_tag((MR_Word) space_partition__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 35 "space_partition.m"
        if ((MR_tag((MR_Word) space_partition__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 35 "space_partition.m"
          space_partition__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__2_2, (MR_Integer) 0)));
        if (space_partition__succeeded)
          {
            return space_partition__succeeded = space_partition____Unify____space_tree_object_0_0(space_partition__V_5_5, space_partition__V_6_6);
          }
#line 35 "space_partition.m"
      }
#line 35 "space_partition.m"
    return space_partition__succeeded;
#line 35 "space_partition.m"
  }
#line 35 "space_partition.m"
}

#line 27 "space_partition.m"
void MR_CALL space_partition____Compare____space_tree_0_0(
#line 27 "space_partition.m"
  MR_Word * space_partition__HeadVar__1_1,
#line 27 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 27 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3)
#line 27 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float space_partition__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word space_partition__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word space_partition__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float space_partition__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 1)));
    MR_Word space_partition__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 2)));
#line 27 "space_partition.m"
    MR_Word space_partition__V_10_10;
    MR_Word space_partition__TypeInfo_12_12 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);
    MR_Word space_partition__TypeInfo_13_13 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);

#line 27 "space_partition.m"
    {
#line 27 "space_partition.m"
      mercury__std_util____Compare____pair_2_0(space_partition__TypeInfo_12_12, space_partition__TypeInfo_13_13, &space_partition__V_10_10, space_partition__V_4_4, space_partition__V_7_7);
    }
#line 27 "space_partition.m"
    space_partition__succeeded = (space_partition__V_10_10 == (MR_Integer) 0);
#line 27 "space_partition.m"
    space_partition__succeeded = !(space_partition__succeeded);
#line 27 "space_partition.m"
    if (space_partition__succeeded)
#line 27 "space_partition.m"
      *space_partition__HeadVar__1_1 = space_partition__V_10_10;
#line 27 "space_partition.m"
    else
#line 27 "space_partition.m"
      {
#line 27 "space_partition.m"
        MR_Word space_partition__V_11_11;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        space_partition__succeeded = (space_partition__V_5_5 < space_partition__V_8_8);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (space_partition__succeeded)
          {
            MR_Word space_partition__V_23_23 = (MR_Integer) 1;

#line 27 "space_partition.m"
            space_partition__succeeded = (space_partition__V_23_23 == (MR_Integer) 0);
#line 27 "space_partition.m"
            space_partition__succeeded = !(space_partition__succeeded);
            if (space_partition__succeeded)
              {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                space_partition__V_11_11 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                space_partition__succeeded = TRUE;
              }
          }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            space_partition__succeeded = (space_partition__V_5_5 > space_partition__V_8_8);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (space_partition__succeeded)
              {
                MR_Word space_partition__V_24_24 = (MR_Integer) 2;

#line 27 "space_partition.m"
                space_partition__succeeded = (space_partition__V_24_24 == (MR_Integer) 0);
#line 27 "space_partition.m"
                space_partition__succeeded = !(space_partition__succeeded);
                if (space_partition__succeeded)
                  {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    space_partition__V_11_11 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    space_partition__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
              {
                MR_Word space_partition__V_25_25 = (MR_Integer) 0;

#line 27 "space_partition.m"
                space_partition__succeeded = (space_partition__V_25_25 == (MR_Integer) 0);
#line 27 "space_partition.m"
                space_partition__succeeded = !(space_partition__succeeded);
                if (space_partition__succeeded)
                  {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    space_partition__V_11_11 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    space_partition__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 27 "space_partition.m"
        if (space_partition__succeeded)
#line 27 "space_partition.m"
          *space_partition__HeadVar__1_1 = space_partition__V_11_11;
#line 27 "space_partition.m"
        else
          {
            MR_Word space_partition__TypeInfo_17_17 = (MR_Word) (&space_partition__space_partition__type_ctor_info_space_tree_node_0);

#line 27 "space_partition.m"
            {
#line 27 "space_partition.m"
              mercury__list____Compare____list_1_0(space_partition__TypeInfo_17_17, space_partition__HeadVar__1_1, space_partition__V_6_6, space_partition__V_9_9);
#line 27 "space_partition.m"
              return;
            }
          }
#line 27 "space_partition.m"
      }
  }
#line 27 "space_partition.m"
}

#line 27 "space_partition.m"
bool MR_CALL space_partition____Unify____space_tree_0_0(
#line 27 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 27 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2)
#line 27 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float space_partition__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word space_partition__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 2)));
    MR_Word space_partition__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float space_partition__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word space_partition__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word space_partition__TypeInfo_9_9 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);
    MR_Word space_partition__TypeInfo_10_10 = (MR_Word) (&vector__vector__type_ctor_info_vector_0);
    MR_Word space_partition__TypeInfo_13_13;

    {
      space_partition__succeeded = mercury__std_util____Unify____pair_2_0(space_partition__TypeInfo_9_9, space_partition__TypeInfo_10_10, space_partition__V_3_3, space_partition__V_6_6);
    }
    if (space_partition__succeeded)
      {
        space_partition__succeeded = (space_partition__V_4_4 == space_partition__V_7_7);
        if (space_partition__succeeded)
          {
            space_partition__TypeInfo_13_13 = (MR_Word) (&space_partition__space_partition__type_ctor_info_space_tree_node_0);
            {
              return space_partition__succeeded = mercury__list____Unify____list_1_0(space_partition__TypeInfo_13_13, space_partition__V_5_5, space_partition__V_8_8);
            }
          }
      }
    return space_partition__succeeded;
  }
#line 27 "space_partition.m"
}

#line 25 "space_partition.m"
void MR_CALL space_partition____Compare____surface_area_0_0(
#line 25 "space_partition.m"
  MR_Word * space_partition__HeadVar__1_1,
#line 25 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 25 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3)
#line 25 "space_partition.m"
{
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  {
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    bool space_partition__succeeded;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Float space_partition__conv1_HeadVar__2_2 = MR_unbox_float((MR_Box) space_partition__HeadVar__2_2);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Float space_partition__conv2_HeadVar__3_3 = MR_unbox_float((MR_Box) space_partition__HeadVar__3_3);

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    space_partition__succeeded = (space_partition__conv1_HeadVar__2_2 < space_partition__conv2_HeadVar__3_3);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (space_partition__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *space_partition__HeadVar__1_1 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        space_partition__succeeded = (space_partition__conv1_HeadVar__2_2 > space_partition__conv2_HeadVar__3_3);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (space_partition__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *space_partition__HeadVar__1_1 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *space_partition__HeadVar__1_1 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  }
#line 25 "space_partition.m"
}

#line 25 "space_partition.m"
bool MR_CALL space_partition____Unify____surface_area_0_0(
#line 25 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 25 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2)
#line 25 "space_partition.m"
{
#line 25 "space_partition.m"
  {
#line 25 "space_partition.m"
    bool space_partition__succeeded;
#line 25 "space_partition.m"
    MR_Float space_partition__conv1_HeadVar__1_1 = MR_unbox_float((MR_Box) space_partition__HeadVar__1_1);
#line 25 "space_partition.m"
    MR_Float space_partition__conv2_HeadVar__2_2 = MR_unbox_float((MR_Box) space_partition__HeadVar__2_2);

#line 25 "space_partition.m"
    space_partition__succeeded = (space_partition__conv1_HeadVar__1_1 == space_partition__conv2_HeadVar__2_2);
#line 25 "space_partition.m"
    if (space_partition__succeeded)
#line 25 "space_partition.m"
      space_partition__succeeded = TRUE;
#line 25 "space_partition.m"
    return space_partition__succeeded;
#line 25 "space_partition.m"
  }
#line 25 "space_partition.m"
}

#line 23 "space_partition.m"
void MR_CALL space_partition____Compare____normal_0_0(
#line 23 "space_partition.m"
  MR_Word * space_partition__HeadVar__1_1,
#line 23 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 23 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3)
#line 23 "space_partition.m"
{
#line 23 "space_partition.m"
  {
#line 23 "space_partition.m"
    bool space_partition__succeeded;
#line 23 "space_partition.m"
    MR_Word space_partition__conv1_HeadVar__2_2 = (MR_Word) space_partition__HeadVar__2_2;
#line 23 "space_partition.m"
    MR_Word space_partition__conv2_HeadVar__3_3 = (MR_Word) space_partition__HeadVar__3_3;

#line 23 "space_partition.m"
    {
#line 23 "space_partition.m"
      vector____Compare____vector_0_0(space_partition__HeadVar__1_1, space_partition__conv1_HeadVar__2_2, space_partition__conv2_HeadVar__3_3);
#line 23 "space_partition.m"
      return;
    }
#line 23 "space_partition.m"
  }
#line 23 "space_partition.m"
}

#line 23 "space_partition.m"
bool MR_CALL space_partition____Unify____normal_0_0(
#line 23 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 23 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2)
#line 23 "space_partition.m"
{
#line 23 "space_partition.m"
  {
#line 23 "space_partition.m"
    bool space_partition__succeeded;
#line 23 "space_partition.m"
    MR_Word space_partition__conv1_HeadVar__1_1 = (MR_Word) space_partition__HeadVar__1_1;
#line 23 "space_partition.m"
    MR_Word space_partition__conv2_HeadVar__2_2 = (MR_Word) space_partition__HeadVar__2_2;

#line 23 "space_partition.m"
    {
#line 23 "space_partition.m"
      space_partition__succeeded = vector____Unify____vector_0_0(space_partition__conv1_HeadVar__1_1, space_partition__conv2_HeadVar__2_2);
    }
#line 23 "space_partition.m"
    if (space_partition__succeeded)
#line 23 "space_partition.m"
      space_partition__succeeded = TRUE;
#line 23 "space_partition.m"
    return space_partition__succeeded;
#line 23 "space_partition.m"
  }
#line 23 "space_partition.m"
}

#line 20 "space_partition.m"
void MR_CALL space_partition____Compare____invalid_object_0_0(
#line 20 "space_partition.m"
  MR_Word * space_partition__HeadVar__1_1,
#line 20 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 20 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3)
#line 20 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__V_4_4 = (MR_Word) space_partition__HeadVar__2_2;
    MR_Word space_partition__V_5_5 = (MR_Word) space_partition__HeadVar__3_3;

#line 20 "space_partition.m"
    {
#line 20 "space_partition.m"
      eval____Compare____object_0_0(space_partition__HeadVar__1_1, space_partition__V_4_4, space_partition__V_5_5);
#line 20 "space_partition.m"
      return;
    }
  }
#line 20 "space_partition.m"
}

#line 20 "space_partition.m"
bool MR_CALL space_partition____Unify____invalid_object_0_0(
#line 20 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 20 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2)
#line 20 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__V_3_3 = (MR_Word) space_partition__HeadVar__1_1;
    MR_Word space_partition__V_4_4 = (MR_Word) space_partition__HeadVar__2_2;

    {
      return space_partition__succeeded = eval____Unify____object_0_0(space_partition__V_3_3, space_partition__V_4_4);
    }
    return space_partition__succeeded;
  }
#line 20 "space_partition.m"
}

#line 17 "space_partition.m"
void MR_CALL space_partition____Compare____invalid_transformation_0_0(
#line 17 "space_partition.m"
  MR_Word * space_partition__HeadVar__1_1,
#line 17 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 17 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3)
#line 17 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__V_4_4 = (MR_Word) space_partition__HeadVar__2_2;
    MR_Word space_partition__V_5_5 = (MR_Word) space_partition__HeadVar__3_3;

#line 17 "space_partition.m"
    {
#line 17 "space_partition.m"
      eval____Compare____transformation_0_0(space_partition__HeadVar__1_1, space_partition__V_4_4, space_partition__V_5_5);
#line 17 "space_partition.m"
      return;
    }
  }
#line 17 "space_partition.m"
}

#line 17 "space_partition.m"
bool MR_CALL space_partition____Unify____invalid_transformation_0_0(
#line 17 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 17 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2)
#line 17 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__V_3_3 = (MR_Word) space_partition__HeadVar__1_1;
    MR_Word space_partition__V_4_4 = (MR_Word) space_partition__HeadVar__2_2;

    {
      return space_partition__succeeded = eval____Unify____transformation_0_0(space_partition__V_3_3, space_partition__V_4_4);
    }
    return space_partition__succeeded;
  }
#line 17 "space_partition.m"
}

#line 10 "space_partition.m"
void MR_CALL space_partition____Compare____scene_0_0(
#line 10 "space_partition.m"
  MR_Word * space_partition__HeadVar__1_1,
#line 10 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 10 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3)
#line 10 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word space_partition__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word space_partition__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 0)));
    MR_Word space_partition__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 1)));
#line 10 "space_partition.m"
    MR_Word space_partition__V_8_8;

#line 10 "space_partition.m"
    {
#line 10 "space_partition.m"
      space_partition____Compare____space_tree_0_0(&space_partition__V_8_8, space_partition__V_4_4, space_partition__V_6_6);
    }
#line 10 "space_partition.m"
    space_partition__succeeded = (space_partition__V_8_8 == (MR_Integer) 0);
#line 10 "space_partition.m"
    space_partition__succeeded = !(space_partition__succeeded);
#line 10 "space_partition.m"
    if (space_partition__succeeded)
#line 10 "space_partition.m"
      *space_partition__HeadVar__1_1 = space_partition__V_8_8;
#line 10 "space_partition.m"
    else
      {
        MR_Word space_partition__TypeInfo_10_10 = (MR_Word) (&eval__eval__type_ctor_info_object_0);

#line 10 "space_partition.m"
        {
#line 10 "space_partition.m"
          mercury__list____Compare____list_1_0(space_partition__TypeInfo_10_10, space_partition__HeadVar__1_1, space_partition__V_5_5, space_partition__V_7_7);
#line 10 "space_partition.m"
          return;
        }
      }
  }
#line 10 "space_partition.m"
}

#line 10 "space_partition.m"
bool MR_CALL space_partition____Unify____scene_0_0(
#line 10 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 10 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2)
#line 10 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word space_partition__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word space_partition__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word space_partition__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word space_partition__TypeInfo_7_7;

    {
      space_partition__succeeded = space_partition____Unify____space_tree_0_0(space_partition__V_3_3, space_partition__V_5_5);
    }
    if (space_partition__succeeded)
      {
        space_partition__TypeInfo_7_7 = (MR_Word) (&eval__eval__type_ctor_info_object_0);
        {
          return space_partition__succeeded = mercury__list____Unify____list_1_0(space_partition__TypeInfo_7_7, space_partition__V_4_4, space_partition__V_6_6);
        }
      }
    return space_partition__succeeded;
  }
#line 10 "space_partition.m"
}

#line 511 "space_partition.m"
static void MR_CALL space_partition__traverse_space_tree_nodes_5_p_0(
#line 511 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 511 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 511 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3,
#line 511 "space_partition.m"
  MR_Word space_partition__HeadVar__4_4,
#line 511 "space_partition.m"
  MR_Word * space_partition__HeadVar__5_5)
#line 511 "space_partition.m"
{
#line 515 "space_partition.m"
  {
#line 515 "space_partition.m"
    /* tailcall optimized into a loop */
#line 515 "space_partition.m"
  loop_top:;
#line 515 "space_partition.m"
    {
#line 515 "space_partition.m"
      bool space_partition__succeeded;

#line 515 "space_partition.m"
      if ((space_partition__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 515 "space_partition.m"
        *space_partition__HeadVar__5_5 = space_partition__HeadVar__4_4;
#line 515 "space_partition.m"
      else
#line 515 "space_partition.m"
        {
          MR_Word space_partition__Node_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word space_partition__Nodes_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__1_1, (MR_Integer) 1)));
          MR_Word space_partition__Result_20;
          MR_Word space_partition__Results1_22;

#line 524 "space_partition.m"
          if ((MR_tag((MR_Word) space_partition__Node_9) == MR_mktag((MR_Integer) 0)))
            {
              MR_Word space_partition__Tree_21 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__Node_9, (MR_Integer) 0)));

#line 526 "space_partition.m"
              {
#line 526 "space_partition.m"
                space_partition__traverse_space_tree_4_p_0(space_partition__Tree_21, space_partition__HeadVar__2_2, space_partition__HeadVar__3_3, &space_partition__Result_20);
              }
            }
#line 524 "space_partition.m"
          else
#line 524 "space_partition.m"
            {
              MR_Word space_partition__SpaceObject_15 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__Node_9, (MR_Integer) 0)));
              MR_Word space_partition__Object_18 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__SpaceObject_15, (MR_Integer) 2)));
              MR_Word space_partition__MaybeTransformation_19 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 520 "space_partition.m"
              MR_Word space_partition__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__SpaceObject_15, (MR_Integer) 0)));
#line 520 "space_partition.m"
              MR_Float space_partition__V_17_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__SpaceObject_15, (MR_Integer) 1)));

#line 522 "space_partition.m"
              {
#line 522 "space_partition.m"
                renderer__find_object_intersection_5_p_0(space_partition__Object_18, space_partition__MaybeTransformation_19, space_partition__HeadVar__2_2, space_partition__HeadVar__3_3, &space_partition__Result_20);
              }
#line 524 "space_partition.m"
            }
#line 9 "renderer.opt"
          space_partition__succeeded = (space_partition__HeadVar__4_4 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 12 "renderer.opt"
          if (space_partition__succeeded)
#line 11 "renderer.opt"
            space_partition__Results1_22 = space_partition__Result_20;
#line 12 "renderer.opt"
          else
#line 17 "renderer.opt"
            {
#line 14 "renderer.opt"
              space_partition__succeeded = (space_partition__Result_20 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 17 "renderer.opt"
              if (space_partition__succeeded)
#line 16 "renderer.opt"
                space_partition__Results1_22 = space_partition__HeadVar__4_4;
#line 17 "renderer.opt"
              else
#line 18 "renderer.opt"
                {
#line 18 "renderer.opt"
                  space_partition__Results1_22 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "tree"));
#line 18 "renderer.opt"
                  MR_hl_field(MR_mktag(2), space_partition__Results1_22, 0) = ((MR_Box) (space_partition__HeadVar__4_4));
#line 18 "renderer.opt"
                  MR_hl_field(MR_mktag(2), space_partition__Results1_22, 1) = ((MR_Box) (space_partition__Result_20));
#line 18 "renderer.opt"
                }
#line 17 "renderer.opt"
            }
#line 529 "space_partition.m"
          {
#line 529 "space_partition.m"
            /* direct tailcall eliminated */
#line 529 "space_partition.m"
            {
#line 529 "space_partition.m"
              MR_Word space_partition__HeadVar__1__tmp_copy_1 = space_partition__Nodes_10;
#line 529 "space_partition.m"
              MR_Word space_partition__HeadVar__4__tmp_copy_4 = space_partition__Results1_22;

#line 529 "space_partition.m"
              space_partition__HeadVar__1_1 = space_partition__HeadVar__1__tmp_copy_1;
#line 529 "space_partition.m"
              space_partition__HeadVar__4_4 = space_partition__HeadVar__4__tmp_copy_4;
#line 529 "space_partition.m"
            }
#line 529 "space_partition.m"
            goto loop_top;
#line 529 "space_partition.m"
          }
#line 515 "space_partition.m"
        }
#line 515 "space_partition.m"
    }
#line 515 "space_partition.m"
  }
#line 511 "space_partition.m"
}

#line 402 "space_partition.m"
static bool MR_CALL space_partition__intersect_bounding_box_2_12_p_0(
#line 402 "space_partition.m"
  MR_Float space_partition__XRay_1,
#line 402 "space_partition.m"
  MR_Float space_partition__YRay_2,
#line 402 "space_partition.m"
  MR_Float space_partition__ZRay_3,
#line 402 "space_partition.m"
  MR_Float space_partition__XDir_4,
#line 402 "space_partition.m"
  MR_Float space_partition__YDir_5,
#line 402 "space_partition.m"
  MR_Float space_partition__ZDir_6,
#line 402 "space_partition.m"
  MR_Float space_partition__XMin_7,
#line 402 "space_partition.m"
  MR_Float space_partition__YMin_8,
#line 402 "space_partition.m"
  MR_Float space_partition__ZMin_9,
#line 402 "space_partition.m"
  MR_Float space_partition__XMax_10,
#line 402 "space_partition.m"
  MR_Float space_partition__YMax_11,
#line 402 "space_partition.m"
  MR_Float space_partition__ZMax_12)
#line 402 "space_partition.m"
{
#line 406 "space_partition.m"
  {
#line 406 "space_partition.m"
    bool space_partition__succeeded;

#line 406 "space_partition.m"
#line 406 "space_partition.m"
{
#line 406 "space_partition.m"
#define MR_PROC_LABEL space_partition__intersect_bounding_box_2_12_p_0
#line 406 "space_partition.m"

#line 406 "space_partition.m"
	MR_Float XRay;
#line 406 "space_partition.m"
	MR_Float YRay;
#line 406 "space_partition.m"
	MR_Float ZRay;
#line 406 "space_partition.m"
	MR_Float XDir;
#line 406 "space_partition.m"
	MR_Float YDir;
#line 406 "space_partition.m"
	MR_Float ZDir;
#line 406 "space_partition.m"
	MR_Float XMin;
#line 406 "space_partition.m"
	MR_Float YMin;
#line 406 "space_partition.m"
	MR_Float ZMin;
#line 406 "space_partition.m"
	MR_Float XMax;
#line 406 "space_partition.m"
	MR_Float YMax;
#line 406 "space_partition.m"
	MR_Float ZMax;
#line 406 "space_partition.m"
	MR_Bool SUCCESS_INDICATOR;
#line 406 "space_partition.m"

#line 406 "space_partition.m"
	XRay = 
#line 406 "space_partition.m"
space_partition__XRay_1
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	YRay = 
#line 406 "space_partition.m"
space_partition__YRay_2
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	ZRay = 
#line 406 "space_partition.m"
space_partition__ZRay_3
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	XDir = 
#line 406 "space_partition.m"
space_partition__XDir_4
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	YDir = 
#line 406 "space_partition.m"
space_partition__YDir_5
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	ZDir = 
#line 406 "space_partition.m"
space_partition__ZDir_6
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	XMin = 
#line 406 "space_partition.m"
space_partition__XMin_7
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	YMin = 
#line 406 "space_partition.m"
space_partition__YMin_8
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	ZMin = 
#line 406 "space_partition.m"
space_partition__ZMin_9
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	XMax = 
#line 406 "space_partition.m"
space_partition__XMax_10
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	YMax = 
#line 406 "space_partition.m"
space_partition__YMax_11
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	ZMax = 
#line 406 "space_partition.m"
space_partition__ZMax_12
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
#line 406 "space_partition.m"
		{
#line 406 "space_partition.m"

{
	double minB[3], maxB[3];	/*box */
	double origin[3], dir[3];	/*ray */
	double coord[3];		/* hit point (not used -stayl)*/
	bool succeeded;

	minB[0] = XMin;
	minB[1] = YMin;
	minB[2] = ZMin;
	maxB[0] = XMax;
	maxB[1] = YMax;
	maxB[2] = ZMax;
	origin[0] = XRay;
	origin[1] = YRay;
	origin[2] = ZRay;
	dir[0] = XDir;
	dir[1] = YDir;
	dir[2] = ZDir;
	succeeded = HitBoundingBox(minB, maxB, origin, dir, coord);
	/*fprintf(stderr, succeeded ? "1\n" : "0\n"); */
	SUCCESS_INDICATOR = succeeded;
}
#line 406 "space_partition.m"

		;}
#line 406 "space_partition.m"
#undef MR_PROC_LABEL
#line 406 "space_partition.m"
#line 406 "space_partition.m"
	if (SUCCESS_INDICATOR) {
#line 406 "space_partition.m"
#line 406 "space_partition.m"
	}
#line 406 "space_partition.m"
space_partition__succeeded
#line 406 "space_partition.m"
 = SUCCESS_INDICATOR;
#line 406 "space_partition.m"
}
#line 406 "space_partition.m"
    return space_partition__succeeded;
#line 406 "space_partition.m"
  }
#line 402 "space_partition.m"
}

#line 349 "space_partition.m"
static void MR_CALL space_partition__subtree_insert_4_p_0(
#line 349 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 349 "space_partition.m"
  MR_Integer space_partition__HeadVar__2_2,
#line 349 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3,
#line 349 "space_partition.m"
  MR_Word * space_partition__HeadVar__4_4)
#line 349 "space_partition.m"
{
#line 352 "space_partition.m"
  {
#line 352 "space_partition.m"
    bool space_partition__succeeded;

#line 352 "space_partition.m"
    if ((space_partition__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
      {
        MR_Word space_partition__V_7_7;
        MR_Word space_partition__V_8_8;

#line 352 "space_partition.m"
        {
#line 352 "space_partition.m"
          space_partition__V_7_7 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "leaf"));
#line 352 "space_partition.m"
          MR_hl_field(MR_mktag(1), space_partition__V_7_7, 0) = ((MR_Box) (space_partition__HeadVar__3_3));
#line 352 "space_partition.m"
        }
#line 352 "space_partition.m"
        space_partition__V_8_8 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 352 "space_partition.m"
        {
#line 352 "space_partition.m"
          *space_partition__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 352 "space_partition.m"
          MR_hl_field(MR_mktag(1), *space_partition__HeadVar__4_4, 0) = ((MR_Box) (space_partition__V_7_7));
#line 352 "space_partition.m"
          MR_hl_field(MR_mktag(1), *space_partition__HeadVar__4_4, 1) = ((MR_Box) (space_partition__V_8_8));
#line 352 "space_partition.m"
        }
      }
#line 352 "space_partition.m"
    else
#line 352 "space_partition.m"
      {
        MR_Word space_partition__Tree0_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__1_1, (MR_Integer) 0)));
        MR_Word space_partition__Trees0_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__1_1, (MR_Integer) 1)));

#line 354 "space_partition.m"
        space_partition__succeeded = (space_partition__HeadVar__2_2 == (MR_Integer) 1);
#line 369 "space_partition.m"
        if (space_partition__succeeded)
          {
            MR_Word space_partition__Tree_23;

#line 363 "space_partition.m"
            if ((MR_tag((MR_Word) space_partition__Tree0_9) == MR_mktag((MR_Integer) 0)))
              {
                MR_Word space_partition__Subtree0_24 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__Tree0_9, (MR_Integer) 0)));
                MR_Word space_partition__Subtree_25;

#line 365 "space_partition.m"
                {
#line 365 "space_partition.m"
                  space_partition__space_tree_insert_3_p_0(space_partition__HeadVar__3_3, space_partition__Subtree0_24, &space_partition__Subtree_25);
                }
#line 366 "space_partition.m"
                {
#line 366 "space_partition.m"
                  space_partition__Tree_23 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "node");
#line 366 "space_partition.m"
                  MR_hl_field(MR_mktag(0), space_partition__Tree_23, 0) = ((MR_Box) (space_partition__Subtree_25));
#line 366 "space_partition.m"
                }
              }
#line 363 "space_partition.m"
            else
#line 363 "space_partition.m"
              {
                MR_Word space_partition__LeafObject_14 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__Tree0_9, (MR_Integer) 0)));
                MR_Word space_partition__OldBox_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__LeafObject_14, (MR_Integer) 0)));
                MR_Word space_partition__ObjBox_18 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 0)));
                MR_Word space_partition__NewBox_21;
                MR_Float space_partition__NewSurfaceArea_22;
                MR_Word space_partition__V_27_27;
                MR_Word space_partition__V_28_28;
                MR_Word space_partition__V_29_29;
                MR_Word space_partition__V_30_30;
                MR_Word space_partition__V_32_32;
                MR_Word space_partition__P1_35 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__OldBox_15, (MR_Integer) 0)));
                MR_Word space_partition__P2_36 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__OldBox_15, (MR_Integer) 1)));
                MR_Word space_partition__P3_37 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__ObjBox_18, (MR_Integer) 0)));
                MR_Word space_partition__P4_38 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__ObjBox_18, (MR_Integer) 1)));
                MR_Word space_partition__V_39_39;
                MR_Word space_partition__V_40_40;
                MR_Float space_partition__X1_41;
                MR_Float space_partition__Y1_42;
                MR_Float space_partition__Z1_43;
                MR_Float space_partition__X2_44;
                MR_Float space_partition__Y2_45;
                MR_Float space_partition__Z2_46;
                MR_Float space_partition__L_47;
                MR_Float space_partition__M_48;
                MR_Float space_partition__N_49;
                MR_Float space_partition__V_52_52;
                MR_Float space_partition__V_53_53;
                MR_Float space_partition__V_54_54;
#line 357 "space_partition.m"
                MR_Float space_partition__V_16_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__LeafObject_14, (MR_Integer) 1)));
#line 357 "space_partition.m"
                MR_Word space_partition__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__LeafObject_14, (MR_Integer) 2)));
#line 358 "space_partition.m"
                MR_Float space_partition__V_19_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 1)));
#line 358 "space_partition.m"
                MR_Word space_partition__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 2)));

#line 154 "space_partition.m"
                {
#line 154 "space_partition.m"
                  space_partition__V_39_39 = space_partition__min_point_3_f_0(space_partition__P1_35, space_partition__P3_37);
                }
#line 154 "space_partition.m"
                {
#line 154 "space_partition.m"
                  space_partition__V_40_40 = space_partition__max_point_3_f_0(space_partition__P2_36, space_partition__P4_38);
                }
#line 154 "space_partition.m"
                {
#line 154 "space_partition.m"
                  space_partition__NewBox_21 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 154 "space_partition.m"
                  MR_hl_field(MR_mktag(0), space_partition__NewBox_21, 0) = ((MR_Box) (space_partition__V_39_39));
#line 154 "space_partition.m"
                  MR_hl_field(MR_mktag(0), space_partition__NewBox_21, 1) = ((MR_Box) (space_partition__V_40_40));
#line 154 "space_partition.m"
                }
#line 377 "space_partition.m"
                space_partition__X1_41 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_39_39, (MR_Integer) 0)));
#line 377 "space_partition.m"
                space_partition__Y1_42 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_39_39, (MR_Integer) 1)));
#line 377 "space_partition.m"
                space_partition__Z1_43 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_39_39, (MR_Integer) 2)));
#line 377 "space_partition.m"
                space_partition__X2_44 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_40_40, (MR_Integer) 0)));
#line 377 "space_partition.m"
                space_partition__Y2_45 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_40_40, (MR_Integer) 1)));
#line 377 "space_partition.m"
                space_partition__Z2_46 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_40_40, (MR_Integer) 2)));
#line 379 "space_partition.m"
                space_partition__L_47 = (space_partition__X1_41 - space_partition__X2_44);
#line 380 "space_partition.m"
                space_partition__M_48 = (space_partition__Y1_42 - space_partition__Y2_45);
#line 378 "space_partition.m"
                space_partition__V_54_54 = (space_partition__L_47 + space_partition__M_48);
#line 378 "space_partition.m"
                space_partition__V_53_53 = (space_partition__L_47 * space_partition__M_48);
#line 381 "space_partition.m"
                space_partition__N_49 = (space_partition__Z1_43 - space_partition__Z2_46);
#line 378 "space_partition.m"
                space_partition__V_52_52 = (space_partition__V_54_54 * space_partition__N_49);
#line 378 "space_partition.m"
                space_partition__NewSurfaceArea_22 = (space_partition__V_52_52 + space_partition__V_53_53);
#line 362 "space_partition.m"
                {
#line 362 "space_partition.m"
                  space_partition__V_29_29 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "leaf"));
#line 362 "space_partition.m"
                  MR_hl_field(MR_mktag(1), space_partition__V_29_29, 0) = ((MR_Box) (space_partition__HeadVar__3_3));
#line 362 "space_partition.m"
                }
#line 362 "space_partition.m"
                space_partition__V_32_32 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 362 "space_partition.m"
                {
#line 362 "space_partition.m"
                  space_partition__V_30_30 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 362 "space_partition.m"
                  MR_hl_field(MR_mktag(1), space_partition__V_30_30, 0) = ((MR_Box) (space_partition__Tree0_9));
#line 362 "space_partition.m"
                  MR_hl_field(MR_mktag(1), space_partition__V_30_30, 1) = ((MR_Box) (space_partition__V_32_32));
#line 362 "space_partition.m"
                }
#line 361 "space_partition.m"
                {
#line 361 "space_partition.m"
                  space_partition__V_28_28 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 361 "space_partition.m"
                  MR_hl_field(MR_mktag(1), space_partition__V_28_28, 0) = ((MR_Box) (space_partition__V_29_29));
#line 361 "space_partition.m"
                  MR_hl_field(MR_mktag(1), space_partition__V_28_28, 1) = ((MR_Box) (space_partition__V_30_30));
#line 361 "space_partition.m"
                }
#line 361 "space_partition.m"
                {
#line 361 "space_partition.m"
                  space_partition__V_27_27 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "space_tree");
#line 361 "space_partition.m"
                  MR_hl_field(MR_mktag(0), space_partition__V_27_27, 0) = ((MR_Box) (space_partition__NewBox_21));
#line 361 "space_partition.m"
                  MR_hl_field(MR_mktag(0), space_partition__V_27_27, 1) = MR_box_float(space_partition__NewSurfaceArea_22);
#line 361 "space_partition.m"
                  MR_hl_field(MR_mktag(0), space_partition__V_27_27, 2) = ((MR_Box) (space_partition__V_28_28));
#line 361 "space_partition.m"
                }
#line 361 "space_partition.m"
                {
#line 361 "space_partition.m"
                  space_partition__Tree_23 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "node");
#line 361 "space_partition.m"
                  MR_hl_field(MR_mktag(0), space_partition__Tree_23, 0) = ((MR_Box) (space_partition__V_27_27));
#line 361 "space_partition.m"
                }
#line 363 "space_partition.m"
              }
#line 368 "space_partition.m"
            {
#line 368 "space_partition.m"
              *space_partition__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 368 "space_partition.m"
              MR_hl_field(MR_mktag(1), *space_partition__HeadVar__4_4, 0) = ((MR_Box) (space_partition__Tree_23));
#line 368 "space_partition.m"
              MR_hl_field(MR_mktag(1), *space_partition__HeadVar__4_4, 1) = ((MR_Box) (space_partition__Trees0_10));
#line 368 "space_partition.m"
            }
          }
#line 369 "space_partition.m"
        else
          {
            MR_Word space_partition__Trees1_26;
            MR_Integer space_partition__V_33_33;
            MR_Integer space_partition__V_34_34 = (MR_Integer) 1;

#line 370 "space_partition.m"
            space_partition__V_33_33 = (space_partition__HeadVar__2_2 - space_partition__V_34_34);
#line 370 "space_partition.m"
            {
#line 370 "space_partition.m"
              space_partition__subtree_insert_4_p_0(space_partition__Trees0_10, space_partition__V_33_33, space_partition__HeadVar__3_3, &space_partition__Trees1_26);
            }
#line 371 "space_partition.m"
            {
#line 371 "space_partition.m"
              *space_partition__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 371 "space_partition.m"
              MR_hl_field(MR_mktag(1), *space_partition__HeadVar__4_4, 0) = ((MR_Box) (space_partition__Tree0_9));
#line 371 "space_partition.m"
              MR_hl_field(MR_mktag(1), *space_partition__HeadVar__4_4, 1) = ((MR_Box) (space_partition__Trees1_26));
#line 371 "space_partition.m"
            }
          }
#line 352 "space_partition.m"
      }
#line 352 "space_partition.m"
  }
#line 349 "space_partition.m"
}

#line 326 "space_partition.m"
static void MR_CALL space_partition__select_subtree_5_p_0(
#line 326 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 326 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 326 "space_partition.m"
  MR_Integer space_partition__HeadVar__3_3,
#line 326 "space_partition.m"
  MR_Word space_partition__HeadVar__4_4,
#line 326 "space_partition.m"
  MR_Integer * space_partition__HeadVar__5_5)
#line 326 "space_partition.m"
{
  {
    /* tailcall optimized into a loop */
  loop_top:;
    {
      bool space_partition__succeeded;
      MR_Integer space_partition__V_32_32 = ((MR_Integer) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__4_4, (MR_Integer) 1)));
      MR_Float space_partition__V_33_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__4_4, (MR_Integer) 0)));

#line 330 "space_partition.m"
      if ((space_partition__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 330 "space_partition.m"
        *space_partition__HeadVar__5_5 = space_partition__V_32_32;
#line 330 "space_partition.m"
      else
#line 330 "space_partition.m"
        {
          MR_Word space_partition__Subtree_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__2_2, (MR_Integer) 0)));
          MR_Word space_partition__Subtrees_12 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__2_2, (MR_Integer) 1)));
          MR_Word space_partition__OldBox_17;
          MR_Float space_partition__OldSurfaceArea_18;
          MR_Float space_partition__NewSurfaceArea_22;
          MR_Float space_partition__SurfaceAreaChange_23;
          MR_Word space_partition__P1_34;
          MR_Word space_partition__P2_35;
          MR_Word space_partition__P3_36;
          MR_Word space_partition__P4_37;
          MR_Word space_partition__V_38_38;
          MR_Word space_partition__V_39_39;
          MR_Float space_partition__X1_40;
          MR_Float space_partition__Y1_41;
          MR_Float space_partition__Z1_42;
          MR_Float space_partition__X2_43;
          MR_Float space_partition__Y2_44;
          MR_Float space_partition__Z2_45;
          MR_Float space_partition__L_46;
          MR_Float space_partition__M_47;
          MR_Float space_partition__N_48;
          MR_Float space_partition__V_51_51;
          MR_Float space_partition__V_52_52;
          MR_Float space_partition__V_53_53;

#line 335 "space_partition.m"
          if ((MR_tag((MR_Word) space_partition__Subtree_11) == MR_mktag((MR_Integer) 0)))
            {
              MR_Word space_partition__V_31_31 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__Subtree_11, (MR_Integer) 0)));
#line 334 "space_partition.m"
              MR_Word space_partition__V_19_19;

#line 334 "space_partition.m"
              space_partition__OldBox_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_31_31, (MR_Integer) 0)));
#line 334 "space_partition.m"
              space_partition__OldSurfaceArea_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_31_31, (MR_Integer) 1)));
#line 334 "space_partition.m"
              space_partition__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_31_31, (MR_Integer) 2)));
            }
#line 335 "space_partition.m"
          else
#line 335 "space_partition.m"
            {
              MR_Word space_partition__V_30_30 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__Subtree_11, (MR_Integer) 0)));
#line 336 "space_partition.m"
              MR_Word space_partition__V_20_20;

#line 336 "space_partition.m"
              space_partition__OldBox_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_30_30, (MR_Integer) 0)));
#line 336 "space_partition.m"
              space_partition__OldSurfaceArea_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_30_30, (MR_Integer) 1)));
#line 336 "space_partition.m"
              space_partition__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_30_30, (MR_Integer) 2)));
#line 335 "space_partition.m"
            }
#line 154 "space_partition.m"
          space_partition__P1_34 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__OldBox_17, (MR_Integer) 0)));
#line 154 "space_partition.m"
          space_partition__P2_35 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__OldBox_17, (MR_Integer) 1)));
#line 154 "space_partition.m"
          space_partition__P3_36 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
#line 154 "space_partition.m"
          space_partition__P4_37 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 1)));
#line 154 "space_partition.m"
          {
#line 154 "space_partition.m"
            space_partition__V_38_38 = space_partition__min_point_3_f_0(space_partition__P1_34, space_partition__P3_36);
          }
#line 154 "space_partition.m"
          {
#line 154 "space_partition.m"
            space_partition__V_39_39 = space_partition__max_point_3_f_0(space_partition__P2_35, space_partition__P4_37);
          }
#line 377 "space_partition.m"
          space_partition__X1_40 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_38_38, (MR_Integer) 0)));
#line 377 "space_partition.m"
          space_partition__Y1_41 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_38_38, (MR_Integer) 1)));
#line 377 "space_partition.m"
          space_partition__Z1_42 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_38_38, (MR_Integer) 2)));
#line 377 "space_partition.m"
          space_partition__X2_43 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_39_39, (MR_Integer) 0)));
#line 377 "space_partition.m"
          space_partition__Y2_44 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_39_39, (MR_Integer) 1)));
#line 377 "space_partition.m"
          space_partition__Z2_45 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_39_39, (MR_Integer) 2)));
#line 379 "space_partition.m"
          space_partition__L_46 = (space_partition__X1_40 - space_partition__X2_43);
#line 380 "space_partition.m"
          space_partition__M_47 = (space_partition__Y1_41 - space_partition__Y2_44);
#line 378 "space_partition.m"
          space_partition__V_53_53 = (space_partition__L_46 + space_partition__M_47);
#line 378 "space_partition.m"
          space_partition__V_52_52 = (space_partition__L_46 * space_partition__M_47);
#line 381 "space_partition.m"
          space_partition__N_48 = (space_partition__Z1_42 - space_partition__Z2_45);
#line 378 "space_partition.m"
          space_partition__V_51_51 = (space_partition__V_53_53 * space_partition__N_48);
#line 378 "space_partition.m"
          space_partition__NewSurfaceArea_22 = (space_partition__V_51_51 + space_partition__V_52_52);
#line 340 "space_partition.m"
          space_partition__SurfaceAreaChange_23 = (space_partition__NewSurfaceArea_22 - space_partition__OldSurfaceArea_18);
#line 341 "space_partition.m"
          space_partition__succeeded = (space_partition__SurfaceAreaChange_23 < space_partition__V_33_33);
#line 344 "space_partition.m"
          if (space_partition__succeeded)
            {
              MR_Integer space_partition__V_24_24;
              MR_Word space_partition__V_25_25;
              MR_Integer space_partition__V_26_26 = (MR_Integer) 1;

#line 342 "space_partition.m"
              space_partition__V_24_24 = (space_partition__HeadVar__3_3 + space_partition__V_26_26);
#line 342 "space_partition.m"
              {
#line 342 "space_partition.m"
                space_partition__V_25_25 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 342 "space_partition.m"
                MR_hl_field(MR_mktag(0), space_partition__V_25_25, 0) = MR_box_float(space_partition__SurfaceAreaChange_23);
#line 342 "space_partition.m"
                MR_hl_field(MR_mktag(0), space_partition__V_25_25, 1) = ((MR_Box) (space_partition__HeadVar__3_3));
#line 342 "space_partition.m"
              }
#line 342 "space_partition.m"
              {
#line 342 "space_partition.m"
                /* direct tailcall eliminated */
#line 342 "space_partition.m"
                {
#line 342 "space_partition.m"
                  MR_Word space_partition__HeadVar__2__tmp_copy_2 = space_partition__Subtrees_12;
#line 342 "space_partition.m"
                  MR_Integer space_partition__HeadVar__3__tmp_copy_3 = space_partition__V_24_24;
#line 342 "space_partition.m"
                  MR_Word space_partition__HeadVar__4__tmp_copy_4 = space_partition__V_25_25;

#line 342 "space_partition.m"
                  space_partition__HeadVar__2_2 = space_partition__HeadVar__2__tmp_copy_2;
#line 342 "space_partition.m"
                  space_partition__HeadVar__3_3 = space_partition__HeadVar__3__tmp_copy_3;
#line 342 "space_partition.m"
                  space_partition__HeadVar__4_4 = space_partition__HeadVar__4__tmp_copy_4;
#line 342 "space_partition.m"
                }
#line 342 "space_partition.m"
                goto loop_top;
#line 342 "space_partition.m"
              }
            }
#line 344 "space_partition.m"
          else
            {
              MR_Integer space_partition__V_27_27;
              MR_Integer space_partition__V_29_29 = (MR_Integer) 1;

#line 345 "space_partition.m"
              space_partition__V_27_27 = (space_partition__HeadVar__3_3 + space_partition__V_29_29);
#line 345 "space_partition.m"
              {
#line 345 "space_partition.m"
                /* direct tailcall eliminated */
#line 345 "space_partition.m"
                {
#line 345 "space_partition.m"
                  MR_Word space_partition__HeadVar__2__tmp_copy_2 = space_partition__Subtrees_12;
#line 345 "space_partition.m"
                  MR_Integer space_partition__HeadVar__3__tmp_copy_3 = space_partition__V_27_27;

#line 345 "space_partition.m"
                  space_partition__HeadVar__2_2 = space_partition__HeadVar__2__tmp_copy_2;
#line 345 "space_partition.m"
                  space_partition__HeadVar__3_3 = space_partition__HeadVar__3__tmp_copy_3;
#line 345 "space_partition.m"
                }
#line 345 "space_partition.m"
                goto loop_top;
#line 345 "space_partition.m"
              }
            }
#line 330 "space_partition.m"
        }
    }
  }
#line 326 "space_partition.m"
}

#line 293 "space_partition.m"
static void MR_CALL space_partition__space_tree_insert_3_p_0(
#line 293 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 293 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 293 "space_partition.m"
  MR_Word * space_partition__HeadVar__3_3)
#line 293 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__OldBox_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word space_partition__Subtrees0_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word space_partition__ObjBox_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word space_partition__NewBox_12;
    MR_Float space_partition__NewSurfaceArea_13;
    MR_Word space_partition__Subtrees_14;
    MR_Word space_partition__P1_27 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__OldBox_5, (MR_Integer) 0)));
    MR_Word space_partition__P2_28 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__OldBox_5, (MR_Integer) 1)));
    MR_Word space_partition__P3_29 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__ObjBox_9, (MR_Integer) 0)));
    MR_Word space_partition__P4_30 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__ObjBox_9, (MR_Integer) 1)));
    MR_Word space_partition__V_31_31;
    MR_Word space_partition__V_32_32;
    MR_Float space_partition__X1_33;
    MR_Float space_partition__Y1_34;
    MR_Float space_partition__Z1_35;
    MR_Float space_partition__X2_36;
    MR_Float space_partition__Y2_37;
    MR_Float space_partition__Z2_38;
    MR_Float space_partition__L_39;
    MR_Float space_partition__M_40;
    MR_Float space_partition__N_41;
    MR_Float space_partition__V_44_44;
    MR_Float space_partition__V_45_45;
    MR_Float space_partition__V_46_46;
#line 297 "space_partition.m"
    MR_Float space_partition__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
#line 298 "space_partition.m"
    MR_Float space_partition__V_10_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 1)));
#line 298 "space_partition.m"
    MR_Word space_partition__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 2)));

#line 154 "space_partition.m"
    {
#line 154 "space_partition.m"
      space_partition__V_31_31 = space_partition__min_point_3_f_0(space_partition__P1_27, space_partition__P3_29);
    }
#line 154 "space_partition.m"
    {
#line 154 "space_partition.m"
      space_partition__V_32_32 = space_partition__max_point_3_f_0(space_partition__P2_28, space_partition__P4_30);
    }
#line 154 "space_partition.m"
    {
#line 154 "space_partition.m"
      space_partition__NewBox_12 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 154 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__NewBox_12, 0) = ((MR_Box) (space_partition__V_31_31));
#line 154 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__NewBox_12, 1) = ((MR_Box) (space_partition__V_32_32));
#line 154 "space_partition.m"
    }
#line 377 "space_partition.m"
    space_partition__X1_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_31_31, (MR_Integer) 0)));
#line 377 "space_partition.m"
    space_partition__Y1_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_31_31, (MR_Integer) 1)));
#line 377 "space_partition.m"
    space_partition__Z1_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_31_31, (MR_Integer) 2)));
#line 377 "space_partition.m"
    space_partition__X2_36 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_32_32, (MR_Integer) 0)));
#line 377 "space_partition.m"
    space_partition__Y2_37 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_32_32, (MR_Integer) 1)));
#line 377 "space_partition.m"
    space_partition__Z2_38 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_32_32, (MR_Integer) 2)));
#line 379 "space_partition.m"
    space_partition__L_39 = (space_partition__X1_33 - space_partition__X2_36);
#line 380 "space_partition.m"
    space_partition__M_40 = (space_partition__Y1_34 - space_partition__Y2_37);
#line 378 "space_partition.m"
    space_partition__V_46_46 = (space_partition__L_39 + space_partition__M_40);
#line 378 "space_partition.m"
    space_partition__V_45_45 = (space_partition__L_39 * space_partition__M_40);
#line 381 "space_partition.m"
    space_partition__N_41 = (space_partition__Z1_35 - space_partition__Z2_38);
#line 378 "space_partition.m"
    space_partition__V_44_44 = (space_partition__V_46_46 * space_partition__N_41);
#line 378 "space_partition.m"
    space_partition__NewSurfaceArea_13 = (space_partition__V_44_44 + space_partition__V_45_45);
#line 302 "space_partition.m"
    space_partition__succeeded = (space_partition__Subtrees0_7 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 305 "space_partition.m"
    if (space_partition__succeeded)
      {
        MR_Word space_partition__V_18_18;
        MR_Word space_partition__V_19_19;

#line 304 "space_partition.m"
        {
#line 304 "space_partition.m"
          space_partition__V_18_18 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "leaf"));
#line 304 "space_partition.m"
          MR_hl_field(MR_mktag(1), space_partition__V_18_18, 0) = ((MR_Box) (space_partition__HeadVar__1_1));
#line 304 "space_partition.m"
        }
#line 304 "space_partition.m"
        space_partition__V_19_19 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 304 "space_partition.m"
        {
#line 304 "space_partition.m"
          space_partition__Subtrees_14 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 304 "space_partition.m"
          MR_hl_field(MR_mktag(1), space_partition__Subtrees_14, 0) = ((MR_Box) (space_partition__V_18_18));
#line 304 "space_partition.m"
          MR_hl_field(MR_mktag(1), space_partition__Subtrees_14, 1) = ((MR_Box) (space_partition__V_19_19));
#line 304 "space_partition.m"
        }
      }
#line 305 "space_partition.m"
    else
#line 309 "space_partition.m"
      {
#line 309 "space_partition.m"
        MR_Word space_partition__Leaf_15;
        MR_Word space_partition__V_20_20;

#line 306 "space_partition.m"
        space_partition__succeeded = (MR_tag((MR_Word) space_partition__Subtrees0_7) == MR_mktag((MR_Integer) 1));
#line 306 "space_partition.m"
        if ((MR_tag((MR_Word) space_partition__Subtrees0_7) == MR_mktag((MR_Integer) 1)))
#line 306 "space_partition.m"
          {
#line 306 "space_partition.m"
            space_partition__Leaf_15 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__Subtrees0_7, (MR_Integer) 0)));
#line 306 "space_partition.m"
            space_partition__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__Subtrees0_7, (MR_Integer) 1)));
#line 306 "space_partition.m"
          }
        if (space_partition__succeeded)
#line 306 "space_partition.m"
          space_partition__succeeded = (space_partition__V_20_20 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 309 "space_partition.m"
        if (space_partition__succeeded)
          {
            MR_Word space_partition__V_21_21;
            MR_Word space_partition__V_22_22;
            MR_Word space_partition__V_23_23;

#line 308 "space_partition.m"
            {
#line 308 "space_partition.m"
              space_partition__V_21_21 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "leaf"));
#line 308 "space_partition.m"
              MR_hl_field(MR_mktag(1), space_partition__V_21_21, 0) = ((MR_Box) (space_partition__HeadVar__1_1));
#line 308 "space_partition.m"
            }
#line 308 "space_partition.m"
            space_partition__V_23_23 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 308 "space_partition.m"
            {
#line 308 "space_partition.m"
              space_partition__V_22_22 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 308 "space_partition.m"
              MR_hl_field(MR_mktag(1), space_partition__V_22_22, 0) = ((MR_Box) (space_partition__Leaf_15));
#line 308 "space_partition.m"
              MR_hl_field(MR_mktag(1), space_partition__V_22_22, 1) = ((MR_Box) (space_partition__V_23_23));
#line 308 "space_partition.m"
            }
#line 308 "space_partition.m"
            {
#line 308 "space_partition.m"
              space_partition__Subtrees_14 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 308 "space_partition.m"
              MR_hl_field(MR_mktag(1), space_partition__Subtrees_14, 0) = ((MR_Box) (space_partition__V_21_21));
#line 308 "space_partition.m"
              MR_hl_field(MR_mktag(1), space_partition__Subtrees_14, 1) = ((MR_Box) (space_partition__V_22_22));
#line 308 "space_partition.m"
            }
          }
#line 309 "space_partition.m"
        else
          {
            MR_Float space_partition__SurfaceAreaChange_16;
            MR_Integer space_partition__SelectedSubtree_17;
            MR_Integer space_partition__V_24_24;
            MR_Word space_partition__V_25_25;
            MR_Integer space_partition__V_26_26;

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL space_partition__space_tree_insert_3_p_0
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Float Max;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
Max = ML_FLOAT_MAX;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
space_partition__SurfaceAreaChange_16
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = Max;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
#line 311 "space_partition.m"
            space_partition__V_24_24 = (MR_Integer) 1;
#line 312 "space_partition.m"
            space_partition__V_26_26 = (MR_Integer) 0;
#line 311 "space_partition.m"
            {
#line 311 "space_partition.m"
              space_partition__V_25_25 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 311 "space_partition.m"
              MR_hl_field(MR_mktag(0), space_partition__V_25_25, 0) = MR_box_float(space_partition__SurfaceAreaChange_16);
#line 311 "space_partition.m"
              MR_hl_field(MR_mktag(0), space_partition__V_25_25, 1) = ((MR_Box) (space_partition__V_26_26));
#line 311 "space_partition.m"
            }
#line 311 "space_partition.m"
            {
#line 311 "space_partition.m"
              space_partition__select_subtree_5_p_0(space_partition__ObjBox_9, space_partition__Subtrees0_7, space_partition__V_24_24, space_partition__V_25_25, &space_partition__SelectedSubtree_17);
            }
#line 314 "space_partition.m"
            {
#line 314 "space_partition.m"
              space_partition__subtree_insert_4_p_0(space_partition__Subtrees0_7, space_partition__SelectedSubtree_17, space_partition__HeadVar__1_1, &space_partition__Subtrees_14);
            }
          }
#line 309 "space_partition.m"
      }
#line 317 "space_partition.m"
    {
#line 317 "space_partition.m"
      *space_partition__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "space_tree");
#line 317 "space_partition.m"
      MR_hl_field(MR_mktag(0), *space_partition__HeadVar__3_3, 0) = ((MR_Box) (space_partition__NewBox_12));
#line 317 "space_partition.m"
      MR_hl_field(MR_mktag(0), *space_partition__HeadVar__3_3, 1) = MR_box_float(space_partition__NewSurfaceArea_13);
#line 317 "space_partition.m"
      MR_hl_field(MR_mktag(0), *space_partition__HeadVar__3_3, 2) = ((MR_Box) (space_partition__Subtrees_14));
#line 317 "space_partition.m"
    }
  }
#line 293 "space_partition.m"
}

#line 242 "space_partition.m"
MR_Word MR_CALL space_partition__build_space_tree_2_f_0(
#line 242 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1)
#line 242 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__HeadVar__2_2;
    MR_Float space_partition__Max_5;
    MR_Float space_partition__Min_6;
    MR_Word space_partition__MinBound_7;
    MR_Word space_partition__MaxBound_8;
    MR_Word space_partition__BoundingBox_9;
    MR_Float space_partition__SurfaceArea_10;
    MR_Word space_partition__Tree0_11;
    MR_Word space_partition__V_20_20;

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL space_partition__build_space_tree_2_f_0
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Float Max;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
Max = ML_FLOAT_MAX;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
space_partition__Max_5
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = Max;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL space_partition__build_space_tree_2_f_0
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Float Min;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
Min = ML_FLOAT_MIN;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
space_partition__Min_6
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = Min;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
#line 247 "space_partition.m"
    {
#line 247 "space_partition.m"
      space_partition__MinBound_7 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 247 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__MinBound_7, 0) = MR_box_float(space_partition__Max_5);
#line 247 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__MinBound_7, 1) = MR_box_float(space_partition__Max_5);
#line 247 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__MinBound_7, 2) = MR_box_float(space_partition__Max_5);
#line 247 "space_partition.m"
    }
#line 248 "space_partition.m"
    {
#line 248 "space_partition.m"
      space_partition__MaxBound_8 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 248 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__MaxBound_8, 0) = MR_box_float(space_partition__Min_6);
#line 248 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__MaxBound_8, 1) = MR_box_float(space_partition__Min_6);
#line 248 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__MaxBound_8, 2) = MR_box_float(space_partition__Min_6);
#line 248 "space_partition.m"
    }
#line 249 "space_partition.m"
    {
#line 249 "space_partition.m"
      space_partition__BoundingBox_9 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 249 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__BoundingBox_9, 0) = ((MR_Box) (space_partition__MinBound_7));
#line 249 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__BoundingBox_9, 1) = ((MR_Box) (space_partition__MaxBound_8));
#line 249 "space_partition.m"
    }
#line 250 "space_partition.m"
    space_partition__SurfaceArea_10 = (MR_Float) 0.00000000000000;
#line 251 "space_partition.m"
    space_partition__V_20_20 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 251 "space_partition.m"
    {
#line 251 "space_partition.m"
      space_partition__Tree0_11 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "space_tree");
#line 251 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Tree0_11, 0) = ((MR_Box) (space_partition__BoundingBox_9));
#line 251 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Tree0_11, 1) = MR_box_float(space_partition__SurfaceArea_10);
#line 251 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Tree0_11, 2) = ((MR_Box) (space_partition__V_20_20));
#line 251 "space_partition.m"
    }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      space_partition__DeforestationIn__pred__build_space_tree__128__0_3_p_0(space_partition__HeadVar__1_1, &space_partition__HeadVar__2_2, space_partition__Tree0_11);
    }
    return space_partition__HeadVar__2_2;
  }
#line 242 "space_partition.m"
}
#line 184 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_1 = (MR_Float) -1.00000000000000;
#line 184 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_2 = (MR_Float) -1.00000000000000;
#line 184 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_3 = (MR_Float) -1.00000000000000;
#line 184 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_4_V_4_4[3] = {
		(MR_Box) &space_partition__float_10_0_1,
		(MR_Box) &space_partition__float_10_0_2,
		(MR_Box) &space_partition__float_10_0_3};
#line 184 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_5 = (MR_Float) 1.00000000000000;
#line 184 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_6 = (MR_Float) 1.00000000000000;
#line 184 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_7 = (MR_Float) 1.00000000000000;
#line 184 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_8_V_5_5[3] = {
		(MR_Box) &space_partition__float_10_0_5,
		(MR_Box) &space_partition__float_10_0_6,
		(MR_Box) &space_partition__float_10_0_7};
#line 183 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_9_HeadVar__2_2[2] = {
		((MR_Box) (&space_partition__const_10_0_4_V_4_4)),
		((MR_Box) (&space_partition__const_10_0_8_V_5_5))};
#line 187 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_10 = (MR_Float) 0.00000000000000;
#line 187 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_11 = (MR_Float) 0.00000000000000;
#line 187 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_12 = (MR_Float) 0.00000000000000;
#line 187 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_13_V_13_13[3] = {
		(MR_Box) &space_partition__float_10_0_10,
		(MR_Box) &space_partition__float_10_0_11,
		(MR_Box) &space_partition__float_10_0_12};
#line 187 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_14 = (MR_Float) 1.00000000000000;
#line 187 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_15 = (MR_Float) 1.00000000000000;
#line 187 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_16 = (MR_Float) 1.00000000000000;
#line 187 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_17_V_14_14[3] = {
		(MR_Box) &space_partition__float_10_0_14,
		(MR_Box) &space_partition__float_10_0_15,
		(MR_Box) &space_partition__float_10_0_16};
#line 186 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_18_HeadVar__2_2[2] = {
		((MR_Box) (&space_partition__const_10_0_13_V_13_13)),
		((MR_Box) (&space_partition__const_10_0_17_V_14_14))};
#line 190 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_19 = (MR_Float) -1.00000000000000;
#line 190 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_20 = (MR_Float) 0.00000000000000;
#line 190 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_21 = (MR_Float) -1.00000000000000;
#line 190 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_22_V_22_22[3] = {
		(MR_Box) &space_partition__float_10_0_19,
		(MR_Box) &space_partition__float_10_0_20,
		(MR_Box) &space_partition__float_10_0_21};
#line 190 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_23 = (MR_Float) 1.00000000000000;
#line 190 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_24 = (MR_Float) 1.00000000000000;
#line 190 "space_partition.m"
static /* final */ const MR_Float space_partition__float_10_0_25 = (MR_Float) 1.00000000000000;
#line 190 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_26_V_23_23[3] = {
		(MR_Box) &space_partition__float_10_0_23,
		(MR_Box) &space_partition__float_10_0_24,
		(MR_Box) &space_partition__float_10_0_25};
#line 189 "space_partition.m"
static /* final */ const MR_Box space_partition__const_10_0_27_HeadVar__2_2[2] = {
		((MR_Box) (&space_partition__const_10_0_22_V_22_22)),
		((MR_Box) (&space_partition__const_10_0_26_V_23_23))};

#line 181 "space_partition.m"
static MR_Word MR_CALL space_partition__find_basic_object_bounding_box_2_f_0(
#line 181 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1)
#line 181 "space_partition.m"
{
#line 183 "space_partition.m"
  {
#line 183 "space_partition.m"
    /* tailcall optimized into a loop */
#line 183 "space_partition.m"
  loop_top:;
#line 183 "space_partition.m"
    {
#line 183 "space_partition.m"
      bool space_partition__succeeded;
#line 183 "space_partition.m"
      MR_Word space_partition__HeadVar__2_2;

#line 183 "space_partition.m"
#line 183 "space_partition.m"
      switch (MR_tag((MR_Word) space_partition__HeadVar__1_1)) {
#line 183 "space_partition.m"
        default: /*NOTREACHED*/ MR_assert(0);
#line 183 "space_partition.m"
        case (MR_Integer) 3:
#line 183 "space_partition.m"
#line 183 "space_partition.m"
          switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 0)))) {
#line 183 "space_partition.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 183 "space_partition.m"
            case (MR_Integer) 0:
              {
                MR_Word space_partition__Surface_30 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 1)));
                MR_Word space_partition__V_31_31;

#line 194 "space_partition.m"
                {
#line 194 "space_partition.m"
                  space_partition__V_31_31 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "cylinder"));
#line 194 "space_partition.m"
                  MR_hl_field(MR_mktag(2), space_partition__V_31_31, 0) = ((MR_Box) (space_partition__Surface_30));
#line 194 "space_partition.m"
                }
#line 193 "space_partition.m"
                {
#line 193 "space_partition.m"
                  /* direct tailcall eliminated */
#line 193 "space_partition.m"
                  {
#line 193 "space_partition.m"
                    MR_Word space_partition__HeadVar__1__tmp_copy_1 = space_partition__V_31_31;

#line 193 "space_partition.m"
                    space_partition__HeadVar__1_1 = space_partition__HeadVar__1__tmp_copy_1;
#line 193 "space_partition.m"
                  }
#line 193 "space_partition.m"
                  goto loop_top;
#line 193 "space_partition.m"
                }
              }
#line 183 "space_partition.m"
              break;
#line 183 "space_partition.m"
            case (MR_Integer) 1:
              {
                MR_Word space_partition__V_34_34;
                MR_Word space_partition__V_35_35;
                MR_Integer space_partition__V_36_36 = (MR_Integer) 0;
                MR_Word space_partition__V_38_38 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
                MR_Word space_partition__TypeInfo_39_39;

#line 197 "space_partition.m"
                {
#line 197 "space_partition.m"
                  space_partition__V_35_35 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 197 "space_partition.m"
                  MR_hl_field(MR_mktag(0), space_partition__V_35_35, 0) = ((MR_Box) (space_partition__V_36_36));
#line 197 "space_partition.m"
                  MR_hl_field(MR_mktag(0), space_partition__V_35_35, 1) = ((MR_Box) (space_partition__HeadVar__1_1));
#line 197 "space_partition.m"
                  MR_hl_field(MR_mktag(0), space_partition__V_35_35, 2) = ((MR_Box) (space_partition__V_38_38));
#line 197 "space_partition.m"
                }
#line 197 "space_partition.m"
                space_partition__V_34_34 = (MR_Word) space_partition__V_35_35;
                space_partition__TypeInfo_39_39 = (MR_Word) (&space_partition__space_partition__type_ctor_info_invalid_object_0);
#line 197 "space_partition.m"
                {
#line 197 "space_partition.m"
                  mercury__exception__throw_1_p_0(space_partition__TypeInfo_39_39, ((MR_Box) (space_partition__V_34_34)));
                }
              }
#line 183 "space_partition.m"
              break;
#line 183 "space_partition.m"
          }
#line 183 "space_partition.m"
          break;
#line 183 "space_partition.m"
        case (MR_Integer) 0:
          {
            MR_Word space_partition__V_4_4 = (MR_Word) &space_partition__const_10_0_4_V_4_4;
            MR_Word space_partition__V_5_5 = (MR_Word) &space_partition__const_10_0_8_V_5_5;
            MR_Float space_partition__V_6_6 = (MR_Float) -1.00000000000000;
            MR_Float space_partition__V_7_7 = (MR_Float) -1.00000000000000;
            MR_Float space_partition__V_8_8 = (MR_Float) -1.00000000000000;
            MR_Float space_partition__V_9_9 = (MR_Float) 1.00000000000000;
            MR_Float space_partition__V_10_10 = (MR_Float) 1.00000000000000;
            MR_Float space_partition__V_11_11 = (MR_Float) 1.00000000000000;

#line 183 "space_partition.m"
            space_partition__HeadVar__2_2 = (MR_Word) &space_partition__const_10_0_9_HeadVar__2_2;
          }
#line 183 "space_partition.m"
          break;
#line 183 "space_partition.m"
        case (MR_Integer) 1:
          {
            MR_Word space_partition__V_13_13 = (MR_Word) &space_partition__const_10_0_13_V_13_13;
            MR_Word space_partition__V_14_14 = (MR_Word) &space_partition__const_10_0_17_V_14_14;
            MR_Float space_partition__V_15_15 = (MR_Float) 0.00000000000000;
            MR_Float space_partition__V_16_16 = (MR_Float) 0.00000000000000;
            MR_Float space_partition__V_17_17 = (MR_Float) 0.00000000000000;
            MR_Float space_partition__V_18_18 = (MR_Float) 1.00000000000000;
            MR_Float space_partition__V_19_19 = (MR_Float) 1.00000000000000;
            MR_Float space_partition__V_20_20 = (MR_Float) 1.00000000000000;

#line 186 "space_partition.m"
            space_partition__HeadVar__2_2 = (MR_Word) &space_partition__const_10_0_18_HeadVar__2_2;
          }
#line 183 "space_partition.m"
          break;
#line 183 "space_partition.m"
        case (MR_Integer) 2:
          {
            MR_Word space_partition__V_22_22 = (MR_Word) &space_partition__const_10_0_22_V_22_22;
            MR_Word space_partition__V_23_23 = (MR_Word) &space_partition__const_10_0_26_V_23_23;
            MR_Float space_partition__V_24_24 = (MR_Float) -1.00000000000000;
            MR_Float space_partition__V_25_25 = (MR_Float) 0.00000000000000;
            MR_Float space_partition__V_26_26 = (MR_Float) -1.00000000000000;
            MR_Float space_partition__V_27_27 = (MR_Float) 1.00000000000000;
            MR_Float space_partition__V_28_28 = (MR_Float) 1.00000000000000;
            MR_Float space_partition__V_29_29 = (MR_Float) 1.00000000000000;

#line 189 "space_partition.m"
            space_partition__HeadVar__2_2 = (MR_Word) &space_partition__const_10_0_27_HeadVar__2_2;
          }
#line 183 "space_partition.m"
          break;
#line 183 "space_partition.m"
      }
#line 183 "space_partition.m"
      return space_partition__HeadVar__2_2;
#line 183 "space_partition.m"
    }
#line 183 "space_partition.m"
  }
#line 181 "space_partition.m"
}

#line 161 "space_partition.m"
static MR_Word MR_CALL space_partition__max_point_3_f_0(
#line 161 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 161 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2)
#line 161 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__HeadVar__3_3;
    MR_Float space_partition__X1_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float space_partition__Y1_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float space_partition__Z1_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float space_partition__X2_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float space_partition__Y2_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float space_partition__Z2_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float space_partition__V_10_10;
    MR_Float space_partition__V_11_11;
    MR_Float space_partition__V_12_12;

#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    space_partition__succeeded = (space_partition__X1_4 >= space_partition__X2_7);
#line 64 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (space_partition__succeeded)
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      space_partition__V_10_10 = space_partition__X1_4;
#line 64 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      space_partition__V_10_10 = space_partition__X2_7;
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    space_partition__succeeded = (space_partition__Y1_5 >= space_partition__Y2_8);
#line 64 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (space_partition__succeeded)
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      space_partition__V_11_11 = space_partition__Y1_5;
#line 64 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      space_partition__V_11_11 = space_partition__Y2_8;
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    space_partition__succeeded = (space_partition__Z1_6 >= space_partition__Z2_9);
#line 64 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (space_partition__succeeded)
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      space_partition__V_12_12 = space_partition__Z1_6;
#line 64 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      space_partition__V_12_12 = space_partition__Z2_9;
#line 163 "space_partition.m"
    {
#line 163 "space_partition.m"
      space_partition__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 163 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, 0) = MR_box_float(space_partition__V_10_10);
#line 163 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, 1) = MR_box_float(space_partition__V_11_11);
#line 163 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, 2) = MR_box_float(space_partition__V_12_12);
#line 163 "space_partition.m"
    }
    return space_partition__HeadVar__3_3;
  }
#line 161 "space_partition.m"
}

#line 156 "space_partition.m"
static MR_Word MR_CALL space_partition__min_point_3_f_0(
#line 156 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 156 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2)
#line 156 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__HeadVar__3_3;
    MR_Float space_partition__X1_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float space_partition__Y1_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float space_partition__Z1_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float space_partition__X2_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float space_partition__Y2_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float space_partition__Z2_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float space_partition__V_10_10;
    MR_Float space_partition__V_11_11;
    MR_Float space_partition__V_12_12;

#line 69 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    space_partition__succeeded = (space_partition__X1_4 <= space_partition__X2_7);
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (space_partition__succeeded)
#line 71 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      space_partition__V_10_10 = space_partition__X1_4;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      space_partition__V_10_10 = space_partition__X2_7;
#line 69 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    space_partition__succeeded = (space_partition__Y1_5 <= space_partition__Y2_8);
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (space_partition__succeeded)
#line 71 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      space_partition__V_11_11 = space_partition__Y1_5;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      space_partition__V_11_11 = space_partition__Y2_8;
#line 69 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    space_partition__succeeded = (space_partition__Z1_6 <= space_partition__Z2_9);
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (space_partition__succeeded)
#line 71 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      space_partition__V_12_12 = space_partition__Z1_6;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      space_partition__V_12_12 = space_partition__Z2_9;
#line 158 "space_partition.m"
    {
#line 158 "space_partition.m"
      space_partition__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 158 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, 0) = MR_box_float(space_partition__V_10_10);
#line 158 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, 1) = MR_box_float(space_partition__V_11_11);
#line 158 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, 2) = MR_box_float(space_partition__V_12_12);
#line 158 "space_partition.m"
    }
    return space_partition__HeadVar__3_3;
  }
#line 156 "space_partition.m"
}

#line 127 "space_partition.m"
static MR_Word MR_CALL space_partition__object_contains_plane_2_f_0(
#line 127 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1)
#line 127 "space_partition.m"
{
#line 129 "space_partition.m"
  {
#line 129 "space_partition.m"
    /* tailcall optimized into a loop */
#line 129 "space_partition.m"
  loop_top:;
#line 129 "space_partition.m"
    {
#line 129 "space_partition.m"
      bool space_partition__succeeded;
#line 129 "space_partition.m"
      MR_Word space_partition__HeadVar__2_2;
#line 129 "space_partition.m"
      MR_Word space_partition__Obj_4;
#line 129 "space_partition.m"
      MR_Word space_partition__Obj_7;
#line 129 "space_partition.m"
      MR_Word space_partition__Obj1_9;
#line 129 "space_partition.m"
      MR_Word space_partition__Obj2_10;
#line 129 "space_partition.m"
      MR_Word space_partition__V_12_12;
#line 129 "space_partition.m"
      MR_Word space_partition__V_13_13;
#line 129 "space_partition.m"
      MR_Word space_partition__Obj1_14;
#line 129 "space_partition.m"
      MR_Word space_partition__Obj2_15;
#line 129 "space_partition.m"
      MR_Word space_partition__V_17_17;
#line 129 "space_partition.m"
      MR_Word space_partition__V_18_18;
#line 129 "space_partition.m"
      MR_Word space_partition__Obj1_19;
#line 129 "space_partition.m"
      MR_Word space_partition__Obj2_20;
#line 129 "space_partition.m"
      MR_Word space_partition__V_22_22;
#line 129 "space_partition.m"
      MR_Word space_partition__V_23_23;

#line 129 "space_partition.m"
#line 129 "space_partition.m"
      switch (MR_tag((MR_Word) space_partition__HeadVar__1_1)) {
#line 129 "space_partition.m"
        default: /*NOTREACHED*/ MR_assert(0);
#line 129 "space_partition.m"
        case (MR_Integer) 3:
#line 129 "space_partition.m"
#line 129 "space_partition.m"
          switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 0)))) {
#line 129 "space_partition.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 129 "space_partition.m"
            case (MR_Integer) 0:
              {
#line 136 "space_partition.m"
                space_partition__Obj1_14 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 1)));
#line 136 "space_partition.m"
                space_partition__Obj2_15 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 2)));
#line 137 "space_partition.m"
                {
#line 137 "space_partition.m"
                  space_partition__V_17_17 = space_partition__object_contains_plane_2_f_0(space_partition__Obj1_14);
                }
#line 137 "space_partition.m"
                {
#line 137 "space_partition.m"
                  space_partition__V_18_18 = space_partition__object_contains_plane_2_f_0(space_partition__Obj2_15);
                }
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                switch (space_partition__V_17_17) {
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                  default: /*NOTREACHED*/ MR_assert(0);
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                  case (MR_Integer) 0:
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                    space_partition__HeadVar__2_2 = (MR_Integer) 0;
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                    break;
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                  case (MR_Integer) 1:
#line 13 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                    space_partition__HeadVar__2_2 = space_partition__V_18_18;
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                    break;
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                }
              }
#line 129 "space_partition.m"
              break;
#line 129 "space_partition.m"
            case (MR_Integer) 1:
              {
#line 139 "space_partition.m"
                space_partition__Obj1_19 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 1)));
#line 139 "space_partition.m"
                space_partition__Obj2_20 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 2)));
#line 140 "space_partition.m"
                {
#line 140 "space_partition.m"
                  space_partition__V_22_22 = space_partition__object_contains_plane_2_f_0(space_partition__Obj1_19);
                }
#line 140 "space_partition.m"
                {
#line 140 "space_partition.m"
                  space_partition__V_23_23 = space_partition__object_contains_plane_2_f_0(space_partition__Obj2_20);
                }
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                switch (space_partition__V_22_22) {
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                  default: /*NOTREACHED*/ MR_assert(0);
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                  case (MR_Integer) 0:
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                    space_partition__HeadVar__2_2 = (MR_Integer) 0;
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                    break;
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                  case (MR_Integer) 1:
#line 13 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                    space_partition__HeadVar__2_2 = space_partition__V_23_23;
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                    break;
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                }
              }
#line 129 "space_partition.m"
              break;
#line 129 "space_partition.m"
          }
#line 129 "space_partition.m"
          break;
#line 129 "space_partition.m"
        case (MR_Integer) 0:
          {
#line 129 "space_partition.m"
            MR_Integer space_partition__V_3_3 = ((MR_Integer) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
#line 129 "space_partition.m"
            MR_Word space_partition__V_5_5;
#line 130 "space_partition.m"
            MR_Word space_partition__V_6_6;

#line 129 "space_partition.m"
            space_partition__Obj_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 1)));
#line 129 "space_partition.m"
            space_partition__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 2)));
#line 130 "space_partition.m"
            space_partition__succeeded = ((MR_tag((MR_Word) space_partition__Obj_4) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), space_partition__Obj_4, (MR_Integer) 0))) == (MR_Integer) 1));
#line 130 "space_partition.m"
            if (((MR_tag((MR_Word) space_partition__Obj_4) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), space_partition__Obj_4, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 130 "space_partition.m"
              space_partition__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__Obj_4, (MR_Integer) 1)));
#line 129 "space_partition.m"
            if (space_partition__succeeded)
#line 129 "space_partition.m"
              space_partition__HeadVar__2_2 = (MR_Integer) 1;
#line 129 "space_partition.m"
            else
#line 129 "space_partition.m"
              space_partition__HeadVar__2_2 = (MR_Integer) 0;
          }
#line 129 "space_partition.m"
          break;
#line 129 "space_partition.m"
        case (MR_Integer) 1:
          {
#line 131 "space_partition.m"
            MR_Word space_partition__V_8_8;

#line 131 "space_partition.m"
            space_partition__Obj_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__1_1, (MR_Integer) 0)));
#line 131 "space_partition.m"
            space_partition__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__1_1, (MR_Integer) 1)));
#line 131 "space_partition.m"
            {
#line 131 "space_partition.m"
              /* direct tailcall eliminated */
#line 131 "space_partition.m"
              {
#line 131 "space_partition.m"
                MR_Word space_partition__HeadVar__1__tmp_copy_1 = space_partition__Obj_7;

#line 131 "space_partition.m"
                space_partition__HeadVar__1_1 = space_partition__HeadVar__1__tmp_copy_1;
#line 131 "space_partition.m"
              }
#line 131 "space_partition.m"
              goto loop_top;
#line 131 "space_partition.m"
            }
          }
#line 129 "space_partition.m"
          break;
#line 129 "space_partition.m"
        case (MR_Integer) 2:
          {
#line 133 "space_partition.m"
            space_partition__Obj1_9 = ((MR_Word) (MR_hl_field(MR_mktag(2), space_partition__HeadVar__1_1, (MR_Integer) 0)));
#line 133 "space_partition.m"
            space_partition__Obj2_10 = ((MR_Word) (MR_hl_field(MR_mktag(2), space_partition__HeadVar__1_1, (MR_Integer) 1)));
#line 134 "space_partition.m"
            {
#line 134 "space_partition.m"
              space_partition__V_12_12 = space_partition__object_contains_plane_2_f_0(space_partition__Obj1_9);
            }
#line 134 "space_partition.m"
            {
#line 134 "space_partition.m"
              space_partition__V_13_13 = space_partition__object_contains_plane_2_f_0(space_partition__Obj2_10);
            }
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
            switch (space_partition__V_12_12) {
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
              default: /*NOTREACHED*/ MR_assert(0);
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
              case (MR_Integer) 0:
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                space_partition__HeadVar__2_2 = (MR_Integer) 0;
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                break;
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
              case (MR_Integer) 1:
#line 13 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                space_partition__HeadVar__2_2 = space_partition__V_13_13;
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
                break;
#line 12 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/bool.opt"
            }
          }
#line 129 "space_partition.m"
          break;
#line 129 "space_partition.m"
      }
#line 129 "space_partition.m"
      return space_partition__HeadVar__2_2;
#line 129 "space_partition.m"
    }
#line 129 "space_partition.m"
  }
#line 127 "space_partition.m"
}

#line 70 "space_partition.m"
void MR_CALL space_partition__split_partitionable_objects_3_p_0(
#line 70 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 70 "space_partition.m"
  MR_Word * space_partition__HeadVar__2_2,
#line 70 "space_partition.m"
  MR_Word * space_partition__HeadVar__3_3)
#line 70 "space_partition.m"
{
#line 74 "space_partition.m"
  {
#line 74 "space_partition.m"
    bool space_partition__succeeded;

#line 74 "space_partition.m"
#line 74 "space_partition.m"
    switch (MR_tag((MR_Word) space_partition__HeadVar__1_1)) {
#line 74 "space_partition.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 74 "space_partition.m"
      case (MR_Integer) 3:
#line 74 "space_partition.m"
#line 74 "space_partition.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 0)))) {
#line 74 "space_partition.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 74 "space_partition.m"
          case (MR_Integer) 0:
            {
              MR_Word space_partition__Obj1_36 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word space_partition__Obj2_37 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 2)));
              MR_Word space_partition__V_39_39;

#line 102 "space_partition.m"
              {
#line 102 "space_partition.m"
                space_partition__V_39_39 = space_partition__object_contains_plane_2_f_0(space_partition__Obj1_36);
              }
#line 102 "space_partition.m"
              space_partition__succeeded = (space_partition__V_39_39 == (MR_Integer) 1);
#line 103 "space_partition.m"
              if (!(space_partition__succeeded))
#line 103 "space_partition.m"
                {
                  MR_Word space_partition__V_38_38;

#line 103 "space_partition.m"
                  {
#line 103 "space_partition.m"
                    space_partition__V_38_38 = space_partition__object_contains_plane_2_f_0(space_partition__Obj2_37);
                  }
#line 103 "space_partition.m"
                  space_partition__succeeded = (space_partition__V_38_38 == (MR_Integer) 1);
#line 103 "space_partition.m"
                }
#line 108 "space_partition.m"
              if (space_partition__succeeded)
                {
                  MR_Word space_partition__V_40_40;

#line 106 "space_partition.m"
                  *space_partition__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 107 "space_partition.m"
                  space_partition__V_40_40 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 107 "space_partition.m"
                  {
#line 107 "space_partition.m"
                    *space_partition__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 107 "space_partition.m"
                    MR_hl_field(MR_mktag(1), *space_partition__HeadVar__3_3, 0) = ((MR_Box) (space_partition__HeadVar__1_1));
#line 107 "space_partition.m"
                    MR_hl_field(MR_mktag(1), *space_partition__HeadVar__3_3, 1) = ((MR_Box) (space_partition__V_40_40));
#line 107 "space_partition.m"
                  }
                }
#line 108 "space_partition.m"
              else
                {
                  MR_Word space_partition__V_41_41;

#line 109 "space_partition.m"
                  *space_partition__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 110 "space_partition.m"
                  space_partition__V_41_41 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 110 "space_partition.m"
                  {
#line 110 "space_partition.m"
                    *space_partition__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 110 "space_partition.m"
                    MR_hl_field(MR_mktag(1), *space_partition__HeadVar__2_2, 0) = ((MR_Box) (space_partition__HeadVar__1_1));
#line 110 "space_partition.m"
                    MR_hl_field(MR_mktag(1), *space_partition__HeadVar__2_2, 1) = ((MR_Box) (space_partition__V_41_41));
#line 110 "space_partition.m"
                  }
                }
            }
#line 74 "space_partition.m"
            break;
#line 74 "space_partition.m"
          case (MR_Integer) 1:
            {
              MR_Word space_partition__Obj1_45 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word space_partition__Obj2_46 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 2)));
              MR_Word space_partition__V_48_48;

#line 116 "space_partition.m"
              {
#line 116 "space_partition.m"
                space_partition__V_48_48 = space_partition__object_contains_plane_2_f_0(space_partition__Obj1_45);
              }
#line 116 "space_partition.m"
              space_partition__succeeded = (space_partition__V_48_48 == (MR_Integer) 1);
#line 117 "space_partition.m"
              if (!(space_partition__succeeded))
#line 117 "space_partition.m"
                {
                  MR_Word space_partition__V_47_47;

#line 117 "space_partition.m"
                  {
#line 117 "space_partition.m"
                    space_partition__V_47_47 = space_partition__object_contains_plane_2_f_0(space_partition__Obj2_46);
                  }
#line 117 "space_partition.m"
                  space_partition__succeeded = (space_partition__V_47_47 == (MR_Integer) 1);
#line 117 "space_partition.m"
                }
#line 122 "space_partition.m"
              if (space_partition__succeeded)
                {
                  MR_Word space_partition__V_49_49;

#line 120 "space_partition.m"
                  *space_partition__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 121 "space_partition.m"
                  space_partition__V_49_49 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 121 "space_partition.m"
                  {
#line 121 "space_partition.m"
                    *space_partition__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 121 "space_partition.m"
                    MR_hl_field(MR_mktag(1), *space_partition__HeadVar__3_3, 0) = ((MR_Box) (space_partition__HeadVar__1_1));
#line 121 "space_partition.m"
                    MR_hl_field(MR_mktag(1), *space_partition__HeadVar__3_3, 1) = ((MR_Box) (space_partition__V_49_49));
#line 121 "space_partition.m"
                  }
                }
#line 122 "space_partition.m"
              else
                {
                  MR_Word space_partition__V_50_50;

#line 123 "space_partition.m"
                  *space_partition__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 124 "space_partition.m"
                  space_partition__V_50_50 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 124 "space_partition.m"
                  {
#line 124 "space_partition.m"
                    *space_partition__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 124 "space_partition.m"
                    MR_hl_field(MR_mktag(1), *space_partition__HeadVar__2_2, 0) = ((MR_Box) (space_partition__HeadVar__1_1));
#line 124 "space_partition.m"
                    MR_hl_field(MR_mktag(1), *space_partition__HeadVar__2_2, 1) = ((MR_Box) (space_partition__V_50_50));
#line 124 "space_partition.m"
                  }
                }
            }
#line 74 "space_partition.m"
            break;
#line 74 "space_partition.m"
        }
#line 74 "space_partition.m"
        break;
#line 74 "space_partition.m"
      case (MR_Integer) 0:
        {
          MR_Word space_partition__Obj_24 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 1)));
#line 90 "space_partition.m"
          MR_Integer space_partition__Id_23 = ((MR_Integer) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
#line 90 "space_partition.m"
          MR_Word space_partition__Light_25 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 2)));
#line 91 "space_partition.m"
          MR_Word space_partition__V_28_28;

#line 91 "space_partition.m"
          space_partition__succeeded = ((MR_tag((MR_Word) space_partition__Obj_24) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), space_partition__Obj_24, (MR_Integer) 0))) == (MR_Integer) 1));
#line 91 "space_partition.m"
          if (((MR_tag((MR_Word) space_partition__Obj_24) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), space_partition__Obj_24, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 91 "space_partition.m"
            space_partition__V_28_28 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__Obj_24, (MR_Integer) 1)));
#line 94 "space_partition.m"
          if (space_partition__succeeded)
            {
              MR_Word space_partition__V_30_30;

#line 92 "space_partition.m"
              *space_partition__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 93 "space_partition.m"
              space_partition__V_30_30 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 93 "space_partition.m"
              {
#line 93 "space_partition.m"
                *space_partition__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 93 "space_partition.m"
                MR_hl_field(MR_mktag(1), *space_partition__HeadVar__3_3, 0) = ((MR_Box) (space_partition__HeadVar__1_1));
#line 93 "space_partition.m"
                MR_hl_field(MR_mktag(1), *space_partition__HeadVar__3_3, 1) = ((MR_Box) (space_partition__V_30_30));
#line 93 "space_partition.m"
              }
            }
#line 94 "space_partition.m"
          else
            {
              MR_Word space_partition__V_32_32;

#line 95 "space_partition.m"
              *space_partition__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 96 "space_partition.m"
              space_partition__V_32_32 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 96 "space_partition.m"
              {
#line 96 "space_partition.m"
                *space_partition__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 96 "space_partition.m"
                MR_hl_field(MR_mktag(1), *space_partition__HeadVar__2_2, 0) = ((MR_Box) (space_partition__HeadVar__1_1));
#line 96 "space_partition.m"
                MR_hl_field(MR_mktag(1), *space_partition__HeadVar__2_2, 1) = ((MR_Box) (space_partition__V_32_32));
#line 96 "space_partition.m"
              }
            }
        }
#line 74 "space_partition.m"
        break;
#line 74 "space_partition.m"
      case (MR_Integer) 1:
        {
          MR_Word space_partition__Object_12 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word space_partition__Trans_13 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__1_1, (MR_Integer) 1)));
          MR_Word space_partition__Partitionable0_16;
          MR_Word space_partition__NonPartitionable0_17;

#line 84 "space_partition.m"
          {
#line 84 "space_partition.m"
            space_partition__split_partitionable_objects_3_p_0(space_partition__Object_12, &space_partition__Partitionable0_16, &space_partition__NonPartitionable0_17);
          }
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          {
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            space_partition__map__ho6__ua0_3_p_in__list_0(space_partition__Trans_13, space_partition__Partitionable0_16, space_partition__HeadVar__2_2);
          }
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          {
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            space_partition__map__ho6__ua0_3_p_in__list_0(space_partition__Trans_13, space_partition__NonPartitionable0_17, space_partition__HeadVar__3_3);
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            return;
          }
        }
#line 74 "space_partition.m"
        break;
#line 74 "space_partition.m"
      case (MR_Integer) 2:
        {
          MR_Word space_partition__Object1_4 = ((MR_Word) (MR_hl_field(MR_mktag(2), space_partition__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word space_partition__Object2_5 = ((MR_Word) (MR_hl_field(MR_mktag(2), space_partition__HeadVar__1_1, (MR_Integer) 1)));
          MR_Word space_partition__Partitionable1_8;
          MR_Word space_partition__NonPartitionable1_9;
          MR_Word space_partition__Partitionable2_10;
          MR_Word space_partition__NonPartitionable2_11;
          MR_Word space_partition__TypeInfo_51_51;
          MR_Word space_partition__TypeInfo_52_52;

#line 75 "space_partition.m"
          {
#line 75 "space_partition.m"
            space_partition__split_partitionable_objects_3_p_0(space_partition__Object1_4, &space_partition__Partitionable1_8, &space_partition__NonPartitionable1_9);
          }
#line 77 "space_partition.m"
          {
#line 77 "space_partition.m"
            space_partition__split_partitionable_objects_3_p_0(space_partition__Object2_5, &space_partition__Partitionable2_10, &space_partition__NonPartitionable2_11);
          }
          space_partition__TypeInfo_51_51 = (MR_Word) (&eval__eval__type_ctor_info_object_0);
#line 79 "space_partition.m"
          {
#line 79 "space_partition.m"
            mercury__list__append_3_p_1(space_partition__TypeInfo_51_51, space_partition__Partitionable1_8, space_partition__Partitionable2_10, space_partition__HeadVar__2_2);
          }
          space_partition__TypeInfo_52_52 = (MR_Word) (&eval__eval__type_ctor_info_object_0);
#line 80 "space_partition.m"
          {
#line 80 "space_partition.m"
            mercury__list__append_3_p_1(space_partition__TypeInfo_52_52, space_partition__NonPartitionable1_9, space_partition__NonPartitionable2_11, space_partition__HeadVar__3_3);
#line 80 "space_partition.m"
            return;
          }
        }
#line 74 "space_partition.m"
        break;
#line 74 "space_partition.m"
    }
#line 74 "space_partition.m"
  }
#line 70 "space_partition.m"
}

#line 58 "space_partition.m"
MR_Word MR_CALL space_partition__transform_bounding_box_3_f_0(
#line 58 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 58 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2)
#line 58 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__HeadVar__3_3;
    MR_Word space_partition__Point1_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word space_partition__Point2_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word space_partition__MinPoint_7;
    MR_Word space_partition__MaxPoint_8;
    MR_Float space_partition__X1_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__Point1_4, (MR_Integer) 0)));
    MR_Float space_partition__Y1_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__Point1_4, (MR_Integer) 1)));
    MR_Float space_partition__Z1_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__Point1_4, (MR_Integer) 2)));
    MR_Float space_partition__X2_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__Point2_5, (MR_Integer) 0)));
    MR_Float space_partition__Y2_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__Point2_5, (MR_Integer) 1)));
    MR_Float space_partition__Z2_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__Point2_5, (MR_Integer) 2)));
    MR_Word space_partition__Point3_15;
    MR_Word space_partition__Point4_16;
    MR_Word space_partition__Point5_17;
    MR_Word space_partition__Point6_18;
    MR_Word space_partition__Point7_19;
    MR_Word space_partition__Point8_20;
    MR_Word space_partition__TPoint1_21;
    MR_Word space_partition__TPoint2_22;
    MR_Word space_partition__TPoint3_23;
    MR_Word space_partition__TPoint4_24;
    MR_Word space_partition__TPoint5_25;
    MR_Word space_partition__TPoint6_26;
    MR_Word space_partition__TPoint7_27;
    MR_Word space_partition__TPoint8_28;
    MR_Word space_partition__V_29_29;
    MR_Word space_partition__V_30_30;
    MR_Word space_partition__V_31_31;
    MR_Word space_partition__V_32_32;
    MR_Word space_partition__V_33_33;
    MR_Word space_partition__V_34_34;
    MR_Word space_partition__V_35_35;
    MR_Word space_partition__V_36_36;
    MR_Word space_partition__V_37_37;
    MR_Word space_partition__V_38_38;
    MR_Word space_partition__V_39_39;
    MR_Word space_partition__V_40_40;
    MR_Word space_partition__M_4_41;
    MR_Word space_partition__M_4_45;
    MR_Word space_partition__M_4_49;
    MR_Word space_partition__M_4_53;
    MR_Word space_partition__M_4_57;
    MR_Word space_partition__M_4_61;
    MR_Word space_partition__M_4_65;
    MR_Word space_partition__M_4_69;
#line 24 "trans.opt"
    MR_Word space_partition___W_5_42;
#line 24 "trans.opt"
    MR_Word space_partition___W_5_46;
#line 24 "trans.opt"
    MR_Word space_partition___W_5_50;
#line 24 "trans.opt"
    MR_Word space_partition___W_5_54;
#line 24 "trans.opt"
    MR_Word space_partition___W_5_58;
#line 24 "trans.opt"
    MR_Word space_partition___W_5_62;
#line 24 "trans.opt"
    MR_Word space_partition___W_5_66;
#line 24 "trans.opt"
    MR_Word space_partition___W_5_70;

#line 203 "space_partition.m"
    {
#line 203 "space_partition.m"
      space_partition__Point3_15 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 203 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point3_15, 0) = MR_box_float(space_partition__X2_12);
#line 203 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point3_15, 1) = MR_box_float(space_partition__Y1_10);
#line 203 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point3_15, 2) = MR_box_float(space_partition__Z1_11);
#line 203 "space_partition.m"
    }
#line 204 "space_partition.m"
    {
#line 204 "space_partition.m"
      space_partition__Point4_16 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 204 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point4_16, 0) = MR_box_float(space_partition__X1_9);
#line 204 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point4_16, 1) = MR_box_float(space_partition__Y2_13);
#line 204 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point4_16, 2) = MR_box_float(space_partition__Z1_11);
#line 204 "space_partition.m"
    }
#line 205 "space_partition.m"
    {
#line 205 "space_partition.m"
      space_partition__Point5_17 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 205 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point5_17, 0) = MR_box_float(space_partition__X1_9);
#line 205 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point5_17, 1) = MR_box_float(space_partition__Y1_10);
#line 205 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point5_17, 2) = MR_box_float(space_partition__Z2_14);
#line 205 "space_partition.m"
    }
#line 206 "space_partition.m"
    {
#line 206 "space_partition.m"
      space_partition__Point6_18 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 206 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point6_18, 0) = MR_box_float(space_partition__X2_12);
#line 206 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point6_18, 1) = MR_box_float(space_partition__Y2_13);
#line 206 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point6_18, 2) = MR_box_float(space_partition__Z1_11);
#line 206 "space_partition.m"
    }
#line 207 "space_partition.m"
    {
#line 207 "space_partition.m"
      space_partition__Point7_19 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 207 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point7_19, 0) = MR_box_float(space_partition__X1_9);
#line 207 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point7_19, 1) = MR_box_float(space_partition__Y2_13);
#line 207 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point7_19, 2) = MR_box_float(space_partition__Z2_14);
#line 207 "space_partition.m"
    }
#line 208 "space_partition.m"
    {
#line 208 "space_partition.m"
      space_partition__Point8_20 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 208 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point8_20, 0) = MR_box_float(space_partition__X2_12);
#line 208 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point8_20, 1) = MR_box_float(space_partition__Y1_10);
#line 208 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__Point8_20, 2) = MR_box_float(space_partition__Z2_14);
#line 208 "space_partition.m"
    }
#line 24 "trans.opt"
    space_partition__M_4_41 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
#line 24 "trans.opt"
    space_partition___W_5_42 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
#line 25 "trans.opt"
    {
#line 25 "trans.opt"
      space_partition__TPoint1_21 = trans__transform_point_3_f_0(space_partition__M_4_41, space_partition__Point1_4);
    }
#line 24 "trans.opt"
    space_partition__M_4_45 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
#line 24 "trans.opt"
    space_partition___W_5_46 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
#line 25 "trans.opt"
    {
#line 25 "trans.opt"
      space_partition__TPoint2_22 = trans__transform_point_3_f_0(space_partition__M_4_45, space_partition__Point2_5);
    }
#line 24 "trans.opt"
    space_partition__M_4_49 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
#line 24 "trans.opt"
    space_partition___W_5_50 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
#line 25 "trans.opt"
    {
#line 25 "trans.opt"
      space_partition__TPoint3_23 = trans__transform_point_3_f_0(space_partition__M_4_49, space_partition__Point3_15);
    }
#line 24 "trans.opt"
    space_partition__M_4_53 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
#line 24 "trans.opt"
    space_partition___W_5_54 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
#line 25 "trans.opt"
    {
#line 25 "trans.opt"
      space_partition__TPoint4_24 = trans__transform_point_3_f_0(space_partition__M_4_53, space_partition__Point4_16);
    }
#line 24 "trans.opt"
    space_partition__M_4_57 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
#line 24 "trans.opt"
    space_partition___W_5_58 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
#line 25 "trans.opt"
    {
#line 25 "trans.opt"
      space_partition__TPoint5_25 = trans__transform_point_3_f_0(space_partition__M_4_57, space_partition__Point5_17);
    }
#line 24 "trans.opt"
    space_partition__M_4_61 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
#line 24 "trans.opt"
    space_partition___W_5_62 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
#line 25 "trans.opt"
    {
#line 25 "trans.opt"
      space_partition__TPoint6_26 = trans__transform_point_3_f_0(space_partition__M_4_61, space_partition__Point6_18);
    }
#line 24 "trans.opt"
    space_partition__M_4_65 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
#line 24 "trans.opt"
    space_partition___W_5_66 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
#line 25 "trans.opt"
    {
#line 25 "trans.opt"
      space_partition__TPoint7_27 = trans__transform_point_3_f_0(space_partition__M_4_65, space_partition__Point7_19);
    }
#line 24 "trans.opt"
    space_partition__M_4_69 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
#line 24 "trans.opt"
    space_partition___W_5_70 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
#line 25 "trans.opt"
    {
#line 25 "trans.opt"
      space_partition__TPoint8_28 = trans__transform_point_3_f_0(space_partition__M_4_69, space_partition__Point8_20);
    }
#line 224 "space_partition.m"
    {
#line 224 "space_partition.m"
      space_partition__V_40_40 = space_partition__min_point_3_f_0(space_partition__TPoint7_27, space_partition__TPoint8_28);
    }
#line 223 "space_partition.m"
    {
#line 223 "space_partition.m"
      space_partition__V_39_39 = space_partition__min_point_3_f_0(space_partition__TPoint6_26, space_partition__V_40_40);
    }
#line 222 "space_partition.m"
    {
#line 222 "space_partition.m"
      space_partition__V_38_38 = space_partition__min_point_3_f_0(space_partition__TPoint5_25, space_partition__V_39_39);
    }
#line 221 "space_partition.m"
    {
#line 221 "space_partition.m"
      space_partition__V_37_37 = space_partition__min_point_3_f_0(space_partition__TPoint4_24, space_partition__V_38_38);
    }
#line 220 "space_partition.m"
    {
#line 220 "space_partition.m"
      space_partition__V_36_36 = space_partition__min_point_3_f_0(space_partition__TPoint3_23, space_partition__V_37_37);
    }
#line 219 "space_partition.m"
    {
#line 219 "space_partition.m"
      space_partition__V_35_35 = space_partition__min_point_3_f_0(space_partition__TPoint2_22, space_partition__V_36_36);
    }
#line 219 "space_partition.m"
    {
#line 219 "space_partition.m"
      space_partition__MinPoint_7 = space_partition__min_point_3_f_0(space_partition__TPoint1_21, space_partition__V_35_35);
    }
#line 233 "space_partition.m"
    {
#line 233 "space_partition.m"
      space_partition__V_34_34 = space_partition__max_point_3_f_0(space_partition__TPoint7_27, space_partition__TPoint8_28);
    }
#line 232 "space_partition.m"
    {
#line 232 "space_partition.m"
      space_partition__V_33_33 = space_partition__max_point_3_f_0(space_partition__TPoint6_26, space_partition__V_34_34);
    }
#line 231 "space_partition.m"
    {
#line 231 "space_partition.m"
      space_partition__V_32_32 = space_partition__max_point_3_f_0(space_partition__TPoint5_25, space_partition__V_33_33);
    }
#line 230 "space_partition.m"
    {
#line 230 "space_partition.m"
      space_partition__V_31_31 = space_partition__max_point_3_f_0(space_partition__TPoint4_24, space_partition__V_32_32);
    }
#line 229 "space_partition.m"
    {
#line 229 "space_partition.m"
      space_partition__V_30_30 = space_partition__max_point_3_f_0(space_partition__TPoint3_23, space_partition__V_31_31);
    }
#line 228 "space_partition.m"
    {
#line 228 "space_partition.m"
      space_partition__V_29_29 = space_partition__max_point_3_f_0(space_partition__TPoint2_22, space_partition__V_30_30);
    }
#line 228 "space_partition.m"
    {
#line 228 "space_partition.m"
      space_partition__MaxPoint_8 = space_partition__max_point_3_f_0(space_partition__TPoint1_21, space_partition__V_29_29);
    }
#line 199 "space_partition.m"
    {
#line 199 "space_partition.m"
      space_partition__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 199 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, 0) = ((MR_Box) (space_partition__MinPoint_7));
#line 199 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, 1) = ((MR_Box) (space_partition__MaxPoint_8));
#line 199 "space_partition.m"
    }
    return space_partition__HeadVar__3_3;
  }
#line 58 "space_partition.m"
}

#line 57 "space_partition.m"
MR_Word MR_CALL space_partition__find_object_bounding_box_2_f_0(
#line 57 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1)
#line 57 "space_partition.m"
{
#line 166 "space_partition.m"
  {
#line 166 "space_partition.m"
    bool space_partition__succeeded;
#line 166 "space_partition.m"
    MR_Word space_partition__HeadVar__2_2;
#line 166 "space_partition.m"
    MR_Word space_partition__Obj_4;
#line 166 "space_partition.m"
    MR_Word space_partition__Obj1_6;
#line 166 "space_partition.m"
    MR_Word space_partition__Obj2_7;
#line 166 "space_partition.m"
    MR_Word space_partition__V_8_8;
#line 166 "space_partition.m"
    MR_Word space_partition__V_9_9;
#line 166 "space_partition.m"
    MR_Word space_partition__Obj_10;
#line 166 "space_partition.m"
    MR_Word space_partition__Transformation_11;
#line 166 "space_partition.m"
    MR_Word space_partition__Trans_12;
#line 166 "space_partition.m"
    MR_Word space_partition__V_13_13;
#line 166 "space_partition.m"
    MR_Word space_partition__V_14_14;
#line 166 "space_partition.m"
    MR_Word space_partition__Obj1_15;
#line 166 "space_partition.m"
    MR_Word space_partition__Obj2_16;
#line 166 "space_partition.m"
    MR_Word space_partition__V_17_17;
#line 166 "space_partition.m"
    MR_Word space_partition__V_18_18;
#line 166 "space_partition.m"
    MR_Word space_partition__Obj1_19;
#line 166 "space_partition.m"
    MR_Word space_partition__Obj2_20;
#line 166 "space_partition.m"
    MR_Word space_partition__V_21_21;
#line 166 "space_partition.m"
    MR_Word space_partition__V_22_22;
#line 166 "space_partition.m"
    MR_Word space_partition__P1_23;
#line 166 "space_partition.m"
    MR_Word space_partition__P2_24;
#line 166 "space_partition.m"
    MR_Word space_partition__P3_25;
#line 166 "space_partition.m"
    MR_Word space_partition__P4_26;
#line 166 "space_partition.m"
    MR_Word space_partition__V_27_27;
#line 166 "space_partition.m"
    MR_Word space_partition__V_28_28;
#line 166 "space_partition.m"
    MR_Word space_partition__P1_29;
#line 166 "space_partition.m"
    MR_Word space_partition__P2_30;
#line 166 "space_partition.m"
    MR_Word space_partition__P3_31;
#line 166 "space_partition.m"
    MR_Word space_partition__P4_32;
#line 166 "space_partition.m"
    MR_Word space_partition__V_33_33;
#line 166 "space_partition.m"
    MR_Word space_partition__V_34_34;
#line 166 "space_partition.m"
    MR_Word space_partition__P1_35;
#line 166 "space_partition.m"
    MR_Word space_partition__P2_36;
#line 166 "space_partition.m"
    MR_Word space_partition__P3_37;
#line 166 "space_partition.m"
    MR_Word space_partition__P4_38;
#line 166 "space_partition.m"
    MR_Word space_partition__V_39_39;
#line 166 "space_partition.m"
    MR_Word space_partition__V_40_40;

#line 166 "space_partition.m"
#line 166 "space_partition.m"
    switch (MR_tag((MR_Word) space_partition__HeadVar__1_1)) {
#line 166 "space_partition.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 166 "space_partition.m"
      case (MR_Integer) 3:
#line 166 "space_partition.m"
#line 166 "space_partition.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 0)))) {
#line 166 "space_partition.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 166 "space_partition.m"
          case (MR_Integer) 0:
            {
#line 174 "space_partition.m"
              space_partition__Obj1_15 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 1)));
#line 174 "space_partition.m"
              space_partition__Obj2_16 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 2)));
#line 175 "space_partition.m"
              {
#line 175 "space_partition.m"
                space_partition__V_17_17 = space_partition__find_object_bounding_box_2_f_0(space_partition__Obj1_15);
              }
#line 175 "space_partition.m"
              {
#line 175 "space_partition.m"
                space_partition__V_18_18 = space_partition__find_object_bounding_box_2_f_0(space_partition__Obj2_16);
              }
#line 154 "space_partition.m"
              space_partition__P1_29 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_17_17, (MR_Integer) 0)));
#line 154 "space_partition.m"
              space_partition__P2_30 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_17_17, (MR_Integer) 1)));
#line 154 "space_partition.m"
              space_partition__P3_31 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_18_18, (MR_Integer) 0)));
#line 154 "space_partition.m"
              space_partition__P4_32 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_18_18, (MR_Integer) 1)));
#line 154 "space_partition.m"
              {
#line 154 "space_partition.m"
                space_partition__V_33_33 = space_partition__min_point_3_f_0(space_partition__P1_29, space_partition__P3_31);
              }
#line 154 "space_partition.m"
              {
#line 154 "space_partition.m"
                space_partition__V_34_34 = space_partition__max_point_3_f_0(space_partition__P2_30, space_partition__P4_32);
              }
#line 154 "space_partition.m"
              {
#line 154 "space_partition.m"
                space_partition__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 154 "space_partition.m"
                MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, 0) = ((MR_Box) (space_partition__V_33_33));
#line 154 "space_partition.m"
                MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, 1) = ((MR_Box) (space_partition__V_34_34));
#line 154 "space_partition.m"
              }
            }
#line 166 "space_partition.m"
            break;
#line 166 "space_partition.m"
          case (MR_Integer) 1:
            {
#line 177 "space_partition.m"
              space_partition__Obj1_19 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 1)));
#line 177 "space_partition.m"
              space_partition__Obj2_20 = ((MR_Word) (MR_hl_field(MR_mktag(3), space_partition__HeadVar__1_1, (MR_Integer) 2)));
#line 178 "space_partition.m"
              {
#line 178 "space_partition.m"
                space_partition__V_21_21 = space_partition__find_object_bounding_box_2_f_0(space_partition__Obj1_19);
              }
#line 178 "space_partition.m"
              {
#line 178 "space_partition.m"
                space_partition__V_22_22 = space_partition__find_object_bounding_box_2_f_0(space_partition__Obj2_20);
              }
#line 154 "space_partition.m"
              space_partition__P1_23 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_21_21, (MR_Integer) 0)));
#line 154 "space_partition.m"
              space_partition__P2_24 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_21_21, (MR_Integer) 1)));
#line 154 "space_partition.m"
              space_partition__P3_25 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_22_22, (MR_Integer) 0)));
#line 154 "space_partition.m"
              space_partition__P4_26 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_22_22, (MR_Integer) 1)));
#line 154 "space_partition.m"
              {
#line 154 "space_partition.m"
                space_partition__V_27_27 = space_partition__min_point_3_f_0(space_partition__P1_23, space_partition__P3_25);
              }
#line 154 "space_partition.m"
              {
#line 154 "space_partition.m"
                space_partition__V_28_28 = space_partition__max_point_3_f_0(space_partition__P2_24, space_partition__P4_26);
              }
#line 154 "space_partition.m"
              {
#line 154 "space_partition.m"
                space_partition__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 154 "space_partition.m"
                MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, 0) = ((MR_Box) (space_partition__V_27_27));
#line 154 "space_partition.m"
                MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, 1) = ((MR_Box) (space_partition__V_28_28));
#line 154 "space_partition.m"
              }
            }
#line 166 "space_partition.m"
            break;
#line 166 "space_partition.m"
        }
#line 166 "space_partition.m"
        break;
#line 166 "space_partition.m"
      case (MR_Integer) 0:
        {
#line 166 "space_partition.m"
          MR_Integer space_partition___Id_3 = ((MR_Integer) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
#line 166 "space_partition.m"
          MR_Word space_partition___List_5;

#line 166 "space_partition.m"
          space_partition__Obj_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 1)));
#line 166 "space_partition.m"
          space_partition___List_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 2)));
#line 166 "space_partition.m"
          {
#line 166 "space_partition.m"
            return space_partition__HeadVar__2_2 = space_partition__find_basic_object_bounding_box_2_f_0(space_partition__Obj_4);
          }
        }
#line 166 "space_partition.m"
        break;
#line 166 "space_partition.m"
      case (MR_Integer) 1:
        {
#line 172 "space_partition.m"
          space_partition__Obj_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__1_1, (MR_Integer) 0)));
#line 172 "space_partition.m"
          space_partition__Transformation_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), space_partition__HeadVar__1_1, (MR_Integer) 1)));
#line 172 "space_partition.m"
          {
#line 172 "space_partition.m"
            space_partition__V_14_14 = space_partition__find_object_bounding_box_2_f_0(space_partition__Obj_10);
          }
#line 173 "space_partition.m"
          {
#line 173 "space_partition.m"
            space_partition__V_13_13 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "yes"));
#line 173 "space_partition.m"
            MR_hl_field(MR_mktag(1), space_partition__V_13_13, 0) = ((MR_Box) (space_partition__Transformation_11));
#line 173 "space_partition.m"
          }
#line 173 "space_partition.m"
          {
#line 173 "space_partition.m"
            space_partition__Trans_12 = renderer__maybe_transformation_to_trans_2_f_0(space_partition__V_13_13);
          }
#line 172 "space_partition.m"
          {
#line 172 "space_partition.m"
            return space_partition__HeadVar__2_2 = space_partition__transform_bounding_box_3_f_0(space_partition__V_14_14, space_partition__Trans_12);
          }
        }
#line 166 "space_partition.m"
        break;
#line 166 "space_partition.m"
      case (MR_Integer) 2:
        {
#line 168 "space_partition.m"
          space_partition__Obj1_6 = ((MR_Word) (MR_hl_field(MR_mktag(2), space_partition__HeadVar__1_1, (MR_Integer) 0)));
#line 168 "space_partition.m"
          space_partition__Obj2_7 = ((MR_Word) (MR_hl_field(MR_mktag(2), space_partition__HeadVar__1_1, (MR_Integer) 1)));
#line 169 "space_partition.m"
          {
#line 169 "space_partition.m"
            space_partition__V_8_8 = space_partition__find_object_bounding_box_2_f_0(space_partition__Obj1_6);
          }
#line 169 "space_partition.m"
          {
#line 169 "space_partition.m"
            space_partition__V_9_9 = space_partition__find_object_bounding_box_2_f_0(space_partition__Obj2_7);
          }
#line 154 "space_partition.m"
          space_partition__P1_35 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_8_8, (MR_Integer) 0)));
#line 154 "space_partition.m"
          space_partition__P2_36 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_8_8, (MR_Integer) 1)));
#line 154 "space_partition.m"
          space_partition__P3_37 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_9_9, (MR_Integer) 0)));
#line 154 "space_partition.m"
          space_partition__P4_38 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__V_9_9, (MR_Integer) 1)));
#line 154 "space_partition.m"
          {
#line 154 "space_partition.m"
            space_partition__V_39_39 = space_partition__min_point_3_f_0(space_partition__P1_35, space_partition__P3_37);
          }
#line 154 "space_partition.m"
          {
#line 154 "space_partition.m"
            space_partition__V_40_40 = space_partition__max_point_3_f_0(space_partition__P2_36, space_partition__P4_38);
          }
#line 154 "space_partition.m"
          {
#line 154 "space_partition.m"
            space_partition__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 154 "space_partition.m"
            MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, 0) = ((MR_Box) (space_partition__V_39_39));
#line 154 "space_partition.m"
            MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, 1) = ((MR_Box) (space_partition__V_40_40));
#line 154 "space_partition.m"
          }
        }
#line 166 "space_partition.m"
        break;
#line 166 "space_partition.m"
    }
#line 166 "space_partition.m"
    return space_partition__HeadVar__2_2;
#line 166 "space_partition.m"
  }
#line 57 "space_partition.m"
}

#line 53 "space_partition.m"
void MR_CALL space_partition__traverse_space_tree_4_p_0(
#line 53 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1,
#line 53 "space_partition.m"
  MR_Word space_partition__HeadVar__2_2,
#line 53 "space_partition.m"
  MR_Word space_partition__HeadVar__3_3,
#line 53 "space_partition.m"
  MR_Word * space_partition__HeadVar__4_4)
#line 53 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__BoundingBox_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word space_partition__Nodes_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 2)));
#line 384 "space_partition.m"
    MR_Float space_partition__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float space_partition__XRay_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float space_partition__YRay_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float space_partition__ZRay_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float space_partition__XDir_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float space_partition__YDir_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 1)));
    MR_Float space_partition__ZDir_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__HeadVar__3_3, (MR_Integer) 2)));
    MR_Float space_partition__XMin_21;
    MR_Float space_partition__YMin_22;
    MR_Float space_partition__ZMin_23;
    MR_Float space_partition__XMax_24;
    MR_Float space_partition__YMax_25;
    MR_Float space_partition__ZMax_26;
    MR_Word space_partition__V_27_27 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__BoundingBox_5, (MR_Integer) 0)));
    MR_Word space_partition__V_28_28 = ((MR_Word) (MR_hl_field(MR_mktag(0), space_partition__BoundingBox_5, (MR_Integer) 1)));

#line 398 "space_partition.m"
    space_partition__XMin_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_27_27, (MR_Integer) 0)));
#line 398 "space_partition.m"
    space_partition__YMin_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_27_27, (MR_Integer) 1)));
#line 398 "space_partition.m"
    space_partition__ZMin_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_27_27, (MR_Integer) 2)));
#line 398 "space_partition.m"
    space_partition__XMax_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_28_28, (MR_Integer) 0)));
#line 398 "space_partition.m"
    space_partition__YMax_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_28_28, (MR_Integer) 1)));
#line 398 "space_partition.m"
    space_partition__ZMax_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), space_partition__V_28_28, (MR_Integer) 2)));
#line 406 "space_partition.m"
#line 406 "space_partition.m"
{
#line 406 "space_partition.m"
#define MR_PROC_LABEL space_partition__traverse_space_tree_4_p_0
#line 406 "space_partition.m"

#line 406 "space_partition.m"
	MR_Float XRay;
#line 406 "space_partition.m"
	MR_Float YRay;
#line 406 "space_partition.m"
	MR_Float ZRay;
#line 406 "space_partition.m"
	MR_Float XDir;
#line 406 "space_partition.m"
	MR_Float YDir;
#line 406 "space_partition.m"
	MR_Float ZDir;
#line 406 "space_partition.m"
	MR_Float XMin;
#line 406 "space_partition.m"
	MR_Float YMin;
#line 406 "space_partition.m"
	MR_Float ZMin;
#line 406 "space_partition.m"
	MR_Float XMax;
#line 406 "space_partition.m"
	MR_Float YMax;
#line 406 "space_partition.m"
	MR_Float ZMax;
#line 406 "space_partition.m"
	MR_Bool SUCCESS_INDICATOR;
#line 406 "space_partition.m"

#line 406 "space_partition.m"
	XRay = 
#line 406 "space_partition.m"
space_partition__XRay_15
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	YRay = 
#line 406 "space_partition.m"
space_partition__YRay_16
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	ZRay = 
#line 406 "space_partition.m"
space_partition__ZRay_17
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	XDir = 
#line 406 "space_partition.m"
space_partition__XDir_18
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	YDir = 
#line 406 "space_partition.m"
space_partition__YDir_19
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	ZDir = 
#line 406 "space_partition.m"
space_partition__ZDir_20
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	XMin = 
#line 406 "space_partition.m"
space_partition__XMin_21
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	YMin = 
#line 406 "space_partition.m"
space_partition__YMin_22
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	ZMin = 
#line 406 "space_partition.m"
space_partition__ZMin_23
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	XMax = 
#line 406 "space_partition.m"
space_partition__XMax_24
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	YMax = 
#line 406 "space_partition.m"
space_partition__YMax_25
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
	ZMax = 
#line 406 "space_partition.m"
space_partition__ZMax_26
#line 406 "space_partition.m"
;
#line 406 "space_partition.m"
#line 406 "space_partition.m"
		{
#line 406 "space_partition.m"

{
	double minB[3], maxB[3];	/*box */
	double origin[3], dir[3];	/*ray */
	double coord[3];		/* hit point (not used -stayl)*/
	bool succeeded;

	minB[0] = XMin;
	minB[1] = YMin;
	minB[2] = ZMin;
	maxB[0] = XMax;
	maxB[1] = YMax;
	maxB[2] = ZMax;
	origin[0] = XRay;
	origin[1] = YRay;
	origin[2] = ZRay;
	dir[0] = XDir;
	dir[1] = YDir;
	dir[2] = ZDir;
	succeeded = HitBoundingBox(minB, maxB, origin, dir, coord);
	/*fprintf(stderr, succeeded ? "1\n" : "0\n"); */
	SUCCESS_INDICATOR = succeeded;
}
#line 406 "space_partition.m"

		;}
#line 406 "space_partition.m"
#undef MR_PROC_LABEL
#line 406 "space_partition.m"
#line 406 "space_partition.m"
	if (SUCCESS_INDICATOR) {
#line 406 "space_partition.m"
#line 406 "space_partition.m"
	}
#line 406 "space_partition.m"
space_partition__succeeded
#line 406 "space_partition.m"
 = SUCCESS_INDICATOR;
#line 406 "space_partition.m"
}
#line 388 "space_partition.m"
    if (space_partition__succeeded)
      {
        MR_Word space_partition__V_11_11 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));

#line 386 "space_partition.m"
        {
#line 386 "space_partition.m"
          space_partition__traverse_space_tree_nodes_5_p_0(space_partition__Nodes_7, space_partition__HeadVar__2_2, space_partition__HeadVar__3_3, space_partition__V_11_11, space_partition__HeadVar__4_4);
#line 386 "space_partition.m"
          return;
        }
      }
#line 388 "space_partition.m"
    else
#line 389 "space_partition.m"
      *space_partition__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
  }
#line 53 "space_partition.m"
}

#line 8 "space_partition.m"
MR_Word MR_CALL space_partition__create_scene_2_f_0(
#line 8 "space_partition.m"
  MR_Word space_partition__HeadVar__1_1)
#line 8 "space_partition.m"
{
  {
    bool space_partition__succeeded;
    MR_Word space_partition__HeadVar__2_2;
    MR_Word space_partition__Tree_4;
    MR_Word space_partition__Others_5;
    MR_Word space_partition__Partitionable_6;

#line 66 "space_partition.m"
    {
#line 66 "space_partition.m"
      space_partition__split_partitionable_objects_3_p_0(space_partition__HeadVar__1_1, &space_partition__Partitionable_6, &space_partition__Others_5);
    }
#line 67 "space_partition.m"
    {
#line 67 "space_partition.m"
      space_partition__Tree_4 = space_partition__build_space_tree_2_f_0(space_partition__Partitionable_6);
    }
#line 65 "space_partition.m"
    {
#line 65 "space_partition.m"
      space_partition__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "scene");
#line 65 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, 0) = ((MR_Box) (space_partition__Tree_4));
#line 65 "space_partition.m"
      MR_hl_field(MR_mktag(0), space_partition__HeadVar__2_2, 1) = ((MR_Box) (space_partition__Others_5));
#line 65 "space_partition.m"
    }
    return space_partition__HeadVar__2_2;
  }
#line 8 "space_partition.m"
}

void mercury__space_partition__init(void)
{
}

void mercury__space_partition__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&space_partition__space_partition__type_ctor_info_surface_area_0);
	MR_register_type_ctor_info(&space_partition__space_partition__type_ctor_info_subtree_result_0);
	MR_register_type_ctor_info(&space_partition__space_partition__type_ctor_info_space_tree_object_0);
	MR_register_type_ctor_info(&space_partition__space_partition__type_ctor_info_space_tree_node_0);
	MR_register_type_ctor_info(&space_partition__space_partition__type_ctor_info_space_tree_0);
	MR_register_type_ctor_info(&space_partition__space_partition__type_ctor_info_scene_0);
	MR_register_type_ctor_info(&space_partition__space_partition__type_ctor_info_normal_0);
	MR_register_type_ctor_info(&space_partition__space_partition__type_ctor_info_invalid_transformation_0);
	MR_register_type_ctor_info(&space_partition__space_partition__type_ctor_info_invalid_object_0);
	MR_register_type_ctor_info(&space_partition__space_partition__type_ctor_info_bounding_box_0);
}

void mercury__space_partition__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module space_partition. */
