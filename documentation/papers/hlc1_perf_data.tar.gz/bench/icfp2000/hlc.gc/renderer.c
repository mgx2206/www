/*
** Automatically generated from `renderer.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module renderer. */
/* :- implementation. */

#include "renderer.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.benchmarking.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "eval.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "globals.h"
#include "gml.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "op.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "peephole.h"
#include "precompute_lights.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "renderer.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "space_partition.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "trans.h"
#include "transform_object.h"
#include "tree.h"
#include "mercury.tree234.h"
#include "mercury.varset.h"
#include "vector.h"



static const MR_NotagFunctorDesc renderer__renderer__notag_functor_desc_unimplemented_object_0;
static const MR_DuFunctorDescPtr renderer__renderer__du_name_ordered_render_params_0[1];
static const MR_DuFunctorDesc renderer__renderer__du_functor_desc_render_params_0_0;
static const MR_ConstString renderer__renderer__field_names_render_params_0_0[8];
static const MR_PseudoTypeInfo renderer__renderer__field_types_render_params_0_0[8];
static const MR_FO_PseudoTypeInfo_Struct1 renderer__array__type_info_array_1__type0_13_eval__value_0;
static const MR_DuPtagLayout renderer__renderer__du_ptag_ordered_render_params_0[1];
static const MR_DuFunctorDescPtr renderer__renderer__du_stag_ordered_render_params_0_0[1];
static const MR_DuFunctorDescPtr renderer__renderer__du_name_ordered_pixel_coords_0[1];
static const MR_DuFunctorDesc renderer__renderer__du_functor_desc_pixel_coords_0_0;
static const MR_ConstString renderer__renderer__field_names_pixel_coords_0_0[2];
static const MR_PseudoTypeInfo renderer__renderer__field_types_pixel_coords_0_0[2];
static const MR_DuPtagLayout renderer__renderer__du_ptag_ordered_pixel_coords_0[1];
static const MR_DuFunctorDescPtr renderer__renderer__du_stag_ordered_pixel_coords_0_0[1];
static const MR_FO_PseudoTypeInfo_Struct2 renderer__std_util__type_info_pair_2__type0_9___float_0__type0_21_trans__intersection_0;
static const MR_FO_PseudoTypeInfo_Struct1 renderer__tree__type_info_tree_1__type_16_std_util__pair_2__type0_9___float_0__type0_21_trans__intersection_0;
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL renderer__filter__ho13__ua0_4_p_in__list_0(
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_16_16,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Integer renderer__V_15_15,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_14_14,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * renderer__HeadVar__3_3,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * renderer__HeadVar__4_4);
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL renderer__map__ho11__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_19_19,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_18_18,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_17_17,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_16_16,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Float renderer__V_15_15,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * renderer__HeadVar__3_3);
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL renderer__map__ho10__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_17_17,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_16_16,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_15_15,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * renderer__HeadVar__3_3);
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static MR_Word MR_CALL renderer__map__ho9__ua0_3_f_in__list_0(
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_20_20,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_19_19,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_18_18,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2);
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static MR_Word MR_CALL renderer__map__ho8__ua0_3_f_in__list_0(
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_22_22,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_21_21,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_20_20,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_19_19,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Float renderer__V_18_18,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2);
#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL renderer__filter__ho6__ua0_3_p_in__list_0(
#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_11_11,
#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Integer renderer__V_10_10,
#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_9_9,
#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2,
#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * renderer__HeadVar__3_3);
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
static MR_Word MR_CALL renderer__foldr_0__ho1__ua0_6_f_in__array_0(
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
  MR_Word renderer__TypeInfo_for_T1_1_17,
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
  MR_Array renderer__HeadVar__2_2,
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
  MR_Word renderer__HeadVar__3_3,
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
  MR_Integer renderer__HeadVar__4_4,
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
  MR_Integer renderer__HeadVar__5_5);
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL renderer__foldl__ho12_4_p_in__list_0(
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2,
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__3_3,
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * renderer__HeadVar__4_4);
#line 158 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static MR_Word MR_CALL renderer__foldl__ho7_4_f_in__list_0(
#line 158 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2,
#line 158 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__3_3);
#line 619 "renderer.m"
static MR_Word MR_CALL renderer__IntroducedFrom__func__compute_intensity__619__2_7_f_0(
#line 619 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 619 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 619 "renderer.m"
  MR_Word renderer__HeadVar__5_5,
#line 619 "renderer.m"
  MR_Word renderer__C_25,
#line 619 "renderer.m"
  MR_Float renderer__V_124_124,
#line 619 "renderer.m"
  MR_Word renderer__V_66_66);
#line 597 "renderer.m"
static MR_Word MR_CALL renderer__IntroducedFrom__func__compute_intensity__597__1_5_f_0(
#line 597 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 597 "renderer.m"
  MR_Word renderer__HeadVar__5_5,
#line 597 "renderer.m"
  MR_Word renderer__C_25,
#line 597 "renderer.m"
  MR_Word renderer__V_76_76);
static /* final */ const MR_Box renderer__const_1330_0_1_TypeInfo_7_7[3];
static /* final */ const MR_Box renderer__const_1329_0_1_TypeInfo_6_6[3];
#line 849 "renderer.m"
static MR_Word MR_CALL renderer__intersection_list_to_tree_3_f_0(
#line 849 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 849 "renderer.m"
  MR_Word renderer__HeadVar__2_2);
#line 784 "renderer.m"
static bool MR_CALL renderer__point_is_in_object_3_p_0(
#line 784 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 784 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 784 "renderer.m"
  MR_Word renderer__HeadVar__3_3);
#line 774 "renderer.m"
static MR_Word MR_CALL renderer__pixel_direction_2_6_f_0(
#line 774 "renderer.m"
  MR_Float renderer__HeadVar__1_1,
#line 774 "renderer.m"
  MR_Integer renderer__HeadVar__2_2,
#line 774 "renderer.m"
  MR_Integer renderer__HeadVar__3_3,
#line 774 "renderer.m"
  MR_Integer renderer__HeadVar__4_4,
#line 774 "renderer.m"
  MR_Integer renderer__HeadVar__5_5);
#line 728 "renderer.m"
static MR_Word MR_CALL renderer__clamp_2_f_0(
#line 728 "renderer.m"
  MR_Word renderer__HeadVar__1_1);
#line 725 "renderer.m"
static MR_Word MR_CALL renderer__f_times_3_f_0(
#line 725 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 725 "renderer.m"
  MR_Word renderer__HeadVar__2_2);
#line 713 "renderer.m"
static MR_Float MR_CALL renderer__distance_attenuation_3_f_0(
#line 713 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 713 "renderer.m"
  MR_Word renderer__HeadVar__2_2);
#line 696 "renderer.m"
static MR_Word MR_CALL renderer__light_intensity_3_f_0(
#line 696 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 696 "renderer.m"
  MR_Word renderer__HeadVar__2_2);
#line 692 "renderer.m"
static /* final */ const MR_Box renderer__const_25_0_1_V_6_6[1];
#line 687 "renderer.m"
static MR_Word MR_CALL renderer__light_value_to_light_2_f_0(
#line 687 "renderer.m"
  MR_Word renderer__HeadVar__1_1);
#line 674 "renderer.m"
static bool MR_CALL renderer__light_is_behind_point_3_p_0(
#line 674 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 674 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 674 "renderer.m"
  MR_Word renderer__HeadVar__3_3);
#line 692 "renderer.m"
static /* final */ const MR_Box renderer__const_23_0_1_V_20_20[1];
#line 660 "renderer.m"
static bool MR_CALL renderer__position_not_in_shadow_4_p_0(
#line 660 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 660 "renderer.m"
  MR_Integer renderer__HeadVar__2_2,
#line 660 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 660 "renderer.m"
  MR_Word renderer__HeadVar__4_4);
#line 649 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_5;
#line 649 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_6;
#line 649 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_7;
#line 649 "renderer.m"
static /* final */ const MR_Box renderer__const_22_0_8_V_61_61[3];
#line 651 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_9;
#line 651 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_10;
#line 651 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_11;
#line 651 "renderer.m"
static /* final */ const MR_Box renderer__const_22_0_12_V_56_56[3];
#line 585 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_1;
#line 585 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_2;
#line 585 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_3;
#line 585 "renderer.m"
static /* final */ const MR_Box renderer__const_22_0_4_ReflectedI_22[3];
#line 553 "renderer.m"
static void MR_CALL renderer__compute_intensity_9_p_0(
#line 553 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 553 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 553 "renderer.m"
  MR_Integer renderer__HeadVar__3_3,
#line 553 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 553 "renderer.m"
  MR_Word renderer__HeadVar__5_5,
#line 553 "renderer.m"
  MR_Word renderer__HeadVar__6_6,
#line 553 "renderer.m"
  MR_Word * renderer__HeadVar__7_7);
#line 456 "renderer.m"
static void MR_CALL renderer__reverse_normals_2_p_0(
#line 456 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 456 "renderer.m"
  MR_Word * renderer__HeadVar__2_2);
#line 436 "renderer.m"
static void MR_CALL renderer__select_intersection_points_NOT_in_object_4_p_0(
#line 436 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 436 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 436 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 436 "renderer.m"
  MR_Word * renderer__HeadVar__4_4);
#line 414 "renderer.m"
static void MR_CALL renderer__select_intersection_points_in_object_4_p_0(
#line 414 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 414 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 414 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 414 "renderer.m"
  MR_Word * renderer__HeadVar__4_4);
#line 403 "renderer.m"
static void MR_CALL renderer__find_surface_and_not_object_intersection_6_p_0(
#line 403 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 403 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 403 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 403 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 403 "renderer.m"
  MR_Word renderer__HeadVar__5_5,
#line 403 "renderer.m"
  MR_Word * renderer__HeadVar__6_6);
#line 386 "renderer.m"
static void MR_CALL renderer__find_surface_and_object_intersection_6_p_0(
#line 386 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 386 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 386 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 386 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 386 "renderer.m"
  MR_Word renderer__HeadVar__5_5,
#line 386 "renderer.m"
  MR_Word * renderer__HeadVar__6_6);
#line 245 "renderer.m"
static void MR_CALL renderer__choose_closest_intersection_5_p_0(
#line 245 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 245 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 245 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 245 "renderer.m"
  MR_Integer renderer__HeadVar__4_4,
#line 245 "renderer.m"
  MR_Word * renderer__HeadVar__5_5);
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_1;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_2;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_3;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_4;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_5;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_6;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_7;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_8;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_9;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_10;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_11;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_12;
#line 43 "trans.opt"
static /* final */ const MR_Box renderer__const_9_0_13_I_2_9[12];
#line 30 "trans.opt"
static /* final */ const MR_Box renderer__const_9_0_14_HeadVar__2_2[2];
#line 148 "renderer.m"
static /* final */ const MR_Float renderer__float_5_0_1;
#line 148 "renderer.m"
static /* final */ const MR_Float renderer__float_5_0_2;
#line 148 "renderer.m"
static /* final */ const MR_Float renderer__float_5_0_3;
#line 148 "renderer.m"
static /* final */ const MR_Box renderer__const_5_0_4_HeadVar__5_5[3];
#line 134 "renderer.m"
static void MR_CALL renderer__fire_ray_7_p_0(
#line 134 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 134 "renderer.m"
  MR_Integer renderer__HeadVar__2_2,
#line 134 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 134 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 134 "renderer.m"
  MR_Word * renderer__HeadVar__5_5);
#line 740 "renderer.m"
static /* final */ const MR_Float renderer__float_2_0_1;
#line 740 "renderer.m"
static /* final */ const MR_Float renderer__float_2_0_2;
#line 740 "renderer.m"
static /* final */ const MR_Float renderer__float_2_0_3;
#line 740 "renderer.m"
static /* final */ const MR_Box renderer__const_2_0_4_RayOrigin_43[3];
#line 82 "renderer.m"
static void MR_CALL renderer__render_pixel_loop_7_p_0(
#line 82 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 82 "renderer.m"
  MR_Integer renderer__HeadVar__2_2,
#line 82 "renderer.m"
  MR_Integer renderer__HeadVar__3_3,
#line 82 "renderer.m"
  MR_Integer renderer__HeadVar__4_4,
#line 82 "renderer.m"
  MR_Integer renderer__HeadVar__5_5);



const MR_TypeCtorInfo_Struct renderer__renderer__type_ctor_info_unimplemented_object_0 = {
		(MR_Integer) 0,
		((MR_Box) (renderer____Unify____unimplemented_object_0_0)),
		((MR_Box) (renderer____Unify____unimplemented_object_0_0)),
		((MR_Box) (renderer____Compare____unimplemented_object_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_NOTAG_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "renderer",
		(MR_String) "unimplemented_object",
		(MR_Integer) 4,
		{
		(MR_Box) (&renderer__renderer__notag_functor_desc_unimplemented_object_0)},
		{
		(MR_Box) (&renderer__renderer__notag_functor_desc_unimplemented_object_0)},
		(MR_Integer) 1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct renderer__renderer__type_ctor_info_render_params_0 = {
		(MR_Integer) 0,
		((MR_Box) (renderer____Unify____render_params_0_0)),
		((MR_Box) (renderer____Unify____render_params_0_0)),
		((MR_Box) (renderer____Compare____render_params_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "renderer",
		(MR_String) "render_params",
		(MR_Integer) 4,
		{
		(MR_Box) renderer__renderer__du_name_ordered_render_params_0},
		{
		(MR_Box) renderer__renderer__du_ptag_ordered_render_params_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct renderer__renderer__type_ctor_info_pixel_coords_0 = {
		(MR_Integer) 0,
		((MR_Box) (renderer____Unify____pixel_coords_0_0)),
		((MR_Box) (renderer____Unify____pixel_coords_0_0)),
		((MR_Box) (renderer____Compare____pixel_coords_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "renderer",
		(MR_String) "pixel_coords",
		(MR_Integer) 4,
		{
		(MR_Box) renderer__renderer__du_name_ordered_pixel_coords_0},
		{
		(MR_Box) renderer__renderer__du_ptag_ordered_pixel_coords_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct renderer__renderer__type_ctor_info_intersection_result_0 = {
		(MR_Integer) 0,
		((MR_Box) (renderer____Unify____intersection_result_0_0)),
		((MR_Box) (renderer____Unify____intersection_result_0_0)),
		((MR_Box) (renderer____Compare____intersection_result_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "renderer",
		(MR_String) "intersection_result",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&renderer__tree__type_info_tree_1__type_16_std_util__pair_2__type0_9___float_0__type0_21_trans__intersection_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct renderer__renderer__type_ctor_info_best_intersection_0 = {
		(MR_Integer) 0,
		((MR_Box) (renderer____Unify____best_intersection_0_0)),
		((MR_Box) (renderer____Unify____best_intersection_0_0)),
		((MR_Box) (renderer____Compare____best_intersection_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "renderer",
		(MR_String) "best_intersection",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&renderer__std_util__type_info_pair_2__type0_9___float_0__type0_21_trans__intersection_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
static const MR_NotagFunctorDesc renderer__renderer__notag_functor_desc_unimplemented_object_0 = {
		(MR_String) "unimplemented_object",
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_object_0),
		(MR_Box) NULL};
static const MR_DuFunctorDescPtr renderer__renderer__du_name_ordered_render_params_0[1] = {
		(&renderer__renderer__du_functor_desc_render_params_0_0)};
static const MR_DuFunctorDesc renderer__renderer__du_functor_desc_render_params_0_0 = {
		(MR_String) "render_params",
		(MR_Integer) 8,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		renderer__renderer__field_types_render_params_0_0,
		renderer__renderer__field_names_render_params_0_0,
		(MR_Box) NULL};
static const MR_ConstString renderer__renderer__field_names_render_params_0_0[8] = {
		(MR_String) "amb",
		(MR_String) "lights",
		(MR_String) "scene",
		(MR_String) "depth",
		(MR_String) "fov",
		(MR_String) "wid",
		(MR_String) "ht",
		(MR_String) "file"};
static const MR_PseudoTypeInfo renderer__renderer__field_types_render_params_0_0[8] = {
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0),
		(MR_PseudoTypeInfo) (&renderer__array__type_info_array_1__type0_13_eval__value_0),
		(MR_PseudoTypeInfo) (&space_partition__space_partition__type_ctor_info_scene_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0)};
static const MR_FO_PseudoTypeInfo_Struct1 renderer__array__type_info_array_1__type0_13_eval__value_0 = {
		(&mercury__array__array__type_ctor_info_array_1),
		{
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_value_0)}};
static const MR_DuPtagLayout renderer__renderer__du_ptag_ordered_render_params_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		renderer__renderer__du_stag_ordered_render_params_0_0}};
static const MR_DuFunctorDescPtr renderer__renderer__du_stag_ordered_render_params_0_0[1] = {
		(&renderer__renderer__du_functor_desc_render_params_0_0)};
static const MR_DuFunctorDescPtr renderer__renderer__du_name_ordered_pixel_coords_0[1] = {
		(&renderer__renderer__du_functor_desc_pixel_coords_0_0)};
static const MR_DuFunctorDesc renderer__renderer__du_functor_desc_pixel_coords_0_0 = {
		(MR_String) "pixel_coords",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		renderer__renderer__field_types_pixel_coords_0_0,
		renderer__renderer__field_names_pixel_coords_0_0,
		(MR_Box) NULL};
static const MR_ConstString renderer__renderer__field_names_pixel_coords_0_0[2] = {
		(MR_String) "pixel_i",
		(MR_String) "pixel_j"};
static const MR_PseudoTypeInfo renderer__renderer__field_types_pixel_coords_0_0[2] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0)};
static const MR_DuPtagLayout renderer__renderer__du_ptag_ordered_pixel_coords_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		renderer__renderer__du_stag_ordered_pixel_coords_0_0}};
static const MR_DuFunctorDescPtr renderer__renderer__du_stag_ordered_pixel_coords_0_0[1] = {
		(&renderer__renderer__du_functor_desc_pixel_coords_0_0)};
static const MR_FO_PseudoTypeInfo_Struct2 renderer__std_util__type_info_pair_2__type0_9___float_0__type0_21_trans__intersection_0 = {
		(&mercury__std_util__std_util__type_ctor_info_pair_2),
		{
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&trans__trans__type_ctor_info_intersection_0)}};
static const MR_FO_PseudoTypeInfo_Struct1 renderer__tree__type_info_tree_1__type_16_std_util__pair_2__type0_9___float_0__type0_21_trans__intersection_0 = {
		(&tree__tree__type_ctor_info_tree_1),
		{
		(MR_PseudoTypeInfo) (&renderer__std_util__type_info_pair_2__type0_9___float_0__type0_21_trans__intersection_0)}};

#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL renderer__filter__ho13__ua0_4_p_in__list_0(
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_16_16,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Integer renderer__V_15_15,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_14_14,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * renderer__HeadVar__3_3,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * renderer__HeadVar__4_4)
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool renderer__succeeded;

#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((renderer__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
      {
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        *renderer__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        *renderer__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
      }
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
        MR_Word renderer__H_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 0)));
        MR_Word renderer__T_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word renderer__L1_11_11;
        MR_Word renderer__M1_12_12;

#line 205 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 205 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          renderer__filter__ho13__ua0_4_p_in__list_0(renderer__V_16_16, renderer__V_15_15, renderer__V_14_14, renderer__T_8_8, &renderer__L1_11_11, &renderer__M1_12_12);
        }
#line 197 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 197 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          renderer__succeeded = renderer__position_not_in_shadow_4_p_0(renderer__V_16_16, renderer__V_15_15, renderer__V_14_14, renderer__H_7_7);
        }
#line 201 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        if (renderer__succeeded)
          {
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            {
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              *renderer__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_hl_field(MR_mktag(1), *renderer__HeadVar__3_3, 0) = ((MR_Box) (renderer__H_7_7));
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_hl_field(MR_mktag(1), *renderer__HeadVar__3_3, 1) = ((MR_Box) (renderer__L1_11_11));
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            }
#line 200 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            *renderer__HeadVar__4_4 = renderer__M1_12_12;
          }
#line 201 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        else
          {
#line 202 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            *renderer__HeadVar__3_3 = renderer__L1_11_11;
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            {
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              *renderer__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_hl_field(MR_mktag(1), *renderer__HeadVar__4_4, 0) = ((MR_Box) (renderer__H_7_7));
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_hl_field(MR_mktag(1), *renderer__HeadVar__4_4, 1) = ((MR_Box) (renderer__M1_12_12));
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            }
          }
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL renderer__map__ho11__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_19_19,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_18_18,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_17_17,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_16_16,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Float renderer__V_15_15,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * renderer__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool renderer__succeeded;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((renderer__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *renderer__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
        MR_Word renderer__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 0)));
        MR_Word renderer__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word renderer__H_8_8;
        MR_Word renderer__T_9_9;

#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          renderer__H_8_8 = renderer__IntroducedFrom__func__compute_intensity__619__2_7_f_0(renderer__V_19_19, renderer__V_18_18, renderer__V_17_17, renderer__V_16_16, renderer__V_15_15, renderer__H0_6_6);
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          renderer__map__ho11__ua0_3_p_in__list_0(renderer__V_19_19, renderer__V_18_18, renderer__V_17_17, renderer__V_16_16, renderer__V_15_15, renderer__T0_7_7, &renderer__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *renderer__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *renderer__HeadVar__3_3, 0) = ((MR_Box) (renderer__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *renderer__HeadVar__3_3, 1) = ((MR_Box) (renderer__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL renderer__map__ho10__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_17_17,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_16_16,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_15_15,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * renderer__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool renderer__succeeded;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((renderer__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *renderer__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
        MR_Word renderer__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 0)));
        MR_Word renderer__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word renderer__H_8_8;
        MR_Word renderer__T_9_9;

#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          renderer__H_8_8 = renderer__IntroducedFrom__func__compute_intensity__597__1_5_f_0(renderer__V_17_17, renderer__V_16_16, renderer__V_15_15, renderer__H0_6_6);
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          renderer__map__ho10__ua0_3_p_in__list_0(renderer__V_17_17, renderer__V_16_16, renderer__V_15_15, renderer__T0_7_7, &renderer__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *renderer__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *renderer__HeadVar__3_3, 0) = ((MR_Box) (renderer__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *renderer__HeadVar__3_3, 1) = ((MR_Box) (renderer__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static MR_Word MR_CALL renderer__map__ho9__ua0_3_f_in__list_0(
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_20_20,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_19_19,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_18_18,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2)
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool renderer__succeeded;
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word renderer__HeadVar__3_3;

#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      renderer__map__ho10__ua0_3_p_in__list_0(renderer__V_20_20, renderer__V_19_19, renderer__V_18_18, renderer__HeadVar__2_2, &renderer__HeadVar__3_3);
    }
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    return renderer__HeadVar__3_3;
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static MR_Word MR_CALL renderer__map__ho8__ua0_3_f_in__list_0(
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_22_22,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_21_21,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_20_20,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_19_19,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Float renderer__V_18_18,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2)
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool renderer__succeeded;
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word renderer__HeadVar__3_3;

#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      renderer__map__ho11__ua0_3_p_in__list_0(renderer__V_22_22, renderer__V_21_21, renderer__V_20_20, renderer__V_19_19, renderer__V_18_18, renderer__HeadVar__2_2, &renderer__HeadVar__3_3);
    }
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    return renderer__HeadVar__3_3;
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL renderer__filter__ho6__ua0_3_p_in__list_0(
#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_11_11,
#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Integer renderer__V_10_10,
#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__V_9_9,
#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2,
#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * renderer__HeadVar__3_3)
#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool renderer__succeeded;
#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word renderer__V_7_7;

#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      renderer__filter__ho13__ua0_4_p_in__list_0(renderer__V_11_11, renderer__V_10_10, renderer__V_9_9, renderer__HeadVar__2_2, renderer__HeadVar__3_3, &renderer__V_7_7);
    }
#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 181 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
static MR_Word MR_CALL renderer__foldr_0__ho1__ua0_6_f_in__array_0(
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
  MR_Word renderer__TypeInfo_for_T1_1_17,
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
  MR_Array renderer__HeadVar__2_2,
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
  MR_Word renderer__HeadVar__3_3,
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
  MR_Integer renderer__HeadVar__4_4,
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
  MR_Integer renderer__HeadVar__5_5)
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
{
#line 247 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
  {
#line 247 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    /* tailcall optimized into a loop */
#line 247 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
  loop_top:;
#line 247 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    {
#line 247 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      bool renderer__succeeded = (renderer__HeadVar__5_5 < renderer__HeadVar__4_4);
#line 247 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      MR_Word renderer__HeadVar__6_6;

#line 247 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      if (renderer__succeeded)
#line 246 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
        renderer__HeadVar__6_6 = renderer__HeadVar__3_3;
#line 247 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      else
        {
          MR_Word renderer__V_12_13;
          MR_Integer renderer__V_13_14;
          MR_Box renderer__V_14_15;
          MR_Integer renderer__V_15_16;

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            mercury__array__lookup_3_p_1(renderer__TypeInfo_for_T1_1_17, (MR_Array) renderer__HeadVar__2_2, renderer__HeadVar__5_5, &renderer__V_14_15);
          }
#line 157 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          {
#line 157 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            renderer__V_12_13 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 157 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            MR_hl_field(MR_mktag(1), renderer__V_12_13, 0) = ((MR_Box) (renderer__V_14_15));
#line 157 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            MR_hl_field(MR_mktag(1), renderer__V_12_13, 1) = ((MR_Box) (renderer__HeadVar__3_3));
#line 157 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          }
#line 252 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          renderer__V_15_16 = (MR_Integer) 1;
#line 251 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          renderer__V_13_14 = (renderer__HeadVar__5_5 - renderer__V_15_16);
#line 248 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          {
#line 248 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            /* direct tailcall eliminated */
#line 248 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            {
#line 248 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
              MR_Array renderer__HeadVar__2__tmp_copy_2 = (MR_Array) renderer__HeadVar__2_2;
#line 248 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
              MR_Word renderer__HeadVar__3__tmp_copy_3 = renderer__V_12_13;
#line 248 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
              MR_Integer renderer__HeadVar__5__tmp_copy_5 = renderer__V_13_14;

#line 248 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
              renderer__HeadVar__2_2 = renderer__HeadVar__2__tmp_copy_2;
#line 248 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
              renderer__HeadVar__3_3 = renderer__HeadVar__3__tmp_copy_3;
#line 248 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
              renderer__HeadVar__5_5 = renderer__HeadVar__5__tmp_copy_5;
#line 248 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            }
#line 248 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            goto loop_top;
#line 248 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          }
        }
#line 247 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
      return renderer__HeadVar__6_6;
#line 247 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
    }
#line 247 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
  }
#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
}

#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL renderer__foldl__ho12_4_p_in__list_0(
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2,
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__3_3,
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * renderer__HeadVar__4_4)
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    /* tailcall optimized into a loop */
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  loop_top:;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      bool renderer__succeeded;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Word renderer__H_8_8;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Word renderer__T_9_9;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Word renderer__Acc1_12_12;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Float renderer__Ax_4_41;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Float renderer__Ay_5_42;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Float renderer__Az_6_43;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Float renderer__Bx_7_44;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Float renderer__By_8_45;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Float renderer__Bz_9_46;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Float renderer__V_10_47;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Float renderer__V_11_48;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Float renderer__V_12_49;

#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      if ((renderer__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        *renderer__HeadVar__4_4 = renderer__HeadVar__3_3;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      else
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 150 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          renderer__H_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 0)));
#line 150 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          renderer__T_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 1)));
#line 3 "vector.opt"
          renderer__Ax_4_41 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__H_8_8, (MR_Integer) 0)));
#line 3 "vector.opt"
          renderer__Ay_5_42 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__H_8_8, (MR_Integer) 1)));
#line 3 "vector.opt"
          renderer__Az_6_43 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__H_8_8, (MR_Integer) 2)));
#line 3 "vector.opt"
          renderer__Bx_7_44 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 0)));
#line 3 "vector.opt"
          renderer__By_8_45 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 1)));
#line 3 "vector.opt"
          renderer__Bz_9_46 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 2)));
#line 4 "vector.opt"
          renderer__V_10_47 = (renderer__Ax_4_41 + renderer__Bx_7_44);
#line 5 "vector.opt"
          renderer__V_11_48 = (renderer__Ay_5_42 + renderer__By_8_45);
#line 6 "vector.opt"
          renderer__V_12_49 = (renderer__Az_6_43 + renderer__Bz_9_46);
#line 3 "vector.opt"
          {
#line 3 "vector.opt"
            renderer__Acc1_12_12 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 3 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__Acc1_12_12, 0) = MR_box_float(renderer__V_10_47);
#line 3 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__Acc1_12_12, 1) = MR_box_float(renderer__V_11_48);
#line 3 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__Acc1_12_12, 2) = MR_box_float(renderer__V_12_49);
#line 3 "vector.opt"
          }
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          {
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            /* direct tailcall eliminated */
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            {
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_Word renderer__HeadVar__2__tmp_copy_2 = renderer__T_9_9;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_Word renderer__HeadVar__3__tmp_copy_3 = renderer__Acc1_12_12;

#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              renderer__HeadVar__2_2 = renderer__HeadVar__2__tmp_copy_2;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              renderer__HeadVar__3_3 = renderer__HeadVar__3__tmp_copy_3;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            }
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            goto loop_top;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 155 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 158 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static MR_Word MR_CALL renderer__foldl__ho7_4_f_in__list_0(
#line 158 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__2_2,
#line 158 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word renderer__HeadVar__3_3)
#line 158 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 162 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 162 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool renderer__succeeded;
#line 162 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word renderer__HeadVar__4_4;

#line 162 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 162 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      renderer__foldl__ho12_4_p_in__list_0(renderer__HeadVar__2_2, renderer__HeadVar__3_3, &renderer__HeadVar__4_4);
    }
#line 162 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    return renderer__HeadVar__4_4;
#line 162 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 158 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 619 "renderer.m"
static MR_Word MR_CALL renderer__IntroducedFrom__func__compute_intensity__619__2_7_f_0(
#line 619 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 619 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 619 "renderer.m"
  MR_Word renderer__HeadVar__5_5,
#line 619 "renderer.m"
  MR_Word renderer__C_25,
#line 619 "renderer.m"
  MR_Float renderer__V_124_124,
#line 619 "renderer.m"
  MR_Word renderer__V_66_66)
#line 619 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__V_65_65;
    MR_Float renderer__SanityCheck_47;
    MR_Word renderer__Light_100;
    MR_Word renderer__Lj_101;
    MR_Float renderer__V_166_166;

#line 622 "renderer.m"
    {
#line 622 "renderer.m"
      renderer__Light_100 = renderer__light_value_to_light_2_f_0(renderer__V_66_66);
    }
#line 623 "renderer.m"
    {
#line 623 "renderer.m"
      renderer__Lj_101 = renderer__light_unit_vector_3_f_0(renderer__Light_100, renderer__HeadVar__4_4);
    }
#line 628 "renderer.m"
    {
#line 628 "renderer.m"
      renderer__SanityCheck_47 = vector__dot_3_f_0(renderer__HeadVar__5_5, renderer__Lj_101);
    }
#line 630 "renderer.m"
    renderer__V_166_166 = (MR_Float) 0.00000000000000;
#line 630 "renderer.m"
    renderer__succeeded = (renderer__SanityCheck_47 <= renderer__V_166_166);
#line 633 "renderer.m"
    if (renderer__succeeded)
#line 632 "renderer.m"
      {
#line 632 "renderer.m"
        return renderer__V_65_65 = vector__zero_1_f_0();
      }
#line 633 "renderer.m"
    else
      {
        MR_Word renderer__Hj_48;
        MR_Float renderer__ReflectionBase_49;
        MR_Word renderer__V_71_71;
        MR_Word renderer__V_72_72;
        MR_Float renderer__V_167_167;

#line 634 "renderer.m"
        {
#line 634 "renderer.m"
          renderer__V_72_72 = vector__unit_2_f_0(renderer__HeadVar__2_2);
        }
#line 634 "renderer.m"
        {
#line 634 "renderer.m"
          renderer__V_71_71 = vector__f_minus_3_f_0(renderer__Lj_101, renderer__V_72_72);
        }
#line 634 "renderer.m"
        {
#line 634 "renderer.m"
          renderer__Hj_48 = vector__unit_2_f_0(renderer__V_71_71);
        }
#line 635 "renderer.m"
        {
#line 635 "renderer.m"
          renderer__ReflectionBase_49 = vector__dot_3_f_0(renderer__HeadVar__5_5, renderer__Hj_48);
        }
#line 636 "renderer.m"
        renderer__V_167_167 = (MR_Float) 0.00000000000000;
#line 636 "renderer.m"
        renderer__succeeded = (renderer__ReflectionBase_49 <= renderer__V_167_167);
#line 638 "renderer.m"
        if (renderer__succeeded)
#line 637 "renderer.m"
          {
#line 637 "renderer.m"
            return renderer__V_65_65 = vector__zero_1_f_0();
          }
#line 638 "renderer.m"
        else
          {
            MR_Float renderer__V_69_69;
            MR_Word renderer__V_70_70;
            MR_Word renderer__Ij_95;

#line 639 "renderer.m"
            {
#line 639 "renderer.m"
              renderer__Ij_95 = renderer__light_intensity_3_f_0(renderer__Light_100, renderer__HeadVar__4_4);
            }
#line 641 "renderer.m"
            {
#line 641 "renderer.m"
              renderer__V_69_69 = mercury__math__pow_3_f_0(renderer__ReflectionBase_49, renderer__V_124_124);
            }
#line 641 "renderer.m"
            {
#line 641 "renderer.m"
              renderer__V_70_70 = renderer__f_times_3_f_0(renderer__Ij_95, renderer__C_25);
            }
#line 641 "renderer.m"
            {
#line 641 "renderer.m"
              return renderer__V_65_65 = vector__scale_3_f_0(renderer__V_69_69, renderer__V_70_70);
            }
          }
      }
    return renderer__V_65_65;
  }
#line 619 "renderer.m"
}

#line 597 "renderer.m"
static MR_Word MR_CALL renderer__IntroducedFrom__func__compute_intensity__597__1_5_f_0(
#line 597 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 597 "renderer.m"
  MR_Word renderer__HeadVar__5_5,
#line 597 "renderer.m"
  MR_Word renderer__C_25,
#line 597 "renderer.m"
  MR_Word renderer__V_76_76)
#line 597 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__V_75_75;
    MR_Word renderer__Light_38;
    MR_Word renderer__Lj_39;
    MR_Float renderer__DotProd_40;
    MR_Float renderer__V_166_166;

#line 599 "renderer.m"
    {
#line 599 "renderer.m"
      renderer__Light_38 = renderer__light_value_to_light_2_f_0(renderer__V_76_76);
    }
#line 600 "renderer.m"
    {
#line 600 "renderer.m"
      renderer__Lj_39 = renderer__light_unit_vector_3_f_0(renderer__Light_38, renderer__HeadVar__4_4);
    }
#line 601 "renderer.m"
    {
#line 601 "renderer.m"
      renderer__DotProd_40 = vector__dot_3_f_0(renderer__HeadVar__5_5, renderer__Lj_39);
    }
#line 602 "renderer.m"
    renderer__V_166_166 = (MR_Float) 0.00000000000000;
#line 602 "renderer.m"
    renderer__succeeded = (renderer__DotProd_40 <= renderer__V_166_166);
#line 604 "renderer.m"
    if (renderer__succeeded)
#line 603 "renderer.m"
      {
#line 603 "renderer.m"
        return renderer__V_75_75 = vector__zero_1_f_0();
      }
#line 604 "renderer.m"
    else
      {
        MR_Word renderer__Ij_41;
        MR_Word renderer__V_78_78;

#line 605 "renderer.m"
        {
#line 605 "renderer.m"
          renderer__Ij_41 = renderer__light_intensity_3_f_0(renderer__Light_38, renderer__HeadVar__4_4);
        }
#line 606 "renderer.m"
        {
#line 606 "renderer.m"
          renderer__V_78_78 = renderer__f_times_3_f_0(renderer__Ij_41, renderer__C_25);
        }
#line 606 "renderer.m"
        {
#line 606 "renderer.m"
          return renderer__V_75_75 = vector__scale_3_f_0(renderer__DotProd_40, renderer__V_78_78);
        }
      }
    return renderer__V_75_75;
  }
#line 597 "renderer.m"
}

#line 267 "renderer.m"
void MR_CALL renderer____Compare____best_intersection_0_0(
#line 267 "renderer.m"
  MR_Word * renderer__HeadVar__1_1,
#line 267 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 267 "renderer.m"
  MR_Word renderer__HeadVar__3_3)
#line 267 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__conv1_HeadVar__2_2 = (MR_Word) renderer__HeadVar__2_2;
    MR_Word renderer__conv2_HeadVar__3_3 = (MR_Word) renderer__HeadVar__3_3;
    MR_Word renderer__TypeInfo_4_4 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_float_0);
    MR_Word renderer__TypeInfo_5_5 = (MR_Word) (&trans__trans__type_ctor_info_intersection_0);

#line 267 "renderer.m"
    {
#line 267 "renderer.m"
      mercury__std_util____Compare____pair_2_0(renderer__TypeInfo_4_4, renderer__TypeInfo_5_5, renderer__HeadVar__1_1, renderer__conv1_HeadVar__2_2, renderer__conv2_HeadVar__3_3);
#line 267 "renderer.m"
      return;
    }
  }
#line 267 "renderer.m"
}

#line 267 "renderer.m"
bool MR_CALL renderer____Unify____best_intersection_0_0(
#line 267 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 267 "renderer.m"
  MR_Word renderer__HeadVar__2_2)
#line 267 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__conv1_HeadVar__1_1 = (MR_Word) renderer__HeadVar__1_1;
    MR_Word renderer__conv2_HeadVar__2_2 = (MR_Word) renderer__HeadVar__2_2;
    MR_Word renderer__TypeInfo_3_3 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_float_0);
    MR_Word renderer__TypeInfo_4_4 = (MR_Word) (&trans__trans__type_ctor_info_intersection_0);

#line 267 "renderer.m"
    {
#line 267 "renderer.m"
      renderer__succeeded = mercury__std_util____Unify____pair_2_0(renderer__TypeInfo_3_3, renderer__TypeInfo_4_4, renderer__conv1_HeadVar__1_1, renderer__conv2_HeadVar__2_2);
    }
    if (renderer__succeeded)
      renderer__succeeded = TRUE;
    return renderer__succeeded;
  }
#line 267 "renderer.m"
}
static /* final */ const MR_Box renderer__const_1330_0_1_TypeInfo_7_7[3] = {
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_pair_2))),
		((MR_Box) ((&mercury__builtin__builtin__type_ctor_info_float_0))),
		((MR_Box) ((&trans__trans__type_ctor_info_intersection_0)))};

#line 168 "renderer.m"
void MR_CALL renderer____Compare____intersection_result_0_0(
#line 168 "renderer.m"
  MR_Word * renderer__HeadVar__1_1,
#line 168 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 168 "renderer.m"
  MR_Word renderer__HeadVar__3_3)
#line 168 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__conv1_HeadVar__2_2 = (MR_Word) renderer__HeadVar__2_2;
    MR_Word renderer__conv2_HeadVar__3_3 = (MR_Word) renderer__HeadVar__3_3;
    MR_Word renderer__TypeInfo_4_4 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_float_0);
    MR_Word renderer__TypeInfo_5_5 = (MR_Word) (&trans__trans__type_ctor_info_intersection_0);
    MR_Word renderer__TypeInfo_6_6 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_pair_2);
    MR_Word renderer__TypeInfo_7_7 = (MR_Word) &renderer__const_1330_0_1_TypeInfo_7_7;

#line 168 "renderer.m"
    {
#line 168 "renderer.m"
      tree____Compare____tree_1_0(renderer__TypeInfo_7_7, renderer__HeadVar__1_1, renderer__conv1_HeadVar__2_2, renderer__conv2_HeadVar__3_3);
#line 168 "renderer.m"
      return;
    }
  }
#line 168 "renderer.m"
}
static /* final */ const MR_Box renderer__const_1329_0_1_TypeInfo_6_6[3] = {
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_pair_2))),
		((MR_Box) ((&mercury__builtin__builtin__type_ctor_info_float_0))),
		((MR_Box) ((&trans__trans__type_ctor_info_intersection_0)))};

#line 168 "renderer.m"
bool MR_CALL renderer____Unify____intersection_result_0_0(
#line 168 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 168 "renderer.m"
  MR_Word renderer__HeadVar__2_2)
#line 168 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__conv1_HeadVar__1_1 = (MR_Word) renderer__HeadVar__1_1;
    MR_Word renderer__conv2_HeadVar__2_2 = (MR_Word) renderer__HeadVar__2_2;
    MR_Word renderer__TypeInfo_3_3 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_float_0);
    MR_Word renderer__TypeInfo_4_4 = (MR_Word) (&trans__trans__type_ctor_info_intersection_0);
    MR_Word renderer__TypeInfo_5_5 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_pair_2);
    MR_Word renderer__TypeInfo_6_6 = (MR_Word) &renderer__const_1329_0_1_TypeInfo_6_6;

#line 168 "renderer.m"
    {
#line 168 "renderer.m"
      renderer__succeeded = tree____Unify____tree_1_0(renderer__TypeInfo_6_6, renderer__conv1_HeadVar__1_1, renderer__conv2_HeadVar__2_2);
    }
    if (renderer__succeeded)
      renderer__succeeded = TRUE;
    return renderer__succeeded;
  }
#line 168 "renderer.m"
}

#line 114 "renderer.m"
void MR_CALL renderer____Compare____pixel_coords_0_0(
#line 114 "renderer.m"
  MR_Word * renderer__HeadVar__1_1,
#line 114 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 114 "renderer.m"
  MR_Word renderer__HeadVar__3_3)
#line 114 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Integer renderer__V_4_4 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 0)));
    MR_Integer renderer__V_5_5 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 1)));
    MR_Integer renderer__V_6_6 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 0)));
    MR_Integer renderer__V_7_7 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 1)));
#line 114 "renderer.m"
    MR_Word renderer__V_8_8;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    renderer__succeeded = (renderer__V_4_4 < renderer__V_6_6);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (renderer__succeeded)
      {
        MR_Word renderer__V_17_17 = (MR_Integer) 1;

#line 114 "renderer.m"
        renderer__succeeded = (renderer__V_17_17 == (MR_Integer) 0);
#line 114 "renderer.m"
        renderer__succeeded = !(renderer__succeeded);
        if (renderer__succeeded)
          {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            renderer__V_8_8 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            renderer__succeeded = TRUE;
          }
      }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        renderer__succeeded = (renderer__V_4_4 == renderer__V_6_6);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (renderer__succeeded)
          {
            MR_Word renderer__V_18_18 = (MR_Integer) 0;

#line 114 "renderer.m"
            renderer__succeeded = (renderer__V_18_18 == (MR_Integer) 0);
#line 114 "renderer.m"
            renderer__succeeded = !(renderer__succeeded);
            if (renderer__succeeded)
              {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                renderer__V_8_8 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                renderer__succeeded = TRUE;
              }
          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
          {
            MR_Word renderer__V_19_19 = (MR_Integer) 2;

#line 114 "renderer.m"
            renderer__succeeded = (renderer__V_19_19 == (MR_Integer) 0);
#line 114 "renderer.m"
            renderer__succeeded = !(renderer__succeeded);
            if (renderer__succeeded)
              {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                renderer__V_8_8 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                renderer__succeeded = TRUE;
              }
          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 114 "renderer.m"
    if (renderer__succeeded)
#line 114 "renderer.m"
      *renderer__HeadVar__1_1 = renderer__V_8_8;
#line 114 "renderer.m"
    else
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        renderer__succeeded = (renderer__V_5_5 < renderer__V_7_7);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (renderer__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *renderer__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            renderer__succeeded = (renderer__V_5_5 == renderer__V_7_7);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (renderer__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              *renderer__HeadVar__1_1 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              *renderer__HeadVar__1_1 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
  }
#line 114 "renderer.m"
}

#line 114 "renderer.m"
bool MR_CALL renderer____Unify____pixel_coords_0_0(
#line 114 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 114 "renderer.m"
  MR_Word renderer__HeadVar__2_2)
#line 114 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Integer renderer__V_3_3 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
    MR_Integer renderer__V_4_4 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
    MR_Integer renderer__V_5_5 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 0)));
    MR_Integer renderer__V_6_6 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 1)));

    renderer__succeeded = (renderer__V_3_3 == renderer__V_5_5);
    if (renderer__succeeded)
      renderer__succeeded = (renderer__V_4_4 == renderer__V_6_6);
    return renderer__succeeded;
  }
#line 114 "renderer.m"
}

#line 23 "renderer.m"
void MR_CALL renderer____Compare____unimplemented_object_0_0(
#line 23 "renderer.m"
  MR_Word * renderer__HeadVar__1_1,
#line 23 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 23 "renderer.m"
  MR_Word renderer__HeadVar__3_3)
#line 23 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__V_4_4 = (MR_Word) renderer__HeadVar__2_2;
    MR_Word renderer__V_5_5 = (MR_Word) renderer__HeadVar__3_3;

#line 23 "renderer.m"
    {
#line 23 "renderer.m"
      eval____Compare____object_0_0(renderer__HeadVar__1_1, renderer__V_4_4, renderer__V_5_5);
#line 23 "renderer.m"
      return;
    }
  }
#line 23 "renderer.m"
}

#line 23 "renderer.m"
bool MR_CALL renderer____Unify____unimplemented_object_0_0(
#line 23 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 23 "renderer.m"
  MR_Word renderer__HeadVar__2_2)
#line 23 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__V_3_3 = (MR_Word) renderer__HeadVar__1_1;
    MR_Word renderer__V_4_4 = (MR_Word) renderer__HeadVar__2_2;

    {
      return renderer__succeeded = eval____Unify____object_0_0(renderer__V_3_3, renderer__V_4_4);
    }
    return renderer__succeeded;
  }
#line 23 "renderer.m"
}

#line 7 "renderer.m"
void MR_CALL renderer____Compare____render_params_0_0(
#line 7 "renderer.m"
  MR_Word * renderer__HeadVar__1_1,
#line 7 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 7 "renderer.m"
  MR_Word renderer__HeadVar__3_3)
#line 7 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 0)));
    MR_Array renderer__V_5_5 = ((MR_Array) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word renderer__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 2)));
    MR_Integer renderer__V_7_7 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 3)));
    MR_Float renderer__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 4)));
    MR_Integer renderer__V_9_9 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 5)));
    MR_Integer renderer__V_10_10 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 6)));
    MR_String renderer__V_11_11 = ((MR_String) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 7)));
    MR_Word renderer__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 0)));
    MR_Array renderer__V_13_13 = ((MR_Array) (MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 1)));
    MR_Word renderer__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 2)));
    MR_Integer renderer__V_15_15 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 3)));
    MR_Float renderer__V_16_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 4)));
    MR_Integer renderer__V_17_17 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 5)));
    MR_Integer renderer__V_18_18 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 6)));
    MR_String renderer__V_19_19 = ((MR_String) (MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 7)));
#line 7 "renderer.m"
    MR_Word renderer__V_20_20;

#line 7 "renderer.m"
    {
#line 7 "renderer.m"
      vector____Compare____vector_0_0(&renderer__V_20_20, renderer__V_4_4, renderer__V_12_12);
    }
#line 7 "renderer.m"
    renderer__succeeded = (renderer__V_20_20 == (MR_Integer) 0);
#line 7 "renderer.m"
    renderer__succeeded = !(renderer__succeeded);
#line 7 "renderer.m"
    if (renderer__succeeded)
#line 7 "renderer.m"
      *renderer__HeadVar__1_1 = renderer__V_20_20;
#line 7 "renderer.m"
    else
#line 7 "renderer.m"
      {
#line 7 "renderer.m"
        MR_Word renderer__V_21_21;
        MR_Word renderer__TypeInfo_28_28 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 7 "renderer.m"
        {
#line 7 "renderer.m"
          mercury__array____Compare____array_1_0(renderer__TypeInfo_28_28, &renderer__V_21_21, (MR_Array) renderer__V_5_5, (MR_Array) renderer__V_13_13);
        }
#line 7 "renderer.m"
        renderer__succeeded = (renderer__V_21_21 == (MR_Integer) 0);
#line 7 "renderer.m"
        renderer__succeeded = !(renderer__succeeded);
#line 7 "renderer.m"
        if (renderer__succeeded)
#line 7 "renderer.m"
          *renderer__HeadVar__1_1 = renderer__V_21_21;
#line 7 "renderer.m"
        else
#line 7 "renderer.m"
          {
#line 7 "renderer.m"
            MR_Word renderer__V_22_22;

#line 7 "renderer.m"
            {
#line 7 "renderer.m"
              space_partition____Compare____scene_0_0(&renderer__V_22_22, renderer__V_6_6, renderer__V_14_14);
            }
#line 7 "renderer.m"
            renderer__succeeded = (renderer__V_22_22 == (MR_Integer) 0);
#line 7 "renderer.m"
            renderer__succeeded = !(renderer__succeeded);
#line 7 "renderer.m"
            if (renderer__succeeded)
#line 7 "renderer.m"
              *renderer__HeadVar__1_1 = renderer__V_22_22;
#line 7 "renderer.m"
            else
#line 7 "renderer.m"
              {
#line 7 "renderer.m"
                MR_Word renderer__V_23_23;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                renderer__succeeded = (renderer__V_7_7 < renderer__V_15_15);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (renderer__succeeded)
                  {
                    MR_Word renderer__V_57_57 = (MR_Integer) 1;

#line 7 "renderer.m"
                    renderer__succeeded = (renderer__V_57_57 == (MR_Integer) 0);
#line 7 "renderer.m"
                    renderer__succeeded = !(renderer__succeeded);
                    if (renderer__succeeded)
                      {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        renderer__V_23_23 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        renderer__succeeded = TRUE;
                      }
                  }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    renderer__succeeded = (renderer__V_7_7 == renderer__V_15_15);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    if (renderer__succeeded)
                      {
                        MR_Word renderer__V_58_58 = (MR_Integer) 0;

#line 7 "renderer.m"
                        renderer__succeeded = (renderer__V_58_58 == (MR_Integer) 0);
#line 7 "renderer.m"
                        renderer__succeeded = !(renderer__succeeded);
                        if (renderer__succeeded)
                          {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            renderer__V_23_23 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            renderer__succeeded = TRUE;
                          }
                      }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    else
                      {
                        MR_Word renderer__V_59_59 = (MR_Integer) 2;

#line 7 "renderer.m"
                        renderer__succeeded = (renderer__V_59_59 == (MR_Integer) 0);
#line 7 "renderer.m"
                        renderer__succeeded = !(renderer__succeeded);
                        if (renderer__succeeded)
                          {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            renderer__V_23_23 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            renderer__succeeded = TRUE;
                          }
                      }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  }
#line 7 "renderer.m"
                if (renderer__succeeded)
#line 7 "renderer.m"
                  *renderer__HeadVar__1_1 = renderer__V_23_23;
#line 7 "renderer.m"
                else
#line 7 "renderer.m"
                  {
#line 7 "renderer.m"
                    MR_Word renderer__V_24_24;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    renderer__succeeded = (renderer__V_8_8 < renderer__V_16_16);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    if (renderer__succeeded)
                      {
                        MR_Word renderer__V_60_60 = (MR_Integer) 1;

#line 7 "renderer.m"
                        renderer__succeeded = (renderer__V_60_60 == (MR_Integer) 0);
#line 7 "renderer.m"
                        renderer__succeeded = !(renderer__succeeded);
                        if (renderer__succeeded)
                          {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            renderer__V_24_24 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            renderer__succeeded = TRUE;
                          }
                      }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        renderer__succeeded = (renderer__V_8_8 > renderer__V_16_16);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        if (renderer__succeeded)
                          {
                            MR_Word renderer__V_61_61 = (MR_Integer) 2;

#line 7 "renderer.m"
                            renderer__succeeded = (renderer__V_61_61 == (MR_Integer) 0);
#line 7 "renderer.m"
                            renderer__succeeded = !(renderer__succeeded);
                            if (renderer__succeeded)
                              {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                renderer__V_24_24 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                renderer__succeeded = TRUE;
                              }
                          }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        else
                          {
                            MR_Word renderer__V_62_62 = (MR_Integer) 0;

#line 7 "renderer.m"
                            renderer__succeeded = (renderer__V_62_62 == (MR_Integer) 0);
#line 7 "renderer.m"
                            renderer__succeeded = !(renderer__succeeded);
                            if (renderer__succeeded)
                              {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                renderer__V_24_24 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                renderer__succeeded = TRUE;
                              }
                          }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      }
#line 7 "renderer.m"
                    if (renderer__succeeded)
#line 7 "renderer.m"
                      *renderer__HeadVar__1_1 = renderer__V_24_24;
#line 7 "renderer.m"
                    else
#line 7 "renderer.m"
                      {
#line 7 "renderer.m"
                        MR_Word renderer__V_25_25;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        renderer__succeeded = (renderer__V_9_9 < renderer__V_17_17);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        if (renderer__succeeded)
                          {
                            MR_Word renderer__V_63_63 = (MR_Integer) 1;

#line 7 "renderer.m"
                            renderer__succeeded = (renderer__V_63_63 == (MR_Integer) 0);
#line 7 "renderer.m"
                            renderer__succeeded = !(renderer__succeeded);
                            if (renderer__succeeded)
                              {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                renderer__V_25_25 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                renderer__succeeded = TRUE;
                              }
                          }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            renderer__succeeded = (renderer__V_9_9 == renderer__V_17_17);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            if (renderer__succeeded)
                              {
                                MR_Word renderer__V_64_64 = (MR_Integer) 0;

#line 7 "renderer.m"
                                renderer__succeeded = (renderer__V_64_64 == (MR_Integer) 0);
#line 7 "renderer.m"
                                renderer__succeeded = !(renderer__succeeded);
                                if (renderer__succeeded)
                                  {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    renderer__V_25_25 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    renderer__succeeded = TRUE;
                                  }
                              }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            else
                              {
                                MR_Word renderer__V_65_65 = (MR_Integer) 2;

#line 7 "renderer.m"
                                renderer__succeeded = (renderer__V_65_65 == (MR_Integer) 0);
#line 7 "renderer.m"
                                renderer__succeeded = !(renderer__succeeded);
                                if (renderer__succeeded)
                                  {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    renderer__V_25_25 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    renderer__succeeded = TRUE;
                                  }
                              }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          }
#line 7 "renderer.m"
                        if (renderer__succeeded)
#line 7 "renderer.m"
                          *renderer__HeadVar__1_1 = renderer__V_25_25;
#line 7 "renderer.m"
                        else
#line 7 "renderer.m"
                          {
#line 7 "renderer.m"
                            MR_Word renderer__V_26_26;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            renderer__succeeded = (renderer__V_10_10 < renderer__V_18_18);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            if (renderer__succeeded)
                              {
                                MR_Word renderer__V_66_66 = (MR_Integer) 1;

#line 7 "renderer.m"
                                renderer__succeeded = (renderer__V_66_66 == (MR_Integer) 0);
#line 7 "renderer.m"
                                renderer__succeeded = !(renderer__succeeded);
                                if (renderer__succeeded)
                                  {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    renderer__V_26_26 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    renderer__succeeded = TRUE;
                                  }
                              }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                renderer__succeeded = (renderer__V_10_10 == renderer__V_18_18);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                if (renderer__succeeded)
                                  {
                                    MR_Word renderer__V_67_67 = (MR_Integer) 0;

#line 7 "renderer.m"
                                    renderer__succeeded = (renderer__V_67_67 == (MR_Integer) 0);
#line 7 "renderer.m"
                                    renderer__succeeded = !(renderer__succeeded);
                                    if (renderer__succeeded)
                                      {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        renderer__V_26_26 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        renderer__succeeded = TRUE;
                                      }
                                  }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                else
                                  {
                                    MR_Word renderer__V_68_68 = (MR_Integer) 2;

#line 7 "renderer.m"
                                    renderer__succeeded = (renderer__V_68_68 == (MR_Integer) 0);
#line 7 "renderer.m"
                                    renderer__succeeded = !(renderer__succeeded);
                                    if (renderer__succeeded)
                                      {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        renderer__V_26_26 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        renderer__succeeded = TRUE;
                                      }
                                  }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              }
#line 7 "renderer.m"
                            if (renderer__succeeded)
#line 7 "renderer.m"
                              *renderer__HeadVar__1_1 = renderer__V_26_26;
#line 7 "renderer.m"
                            else
                              {
                                MR_Integer renderer__Res_7_52;
                                MR_Integer renderer__V_69_69;

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL renderer____Compare____render_params_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
renderer__V_11_11
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
renderer__V_19_19
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
renderer__Res_7_52
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                renderer__V_69_69 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                renderer__succeeded = (renderer__Res_7_52 < renderer__V_69_69);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                if (renderer__succeeded)
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  *renderer__HeadVar__1_1 = (MR_Integer) 1;
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    renderer__succeeded = (renderer__Res_7_52 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    if (renderer__succeeded)
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      *renderer__HeadVar__1_1 = (MR_Integer) 0;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    else
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      *renderer__HeadVar__1_1 = (MR_Integer) 2;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  }
                              }
#line 7 "renderer.m"
                          }
#line 7 "renderer.m"
                      }
#line 7 "renderer.m"
                  }
#line 7 "renderer.m"
              }
#line 7 "renderer.m"
          }
#line 7 "renderer.m"
      }
  }
#line 7 "renderer.m"
}

#line 7 "renderer.m"
bool MR_CALL renderer____Unify____render_params_0_0(
#line 7 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 7 "renderer.m"
  MR_Word renderer__HeadVar__2_2)
#line 7 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
    MR_Array renderer__V_4_4 = ((MR_Array) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word renderer__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
    MR_Integer renderer__V_6_6 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 3)));
    MR_Float renderer__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 4)));
    MR_Integer renderer__V_8_8 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 5)));
    MR_Integer renderer__V_9_9 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 6)));
    MR_String renderer__V_10_10 = ((MR_String) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 7)));
    MR_Word renderer__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 0)));
    MR_Array renderer__V_12_12 = ((MR_Array) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word renderer__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 2)));
    MR_Integer renderer__V_14_14 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 3)));
    MR_Float renderer__V_15_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 4)));
    MR_Integer renderer__V_16_16 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 5)));
    MR_Integer renderer__V_17_17 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 6)));
    MR_String renderer__V_18_18 = ((MR_String) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 7)));
    MR_Word renderer__TypeInfo_20_20;

    {
      renderer__succeeded = vector____Unify____vector_0_0(renderer__V_3_3, renderer__V_11_11);
    }
    if (renderer__succeeded)
      {
        renderer__TypeInfo_20_20 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
        {
          renderer__succeeded = mercury__array____Unify____array_1_0(renderer__TypeInfo_20_20, (MR_Array) renderer__V_4_4, (MR_Array) renderer__V_12_12);
        }
        if (renderer__succeeded)
          {
            {
              renderer__succeeded = space_partition____Unify____scene_0_0(renderer__V_5_5, renderer__V_13_13);
            }
            if (renderer__succeeded)
              {
                renderer__succeeded = (renderer__V_6_6 == renderer__V_14_14);
                if (renderer__succeeded)
                  {
                    renderer__succeeded = (renderer__V_7_7 == renderer__V_15_15);
                    if (renderer__succeeded)
                      {
                        renderer__succeeded = (renderer__V_8_8 == renderer__V_16_16);
                        if (renderer__succeeded)
                          {
                            renderer__succeeded = (renderer__V_9_9 == renderer__V_17_17);
                            if (renderer__succeeded)
                              renderer__succeeded = (strcmp(renderer__V_10_10, renderer__V_18_18) == 0);
                          }
                      }
                  }
              }
          }
      }
    return renderer__succeeded;
  }
#line 7 "renderer.m"
}

#line 849 "renderer.m"
static MR_Word MR_CALL renderer__intersection_list_to_tree_3_f_0(
#line 849 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 849 "renderer.m"
  MR_Word renderer__HeadVar__2_2)
#line 849 "renderer.m"
{
#line 851 "renderer.m"
  {
#line 851 "renderer.m"
    bool renderer__succeeded;
#line 851 "renderer.m"
    MR_Word renderer__HeadVar__3_3;
#line 851 "renderer.m"
    MR_Word renderer__Int_6;
#line 851 "renderer.m"
    MR_Word renderer__Ints_7;
#line 851 "renderer.m"
    MR_Float renderer__DistanceSquared_8;
#line 851 "renderer.m"
    MR_Word renderer__Tree0_9;
#line 851 "renderer.m"
    MR_Word renderer__V_10_10;
#line 851 "renderer.m"
    MR_Word renderer__V_11_11;
#line 851 "renderer.m"
    MR_Word renderer__V_12_12;

#line 851 "renderer.m"
    if ((renderer__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 851 "renderer.m"
      renderer__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 851 "renderer.m"
    else
#line 851 "renderer.m"
      {
#line 856 "renderer.m"
        MR_Integer renderer__V_13_13;
#line 856 "renderer.m"
        MR_Word renderer__V_14_14;
#line 856 "renderer.m"
        MR_Word renderer__V_15_15;
#line 856 "renderer.m"
        MR_Word renderer__V_16_16;

#line 853 "renderer.m"
        renderer__Int_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 0)));
#line 853 "renderer.m"
        renderer__Ints_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 1)));
#line 854 "renderer.m"
        {
#line 854 "renderer.m"
          renderer__Tree0_9 = renderer__intersection_list_to_tree_3_f_0(renderer__HeadVar__1_1, renderer__Ints_7);
        }
#line 856 "renderer.m"
        renderer__V_13_13 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__Int_6, (MR_Integer) 0)));
#line 856 "renderer.m"
        renderer__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Int_6, (MR_Integer) 1)));
#line 856 "renderer.m"
        renderer__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Int_6, (MR_Integer) 2)));
#line 856 "renderer.m"
        renderer__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Int_6, (MR_Integer) 3)));
#line 856 "renderer.m"
        renderer__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Int_6, (MR_Integer) 4)));
#line 855 "renderer.m"
        {
#line 855 "renderer.m"
          renderer__DistanceSquared_8 = vector__distance_squared_3_f_0(renderer__HeadVar__1_1, renderer__V_10_10);
        }
#line 853 "renderer.m"
        {
#line 853 "renderer.m"
          renderer__V_12_12 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 853 "renderer.m"
          MR_hl_field(MR_mktag(0), renderer__V_12_12, 0) = MR_box_float(renderer__DistanceSquared_8);
#line 853 "renderer.m"
          MR_hl_field(MR_mktag(0), renderer__V_12_12, 1) = ((MR_Box) (renderer__Int_6));
#line 853 "renderer.m"
        }
#line 853 "renderer.m"
        {
#line 853 "renderer.m"
          renderer__V_11_11 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "node"));
#line 853 "renderer.m"
          MR_hl_field(MR_mktag(1), renderer__V_11_11, 0) = ((MR_Box) (renderer__V_12_12));
#line 853 "renderer.m"
        }
#line 853 "renderer.m"
        {
#line 853 "renderer.m"
          renderer__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "tree"));
#line 853 "renderer.m"
          MR_hl_field(MR_mktag(2), renderer__HeadVar__3_3, 0) = ((MR_Box) (renderer__V_11_11));
#line 853 "renderer.m"
          MR_hl_field(MR_mktag(2), renderer__HeadVar__3_3, 1) = ((MR_Box) (renderer__Tree0_9));
#line 853 "renderer.m"
        }
#line 851 "renderer.m"
      }
#line 851 "renderer.m"
    return renderer__HeadVar__3_3;
#line 851 "renderer.m"
  }
#line 849 "renderer.m"
}

#line 784 "renderer.m"
static bool MR_CALL renderer__point_is_in_object_3_p_0(
#line 784 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 784 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 784 "renderer.m"
  MR_Word renderer__HeadVar__3_3)
#line 784 "renderer.m"
{
#line 787 "renderer.m"
  {
#line 787 "renderer.m"
    /* tailcall optimized into a loop */
#line 787 "renderer.m"
  loop_top:;
#line 787 "renderer.m"
    {
#line 787 "renderer.m"
      bool renderer__succeeded;

#line 787 "renderer.m"
#line 787 "renderer.m"
      switch (MR_tag((MR_Word) renderer__HeadVar__2_2)) {
#line 787 "renderer.m"
        default: /*NOTREACHED*/ MR_assert(0);
#line 787 "renderer.m"
        case (MR_Integer) 3:
#line 787 "renderer.m"
#line 787 "renderer.m"
          switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__2_2, (MR_Integer) 0)))) {
#line 787 "renderer.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 787 "renderer.m"
            case (MR_Integer) 0:
              {
                MR_Word renderer__Obj1_21 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__2_2, (MR_Integer) 1)));
                MR_Word renderer__Obj2_22 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__2_2, (MR_Integer) 2)));

#line 806 "renderer.m"
                {
#line 806 "renderer.m"
                  renderer__succeeded = renderer__point_is_in_object_3_p_0(renderer__HeadVar__1_1, renderer__Obj1_21, renderer__HeadVar__3_3);
                }
                if (renderer__succeeded)
#line 807 "renderer.m"
                  {
#line 807 "renderer.m"
                    /* direct tailcall eliminated */
#line 807 "renderer.m"
                    {
#line 807 "renderer.m"
                      MR_Word renderer__HeadVar__2__tmp_copy_2 = renderer__Obj2_22;

#line 807 "renderer.m"
                      renderer__HeadVar__2_2 = renderer__HeadVar__2__tmp_copy_2;
#line 807 "renderer.m"
                    }
#line 807 "renderer.m"
                    goto loop_top;
#line 807 "renderer.m"
                  }
              }
#line 787 "renderer.m"
              break;
#line 787 "renderer.m"
            case (MR_Integer) 1:
              {
                MR_Word renderer__Obj1_25 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__2_2, (MR_Integer) 1)));
                MR_Word renderer__Obj2_26 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__2_2, (MR_Integer) 2)));

#line 809 "renderer.m"
                {
#line 809 "renderer.m"
                  renderer__succeeded = renderer__point_is_in_object_3_p_0(renderer__HeadVar__1_1, renderer__Obj1_25, renderer__HeadVar__3_3);
                }
                if (renderer__succeeded)
                  {
#line 810 "renderer.m"
                    {
#line 810 "renderer.m"
                      renderer__succeeded = renderer__point_is_in_object_3_p_0(renderer__HeadVar__1_1, renderer__Obj2_26, renderer__HeadVar__3_3);
                    }
#line 810 "renderer.m"
                    renderer__succeeded = !(renderer__succeeded);
                  }
              }
#line 787 "renderer.m"
              break;
#line 787 "renderer.m"
          }
#line 787 "renderer.m"
          break;
#line 787 "renderer.m"
        case (MR_Integer) 0:
          {
            MR_Word renderer__Obj_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 1)));
            MR_Word renderer__Trans_32;
#line 787 "renderer.m"
            MR_Integer renderer___Id_5 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 0)));
#line 787 "renderer.m"
            MR_Word renderer___List_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 2)));

#line 816 "renderer.m"
            {
#line 816 "renderer.m"
              renderer__Trans_32 = renderer__maybe_transformation_to_trans_2_f_0(renderer__HeadVar__3_3);
            }
#line 836 "renderer.m"
#line 836 "renderer.m"
            switch (MR_tag((MR_Word) renderer__Obj_6)) {
#line 836 "renderer.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 836 "renderer.m"
              case (MR_Integer) 3:
#line 836 "renderer.m"
#line 836 "renderer.m"
                switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), renderer__Obj_6, (MR_Integer) 0)))) {
#line 836 "renderer.m"
                  default: /*NOTREACHED*/ MR_assert(0);
#line 836 "renderer.m"
                  case (MR_Integer) 0:
#line 845 "renderer.m"
                    {
#line 845 "renderer.m"
                      return renderer__succeeded = trans__inside_cone_2_p_0(renderer__HeadVar__1_1, renderer__Trans_32);
                    }
#line 836 "renderer.m"
                    break;
#line 836 "renderer.m"
                  case (MR_Integer) 1:
                    {
                      MR_Word renderer__V_9_50;
                      MR_Float renderer__Y_6_52;
                      MR_Word renderer__W_5_56 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Trans_32, (MR_Integer) 1)));
                      MR_Float renderer__V_79_79;
#line 18 "trans.opt"
                      MR_Word renderer___M_4_55 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Trans_32, (MR_Integer) 0)));
#line 39 "trans.opt"
                      MR_Float renderer___X_5_51;
#line 39 "trans.opt"
                      MR_Float renderer___Z_7_53;

#line 19 "trans.opt"
                      {
#line 19 "trans.opt"
                        renderer__V_9_50 = trans__transform_point_3_f_0(renderer__W_5_56, renderer__HeadVar__1_1);
                      }
#line 39 "trans.opt"
                      renderer___X_5_51 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_9_50, (MR_Integer) 0)));
#line 39 "trans.opt"
                      renderer__Y_6_52 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_9_50, (MR_Integer) 1)));
#line 39 "trans.opt"
                      renderer___Z_7_53 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_9_50, (MR_Integer) 2)));
#line 41 "trans.opt"
                      renderer__V_79_79 = (MR_Float) 0.00000000000000;
#line 42 "trans.opt"
                      renderer__succeeded = (renderer__Y_6_52 <= renderer__V_79_79);
                    }
#line 836 "renderer.m"
                    break;
#line 836 "renderer.m"
                }
#line 836 "renderer.m"
                break;
#line 836 "renderer.m"
              case (MR_Integer) 0:
                {
                  MR_Word renderer__Point_5_61;
                  MR_Float renderer__V_6_62;
                  MR_Word renderer__W_5_65 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Trans_32, (MR_Integer) 1)));
                  MR_Float renderer__Ax_3_68;
                  MR_Float renderer__Ay_4_69;
                  MR_Float renderer__Az_5_70;
                  MR_Float renderer__V_6_72;
                  MR_Float renderer__V_7_73;
                  MR_Float renderer__V_8_74;
                  MR_Float renderer__V_9_75;
                  MR_Float renderer__V_80_80;
#line 18 "trans.opt"
                  MR_Word renderer___M_4_64 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Trans_32, (MR_Integer) 0)));

#line 19 "trans.opt"
                  {
#line 19 "trans.opt"
                    renderer__Point_5_61 = trans__transform_point_3_f_0(renderer__W_5_65, renderer__HeadVar__1_1);
                  }
#line 25 "vector.opt"
                  renderer__Ax_3_68 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Point_5_61, (MR_Integer) 0)));
#line 25 "vector.opt"
                  renderer__Ay_4_69 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Point_5_61, (MR_Integer) 1)));
#line 25 "vector.opt"
                  renderer__Az_5_70 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Point_5_61, (MR_Integer) 2)));
#line 28 "vector.opt"
                  renderer__V_8_74 = (renderer__Ax_3_68 * renderer__Ax_3_68);
#line 30 "vector.opt"
                  renderer__V_9_75 = (renderer__Ay_4_69 * renderer__Ay_4_69);
#line 27 "vector.opt"
                  renderer__V_6_72 = (renderer__V_8_74 + renderer__V_9_75);
#line 32 "vector.opt"
                  renderer__V_7_73 = (renderer__Az_5_70 * renderer__Az_5_70);
#line 26 "vector.opt"
                  renderer__V_6_62 = (renderer__V_6_72 + renderer__V_7_73);
#line 36 "trans.opt"
                  renderer__V_80_80 = (MR_Float) 1.00000000000000;
#line 37 "trans.opt"
                  renderer__succeeded = (renderer__V_6_62 <= renderer__V_80_80);
                }
#line 836 "renderer.m"
                break;
#line 836 "renderer.m"
              case (MR_Integer) 1:
#line 841 "renderer.m"
                {
#line 841 "renderer.m"
                  return renderer__succeeded = trans__inside_cube_2_p_0(renderer__HeadVar__1_1, renderer__Trans_32);
                }
#line 836 "renderer.m"
                break;
#line 836 "renderer.m"
              case (MR_Integer) 2:
#line 843 "renderer.m"
                {
#line 843 "renderer.m"
                  return renderer__succeeded = trans__inside_cylinder_2_p_0(renderer__HeadVar__1_1, renderer__Trans_32);
                }
#line 836 "renderer.m"
                break;
#line 836 "renderer.m"
            }
          }
#line 787 "renderer.m"
          break;
#line 787 "renderer.m"
        case (MR_Integer) 1:
          {
            MR_Word renderer__Obj_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 0)));
            MR_Word renderer__Transformation1_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 1)));
            MR_Word renderer__V_14_14;
#line 791 "renderer.m"
            MR_Word renderer__V_13_13;

#line 791 "renderer.m"
            renderer__succeeded = (MR_tag((MR_Word) renderer__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 791 "renderer.m"
            if ((MR_tag((MR_Word) renderer__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 791 "renderer.m"
              renderer__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__3_3, (MR_Integer) 0)));
#line 795 "renderer.m"
            if (renderer__succeeded)
              {
                MR_Word renderer__V_15_15 = (MR_Word) renderer__Transformation1_11;
                MR_Word renderer__TypeInfo_28_28 = (MR_Word) (&space_partition__space_partition__type_ctor_info_invalid_transformation_0);

#line 794 "renderer.m"
                {
#line 794 "renderer.m"
                  mercury__exception__throw_1_p_0(renderer__TypeInfo_28_28, ((MR_Box) (renderer__V_15_15)));
                }
              }
#line 795 "renderer.m"
            else
              {
              }
#line 798 "renderer.m"
            {
#line 798 "renderer.m"
              renderer__V_14_14 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "yes"));
#line 798 "renderer.m"
              MR_hl_field(MR_mktag(1), renderer__V_14_14, 0) = ((MR_Box) (renderer__Transformation1_11));
#line 798 "renderer.m"
            }
#line 798 "renderer.m"
            {
#line 798 "renderer.m"
              /* direct tailcall eliminated */
#line 798 "renderer.m"
              {
#line 798 "renderer.m"
                MR_Word renderer__HeadVar__2__tmp_copy_2 = renderer__Obj_10;
#line 798 "renderer.m"
                MR_Word renderer__HeadVar__3__tmp_copy_3 = renderer__V_14_14;

#line 798 "renderer.m"
                renderer__HeadVar__2_2 = renderer__HeadVar__2__tmp_copy_2;
#line 798 "renderer.m"
                renderer__HeadVar__3_3 = renderer__HeadVar__3__tmp_copy_3;
#line 798 "renderer.m"
              }
#line 798 "renderer.m"
              goto loop_top;
#line 798 "renderer.m"
            }
          }
#line 787 "renderer.m"
          break;
#line 787 "renderer.m"
        case (MR_Integer) 2:
          {
            MR_Word renderer__Obj1_17 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__2_2, (MR_Integer) 0)));
            MR_Word renderer__Obj2_18 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__2_2, (MR_Integer) 1)));

#line 801 "renderer.m"
            {
#line 801 "renderer.m"
              renderer__succeeded = renderer__point_is_in_object_3_p_0(renderer__HeadVar__1_1, renderer__Obj1_17, renderer__HeadVar__3_3);
            }
#line 802 "renderer.m"
            if (!(renderer__succeeded))
#line 803 "renderer.m"
              {
#line 803 "renderer.m"
                /* direct tailcall eliminated */
#line 803 "renderer.m"
                {
#line 803 "renderer.m"
                  MR_Word renderer__HeadVar__2__tmp_copy_2 = renderer__Obj2_18;

#line 803 "renderer.m"
                  renderer__HeadVar__2_2 = renderer__HeadVar__2__tmp_copy_2;
#line 803 "renderer.m"
                }
#line 803 "renderer.m"
                goto loop_top;
#line 803 "renderer.m"
              }
          }
#line 787 "renderer.m"
          break;
#line 787 "renderer.m"
      }
#line 787 "renderer.m"
      return renderer__succeeded;
#line 787 "renderer.m"
    }
#line 787 "renderer.m"
  }
#line 784 "renderer.m"
}

#line 774 "renderer.m"
static MR_Word MR_CALL renderer__pixel_direction_2_6_f_0(
#line 774 "renderer.m"
  MR_Float renderer__HeadVar__1_1,
#line 774 "renderer.m"
  MR_Integer renderer__HeadVar__2_2,
#line 774 "renderer.m"
  MR_Integer renderer__HeadVar__3_3,
#line 774 "renderer.m"
  MR_Integer renderer__HeadVar__4_4,
#line 774 "renderer.m"
  MR_Integer renderer__HeadVar__5_5)
#line 774 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__HeadVar__6_6;
    MR_Float renderer__Delta_17;
    MR_Float renderer__XV_18;
    MR_Float renderer__YV_19;
    MR_Float renderer__ZV_20;
    MR_Float renderer__V_21_21;
    MR_Float renderer__V_22_22;
    MR_Float renderer__V_23_23;
    MR_Float renderer__V_24_24;
    MR_Float renderer__V_25_25;
    MR_Float renderer__V_26_26;
    MR_Float renderer__V_27_27;
    MR_Float renderer__V_28_28;
    MR_Float renderer__V_29_29;
    MR_Float renderer__V_30_30;
    MR_Float renderer__HalfWidth_35;
    MR_Float renderer__HalfHeight_36;
    MR_Float renderer__V_37_37;
    MR_Float renderer__V_40_40;
    MR_Float renderer__V_41_41 = (MR_Float) 0.500000000000000;
    MR_Float renderer__V_42_42;
    MR_Float renderer__V_4_45;
    MR_Float renderer__V_5_46;
    MR_Float renderer__V_6_47;
    MR_Float renderer__V_60_60;
    MR_Float renderer__V_61_61;
    MR_Float renderer__V_62_62;
    MR_Float renderer__V_78_78;
    MR_Float renderer__V_79_79;
    MR_Float renderer__V_81_81;
    MR_Float renderer__V_82_82;
    MR_Float renderer__V_83_83;
    MR_Float renderer__V_4_86;
    MR_Float renderer__V_5_87;
    MR_Float renderer__V_6_88;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL renderer__pixel_direction_2_6_f_0
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
renderer__V_6_47
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 80 "op.opt"
    renderer__V_4_45 = (renderer__HeadVar__1_1 * renderer__V_6_47);
#line 82 "op.opt"
    renderer__V_5_46 = (MR_Float) 180.000000000000;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL renderer__pixel_direction_2_6_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (renderer__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      renderer__succeeded = (renderer__V_5_46 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (renderer__succeeded)
      {
        MR_Word renderer__V_7_52;
        MR_String renderer__V_8_53 = (MR_String) "float:'/'";
        MR_Word renderer__TypeInfo_9_54;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        renderer__V_7_52 = (MR_Word) renderer__V_8_53;
        renderer__TypeInfo_9_54 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(renderer__TypeInfo_9_54, ((MR_Box) (renderer__V_7_52)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      renderer__V_42_42 = (renderer__V_4_45 / renderer__V_5_46);
#line 750 "renderer.m"
    renderer__V_40_40 = (renderer__V_41_41 * renderer__V_42_42);
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL renderer__pixel_direction_2_6_f_0
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Tan;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
renderer__V_40_40
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Tan = tan(X);

#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
renderer__HalfWidth_35
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Tan;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#define MR_PROC_LABEL renderer__pixel_direction_2_6_f_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	MR_Integer IntVal;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	MR_Float FloatVal;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	IntVal = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
renderer__HeadVar__3_3
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	FloatVal = IntVal;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
renderer__V_62_62
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
 = FloatVal;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
}
#line 755 "renderer.m"
    renderer__V_60_60 = (renderer__HalfWidth_35 * renderer__V_62_62);
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#define MR_PROC_LABEL renderer__pixel_direction_2_6_f_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	MR_Integer IntVal;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	MR_Float FloatVal;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	IntVal = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
renderer__HeadVar__2_2
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	FloatVal = IntVal;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
renderer__V_61_61
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
 = FloatVal;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL renderer__pixel_direction_2_6_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (renderer__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      renderer__succeeded = (renderer__V_61_61 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (renderer__succeeded)
      {
        MR_Word renderer__V_7_74;
        MR_String renderer__V_8_75 = (MR_String) "float:'/'";
        MR_Word renderer__TypeInfo_9_76;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        renderer__V_7_74 = (MR_Word) renderer__V_8_75;
        renderer__TypeInfo_9_76 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(renderer__TypeInfo_9_76, ((MR_Box) (renderer__V_7_74)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      renderer__HalfHeight_36 = (renderer__V_60_60 / renderer__V_61_61);
#line 761 "renderer.m"
    renderer__V_37_37 = (((MR_Float) 0.00000000000000) - renderer__HalfWidth_35);
#line 745 "renderer.m"
    renderer__V_78_78 = (MR_Float) 2.00000000000000;
#line 750 "renderer.m"
    renderer__V_82_82 = (MR_Float) 0.500000000000000;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL renderer__pixel_direction_2_6_f_0
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
renderer__V_6_88
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 80 "op.opt"
    renderer__V_4_86 = (renderer__HeadVar__1_1 * renderer__V_6_88);
#line 82 "op.opt"
    renderer__V_5_87 = (MR_Float) 180.000000000000;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL renderer__pixel_direction_2_6_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (renderer__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      renderer__succeeded = (renderer__V_5_87 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (renderer__succeeded)
      {
        MR_Word renderer__V_7_93;
        MR_String renderer__V_8_94 = (MR_String) "float:'/'";
        MR_Word renderer__TypeInfo_9_95;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        renderer__V_7_93 = (MR_Word) renderer__V_8_94;
        renderer__TypeInfo_9_95 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(renderer__TypeInfo_9_95, ((MR_Box) (renderer__V_7_93)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      renderer__V_83_83 = (renderer__V_4_86 / renderer__V_5_87);
#line 750 "renderer.m"
    renderer__V_81_81 = (renderer__V_82_82 * renderer__V_83_83);
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL renderer__pixel_direction_2_6_f_0
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Tan;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
renderer__V_81_81
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Tan = tan(X);

#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
renderer__V_79_79
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Tan;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 745 "renderer.m"
    renderer__V_29_29 = (renderer__V_78_78 * renderer__V_79_79);
#line 778 "renderer.m"
    {
#line 778 "renderer.m"
      renderer__V_30_30 = mercury__float__float_2_f_0(renderer__HeadVar__2_2);
    }
#line 778 "renderer.m"
    {
#line 778 "renderer.m"
      renderer__Delta_17 = mercury__float__f_slash_3_f_0(renderer__V_29_29, renderer__V_30_30);
    }
#line 779 "renderer.m"
    {
#line 779 "renderer.m"
      renderer__V_27_27 = mercury__float__float_2_f_0(renderer__HeadVar__4_4);
    }
#line 779 "renderer.m"
    renderer__V_28_28 = (MR_Float) 0.500000000000000;
#line 779 "renderer.m"
    renderer__V_26_26 = (renderer__V_27_27 + renderer__V_28_28);
#line 779 "renderer.m"
    renderer__V_25_25 = (renderer__V_26_26 * renderer__Delta_17);
#line 779 "renderer.m"
    renderer__XV_18 = (renderer__V_37_37 + renderer__V_25_25);
#line 780 "renderer.m"
    {
#line 780 "renderer.m"
      renderer__V_23_23 = mercury__float__float_2_f_0(renderer__HeadVar__5_5);
    }
#line 780 "renderer.m"
    renderer__V_24_24 = (MR_Float) 0.500000000000000;
#line 780 "renderer.m"
    renderer__V_22_22 = (renderer__V_23_23 + renderer__V_24_24);
#line 780 "renderer.m"
    renderer__V_21_21 = (renderer__V_22_22 * renderer__Delta_17);
#line 780 "renderer.m"
    renderer__YV_19 = (renderer__HalfHeight_36 - renderer__V_21_21);
#line 781 "renderer.m"
    renderer__ZV_20 = (MR_Float) 1.00000000000000;
#line 782 "renderer.m"
    {
#line 782 "renderer.m"
      renderer__HeadVar__6_6 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 782 "renderer.m"
      MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, 0) = MR_box_float(renderer__XV_18);
#line 782 "renderer.m"
      MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, 1) = MR_box_float(renderer__YV_19);
#line 782 "renderer.m"
      MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, 2) = MR_box_float(renderer__ZV_20);
#line 782 "renderer.m"
    }
    return renderer__HeadVar__6_6;
  }
#line 774 "renderer.m"
}

#line 728 "renderer.m"
static MR_Word MR_CALL renderer__clamp_2_f_0(
#line 728 "renderer.m"
  MR_Word renderer__HeadVar__1_1)
#line 728 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__HeadVar__2_2;
    MR_Float renderer__R0_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float renderer__G0_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float renderer__B0_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float renderer__R_6;
    MR_Float renderer__G_7;
    MR_Float renderer__B_8;

#line 730 "renderer.m"
    {
#line 730 "renderer.m"
      renderer__R_6 = op__op_clampf_2_f_0(renderer__R0_3);
    }
#line 731 "renderer.m"
    {
#line 731 "renderer.m"
      renderer__G_7 = op__op_clampf_2_f_0(renderer__G0_4);
    }
#line 732 "renderer.m"
    {
#line 732 "renderer.m"
      renderer__B_8 = op__op_clampf_2_f_0(renderer__B0_5);
    }
#line 729 "renderer.m"
    {
#line 729 "renderer.m"
      renderer__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 729 "renderer.m"
      MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, 0) = MR_box_float(renderer__R_6);
#line 729 "renderer.m"
      MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, 1) = MR_box_float(renderer__G_7);
#line 729 "renderer.m"
      MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, 2) = MR_box_float(renderer__B_8);
#line 729 "renderer.m"
    }
    return renderer__HeadVar__2_2;
  }
#line 728 "renderer.m"
}

#line 725 "renderer.m"
static MR_Word MR_CALL renderer__f_times_3_f_0(
#line 725 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 725 "renderer.m"
  MR_Word renderer__HeadVar__2_2)
#line 725 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__HeadVar__3_3;
    MR_Float renderer__AX_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float renderer__AY_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float renderer__AZ_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float renderer__BX_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float renderer__BY_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float renderer__BZ_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float renderer__V_10_10 = (renderer__AX_4 * renderer__BX_7);
    MR_Float renderer__V_11_11 = (renderer__AY_5 * renderer__BY_8);
    MR_Float renderer__V_12_12 = (renderer__AZ_6 * renderer__BZ_9);

#line 726 "renderer.m"
    {
#line 726 "renderer.m"
      renderer__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 726 "renderer.m"
      MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, 0) = MR_box_float(renderer__V_10_10);
#line 726 "renderer.m"
      MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, 1) = MR_box_float(renderer__V_11_11);
#line 726 "renderer.m"
      MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, 2) = MR_box_float(renderer__V_12_12);
#line 726 "renderer.m"
    }
    return renderer__HeadVar__3_3;
  }
#line 725 "renderer.m"
}

#line 713 "renderer.m"
static MR_Float MR_CALL renderer__distance_attenuation_3_f_0(
#line 713 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 713 "renderer.m"
  MR_Word renderer__HeadVar__2_2)
#line 713 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Float renderer__HeadVar__3_3;
    MR_Float renderer__D2_6;
    MR_Float renderer__V_8_8 = (MR_Float) 100.000000000000;
    MR_Float renderer__V_9_9;
    MR_Float renderer__V_10_10 = (MR_Float) 99.0000000000000;
    MR_Float renderer__Ax_4_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float renderer__Ay_5_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float renderer__Az_6_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float renderer__Bx_7_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float renderer__By_8_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float renderer__Bz_9_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float renderer__V_10_17 = (renderer__Ax_4_11 - renderer__Bx_7_14);
    MR_Float renderer__V_11_18 = (renderer__Ay_5_12 - renderer__By_8_15);
    MR_Float renderer__V_12_19 = (renderer__Az_6_13 - renderer__Bz_9_16);
    MR_Float renderer__V_6_24;
    MR_Float renderer__V_7_25;
    MR_Float renderer__V_8_26 = (renderer__V_10_17 * renderer__V_10_17);
    MR_Float renderer__V_9_27 = (renderer__V_11_18 * renderer__V_11_18);

#line 27 "vector.opt"
    renderer__V_6_24 = (renderer__V_8_26 + renderer__V_9_27);
#line 32 "vector.opt"
    renderer__V_7_25 = (renderer__V_12_19 * renderer__V_12_19);
#line 26 "vector.opt"
    renderer__D2_6 = (renderer__V_6_24 + renderer__V_7_25);
#line 714 "renderer.m"
    renderer__V_9_9 = (renderer__V_10_10 + renderer__D2_6);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL renderer__distance_attenuation_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (renderer__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      renderer__succeeded = (renderer__V_9_9 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (renderer__succeeded)
      {
        MR_Word renderer__V_7_34;
        MR_String renderer__V_8_35 = (MR_String) "float:'/'";
        MR_Word renderer__TypeInfo_9_36;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        renderer__V_7_34 = (MR_Word) renderer__V_8_35;
        renderer__TypeInfo_9_36 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(renderer__TypeInfo_9_36, ((MR_Box) (renderer__V_7_34)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      renderer__HeadVar__3_3 = (renderer__V_8_8 / renderer__V_9_9);
    return renderer__HeadVar__3_3;
  }
#line 713 "renderer.m"
}

#line 696 "renderer.m"
static MR_Word MR_CALL renderer__light_intensity_3_f_0(
#line 696 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 696 "renderer.m"
  MR_Word renderer__HeadVar__2_2)
#line 696 "renderer.m"
{
#line 697 "renderer.m"
  {
#line 697 "renderer.m"
    bool renderer__succeeded;
#line 697 "renderer.m"
    MR_Word renderer__HeadVar__3_3;

#line 697 "renderer.m"
#line 697 "renderer.m"
    switch (MR_tag((MR_Word) renderer__HeadVar__1_1)) {
#line 697 "renderer.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 697 "renderer.m"
      case (MR_Integer) 0:
#line 697 "renderer.m"
        {
#line 697 "renderer.m"
          MR_Word renderer___Dir_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));

#line 697 "renderer.m"
          renderer__HeadVar__3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 697 "renderer.m"
        }
#line 697 "renderer.m"
        break;
#line 697 "renderer.m"
      case (MR_Integer) 1:
        {
          MR_Word renderer__Pos_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word renderer__Intensity_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__1_1, (MR_Integer) 1)));
          MR_Float renderer__V_10_10;
          MR_Float renderer__D2_29;
          MR_Float renderer__V_31_31 = (MR_Float) 100.000000000000;
          MR_Float renderer__V_32_32;
          MR_Float renderer__V_33_33 = (MR_Float) 99.0000000000000;
          MR_Float renderer__Ax_4_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 0)));
          MR_Float renderer__Ay_5_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 1)));
          MR_Float renderer__Az_6_36 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 2)));
          MR_Float renderer__Bx_7_37 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_7, (MR_Integer) 0)));
          MR_Float renderer__By_8_38 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_7, (MR_Integer) 1)));
          MR_Float renderer__Bz_9_39 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_7, (MR_Integer) 2)));
          MR_Float renderer__V_10_40 = (renderer__Ax_4_34 - renderer__Bx_7_37);
          MR_Float renderer__V_11_41 = (renderer__Ay_5_35 - renderer__By_8_38);
          MR_Float renderer__V_12_42 = (renderer__Az_6_36 - renderer__Bz_9_39);
          MR_Float renderer__V_6_47;
          MR_Float renderer__V_7_48;
          MR_Float renderer__V_8_49 = (renderer__V_10_40 * renderer__V_10_40);
          MR_Float renderer__V_9_50 = (renderer__V_11_41 * renderer__V_11_41);
          MR_Float renderer__Ax_5_61;
          MR_Float renderer__Ay_6_62;
          MR_Float renderer__Az_7_63;
          MR_Float renderer__V_8_64;
          MR_Float renderer__V_9_65;
          MR_Float renderer__V_10_66;

#line 27 "vector.opt"
          renderer__V_6_47 = (renderer__V_8_49 + renderer__V_9_50);
#line 32 "vector.opt"
          renderer__V_7_48 = (renderer__V_12_42 * renderer__V_12_42);
#line 26 "vector.opt"
          renderer__D2_29 = (renderer__V_6_47 + renderer__V_7_48);
#line 714 "renderer.m"
          renderer__V_32_32 = (renderer__V_33_33 + renderer__D2_29);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL renderer__light_intensity_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
          if (renderer__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            renderer__succeeded = (renderer__V_32_32 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          if (renderer__succeeded)
            {
              MR_Word renderer__V_7_57;
              MR_String renderer__V_8_58 = (MR_String) "float:'/'";
              MR_Word renderer__TypeInfo_9_59;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              renderer__V_7_57 = (MR_Word) renderer__V_8_58;
              renderer__TypeInfo_9_59 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
                mercury__exception__throw_1_p_0(renderer__TypeInfo_9_59, ((MR_Box) (renderer__V_7_57)));
              }
            }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            renderer__V_10_10 = (renderer__V_31_31 / renderer__V_32_32);
#line 41 "vector.opt"
          renderer__Ax_5_61 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Intensity_8, (MR_Integer) 0)));
#line 41 "vector.opt"
          renderer__Ay_6_62 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Intensity_8, (MR_Integer) 1)));
#line 41 "vector.opt"
          renderer__Az_7_63 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Intensity_8, (MR_Integer) 2)));
#line 42 "vector.opt"
          renderer__V_8_64 = (renderer__V_10_10 * renderer__Ax_5_61);
#line 43 "vector.opt"
          renderer__V_9_65 = (renderer__V_10_10 * renderer__Ay_6_62);
#line 44 "vector.opt"
          renderer__V_10_66 = (renderer__V_10_10 * renderer__Az_7_63);
#line 41 "vector.opt"
          {
#line 41 "vector.opt"
            renderer__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 41 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, 0) = MR_box_float(renderer__V_8_64);
#line 41 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, 1) = MR_box_float(renderer__V_9_65);
#line 41 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, 2) = MR_box_float(renderer__V_10_66);
#line 41 "vector.opt"
          }
        }
#line 697 "renderer.m"
        break;
#line 697 "renderer.m"
      case (MR_Integer) 2:
        {
          MR_Word renderer__Pos_11 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word renderer__At_12 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 1)));
          MR_Word renderer__Intensity_13 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 2)));
          MR_Float renderer__Cutoff_14 = MR_unbox_float((MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 3)));
          MR_Float renderer__Exp_15 = MR_unbox_float((MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 4)));
          MR_Float renderer__DistanceAttenuation_17;
          MR_Float renderer__AngleAttenuation_18;
          MR_Float renderer__AngleCos_19;
          MR_Word renderer__V_22_22;
          MR_Word renderer__V_23_23;
          MR_Word renderer__V_24_24;
          MR_Word renderer__V_25_25;
          MR_Float renderer__V_26_26;
          MR_Float renderer__Ax_4_67;
          MR_Float renderer__Ay_5_68;
          MR_Float renderer__Az_6_69;
          MR_Float renderer__Bx_7_70;
          MR_Float renderer__By_8_71;
          MR_Float renderer__Bz_9_72;
          MR_Float renderer__V_10_73;
          MR_Float renderer__V_11_74;
          MR_Float renderer__V_12_75;
          MR_Float renderer__Ax_4_76;
          MR_Float renderer__Ay_5_77;
          MR_Float renderer__Az_6_78;
          MR_Float renderer__Bx_7_79;
          MR_Float renderer__By_8_80;
          MR_Float renderer__Bz_9_81;
          MR_Float renderer__V_10_82;
          MR_Float renderer__V_11_83;
          MR_Float renderer__V_12_84;
          MR_Float renderer__Ax_4_85;
          MR_Float renderer__Ay_5_86;
          MR_Float renderer__Az_6_87;
          MR_Float renderer__Bx_7_88;
          MR_Float renderer__By_8_89;
          MR_Float renderer__Bz_9_90;
          MR_Float renderer__V_10_92;
          MR_Float renderer__V_11_93;
          MR_Float renderer__V_12_94;
          MR_Float renderer__V_13_95;
          MR_Float renderer__V_20_20;
          MR_Float renderer__V_21_21;

#line 703 "renderer.m"
          {
#line 703 "renderer.m"
            renderer__DistanceAttenuation_17 = renderer__distance_attenuation_3_f_0(renderer__Pos_11, renderer__HeadVar__2_2);
          }
#line 7 "vector.opt"
          renderer__Ax_4_67 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__At_12, (MR_Integer) 0)));
#line 7 "vector.opt"
          renderer__Ay_5_68 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__At_12, (MR_Integer) 1)));
#line 7 "vector.opt"
          renderer__Az_6_69 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__At_12, (MR_Integer) 2)));
#line 7 "vector.opt"
          renderer__Bx_7_70 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_11, (MR_Integer) 0)));
#line 7 "vector.opt"
          renderer__By_8_71 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_11, (MR_Integer) 1)));
#line 7 "vector.opt"
          renderer__Bz_9_72 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_11, (MR_Integer) 2)));
#line 8 "vector.opt"
          renderer__V_10_73 = (renderer__Ax_4_67 - renderer__Bx_7_70);
#line 9 "vector.opt"
          renderer__V_11_74 = (renderer__Ay_5_68 - renderer__By_8_71);
#line 10 "vector.opt"
          renderer__V_12_75 = (renderer__Az_6_69 - renderer__Bz_9_72);
#line 7 "vector.opt"
          {
#line 7 "vector.opt"
            renderer__V_24_24 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_24_24, 0) = MR_box_float(renderer__V_10_73);
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_24_24, 1) = MR_box_float(renderer__V_11_74);
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_24_24, 2) = MR_box_float(renderer__V_12_75);
#line 7 "vector.opt"
          }
#line 704 "renderer.m"
          {
#line 704 "renderer.m"
            renderer__V_22_22 = vector__unit_2_f_0(renderer__V_24_24);
          }
#line 7 "vector.opt"
          renderer__Ax_4_76 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 0)));
#line 7 "vector.opt"
          renderer__Ay_5_77 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 1)));
#line 7 "vector.opt"
          renderer__Az_6_78 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 2)));
#line 7 "vector.opt"
          renderer__Bx_7_79 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_11, (MR_Integer) 0)));
#line 7 "vector.opt"
          renderer__By_8_80 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_11, (MR_Integer) 1)));
#line 7 "vector.opt"
          renderer__Bz_9_81 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_11, (MR_Integer) 2)));
#line 8 "vector.opt"
          renderer__V_10_82 = (renderer__Ax_4_76 - renderer__Bx_7_79);
#line 9 "vector.opt"
          renderer__V_11_83 = (renderer__Ay_5_77 - renderer__By_8_80);
#line 10 "vector.opt"
          renderer__V_12_84 = (renderer__Az_6_78 - renderer__Bz_9_81);
#line 7 "vector.opt"
          {
#line 7 "vector.opt"
            renderer__V_25_25 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_25_25, 0) = MR_box_float(renderer__V_10_82);
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_25_25, 1) = MR_box_float(renderer__V_11_83);
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_25_25, 2) = MR_box_float(renderer__V_12_84);
#line 7 "vector.opt"
          }
#line 704 "renderer.m"
          {
#line 704 "renderer.m"
            renderer__V_23_23 = vector__unit_2_f_0(renderer__V_25_25);
          }
#line 15 "vector.opt"
          renderer__Ax_4_85 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_22_22, (MR_Integer) 0)));
#line 15 "vector.opt"
          renderer__Ay_5_86 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_22_22, (MR_Integer) 1)));
#line 15 "vector.opt"
          renderer__Az_6_87 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_22_22, (MR_Integer) 2)));
#line 15 "vector.opt"
          renderer__Bx_7_88 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_23_23, (MR_Integer) 0)));
#line 15 "vector.opt"
          renderer__By_8_89 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_23_23, (MR_Integer) 1)));
#line 15 "vector.opt"
          renderer__Bz_9_90 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_23_23, (MR_Integer) 2)));
#line 18 "vector.opt"
          renderer__V_12_94 = (renderer__Ax_4_85 * renderer__Bx_7_88);
#line 19 "vector.opt"
          renderer__V_13_95 = (renderer__Ay_5_86 * renderer__By_8_89);
#line 17 "vector.opt"
          renderer__V_10_92 = (renderer__V_12_94 + renderer__V_13_95);
#line 20 "vector.opt"
          renderer__V_11_93 = (renderer__Az_6_87 * renderer__Bz_9_90);
#line 16 "vector.opt"
          renderer__AngleCos_19 = (renderer__V_10_92 + renderer__V_11_93);
#line 706 "renderer.m"
          {
#line 706 "renderer.m"
            renderer__V_21_21 = op__radians_2_f_0(renderer__Cutoff_14);
          }
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL renderer__light_intensity_3_f_0
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Cos;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
renderer__V_21_21
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
renderer__V_20_20
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Cos;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 706 "renderer.m"
          renderer__succeeded = (renderer__AngleCos_19 > renderer__V_20_20);
#line 709 "renderer.m"
          if (renderer__succeeded)
#line 708 "renderer.m"
            {
#line 708 "renderer.m"
              renderer__AngleAttenuation_18 = mercury__math__pow_3_f_0(renderer__AngleCos_19, renderer__Exp_15);
            }
#line 709 "renderer.m"
          else
#line 710 "renderer.m"
            renderer__AngleAttenuation_18 = (MR_Float) 0.00000000000000;
#line 701 "renderer.m"
          renderer__V_26_26 = (renderer__DistanceAttenuation_17 * renderer__AngleAttenuation_18);
#line 701 "renderer.m"
          {
#line 701 "renderer.m"
            return renderer__HeadVar__3_3 = vector__scale_3_f_0(renderer__V_26_26, renderer__Intensity_13);
          }
        }
#line 697 "renderer.m"
        break;
#line 697 "renderer.m"
    }
#line 697 "renderer.m"
    return renderer__HeadVar__3_3;
#line 697 "renderer.m"
  }
#line 696 "renderer.m"
}
#line 692 "renderer.m"
static /* final */ const MR_Box renderer__const_25_0_1_V_6_6[1] = {
		((MR_Box) ((MR_String) "incorrect type for element of light array"))};

#line 687 "renderer.m"
static MR_Word MR_CALL renderer__light_value_to_light_2_f_0(
#line 687 "renderer.m"
  MR_Word renderer__HeadVar__1_1)
#line 687 "renderer.m"
{
#line 691 "renderer.m"
  {
#line 691 "renderer.m"
    bool renderer__succeeded = ((MR_tag((MR_Word) renderer__HeadVar__1_1) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__1_1, (MR_Integer) 0))) == (MR_Integer) 5));
#line 691 "renderer.m"
    MR_Word renderer__HeadVar__2_2;
#line 691 "renderer.m"
    MR_Word renderer__Light0_5;

#line 689 "renderer.m"
    if (((MR_tag((MR_Word) renderer__HeadVar__1_1) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__1_1, (MR_Integer) 0))) == (MR_Integer) 5)))
#line 689 "renderer.m"
      renderer__Light0_5 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 691 "renderer.m"
    if (renderer__succeeded)
#line 690 "renderer.m"
      renderer__HeadVar__2_2 = renderer__Light0_5;
#line 691 "renderer.m"
    else
      {
        MR_Word renderer__V_6_6 = (MR_Word) &renderer__const_25_0_1_V_6_6;
        MR_String renderer__V_7_7 = (MR_String) "incorrect type for element of light array";
        MR_Word renderer__TypeInfo_8_8 = (MR_Word) (&eval__eval__type_ctor_info_program_error_0);

#line 692 "renderer.m"
        {
#line 692 "renderer.m"
          mercury__exception__throw_1_p_0(renderer__TypeInfo_8_8, ((MR_Box) (renderer__V_6_6)));
        }
      }
#line 691 "renderer.m"
    return renderer__HeadVar__2_2;
#line 691 "renderer.m"
  }
#line 687 "renderer.m"
}

#line 674 "renderer.m"
static bool MR_CALL renderer__light_is_behind_point_3_p_0(
#line 674 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 674 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 674 "renderer.m"
  MR_Word renderer__HeadVar__3_3)
#line 674 "renderer.m"
{
#line 676 "renderer.m"
  {
#line 676 "renderer.m"
    bool renderer__succeeded;

#line 676 "renderer.m"
#line 676 "renderer.m"
    switch (MR_tag((MR_Word) renderer__HeadVar__2_2)) {
#line 676 "renderer.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 676 "renderer.m"
      case (MR_Integer) 0:
        {
          MR_Word renderer__Dir_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 0)));
          MR_Float renderer__V_8_8;
          MR_Float renderer__Ax_4_30 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
          MR_Float renderer__Ay_5_31 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
          MR_Float renderer__Az_6_32 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
          MR_Float renderer__Bx_7_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 0)));
          MR_Float renderer__By_8_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 1)));
          MR_Float renderer__Bz_9_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 2)));
          MR_Float renderer__V_10_36 = (renderer__Ax_4_30 - renderer__Bx_7_33);
          MR_Float renderer__V_11_37 = (renderer__Ay_5_31 - renderer__By_8_34);
          MR_Float renderer__V_12_38 = (renderer__Az_6_32 - renderer__Bz_9_35);
          MR_Float renderer__Bx_7_42 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Dir_5, (MR_Integer) 0)));
          MR_Float renderer__By_8_43 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Dir_5, (MR_Integer) 1)));
          MR_Float renderer__Bz_9_44 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Dir_5, (MR_Integer) 2)));
          MR_Float renderer__V_10_46;
          MR_Float renderer__V_11_47;
          MR_Float renderer__V_12_48 = (renderer__V_10_36 * renderer__Bx_7_42);
          MR_Float renderer__V_13_49 = (renderer__V_11_37 * renderer__By_8_43);
          MR_Float renderer__V_97_97;
#line 676 "renderer.m"
          MR_Word renderer__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 1)));

#line 17 "vector.opt"
          renderer__V_10_46 = (renderer__V_12_48 + renderer__V_13_49);
#line 20 "vector.opt"
          renderer__V_11_47 = (renderer__V_12_38 * renderer__Bz_9_44);
#line 16 "vector.opt"
          renderer__V_8_8 = (renderer__V_10_46 + renderer__V_11_47);
#line 679 "renderer.m"
          renderer__V_97_97 = (MR_Float) 0.00000000000000;
#line 679 "renderer.m"
          renderer__succeeded = (renderer__V_8_8 > renderer__V_97_97);
        }
#line 676 "renderer.m"
        break;
#line 676 "renderer.m"
      case (MR_Integer) 1:
        {
          MR_Word renderer__LightPos_12 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 0)));
          MR_Float renderer__V_15_15;
          MR_Float renderer__Ax_4_50 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__LightPos_12, (MR_Integer) 0)));
          MR_Float renderer__Ay_5_51 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__LightPos_12, (MR_Integer) 1)));
          MR_Float renderer__Az_6_52 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__LightPos_12, (MR_Integer) 2)));
          MR_Float renderer__Bx_7_53 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 0)));
          MR_Float renderer__By_8_54 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 1)));
          MR_Float renderer__Bz_9_55 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 2)));
          MR_Float renderer__V_10_56 = (renderer__Ax_4_50 - renderer__Bx_7_53);
          MR_Float renderer__V_11_57 = (renderer__Ay_5_51 - renderer__By_8_54);
          MR_Float renderer__V_12_58 = (renderer__Az_6_52 - renderer__Bz_9_55);
          MR_Float renderer__Ax_4_59 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
          MR_Float renderer__Ay_5_60 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
          MR_Float renderer__Az_6_61 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
          MR_Float renderer__V_10_65 = (renderer__Ax_4_59 - renderer__Bx_7_53);
          MR_Float renderer__V_11_66 = (renderer__Ay_5_60 - renderer__By_8_54);
          MR_Float renderer__V_12_67 = (renderer__Az_6_61 - renderer__Bz_9_55);
          MR_Float renderer__V_10_75;
          MR_Float renderer__V_11_76;
          MR_Float renderer__V_12_77 = (renderer__V_10_56 * renderer__V_10_65);
          MR_Float renderer__V_13_78 = (renderer__V_11_57 * renderer__V_11_66);
          MR_Float renderer__V_98_98;
#line 680 "renderer.m"
          MR_Word renderer__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 1)));

#line 17 "vector.opt"
          renderer__V_10_75 = (renderer__V_12_77 + renderer__V_13_78);
#line 20 "vector.opt"
          renderer__V_11_76 = (renderer__V_12_58 * renderer__V_12_67);
#line 16 "vector.opt"
          renderer__V_15_15 = (renderer__V_10_75 + renderer__V_11_76);
#line 682 "renderer.m"
          renderer__V_98_98 = (MR_Float) 0.00000000000000;
#line 682 "renderer.m"
          renderer__succeeded = (renderer__V_15_15 < renderer__V_98_98);
        }
#line 676 "renderer.m"
        break;
#line 676 "renderer.m"
      case (MR_Integer) 2:
        {
          MR_Word renderer__LightPos_20 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__2_2, (MR_Integer) 0)));
          MR_Float renderer__V_26_26;
          MR_Word renderer__V_28_28;
          MR_Word renderer__V_29_29;
          MR_Float renderer__Ax_4_79 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__LightPos_20, (MR_Integer) 0)));
          MR_Float renderer__Ay_5_80 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__LightPos_20, (MR_Integer) 1)));
          MR_Float renderer__Az_6_81 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__LightPos_20, (MR_Integer) 2)));
          MR_Float renderer__Bx_7_82 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 0)));
          MR_Float renderer__By_8_83 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 1)));
          MR_Float renderer__Bz_9_84 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, (MR_Integer) 2)));
          MR_Float renderer__V_10_85 = (renderer__Ax_4_79 - renderer__Bx_7_82);
          MR_Float renderer__V_11_86 = (renderer__Ay_5_80 - renderer__By_8_83);
          MR_Float renderer__V_12_87 = (renderer__Az_6_81 - renderer__Bz_9_84);
          MR_Float renderer__Ax_4_88 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
          MR_Float renderer__Ay_5_89 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
          MR_Float renderer__Az_6_90 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
          MR_Float renderer__V_10_94 = (renderer__Ax_4_88 - renderer__Bx_7_82);
          MR_Float renderer__V_11_95 = (renderer__Ay_5_89 - renderer__By_8_83);
          MR_Float renderer__V_12_96 = (renderer__Az_6_90 - renderer__Bz_9_84);
          MR_Float renderer__V_99_99;
#line 683 "renderer.m"
          MR_Word renderer__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__2_2, (MR_Integer) 1)));
#line 683 "renderer.m"
          MR_Word renderer__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__2_2, (MR_Integer) 2)));
#line 683 "renderer.m"
          MR_Float renderer__V_23_23 = MR_unbox_float((MR_hl_field(MR_mktag(2), renderer__HeadVar__2_2, (MR_Integer) 3)));
#line 683 "renderer.m"
          MR_Float renderer__V_24_24 = MR_unbox_float((MR_hl_field(MR_mktag(2), renderer__HeadVar__2_2, (MR_Integer) 4)));

#line 7 "vector.opt"
          {
#line 7 "vector.opt"
            renderer__V_28_28 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_28_28, 0) = MR_box_float(renderer__V_10_85);
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_28_28, 1) = MR_box_float(renderer__V_11_86);
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_28_28, 2) = MR_box_float(renderer__V_12_87);
#line 7 "vector.opt"
          }
#line 7 "vector.opt"
          {
#line 7 "vector.opt"
            renderer__V_29_29 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_29_29, 0) = MR_box_float(renderer__V_10_94);
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_29_29, 1) = MR_box_float(renderer__V_11_95);
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_29_29, 2) = MR_box_float(renderer__V_12_96);
#line 7 "vector.opt"
          }
#line 685 "renderer.m"
          {
#line 685 "renderer.m"
            renderer__V_26_26 = vector__dot_3_f_0(renderer__V_28_28, renderer__V_29_29);
          }
#line 685 "renderer.m"
          renderer__V_99_99 = (MR_Float) 0.00000000000000;
#line 685 "renderer.m"
          renderer__succeeded = (renderer__V_26_26 < renderer__V_99_99);
        }
#line 676 "renderer.m"
        break;
#line 676 "renderer.m"
    }
#line 676 "renderer.m"
    return renderer__succeeded;
#line 676 "renderer.m"
  }
#line 674 "renderer.m"
}
#line 692 "renderer.m"
static /* final */ const MR_Box renderer__const_23_0_1_V_20_20[1] = {
		((MR_Box) ((MR_String) "incorrect type for element of light array"))};

#line 660 "renderer.m"
static bool MR_CALL renderer__position_not_in_shadow_4_p_0(
#line 660 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 660 "renderer.m"
  MR_Integer renderer__HeadVar__2_2,
#line 660 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 660 "renderer.m"
  MR_Word renderer__HeadVar__4_4)
#line 660 "renderer.m"
{
  {
    bool renderer__succeeded = ((MR_tag((MR_Word) renderer__HeadVar__4_4) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__4_4, (MR_Integer) 0))) == (MR_Integer) 5));
    MR_Word renderer__Light_9;
    MR_Word renderer__Lj_10;
#line 691 "renderer.m"
    MR_Word renderer__Light0_19;
    MR_Word renderer__Intersection_16;
    MR_Word renderer__Intersections_32;
    MR_Word renderer__MaybeIntersection_33;
    MR_Word renderer__Intersection_35;
    MR_Word renderer__V_36_36;
    MR_Word renderer__V_37_37;
    MR_Word renderer__Partition_45;
    MR_Word renderer__OtherObjects_46;
    MR_Word renderer__IntersectionResult1_50;
    MR_Word renderer__IntersectionResult2_51;
    MR_Word renderer__V_52_52;
#line 195 "renderer.m"
    MR_Array renderer__V_38_38;
#line 195 "renderer.m"
    MR_Word renderer__V_39_39;
#line 195 "renderer.m"
    MR_String renderer__V_40_40;
#line 195 "renderer.m"
    MR_Integer renderer__V_41_41;
#line 195 "renderer.m"
    MR_Integer renderer__V_42_42;
#line 195 "renderer.m"
    MR_Float renderer__V_43_43;
#line 195 "renderer.m"
    MR_Integer renderer__V_44_44;
#line 199 "renderer.m"
    MR_Float renderer__V_34_34;
#line 202 "renderer.m"
    MR_Integer renderer___Id_12;
#line 202 "renderer.m"
    MR_Word renderer__V_13_13;
#line 202 "renderer.m"
    MR_Word renderer__V_14_14;
#line 202 "renderer.m"
    MR_Word renderer__V_15_15;

#line 689 "renderer.m"
    if (((MR_tag((MR_Word) renderer__HeadVar__4_4) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__4_4, (MR_Integer) 0))) == (MR_Integer) 5)))
#line 689 "renderer.m"
      renderer__Light0_19 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__4_4, (MR_Integer) 1)));
#line 691 "renderer.m"
    if (renderer__succeeded)
#line 690 "renderer.m"
      renderer__Light_9 = renderer__Light0_19;
#line 691 "renderer.m"
    else
      {
        MR_Word renderer__V_20_20 = (MR_Word) &renderer__const_23_0_1_V_20_20;
        MR_String renderer__V_21_21 = (MR_String) "incorrect type for element of light array";
        MR_Word renderer__TypeInfo_8_22 = (MR_Word) (&eval__eval__type_ctor_info_program_error_0);

#line 692 "renderer.m"
        {
#line 692 "renderer.m"
          mercury__exception__throw_1_p_0(renderer__TypeInfo_8_22, ((MR_Box) (renderer__V_20_20)));
        }
      }
#line 664 "renderer.m"
    {
#line 664 "renderer.m"
      renderer__Lj_10 = renderer__light_unit_vector_3_f_0(renderer__Light_9, renderer__HeadVar__3_3);
    }
#line 195 "renderer.m"
    renderer__V_39_39 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 195 "renderer.m"
    renderer__V_38_38 = ((MR_Array) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 195 "renderer.m"
    renderer__V_37_37 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
#line 195 "renderer.m"
    renderer__V_44_44 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 3)));
#line 195 "renderer.m"
    renderer__V_43_43 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 4)));
#line 195 "renderer.m"
    renderer__V_42_42 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 5)));
#line 195 "renderer.m"
    renderer__V_41_41 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 6)));
#line 195 "renderer.m"
    renderer__V_40_40 = ((MR_String) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 7)));
#line 227 "renderer.m"
    renderer__Partition_45 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_37_37, (MR_Integer) 0)));
#line 227 "renderer.m"
    renderer__OtherObjects_46 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_37_37, (MR_Integer) 1)));
#line 228 "renderer.m"
    {
#line 228 "renderer.m"
      space_partition__traverse_space_tree_4_p_0(renderer__Partition_45, renderer__HeadVar__3_3, renderer__Lj_10, &renderer__IntersectionResult1_50);
    }
#line 230 "renderer.m"
    renderer__V_52_52 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 230 "renderer.m"
    {
#line 230 "renderer.m"
      renderer__find_object_list_intersection_5_p_0(renderer__OtherObjects_46, renderer__HeadVar__3_3, renderer__Lj_10, renderer__V_52_52, &renderer__IntersectionResult2_51);
    }
#line 469 "renderer.m"
    renderer__succeeded = (renderer__IntersectionResult1_50 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 471 "renderer.m"
    if (renderer__succeeded)
#line 470 "renderer.m"
      renderer__Intersections_32 = renderer__IntersectionResult2_51;
#line 471 "renderer.m"
    else
#line 473 "renderer.m"
      {
#line 471 "renderer.m"
        renderer__succeeded = (renderer__IntersectionResult2_51 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 473 "renderer.m"
        if (renderer__succeeded)
#line 472 "renderer.m"
          renderer__Intersections_32 = renderer__IntersectionResult1_50;
#line 473 "renderer.m"
        else
#line 474 "renderer.m"
          {
#line 474 "renderer.m"
            renderer__Intersections_32 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "tree"));
#line 474 "renderer.m"
            MR_hl_field(MR_mktag(2), renderer__Intersections_32, 0) = ((MR_Box) (renderer__IntersectionResult1_50));
#line 474 "renderer.m"
            MR_hl_field(MR_mktag(2), renderer__Intersections_32, 1) = ((MR_Box) (renderer__IntersectionResult2_51));
#line 474 "renderer.m"
          }
#line 473 "renderer.m"
      }
#line 197 "renderer.m"
    {
#line 197 "renderer.m"
      renderer__choose_closest_intersection_5_p_0(renderer__HeadVar__3_3, renderer__Lj_10, renderer__Intersections_32, renderer__HeadVar__2_2, &renderer__MaybeIntersection_33);
    }
#line 199 "renderer.m"
    renderer__succeeded = (MR_tag((MR_Word) renderer__MaybeIntersection_33) == MR_mktag((MR_Integer) 1));
#line 199 "renderer.m"
    if ((MR_tag((MR_Word) renderer__MaybeIntersection_33) == MR_mktag((MR_Integer) 1)))
#line 199 "renderer.m"
      renderer__V_36_36 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__MaybeIntersection_33, (MR_Integer) 0)));
    if (renderer__succeeded)
      {
#line 199 "renderer.m"
        renderer__V_34_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_36_36, (MR_Integer) 0)));
#line 199 "renderer.m"
        renderer__Intersection_35 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_36_36, (MR_Integer) 1)));
#line 202 "renderer.m"
        renderer___Id_12 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__Intersection_35, (MR_Integer) 0)));
#line 202 "renderer.m"
        renderer__Intersection_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_35, (MR_Integer) 1)));
#line 202 "renderer.m"
        renderer__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_35, (MR_Integer) 2)));
#line 202 "renderer.m"
        renderer__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_35, (MR_Integer) 3)));
#line 202 "renderer.m"
        renderer__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_35, (MR_Integer) 4)));
#line 668 "renderer.m"
        {
#line 668 "renderer.m"
          renderer__succeeded = renderer__light_is_behind_point_3_p_0(renderer__HeadVar__3_3, renderer__Light_9, renderer__Intersection_16);
        }
      }
#line 665 "renderer.m"
    renderer__succeeded = !(renderer__succeeded);
    return renderer__succeeded;
  }
#line 660 "renderer.m"
}
#line 649 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_5 = (MR_Float) 0.00000000000000;
#line 649 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_6 = (MR_Float) 0.00000000000000;
#line 649 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_7 = (MR_Float) 0.00000000000000;
#line 649 "renderer.m"
static /* final */ const MR_Box renderer__const_22_0_8_V_61_61[3] = {
		(MR_Box) &renderer__float_22_0_5,
		(MR_Box) &renderer__float_22_0_6,
		(MR_Box) &renderer__float_22_0_7};
#line 651 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_9 = (MR_Float) 0.00000000000000;
#line 651 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_10 = (MR_Float) 0.00000000000000;
#line 651 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_11 = (MR_Float) 0.00000000000000;
#line 651 "renderer.m"
static /* final */ const MR_Box renderer__const_22_0_12_V_56_56[3] = {
		(MR_Box) &renderer__float_22_0_9,
		(MR_Box) &renderer__float_22_0_10,
		(MR_Box) &renderer__float_22_0_11};
#line 585 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_1 = (MR_Float) 0.00000000000000;
#line 585 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_2 = (MR_Float) 0.00000000000000;
#line 585 "renderer.m"
static /* final */ const MR_Float renderer__float_22_0_3 = (MR_Float) 0.00000000000000;
#line 585 "renderer.m"
static /* final */ const MR_Box renderer__const_22_0_4_ReflectedI_22[3] = {
		(MR_Box) &renderer__float_22_0_1,
		(MR_Box) &renderer__float_22_0_2,
		(MR_Box) &renderer__float_22_0_3};

#line 553 "renderer.m"
static void MR_CALL renderer__compute_intensity_9_p_0(
#line 553 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 553 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 553 "renderer.m"
  MR_Integer renderer__HeadVar__3_3,
#line 553 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 553 "renderer.m"
  MR_Word renderer__HeadVar__5_5,
#line 553 "renderer.m"
  MR_Word renderer__HeadVar__6_6,
#line 553 "renderer.m"
  MR_Word * renderer__HeadVar__7_7)
#line 553 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__I0_19;
    MR_Word renderer__AmbientI_20;
    MR_Word renderer__DirectionalOrPositionalI_21;
    MR_Word renderer__ReflectedI_22;
    MR_Float renderer__Kd_23;
    MR_Word renderer__Ia_24 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word renderer__C_25 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, (MR_Integer) 0)));
    MR_Float renderer__Ks_26;
    MR_Integer renderer__Depth_28;
    MR_Array renderer__Lights_34;
    MR_Word renderer__LightList0_42;
    MR_Word renderer__LightList_43;
    MR_Word renderer__ContributionList1_44;
    MR_Word renderer__ContributionList2_50;
    MR_Word renderer__SumContributions1_51;
    MR_Word renderer__SumContributions2_52;
    MR_Word renderer__V_53_53;
    MR_Word renderer__V_54_54;
    MR_Word renderer__V_56_56;
    MR_Float renderer__V_57_57;
    MR_Float renderer__V_58_58;
    MR_Float renderer__V_59_59;
    MR_Word renderer__V_61_61;
    MR_Float renderer__V_62_62;
    MR_Float renderer__V_63_63;
    MR_Float renderer__V_64_64;
    MR_Word renderer__V_91_91;
    MR_Word renderer__V_92_92;
    MR_Float renderer__V_124_124;
    MR_Word renderer__TypeInfo_150_150;
#line 567 "renderer.m"
    MR_String renderer__V_109_109 = ((MR_String) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 7)));
#line 567 "renderer.m"
    MR_Integer renderer__V_110_110 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 6)));
#line 567 "renderer.m"
    MR_Integer renderer__V_111_111 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 5)));
#line 567 "renderer.m"
    MR_Float renderer__V_112_112 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 4)));
#line 567 "renderer.m"
    MR_Integer renderer__V_113_113 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 3)));
#line 567 "renderer.m"
    MR_Word renderer__V_114_114 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
#line 567 "renderer.m"
    MR_Array renderer__V_115_115 = ((MR_Array) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 569 "renderer.m"
    MR_Float renderer__V_116_116 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, (MR_Integer) 3)));
#line 569 "renderer.m"
    MR_Float renderer__V_117_117 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, (MR_Integer) 2)));
#line 569 "renderer.m"
    MR_Float renderer__V_118_118 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, (MR_Integer) 1)));
#line 570 "renderer.m"
    MR_Word renderer__V_119_119;
#line 570 "renderer.m"
    MR_Float renderer__V_120_120;
#line 570 "renderer.m"
    MR_Float renderer__V_121_121;
#line 571 "renderer.m"
    MR_Float renderer__V_122_122;
#line 571 "renderer.m"
    MR_Word renderer__V_123_123;
#line 574 "renderer.m"
    MR_Word renderer__V_128_128;
#line 574 "renderer.m"
    MR_Array renderer__V_129_129;
#line 574 "renderer.m"
    MR_Word renderer__V_130_130;
#line 574 "renderer.m"
    MR_String renderer__V_131_131;
#line 574 "renderer.m"
    MR_Integer renderer__V_132_132;
#line 574 "renderer.m"
    MR_Integer renderer__V_133_133;
#line 574 "renderer.m"
    MR_Float renderer__V_134_134;
    MR_Integer renderer__V_166_166;
#line 596 "renderer.m"
    MR_Word renderer__V_143_143;
#line 596 "renderer.m"
    MR_String renderer__V_144_144;
#line 596 "renderer.m"
    MR_Integer renderer__V_145_145;
#line 596 "renderer.m"
    MR_Integer renderer__V_146_146;
#line 596 "renderer.m"
    MR_Float renderer__V_147_147;
#line 596 "renderer.m"
    MR_Integer renderer__V_148_148;
#line 596 "renderer.m"
    MR_Word renderer__V_149_149;

#line 565 "renderer.m"
    {
#line 565 "renderer.m"
      renderer__V_91_91 = renderer__f_times_3_f_0(renderer__Ia_24, renderer__C_25);
    }
#line 570 "renderer.m"
    renderer__V_119_119 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, (MR_Integer) 0)));
#line 570 "renderer.m"
    renderer__Kd_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, (MR_Integer) 1)));
#line 570 "renderer.m"
    renderer__V_121_121 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, (MR_Integer) 2)));
#line 570 "renderer.m"
    renderer__V_120_120 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, (MR_Integer) 3)));
#line 565 "renderer.m"
    {
#line 565 "renderer.m"
      renderer__AmbientI_20 = vector__scale_3_f_0(renderer__Kd_23, renderer__V_91_91);
    }
#line 571 "renderer.m"
    renderer__V_123_123 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, (MR_Integer) 0)));
#line 571 "renderer.m"
    renderer__V_122_122 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, (MR_Integer) 1)));
#line 571 "renderer.m"
    renderer__Ks_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, (MR_Integer) 2)));
#line 571 "renderer.m"
    renderer__V_124_124 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__6_6, (MR_Integer) 3)));
#line 574 "renderer.m"
    renderer__V_130_130 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 574 "renderer.m"
    renderer__V_129_129 = ((MR_Array) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 574 "renderer.m"
    renderer__V_128_128 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
#line 574 "renderer.m"
    renderer__Depth_28 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 3)));
#line 574 "renderer.m"
    renderer__V_134_134 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 4)));
#line 574 "renderer.m"
    renderer__V_133_133 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 5)));
#line 574 "renderer.m"
    renderer__V_132_132 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 6)));
#line 574 "renderer.m"
    renderer__V_131_131 = ((MR_String) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 7)));
#line 575 "renderer.m"
    renderer__V_166_166 = (MR_Integer) 0;
#line 575 "renderer.m"
    renderer__succeeded = (renderer__Depth_28 > renderer__V_166_166);
#line 584 "renderer.m"
    if (renderer__succeeded)
      {
        MR_Word renderer__NewRenderParams_29;
        MR_Word renderer__ReflectionDirection_31;
        MR_Word renderer__Is_32;
        MR_Word renderer__V_80_80;
        MR_Word renderer__V_81_81;
        MR_Float renderer__V_82_82;
        MR_Word renderer__V_83_83;
        MR_Float renderer__V_84_84;
        MR_Word renderer__V_85_85;
        MR_Integer renderer__V_86_86;
        MR_Integer renderer__V_87_87 = (MR_Integer) 1;
        MR_Word renderer__V_135_135;
        MR_Array renderer__V_136_136;
        MR_Word renderer__V_137_137;
        MR_String renderer__V_139_139;
        MR_Integer renderer__V_140_140;
        MR_Integer renderer__V_141_141;
        MR_Float renderer__V_142_142;
#line 576 "renderer.m"
        MR_Integer renderer__V_138_138;

#line 576 "renderer.m"
        renderer__V_86_86 = (renderer__Depth_28 - renderer__V_87_87);
#line 576 "renderer.m"
        renderer__V_137_137 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 576 "renderer.m"
        renderer__V_136_136 = ((MR_Array) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 576 "renderer.m"
        renderer__V_135_135 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
#line 576 "renderer.m"
        renderer__V_138_138 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 3)));
#line 576 "renderer.m"
        renderer__V_142_142 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 4)));
#line 576 "renderer.m"
        renderer__V_141_141 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 5)));
#line 576 "renderer.m"
        renderer__V_140_140 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 6)));
#line 576 "renderer.m"
        renderer__V_139_139 = ((MR_String) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 7)));
#line 576 "renderer.m"
        {
#line 576 "renderer.m"
          renderer__NewRenderParams_29 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 8 * sizeof(MR_Word)), "render_params");
#line 576 "renderer.m"
          MR_hl_field(MR_mktag(0), renderer__NewRenderParams_29, 0) = ((MR_Box) (renderer__V_137_137));
#line 576 "renderer.m"
          MR_hl_field(MR_mktag(0), renderer__NewRenderParams_29, 1) = ((MR_Box) (renderer__V_136_136));
#line 576 "renderer.m"
          MR_hl_field(MR_mktag(0), renderer__NewRenderParams_29, 2) = ((MR_Box) (renderer__V_135_135));
#line 576 "renderer.m"
          MR_hl_field(MR_mktag(0), renderer__NewRenderParams_29, 3) = ((MR_Box) (renderer__V_86_86));
#line 576 "renderer.m"
          MR_hl_field(MR_mktag(0), renderer__NewRenderParams_29, 4) = MR_box_float(renderer__V_142_142);
#line 576 "renderer.m"
          MR_hl_field(MR_mktag(0), renderer__NewRenderParams_29, 5) = ((MR_Box) (renderer__V_141_141));
#line 576 "renderer.m"
          MR_hl_field(MR_mktag(0), renderer__NewRenderParams_29, 6) = ((MR_Box) (renderer__V_140_140));
#line 576 "renderer.m"
          MR_hl_field(MR_mktag(0), renderer__NewRenderParams_29, 7) = ((MR_Box) (renderer__V_139_139));
#line 576 "renderer.m"
        }
#line 579 "renderer.m"
        renderer__V_82_82 = (MR_Float) 2.00000000000000;
#line 579 "renderer.m"
        {
#line 579 "renderer.m"
          renderer__V_85_85 = vector__f_minus_2_f_0(renderer__HeadVar__2_2);
        }
#line 579 "renderer.m"
        {
#line 579 "renderer.m"
          renderer__V_84_84 = vector__dot_3_f_0(renderer__HeadVar__5_5, renderer__V_85_85);
        }
#line 579 "renderer.m"
        {
#line 579 "renderer.m"
          renderer__V_83_83 = vector__scale_3_f_0(renderer__V_84_84, renderer__HeadVar__5_5);
        }
#line 578 "renderer.m"
        {
#line 578 "renderer.m"
          renderer__V_81_81 = vector__scale_3_f_0(renderer__V_82_82, renderer__V_83_83);
        }
#line 578 "renderer.m"
        {
#line 578 "renderer.m"
          renderer__ReflectionDirection_31 = vector__f_plus_3_f_0(renderer__HeadVar__2_2, renderer__V_81_81);
        }
#line 580 "renderer.m"
        {
#line 580 "renderer.m"
          renderer__fire_ray_7_p_0(renderer__NewRenderParams_29, renderer__HeadVar__3_3, renderer__HeadVar__4_4, renderer__ReflectionDirection_31, &renderer__Is_32);
        }
#line 582 "renderer.m"
        {
#line 582 "renderer.m"
          renderer__V_80_80 = renderer__f_times_3_f_0(renderer__Is_32, renderer__C_25);
        }
#line 582 "renderer.m"
        {
#line 582 "renderer.m"
          renderer__ReflectedI_22 = vector__scale_3_f_0(renderer__Ks_26, renderer__V_80_80);
        }
      }
#line 584 "renderer.m"
    else
      {
        MR_Float renderer__V_88_88 = (MR_Float) 0.00000000000000;
        MR_Float renderer__V_89_89 = (MR_Float) 0.00000000000000;
        MR_Float renderer__V_90_90 = (MR_Float) 0.00000000000000;

#line 585 "renderer.m"
        renderer__ReflectedI_22 = (MR_Word) &renderer__const_22_0_4_ReflectedI_22;
      }
#line 596 "renderer.m"
    renderer__V_143_143 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 596 "renderer.m"
    renderer__Lights_34 = ((MR_Array) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 596 "renderer.m"
    renderer__V_149_149 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
#line 596 "renderer.m"
    renderer__V_148_148 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 3)));
#line 596 "renderer.m"
    renderer__V_147_147 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 4)));
#line 596 "renderer.m"
    renderer__V_146_146 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 5)));
#line 596 "renderer.m"
    renderer__V_145_145 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 6)));
#line 596 "renderer.m"
    renderer__V_144_144 = ((MR_String) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 7)));
    renderer__TypeInfo_150_150 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
#line 609 "renderer.m"
    {
#line 609 "renderer.m"
      mercury__array__to_list_2_p_1(renderer__TypeInfo_150_150, (MR_Array) renderer__Lights_34, &renderer__LightList0_42);
    }
#line 611 "renderer.m"
    {
#line 611 "renderer.m"
      renderer__filter__ho6__ua0_3_p_in__list_0(renderer__HeadVar__1_1, renderer__HeadVar__3_3, renderer__HeadVar__4_4, renderer__LightList0_42, &renderer__LightList_43);
    }
#line 616 "renderer.m"
    {
#line 616 "renderer.m"
      renderer__ContributionList1_44 = renderer__map__ho9__ua0_3_f_in__list_0(renderer__HeadVar__4_4, renderer__HeadVar__5_5, renderer__C_25, renderer__LightList_43);
    }
#line 647 "renderer.m"
    {
#line 647 "renderer.m"
      renderer__ContributionList2_50 = renderer__map__ho8__ua0_3_f_in__list_0(renderer__HeadVar__2_2, renderer__HeadVar__4_4, renderer__HeadVar__5_5, renderer__C_25, renderer__V_124_124, renderer__LightList_43);
    }
#line 650 "renderer.m"
    renderer__V_62_62 = (MR_Float) 0.00000000000000;
#line 650 "renderer.m"
    renderer__V_63_63 = (MR_Float) 0.00000000000000;
#line 650 "renderer.m"
    renderer__V_64_64 = (MR_Float) 0.00000000000000;
#line 649 "renderer.m"
    renderer__V_61_61 = (MR_Word) &renderer__const_22_0_8_V_61_61;
#line 649 "renderer.m"
    {
#line 649 "renderer.m"
      renderer__SumContributions1_51 = renderer__foldl__ho7_4_f_in__list_0(renderer__ContributionList1_44, renderer__V_61_61);
    }
#line 652 "renderer.m"
    renderer__V_57_57 = (MR_Float) 0.00000000000000;
#line 652 "renderer.m"
    renderer__V_58_58 = (MR_Float) 0.00000000000000;
#line 652 "renderer.m"
    renderer__V_59_59 = (MR_Float) 0.00000000000000;
#line 651 "renderer.m"
    renderer__V_56_56 = (MR_Word) &renderer__const_22_0_12_V_56_56;
#line 651 "renderer.m"
    {
#line 651 "renderer.m"
      renderer__SumContributions2_52 = renderer__foldl__ho7_4_f_in__list_0(renderer__ContributionList2_50, renderer__V_56_56);
    }
#line 654 "renderer.m"
    {
#line 654 "renderer.m"
      renderer__V_53_53 = vector__scale_3_f_0(renderer__Kd_23, renderer__SumContributions1_51);
    }
#line 654 "renderer.m"
    {
#line 654 "renderer.m"
      renderer__V_54_54 = vector__scale_3_f_0(renderer__Ks_26, renderer__SumContributions2_52);
    }
#line 654 "renderer.m"
    {
#line 654 "renderer.m"
      renderer__DirectionalOrPositionalI_21 = vector__f_plus_3_f_0(renderer__V_53_53, renderer__V_54_54);
    }
#line 563 "renderer.m"
    {
#line 563 "renderer.m"
      renderer__V_92_92 = vector__f_plus_3_f_0(renderer__AmbientI_20, renderer__DirectionalOrPositionalI_21);
    }
#line 563 "renderer.m"
    {
#line 563 "renderer.m"
      renderer__I0_19 = vector__f_plus_3_f_0(renderer__V_92_92, renderer__ReflectedI_22);
    }
#line 564 "renderer.m"
    {
#line 564 "renderer.m"
      *renderer__HeadVar__7_7 = renderer__clamp_2_f_0(renderer__I0_19);
    }
  }
#line 553 "renderer.m"
}

#line 456 "renderer.m"
static void MR_CALL renderer__reverse_normals_2_p_0(
#line 456 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 456 "renderer.m"
  MR_Word * renderer__HeadVar__2_2)
#line 456 "renderer.m"
{
#line 458 "renderer.m"
  {
#line 458 "renderer.m"
    bool renderer__succeeded;
#line 458 "renderer.m"
    MR_Float renderer__Dist_3;
#line 458 "renderer.m"
    MR_Word renderer__Intersection0_4;
#line 458 "renderer.m"
    MR_Word renderer__Intersection_5;
#line 458 "renderer.m"
    MR_Word renderer__V_6_6;
#line 458 "renderer.m"
    MR_Word renderer__V_7_7;
#line 458 "renderer.m"
    MR_Word renderer__V_8_8;
#line 458 "renderer.m"
    MR_Word renderer__V_9_9;
#line 458 "renderer.m"
    MR_Word renderer__I1_10;
#line 458 "renderer.m"
    MR_Word renderer__I2_11;
#line 458 "renderer.m"
    MR_Word renderer__N1_12;
#line 458 "renderer.m"
    MR_Word renderer__N2_13;
#line 458 "renderer.m"
    MR_Word renderer__V_19_19;
#line 458 "renderer.m"
    MR_Integer renderer__V_20_20;
#line 458 "renderer.m"
    MR_Word renderer__V_21_21;
#line 458 "renderer.m"
    MR_Word renderer__V_22_22;
#line 458 "renderer.m"
    MR_Float renderer__X_3_23;
#line 458 "renderer.m"
    MR_Float renderer__Y_4_24;
#line 458 "renderer.m"
    MR_Float renderer__Z_5_25;
#line 458 "renderer.m"
    MR_Float renderer__V_6_26;
#line 458 "renderer.m"
    MR_Float renderer__V_7_27;
#line 458 "renderer.m"
    MR_Float renderer__V_8_28;

#line 458 "renderer.m"
#line 458 "renderer.m"
    switch (MR_tag((MR_Word) renderer__HeadVar__1_1)) {
#line 458 "renderer.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 458 "renderer.m"
      case (MR_Integer) 0:
#line 458 "renderer.m"
        *renderer__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 458 "renderer.m"
        break;
#line 458 "renderer.m"
      case (MR_Integer) 1:
        {
#line 459 "renderer.m"
          renderer__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 459 "renderer.m"
          renderer__Dist_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_8_8, (MR_Integer) 0)));
#line 459 "renderer.m"
          renderer__Intersection0_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_8_8, (MR_Integer) 1)));
#line 461 "renderer.m"
          renderer__V_20_20 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__Intersection0_4, (MR_Integer) 0)));
#line 461 "renderer.m"
          renderer__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection0_4, (MR_Integer) 1)));
#line 461 "renderer.m"
          renderer__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection0_4, (MR_Integer) 2)));
#line 461 "renderer.m"
          renderer__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection0_4, (MR_Integer) 3)));
#line 461 "renderer.m"
          renderer__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection0_4, (MR_Integer) 4)));
#line 11 "vector.opt"
          renderer__X_3_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_7_7, (MR_Integer) 0)));
#line 11 "vector.opt"
          renderer__Y_4_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_7_7, (MR_Integer) 1)));
#line 11 "vector.opt"
          renderer__Z_5_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_7_7, (MR_Integer) 2)));
#line 12 "vector.opt"
          renderer__V_6_26 = (((MR_Float) 0.00000000000000) - renderer__X_3_23);
#line 13 "vector.opt"
          renderer__V_7_27 = (((MR_Float) 0.00000000000000) - renderer__Y_4_24);
#line 14 "vector.opt"
          renderer__V_8_28 = (((MR_Float) 0.00000000000000) - renderer__Z_5_25);
#line 11 "vector.opt"
          {
#line 11 "vector.opt"
            renderer__V_6_6 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 11 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_6_6, 0) = MR_box_float(renderer__V_6_26);
#line 11 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_6_6, 1) = MR_box_float(renderer__V_7_27);
#line 11 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_6_6, 2) = MR_box_float(renderer__V_8_28);
#line 11 "vector.opt"
          }
#line 460 "renderer.m"
          {
#line 460 "renderer.m"
            renderer__Intersection_5 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 5 * sizeof(MR_Word)), "intersection");
#line 460 "renderer.m"
            MR_hl_field(MR_mktag(0), renderer__Intersection_5, 0) = ((MR_Box) (renderer__V_20_20));
#line 460 "renderer.m"
            MR_hl_field(MR_mktag(0), renderer__Intersection_5, 1) = ((MR_Box) (renderer__V_19_19));
#line 460 "renderer.m"
            MR_hl_field(MR_mktag(0), renderer__Intersection_5, 2) = ((MR_Box) (renderer__V_6_6));
#line 460 "renderer.m"
            MR_hl_field(MR_mktag(0), renderer__Intersection_5, 3) = ((MR_Box) (renderer__V_22_22));
#line 460 "renderer.m"
            MR_hl_field(MR_mktag(0), renderer__Intersection_5, 4) = ((MR_Box) (renderer__V_21_21));
#line 460 "renderer.m"
          }
#line 459 "renderer.m"
          {
#line 459 "renderer.m"
            renderer__V_9_9 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 459 "renderer.m"
            MR_hl_field(MR_mktag(0), renderer__V_9_9, 0) = MR_box_float(renderer__Dist_3);
#line 459 "renderer.m"
            MR_hl_field(MR_mktag(0), renderer__V_9_9, 1) = ((MR_Box) (renderer__Intersection_5));
#line 459 "renderer.m"
          }
#line 459 "renderer.m"
          {
#line 459 "renderer.m"
            *renderer__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "node"));
#line 459 "renderer.m"
            MR_hl_field(MR_mktag(1), *renderer__HeadVar__2_2, 0) = ((MR_Box) (renderer__V_9_9));
#line 459 "renderer.m"
          }
        }
#line 458 "renderer.m"
        break;
#line 458 "renderer.m"
      case (MR_Integer) 2:
        {
#line 462 "renderer.m"
          renderer__I1_10 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 462 "renderer.m"
          renderer__I2_11 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 463 "renderer.m"
          {
#line 463 "renderer.m"
            renderer__reverse_normals_2_p_0(renderer__I1_10, &renderer__N1_12);
          }
#line 464 "renderer.m"
          {
#line 464 "renderer.m"
            renderer__reverse_normals_2_p_0(renderer__I2_11, &renderer__N2_13);
          }
#line 469 "renderer.m"
          renderer__succeeded = (renderer__N1_12 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 471 "renderer.m"
          if (renderer__succeeded)
#line 470 "renderer.m"
            *renderer__HeadVar__2_2 = renderer__N2_13;
#line 471 "renderer.m"
          else
#line 473 "renderer.m"
            {
#line 471 "renderer.m"
              renderer__succeeded = (renderer__N2_13 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 473 "renderer.m"
              if (renderer__succeeded)
#line 472 "renderer.m"
                *renderer__HeadVar__2_2 = renderer__N1_12;
#line 473 "renderer.m"
              else
#line 474 "renderer.m"
                {
#line 474 "renderer.m"
                  *renderer__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "tree"));
#line 474 "renderer.m"
                  MR_hl_field(MR_mktag(2), *renderer__HeadVar__2_2, 0) = ((MR_Box) (renderer__N1_12));
#line 474 "renderer.m"
                  MR_hl_field(MR_mktag(2), *renderer__HeadVar__2_2, 1) = ((MR_Box) (renderer__N2_13));
#line 474 "renderer.m"
                }
#line 473 "renderer.m"
            }
        }
#line 458 "renderer.m"
        break;
#line 458 "renderer.m"
    }
#line 458 "renderer.m"
  }
#line 456 "renderer.m"
}

#line 436 "renderer.m"
static void MR_CALL renderer__select_intersection_points_NOT_in_object_4_p_0(
#line 436 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 436 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 436 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 436 "renderer.m"
  MR_Word * renderer__HeadVar__4_4)
#line 436 "renderer.m"
{
#line 439 "renderer.m"
  {
#line 439 "renderer.m"
    bool renderer__succeeded;
#line 439 "renderer.m"
    MR_Word renderer__I_7;
#line 439 "renderer.m"
    MR_Word renderer__Intersection_12;
#line 439 "renderer.m"
    MR_Word renderer__I1_14;
#line 439 "renderer.m"
    MR_Word renderer__I2_15;
#line 439 "renderer.m"
    MR_Word renderer__N1_19;
#line 439 "renderer.m"
    MR_Word renderer__N2_20;

#line 439 "renderer.m"
#line 439 "renderer.m"
    switch (MR_tag((MR_Word) renderer__HeadVar__1_1)) {
#line 439 "renderer.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 439 "renderer.m"
      case (MR_Integer) 0:
#line 439 "renderer.m"
        *renderer__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 439 "renderer.m"
        break;
#line 439 "renderer.m"
      case (MR_Integer) 1:
        {
#line 442 "renderer.m"
          MR_Float renderer___Dist_11;
#line 444 "renderer.m"
          MR_Word renderer__V_13_13;
#line 444 "renderer.m"
          MR_Integer renderer__V_21_21;
#line 444 "renderer.m"
          MR_Word renderer__V_22_22;
#line 444 "renderer.m"
          MR_Word renderer__V_23_23;
#line 444 "renderer.m"
          MR_Word renderer__V_24_24;

#line 441 "renderer.m"
          renderer__I_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 442 "renderer.m"
          renderer___Dist_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__I_7, (MR_Integer) 0)));
#line 442 "renderer.m"
          renderer__Intersection_12 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__I_7, (MR_Integer) 1)));
#line 444 "renderer.m"
          renderer__V_21_21 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__Intersection_12, (MR_Integer) 0)));
#line 444 "renderer.m"
          renderer__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_12, (MR_Integer) 1)));
#line 444 "renderer.m"
          renderer__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_12, (MR_Integer) 2)));
#line 444 "renderer.m"
          renderer__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_12, (MR_Integer) 3)));
#line 444 "renderer.m"
          renderer__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_12, (MR_Integer) 4)));
#line 444 "renderer.m"
          {
#line 444 "renderer.m"
            renderer__succeeded = renderer__point_is_in_object_3_p_0(renderer__V_13_13, renderer__HeadVar__2_2, renderer__HeadVar__3_3);
          }
#line 444 "renderer.m"
          renderer__succeeded = !(renderer__succeeded);
#line 448 "renderer.m"
          if (renderer__succeeded)
            *renderer__HeadVar__4_4 = renderer__HeadVar__1_1;
#line 448 "renderer.m"
          else
#line 449 "renderer.m"
            *renderer__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
        }
#line 439 "renderer.m"
        break;
#line 439 "renderer.m"
      case (MR_Integer) 2:
        {
#line 451 "renderer.m"
          renderer__I1_14 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 451 "renderer.m"
          renderer__I2_15 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 452 "renderer.m"
          {
#line 452 "renderer.m"
            renderer__select_intersection_points_NOT_in_object_4_p_0(renderer__I1_14, renderer__HeadVar__2_2, renderer__HeadVar__3_3, &renderer__N1_19);
          }
#line 453 "renderer.m"
          {
#line 453 "renderer.m"
            renderer__select_intersection_points_NOT_in_object_4_p_0(renderer__I2_15, renderer__HeadVar__2_2, renderer__HeadVar__3_3, &renderer__N2_20);
          }
#line 469 "renderer.m"
          renderer__succeeded = (renderer__N1_19 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 471 "renderer.m"
          if (renderer__succeeded)
#line 470 "renderer.m"
            *renderer__HeadVar__4_4 = renderer__N2_20;
#line 471 "renderer.m"
          else
#line 473 "renderer.m"
            {
#line 471 "renderer.m"
              renderer__succeeded = (renderer__N2_20 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 473 "renderer.m"
              if (renderer__succeeded)
#line 472 "renderer.m"
                *renderer__HeadVar__4_4 = renderer__N1_19;
#line 473 "renderer.m"
              else
#line 474 "renderer.m"
                {
#line 474 "renderer.m"
                  *renderer__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "tree"));
#line 474 "renderer.m"
                  MR_hl_field(MR_mktag(2), *renderer__HeadVar__4_4, 0) = ((MR_Box) (renderer__N1_19));
#line 474 "renderer.m"
                  MR_hl_field(MR_mktag(2), *renderer__HeadVar__4_4, 1) = ((MR_Box) (renderer__N2_20));
#line 474 "renderer.m"
                }
#line 473 "renderer.m"
            }
        }
#line 439 "renderer.m"
        break;
#line 439 "renderer.m"
    }
#line 439 "renderer.m"
  }
#line 436 "renderer.m"
}

#line 414 "renderer.m"
static void MR_CALL renderer__select_intersection_points_in_object_4_p_0(
#line 414 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 414 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 414 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 414 "renderer.m"
  MR_Word * renderer__HeadVar__4_4)
#line 414 "renderer.m"
{
#line 417 "renderer.m"
  {
#line 417 "renderer.m"
    bool renderer__succeeded;
#line 417 "renderer.m"
    MR_Word renderer__I_7;
#line 417 "renderer.m"
    MR_Word renderer__Intersection_12;
#line 417 "renderer.m"
    MR_Word renderer__I1_14;
#line 417 "renderer.m"
    MR_Word renderer__I2_15;
#line 417 "renderer.m"
    MR_Word renderer__N1_19;
#line 417 "renderer.m"
    MR_Word renderer__N2_20;

#line 417 "renderer.m"
#line 417 "renderer.m"
    switch (MR_tag((MR_Word) renderer__HeadVar__1_1)) {
#line 417 "renderer.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 417 "renderer.m"
      case (MR_Integer) 0:
#line 417 "renderer.m"
        *renderer__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 417 "renderer.m"
        break;
#line 417 "renderer.m"
      case (MR_Integer) 1:
        {
#line 420 "renderer.m"
          MR_Float renderer___Dist_11;
#line 426 "renderer.m"
          MR_Word renderer__V_13_13;
#line 422 "renderer.m"
          MR_Integer renderer__V_21_21;
#line 422 "renderer.m"
          MR_Word renderer__V_22_22;
#line 422 "renderer.m"
          MR_Word renderer__V_23_23;
#line 422 "renderer.m"
          MR_Word renderer__V_24_24;

#line 419 "renderer.m"
          renderer__I_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 420 "renderer.m"
          renderer___Dist_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__I_7, (MR_Integer) 0)));
#line 420 "renderer.m"
          renderer__Intersection_12 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__I_7, (MR_Integer) 1)));
#line 422 "renderer.m"
          renderer__V_21_21 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__Intersection_12, (MR_Integer) 0)));
#line 422 "renderer.m"
          renderer__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_12, (MR_Integer) 1)));
#line 422 "renderer.m"
          renderer__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_12, (MR_Integer) 2)));
#line 422 "renderer.m"
          renderer__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_12, (MR_Integer) 3)));
#line 422 "renderer.m"
          renderer__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_12, (MR_Integer) 4)));
#line 422 "renderer.m"
          {
#line 422 "renderer.m"
            renderer__succeeded = renderer__point_is_in_object_3_p_0(renderer__V_13_13, renderer__HeadVar__2_2, renderer__HeadVar__3_3);
          }
#line 426 "renderer.m"
          if (renderer__succeeded)
            *renderer__HeadVar__4_4 = renderer__HeadVar__1_1;
#line 426 "renderer.m"
          else
#line 427 "renderer.m"
            *renderer__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
        }
#line 417 "renderer.m"
        break;
#line 417 "renderer.m"
      case (MR_Integer) 2:
        {
#line 429 "renderer.m"
          renderer__I1_14 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 429 "renderer.m"
          renderer__I2_15 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 430 "renderer.m"
          {
#line 430 "renderer.m"
            renderer__select_intersection_points_in_object_4_p_0(renderer__I1_14, renderer__HeadVar__2_2, renderer__HeadVar__3_3, &renderer__N1_19);
          }
#line 431 "renderer.m"
          {
#line 431 "renderer.m"
            renderer__select_intersection_points_in_object_4_p_0(renderer__I2_15, renderer__HeadVar__2_2, renderer__HeadVar__3_3, &renderer__N2_20);
          }
#line 469 "renderer.m"
          renderer__succeeded = (renderer__N1_19 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 471 "renderer.m"
          if (renderer__succeeded)
#line 470 "renderer.m"
            *renderer__HeadVar__4_4 = renderer__N2_20;
#line 471 "renderer.m"
          else
#line 473 "renderer.m"
            {
#line 471 "renderer.m"
              renderer__succeeded = (renderer__N2_20 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 473 "renderer.m"
              if (renderer__succeeded)
#line 472 "renderer.m"
                *renderer__HeadVar__4_4 = renderer__N1_19;
#line 473 "renderer.m"
              else
#line 474 "renderer.m"
                {
#line 474 "renderer.m"
                  *renderer__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "tree"));
#line 474 "renderer.m"
                  MR_hl_field(MR_mktag(2), *renderer__HeadVar__4_4, 0) = ((MR_Box) (renderer__N1_19));
#line 474 "renderer.m"
                  MR_hl_field(MR_mktag(2), *renderer__HeadVar__4_4, 1) = ((MR_Box) (renderer__N2_20));
#line 474 "renderer.m"
                }
#line 473 "renderer.m"
            }
        }
#line 417 "renderer.m"
        break;
#line 417 "renderer.m"
    }
#line 417 "renderer.m"
  }
#line 414 "renderer.m"
}

#line 403 "renderer.m"
static void MR_CALL renderer__find_surface_and_not_object_intersection_6_p_0(
#line 403 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 403 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 403 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 403 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 403 "renderer.m"
  MR_Word renderer__HeadVar__5_5,
#line 403 "renderer.m"
  MR_Word * renderer__HeadVar__6_6)
#line 403 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__IntersectionResult0_13;

#line 409 "renderer.m"
    {
#line 409 "renderer.m"
      renderer__find_object_intersection_5_p_0(renderer__HeadVar__1_1, renderer__HeadVar__3_3, renderer__HeadVar__4_4, renderer__HeadVar__5_5, &renderer__IntersectionResult0_13);
    }
#line 411 "renderer.m"
    {
#line 411 "renderer.m"
      renderer__select_intersection_points_NOT_in_object_4_p_0(renderer__IntersectionResult0_13, renderer__HeadVar__2_2, renderer__HeadVar__3_3, renderer__HeadVar__6_6);
#line 411 "renderer.m"
      return;
    }
  }
#line 403 "renderer.m"
}

#line 386 "renderer.m"
static void MR_CALL renderer__find_surface_and_object_intersection_6_p_0(
#line 386 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 386 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 386 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 386 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 386 "renderer.m"
  MR_Word renderer__HeadVar__5_5,
#line 386 "renderer.m"
  MR_Word * renderer__HeadVar__6_6)
#line 386 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Word renderer__IntersectionResult0_13;

#line 392 "renderer.m"
    {
#line 392 "renderer.m"
      renderer__find_object_intersection_5_p_0(renderer__HeadVar__1_1, renderer__HeadVar__3_3, renderer__HeadVar__4_4, renderer__HeadVar__5_5, &renderer__IntersectionResult0_13);
    }
#line 394 "renderer.m"
    {
#line 394 "renderer.m"
      renderer__select_intersection_points_in_object_4_p_0(renderer__IntersectionResult0_13, renderer__HeadVar__2_2, renderer__HeadVar__3_3, renderer__HeadVar__6_6);
#line 394 "renderer.m"
      return;
    }
  }
#line 386 "renderer.m"
}

#line 245 "renderer.m"
static void MR_CALL renderer__choose_closest_intersection_5_p_0(
#line 245 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 245 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 245 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 245 "renderer.m"
  MR_Integer renderer__HeadVar__4_4,
#line 245 "renderer.m"
  MR_Word * renderer__HeadVar__5_5)
#line 245 "renderer.m"
{
#line 249 "renderer.m"
  {
#line 249 "renderer.m"
    bool renderer__succeeded;

#line 249 "renderer.m"
#line 249 "renderer.m"
    switch (MR_tag((MR_Word) renderer__HeadVar__3_3)) {
#line 249 "renderer.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 249 "renderer.m"
      case (MR_Integer) 0:
#line 265 "renderer.m"
        *renderer__HeadVar__5_5 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 249 "renderer.m"
        break;
#line 249 "renderer.m"
      case (MR_Integer) 1:
        {
          MR_Word renderer__Intersection_16 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__3_3, (MR_Integer) 0)));
          MR_Word renderer__Point_19;
          MR_Float renderer__V_20_20;
          MR_Word renderer__V_23_23;
          MR_Float renderer__Ax_4_56;
          MR_Float renderer__Ay_5_57;
          MR_Float renderer__Az_6_58;
          MR_Float renderer__Bx_7_59;
          MR_Float renderer__By_8_60;
          MR_Float renderer__Bz_9_61;
          MR_Float renderer__V_10_62;
          MR_Float renderer__V_11_63;
          MR_Float renderer__V_12_64;
          MR_Float renderer__Ax_4_65;
          MR_Float renderer__Ay_5_66;
          MR_Float renderer__Az_6_67;
          MR_Float renderer__V_10_72;
          MR_Float renderer__V_11_73;
          MR_Float renderer__V_12_74;
          MR_Float renderer__V_13_75;
          MR_Float renderer__V_88_88;
          MR_Word renderer__V_24_24;
          MR_Word renderer__V_40_40;
          MR_Integer renderer__V_48_48;
          MR_Word renderer__V_49_49;
          MR_Word renderer__V_50_50;
          MR_Word renderer__V_51_51;
          MR_Word renderer__V_52_52;
          MR_Integer renderer__V_53_53;
#line 256 "renderer.m"
          MR_Word renderer__V_28_28;
#line 256 "renderer.m"
          MR_Word renderer__V_29_29;
#line 256 "renderer.m"
          MR_Word renderer__V_30_30;
#line 256 "renderer.m"
          MR_Word renderer__V_31_31;
#line 336 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
          MR_Float renderer___X_3_41;
#line 336 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
          MR_Float renderer___X_3_54;
#line 258 "renderer.m"
          MR_Integer renderer__V_32_32;
#line 258 "renderer.m"
          MR_Word renderer__V_33_33;
#line 258 "renderer.m"
          MR_Word renderer__V_34_34;
#line 258 "renderer.m"
          MR_Word renderer__V_35_35;

#line 256 "renderer.m"
          {
#line 256 "renderer.m"
            renderer__V_24_24 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 5 * sizeof(MR_Word)), "intersection");
#line 256 "renderer.m"
            MR_hl_field(MR_mktag(0), renderer__V_24_24, 0) = ((MR_Box) (renderer__HeadVar__4_4));
#line 256 "renderer.m"
            MR_hl_field(MR_mktag(0), renderer__V_24_24, 1) = ((MR_Box) (NULL));
#line 256 "renderer.m"
            MR_hl_field(MR_mktag(0), renderer__V_24_24, 2) = ((MR_Box) (NULL));
#line 256 "renderer.m"
            MR_hl_field(MR_mktag(0), renderer__V_24_24, 3) = ((MR_Box) (NULL));
#line 256 "renderer.m"
            MR_hl_field(MR_mktag(0), renderer__V_24_24, 4) = ((MR_Box) (NULL));
#line 256 "renderer.m"
          }
#line 336 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
          renderer___X_3_41 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Intersection_16, (MR_Integer) 0)));
#line 336 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
          renderer__V_40_40 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_16, (MR_Integer) 1)));
#line 256 "renderer.m"
          renderer__V_48_48 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__V_40_40, (MR_Integer) 0)));
#line 256 "renderer.m"
          renderer__V_49_49 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_40_40, (MR_Integer) 1)));
#line 256 "renderer.m"
          renderer__V_50_50 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_40_40, (MR_Integer) 2)));
#line 256 "renderer.m"
          renderer__V_51_51 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_40_40, (MR_Integer) 3)));
#line 256 "renderer.m"
          renderer__V_52_52 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_40_40, (MR_Integer) 4)));
#line 256 "renderer.m"
          renderer__V_53_53 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__V_24_24, (MR_Integer) 0)));
#line 256 "renderer.m"
          (MR_hl_field(MR_mktag(0), renderer__V_24_24, (MR_Integer) 1)) = ((MR_Box) (renderer__V_49_49));
#line 256 "renderer.m"
          (MR_hl_field(MR_mktag(0), renderer__V_24_24, (MR_Integer) 2)) = ((MR_Box) (renderer__V_50_50));
#line 256 "renderer.m"
          (MR_hl_field(MR_mktag(0), renderer__V_24_24, (MR_Integer) 3)) = ((MR_Box) (renderer__V_51_51));
#line 256 "renderer.m"
          (MR_hl_field(MR_mktag(0), renderer__V_24_24, (MR_Integer) 4)) = ((MR_Box) (renderer__V_52_52));
#line 256 "renderer.m"
          renderer__succeeded = (renderer__V_48_48 == renderer__V_53_53);
#line 256 "renderer.m"
          renderer__succeeded = !(renderer__succeeded);
          if (renderer__succeeded)
            {
#line 336 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
              renderer___X_3_54 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Intersection_16, (MR_Integer) 0)));
#line 336 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
              renderer__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_16, (MR_Integer) 1)));
#line 258 "renderer.m"
              renderer__V_32_32 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__V_23_23, (MR_Integer) 0)));
#line 258 "renderer.m"
              renderer__Point_19 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_23_23, (MR_Integer) 1)));
#line 258 "renderer.m"
              renderer__V_35_35 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_23_23, (MR_Integer) 2)));
#line 258 "renderer.m"
              renderer__V_34_34 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_23_23, (MR_Integer) 3)));
#line 258 "renderer.m"
              renderer__V_33_33 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_23_23, (MR_Integer) 4)));
#line 7 "vector.opt"
              renderer__Ax_4_56 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Point_19, (MR_Integer) 0)));
#line 7 "vector.opt"
              renderer__Ay_5_57 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Point_19, (MR_Integer) 1)));
#line 7 "vector.opt"
              renderer__Az_6_58 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Point_19, (MR_Integer) 2)));
#line 7 "vector.opt"
              renderer__Bx_7_59 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 7 "vector.opt"
              renderer__By_8_60 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 7 "vector.opt"
              renderer__Bz_9_61 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
#line 8 "vector.opt"
              renderer__V_10_62 = (renderer__Ax_4_56 - renderer__Bx_7_59);
#line 9 "vector.opt"
              renderer__V_11_63 = (renderer__Ay_5_57 - renderer__By_8_60);
#line 10 "vector.opt"
              renderer__V_12_64 = (renderer__Az_6_58 - renderer__Bz_9_61);
#line 15 "vector.opt"
              renderer__Ax_4_65 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 0)));
#line 15 "vector.opt"
              renderer__Ay_5_66 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 1)));
#line 15 "vector.opt"
              renderer__Az_6_67 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 2)));
#line 18 "vector.opt"
              renderer__V_12_74 = (renderer__Ax_4_65 * renderer__V_10_62);
#line 19 "vector.opt"
              renderer__V_13_75 = (renderer__Ay_5_66 * renderer__V_11_63);
#line 17 "vector.opt"
              renderer__V_10_72 = (renderer__V_12_74 + renderer__V_13_75);
#line 20 "vector.opt"
              renderer__V_11_73 = (renderer__Az_6_67 * renderer__V_12_64);
#line 16 "vector.opt"
              renderer__V_20_20 = (renderer__V_10_72 + renderer__V_11_73);
#line 259 "renderer.m"
              renderer__V_88_88 = (MR_Float) 0.00000000000000;
#line 259 "renderer.m"
              renderer__succeeded = (renderer__V_20_20 > renderer__V_88_88);
            }
#line 262 "renderer.m"
          if (renderer__succeeded)
#line 261 "renderer.m"
            {
#line 261 "renderer.m"
              *renderer__HeadVar__5_5 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "yes"));
#line 261 "renderer.m"
              MR_hl_field(MR_mktag(1), *renderer__HeadVar__5_5, 0) = ((MR_Box) (renderer__Intersection_16));
#line 261 "renderer.m"
            }
#line 262 "renderer.m"
          else
#line 263 "renderer.m"
            *renderer__HeadVar__5_5 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
        }
#line 249 "renderer.m"
        break;
#line 249 "renderer.m"
      case (MR_Integer) 2:
        {
          MR_Word renderer__Left_8 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__3_3, (MR_Integer) 0)));
          MR_Word renderer__Right_9 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__3_3, (MR_Integer) 1)));
          MR_Word renderer__LeftBest_12;
          MR_Word renderer__RightBest_13;

#line 250 "renderer.m"
          {
#line 250 "renderer.m"
            renderer__choose_closest_intersection_5_p_0(renderer__HeadVar__1_1, renderer__HeadVar__2_2, renderer__Left_8, renderer__HeadVar__4_4, &renderer__LeftBest_12);
          }
#line 251 "renderer.m"
          {
#line 251 "renderer.m"
            renderer__choose_closest_intersection_5_p_0(renderer__HeadVar__1_1, renderer__HeadVar__2_2, renderer__Right_9, renderer__HeadVar__4_4, &renderer__RightBest_13);
          }
#line 273 "renderer.m"
          if ((renderer__LeftBest_12 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 273 "renderer.m"
            if ((renderer__RightBest_13 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 273 "renderer.m"
              *renderer__HeadVar__5_5 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 273 "renderer.m"
            else
              *renderer__HeadVar__5_5 = renderer__RightBest_13;
#line 273 "renderer.m"
          else
#line 273 "renderer.m"
            {
              MR_Word renderer__V_87_87 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__LeftBest_12, (MR_Integer) 0)));

#line 273 "renderer.m"
              if ((renderer__RightBest_13 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
                *renderer__HeadVar__5_5 = renderer__LeftBest_12;
#line 273 "renderer.m"
              else
#line 273 "renderer.m"
                {
                  MR_Word renderer__Best2_82 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__RightBest_13, (MR_Integer) 0)));
                  MR_Float renderer__Distance1_83 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_87_87, (MR_Integer) 0)));
                  MR_Float renderer__Distance2_85 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Best2_82, (MR_Integer) 0)));
#line 279 "renderer.m"
                  MR_Word renderer__V_84_84 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_87_87, (MR_Integer) 1)));
#line 280 "renderer.m"
                  MR_Word renderer__V_86_86 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Best2_82, (MR_Integer) 1)));

#line 281 "renderer.m"
                  renderer__succeeded = (renderer__Distance1_83 < renderer__Distance2_85);
#line 283 "renderer.m"
                  if (renderer__succeeded)
#line 282 "renderer.m"
                    *renderer__HeadVar__5_5 = renderer__LeftBest_12;
#line 283 "renderer.m"
                  else
#line 284 "renderer.m"
                    *renderer__HeadVar__5_5 = renderer__RightBest_13;
#line 273 "renderer.m"
                }
#line 273 "renderer.m"
            }
        }
#line 249 "renderer.m"
        break;
#line 249 "renderer.m"
    }
#line 249 "renderer.m"
  }
#line 245 "renderer.m"
}
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_1 = (MR_Float) 1.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_2 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_3 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_4 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_5 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_6 = (MR_Float) 1.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_7 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_8 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_9 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_10 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_11 = (MR_Float) 1.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Float renderer__float_9_0_12 = (MR_Float) 0.00000000000000;
#line 43 "trans.opt"
static /* final */ const MR_Box renderer__const_9_0_13_I_2_9[12] = {
		(MR_Box) &renderer__float_9_0_1,
		(MR_Box) &renderer__float_9_0_2,
		(MR_Box) &renderer__float_9_0_3,
		(MR_Box) &renderer__float_9_0_4,
		(MR_Box) &renderer__float_9_0_5,
		(MR_Box) &renderer__float_9_0_6,
		(MR_Box) &renderer__float_9_0_7,
		(MR_Box) &renderer__float_9_0_8,
		(MR_Box) &renderer__float_9_0_9,
		(MR_Box) &renderer__float_9_0_10,
		(MR_Box) &renderer__float_9_0_11,
		(MR_Box) &renderer__float_9_0_12};
#line 30 "trans.opt"
static /* final */ const MR_Box renderer__const_9_0_14_HeadVar__2_2[2] = {
		((MR_Box) (&renderer__const_9_0_13_I_2_9)),
		((MR_Box) (&renderer__const_9_0_13_I_2_9))};

#line 181 "renderer.m"
MR_Word MR_CALL renderer__maybe_transformation_to_trans_2_f_0(
#line 181 "renderer.m"
  MR_Word renderer__HeadVar__1_1)
#line 181 "renderer.m"
{
#line 829 "renderer.m"
  {
#line 829 "renderer.m"
    bool renderer__succeeded = (MR_tag((MR_Word) renderer__HeadVar__1_1) == MR_mktag((MR_Integer) 1));
#line 829 "renderer.m"
    MR_Word renderer__HeadVar__2_2;
#line 829 "renderer.m"
    MR_Word renderer__Trans0_5;

#line 820 "renderer.m"
    if ((MR_tag((MR_Word) renderer__HeadVar__1_1) == MR_mktag((MR_Integer) 1)))
#line 820 "renderer.m"
      renderer__Trans0_5 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 829 "renderer.m"
    if (renderer__succeeded)
#line 823 "renderer.m"
      {
#line 823 "renderer.m"
        MR_Word renderer__Trans1_6;

#line 821 "renderer.m"
        renderer__succeeded = ((MR_tag((MR_Word) renderer__Trans0_5) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), renderer__Trans0_5, (MR_Integer) 0))) == (MR_Integer) 3));
#line 821 "renderer.m"
        if (((MR_tag((MR_Word) renderer__Trans0_5) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), renderer__Trans0_5, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 821 "renderer.m"
          renderer__Trans1_6 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__Trans0_5, (MR_Integer) 1)));
#line 823 "renderer.m"
        if (renderer__succeeded)
#line 822 "renderer.m"
          renderer__HeadVar__2_2 = renderer__Trans1_6;
#line 823 "renderer.m"
        else
          {
            MR_Word renderer__V_7_7 = (MR_Word) renderer__Trans0_5;
            MR_Word renderer__TypeInfo_8_8 = (MR_Word) (&space_partition__space_partition__type_ctor_info_invalid_transformation_0);

#line 827 "renderer.m"
            {
#line 827 "renderer.m"
              mercury__exception__throw_1_p_0(renderer__TypeInfo_8_8, ((MR_Box) (renderer__V_7_7)));
            }
          }
#line 823 "renderer.m"
      }
#line 829 "renderer.m"
    else
      {
        MR_Word renderer__I_2_9 = (MR_Word) &renderer__const_9_0_13_I_2_9;
        MR_Float renderer__V_2_11 = (MR_Float) 1.00000000000000;
        MR_Float renderer__V_3_12 = (MR_Float) 0.00000000000000;
        MR_Float renderer__V_4_13 = (MR_Float) 0.00000000000000;
        MR_Float renderer__V_5_14 = (MR_Float) 0.00000000000000;
        MR_Float renderer__V_6_15 = (MR_Float) 0.00000000000000;
        MR_Float renderer__V_7_16 = (MR_Float) 1.00000000000000;
        MR_Float renderer__V_8_17 = (MR_Float) 0.00000000000000;
        MR_Float renderer__V_9_18 = (MR_Float) 0.00000000000000;
        MR_Float renderer__V_10_19 = (MR_Float) 0.00000000000000;
        MR_Float renderer__V_11_20 = (MR_Float) 0.00000000000000;
        MR_Float renderer__V_12_21 = (MR_Float) 1.00000000000000;
        MR_Float renderer__V_13_22 = (MR_Float) 0.00000000000000;

#line 30 "trans.opt"
        renderer__HeadVar__2_2 = (MR_Word) &renderer__const_9_0_14_HeadVar__2_2;
      }
#line 829 "renderer.m"
    return renderer__HeadVar__2_2;
#line 829 "renderer.m"
  }
#line 181 "renderer.m"
}

#line 178 "renderer.m"
void MR_CALL renderer__find_object_list_intersection_5_p_0(
#line 178 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 178 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 178 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 178 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 178 "renderer.m"
  MR_Word * renderer__HeadVar__5_5)
#line 178 "renderer.m"
{
#line 235 "renderer.m"
  {
#line 235 "renderer.m"
    /* tailcall optimized into a loop */
#line 235 "renderer.m"
  loop_top:;
#line 235 "renderer.m"
    {
#line 235 "renderer.m"
      bool renderer__succeeded;

#line 235 "renderer.m"
      if ((renderer__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 235 "renderer.m"
        *renderer__HeadVar__5_5 = renderer__HeadVar__4_4;
#line 235 "renderer.m"
      else
#line 235 "renderer.m"
        {
          MR_Word renderer__Obj_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word renderer__Objs_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__1_1, (MR_Integer) 1)));
          MR_Word renderer__MaybeTrans_15 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
          MR_Word renderer__Result_16;
          MR_Word renderer__V_17_17;

#line 239 "renderer.m"
          {
#line 239 "renderer.m"
            renderer__find_object_intersection_5_p_0(renderer__Obj_9, renderer__MaybeTrans_15, renderer__HeadVar__2_2, renderer__HeadVar__3_3, &renderer__Result_16);
          }
#line 469 "renderer.m"
          renderer__succeeded = (renderer__Result_16 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 471 "renderer.m"
          if (renderer__succeeded)
#line 470 "renderer.m"
            renderer__V_17_17 = renderer__HeadVar__4_4;
#line 471 "renderer.m"
          else
#line 473 "renderer.m"
            {
#line 471 "renderer.m"
              renderer__succeeded = (renderer__HeadVar__4_4 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 473 "renderer.m"
              if (renderer__succeeded)
#line 472 "renderer.m"
                renderer__V_17_17 = renderer__Result_16;
#line 473 "renderer.m"
              else
#line 474 "renderer.m"
                {
#line 474 "renderer.m"
                  renderer__V_17_17 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "tree"));
#line 474 "renderer.m"
                  MR_hl_field(MR_mktag(2), renderer__V_17_17, 0) = ((MR_Box) (renderer__Result_16));
#line 474 "renderer.m"
                  MR_hl_field(MR_mktag(2), renderer__V_17_17, 1) = ((MR_Box) (renderer__HeadVar__4_4));
#line 474 "renderer.m"
                }
#line 473 "renderer.m"
            }
#line 240 "renderer.m"
          {
#line 240 "renderer.m"
            /* direct tailcall eliminated */
#line 240 "renderer.m"
            {
#line 240 "renderer.m"
              MR_Word renderer__HeadVar__1__tmp_copy_1 = renderer__Objs_10;
#line 240 "renderer.m"
              MR_Word renderer__HeadVar__4__tmp_copy_4 = renderer__V_17_17;

#line 240 "renderer.m"
              renderer__HeadVar__1_1 = renderer__HeadVar__1__tmp_copy_1;
#line 240 "renderer.m"
              renderer__HeadVar__4_4 = renderer__HeadVar__4__tmp_copy_4;
#line 240 "renderer.m"
            }
#line 240 "renderer.m"
            goto loop_top;
#line 240 "renderer.m"
          }
#line 235 "renderer.m"
        }
#line 235 "renderer.m"
    }
#line 235 "renderer.m"
  }
#line 178 "renderer.m"
}

#line 175 "renderer.m"
void MR_CALL renderer__find_object_intersection_5_p_0(
#line 175 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 175 "renderer.m"
  MR_Word renderer__HeadVar__2_2,
#line 175 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 175 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 175 "renderer.m"
  MR_Word * renderer__HeadVar__5_5)
#line 175 "renderer.m"
{
#line 291 "renderer.m"
  {
#line 291 "renderer.m"
    /* tailcall optimized into a loop */
#line 291 "renderer.m"
  loop_top:;
#line 291 "renderer.m"
    {
#line 291 "renderer.m"
      bool renderer__succeeded;

#line 291 "renderer.m"
#line 291 "renderer.m"
      switch (MR_tag((MR_Word) renderer__HeadVar__1_1)) {
#line 291 "renderer.m"
        default: /*NOTREACHED*/ MR_assert(0);
#line 291 "renderer.m"
        case (MR_Integer) 3:
#line 291 "renderer.m"
#line 291 "renderer.m"
          switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__1_1, (MR_Integer) 0)))) {
#line 291 "renderer.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 291 "renderer.m"
            case (MR_Integer) 0:
              {
                MR_Word renderer__Object1_31 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__1_1, (MR_Integer) 1)));
                MR_Word renderer__Object2_32 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__1_1, (MR_Integer) 2)));
                MR_Word renderer__Intersection1_37;
                MR_Word renderer__Intersection2_38;

#line 344 "renderer.m"
                {
#line 344 "renderer.m"
                  renderer__find_surface_and_object_intersection_6_p_0(renderer__Object1_31, renderer__Object2_32, renderer__HeadVar__2_2, renderer__HeadVar__3_3, renderer__HeadVar__4_4, &renderer__Intersection1_37);
                }
#line 351 "renderer.m"
                {
#line 351 "renderer.m"
                  renderer__find_surface_and_object_intersection_6_p_0(renderer__Object2_32, renderer__Object1_31, renderer__HeadVar__2_2, renderer__HeadVar__3_3, renderer__HeadVar__4_4, &renderer__Intersection2_38);
                }
#line 469 "renderer.m"
                renderer__succeeded = (renderer__Intersection1_37 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 471 "renderer.m"
                if (renderer__succeeded)
#line 470 "renderer.m"
                  *renderer__HeadVar__5_5 = renderer__Intersection2_38;
#line 471 "renderer.m"
                else
#line 473 "renderer.m"
                  {
#line 471 "renderer.m"
                    renderer__succeeded = (renderer__Intersection2_38 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 473 "renderer.m"
                    if (renderer__succeeded)
#line 472 "renderer.m"
                      *renderer__HeadVar__5_5 = renderer__Intersection1_37;
#line 473 "renderer.m"
                    else
#line 474 "renderer.m"
                      {
#line 474 "renderer.m"
                        *renderer__HeadVar__5_5 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "tree"));
#line 474 "renderer.m"
                        MR_hl_field(MR_mktag(2), *renderer__HeadVar__5_5, 0) = ((MR_Box) (renderer__Intersection1_37));
#line 474 "renderer.m"
                        MR_hl_field(MR_mktag(2), *renderer__HeadVar__5_5, 1) = ((MR_Box) (renderer__Intersection2_38));
#line 474 "renderer.m"
                      }
#line 473 "renderer.m"
                  }
              }
#line 291 "renderer.m"
              break;
#line 291 "renderer.m"
            case (MR_Integer) 1:
              {
                MR_Word renderer__Object1_39 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__1_1, (MR_Integer) 1)));
                MR_Word renderer__Object2_40 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__HeadVar__1_1, (MR_Integer) 2)));
                MR_Word renderer__Intersection1_45;
                MR_Word renderer__Intersection2_46;
                MR_Word renderer__Intersection3_47;

#line 365 "renderer.m"
                {
#line 365 "renderer.m"
                  renderer__find_surface_and_not_object_intersection_6_p_0(renderer__Object1_39, renderer__Object2_40, renderer__HeadVar__2_2, renderer__HeadVar__3_3, renderer__HeadVar__4_4, &renderer__Intersection1_45);
                }
#line 373 "renderer.m"
                {
#line 373 "renderer.m"
                  renderer__find_surface_and_object_intersection_6_p_0(renderer__Object2_40, renderer__Object1_39, renderer__HeadVar__2_2, renderer__HeadVar__3_3, renderer__HeadVar__4_4, &renderer__Intersection2_46);
                }
#line 376 "renderer.m"
                {
#line 376 "renderer.m"
                  renderer__reverse_normals_2_p_0(renderer__Intersection2_46, &renderer__Intersection3_47);
                }
#line 380 "renderer.m"
                {
#line 380 "renderer.m"
                  *renderer__HeadVar__5_5 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "tree"));
#line 380 "renderer.m"
                  MR_hl_field(MR_mktag(2), *renderer__HeadVar__5_5, 0) = ((MR_Box) (renderer__Intersection1_45));
#line 380 "renderer.m"
                  MR_hl_field(MR_mktag(2), *renderer__HeadVar__5_5, 1) = ((MR_Box) (renderer__Intersection3_47));
#line 380 "renderer.m"
                }
              }
#line 291 "renderer.m"
              break;
#line 291 "renderer.m"
          }
#line 291 "renderer.m"
          break;
#line 291 "renderer.m"
        case (MR_Integer) 0:
          {
            MR_Integer renderer__Id_6 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
            MR_Word renderer__Obj_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
            MR_Word renderer__Intersections_13;
            MR_Word renderer__Trans_55;
#line 291 "renderer.m"
            MR_Word renderer___List_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));

#line 483 "renderer.m"
            {
#line 483 "renderer.m"
              renderer__Trans_55 = renderer__maybe_transformation_to_trans_2_f_0(renderer__HeadVar__2_2);
            }
#line 492 "renderer.m"
#line 492 "renderer.m"
            switch (MR_tag((MR_Word) renderer__Obj_7)) {
#line 492 "renderer.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 492 "renderer.m"
              case (MR_Integer) 3:
#line 492 "renderer.m"
#line 492 "renderer.m"
                switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), renderer__Obj_7, (MR_Integer) 0)))) {
#line 492 "renderer.m"
                  default: /*NOTREACHED*/ MR_assert(0);
#line 492 "renderer.m"
                  case (MR_Integer) 0:
                    {
                      MR_Word renderer__Surface_89 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__Obj_7, (MR_Integer) 1)));

#line 517 "renderer.m"
                      {
#line 517 "renderer.m"
                        trans__intersects_cone_6_p_0(renderer__Id_6, renderer__Trans_55, renderer__HeadVar__3_3, renderer__HeadVar__4_4, renderer__Surface_89, &renderer__Intersections_13);
                      }
                    }
#line 492 "renderer.m"
                    break;
#line 492 "renderer.m"
                  case (MR_Integer) 1:
                    {
                      MR_Word renderer__Surface_68 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__Obj_7, (MR_Integer) 1)));

#line 499 "renderer.m"
                      {
#line 499 "renderer.m"
                        trans__intersects_plane_6_p_0(renderer__Id_6, renderer__Trans_55, renderer__HeadVar__3_3, renderer__HeadVar__4_4, renderer__Surface_68, &renderer__Intersections_13);
                      }
                    }
#line 492 "renderer.m"
                    break;
#line 492 "renderer.m"
                }
#line 492 "renderer.m"
                break;
#line 492 "renderer.m"
              case (MR_Integer) 0:
                {
                  MR_Word renderer__Surface_57 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Obj_7, (MR_Integer) 0)));

#line 493 "renderer.m"
                  {
#line 493 "renderer.m"
                    trans__intersects_sphere_6_p_0(renderer__Id_6, renderer__Trans_55, renderer__HeadVar__3_3, renderer__HeadVar__4_4, renderer__Surface_57, &renderer__Intersections_13);
                  }
                }
#line 492 "renderer.m"
                break;
#line 492 "renderer.m"
              case (MR_Integer) 1:
                {
                  MR_Word renderer__Surface_75 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__Obj_7, (MR_Integer) 0)));

#line 505 "renderer.m"
                  {
#line 505 "renderer.m"
                    trans__intersects_cube_6_p_0(renderer__Id_6, renderer__Trans_55, renderer__HeadVar__3_3, renderer__HeadVar__4_4, renderer__Surface_75, &renderer__Intersections_13);
                  }
                }
#line 492 "renderer.m"
                break;
#line 492 "renderer.m"
              case (MR_Integer) 2:
                {
                  MR_Word renderer__Surface_82 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__Obj_7, (MR_Integer) 0)));

#line 511 "renderer.m"
                  {
#line 511 "renderer.m"
                    trans__intersects_cylinder_6_p_0(renderer__Id_6, renderer__Trans_55, renderer__HeadVar__3_3, renderer__HeadVar__4_4, renderer__Surface_82, &renderer__Intersections_13);
                  }
                }
#line 492 "renderer.m"
                break;
#line 492 "renderer.m"
            }
#line 294 "renderer.m"
            {
#line 294 "renderer.m"
              *renderer__HeadVar__5_5 = renderer__intersection_list_to_tree_3_f_0(renderer__HeadVar__3_3, renderer__Intersections_13);
            }
          }
#line 291 "renderer.m"
          break;
#line 291 "renderer.m"
        case (MR_Integer) 1:
          {
            MR_Word renderer__Object_14 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__1_1, (MR_Integer) 0)));
            MR_Word renderer__Transformation1_15 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__1_1, (MR_Integer) 1)));
            MR_Word renderer__V_21_21;
#line 299 "renderer.m"
            MR_Word renderer__V_20_20;

#line 299 "renderer.m"
            renderer__succeeded = (MR_tag((MR_Word) renderer__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 299 "renderer.m"
            if ((MR_tag((MR_Word) renderer__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 299 "renderer.m"
              renderer__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__2_2, (MR_Integer) 0)));
#line 303 "renderer.m"
            if (renderer__succeeded)
              {
                MR_Word renderer__V_22_22 = (MR_Word) renderer__Transformation1_15;
                MR_Word renderer__TypeInfo_48_48 = (MR_Word) (&space_partition__space_partition__type_ctor_info_invalid_transformation_0);

#line 302 "renderer.m"
                {
#line 302 "renderer.m"
                  mercury__exception__throw_1_p_0(renderer__TypeInfo_48_48, ((MR_Box) (renderer__V_22_22)));
                }
              }
#line 303 "renderer.m"
            else
              {
              }
#line 306 "renderer.m"
            {
#line 306 "renderer.m"
              renderer__V_21_21 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "yes"));
#line 306 "renderer.m"
              MR_hl_field(MR_mktag(1), renderer__V_21_21, 0) = ((MR_Box) (renderer__Transformation1_15));
#line 306 "renderer.m"
            }
#line 306 "renderer.m"
            {
#line 306 "renderer.m"
              /* direct tailcall eliminated */
#line 306 "renderer.m"
              {
#line 306 "renderer.m"
                MR_Word renderer__HeadVar__1__tmp_copy_1 = renderer__Object_14;
#line 306 "renderer.m"
                MR_Word renderer__HeadVar__2__tmp_copy_2 = renderer__V_21_21;

#line 306 "renderer.m"
                renderer__HeadVar__1_1 = renderer__HeadVar__1__tmp_copy_1;
#line 306 "renderer.m"
                renderer__HeadVar__2_2 = renderer__HeadVar__2__tmp_copy_2;
#line 306 "renderer.m"
              }
#line 306 "renderer.m"
              goto loop_top;
#line 306 "renderer.m"
            }
          }
#line 291 "renderer.m"
          break;
#line 291 "renderer.m"
        case (MR_Integer) 2:
          {
            MR_Word renderer__Object1_23 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 0)));
            MR_Word renderer__Object2_24 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 1)));
            MR_Word renderer__Intersection1_29;
            MR_Word renderer__Intersection2_30;

#line 314 "renderer.m"
            {
#line 314 "renderer.m"
              renderer__find_surface_and_not_object_intersection_6_p_0(renderer__Object1_23, renderer__Object2_24, renderer__HeadVar__2_2, renderer__HeadVar__3_3, renderer__HeadVar__4_4, &renderer__Intersection1_29);
            }
#line 321 "renderer.m"
            {
#line 321 "renderer.m"
              renderer__find_surface_and_not_object_intersection_6_p_0(renderer__Object2_24, renderer__Object1_23, renderer__HeadVar__2_2, renderer__HeadVar__3_3, renderer__HeadVar__4_4, &renderer__Intersection2_30);
            }
#line 469 "renderer.m"
            renderer__succeeded = (renderer__Intersection1_29 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 471 "renderer.m"
            if (renderer__succeeded)
#line 470 "renderer.m"
              *renderer__HeadVar__5_5 = renderer__Intersection2_30;
#line 471 "renderer.m"
            else
#line 473 "renderer.m"
              {
#line 471 "renderer.m"
                renderer__succeeded = (renderer__Intersection2_30 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 473 "renderer.m"
                if (renderer__succeeded)
#line 472 "renderer.m"
                  *renderer__HeadVar__5_5 = renderer__Intersection1_29;
#line 473 "renderer.m"
                else
#line 474 "renderer.m"
                  {
#line 474 "renderer.m"
                    *renderer__HeadVar__5_5 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "tree"));
#line 474 "renderer.m"
                    MR_hl_field(MR_mktag(2), *renderer__HeadVar__5_5, 0) = ((MR_Box) (renderer__Intersection1_29));
#line 474 "renderer.m"
                    MR_hl_field(MR_mktag(2), *renderer__HeadVar__5_5, 1) = ((MR_Box) (renderer__Intersection2_30));
#line 474 "renderer.m"
                  }
#line 473 "renderer.m"
              }
          }
#line 291 "renderer.m"
          break;
#line 291 "renderer.m"
      }
#line 291 "renderer.m"
    }
#line 291 "renderer.m"
  }
#line 175 "renderer.m"
}

#line 172 "renderer.m"
MR_Word MR_CALL renderer__make_tree_3_f_0(
#line 172 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 172 "renderer.m"
  MR_Word renderer__HeadVar__2_2)
#line 172 "renderer.m"
{
#line 471 "renderer.m"
  {
#line 471 "renderer.m"
    bool renderer__succeeded = (renderer__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 471 "renderer.m"
    MR_Word renderer__HeadVar__3_3;

#line 471 "renderer.m"
    if (renderer__succeeded)
#line 470 "renderer.m"
      renderer__HeadVar__3_3 = renderer__HeadVar__2_2;
#line 471 "renderer.m"
    else
#line 473 "renderer.m"
      {
#line 471 "renderer.m"
        renderer__succeeded = (renderer__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 473 "renderer.m"
        if (renderer__succeeded)
#line 472 "renderer.m"
          renderer__HeadVar__3_3 = renderer__HeadVar__1_1;
#line 473 "renderer.m"
        else
#line 474 "renderer.m"
          {
#line 474 "renderer.m"
            renderer__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "tree"));
#line 474 "renderer.m"
            MR_hl_field(MR_mktag(2), renderer__HeadVar__3_3, 0) = ((MR_Box) (renderer__HeadVar__1_1));
#line 474 "renderer.m"
            MR_hl_field(MR_mktag(2), renderer__HeadVar__3_3, 1) = ((MR_Box) (renderer__HeadVar__2_2));
#line 474 "renderer.m"
          }
#line 473 "renderer.m"
      }
#line 471 "renderer.m"
    return renderer__HeadVar__3_3;
#line 471 "renderer.m"
  }
#line 172 "renderer.m"
}
#line 148 "renderer.m"
static /* final */ const MR_Float renderer__float_5_0_1 = (MR_Float) 0.00000000000000;
#line 148 "renderer.m"
static /* final */ const MR_Float renderer__float_5_0_2 = (MR_Float) 0.00000000000000;
#line 148 "renderer.m"
static /* final */ const MR_Float renderer__float_5_0_3 = (MR_Float) 0.00000000000000;
#line 148 "renderer.m"
static /* final */ const MR_Box renderer__const_5_0_4_HeadVar__5_5[3] = {
		(MR_Box) &renderer__float_5_0_1,
		(MR_Box) &renderer__float_5_0_2,
		(MR_Box) &renderer__float_5_0_3};

#line 134 "renderer.m"
static void MR_CALL renderer__fire_ray_7_p_0(
#line 134 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 134 "renderer.m"
  MR_Integer renderer__HeadVar__2_2,
#line 134 "renderer.m"
  MR_Word renderer__HeadVar__3_3,
#line 134 "renderer.m"
  MR_Word renderer__HeadVar__4_4,
#line 134 "renderer.m"
  MR_Word * renderer__HeadVar__5_5)
#line 134 "renderer.m"
{
#line 146 "renderer.m"
  {
#line 146 "renderer.m"
    bool renderer__succeeded;
#line 146 "renderer.m"
    MR_Integer renderer__HitId_13;
#line 146 "renderer.m"
    MR_Word renderer__IntersectionPoint_14;
#line 146 "renderer.m"
    MR_Word renderer__UnitSurfaceNormal_15;
#line 146 "renderer.m"
    MR_Word renderer__SurfaceCoords_16;
#line 146 "renderer.m"
    MR_Word renderer__SurfaceTextureFunc_17;
    MR_Word renderer__Intersections_34;
    MR_Word renderer__MaybeIntersection_35;
    MR_Word renderer__Intersection_37;
    MR_Word renderer__V_38_38;
    MR_Word renderer__V_39_39 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
    MR_Word renderer__Partition_47 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_39_39, (MR_Integer) 0)));
    MR_Word renderer__OtherObjects_48 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_39_39, (MR_Integer) 1)));
    MR_Word renderer__IntersectionResult1_52;
    MR_Word renderer__IntersectionResult2_53;
    MR_Word renderer__V_54_54;
#line 195 "renderer.m"
    MR_Array renderer__V_40_40 = ((MR_Array) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 195 "renderer.m"
    MR_Word renderer__V_41_41 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 195 "renderer.m"
    MR_String renderer__V_42_42 = ((MR_String) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 7)));
#line 195 "renderer.m"
    MR_Integer renderer__V_43_43 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 6)));
#line 195 "renderer.m"
    MR_Integer renderer__V_44_44 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 5)));
#line 195 "renderer.m"
    MR_Float renderer__V_45_45 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 4)));
#line 195 "renderer.m"
    MR_Integer renderer__V_46_46 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 3)));
#line 199 "renderer.m"
    MR_Float renderer__V_36_36;

#line 228 "renderer.m"
    {
#line 228 "renderer.m"
      space_partition__traverse_space_tree_4_p_0(renderer__Partition_47, renderer__HeadVar__3_3, renderer__HeadVar__4_4, &renderer__IntersectionResult1_52);
    }
#line 230 "renderer.m"
    renderer__V_54_54 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 230 "renderer.m"
    {
#line 230 "renderer.m"
      renderer__find_object_list_intersection_5_p_0(renderer__OtherObjects_48, renderer__HeadVar__3_3, renderer__HeadVar__4_4, renderer__V_54_54, &renderer__IntersectionResult2_53);
    }
#line 469 "renderer.m"
    renderer__succeeded = (renderer__IntersectionResult1_52 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 471 "renderer.m"
    if (renderer__succeeded)
#line 470 "renderer.m"
      renderer__Intersections_34 = renderer__IntersectionResult2_53;
#line 471 "renderer.m"
    else
#line 473 "renderer.m"
      {
#line 471 "renderer.m"
        renderer__succeeded = (renderer__IntersectionResult2_53 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 473 "renderer.m"
        if (renderer__succeeded)
#line 472 "renderer.m"
          renderer__Intersections_34 = renderer__IntersectionResult1_52;
#line 473 "renderer.m"
        else
#line 474 "renderer.m"
          {
#line 474 "renderer.m"
            renderer__Intersections_34 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "tree"));
#line 474 "renderer.m"
            MR_hl_field(MR_mktag(2), renderer__Intersections_34, 0) = ((MR_Box) (renderer__IntersectionResult1_52));
#line 474 "renderer.m"
            MR_hl_field(MR_mktag(2), renderer__Intersections_34, 1) = ((MR_Box) (renderer__IntersectionResult2_53));
#line 474 "renderer.m"
          }
#line 473 "renderer.m"
      }
#line 197 "renderer.m"
    {
#line 197 "renderer.m"
      renderer__choose_closest_intersection_5_p_0(renderer__HeadVar__3_3, renderer__HeadVar__4_4, renderer__Intersections_34, renderer__HeadVar__2_2, &renderer__MaybeIntersection_35);
    }
#line 199 "renderer.m"
    renderer__succeeded = (MR_tag((MR_Word) renderer__MaybeIntersection_35) == MR_mktag((MR_Integer) 1));
#line 199 "renderer.m"
    if ((MR_tag((MR_Word) renderer__MaybeIntersection_35) == MR_mktag((MR_Integer) 1)))
#line 199 "renderer.m"
      renderer__V_38_38 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__MaybeIntersection_35, (MR_Integer) 0)));
    if (renderer__succeeded)
      {
#line 199 "renderer.m"
        renderer__V_36_36 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__V_38_38, (MR_Integer) 0)));
#line 199 "renderer.m"
        renderer__Intersection_37 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__V_38_38, (MR_Integer) 1)));
#line 202 "renderer.m"
        renderer__HitId_13 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__Intersection_37, (MR_Integer) 0)));
#line 202 "renderer.m"
        renderer__IntersectionPoint_14 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_37, (MR_Integer) 1)));
#line 202 "renderer.m"
        renderer__UnitSurfaceNormal_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_37, (MR_Integer) 2)));
#line 202 "renderer.m"
        renderer__SurfaceCoords_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_37, (MR_Integer) 3)));
#line 202 "renderer.m"
        renderer__SurfaceTextureFunc_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__Intersection_37, (MR_Integer) 4)));
#line 202 "renderer.m"
        renderer__succeeded = TRUE;
      }
#line 146 "renderer.m"
    if (renderer__succeeded)
      {
        MR_Word renderer__SurfaceProperties_18;

#line 531 "renderer.m"
        if ((MR_tag((MR_Word) renderer__SurfaceTextureFunc_17) == MR_mktag((MR_Integer) 0)))
          {
            MR_Word renderer__Env0_61 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__SurfaceTextureFunc_17, (MR_Integer) 0)));
            MR_Word renderer__Code_62 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__SurfaceTextureFunc_17, (MR_Integer) 1)));
            MR_Integer renderer__Face_63 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__SurfaceCoords_16, (MR_Integer) 0)));
            MR_Float renderer__U_64 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__SurfaceCoords_16, (MR_Integer) 1)));
            MR_Float renderer__V_65 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__SurfaceCoords_16, (MR_Integer) 2)));
            MR_Word renderer__Stack0_66;
            MR_Word renderer__Stack_68;
            MR_Word renderer__V_84_84;
            MR_Word renderer__V_85_85;
            MR_Word renderer__V_86_86;
            MR_Word renderer__V_87_87;
            MR_Word renderer__V_88_88;
            MR_Word renderer__V_89_89;
#line 535 "renderer.m"
            MR_Word renderer___Env_67;
#line 538 "renderer.m"
            MR_Float renderer__N_69;
#line 538 "renderer.m"
            MR_Float renderer__Ks_70;
#line 538 "renderer.m"
            MR_Float renderer__Kd_71;
#line 538 "renderer.m"
            MR_Word renderer__C_72;
            MR_Word renderer__V_75_75;
            MR_Word renderer__V_76_76;
            MR_Word renderer__V_77_77;
            MR_Word renderer__V_78_78;
            MR_Word renderer__V_79_79;
            MR_Word renderer__V_80_80;
            MR_Word renderer__V_81_81;
            MR_Word renderer__V_82_82;

#line 534 "renderer.m"
            {
#line 534 "renderer.m"
              renderer__V_84_84 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 534 "renderer.m"
              MR_hl_field(MR_mktag(2), renderer__V_84_84, 0) = MR_box_float(renderer__V_65);
#line 534 "renderer.m"
            }
#line 534 "renderer.m"
            {
#line 534 "renderer.m"
              renderer__V_86_86 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 534 "renderer.m"
              MR_hl_field(MR_mktag(2), renderer__V_86_86, 0) = MR_box_float(renderer__U_64);
#line 534 "renderer.m"
            }
#line 534 "renderer.m"
            {
#line 534 "renderer.m"
              renderer__V_88_88 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "int"));
#line 534 "renderer.m"
              MR_hl_field(MR_mktag(1), renderer__V_88_88, 0) = ((MR_Box) (renderer__Face_63));
#line 534 "renderer.m"
            }
#line 534 "renderer.m"
            renderer__V_89_89 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 534 "renderer.m"
            {
#line 534 "renderer.m"
              renderer__V_87_87 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 534 "renderer.m"
              MR_hl_field(MR_mktag(1), renderer__V_87_87, 0) = ((MR_Box) (renderer__V_88_88));
#line 534 "renderer.m"
              MR_hl_field(MR_mktag(1), renderer__V_87_87, 1) = ((MR_Box) (renderer__V_89_89));
#line 534 "renderer.m"
            }
#line 534 "renderer.m"
            {
#line 534 "renderer.m"
              renderer__V_85_85 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 534 "renderer.m"
              MR_hl_field(MR_mktag(1), renderer__V_85_85, 0) = ((MR_Box) (renderer__V_86_86));
#line 534 "renderer.m"
              MR_hl_field(MR_mktag(1), renderer__V_85_85, 1) = ((MR_Box) (renderer__V_87_87));
#line 534 "renderer.m"
            }
#line 534 "renderer.m"
            {
#line 534 "renderer.m"
              renderer__Stack0_66 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 534 "renderer.m"
              MR_hl_field(MR_mktag(1), renderer__Stack0_66, 0) = ((MR_Box) (renderer__V_84_84));
#line 534 "renderer.m"
              MR_hl_field(MR_mktag(1), renderer__Stack0_66, 1) = ((MR_Box) (renderer__V_85_85));
#line 534 "renderer.m"
            }
#line 535 "renderer.m"
            {
#line 535 "renderer.m"
              eval__interpret_7_p_0(renderer__Code_62, renderer__Env0_61, renderer__Stack0_66, &renderer___Env_67, &renderer__Stack_68);
            }
#line 536 "renderer.m"
            renderer__succeeded = (MR_tag((MR_Word) renderer__Stack_68) == MR_mktag((MR_Integer) 1));
#line 536 "renderer.m"
            if ((MR_tag((MR_Word) renderer__Stack_68) == MR_mktag((MR_Integer) 1)))
#line 536 "renderer.m"
              {
#line 536 "renderer.m"
                renderer__V_75_75 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__Stack_68, (MR_Integer) 0)));
#line 536 "renderer.m"
                renderer__V_76_76 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__Stack_68, (MR_Integer) 1)));
#line 536 "renderer.m"
              }
            if (renderer__succeeded)
              {
#line 536 "renderer.m"
                renderer__succeeded = (MR_tag((MR_Word) renderer__V_75_75) == MR_mktag((MR_Integer) 2));
#line 536 "renderer.m"
                if ((MR_tag((MR_Word) renderer__V_75_75) == MR_mktag((MR_Integer) 2)))
#line 536 "renderer.m"
                  renderer__N_69 = MR_unbox_float((MR_hl_field(MR_mktag(2), renderer__V_75_75, (MR_Integer) 0)));
                if (renderer__succeeded)
                  {
#line 536 "renderer.m"
                    renderer__succeeded = (MR_tag((MR_Word) renderer__V_76_76) == MR_mktag((MR_Integer) 1));
#line 536 "renderer.m"
                    if ((MR_tag((MR_Word) renderer__V_76_76) == MR_mktag((MR_Integer) 1)))
#line 536 "renderer.m"
                      {
#line 536 "renderer.m"
                        renderer__V_77_77 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__V_76_76, (MR_Integer) 0)));
#line 536 "renderer.m"
                        renderer__V_78_78 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__V_76_76, (MR_Integer) 1)));
#line 536 "renderer.m"
                      }
                    if (renderer__succeeded)
                      {
#line 536 "renderer.m"
                        renderer__succeeded = (MR_tag((MR_Word) renderer__V_77_77) == MR_mktag((MR_Integer) 2));
#line 536 "renderer.m"
                        if ((MR_tag((MR_Word) renderer__V_77_77) == MR_mktag((MR_Integer) 2)))
#line 536 "renderer.m"
                          renderer__Ks_70 = MR_unbox_float((MR_hl_field(MR_mktag(2), renderer__V_77_77, (MR_Integer) 0)));
                        if (renderer__succeeded)
                          {
#line 536 "renderer.m"
                            renderer__succeeded = (MR_tag((MR_Word) renderer__V_78_78) == MR_mktag((MR_Integer) 1));
#line 536 "renderer.m"
                            if ((MR_tag((MR_Word) renderer__V_78_78) == MR_mktag((MR_Integer) 1)))
#line 536 "renderer.m"
                              {
#line 536 "renderer.m"
                                renderer__V_79_79 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__V_78_78, (MR_Integer) 0)));
#line 536 "renderer.m"
                                renderer__V_80_80 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__V_78_78, (MR_Integer) 1)));
#line 536 "renderer.m"
                              }
                            if (renderer__succeeded)
                              {
#line 536 "renderer.m"
                                renderer__succeeded = (MR_tag((MR_Word) renderer__V_79_79) == MR_mktag((MR_Integer) 2));
#line 536 "renderer.m"
                                if ((MR_tag((MR_Word) renderer__V_79_79) == MR_mktag((MR_Integer) 2)))
#line 536 "renderer.m"
                                  renderer__Kd_71 = MR_unbox_float((MR_hl_field(MR_mktag(2), renderer__V_79_79, (MR_Integer) 0)));
                                if (renderer__succeeded)
                                  {
#line 536 "renderer.m"
                                    renderer__succeeded = (MR_tag((MR_Word) renderer__V_80_80) == MR_mktag((MR_Integer) 1));
#line 536 "renderer.m"
                                    if ((MR_tag((MR_Word) renderer__V_80_80) == MR_mktag((MR_Integer) 1)))
#line 536 "renderer.m"
                                      {
#line 536 "renderer.m"
                                        renderer__V_81_81 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__V_80_80, (MR_Integer) 0)));
#line 536 "renderer.m"
                                        renderer__V_82_82 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__V_80_80, (MR_Integer) 1)));
#line 536 "renderer.m"
                                      }
                                    if (renderer__succeeded)
                                      {
#line 536 "renderer.m"
                                        renderer__succeeded = (renderer__V_82_82 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
                                        if (renderer__succeeded)
                                          {
#line 536 "renderer.m"
                                            renderer__succeeded = ((MR_tag((MR_Word) renderer__V_81_81) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), renderer__V_81_81, (MR_Integer) 0))) == (MR_Integer) 3));
#line 536 "renderer.m"
                                            if (((MR_tag((MR_Word) renderer__V_81_81) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), renderer__V_81_81, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 536 "renderer.m"
                                              renderer__C_72 = ((MR_Word) (MR_hl_field(MR_mktag(3), renderer__V_81_81, (MR_Integer) 1)));
                                          }
                                      }
                                  }
                              }
                          }
                      }
                  }
              }
#line 538 "renderer.m"
            if (renderer__succeeded)
#line 537 "renderer.m"
              {
#line 537 "renderer.m"
                renderer__SurfaceProperties_18 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 4 * sizeof(MR_Word)), "surface_properties");
#line 537 "renderer.m"
                MR_hl_field(MR_mktag(0), renderer__SurfaceProperties_18, 0) = ((MR_Box) (renderer__C_72));
#line 537 "renderer.m"
                MR_hl_field(MR_mktag(0), renderer__SurfaceProperties_18, 1) = MR_box_float(renderer__Kd_71);
#line 537 "renderer.m"
                MR_hl_field(MR_mktag(0), renderer__SurfaceProperties_18, 2) = MR_box_float(renderer__Ks_70);
#line 537 "renderer.m"
                MR_hl_field(MR_mktag(0), renderer__SurfaceProperties_18, 3) = MR_box_float(renderer__N_69);
#line 537 "renderer.m"
              }
#line 538 "renderer.m"
            else
              {
                MR_String renderer__V_83_83 = (MR_String) "surface texture function returned wrong number/type of values";
                MR_Word renderer__TypeInfo_42_94 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 539 "renderer.m"
                {
#line 539 "renderer.m"
                  mercury__exception__throw_1_p_0(renderer__TypeInfo_42_94, ((MR_Box) (renderer__V_83_83)));
                }
              }
          }
#line 531 "renderer.m"
        else
#line 544 "renderer.m"
          renderer__SurfaceProperties_18 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__SurfaceTextureFunc_17, (MR_Integer) 0)));
#line 143 "renderer.m"
        {
#line 143 "renderer.m"
          renderer__compute_intensity_9_p_0(renderer__HeadVar__1_1, renderer__HeadVar__4_4, renderer__HitId_13, renderer__IntersectionPoint_14, renderer__UnitSurfaceNormal_15, renderer__SurfaceProperties_18, renderer__HeadVar__5_5);
#line 143 "renderer.m"
          return;
        }
      }
#line 146 "renderer.m"
    else
      {
        MR_Float renderer__V_22_22 = (MR_Float) 0.00000000000000;
        MR_Float renderer__V_23_23 = (MR_Float) 0.00000000000000;
        MR_Float renderer__V_24_24 = (MR_Float) 0.00000000000000;

#line 148 "renderer.m"
        *renderer__HeadVar__5_5 = (MR_Word) &renderer__const_5_0_4_HeadVar__5_5;
      }
#line 146 "renderer.m"
  }
#line 134 "renderer.m"
}
#line 740 "renderer.m"
static /* final */ const MR_Float renderer__float_2_0_1 = (MR_Float) 0.00000000000000;
#line 740 "renderer.m"
static /* final */ const MR_Float renderer__float_2_0_2 = (MR_Float) 0.00000000000000;
#line 740 "renderer.m"
static /* final */ const MR_Float renderer__float_2_0_3 = (MR_Float) -1.00000000000000;
#line 740 "renderer.m"
static /* final */ const MR_Box renderer__const_2_0_4_RayOrigin_43[3] = {
		(MR_Box) &renderer__float_2_0_1,
		(MR_Box) &renderer__float_2_0_2,
		(MR_Box) &renderer__float_2_0_3};

#line 82 "renderer.m"
static void MR_CALL renderer__render_pixel_loop_7_p_0(
#line 82 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 82 "renderer.m"
  MR_Integer renderer__HeadVar__2_2,
#line 82 "renderer.m"
  MR_Integer renderer__HeadVar__3_3,
#line 82 "renderer.m"
  MR_Integer renderer__HeadVar__4_4,
#line 82 "renderer.m"
  MR_Integer renderer__HeadVar__5_5)
#line 82 "renderer.m"
{
#line 88 "renderer.m"
  {
#line 88 "renderer.m"
    /* tailcall optimized into a loop */
#line 88 "renderer.m"
  loop_top:;
#line 88 "renderer.m"
    {
#line 88 "renderer.m"
      bool renderer__succeeded = (renderer__HeadVar__3_3 == renderer__HeadVar__5_5);

#line 88 "renderer.m"
      if (renderer__succeeded)
#line 87 "renderer.m"
        {
#line 87 "renderer.m"
        }
#line 88 "renderer.m"
      else
#line 90 "renderer.m"
        {
#line 88 "renderer.m"
          renderer__succeeded = (renderer__HeadVar__2_2 == renderer__HeadVar__4_4);
#line 90 "renderer.m"
          if (renderer__succeeded)
            {
              MR_Integer renderer__V_29_29 = (MR_Integer) 0;
              MR_Integer renderer__V_30_30;
              MR_Integer renderer__V_31_31 = (MR_Integer) 1;

#line 89 "renderer.m"
              renderer__V_30_30 = (renderer__HeadVar__3_3 + renderer__V_31_31);
#line 89 "renderer.m"
              {
#line 89 "renderer.m"
                /* direct tailcall eliminated */
#line 89 "renderer.m"
                {
#line 89 "renderer.m"
                  MR_Integer renderer__HeadVar__2__tmp_copy_2 = renderer__V_29_29;
#line 89 "renderer.m"
                  MR_Integer renderer__HeadVar__3__tmp_copy_3 = renderer__V_30_30;

#line 89 "renderer.m"
                  renderer__HeadVar__2_2 = renderer__HeadVar__2__tmp_copy_2;
#line 89 "renderer.m"
                  renderer__HeadVar__3_3 = renderer__HeadVar__3__tmp_copy_3;
#line 89 "renderer.m"
                }
#line 89 "renderer.m"
                goto loop_top;
#line 89 "renderer.m"
              }
            }
#line 90 "renderer.m"
          else
            {
              MR_Word renderer__Intensity_14;
              MR_Float renderer__R0_15;
              MR_Float renderer__G0_16;
              MR_Float renderer__B0_17;
              MR_Integer renderer__R_18;
              MR_Integer renderer__G_19;
              MR_Integer renderer__B_20;
              MR_Integer renderer__V_32_32;
              MR_Integer renderer__V_33_33;
              MR_Float renderer__V_34_34;
              MR_Float renderer__V_35_35;
              MR_Float renderer__V_36_36;
              MR_Float renderer__V_37_37;
              MR_Float renderer__V_38_38;
              MR_Float renderer__V_39_39;
              MR_Word renderer__RayOrigin_43 = (MR_Word) &renderer__const_2_0_4_RayOrigin_43;
              MR_Word renderer__RayDirection_44;
              MR_Integer renderer__V_47_47;
              MR_Float renderer__V_48_48 = (MR_Float) 0.00000000000000;
              MR_Float renderer__V_49_49 = (MR_Float) 0.00000000000000;
              MR_Float renderer__V_50_50 = (MR_Float) -1.00000000000000;
              MR_Float renderer__Fov_54 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 4)));
              MR_Integer renderer__V_64_64 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 6)));
              MR_Integer renderer__V_65_65 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 5)));
#line 766 "renderer.m"
              MR_Integer renderer__V_59_59 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 3)));
#line 766 "renderer.m"
              MR_Word renderer__V_60_60 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
#line 766 "renderer.m"
              MR_Array renderer__V_61_61 = ((MR_Array) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 766 "renderer.m"
              MR_Word renderer__V_62_62 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
#line 766 "renderer.m"
              MR_String renderer__V_63_63 = ((MR_String) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 7)));

#line 771 "renderer.m"
              {
#line 771 "renderer.m"
                renderer__RayDirection_44 = renderer__pixel_direction_2_6_f_0(renderer__Fov_54, renderer__V_65_65, renderer__V_64_64, renderer__HeadVar__2_2, renderer__HeadVar__3_3);
              }
#line 131 "renderer.m"
              renderer__V_47_47 = (MR_Integer) 0;
#line 126 "renderer.m"
              {
#line 126 "renderer.m"
                renderer__fire_ray_7_p_0(renderer__HeadVar__1_1, renderer__V_47_47, renderer__RayOrigin_43, renderer__RayDirection_44, &renderer__Intensity_14);
              }
#line 94 "renderer.m"
              renderer__R0_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Intensity_14, (MR_Integer) 0)));
#line 94 "renderer.m"
              renderer__G0_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Intensity_14, (MR_Integer) 1)));
#line 94 "renderer.m"
              renderer__B0_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Intensity_14, (MR_Integer) 2)));
#line 95 "renderer.m"
              renderer__V_39_39 = (MR_Float) 255.000000000000;
#line 95 "renderer.m"
              renderer__V_38_38 = (renderer__R0_15 * renderer__V_39_39);
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL renderer__render_pixel_loop_7_p_0
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Float X;
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Integer Round;
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	X = 
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__V_38_38
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
;
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

	Round = (MR_Integer) floor(X + 0.5);

#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__R_18
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = Round;
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
#line 96 "renderer.m"
              renderer__V_37_37 = (MR_Float) 255.000000000000;
#line 96 "renderer.m"
              renderer__V_36_36 = (renderer__G0_16 * renderer__V_37_37);
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL renderer__render_pixel_loop_7_p_0
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Float X;
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Integer Round;
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	X = 
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__V_36_36
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
;
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

	Round = (MR_Integer) floor(X + 0.5);

#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__G_19
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = Round;
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
#line 97 "renderer.m"
              renderer__V_35_35 = (MR_Float) 255.000000000000;
#line 97 "renderer.m"
              renderer__V_34_34 = (renderer__B0_17 * renderer__V_35_35);
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL renderer__render_pixel_loop_7_p_0
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Float X;
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Integer Round;
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	X = 
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__V_34_34
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
;
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

	Round = (MR_Integer) floor(X + 0.5);

#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__B_20
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = Round;
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL renderer__render_pixel_loop_7_p_0
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer Byte;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Byte = 
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
renderer__R_18
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	/* call putc with a strictly non-negative byte-sized integer */
	if (MR_PUTCH(*mercury_current_binary_output,
			(int) ((unsigned char) Byte)) < 0)
	{
		mercury_output_error(mercury_current_text_output);
	}
	update_io(IO0, IO);

#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL renderer__render_pixel_loop_7_p_0
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer Byte;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Byte = 
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
renderer__G_19
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	/* call putc with a strictly non-negative byte-sized integer */
	if (MR_PUTCH(*mercury_current_binary_output,
			(int) ((unsigned char) Byte)) < 0)
	{
		mercury_output_error(mercury_current_text_output);
	}
	update_io(IO0, IO);

#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL renderer__render_pixel_loop_7_p_0
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer Byte;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Byte = 
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
renderer__B_20
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	/* call putc with a strictly non-negative byte-sized integer */
	if (MR_PUTCH(*mercury_current_binary_output,
			(int) ((unsigned char) Byte)) < 0)
	{
		mercury_output_error(mercury_current_text_output);
	}
	update_io(IO0, IO);

#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 527 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 100 "renderer.m"
              renderer__V_33_33 = (MR_Integer) 1;
#line 100 "renderer.m"
              renderer__V_32_32 = (renderer__HeadVar__2_2 + renderer__V_33_33);
#line 100 "renderer.m"
              {
#line 100 "renderer.m"
                /* direct tailcall eliminated */
#line 100 "renderer.m"
                {
#line 100 "renderer.m"
                  MR_Integer renderer__HeadVar__2__tmp_copy_2 = renderer__V_32_32;

#line 100 "renderer.m"
                  renderer__HeadVar__2_2 = renderer__HeadVar__2__tmp_copy_2;
#line 100 "renderer.m"
                }
#line 100 "renderer.m"
                goto loop_top;
#line 100 "renderer.m"
              }
            }
#line 90 "renderer.m"
        }
#line 88 "renderer.m"
    }
#line 88 "renderer.m"
  }
#line 82 "renderer.m"
}

#line 27 "renderer.m"
MR_Word MR_CALL renderer__light_unit_vector_3_f_0(
#line 27 "renderer.m"
  MR_Word renderer__HeadVar__1_1,
#line 27 "renderer.m"
  MR_Word renderer__HeadVar__2_2)
#line 27 "renderer.m"
{
#line 720 "renderer.m"
  {
#line 720 "renderer.m"
    bool renderer__succeeded;
#line 720 "renderer.m"
    MR_Word renderer__HeadVar__3_3;

#line 720 "renderer.m"
#line 720 "renderer.m"
    switch (MR_tag((MR_Word) renderer__HeadVar__1_1)) {
#line 720 "renderer.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 720 "renderer.m"
      case (MR_Integer) 0:
        {
          MR_Word renderer__Dir_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));
          MR_Float renderer__X_3_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Dir_4, (MR_Integer) 0)));
          MR_Float renderer__Y_4_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Dir_4, (MR_Integer) 1)));
          MR_Float renderer__Z_5_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Dir_4, (MR_Integer) 2)));
          MR_Float renderer__V_6_22 = (((MR_Float) 0.00000000000000) - renderer__X_3_19);
          MR_Float renderer__V_7_23 = (((MR_Float) 0.00000000000000) - renderer__Y_4_20);
          MR_Float renderer__V_8_24 = (((MR_Float) 0.00000000000000) - renderer__Z_5_21);
          MR_Float renderer__V_8_28;
          MR_Float renderer__V_9_29;
          MR_Float renderer__V_10_30;
          MR_Float renderer__Mag_6_31;
          MR_Float renderer__V_4_35;
          MR_Float renderer__V_6_40;
          MR_Float renderer__V_7_41;
          MR_Float renderer__V_8_42 = (renderer__V_6_22 * renderer__V_6_22);
          MR_Float renderer__V_9_43 = (renderer__V_7_23 * renderer__V_7_23);
#line 720 "renderer.m"
          MR_Word renderer___Intensity_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));

#line 27 "vector.opt"
          renderer__V_6_40 = (renderer__V_8_42 + renderer__V_9_43);
#line 32 "vector.opt"
          renderer__V_7_41 = (renderer__V_8_24 * renderer__V_8_24);
#line 26 "vector.opt"
          renderer__V_4_35 = (renderer__V_6_40 + renderer__V_7_41);
#line 22 "vector.opt"
          {
#line 22 "vector.opt"
            renderer__Mag_6_31 = mercury__math__sqrt_2_f_0(renderer__V_4_35);
          }
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL renderer__light_unit_vector_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
          if (renderer__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            renderer__succeeded = (renderer__Mag_6_31 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          if (renderer__succeeded)
            {
              MR_Word renderer__V_7_50;
              MR_String renderer__V_8_51 = (MR_String) "float:'/'";
              MR_Word renderer__TypeInfo_9_52;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              renderer__V_7_50 = (MR_Word) renderer__V_8_51;
              renderer__TypeInfo_9_52 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
                mercury__exception__throw_1_p_0(renderer__TypeInfo_9_52, ((MR_Box) (renderer__V_7_50)));
              }
            }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            renderer__V_8_28 = (renderer__V_6_22 / renderer__Mag_6_31);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL renderer__light_unit_vector_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
          if (renderer__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            renderer__succeeded = (renderer__Mag_6_31 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          if (renderer__succeeded)
            {
              MR_Word renderer__V_7_56;
              MR_String renderer__V_8_57 = (MR_String) "float:'/'";
              MR_Word renderer__TypeInfo_9_58;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              renderer__V_7_56 = (MR_Word) renderer__V_8_57;
              renderer__TypeInfo_9_58 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
                mercury__exception__throw_1_p_0(renderer__TypeInfo_9_58, ((MR_Box) (renderer__V_7_56)));
              }
            }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            renderer__V_9_29 = (renderer__V_7_23 / renderer__Mag_6_31);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL renderer__light_unit_vector_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
renderer__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
          if (renderer__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            renderer__succeeded = (renderer__Mag_6_31 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          if (renderer__succeeded)
            {
              MR_Word renderer__V_7_62;
              MR_String renderer__V_8_63 = (MR_String) "float:'/'";
              MR_Word renderer__TypeInfo_9_64;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              renderer__V_7_62 = (MR_Word) renderer__V_8_63;
              renderer__TypeInfo_9_64 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
                mercury__exception__throw_1_p_0(renderer__TypeInfo_9_64, ((MR_Box) (renderer__V_7_62)));
              }
            }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            renderer__V_10_30 = (renderer__V_8_24 / renderer__Mag_6_31);
#line 35 "vector.opt"
          {
#line 35 "vector.opt"
            renderer__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 35 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, 0) = MR_box_float(renderer__V_8_28);
#line 35 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, 1) = MR_box_float(renderer__V_9_29);
#line 35 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__HeadVar__3_3, 2) = MR_box_float(renderer__V_10_30);
#line 35 "vector.opt"
          }
        }
#line 720 "renderer.m"
        break;
#line 720 "renderer.m"
      case (MR_Integer) 1:
        {
          MR_Word renderer__Pos_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word renderer__V_11_11;
          MR_Float renderer__Ax_4_65 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_8, (MR_Integer) 0)));
          MR_Float renderer__Ay_5_66 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_8, (MR_Integer) 1)));
          MR_Float renderer__Az_6_67 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_8, (MR_Integer) 2)));
          MR_Float renderer__Bx_7_68 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 0)));
          MR_Float renderer__By_8_69 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 1)));
          MR_Float renderer__Bz_9_70 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 2)));
          MR_Float renderer__V_10_71 = (renderer__Ax_4_65 - renderer__Bx_7_68);
          MR_Float renderer__V_11_72 = (renderer__Ay_5_66 - renderer__By_8_69);
          MR_Float renderer__V_12_73 = (renderer__Az_6_67 - renderer__Bz_9_70);
#line 721 "renderer.m"
          MR_Word renderer___Intensity_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), renderer__HeadVar__1_1, (MR_Integer) 1)));

#line 7 "vector.opt"
          {
#line 7 "vector.opt"
            renderer__V_11_11 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_11_11, 0) = MR_box_float(renderer__V_10_71);
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_11_11, 1) = MR_box_float(renderer__V_11_72);
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_11_11, 2) = MR_box_float(renderer__V_12_73);
#line 7 "vector.opt"
          }
#line 721 "renderer.m"
          {
#line 721 "renderer.m"
            return renderer__HeadVar__3_3 = vector__unit_2_f_0(renderer__V_11_11);
          }
        }
#line 720 "renderer.m"
        break;
#line 720 "renderer.m"
      case (MR_Integer) 2:
        {
          MR_Word renderer__Pos_12 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word renderer__V_18_18;
          MR_Float renderer__Ax_4_74 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_12, (MR_Integer) 0)));
          MR_Float renderer__Ay_5_75 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_12, (MR_Integer) 1)));
          MR_Float renderer__Az_6_76 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__Pos_12, (MR_Integer) 2)));
          MR_Float renderer__Bx_7_77 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 0)));
          MR_Float renderer__By_8_78 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 1)));
          MR_Float renderer__Bz_9_79 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__2_2, (MR_Integer) 2)));
          MR_Float renderer__V_10_80 = (renderer__Ax_4_74 - renderer__Bx_7_77);
          MR_Float renderer__V_11_81 = (renderer__Ay_5_75 - renderer__By_8_78);
          MR_Float renderer__V_12_82 = (renderer__Az_6_76 - renderer__Bz_9_79);
#line 722 "renderer.m"
          MR_Word renderer___At_13 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 722 "renderer.m"
          MR_Word renderer___Intensity_14 = ((MR_Word) (MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 2)));
#line 722 "renderer.m"
          MR_Float renderer___Cutoff_15 = MR_unbox_float((MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 3)));
#line 722 "renderer.m"
          MR_Float renderer___Exp_16 = MR_unbox_float((MR_hl_field(MR_mktag(2), renderer__HeadVar__1_1, (MR_Integer) 4)));

#line 7 "vector.opt"
          {
#line 7 "vector.opt"
            renderer__V_18_18 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_18_18, 0) = MR_box_float(renderer__V_10_80);
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_18_18, 1) = MR_box_float(renderer__V_11_81);
#line 7 "vector.opt"
            MR_hl_field(MR_mktag(0), renderer__V_18_18, 2) = MR_box_float(renderer__V_12_82);
#line 7 "vector.opt"
          }
#line 722 "renderer.m"
          {
#line 722 "renderer.m"
            return renderer__HeadVar__3_3 = vector__unit_2_f_0(renderer__V_18_18);
          }
        }
#line 720 "renderer.m"
        break;
#line 720 "renderer.m"
    }
#line 720 "renderer.m"
    return renderer__HeadVar__3_3;
#line 720 "renderer.m"
  }
#line 27 "renderer.m"
}

#line 20 "renderer.m"
void MR_CALL renderer__render_3_p_0(
#line 20 "renderer.m"
  MR_Word renderer__HeadVar__1_1)
#line 20 "renderer.m"
{
  {
    bool renderer__succeeded;
    MR_Integer renderer__Wid_5 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 5)));
    MR_Word renderer__Res_8;
    MR_String renderer__V_42_42 = ((MR_String) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 7)));
    MR_Integer renderer__V_43_43 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 6)));
#line 38 "renderer.m"
    MR_Float renderer__V_37_37 = MR_unbox_float((MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 4)));
#line 38 "renderer.m"
    MR_Integer renderer__V_38_38 = ((MR_Integer) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 3)));
#line 38 "renderer.m"
    MR_Word renderer__V_39_39 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 2)));
#line 38 "renderer.m"
    MR_Array renderer__V_40_40 = ((MR_Array) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 1)));
#line 38 "renderer.m"
    MR_Word renderer__V_41_41 = ((MR_Word) (MR_hl_field(MR_mktag(0), renderer__HeadVar__1_1, (MR_Integer) 0)));

#line 46 "renderer.m"
    {
#line 46 "renderer.m"
      mercury__io__tell_4_p_0(renderer__V_42_42, &renderer__Res_8);
    }
#line 47 "renderer.m"
    renderer__succeeded = (renderer__Res_8 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 75 "renderer.m"
    if (renderer__succeeded)
      {
        MR_Word renderer__Stream_9;
        MR_Word renderer__BinStream_10;
        MR_Integer renderer__V_23_23;
        MR_Integer renderer__V_24_24;
        MR_String renderer__V_25_25;
        MR_Word renderer__V_26_26;
        MR_String renderer__V_27_27;
        MR_Word renderer__V_28_28;
        MR_Word renderer__V_29_29;
        MR_Word renderer__V_30_30;
        MR_Word renderer__V_31_31;
        MR_Word renderer__V_32_32;
        MR_String renderer__V_33_33;
        MR_Word renderer__V_34_34;
        MR_String renderer__V_35_35;
        MR_Word renderer__V_36_36;
        MR_Word renderer__Stream_7_70;
        MR_String renderer__String_9_80;
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        MR_Word renderer___Old_11;

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL renderer__render_3_p_0
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_output;
	update_io(IO0, IO);

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
renderer__Stream_9
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 49 "renderer.m"
        renderer__BinStream_10 = renderer__Stream_9;
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL renderer__render_3_p_0
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word NewStream;
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word OutStream;
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	NewStream = 
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
renderer__BinStream_10
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	OutStream = (MR_Word) mercury_current_binary_output;
	mercury_current_binary_output = (MercuryFile *) NewStream;
	update_io(IO0, IO);

#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
renderer___Old_11
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = OutStream;
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 621 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 52 "renderer.m"
        renderer__V_35_35 = (MR_String) "P6\n";
#line 52 "renderer.m"
        renderer__V_36_36 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL renderer__render_3_p_0
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_output;
	update_io(IO0, IO);

#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
renderer__Stream_7_70
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 427 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 343 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
        {
#line 343 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          mercury__string__format_3_p_0(renderer__V_35_35, renderer__V_36_36, &renderer__String_9_80);
        }
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL renderer__render_3_p_0
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Stream = 
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
renderer__Stream_7_70
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
renderer__String_9_80
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile *stream = (MercuryFile *) Stream;
	mercury_print_string(stream, Message);
	update_io(IO0, IO);
}
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 286 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 53 "renderer.m"
        renderer__V_33_33 = (MR_String) "# Merry Mercuryians )O+\n";
#line 53 "renderer.m"
        renderer__V_34_34 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 53 "renderer.m"
        {
#line 53 "renderer.m"
          mercury__io__format_4_p_0(renderer__V_33_33, renderer__V_34_34);
        }
#line 54 "renderer.m"
        renderer__V_27_27 = (MR_String) "%d %d\n";
#line 54 "renderer.m"
        {
#line 54 "renderer.m"
          renderer__V_29_29 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "i"));
#line 54 "renderer.m"
          MR_hl_field(MR_mktag(1), renderer__V_29_29, 0) = ((MR_Box) (renderer__Wid_5));
#line 54 "renderer.m"
        }
#line 54 "renderer.m"
        {
#line 54 "renderer.m"
          renderer__V_31_31 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "i"));
#line 54 "renderer.m"
          MR_hl_field(MR_mktag(1), renderer__V_31_31, 0) = ((MR_Box) (renderer__V_43_43));
#line 54 "renderer.m"
        }
#line 54 "renderer.m"
        renderer__V_32_32 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 54 "renderer.m"
        {
#line 54 "renderer.m"
          renderer__V_30_30 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 54 "renderer.m"
          MR_hl_field(MR_mktag(1), renderer__V_30_30, 0) = ((MR_Box) (renderer__V_31_31));
#line 54 "renderer.m"
          MR_hl_field(MR_mktag(1), renderer__V_30_30, 1) = ((MR_Box) (renderer__V_32_32));
#line 54 "renderer.m"
        }
#line 54 "renderer.m"
        {
#line 54 "renderer.m"
          renderer__V_28_28 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 54 "renderer.m"
          MR_hl_field(MR_mktag(1), renderer__V_28_28, 0) = ((MR_Box) (renderer__V_29_29));
#line 54 "renderer.m"
          MR_hl_field(MR_mktag(1), renderer__V_28_28, 1) = ((MR_Box) (renderer__V_30_30));
#line 54 "renderer.m"
        }
#line 54 "renderer.m"
        {
#line 54 "renderer.m"
          mercury__io__format_4_p_0(renderer__V_27_27, renderer__V_28_28);
        }
#line 55 "renderer.m"
        renderer__V_25_25 = (MR_String) "255\n";
#line 55 "renderer.m"
        renderer__V_26_26 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 55 "renderer.m"
        {
#line 55 "renderer.m"
          mercury__io__format_4_p_0(renderer__V_25_25, renderer__V_26_26);
        }
#line 72 "renderer.m"
        renderer__V_23_23 = (MR_Integer) 0;
#line 72 "renderer.m"
        renderer__V_24_24 = (MR_Integer) 0;
#line 72 "renderer.m"
        {
#line 72 "renderer.m"
          renderer__render_pixel_loop_7_p_0(renderer__HeadVar__1_1, renderer__V_23_23, renderer__V_24_24, renderer__Wid_5, renderer__V_43_43);
        }
#line 74 "renderer.m"
        {
#line 74 "renderer.m"
          mercury__io__told_2_p_0();
#line 74 "renderer.m"
          return;
        }
      }
#line 75 "renderer.m"
    else
      {
        MR_Word renderer__TypeInfo_58_58 = (MR_Word) (&mercury__io__io__type_ctor_info_res_0);

#line 76 "renderer.m"
        {
#line 76 "renderer.m"
          mercury__exception__throw_1_p_0(renderer__TypeInfo_58_58, ((MR_Box) (renderer__Res_8)));
#line 76 "renderer.m"
          return;
        }
      }
  }
#line 20 "renderer.m"
}

void mercury__renderer__init(void)
{
}

void mercury__renderer__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&renderer__renderer__type_ctor_info_unimplemented_object_0);
	MR_register_type_ctor_info(&renderer__renderer__type_ctor_info_render_params_0);
	MR_register_type_ctor_info(&renderer__renderer__type_ctor_info_pixel_coords_0);
	MR_register_type_ctor_info(&renderer__renderer__type_ctor_info_intersection_result_0);
	MR_register_type_ctor_info(&renderer__renderer__type_ctor_info_best_intersection_0);
}

void mercury__renderer__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module renderer. */
