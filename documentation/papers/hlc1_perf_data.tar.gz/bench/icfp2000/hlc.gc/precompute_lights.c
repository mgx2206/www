/*
** Automatically generated from `precompute_lights.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module precompute_lights. */
/* :- implementation. */

#include "precompute_lights.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.enum.h"
#include "eval.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "globals.h"
#include "gml.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "op.h"
#include "mercury.ops.h"
#include "peephole.h"
#include "precompute_lights.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "renderer.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "space_partition.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.term.h"
#include "mercury.time.h"
#include "trans.h"
#include "transform_object.h"
#include "tree.h"
#include "mercury.tree234.h"
#include "vector.h"



static const MR_DuFunctorDescPtr precompute_lights__precompute_lights__du_name_ordered_bounding_sphere_0[1];
static const MR_DuFunctorDesc precompute_lights__precompute_lights__du_functor_desc_bounding_sphere_0_0;
static const MR_ConstString precompute_lights__precompute_lights__field_names_bounding_sphere_0_0[2];
static const MR_PseudoTypeInfo precompute_lights__precompute_lights__field_types_bounding_sphere_0_0[2];
static const MR_DuPtagLayout precompute_lights__precompute_lights__du_ptag_ordered_bounding_sphere_0[1];
static const MR_DuFunctorDescPtr precompute_lights__precompute_lights__du_stag_ordered_bounding_sphere_0_0[1];
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL precompute_lights__filter__ho9__ua0_4_p_in__list_0(
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_16_16,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Float precompute_lights__V_15_15,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_14_14,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__HeadVar__2_2,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__3_3,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__4_4);
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL precompute_lights__filter__ho8__ua0_4_p_in__list_0(
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_16_16,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Float precompute_lights__V_15_15,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_14_14,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__HeadVar__2_2,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__3_3,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__4_4);
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL precompute_lights__map__ho6__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_13_13,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_12_12,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__3_3);
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL precompute_lights__map__ho4__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_13_13,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_12_12,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__3_3);
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL precompute_lights__map__ho7_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__3_3);
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL precompute_lights__map__ho5_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__3_3);
#line 127 "precompute_lights.m"
static void MR_CALL precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_p_0(
#line 127 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__2_2,
#line 127 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__3_3,
#line 127 "precompute_lights.m"
  MR_Word precompute_lights__V_21_21,
#line 127 "precompute_lights.m"
  MR_Word * precompute_lights__V_20_20);
#line 256 "precompute_lights.m"
static MR_Word MR_CALL precompute_lights__bounding_sphere_2_f_0(
#line 256 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1);
#line 249 "precompute_lights.m"
static /* final */ const MR_Float precompute_lights__float_9_0_1;
#line 249 "precompute_lights.m"
static /* final */ const MR_Float precompute_lights__float_9_0_2;
#line 249 "precompute_lights.m"
static /* final */ const MR_Float precompute_lights__float_9_0_3;
#line 249 "precompute_lights.m"
static /* final */ const MR_Box precompute_lights__const_9_0_4_V_47_47[3];
#line 228 "precompute_lights.m"
static bool MR_CALL precompute_lights__single_is_clear_4_p_0(
#line 228 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 228 "precompute_lights.m"
  MR_Float precompute_lights__HeadVar__2_2,
#line 228 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__3_3,
#line 228 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__4_4);
#line 215 "precompute_lights.m"
static bool MR_CALL precompute_lights__is_clear_4_p_0(
#line 215 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 215 "precompute_lights.m"
  MR_Float precompute_lights__HeadVar__2_2,
#line 215 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__3_3,
#line 215 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__4_4);
#line 183 "precompute_lights.m"
static void MR_CALL precompute_lights__calc_light_list_5_p_0(
#line 183 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 183 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__2_2,
#line 183 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__3_3,
#line 183 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__4_4,
#line 183 "precompute_lights.m"
  MR_Word * precompute_lights__HeadVar__5_5);
#line 67 "precompute_lights.m"
static void MR_CALL precompute_lights__object_list_2_p_0(
#line 67 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 67 "precompute_lights.m"
  MR_Word * precompute_lights__HeadVar__2_2);
#line 50 "precompute_lights.m"
static void MR_CALL precompute_lights__space_tree_node_list_2_p_0(
#line 50 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 50 "precompute_lights.m"
  MR_Word * precompute_lights__HeadVar__2_2);



const MR_TypeCtorInfo_Struct precompute_lights__precompute_lights__type_ctor_info_bounding_sphere_0 = {
		(MR_Integer) 0,
		((MR_Box) (precompute_lights____Unify____bounding_sphere_0_0)),
		((MR_Box) (precompute_lights____Unify____bounding_sphere_0_0)),
		((MR_Box) (precompute_lights____Compare____bounding_sphere_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "precompute_lights",
		(MR_String) "bounding_sphere",
		(MR_Integer) 4,
		{
		(MR_Box) precompute_lights__precompute_lights__du_name_ordered_bounding_sphere_0},
		{
		(MR_Box) precompute_lights__precompute_lights__du_ptag_ordered_bounding_sphere_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
static const MR_DuFunctorDescPtr precompute_lights__precompute_lights__du_name_ordered_bounding_sphere_0[1] = {
		(&precompute_lights__precompute_lights__du_functor_desc_bounding_sphere_0_0)};
static const MR_DuFunctorDesc precompute_lights__precompute_lights__du_functor_desc_bounding_sphere_0_0 = {
		(MR_String) "bsphere",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		precompute_lights__precompute_lights__field_types_bounding_sphere_0_0,
		precompute_lights__precompute_lights__field_names_bounding_sphere_0_0,
		(MR_Box) NULL};
static const MR_ConstString precompute_lights__precompute_lights__field_names_bounding_sphere_0_0[2] = {
		(MR_String) "centre",
		(MR_String) "radius"};
static const MR_PseudoTypeInfo precompute_lights__precompute_lights__field_types_bounding_sphere_0_0[2] = {
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuPtagLayout precompute_lights__precompute_lights__du_ptag_ordered_bounding_sphere_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		precompute_lights__precompute_lights__du_stag_ordered_bounding_sphere_0_0}};
static const MR_DuFunctorDescPtr precompute_lights__precompute_lights__du_stag_ordered_bounding_sphere_0_0[1] = {
		(&precompute_lights__precompute_lights__du_functor_desc_bounding_sphere_0_0)};

#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL precompute_lights__filter__ho9__ua0_4_p_in__list_0(
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_16_16,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Float precompute_lights__V_15_15,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_14_14,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__HeadVar__2_2,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__3_3,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__4_4)
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool precompute_lights__succeeded;

#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((precompute_lights__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
      {
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        *precompute_lights__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        *precompute_lights__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
      }
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
        MR_Word precompute_lights__H_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__2_2, (MR_Integer) 0)));
        MR_Word precompute_lights__T_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word precompute_lights__L1_11_11;
        MR_Word precompute_lights__M1_12_12;

#line 205 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 205 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          precompute_lights__filter__ho9__ua0_4_p_in__list_0(precompute_lights__V_16_16, precompute_lights__V_15_15, precompute_lights__V_14_14, precompute_lights__T_8_8, &precompute_lights__L1_11_11, &precompute_lights__M1_12_12);
        }
#line 197 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 197 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          precompute_lights__succeeded = precompute_lights__single_is_clear_4_p_0(precompute_lights__V_16_16, precompute_lights__V_15_15, precompute_lights__V_14_14, precompute_lights__H_7_7);
        }
#line 201 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        if (precompute_lights__succeeded)
          {
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            {
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              *precompute_lights__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__3_3, 0) = ((MR_Box) (precompute_lights__H_7_7));
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__3_3, 1) = ((MR_Box) (precompute_lights__L1_11_11));
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            }
#line 200 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            *precompute_lights__HeadVar__4_4 = precompute_lights__M1_12_12;
          }
#line 201 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        else
          {
#line 202 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            *precompute_lights__HeadVar__3_3 = precompute_lights__L1_11_11;
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            {
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              *precompute_lights__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__4_4, 0) = ((MR_Box) (precompute_lights__H_7_7));
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__4_4, 1) = ((MR_Box) (precompute_lights__M1_12_12));
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            }
          }
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL precompute_lights__filter__ho8__ua0_4_p_in__list_0(
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_16_16,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Float precompute_lights__V_15_15,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_14_14,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__HeadVar__2_2,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__3_3,
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__4_4)
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool precompute_lights__succeeded;

#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((precompute_lights__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
      {
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        *precompute_lights__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        *precompute_lights__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
      }
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
        MR_Word precompute_lights__H_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__2_2, (MR_Integer) 0)));
        MR_Word precompute_lights__T_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word precompute_lights__L1_11_11;
        MR_Word precompute_lights__M1_12_12;

#line 205 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 205 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          precompute_lights__filter__ho8__ua0_4_p_in__list_0(precompute_lights__V_16_16, precompute_lights__V_15_15, precompute_lights__V_14_14, precompute_lights__T_8_8, &precompute_lights__L1_11_11, &precompute_lights__M1_12_12);
        }
#line 197 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 197 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          precompute_lights__succeeded = precompute_lights__is_clear_4_p_0(precompute_lights__V_16_16, precompute_lights__V_15_15, precompute_lights__V_14_14, precompute_lights__H_7_7);
        }
#line 201 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        if (precompute_lights__succeeded)
          {
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            {
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              *precompute_lights__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__3_3, 0) = ((MR_Box) (precompute_lights__H_7_7));
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__3_3, 1) = ((MR_Box) (precompute_lights__L1_11_11));
#line 199 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            }
#line 200 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            *precompute_lights__HeadVar__4_4 = precompute_lights__M1_12_12;
          }
#line 201 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        else
          {
#line 202 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            *precompute_lights__HeadVar__3_3 = precompute_lights__L1_11_11;
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            {
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              *precompute_lights__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__4_4, 0) = ((MR_Box) (precompute_lights__H_7_7));
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__4_4, 1) = ((MR_Box) (precompute_lights__M1_12_12));
#line 203 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            }
          }
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 194 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 185 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL precompute_lights__map__ho6__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_13_13,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_12_12,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool precompute_lights__succeeded;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((precompute_lights__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *precompute_lights__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
        MR_Word precompute_lights__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__2_2, (MR_Integer) 0)));
        MR_Word precompute_lights__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word precompute_lights__H_8_8;
        MR_Word precompute_lights__T_9_9;

#line 130 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 130 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          precompute_lights__traverse_objects_4_p_0(precompute_lights__V_13_13, precompute_lights__V_12_12, precompute_lights__H0_6_6, &precompute_lights__H_8_8);
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          precompute_lights__map__ho6__ua0_3_p_in__list_0(precompute_lights__V_13_13, precompute_lights__V_12_12, precompute_lights__T0_7_7, &precompute_lights__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *precompute_lights__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__3_3, 0) = ((MR_Box) (precompute_lights__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__3_3, 1) = ((MR_Box) (precompute_lights__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL precompute_lights__map__ho4__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_13_13,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__V_12_12,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool precompute_lights__succeeded;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((precompute_lights__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *precompute_lights__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
        MR_Word precompute_lights__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__2_2, (MR_Integer) 0)));
        MR_Word precompute_lights__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word precompute_lights__H_8_8;
        MR_Word precompute_lights__T_9_9;

#line 130 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 130 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_p_0(precompute_lights__V_13_13, precompute_lights__V_12_12, precompute_lights__H0_6_6, &precompute_lights__H_8_8);
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          precompute_lights__map__ho4__ua0_3_p_in__list_0(precompute_lights__V_13_13, precompute_lights__V_12_12, precompute_lights__T0_7_7, &precompute_lights__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *precompute_lights__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__3_3, 0) = ((MR_Box) (precompute_lights__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__3_3, 1) = ((MR_Box) (precompute_lights__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL precompute_lights__map__ho7_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool precompute_lights__succeeded;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word precompute_lights__H0_6_6;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word precompute_lights__T0_7_7;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word precompute_lights__H_8_8;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word precompute_lights__T_9_9;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((precompute_lights__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *precompute_lights__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        precompute_lights__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__2_2, (MR_Integer) 0)));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        precompute_lights__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__2_2, (MR_Integer) 1)));
#line 130 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 130 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          precompute_lights__object_list_2_p_0(precompute_lights__H0_6_6, &precompute_lights__H_8_8);
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          precompute_lights__map__ho7_3_p_in__list_0(precompute_lights__T0_7_7, &precompute_lights__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *precompute_lights__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__3_3, 0) = ((MR_Box) (precompute_lights__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__3_3, 1) = ((MR_Box) (precompute_lights__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL precompute_lights__map__ho5_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word precompute_lights__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * precompute_lights__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool precompute_lights__succeeded;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word precompute_lights__H0_6_6;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word precompute_lights__T0_7_7;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word precompute_lights__H_8_8;
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word precompute_lights__T_9_9;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((precompute_lights__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *precompute_lights__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        precompute_lights__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__2_2, (MR_Integer) 0)));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        precompute_lights__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__2_2, (MR_Integer) 1)));
#line 130 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 130 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          precompute_lights__space_tree_node_list_2_p_0(precompute_lights__H0_6_6, &precompute_lights__H_8_8);
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          precompute_lights__map__ho5_3_p_in__list_0(precompute_lights__T0_7_7, &precompute_lights__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *precompute_lights__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__3_3, 0) = ((MR_Box) (precompute_lights__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__3_3, 1) = ((MR_Box) (precompute_lights__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 127 "precompute_lights.m"
static void MR_CALL precompute_lights__IntroducedFrom__pred__traverse_part__127__1_4_p_0(
#line 127 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__2_2,
#line 127 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__3_3,
#line 127 "precompute_lights.m"
  MR_Word precompute_lights__V_21_21,
#line 127 "precompute_lights.m"
  MR_Word * precompute_lights__V_20_20)
#line 127 "precompute_lights.m"
{
#line 127 "precompute_lights.m"
  {
#line 127 "precompute_lights.m"
    bool precompute_lights__succeeded;

#line 127 "precompute_lights.m"
    if ((MR_tag((MR_Word) precompute_lights__V_21_21) == MR_mktag((MR_Integer) 0)))
      {
        MR_Word precompute_lights__Tree0_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__V_21_21, (MR_Integer) 0)));
        MR_Word precompute_lights__Tree_18;
        MR_Word precompute_lights__Box_28 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__Tree0_17, (MR_Integer) 0)));
        MR_Float precompute_lights__Area_29 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__Tree0_17, (MR_Integer) 1)));
        MR_Word precompute_lights__Nodes0_30 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__Tree0_17, (MR_Integer) 2)));
        MR_Word precompute_lights__Nodes_33;

#line 121 "precompute_lights.m"
        {
#line 121 "precompute_lights.m"
          precompute_lights__map__ho4__ua0_3_p_in__list_0(precompute_lights__HeadVar__2_2, precompute_lights__HeadVar__3_3, precompute_lights__Nodes0_30, &precompute_lights__Nodes_33);
        }
#line 120 "precompute_lights.m"
        {
#line 120 "precompute_lights.m"
          precompute_lights__Tree_18 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "space_tree");
#line 120 "precompute_lights.m"
          MR_hl_field(MR_mktag(0), precompute_lights__Tree_18, 0) = ((MR_Box) (precompute_lights__Box_28));
#line 120 "precompute_lights.m"
          MR_hl_field(MR_mktag(0), precompute_lights__Tree_18, 1) = MR_box_float(precompute_lights__Area_29);
#line 120 "precompute_lights.m"
          MR_hl_field(MR_mktag(0), precompute_lights__Tree_18, 2) = ((MR_Box) (precompute_lights__Nodes_33));
#line 120 "precompute_lights.m"
        }
#line 130 "precompute_lights.m"
        {
#line 130 "precompute_lights.m"
          *precompute_lights__V_20_20 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "node");
#line 130 "precompute_lights.m"
          MR_hl_field(MR_mktag(0), *precompute_lights__V_20_20, 0) = ((MR_Box) (precompute_lights__Tree_18));
#line 130 "precompute_lights.m"
        }
      }
#line 127 "precompute_lights.m"
    else
#line 127 "precompute_lights.m"
      {
        MR_Word precompute_lights__A_13;
        MR_Float precompute_lights__B_14;
        MR_Word precompute_lights__Obj0_15;
        MR_Word precompute_lights__Obj_16;
        MR_Word precompute_lights__V_22_22;
        MR_Word precompute_lights__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__V_21_21, (MR_Integer) 0)));

#line 124 "precompute_lights.m"
        precompute_lights__A_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__V_23_23, (MR_Integer) 0)));
#line 124 "precompute_lights.m"
        precompute_lights__B_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__V_23_23, (MR_Integer) 1)));
#line 124 "precompute_lights.m"
        precompute_lights__Obj0_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__V_23_23, (MR_Integer) 2)));
#line 125 "precompute_lights.m"
        {
#line 125 "precompute_lights.m"
          precompute_lights__traverse_objects_4_p_0(precompute_lights__HeadVar__2_2, precompute_lights__HeadVar__3_3, precompute_lights__Obj0_15, &precompute_lights__Obj_16);
        }
#line 126 "precompute_lights.m"
        {
#line 126 "precompute_lights.m"
          precompute_lights__V_22_22 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "space_tree_object");
#line 126 "precompute_lights.m"
          MR_hl_field(MR_mktag(0), precompute_lights__V_22_22, 0) = ((MR_Box) (precompute_lights__A_13));
#line 126 "precompute_lights.m"
          MR_hl_field(MR_mktag(0), precompute_lights__V_22_22, 1) = MR_box_float(precompute_lights__B_14);
#line 126 "precompute_lights.m"
          MR_hl_field(MR_mktag(0), precompute_lights__V_22_22, 2) = ((MR_Box) (precompute_lights__Obj_16));
#line 126 "precompute_lights.m"
        }
#line 126 "precompute_lights.m"
        {
#line 126 "precompute_lights.m"
          *precompute_lights__V_20_20 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "leaf"));
#line 126 "precompute_lights.m"
          MR_hl_field(MR_mktag(1), *precompute_lights__V_20_20, 0) = ((MR_Box) (precompute_lights__V_22_22));
#line 126 "precompute_lights.m"
        }
#line 127 "precompute_lights.m"
      }
#line 127 "precompute_lights.m"
  }
#line 127 "precompute_lights.m"
}

#line 10 "precompute_lights.m"
void MR_CALL precompute_lights____Compare____bounding_sphere_0_0(
#line 10 "precompute_lights.m"
  MR_Word * precompute_lights__HeadVar__1_1,
#line 10 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__2_2,
#line 10 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__3_3)
#line 10 "precompute_lights.m"
{
  {
    bool precompute_lights__succeeded;
    MR_Word precompute_lights__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float precompute_lights__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word precompute_lights__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float precompute_lights__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__3_3, (MR_Integer) 1)));
#line 10 "precompute_lights.m"
    MR_Word precompute_lights__V_8_8;

#line 10 "precompute_lights.m"
    {
#line 10 "precompute_lights.m"
      vector____Compare____vector_0_0(&precompute_lights__V_8_8, precompute_lights__V_4_4, precompute_lights__V_6_6);
    }
#line 10 "precompute_lights.m"
    precompute_lights__succeeded = (precompute_lights__V_8_8 == (MR_Integer) 0);
#line 10 "precompute_lights.m"
    precompute_lights__succeeded = !(precompute_lights__succeeded);
#line 10 "precompute_lights.m"
    if (precompute_lights__succeeded)
#line 10 "precompute_lights.m"
      *precompute_lights__HeadVar__1_1 = precompute_lights__V_8_8;
#line 10 "precompute_lights.m"
    else
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        precompute_lights__succeeded = (precompute_lights__V_5_5 < precompute_lights__V_7_7);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (precompute_lights__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *precompute_lights__HeadVar__1_1 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            precompute_lights__succeeded = (precompute_lights__V_5_5 > precompute_lights__V_7_7);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (precompute_lights__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              *precompute_lights__HeadVar__1_1 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              *precompute_lights__HeadVar__1_1 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
  }
#line 10 "precompute_lights.m"
}

#line 10 "precompute_lights.m"
bool MR_CALL precompute_lights____Unify____bounding_sphere_0_0(
#line 10 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 10 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__2_2)
#line 10 "precompute_lights.m"
{
  {
    bool precompute_lights__succeeded;
    MR_Word precompute_lights__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float precompute_lights__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word precompute_lights__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float precompute_lights__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__2_2, (MR_Integer) 1)));

    {
      precompute_lights__succeeded = vector____Unify____vector_0_0(precompute_lights__V_3_3, precompute_lights__V_5_5);
    }
    if (precompute_lights__succeeded)
      precompute_lights__succeeded = (precompute_lights__V_4_4 == precompute_lights__V_6_6);
    return precompute_lights__succeeded;
  }
#line 10 "precompute_lights.m"
}

#line 256 "precompute_lights.m"
static MR_Word MR_CALL precompute_lights__bounding_sphere_2_f_0(
#line 256 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1)
#line 256 "precompute_lights.m"
{
  {
    bool precompute_lights__succeeded;
    MR_Word precompute_lights__HeadVar__2_2;
    MR_Word precompute_lights__P1_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word precompute_lights__P2_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word precompute_lights__Centre_5;
    MR_Float precompute_lights__Radius_6;
    MR_Float precompute_lights__V_7_7;
    MR_Float precompute_lights__V_8_8;
    MR_Float precompute_lights__V_10_10 = (MR_Float) 0.500000000000000;
    MR_Float precompute_lights__Ax_4_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__P1_3, (MR_Integer) 0)));
    MR_Float precompute_lights__Ay_5_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__P1_3, (MR_Integer) 1)));
    MR_Float precompute_lights__Az_6_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__P1_3, (MR_Integer) 2)));
    MR_Float precompute_lights__Bx_7_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__P2_4, (MR_Integer) 0)));
    MR_Float precompute_lights__By_8_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__P2_4, (MR_Integer) 1)));
    MR_Float precompute_lights__Bz_9_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__P2_4, (MR_Integer) 2)));
    MR_Float precompute_lights__V_10_18 = (precompute_lights__Ax_4_12 + precompute_lights__Bx_7_15);
    MR_Float precompute_lights__V_11_19 = (precompute_lights__Ay_5_13 + precompute_lights__By_8_16);
    MR_Float precompute_lights__V_12_20 = (precompute_lights__Az_6_14 + precompute_lights__Bz_9_17);
    MR_Float precompute_lights__V_8_25 = (precompute_lights__V_10_10 * precompute_lights__V_10_18);
    MR_Float precompute_lights__V_9_26 = (precompute_lights__V_10_10 * precompute_lights__V_11_19);
    MR_Float precompute_lights__V_10_27 = (precompute_lights__V_10_10 * precompute_lights__V_12_20);
    MR_Float precompute_lights__V_10_34;
    MR_Float precompute_lights__V_11_35;
    MR_Float precompute_lights__V_12_36;
    MR_Float precompute_lights__V_4_39;
    MR_Float precompute_lights__V_6_44;
    MR_Float precompute_lights__V_7_45;
    MR_Float precompute_lights__V_8_46;
    MR_Float precompute_lights__V_9_47;

#line 41 "vector.opt"
    {
#line 41 "vector.opt"
      precompute_lights__Centre_5 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 41 "vector.opt"
      MR_hl_field(MR_mktag(0), precompute_lights__Centre_5, 0) = MR_box_float(precompute_lights__V_8_25);
#line 41 "vector.opt"
      MR_hl_field(MR_mktag(0), precompute_lights__Centre_5, 1) = MR_box_float(precompute_lights__V_9_26);
#line 41 "vector.opt"
      MR_hl_field(MR_mktag(0), precompute_lights__Centre_5, 2) = MR_box_float(precompute_lights__V_10_27);
#line 41 "vector.opt"
    }
#line 8 "vector.opt"
    precompute_lights__V_10_34 = (precompute_lights__Ax_4_12 - precompute_lights__Bx_7_15);
#line 9 "vector.opt"
    precompute_lights__V_11_35 = (precompute_lights__Ay_5_13 - precompute_lights__By_8_16);
#line 10 "vector.opt"
    precompute_lights__V_12_36 = (precompute_lights__Az_6_14 - precompute_lights__Bz_9_17);
#line 28 "vector.opt"
    precompute_lights__V_8_46 = (precompute_lights__V_10_34 * precompute_lights__V_10_34);
#line 30 "vector.opt"
    precompute_lights__V_9_47 = (precompute_lights__V_11_35 * precompute_lights__V_11_35);
#line 27 "vector.opt"
    precompute_lights__V_6_44 = (precompute_lights__V_8_46 + precompute_lights__V_9_47);
#line 32 "vector.opt"
    precompute_lights__V_7_45 = (precompute_lights__V_12_36 * precompute_lights__V_12_36);
#line 26 "vector.opt"
    precompute_lights__V_4_39 = (precompute_lights__V_6_44 + precompute_lights__V_7_45);
#line 22 "vector.opt"
    {
#line 22 "vector.opt"
      precompute_lights__V_7_7 = mercury__math__sqrt_2_f_0(precompute_lights__V_4_39);
    }
#line 260 "precompute_lights.m"
    precompute_lights__V_8_8 = (MR_Float) 2.00000000000000;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL precompute_lights__bounding_sphere_2_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
precompute_lights__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (precompute_lights__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      precompute_lights__succeeded = (precompute_lights__V_8_8 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (precompute_lights__succeeded)
      {
        MR_Word precompute_lights__V_7_54;
        MR_String precompute_lights__V_8_55 = (MR_String) "float:'/'";
        MR_Word precompute_lights__TypeInfo_9_56;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        precompute_lights__V_7_54 = (MR_Word) precompute_lights__V_8_55;
        precompute_lights__TypeInfo_9_56 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(precompute_lights__TypeInfo_9_56, ((MR_Box) (precompute_lights__V_7_54)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      precompute_lights__Radius_6 = (precompute_lights__V_7_7 / precompute_lights__V_8_8);
#line 258 "precompute_lights.m"
    {
#line 258 "precompute_lights.m"
      precompute_lights__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "bsphere");
#line 258 "precompute_lights.m"
      MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__2_2, 0) = ((MR_Box) (precompute_lights__Centre_5));
#line 258 "precompute_lights.m"
      MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__2_2, 1) = MR_box_float(precompute_lights__Radius_6);
#line 258 "precompute_lights.m"
    }
    return precompute_lights__HeadVar__2_2;
  }
#line 256 "precompute_lights.m"
}
#line 249 "precompute_lights.m"
static /* final */ const MR_Float precompute_lights__float_9_0_1 = (MR_Float) 0.00000000000000;
#line 249 "precompute_lights.m"
static /* final */ const MR_Float precompute_lights__float_9_0_2 = (MR_Float) 0.00000000000000;
#line 249 "precompute_lights.m"
static /* final */ const MR_Float precompute_lights__float_9_0_3 = (MR_Float) 0.00000000000000;
#line 249 "precompute_lights.m"
static /* final */ const MR_Box precompute_lights__const_9_0_4_V_47_47[3] = {
		(MR_Box) &precompute_lights__float_9_0_1,
		(MR_Box) &precompute_lights__float_9_0_2,
		(MR_Box) &precompute_lights__float_9_0_3};

#line 228 "precompute_lights.m"
static bool MR_CALL precompute_lights__single_is_clear_4_p_0(
#line 228 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 228 "precompute_lights.m"
  MR_Float precompute_lights__HeadVar__2_2,
#line 228 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__3_3,
#line 228 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__4_4)
#line 228 "precompute_lights.m"
{
  {
    bool precompute_lights__succeeded;
    MR_Word precompute_lights__SCentre_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__4_4, (MR_Integer) 0)));
    MR_Float precompute_lights__SRadius_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__4_4, (MR_Integer) 1)));
    MR_Word precompute_lights__ObjOffset_10;
    MR_Word precompute_lights__LightOffset_11;
    MR_Word precompute_lights__LightwardsComponent_12;
    MR_Float precompute_lights__ObjClearance2_13;
    MR_Word precompute_lights__V_22_22;
    MR_Float precompute_lights__Ax_4_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__SCentre_8, (MR_Integer) 0)));
    MR_Float precompute_lights__Ay_5_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__SCentre_8, (MR_Integer) 1)));
    MR_Float precompute_lights__Az_6_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__SCentre_8, (MR_Integer) 2)));
    MR_Float precompute_lights__Bx_7_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float precompute_lights__By_8_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float precompute_lights__Bz_9_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float precompute_lights__V_10_29 = (precompute_lights__Ax_4_23 - precompute_lights__Bx_7_26);
    MR_Float precompute_lights__V_11_30 = (precompute_lights__Ay_5_24 - precompute_lights__By_8_27);
    MR_Float precompute_lights__V_12_31 = (precompute_lights__Az_6_25 - precompute_lights__Bz_9_28);
    MR_Float precompute_lights__Ax_4_66;
    MR_Float precompute_lights__Ay_5_67;
    MR_Float precompute_lights__Az_6_68;
    MR_Float precompute_lights__Bx_7_69;
    MR_Float precompute_lights__By_8_70;
    MR_Float precompute_lights__Bz_9_71;
    MR_Float precompute_lights__V_10_72;
    MR_Float precompute_lights__V_11_73;
    MR_Float precompute_lights__V_12_74;
    MR_Float precompute_lights__Ax_4_75;
    MR_Float precompute_lights__Ay_5_76;
    MR_Float precompute_lights__Az_6_77;
    MR_Float precompute_lights__Bx_7_78;
    MR_Float precompute_lights__By_8_79;
    MR_Float precompute_lights__Bz_9_80;
    MR_Float precompute_lights__V_10_81;
    MR_Float precompute_lights__V_11_82;
    MR_Float precompute_lights__V_12_83;
    MR_Float precompute_lights__V_6_88;
    MR_Float precompute_lights__V_7_89;
    MR_Float precompute_lights__V_8_90;
    MR_Float precompute_lights__V_9_91;
    MR_Float precompute_lights__ReqClearance_14;
    MR_Float precompute_lights__V_19_19;

#line 7 "vector.opt"
    {
#line 7 "vector.opt"
      precompute_lights__ObjOffset_10 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 7 "vector.opt"
      MR_hl_field(MR_mktag(0), precompute_lights__ObjOffset_10, 0) = MR_box_float(precompute_lights__V_10_29);
#line 7 "vector.opt"
      MR_hl_field(MR_mktag(0), precompute_lights__ObjOffset_10, 1) = MR_box_float(precompute_lights__V_11_30);
#line 7 "vector.opt"
      MR_hl_field(MR_mktag(0), precompute_lights__ObjOffset_10, 2) = MR_box_float(precompute_lights__V_12_31);
#line 7 "vector.opt"
    }
#line 245 "precompute_lights.m"
#line 245 "precompute_lights.m"
    switch (MR_tag((MR_Word) precompute_lights__HeadVar__3_3)) {
#line 245 "precompute_lights.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 245 "precompute_lights.m"
      case (MR_Integer) 0:
        {
          MR_Float precompute_lights__V_43_43;
          MR_Word precompute_lights__V_44_44;
          MR_Float precompute_lights__V_45_45;
          MR_Float precompute_lights__V_46_46;
          MR_Word precompute_lights__V_47_47;
          MR_Float precompute_lights__V_48_48;
          MR_Float precompute_lights__V_49_49;
          MR_Float precompute_lights__V_50_50;
          MR_Float precompute_lights__Ax_5_60;
          MR_Float precompute_lights__Ay_6_61;
          MR_Float precompute_lights__Az_7_62;
          MR_Float precompute_lights__V_8_63;
          MR_Float precompute_lights__V_9_64;
          MR_Float precompute_lights__V_10_65;

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL precompute_lights__single_is_clear_4_p_0
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Float Max;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
Max = ML_FLOAT_MAX;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
precompute_lights__V_45_45
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = Max;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
#line 249 "precompute_lights.m"
          precompute_lights__V_46_46 = (MR_Float) 2.00000000000000;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL precompute_lights__single_is_clear_4_p_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
precompute_lights__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
          if (precompute_lights__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            precompute_lights__succeeded = (precompute_lights__V_46_46 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          if (precompute_lights__succeeded)
            {
              MR_Word precompute_lights__V_7_56;
              MR_String precompute_lights__V_8_57 = (MR_String) "float:'/'";
              MR_Word precompute_lights__TypeInfo_9_58;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              precompute_lights__V_7_56 = (MR_Word) precompute_lights__V_8_57;
              precompute_lights__TypeInfo_9_58 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
                mercury__exception__throw_1_p_0(precompute_lights__TypeInfo_9_58, ((MR_Box) (precompute_lights__V_7_56)));
              }
            }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            precompute_lights__V_43_43 = (precompute_lights__V_45_45 / precompute_lights__V_46_46);
#line 249 "precompute_lights.m"
          precompute_lights__V_48_48 = (MR_Float) 0.00000000000000;
#line 249 "precompute_lights.m"
          precompute_lights__V_49_49 = (MR_Float) 0.00000000000000;
#line 249 "precompute_lights.m"
          precompute_lights__V_50_50 = (MR_Float) 0.00000000000000;
#line 249 "precompute_lights.m"
          precompute_lights__V_47_47 = (MR_Word) &precompute_lights__const_9_0_4_V_47_47;
#line 249 "precompute_lights.m"
          {
#line 249 "precompute_lights.m"
            precompute_lights__V_44_44 = renderer__light_unit_vector_3_f_0(precompute_lights__HeadVar__3_3, precompute_lights__V_47_47);
          }
#line 41 "vector.opt"
          precompute_lights__Ax_5_60 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__V_44_44, (MR_Integer) 0)));
#line 41 "vector.opt"
          precompute_lights__Ay_6_61 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__V_44_44, (MR_Integer) 1)));
#line 41 "vector.opt"
          precompute_lights__Az_7_62 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__V_44_44, (MR_Integer) 2)));
#line 42 "vector.opt"
          precompute_lights__V_8_63 = (precompute_lights__V_43_43 * precompute_lights__Ax_5_60);
#line 43 "vector.opt"
          precompute_lights__V_9_64 = (precompute_lights__V_43_43 * precompute_lights__Ay_6_61);
#line 44 "vector.opt"
          precompute_lights__V_10_65 = (precompute_lights__V_43_43 * precompute_lights__Az_7_62);
#line 41 "vector.opt"
          {
#line 41 "vector.opt"
            precompute_lights__V_22_22 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 41 "vector.opt"
            MR_hl_field(MR_mktag(0), precompute_lights__V_22_22, 0) = MR_box_float(precompute_lights__V_8_63);
#line 41 "vector.opt"
            MR_hl_field(MR_mktag(0), precompute_lights__V_22_22, 1) = MR_box_float(precompute_lights__V_9_64);
#line 41 "vector.opt"
            MR_hl_field(MR_mktag(0), precompute_lights__V_22_22, 2) = MR_box_float(precompute_lights__V_10_65);
#line 41 "vector.opt"
          }
        }
#line 245 "precompute_lights.m"
        break;
#line 245 "precompute_lights.m"
      case (MR_Integer) 1:
#line 245 "precompute_lights.m"
        {
#line 245 "precompute_lights.m"
          MR_Word precompute_lights__V_33_33;

#line 245 "precompute_lights.m"
          precompute_lights__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__3_3, (MR_Integer) 0)));
#line 245 "precompute_lights.m"
          precompute_lights__V_33_33 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__3_3, (MR_Integer) 1)));
#line 245 "precompute_lights.m"
        }
#line 245 "precompute_lights.m"
        break;
#line 245 "precompute_lights.m"
      case (MR_Integer) 2:
#line 246 "precompute_lights.m"
        {
#line 246 "precompute_lights.m"
          MR_Word precompute_lights__V_35_35;
#line 246 "precompute_lights.m"
          MR_Word precompute_lights__V_36_36;
#line 246 "precompute_lights.m"
          MR_Float precompute_lights__V_37_37;
#line 246 "precompute_lights.m"
          MR_Float precompute_lights__V_38_38;

#line 246 "precompute_lights.m"
          precompute_lights__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(2), precompute_lights__HeadVar__3_3, (MR_Integer) 0)));
#line 246 "precompute_lights.m"
          precompute_lights__V_35_35 = ((MR_Word) (MR_hl_field(MR_mktag(2), precompute_lights__HeadVar__3_3, (MR_Integer) 1)));
#line 246 "precompute_lights.m"
          precompute_lights__V_36_36 = ((MR_Word) (MR_hl_field(MR_mktag(2), precompute_lights__HeadVar__3_3, (MR_Integer) 2)));
#line 246 "precompute_lights.m"
          precompute_lights__V_37_37 = MR_unbox_float((MR_hl_field(MR_mktag(2), precompute_lights__HeadVar__3_3, (MR_Integer) 3)));
#line 246 "precompute_lights.m"
          precompute_lights__V_38_38 = MR_unbox_float((MR_hl_field(MR_mktag(2), precompute_lights__HeadVar__3_3, (MR_Integer) 4)));
#line 246 "precompute_lights.m"
        }
#line 245 "precompute_lights.m"
        break;
#line 245 "precompute_lights.m"
    }
#line 7 "vector.opt"
    precompute_lights__Ax_4_66 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__V_22_22, (MR_Integer) 0)));
#line 7 "vector.opt"
    precompute_lights__Ay_5_67 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__V_22_22, (MR_Integer) 1)));
#line 7 "vector.opt"
    precompute_lights__Az_6_68 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__V_22_22, (MR_Integer) 2)));
#line 7 "vector.opt"
    precompute_lights__Bx_7_69 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 0)));
#line 7 "vector.opt"
    precompute_lights__By_8_70 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 1)));
#line 7 "vector.opt"
    precompute_lights__Bz_9_71 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 2)));
#line 8 "vector.opt"
    precompute_lights__V_10_72 = (precompute_lights__Ax_4_66 - precompute_lights__Bx_7_69);
#line 9 "vector.opt"
    precompute_lights__V_11_73 = (precompute_lights__Ay_5_67 - precompute_lights__By_8_70);
#line 10 "vector.opt"
    precompute_lights__V_12_74 = (precompute_lights__Az_6_68 - precompute_lights__Bz_9_71);
#line 7 "vector.opt"
    {
#line 7 "vector.opt"
      precompute_lights__LightOffset_11 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 7 "vector.opt"
      MR_hl_field(MR_mktag(0), precompute_lights__LightOffset_11, 0) = MR_box_float(precompute_lights__V_10_72);
#line 7 "vector.opt"
      MR_hl_field(MR_mktag(0), precompute_lights__LightOffset_11, 1) = MR_box_float(precompute_lights__V_11_73);
#line 7 "vector.opt"
      MR_hl_field(MR_mktag(0), precompute_lights__LightOffset_11, 2) = MR_box_float(precompute_lights__V_12_74);
#line 7 "vector.opt"
    }
#line 233 "precompute_lights.m"
    {
#line 233 "precompute_lights.m"
      precompute_lights__LightwardsComponent_12 = vector__project_3_f_0(precompute_lights__ObjOffset_10, precompute_lights__LightOffset_11);
    }
#line 7 "vector.opt"
    precompute_lights__Ax_4_75 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__LightOffset_11, (MR_Integer) 0)));
#line 7 "vector.opt"
    precompute_lights__Ay_5_76 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__LightOffset_11, (MR_Integer) 1)));
#line 7 "vector.opt"
    precompute_lights__Az_6_77 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__LightOffset_11, (MR_Integer) 2)));
#line 7 "vector.opt"
    precompute_lights__Bx_7_78 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__LightwardsComponent_12, (MR_Integer) 0)));
#line 7 "vector.opt"
    precompute_lights__By_8_79 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__LightwardsComponent_12, (MR_Integer) 1)));
#line 7 "vector.opt"
    precompute_lights__Bz_9_80 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__LightwardsComponent_12, (MR_Integer) 2)));
#line 8 "vector.opt"
    precompute_lights__V_10_81 = (precompute_lights__Ax_4_75 - precompute_lights__Bx_7_78);
#line 9 "vector.opt"
    precompute_lights__V_11_82 = (precompute_lights__Ay_5_76 - precompute_lights__By_8_79);
#line 10 "vector.opt"
    precompute_lights__V_12_83 = (precompute_lights__Az_6_77 - precompute_lights__Bz_9_80);
#line 28 "vector.opt"
    precompute_lights__V_8_90 = (precompute_lights__V_10_81 * precompute_lights__V_10_81);
#line 30 "vector.opt"
    precompute_lights__V_9_91 = (precompute_lights__V_11_82 * precompute_lights__V_11_82);
#line 27 "vector.opt"
    precompute_lights__V_6_88 = (precompute_lights__V_8_90 + precompute_lights__V_9_91);
#line 32 "vector.opt"
    precompute_lights__V_7_89 = (precompute_lights__V_12_83 * precompute_lights__V_12_83);
#line 26 "vector.opt"
    precompute_lights__ObjClearance2_13 = (precompute_lights__V_6_88 + precompute_lights__V_7_89);
#line 236 "precompute_lights.m"
    precompute_lights__ReqClearance_14 = (precompute_lights__HeadVar__2_2 + precompute_lights__SRadius_9);
#line 237 "precompute_lights.m"
    precompute_lights__V_19_19 = (precompute_lights__ReqClearance_14 * precompute_lights__ReqClearance_14);
#line 237 "precompute_lights.m"
    precompute_lights__succeeded = (precompute_lights__ObjClearance2_13 > precompute_lights__V_19_19);
#line 238 "precompute_lights.m"
    if (!(precompute_lights__succeeded))
#line 238 "precompute_lights.m"
      {
        MR_Float precompute_lights__V_15_15;
        MR_Float precompute_lights__V_16_16;
        MR_Float precompute_lights__V_17_17;
        MR_Float precompute_lights__V_95_95;

#line 239 "precompute_lights.m"
        {
#line 239 "precompute_lights.m"
          precompute_lights__V_17_17 = vector__dot_3_f_0(precompute_lights__LightwardsComponent_12, precompute_lights__LightOffset_11);
        }
#line 239 "precompute_lights.m"
        precompute_lights__V_95_95 = (MR_Float) 0.00000000000000;
#line 239 "precompute_lights.m"
        precompute_lights__succeeded = (precompute_lights__V_17_17 < precompute_lights__V_95_95);
        if (precompute_lights__succeeded)
          {
#line 240 "precompute_lights.m"
            {
#line 240 "precompute_lights.m"
              precompute_lights__V_15_15 = vector__mag_2_f_0(precompute_lights__LightwardsComponent_12);
            }
#line 240 "precompute_lights.m"
            precompute_lights__V_16_16 = (precompute_lights__SRadius_9 + precompute_lights__HeadVar__2_2);
#line 240 "precompute_lights.m"
            precompute_lights__succeeded = (precompute_lights__V_15_15 > precompute_lights__V_16_16);
          }
#line 238 "precompute_lights.m"
      }
    return precompute_lights__succeeded;
  }
#line 228 "precompute_lights.m"
}

#line 215 "precompute_lights.m"
static bool MR_CALL precompute_lights__is_clear_4_p_0(
#line 215 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 215 "precompute_lights.m"
  MR_Float precompute_lights__HeadVar__2_2,
#line 215 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__3_3,
#line 215 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__4_4)
#line 215 "precompute_lights.m"
{
  {
    bool precompute_lights__succeeded;
    MR_Word precompute_lights__BadList_9;
    MR_Integer precompute_lights__Len_10;
    MR_Word precompute_lights__TypeInfo_15_15;
    MR_Integer precompute_lights__V_5_23;
    MR_Integer precompute_lights__V_24_24;
#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word precompute_lights__V_7_19;

#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      precompute_lights__filter__ho9__ua0_4_p_in__list_0(precompute_lights__HeadVar__1_1, precompute_lights__HeadVar__2_2, precompute_lights__HeadVar__4_4, precompute_lights__HeadVar__3_3, &precompute_lights__BadList_9, &precompute_lights__V_7_19);
    }
    precompute_lights__TypeInfo_15_15 = (MR_Word) (&precompute_lights__precompute_lights__type_ctor_info_bounding_sphere_0);
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    precompute_lights__V_5_23 = (MR_Integer) 0;
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      mercury__list__length_2_3_p_0(precompute_lights__TypeInfo_15_15, precompute_lights__BadList_9, precompute_lights__V_5_23, &precompute_lights__Len_10);
    }
#line 220 "precompute_lights.m"
    precompute_lights__V_24_24 = (MR_Integer) 1;
#line 220 "precompute_lights.m"
    precompute_lights__succeeded = (precompute_lights__Len_10 <= precompute_lights__V_24_24);
    return precompute_lights__succeeded;
  }
#line 215 "precompute_lights.m"
}

#line 183 "precompute_lights.m"
static void MR_CALL precompute_lights__calc_light_list_5_p_0(
#line 183 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 183 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__2_2,
#line 183 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__3_3,
#line 183 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__4_4,
#line 183 "precompute_lights.m"
  MR_Word * precompute_lights__HeadVar__5_5)
#line 183 "precompute_lights.m"
{
  {
    bool precompute_lights__succeeded;
    MR_Integer precompute_lights__Id_11 = ((MR_Integer) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word precompute_lights__Obj2_12 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word precompute_lights__LList0_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 2)));
#line 191 "precompute_lights.m"
    MR_Word precompute_lights___S_14;

#line 191 "precompute_lights.m"
    precompute_lights__succeeded = ((MR_tag((MR_Word) precompute_lights__Obj2_12) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__Obj2_12, (MR_Integer) 0))) == (MR_Integer) 1));
#line 191 "precompute_lights.m"
    if (((MR_tag((MR_Word) precompute_lights__Obj2_12) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__Obj2_12, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 191 "precompute_lights.m"
      precompute_lights___S_14 = ((MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__Obj2_12, (MR_Integer) 1)));
#line 193 "precompute_lights.m"
    if (precompute_lights__succeeded)
#line 192 "precompute_lights.m"
      *precompute_lights__HeadVar__5_5 = precompute_lights__HeadVar__1_1;
#line 193 "precompute_lights.m"
    else
      {
        MR_Word precompute_lights__BBox_15;
        MR_Word precompute_lights__Centre_19;
        MR_Float precompute_lights__Radius_20;
        MR_Word precompute_lights__LList1_21;
        MR_Word precompute_lights__LList2_22;
        MR_Word precompute_lights__V_24_24;
        MR_Word precompute_lights__TypeInfo_28_28;
#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        MR_Word precompute_lights__V_7_32;

#line 197 "precompute_lights.m"
        if ((precompute_lights__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 196 "precompute_lights.m"
          {
#line 196 "precompute_lights.m"
            precompute_lights__BBox_15 = space_partition__find_object_bounding_box_2_f_0(precompute_lights__HeadVar__1_1);
          }
#line 197 "precompute_lights.m"
        else
#line 197 "precompute_lights.m"
          {
            MR_Word precompute_lights__BBox0_17;
            MR_Word precompute_lights__Trans2_18;

#line 199 "precompute_lights.m"
            {
#line 199 "precompute_lights.m"
              precompute_lights__BBox0_17 = space_partition__find_object_bounding_box_2_f_0(precompute_lights__HeadVar__1_1);
            }
#line 200 "precompute_lights.m"
            {
#line 200 "precompute_lights.m"
              precompute_lights__Trans2_18 = renderer__maybe_transformation_to_trans_2_f_0(precompute_lights__HeadVar__2_2);
            }
#line 201 "precompute_lights.m"
            {
#line 201 "precompute_lights.m"
              precompute_lights__BBox_15 = space_partition__transform_bounding_box_3_f_0(precompute_lights__BBox0_17, precompute_lights__Trans2_18);
            }
#line 197 "precompute_lights.m"
          }
#line 203 "precompute_lights.m"
        {
#line 203 "precompute_lights.m"
          precompute_lights__V_24_24 = precompute_lights__bounding_sphere_2_f_0(precompute_lights__BBox_15);
        }
#line 203 "precompute_lights.m"
        precompute_lights__Centre_19 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__V_24_24, (MR_Integer) 0)));
#line 203 "precompute_lights.m"
        precompute_lights__Radius_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__V_24_24, (MR_Integer) 1)));
#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          precompute_lights__filter__ho8__ua0_4_p_in__list_0(precompute_lights__Centre_19, precompute_lights__Radius_20, precompute_lights__HeadVar__3_3, precompute_lights__HeadVar__4_4, &precompute_lights__LList1_21, &precompute_lights__V_7_32);
        }
        precompute_lights__TypeInfo_28_28 = (MR_Word) (&eval__eval__type_ctor_info_light_0);
#line 205 "precompute_lights.m"
        {
#line 205 "precompute_lights.m"
          mercury__list__append_3_p_1(precompute_lights__TypeInfo_28_28, precompute_lights__LList0_13, precompute_lights__LList1_21, &precompute_lights__LList2_22);
        }
#line 206 "precompute_lights.m"
        {
#line 206 "precompute_lights.m"
          *precompute_lights__HeadVar__5_5 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 206 "precompute_lights.m"
          MR_hl_field(MR_mktag(0), *precompute_lights__HeadVar__5_5, 0) = ((MR_Box) (precompute_lights__Id_11));
#line 206 "precompute_lights.m"
          MR_hl_field(MR_mktag(0), *precompute_lights__HeadVar__5_5, 1) = ((MR_Box) (precompute_lights__Obj2_12));
#line 206 "precompute_lights.m"
          MR_hl_field(MR_mktag(0), *precompute_lights__HeadVar__5_5, 2) = ((MR_Box) (precompute_lights__LList2_22));
#line 206 "precompute_lights.m"
        }
      }
  }
#line 183 "precompute_lights.m"
}

#line 139 "precompute_lights.m"
void MR_CALL precompute_lights__traverse_objects_4_p_0(
#line 139 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 139 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__2_2,
#line 139 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__3_3,
#line 139 "precompute_lights.m"
  MR_Word * precompute_lights__HeadVar__4_4)
#line 139 "precompute_lights.m"
{
#line 141 "precompute_lights.m"
  {
#line 141 "precompute_lights.m"
    bool precompute_lights__succeeded;

#line 141 "precompute_lights.m"
#line 141 "precompute_lights.m"
    switch (MR_tag((MR_Word) precompute_lights__HeadVar__3_3)) {
#line 141 "precompute_lights.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 141 "precompute_lights.m"
      case (MR_Integer) 3:
#line 141 "precompute_lights.m"
#line 141 "precompute_lights.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__HeadVar__3_3, (MR_Integer) 0)))) {
#line 141 "precompute_lights.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 141 "precompute_lights.m"
          case (MR_Integer) 0:
            {
              MR_Word precompute_lights__Obj1_22 = ((MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__HeadVar__3_3, (MR_Integer) 1)));
              MR_Word precompute_lights__Obj2_23 = ((MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__HeadVar__3_3, (MR_Integer) 2)));
              MR_Word precompute_lights__NewObject1_25;
              MR_Word precompute_lights__NewObject2_26;

#line 151 "precompute_lights.m"
              {
#line 151 "precompute_lights.m"
                precompute_lights__traverse_objects_4_p_0(precompute_lights__HeadVar__1_1, precompute_lights__HeadVar__2_2, precompute_lights__Obj1_22, &precompute_lights__NewObject1_25);
              }
#line 152 "precompute_lights.m"
              {
#line 152 "precompute_lights.m"
                precompute_lights__traverse_objects_4_p_0(precompute_lights__HeadVar__1_1, precompute_lights__HeadVar__2_2, precompute_lights__Obj2_23, &precompute_lights__NewObject2_26);
              }
#line 153 "precompute_lights.m"
              {
#line 153 "precompute_lights.m"
                *precompute_lights__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "intersect"));
#line 153 "precompute_lights.m"
                MR_hl_field(MR_mktag(3), *precompute_lights__HeadVar__4_4, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 0));
#line 153 "precompute_lights.m"
                MR_hl_field(MR_mktag(3), *precompute_lights__HeadVar__4_4, 1) = ((MR_Box) (precompute_lights__NewObject1_25));
#line 153 "precompute_lights.m"
                MR_hl_field(MR_mktag(3), *precompute_lights__HeadVar__4_4, 2) = ((MR_Box) (precompute_lights__NewObject2_26));
#line 153 "precompute_lights.m"
              }
            }
#line 141 "precompute_lights.m"
            break;
#line 141 "precompute_lights.m"
          case (MR_Integer) 1:
            {
              MR_Word precompute_lights__Obj1_29 = ((MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__HeadVar__3_3, (MR_Integer) 1)));
              MR_Word precompute_lights__Obj2_30 = ((MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__HeadVar__3_3, (MR_Integer) 2)));
              MR_Word precompute_lights__NewObject1_32;
              MR_Word precompute_lights__NewObject2_33;

#line 156 "precompute_lights.m"
              {
#line 156 "precompute_lights.m"
                precompute_lights__traverse_objects_4_p_0(precompute_lights__HeadVar__1_1, precompute_lights__HeadVar__2_2, precompute_lights__Obj1_29, &precompute_lights__NewObject1_32);
              }
#line 157 "precompute_lights.m"
              {
#line 157 "precompute_lights.m"
                precompute_lights__traverse_objects_4_p_0(precompute_lights__HeadVar__1_1, precompute_lights__HeadVar__2_2, precompute_lights__Obj2_30, &precompute_lights__NewObject2_33);
              }
#line 158 "precompute_lights.m"
              {
#line 158 "precompute_lights.m"
                *precompute_lights__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "difference"));
#line 158 "precompute_lights.m"
                MR_hl_field(MR_mktag(3), *precompute_lights__HeadVar__4_4, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 1));
#line 158 "precompute_lights.m"
                MR_hl_field(MR_mktag(3), *precompute_lights__HeadVar__4_4, 1) = ((MR_Box) (precompute_lights__NewObject1_32));
#line 158 "precompute_lights.m"
                MR_hl_field(MR_mktag(3), *precompute_lights__HeadVar__4_4, 2) = ((MR_Box) (precompute_lights__NewObject2_33));
#line 158 "precompute_lights.m"
              }
            }
#line 141 "precompute_lights.m"
            break;
#line 141 "precompute_lights.m"
        }
#line 141 "precompute_lights.m"
        break;
#line 141 "precompute_lights.m"
      case (MR_Integer) 0:
        {
          MR_Integer precompute_lights__Id_57 = ((MR_Integer) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__3_3, (MR_Integer) 0)));
          MR_Word precompute_lights__Obj2_58 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__3_3, (MR_Integer) 1)));
          MR_Word precompute_lights__LList0_59 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__3_3, (MR_Integer) 2)));
#line 191 "precompute_lights.m"
          MR_Word precompute_lights___S_60;

#line 191 "precompute_lights.m"
          precompute_lights__succeeded = ((MR_tag((MR_Word) precompute_lights__Obj2_58) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__Obj2_58, (MR_Integer) 0))) == (MR_Integer) 1));
#line 191 "precompute_lights.m"
          if (((MR_tag((MR_Word) precompute_lights__Obj2_58) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__Obj2_58, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 191 "precompute_lights.m"
            precompute_lights___S_60 = ((MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__Obj2_58, (MR_Integer) 1)));
#line 193 "precompute_lights.m"
          if (precompute_lights__succeeded)
#line 192 "precompute_lights.m"
            *precompute_lights__HeadVar__4_4 = precompute_lights__HeadVar__3_3;
#line 193 "precompute_lights.m"
          else
            {
              MR_Word precompute_lights__BBox_61;
              MR_Word precompute_lights__Centre_65;
              MR_Float precompute_lights__Radius_66;
              MR_Word precompute_lights__LList1_67;
              MR_Word precompute_lights__LList2_68;
              MR_Word precompute_lights__V_70_70;
              MR_Word precompute_lights__TypeInfo_28_74;
#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_Word precompute_lights__V_7_78;

#line 196 "precompute_lights.m"
              {
#line 196 "precompute_lights.m"
                precompute_lights__BBox_61 = space_partition__find_object_bounding_box_2_f_0(precompute_lights__HeadVar__3_3);
              }
#line 203 "precompute_lights.m"
              {
#line 203 "precompute_lights.m"
                precompute_lights__V_70_70 = precompute_lights__bounding_sphere_2_f_0(precompute_lights__BBox_61);
              }
#line 203 "precompute_lights.m"
              precompute_lights__Centre_65 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__V_70_70, (MR_Integer) 0)));
#line 203 "precompute_lights.m"
              precompute_lights__Radius_66 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__V_70_70, (MR_Integer) 1)));
#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              {
#line 191 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                precompute_lights__filter__ho8__ua0_4_p_in__list_0(precompute_lights__Centre_65, precompute_lights__Radius_66, precompute_lights__HeadVar__1_1, precompute_lights__HeadVar__2_2, &precompute_lights__LList1_67, &precompute_lights__V_7_78);
              }
              precompute_lights__TypeInfo_28_74 = (MR_Word) (&eval__eval__type_ctor_info_light_0);
#line 205 "precompute_lights.m"
              {
#line 205 "precompute_lights.m"
                mercury__list__append_3_p_1(precompute_lights__TypeInfo_28_74, precompute_lights__LList0_59, precompute_lights__LList1_67, &precompute_lights__LList2_68);
              }
#line 206 "precompute_lights.m"
              {
#line 206 "precompute_lights.m"
                *precompute_lights__HeadVar__4_4 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 206 "precompute_lights.m"
                MR_hl_field(MR_mktag(0), *precompute_lights__HeadVar__4_4, 0) = ((MR_Box) (precompute_lights__Id_57));
#line 206 "precompute_lights.m"
                MR_hl_field(MR_mktag(0), *precompute_lights__HeadVar__4_4, 1) = ((MR_Box) (precompute_lights__Obj2_58));
#line 206 "precompute_lights.m"
                MR_hl_field(MR_mktag(0), *precompute_lights__HeadVar__4_4, 2) = ((MR_Box) (precompute_lights__LList2_68));
#line 206 "precompute_lights.m"
              }
            }
        }
#line 141 "precompute_lights.m"
        break;
#line 141 "precompute_lights.m"
      case (MR_Integer) 1:
        {
          MR_Word precompute_lights__V_50_50 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__3_3, (MR_Integer) 1)));
          MR_Word precompute_lights__V_51_51 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__3_3, (MR_Integer) 0)));
          MR_Word precompute_lights__V_42_42;
#line 163 "precompute_lights.m"
          MR_Integer precompute_lights__V_39_39;
#line 163 "precompute_lights.m"
          MR_Word precompute_lights__V_40_40;
#line 163 "precompute_lights.m"
          MR_Word precompute_lights__V_41_41;

#line 163 "precompute_lights.m"
          precompute_lights__succeeded = (MR_tag((MR_Word) precompute_lights__V_51_51) == MR_mktag((MR_Integer) 0));
#line 163 "precompute_lights.m"
          if ((MR_tag((MR_Word) precompute_lights__V_51_51) == MR_mktag((MR_Integer) 0)))
#line 163 "precompute_lights.m"
            {
#line 163 "precompute_lights.m"
              precompute_lights__V_39_39 = ((MR_Integer) (MR_hl_field(MR_mktag(0), precompute_lights__V_51_51, (MR_Integer) 0)));
#line 163 "precompute_lights.m"
              precompute_lights__V_40_40 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__V_51_51, (MR_Integer) 1)));
#line 163 "precompute_lights.m"
              precompute_lights__V_41_41 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__V_51_51, (MR_Integer) 2)));
#line 163 "precompute_lights.m"
            }
          if (precompute_lights__succeeded)
            {
#line 164 "precompute_lights.m"
              {
#line 164 "precompute_lights.m"
                precompute_lights__V_42_42 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "yes"));
#line 164 "precompute_lights.m"
                MR_hl_field(MR_mktag(1), precompute_lights__V_42_42, 0) = ((MR_Box) (precompute_lights__V_50_50));
#line 164 "precompute_lights.m"
              }
#line 164 "precompute_lights.m"
              {
#line 164 "precompute_lights.m"
                precompute_lights__calc_light_list_5_p_0(precompute_lights__V_51_51, precompute_lights__V_42_42, precompute_lights__HeadVar__1_1, precompute_lights__HeadVar__2_2, precompute_lights__HeadVar__4_4);
              }
#line 164 "precompute_lights.m"
              precompute_lights__succeeded = TRUE;
            }
#line 141 "precompute_lights.m"
          if (!(precompute_lights__succeeded))
#line 141 "precompute_lights.m"
            {
              MR_String precompute_lights__V_48_48 = (MR_String) "traverse_objects can't handle complex transform objects!";
              MR_Word precompute_lights__TypeInfo_49_49 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 170 "precompute_lights.m"
              {
#line 170 "precompute_lights.m"
                mercury__exception__throw_1_p_0(precompute_lights__TypeInfo_49_49, ((MR_Box) (precompute_lights__V_48_48)));
#line 170 "precompute_lights.m"
                return;
              }
#line 141 "precompute_lights.m"
            }
        }
#line 141 "precompute_lights.m"
        break;
#line 141 "precompute_lights.m"
      case (MR_Integer) 2:
        {
          MR_Word precompute_lights__Obj1_15 = ((MR_Word) (MR_hl_field(MR_mktag(2), precompute_lights__HeadVar__3_3, (MR_Integer) 0)));
          MR_Word precompute_lights__Obj2_16 = ((MR_Word) (MR_hl_field(MR_mktag(2), precompute_lights__HeadVar__3_3, (MR_Integer) 1)));
          MR_Word precompute_lights__NewObject1_18;
          MR_Word precompute_lights__NewObject2_19;

#line 146 "precompute_lights.m"
          {
#line 146 "precompute_lights.m"
            precompute_lights__traverse_objects_4_p_0(precompute_lights__HeadVar__1_1, precompute_lights__HeadVar__2_2, precompute_lights__Obj1_15, &precompute_lights__NewObject1_18);
          }
#line 147 "precompute_lights.m"
          {
#line 147 "precompute_lights.m"
            precompute_lights__traverse_objects_4_p_0(precompute_lights__HeadVar__1_1, precompute_lights__HeadVar__2_2, precompute_lights__Obj2_16, &precompute_lights__NewObject2_19);
          }
#line 148 "precompute_lights.m"
          {
#line 148 "precompute_lights.m"
            *precompute_lights__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "union"));
#line 148 "precompute_lights.m"
            MR_hl_field(MR_mktag(2), *precompute_lights__HeadVar__4_4, 0) = ((MR_Box) (precompute_lights__NewObject1_18));
#line 148 "precompute_lights.m"
            MR_hl_field(MR_mktag(2), *precompute_lights__HeadVar__4_4, 1) = ((MR_Box) (precompute_lights__NewObject2_19));
#line 148 "precompute_lights.m"
          }
        }
#line 141 "precompute_lights.m"
        break;
#line 141 "precompute_lights.m"
    }
#line 141 "precompute_lights.m"
  }
#line 139 "precompute_lights.m"
}

#line 117 "precompute_lights.m"
void MR_CALL precompute_lights__traverse_part_4_p_0(
#line 117 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 117 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__2_2,
#line 117 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__3_3,
#line 117 "precompute_lights.m"
  MR_Word * precompute_lights__HeadVar__4_4)
#line 117 "precompute_lights.m"
{
  {
    bool precompute_lights__succeeded;
    MR_Word precompute_lights__Box_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float precompute_lights__Area_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word precompute_lights__Nodes0_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 2)));
    MR_Word precompute_lights__Nodes_10;

#line 121 "precompute_lights.m"
    {
#line 121 "precompute_lights.m"
      precompute_lights__map__ho4__ua0_3_p_in__list_0(precompute_lights__HeadVar__2_2, precompute_lights__HeadVar__3_3, precompute_lights__Nodes0_7, &precompute_lights__Nodes_10);
    }
#line 120 "precompute_lights.m"
    {
#line 120 "precompute_lights.m"
      *precompute_lights__HeadVar__4_4 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "space_tree");
#line 120 "precompute_lights.m"
      MR_hl_field(MR_mktag(0), *precompute_lights__HeadVar__4_4, 0) = ((MR_Box) (precompute_lights__Box_5));
#line 120 "precompute_lights.m"
      MR_hl_field(MR_mktag(0), *precompute_lights__HeadVar__4_4, 1) = MR_box_float(precompute_lights__Area_6);
#line 120 "precompute_lights.m"
      MR_hl_field(MR_mktag(0), *precompute_lights__HeadVar__4_4, 2) = ((MR_Box) (precompute_lights__Nodes_10));
#line 120 "precompute_lights.m"
    }
  }
#line 117 "precompute_lights.m"
}

#line 67 "precompute_lights.m"
static void MR_CALL precompute_lights__object_list_2_p_0(
#line 67 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 67 "precompute_lights.m"
  MR_Word * precompute_lights__HeadVar__2_2)
#line 67 "precompute_lights.m"
{
#line 69 "precompute_lights.m"
  {
#line 69 "precompute_lights.m"
    bool precompute_lights__succeeded;

#line 69 "precompute_lights.m"
#line 69 "precompute_lights.m"
    switch (MR_tag((MR_Word) precompute_lights__HeadVar__1_1)) {
#line 69 "precompute_lights.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 69 "precompute_lights.m"
      case (MR_Integer) 3:
#line 69 "precompute_lights.m"
#line 69 "precompute_lights.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__HeadVar__1_1, (MR_Integer) 0)))) {
#line 69 "precompute_lights.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 69 "precompute_lights.m"
          case (MR_Integer) 0:
            {
              MR_Word precompute_lights__Object1_15 = ((MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word precompute_lights__Object2_16 = ((MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__HeadVar__1_1, (MR_Integer) 2)));
              MR_Word precompute_lights__BSList1_18;
              MR_Word precompute_lights__BSList2_19;
              MR_Word precompute_lights__TypeInfo_40_40;

#line 80 "precompute_lights.m"
              {
#line 80 "precompute_lights.m"
                precompute_lights__object_list_2_p_0(precompute_lights__Object1_15, &precompute_lights__BSList1_18);
              }
#line 81 "precompute_lights.m"
              {
#line 81 "precompute_lights.m"
                precompute_lights__object_list_2_p_0(precompute_lights__Object2_16, &precompute_lights__BSList2_19);
              }
              precompute_lights__TypeInfo_40_40 = (MR_Word) (&precompute_lights__precompute_lights__type_ctor_info_bounding_sphere_0);
#line 82 "precompute_lights.m"
              {
#line 82 "precompute_lights.m"
                mercury__list__append_3_p_1(precompute_lights__TypeInfo_40_40, precompute_lights__BSList1_18, precompute_lights__BSList2_19, precompute_lights__HeadVar__2_2);
#line 82 "precompute_lights.m"
                return;
              }
            }
#line 69 "precompute_lights.m"
            break;
#line 69 "precompute_lights.m"
          case (MR_Integer) 1:
            {
              MR_Word precompute_lights__Object1_20 = ((MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word precompute_lights__Object2_21 = ((MR_Word) (MR_hl_field(MR_mktag(3), precompute_lights__HeadVar__1_1, (MR_Integer) 2)));
              MR_Word precompute_lights__BSList1_23;
              MR_Word precompute_lights__BSList2_24;
              MR_Word precompute_lights__TypeInfo_41_41;

#line 85 "precompute_lights.m"
              {
#line 85 "precompute_lights.m"
                precompute_lights__object_list_2_p_0(precompute_lights__Object1_20, &precompute_lights__BSList1_23);
              }
#line 86 "precompute_lights.m"
              {
#line 86 "precompute_lights.m"
                precompute_lights__object_list_2_p_0(precompute_lights__Object2_21, &precompute_lights__BSList2_24);
              }
              precompute_lights__TypeInfo_41_41 = (MR_Word) (&precompute_lights__precompute_lights__type_ctor_info_bounding_sphere_0);
#line 87 "precompute_lights.m"
              {
#line 87 "precompute_lights.m"
                mercury__list__append_3_p_1(precompute_lights__TypeInfo_41_41, precompute_lights__BSList1_23, precompute_lights__BSList2_24, precompute_lights__HeadVar__2_2);
#line 87 "precompute_lights.m"
                return;
              }
            }
#line 69 "precompute_lights.m"
            break;
#line 69 "precompute_lights.m"
        }
#line 69 "precompute_lights.m"
        break;
#line 69 "precompute_lights.m"
      case (MR_Integer) 0:
        {
          MR_Word precompute_lights__BS_4;
          MR_Word precompute_lights__Box_8;
          MR_Word precompute_lights__V_9_9 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));

#line 71 "precompute_lights.m"
          {
#line 71 "precompute_lights.m"
            precompute_lights__Box_8 = space_partition__find_object_bounding_box_2_f_0(precompute_lights__HeadVar__1_1);
          }
#line 72 "precompute_lights.m"
          {
#line 72 "precompute_lights.m"
            precompute_lights__BS_4 = precompute_lights__bounding_sphere_2_f_0(precompute_lights__Box_8);
          }
#line 69 "precompute_lights.m"
          {
#line 69 "precompute_lights.m"
            *precompute_lights__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 69 "precompute_lights.m"
            MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__2_2, 0) = ((MR_Box) (precompute_lights__BS_4));
#line 69 "precompute_lights.m"
            MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__2_2, 1) = ((MR_Box) (precompute_lights__V_9_9));
#line 69 "precompute_lights.m"
          }
        }
#line 69 "precompute_lights.m"
        break;
#line 69 "precompute_lights.m"
      case (MR_Integer) 1:
        {
          MR_Word precompute_lights__V_43_43 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__1_1, (MR_Integer) 1)));
          MR_Word precompute_lights__V_44_44 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word precompute_lights__BS_27;
          MR_Word precompute_lights__Box0_31;
          MR_Word precompute_lights__Trans2_32;
          MR_Word precompute_lights__Box_33;
          MR_Word precompute_lights__V_34_34;
          MR_Word precompute_lights__V_35_35;
#line 92 "precompute_lights.m"
          MR_Integer precompute_lights__V_28_28;
#line 92 "precompute_lights.m"
          MR_Word precompute_lights__V_29_29;
#line 92 "precompute_lights.m"
          MR_Word precompute_lights__V_30_30;

#line 92 "precompute_lights.m"
          precompute_lights__succeeded = (MR_tag((MR_Word) precompute_lights__V_44_44) == MR_mktag((MR_Integer) 0));
#line 92 "precompute_lights.m"
          if ((MR_tag((MR_Word) precompute_lights__V_44_44) == MR_mktag((MR_Integer) 0)))
#line 92 "precompute_lights.m"
            {
#line 92 "precompute_lights.m"
              precompute_lights__V_28_28 = ((MR_Integer) (MR_hl_field(MR_mktag(0), precompute_lights__V_44_44, (MR_Integer) 0)));
#line 92 "precompute_lights.m"
              precompute_lights__V_29_29 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__V_44_44, (MR_Integer) 1)));
#line 92 "precompute_lights.m"
              precompute_lights__V_30_30 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__V_44_44, (MR_Integer) 2)));
#line 92 "precompute_lights.m"
            }
          if (precompute_lights__succeeded)
            {
#line 91 "precompute_lights.m"
              precompute_lights__V_35_35 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 93 "precompute_lights.m"
              {
#line 93 "precompute_lights.m"
                precompute_lights__Box0_31 = space_partition__find_object_bounding_box_2_f_0(precompute_lights__V_44_44);
              }
#line 94 "precompute_lights.m"
              {
#line 94 "precompute_lights.m"
                precompute_lights__V_34_34 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "yes"));
#line 94 "precompute_lights.m"
                MR_hl_field(MR_mktag(1), precompute_lights__V_34_34, 0) = ((MR_Box) (precompute_lights__V_43_43));
#line 94 "precompute_lights.m"
              }
#line 94 "precompute_lights.m"
              {
#line 94 "precompute_lights.m"
                precompute_lights__Trans2_32 = renderer__maybe_transformation_to_trans_2_f_0(precompute_lights__V_34_34);
              }
#line 95 "precompute_lights.m"
              {
#line 95 "precompute_lights.m"
                precompute_lights__Box_33 = space_partition__transform_bounding_box_3_f_0(precompute_lights__Box0_31, precompute_lights__Trans2_32);
              }
#line 96 "precompute_lights.m"
              {
#line 96 "precompute_lights.m"
                precompute_lights__BS_27 = precompute_lights__bounding_sphere_2_f_0(precompute_lights__Box_33);
              }
#line 91 "precompute_lights.m"
              {
#line 91 "precompute_lights.m"
                *precompute_lights__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 91 "precompute_lights.m"
                MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__2_2, 0) = ((MR_Box) (precompute_lights__BS_27));
#line 91 "precompute_lights.m"
                MR_hl_field(MR_mktag(1), *precompute_lights__HeadVar__2_2, 1) = ((MR_Box) (precompute_lights__V_35_35));
#line 91 "precompute_lights.m"
              }
#line 91 "precompute_lights.m"
              precompute_lights__succeeded = TRUE;
            }
#line 69 "precompute_lights.m"
          if (!(precompute_lights__succeeded))
#line 69 "precompute_lights.m"
            {
              MR_String precompute_lights__V_38_38;
              MR_Word precompute_lights__TypeInfo_42_42;

#line 100 "precompute_lights.m"
              *precompute_lights__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 101 "precompute_lights.m"
              precompute_lights__V_38_38 = (MR_String) "object_list can't handle complex transform objects!";
              precompute_lights__TypeInfo_42_42 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
#line 101 "precompute_lights.m"
              {
#line 101 "precompute_lights.m"
                mercury__exception__throw_1_p_0(precompute_lights__TypeInfo_42_42, ((MR_Box) (precompute_lights__V_38_38)));
#line 101 "precompute_lights.m"
                return;
              }
#line 69 "precompute_lights.m"
            }
        }
#line 69 "precompute_lights.m"
        break;
#line 69 "precompute_lights.m"
      case (MR_Integer) 2:
        {
          MR_Word precompute_lights__Object1_10 = ((MR_Word) (MR_hl_field(MR_mktag(2), precompute_lights__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word precompute_lights__Object2_11 = ((MR_Word) (MR_hl_field(MR_mktag(2), precompute_lights__HeadVar__1_1, (MR_Integer) 1)));
          MR_Word precompute_lights__BSList1_13;
          MR_Word precompute_lights__BSList2_14;
          MR_Word precompute_lights__TypeInfo_39_39;

#line 75 "precompute_lights.m"
          {
#line 75 "precompute_lights.m"
            precompute_lights__object_list_2_p_0(precompute_lights__Object1_10, &precompute_lights__BSList1_13);
          }
#line 76 "precompute_lights.m"
          {
#line 76 "precompute_lights.m"
            precompute_lights__object_list_2_p_0(precompute_lights__Object2_11, &precompute_lights__BSList2_14);
          }
          precompute_lights__TypeInfo_39_39 = (MR_Word) (&precompute_lights__precompute_lights__type_ctor_info_bounding_sphere_0);
#line 77 "precompute_lights.m"
          {
#line 77 "precompute_lights.m"
            mercury__list__append_3_p_1(precompute_lights__TypeInfo_39_39, precompute_lights__BSList1_13, precompute_lights__BSList2_14, precompute_lights__HeadVar__2_2);
#line 77 "precompute_lights.m"
            return;
          }
        }
#line 69 "precompute_lights.m"
        break;
#line 69 "precompute_lights.m"
    }
#line 69 "precompute_lights.m"
  }
#line 67 "precompute_lights.m"
}

#line 50 "precompute_lights.m"
static void MR_CALL precompute_lights__space_tree_node_list_2_p_0(
#line 50 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 50 "precompute_lights.m"
  MR_Word * precompute_lights__HeadVar__2_2)
#line 50 "precompute_lights.m"
{
#line 58 "precompute_lights.m"
  {
#line 58 "precompute_lights.m"
    bool precompute_lights__succeeded;

#line 58 "precompute_lights.m"
    if ((MR_tag((MR_Word) precompute_lights__HeadVar__1_1) == MR_mktag((MR_Integer) 0)))
      {
        MR_Word precompute_lights__Tree_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 0)));
        MR_Word precompute_lights__Nodes_12 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__Tree_9, (MR_Integer) 2)));
        MR_Word precompute_lights__ObjectLists_14;
        MR_Word precompute_lights__TypeInfo_15_22;
#line 46 "precompute_lights.m"
        MR_Word precompute_lights___Pt_10 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__Tree_9, (MR_Integer) 0)));
#line 46 "precompute_lights.m"
        MR_Float precompute_lights___N_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__Tree_9, (MR_Integer) 1)));

#line 47 "precompute_lights.m"
        {
#line 47 "precompute_lights.m"
          precompute_lights__map__ho5_3_p_in__list_0(precompute_lights__Nodes_12, &precompute_lights__ObjectLists_14);
        }
        precompute_lights__TypeInfo_15_22 = (MR_Word) (&precompute_lights__precompute_lights__type_ctor_info_bounding_sphere_0);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          mercury__list__condense_2_p_0(precompute_lights__TypeInfo_15_22, precompute_lights__ObjectLists_14, precompute_lights__HeadVar__2_2);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          return;
        }
      }
#line 58 "precompute_lights.m"
    else
#line 58 "precompute_lights.m"
      {
        MR_Word precompute_lights__SpaceObj_5 = ((MR_Word) (MR_hl_field(MR_mktag(1), precompute_lights__HeadVar__1_1, (MR_Integer) 0)));
        MR_Word precompute_lights__Object_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__SpaceObj_5, (MR_Integer) 2)));
#line 56 "precompute_lights.m"
        MR_Word precompute_lights__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__SpaceObj_5, (MR_Integer) 0)));
#line 56 "precompute_lights.m"
        MR_Float precompute_lights__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__SpaceObj_5, (MR_Integer) 1)));

#line 57 "precompute_lights.m"
        {
#line 57 "precompute_lights.m"
          precompute_lights__object_list_2_p_0(precompute_lights__Object_8, precompute_lights__HeadVar__2_2);
#line 57 "precompute_lights.m"
          return;
        }
#line 58 "precompute_lights.m"
      }
#line 58 "precompute_lights.m"
  }
#line 50 "precompute_lights.m"
}

#line 22 "precompute_lights.m"
void MR_CALL precompute_lights__pre_compute_lighting_4_p_0(
#line 22 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 22 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__2_2,
#line 22 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__3_3,
#line 22 "precompute_lights.m"
  MR_Word * precompute_lights__HeadVar__4_4)
#line 22 "precompute_lights.m"
{
  {
    bool precompute_lights__succeeded;
    MR_Word precompute_lights__Part_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word precompute_lights__Objs_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word precompute_lights__NewPart_10;
    MR_Word precompute_lights__NewObjs_11;
    MR_Word precompute_lights__Box_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__Part_5, (MR_Integer) 0)));
    MR_Float precompute_lights__Area_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__Part_5, (MR_Integer) 1)));
    MR_Word precompute_lights__Nodes0_19 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__Part_5, (MR_Integer) 2)));
    MR_Word precompute_lights__Nodes_22;

#line 121 "precompute_lights.m"
    {
#line 121 "precompute_lights.m"
      precompute_lights__map__ho4__ua0_3_p_in__list_0(precompute_lights__HeadVar__2_2, precompute_lights__HeadVar__3_3, precompute_lights__Nodes0_19, &precompute_lights__Nodes_22);
    }
#line 120 "precompute_lights.m"
    {
#line 120 "precompute_lights.m"
      precompute_lights__NewPart_10 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "space_tree");
#line 120 "precompute_lights.m"
      MR_hl_field(MR_mktag(0), precompute_lights__NewPart_10, 0) = ((MR_Box) (precompute_lights__Box_17));
#line 120 "precompute_lights.m"
      MR_hl_field(MR_mktag(0), precompute_lights__NewPart_10, 1) = MR_box_float(precompute_lights__Area_18);
#line 120 "precompute_lights.m"
      MR_hl_field(MR_mktag(0), precompute_lights__NewPart_10, 2) = ((MR_Box) (precompute_lights__Nodes_22));
#line 120 "precompute_lights.m"
    }
#line 111 "precompute_lights.m"
    {
#line 111 "precompute_lights.m"
      precompute_lights__map__ho6__ua0_3_p_in__list_0(precompute_lights__HeadVar__2_2, precompute_lights__HeadVar__3_3, precompute_lights__Objs_6, &precompute_lights__NewObjs_11);
    }
#line 112 "precompute_lights.m"
    {
#line 112 "precompute_lights.m"
      *precompute_lights__HeadVar__4_4 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "scene");
#line 112 "precompute_lights.m"
      MR_hl_field(MR_mktag(0), *precompute_lights__HeadVar__4_4, 0) = ((MR_Box) (precompute_lights__NewPart_10));
#line 112 "precompute_lights.m"
      MR_hl_field(MR_mktag(0), *precompute_lights__HeadVar__4_4, 1) = ((MR_Box) (precompute_lights__NewObjs_11));
#line 112 "precompute_lights.m"
    }
  }
#line 22 "precompute_lights.m"
}

#line 16 "precompute_lights.m"
void MR_CALL precompute_lights__scene_list_2_p_0(
#line 16 "precompute_lights.m"
  MR_Word precompute_lights__HeadVar__1_1,
#line 16 "precompute_lights.m"
  MR_Word * precompute_lights__HeadVar__2_2)
#line 16 "precompute_lights.m"
{
  {
    bool precompute_lights__succeeded;
    MR_Word precompute_lights__Part_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word precompute_lights__Objs_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word precompute_lights__Tmp_6;
    MR_Word precompute_lights__L1_7;
    MR_Word precompute_lights__L2_8;
    MR_Word precompute_lights__TypeInfo_16_16;
    MR_Word precompute_lights__TypeInfo_17_17;
    MR_Word precompute_lights__Nodes_20;
    MR_Word precompute_lights__ObjectLists_22;
    MR_Word precompute_lights__TypeInfo_15_30;
#line 46 "precompute_lights.m"
    MR_Word precompute_lights___Pt_18;
#line 46 "precompute_lights.m"
    MR_Float precompute_lights___N_19;

#line 37 "precompute_lights.m"
    {
#line 37 "precompute_lights.m"
      precompute_lights__map__ho7_3_p_in__list_0(precompute_lights__Objs_4, &precompute_lights__Tmp_6);
    }
    precompute_lights__TypeInfo_16_16 = (MR_Word) (&precompute_lights__precompute_lights__type_ctor_info_bounding_sphere_0);
#line 38 "precompute_lights.m"
    {
#line 38 "precompute_lights.m"
      mercury__list__condense_2_p_0(precompute_lights__TypeInfo_16_16, precompute_lights__Tmp_6, &precompute_lights__L1_7);
    }
#line 46 "precompute_lights.m"
    precompute_lights___Pt_18 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__Part_3, (MR_Integer) 0)));
#line 46 "precompute_lights.m"
    precompute_lights___N_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), precompute_lights__Part_3, (MR_Integer) 1)));
#line 46 "precompute_lights.m"
    precompute_lights__Nodes_20 = ((MR_Word) (MR_hl_field(MR_mktag(0), precompute_lights__Part_3, (MR_Integer) 2)));
#line 47 "precompute_lights.m"
    {
#line 47 "precompute_lights.m"
      precompute_lights__map__ho5_3_p_in__list_0(precompute_lights__Nodes_20, &precompute_lights__ObjectLists_22);
    }
    precompute_lights__TypeInfo_15_30 = (MR_Word) (&precompute_lights__precompute_lights__type_ctor_info_bounding_sphere_0);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      mercury__list__condense_2_p_0(precompute_lights__TypeInfo_15_30, precompute_lights__ObjectLists_22, &precompute_lights__L2_8);
    }
    precompute_lights__TypeInfo_17_17 = (MR_Word) (&precompute_lights__precompute_lights__type_ctor_info_bounding_sphere_0);
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      mercury__list__append_3_p_1(precompute_lights__TypeInfo_17_17, precompute_lights__L1_7, precompute_lights__L2_8, precompute_lights__HeadVar__2_2);
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      return;
    }
  }
#line 16 "precompute_lights.m"
}

void mercury__precompute_lights__init(void)
{
}

void mercury__precompute_lights__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&precompute_lights__precompute_lights__type_ctor_info_bounding_sphere_0);
}

void mercury__precompute_lights__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module precompute_lights. */
