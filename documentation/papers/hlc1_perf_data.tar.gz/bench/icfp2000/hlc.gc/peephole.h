/*
** Automatically generated from `peephole.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module peephole. */
/* :- interface. */

#ifndef MR_HEADER_GUARD_peephole
#define MR_HEADER_GUARD_peephole

#ifdef __cplusplus
extern "C" {
#endif

#include "mercury.h"


#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#include <string.h>
#include <stdio.h>

#include "mercury_string.h"	/* for MR_allocate_aligned_string*() etc. */
#include "mercury_tags.h"	/* for MR_list_cons*() */

#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#ifdef USE_GCC_GLOBAL_REGISTERS
	/*
	** GNU C version egcs-1.1.2 crashes with `fixed or forbidden
	** register spilled' in grade asm_fast.gc.tr.debug
	** if we write this inline.
	*/
	static void MR_set_char(MR_String str, MR_Integer ind, MR_Char ch)
	{
		str[ind] = ch;
	}
#else
	#define MR_set_char(str, ind, ch) \
		((str)[ind] = (ch))
#endif

#line 14 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


#include "mercury_deep_copy.h"

#ifdef CONSERVATIVE_GC
  /* for conservative GC, shallow copies suffice */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		NewVal = OldVal;					\
	} while (0)
#else
  /*
  ** Note that we need to save/restore the MR_hp register, if it
  ** is transient, before/after calling MR_deep_copy().
  */
  #define MR_PARTIAL_DEEP_COPY(SolutionsHeapPtr,			\
  		OldVar, NewVal, TypeInfo_for_T)				\
  	do {								\
		MR_save_transient_hp();					\
		NewVal = MR_deep_copy(&OldVal, (MR_TypeInfo) TypeInfo_for_T,\
				(const MR_Word *) SolutionsHeapPtr,	\
				MR_ENGINE(MR_eng_solutions_heap_zone)->top);\
		MR_restore_transient_hp();				\
	} while (0)
#endif


#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"

#include "mercury_heap.h"	/* for MR_incr_hp_msg() etc. */
#include "mercury_misc.h"	/* for MR_fatal_error() */
#include "mercury_string.h"	/* for MR_make_aligned_string() */

#line 47 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_TYPECTORDESC_GUARD
#define ML_TYPECTORDESC_GUARD

/*
** Values of type `std_util:type_desc' are represented the same way as
** values of type `private_builtin:type_info' (this representation is
** documented in compiler/polymorphism.m). Some parts of the library
** (e.g. the gc initialization code) depend on this.
** The C type corresponding to these Mercury types is `MR_TypeInfo'.
**
** Values of type `std_util:type_ctor_desc' are not guaranteed to be
** represented the same way as values of type `private_builtin:type_ctor_info'.
** The representations *are* in fact identical for first order types, but they
** differ for higher order and tuple types. Instead of a type_ctor_desc
** being a structure containing a pointer to the type_ctor_info for pred/0
** or func/0 and an arity, we have a single small encoded integer. This
** integer is four times the arity, plus zero, one or two; plus zero encodes a
** tuple, plus one encodes a predicate, plus two encodes a function.
** The maximum arity that can be encoded is given by MR_MAX_VARIABLE_ARITY
** (see below).
** The C type corresponding to std_util:type_ctor_desc is `MR_TypeCtorDesc'.
*/

/*
** Declare the MR_TypeCtorDesc ADT.
**
** Note that `struct MR_TypeCtorDesc_Struct' is deliberately left undefined.
** MR_TypeCtorDesc is declared as a pointer to a dummy structure only
** in order to allow the C compiler to catch errors in which things other
** than MR_TypeCtorDescs are given as arguments to macros that depend on their
** arguments being MR_TypeCtorDescs. The actual value is either a small integer
** or a pointer to a MR_TypeCtorInfo_Struct structure, as described above.
*/
typedef struct MR_TypeCtorDesc_Struct *MR_TypeCtorDesc;

/*
** The maximum arity that can be encoded should be set to twice the maximum
** number of general purpose registers, since an predicate or function having
** more arguments that this would run out of registers when passing the input
** arguments, or the output arguments, or both.
**
** XXX When tuples were added this was reduced to be the maximum number
** of general purpose registers, to reduce the probability that the
** `small' integers for higher-order and tuple types are confused with
** type_ctor_info pointers. This still allows higher-order terms with
** 1024 arguments, which is more than ../LIMITATIONS promises.
*/
#define MR_MAX_VARIABLE_ARITY         MR_MAX_VIRTUAL_REG

/*
** Constructors for the MR_TypeCtorDesc ADT
*/

#define MR_TYPECTOR_DESC_MAKE_PRED(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4) )
#define MR_TYPECTOR_DESC_MAKE_FUNC(Arity)                                       ( (MR_TypeCtorDesc) ((Arity) * 4 + 1) )
#define MR_TYPECTOR_DESC_MAKE_TUPLE(Arity)                                      ( (MR_TypeCtorDesc) ((Arity) * 4 + 2) )
#define MR_TYPECTOR_DESC_MAKE_FIXED_ARITY(type_ctor_info)                       ( MR_CHECK_EXPR_TYPE(type_ctor_info, MR_TypeCtorInfo),                    (MR_TypeCtorDesc) type_ctor_info )

/*
** Access macros for the MR_TypeCtor ADT.
**
** The MR_TYPECTOR_DESC_GET_VA_* macros should only be called if
** MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns true.
** The MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO() macro
** should only be called if MR_TYPECTOR_DESC_IS_VARIABLE_ARITY() returns false.
*/
#define MR_TYPECTOR_DESC_IS_VARIABLE_ARITY(T)                                   ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) <= (4 * MR_MAX_VARIABLE_ARITY + 2) )
#define MR_TYPECTOR_DESC_GET_FIXED_ARITY_TYPE_CTOR_INFO(T)                      ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_TypeCtorInfo) (T) )
#define MR_TYPECTOR_DESC_GET_VA_ARITY(T)                                        ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_Unsigned) (T) / 4 )
#define MR_TYPECTOR_DESC_GET_VA_NAME(T)                                         ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) (((MR_Unsigned) (T) % 4 == 0)                                ? "pred"                                                              : (((MR_Unsigned) (T) % 4 == 1)                                             ? "func"                                                              : "{}" )) )
#define MR_TYPECTOR_DESC_GET_VA_MODULE_NAME(T)                                  ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 (MR_ConstString) "builtin" )
#define MR_TYPECTOR_DESC_GET_VA_TYPE_CTOR_INFO(T)                               ( MR_CHECK_EXPR_TYPE(T, MR_TypeCtorDesc),                                 ((MR_Unsigned) (T) % 4 == 0)                                                  ? MR_TYPE_CTOR_INFO_HO_PRED                                             : (((MR_Unsigned) (T) % 4 == 1)                                            ? MR_TYPE_CTOR_INFO_HO_FUNC                                             : MR_TYPE_CTOR_INFO_TUPLE ) )

#endif /* ML_TYPECTORDESC_GUARD */


#line 126 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef ML_CONSTRUCT_INFO_GUARD
#define ML_CONSTRUCT_INFO_GUARD

typedef struct ML_Construct_Info_Struct {
    MR_ConstString          functor_name;
    MR_Integer              arity;
    const MR_PseudoTypeInfo *arg_pseudo_type_infos;
    MR_ConstString          *arg_names;
    MR_TypeCtorRep          type_ctor_rep;
    union {
        const MR_EnumFunctorDesc  *enum_functor_desc;
        const MR_NotagFunctorDesc *notag_functor_desc;
        const MR_DuFunctorDesc    *du_functor_desc;
    }                       functor_info;
} ML_Construct_Info;

#endif

extern  void            ML_type_ctor_and_args(MR_TypeInfo type_info,
                            bool collapse_equivalences,
                            MR_TypeCtorDesc *type_ctor_desc_ptr,
                            MR_Word *arg_type_info_list_ptr);
extern  int     	    ML_get_num_functors(MR_TypeInfo type_info);
extern	MR_Word		    ML_type_params_vector_to_list(int arity,
                            MR_TypeInfoParams type_params);
extern	MR_Word		    ML_arg_name_vector_to_list(int arity,
                            MR_ConstString *arg_names);
extern	MR_Word		    ML_pseudo_type_info_vector_to_type_info_list(int arity,
                            MR_TypeInfoParams type_params,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  bool    	    ML_get_functors_check_range(int functor_number,
                            MR_TypeInfo type_info,
                            ML_Construct_Info *construct_info);
extern  void    	    ML_copy_arguments_from_list_to_vector(int arity,
                            MR_Word arg_list, MR_Word term_vector);
extern  bool    	    ML_typecheck_arguments(MR_TypeInfo type_info,
                            int arity, MR_Word arg_list,
                            const MR_PseudoTypeInfo *arg_pseudo_type_infos);
extern  MR_TypeInfo	    ML_make_type(int arity, MR_TypeCtorDesc type_ctor_desc,
				             MR_Word arg_type_list);

#line 170 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


extern	MR_TypeCtorDesc ML_make_type_ctor_desc(MR_TypeInfo type_info,
				MR_TypeCtorInfo type_ctor_info);


#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"


    #include <stdio.h>
	#include "mercury_library_types.h"		/* for MR_ArrayType */

#ifdef MR_DEEP_PROFILING
    #include "mercury_deep_profiling.h"
#endif

/* The `#ifndef ... #define ... #endif' guards against multiple inclusion */
#ifndef	ML_EXPAND_INFO_GUARD
#define	ML_EXPAND_INFO_GUARD

typedef struct {
    int                     num_extra_args;
    MR_Word                 *arg_values;
    MR_TypeInfo             *arg_type_infos;
    bool                    can_free_arg_type_infos;
} ML_Expand_Args_Fields;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
} ML_Expand_Functor_Args_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor;
    ML_Expand_Args_Fields   args;
    bool                    limit_reached;
} ML_Expand_Functor_Args_Limit_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    MR_ConstString          functor_only;
} ML_Expand_Functor_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    ML_Expand_Args_Fields   args_only;
} ML_Expand_Args_Only_Info;

typedef struct {
    bool                    non_canonical_type;
    int                     arity;
    bool                    chosen_index_exists;
    MR_Word                 *chosen_value_ptr;
    MR_TypeInfo             chosen_type_info;
} ML_Expand_Chosen_Arg_Only_Info;

    /* Prototypes */

extern  void    ML_expand_functor_args(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Args_Info *expand_info);

extern  void    ML_expand_functor_args_limit(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int max_arity,
                    ML_Expand_Functor_Args_Limit_Info *expand_info);

extern  void    ML_expand_functor_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Functor_Only_Info *expand_info);

extern  void    ML_expand_args_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr,
                    ML_Expand_Args_Only_Info *expand_info);

extern  void    ML_expand_chosen_arg_only(MR_TypeInfo type_info,
                    MR_Word *data_word_ptr, int chosen,
                    ML_Expand_Chosen_Arg_Only_Info *expand_info);

    /*
    ** NB. ML_arg() is also used by arg_ref and new_arg_ref
    ** in store.m, in trace/mercury_trace_vars.m, and in
    ** extras/trailed_update/tr_store.m.
    */
extern  bool    ML_arg(MR_TypeInfo type_info, MR_Word *term, int arg_index,
                    MR_TypeInfo *arg_type_info_ptr, MR_Word **argument_ptr);

    /*
    ** NB. ML_named_arg_num() is used in mercury_trace_vars.c.
    */
extern  bool    ML_named_arg_num(MR_TypeInfo type_info, MR_Word *term_ptr,
                    const char *arg_name, int *arg_num_ptr);

/*
** The following macros factor out the common parts of the various
** deconstruction predicates.
*/

    /*
    ** Check for attempts to deconstruct a non-canonical type.
    ** Such deconstructions must be cc_multi, which is why we treat
    ** violations of this as runtime errors in det deconstruction
    ** predicates.
    ** (There ought to be cc_multi versions of those predicates.)
    */
#define ML_abort_if_type_is_noncanonical(ei, predname)                  do {                                                                    if ((ei).non_canonical_type) {                                          MR_fatal_error("called " predname " for a type "                    "with a user-defined equality predicate");                }                                                               } while (0)

#endif

#define ML_deconstruct_get_functor(ei, functor_field, var)              do {                                                                    MR_make_aligned_string(MR_LVALUE_CAST(MR_ConstString, var),             (ei).functor_field);                                        } while (0)

#define ML_deconstruct_get_arity(ei, var)                               do {                                                                    var = (ei).arity;                                               } while (0)

#define ML_deconstruct_get_arg_list(ei, args_field, var)                do {                                                                    int     i;                                                                                                                              var = MR_list_empty_msg(MR_PROC_LABEL);                             i = (ei).arity;                                                                                                                         while (--i >= 0) {                                                      MR_Word arg;                                                                                                                                /* Create an argument on the heap */                            MR_new_univ_on_hp(arg,                                                  (ei).args_field.arg_type_infos[i],                                  (ei).args_field.arg_values[i +                                          (ei).args_field.num_extra_args]);                                                                                                   /* Join the argument to the front of the list */                var = MR_list_cons_msg(arg, var, MR_PROC_LABEL);                }                                                               } while (0)

    /*
    ** Free any arg_type_infos allocated by the ML_expand variant.
    ** Should be called after we have used them for the last time.
    */
#define ML_deconstruct_free_allocated_arg_type_infos(ei, args_field)    do {                                                                    if ((ei).args_field.can_free_arg_type_infos) {                          MR_GC_free((ei).args_field.arg_type_infos);                     }                                                               } while (0)


#line 16 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	extern MR_Word		ML_io_stream_names;
	extern MR_Word		ML_io_user_globals;
	#if 0
	  extern MR_Word	ML_io_ops_table;
	#endif

#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
#ifdef HAVE_SYS_STAT_H
	#include <sys/stat.h>
#endif

#line 31 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include "mercury_init.h"
#include "mercury_wrapper.h"
#include "mercury_type_info.h"
#include "mercury_library_types.h"
#include "mercury_file.h"
#include "mercury_heap.h"
#include "mercury_misc.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

#ifdef HAVE_SYS_WAIT
  #include <sys/wait.h>		/* for WIFEXITED, WEXITSTATUS, etc. */
#endif

extern MercuryFile mercury_stdin;
extern MercuryFile mercury_stdout;
extern MercuryFile mercury_stderr;
extern MercuryFile mercury_stdin_binary;
extern MercuryFile mercury_stdout_binary;
extern MercuryFile *mercury_current_text_input;
extern MercuryFile *mercury_current_text_output;
extern MercuryFile *mercury_current_binary_input;
extern MercuryFile *mercury_current_binary_output;

#define initial_io_state()		0	/* some random number */
#define update_io(r_src, r_dest)	((r_dest) = (r_src))
#define final_io_state(r)		((void)0)

void 		mercury_init_io(void);
MercuryFile*	mercury_open(const char *filename, const char *type);
void		mercury_io_error(MercuryFile* mf, const char *format, ...);
void		mercury_output_error(MercuryFile* mf);
void		mercury_print_string(MercuryFile* mf, const char *s);
void		mercury_print_binary_string(MercuryFile* mf, const char *s);
int		mercury_getc(MercuryFile* mf);
void		mercury_close(MercuryFile* mf);
int		ML_fprintf(MercuryFile* mf, const char *format, ...);

#line 106 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#ifdef HAVE_UNISTD_H
	#include <unistd.h>
#endif
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <fcntl.h>

	#define	MAX_TEMPNAME_TRIES	(6 * 4)

	extern long ML_io_tempnam_counter;

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"


#include <string.h>
#include <errno.h>

/*
** ML_maybe_make_err_msg(was_error, msg, procname, error_msg):
**	if `was_error' is true, then append `msg' and `strerror(errno)'
**	to give `error_msg'; otherwise, set `error_msg' to NULL.
**
** WARNING: this must only be called when the `hp' register is valid.
** That means it must only be called from procedures declared
** `will_not_call_mercury'.
**
** This is defined as a macro rather than a C function
** to avoid worrying about the `hp' register being
** invalidated by the function call.
** It also needs to be a macro because MR_incr_hp_atomic_msg()
** stringizes the procname argument.
*/
#define ML_maybe_make_err_msg(was_error, msg, procname, error_msg)	\
	do {								\
		char *errno_msg;					\
		size_t total_len;					\
		MR_Word tmp;						\
									\
		if (was_error) {					\
			errno_msg = strerror(errno);			\
			total_len = strlen(msg) + strlen(errno_msg);	\
			MR_incr_hp_atomic_msg(tmp,			\
				(total_len + sizeof(MR_Word))		\
					/ sizeof(MR_Word),		\
				procname,				\
				"string:string/0");			\
			(error_msg) = (char *)tmp;			\
			strcpy((error_msg), msg);			\
			strcat((error_msg), errno_msg);			\
		} else {						\
			(error_msg) = NULL;				\
		}							\
	} while(0)


#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#include <float.h>
	#include <math.h>


#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#define	ML_FLOAT_RADIX	FLT_RADIX	/* There is no DBL_RADIX. */

	#if defined USE_SINGLE_PREC_FLOAT
		#define	ML_FLOAT_MAX		FLT_MAX
		#define	ML_FLOAT_MIN		FLT_MIN
		#define	ML_FLOAT_EPSILON	FLT_EPSILON
		#define	ML_FLOAT_MANT_DIG	FLT_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	FLT_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	FLT_MAX_EXP
	#else
		#define	ML_FLOAT_MAX		DBL_MAX
		#define	ML_FLOAT_MIN		DBL_MIN
		#define	ML_FLOAT_EPSILON	DBL_EPSILON
		#define	ML_FLOAT_MANT_DIG	DBL_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	DBL_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	DBL_MAX_EXP
	#endif


#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif



extern const MR_TypeCtorInfo_Struct peephole__peephole__type_ctor_info_peephole_0;
#line 15 "peephole.m"
void MR_CALL peephole____Compare____peephole_0_0(
#line 15 "peephole.m"
  MR_Word * peephole__HeadVar__1_1,
#line 15 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 15 "peephole.m"
  MR_Word peephole__HeadVar__3_3);
#line 15 "peephole.m"
bool MR_CALL peephole____Unify____peephole_0_0(
#line 15 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 15 "peephole.m"
  MR_Word peephole__HeadVar__2_2);
#line 8 "peephole.m"
void MR_CALL peephole__peephole_2_p_0(
#line 8 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 8 "peephole.m"
  MR_Word * peephole__HeadVar__2_2);

void mercury__peephole__init(void);
void mercury__peephole__init_type_tables(void);
void mercury__peephole__init_debugger(void);

#ifdef __cplusplus
}
#endif

#endif /* MR_HEADER_GUARD_peephole */

/* :- end_interface peephole. */
