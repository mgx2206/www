/*
** Automatically generated from `peephole.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module peephole. */
/* :- implementation. */

#include "peephole.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.benchmarking.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "eval.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "globals.h"
#include "gml.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "op.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "peephole.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "renderer.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "space_partition.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "trans.h"
#include "transform_object.h"
#include "tree.h"
#include "mercury.tree234.h"
#include "mercury.varset.h"
#include "vector.h"



static const MR_NotagFunctorDesc peephole__peephole__notag_functor_desc_peephole_0;
static const MR_FO_PseudoTypeInfo_Struct2 peephole__tree234__type_info_tree234_2__type0_10___string_0__type0_18_gml__token_group_0;
#line 585 "peephole.m"
static bool MR_CALL peephole__boolean_token_2_f_1(
#line 585 "peephole.m"
  MR_Word * peephole__HeadVar__1_1,
#line 585 "peephole.m"
  MR_Word peephole__HeadVar__2_2);
#line 584 "peephole.m"
static MR_Word MR_CALL peephole__boolean_token_2_f_0(
#line 584 "peephole.m"
  MR_Word peephole__HeadVar__1_1);
#line 579 "peephole.m"
static bool MR_CALL peephole__integer_token_2_f_1(
#line 579 "peephole.m"
  MR_Integer * peephole__HeadVar__1_1,
#line 579 "peephole.m"
  MR_Word peephole__HeadVar__2_2);
#line 578 "peephole.m"
static MR_Word MR_CALL peephole__integer_token_2_f_0(
#line 578 "peephole.m"
  MR_Integer peephole__HeadVar__1_1);
#line 573 "peephole.m"
static bool MR_CALL peephole__real_token_2_f_1(
#line 573 "peephole.m"
  MR_Float * peephole__HeadVar__1_1,
#line 573 "peephole.m"
  MR_Word peephole__HeadVar__2_2);
#line 572 "peephole.m"
static MR_Word MR_CALL peephole__real_token_2_f_0(
#line 572 "peephole.m"
  MR_Float peephole__HeadVar__1_1);
#line 563 "peephole.m"
static bool MR_CALL peephole__top_two_integer_args_4_p_0(
#line 563 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 563 "peephole.m"
  MR_Integer * peephole__HeadVar__2_2,
#line 563 "peephole.m"
  MR_Integer * peephole__HeadVar__3_3,
#line 563 "peephole.m"
  MR_Word * peephole__HeadVar__4_4);
#line 555 "peephole.m"
static bool MR_CALL peephole__top_two_real_args_4_p_0(
#line 555 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 555 "peephole.m"
  MR_Float * peephole__HeadVar__2_2,
#line 555 "peephole.m"
  MR_Float * peephole__HeadVar__3_3,
#line 555 "peephole.m"
  MR_Word * peephole__HeadVar__4_4);
#line 546 "peephole.m"
static bool MR_CALL peephole__top_three_real_args_5_p_0(
#line 546 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 546 "peephole.m"
  MR_Float * peephole__HeadVar__2_2,
#line 546 "peephole.m"
  MR_Float * peephole__HeadVar__3_3,
#line 546 "peephole.m"
  MR_Float * peephole__HeadVar__4_4,
#line 546 "peephole.m"
  MR_Word * peephole__HeadVar__5_5);
#line 533 "peephole.m"
static bool MR_CALL peephole__remove_n_values_3_p_0(
#line 533 "peephole.m"
  MR_Integer peephole__HeadVar__1_1,
#line 533 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 533 "peephole.m"
  MR_Word * peephole__HeadVar__3_3);
#line 526 "peephole.m"
static bool MR_CALL peephole__remove_op_3_p_0(
#line 526 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 526 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 526 "peephole.m"
  MR_Word * peephole__HeadVar__3_3);
#line 511 "peephole.m"
static bool MR_CALL peephole__remove_single_3_p_0(
#line 511 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 511 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 511 "peephole.m"
  MR_Word * peephole__HeadVar__3_3);
#line 504 "peephole.m"
static bool MR_CALL peephole__remove_code_to_construct_one_value_2_p_0(
#line 504 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 504 "peephole.m"
  MR_Word * peephole__HeadVar__2_2);
#line 493 "peephole.m"
static bool MR_CALL peephole__constant_value_2_p_0(
#line 493 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 493 "peephole.m"
  MR_Word * peephole__HeadVar__2_2);
#line 481 "peephole.m"
static bool MR_CALL peephole__value_token_group_1_p_0(
#line 481 "peephole.m"
  MR_Word peephole__HeadVar__1_1);
#line 471 "peephole.m"
static bool MR_CALL peephole__chase_dups_2_p_0(
#line 471 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 471 "peephole.m"
  MR_Word * peephole__HeadVar__2_2);
#line 457 "peephole.m"
static bool MR_CALL peephole__constant_surface_function_2_p_0(
#line 457 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 457 "peephole.m"
  MR_Word * peephole__HeadVar__2_2);
#line 420 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_1_V_488_488[1];
#line 420 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_2_V_487_487[1];
#line 431 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_3_V_504_504[1];
#line 431 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_4_V_503_503[1];
#line 442 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_5_V_520_520[1];
#line 442 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_6_V_519_519[1];
#line 409 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_7_V_472_472[1];
#line 409 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_8_V_471_471[1];
#line 398 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_9_V_456_456[1];
#line 398 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_10_V_455_455[1];
#line 328 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_11_V_353_353[2];
#line 328 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_12_V_351_351[1];
#line 341 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_13_V_363_363[2];
#line 342 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_14_V_362_362[1];
#line 305 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_15_V_335_335[1];
#line 305 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_16_V_334_334[2];
#line 305 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_17_NewToken_323[1];
#line 132 "peephole.m"
static bool MR_CALL peephole__match_6_p_0(
#line 132 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 132 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 132 "peephole.m"
  MR_Word peephole__HeadVar__3_3,
#line 132 "peephole.m"
  MR_Word * peephole__HeadVar__4_4,
#line 132 "peephole.m"
  MR_Word peephole__HeadVar__5_5,
#line 132 "peephole.m"
  MR_Word * peephole__HeadVar__6_6);
#line 97 "peephole.m"
static MR_Word MR_CALL peephole__used_ids_2_f_0(
#line 97 "peephole.m"
  MR_Word peephole__HeadVar__1_1);
#line 83 "peephole.m"
static void MR_CALL peephole__search_4_p_0(
#line 83 "peephole.m"
  MR_String peephole__HeadVar__1_1,
#line 83 "peephole.m"
  MR_Word * peephole__HeadVar__2_2,
#line 83 "peephole.m"
  MR_Word peephole__HeadVar__3_3,
#line 83 "peephole.m"
  MR_Word * peephole__HeadVar__4_4);
#line 78 "peephole.m"
static void MR_CALL peephole__delete_3_p_0(
#line 78 "peephole.m"
  MR_String peephole__HeadVar__1_1,
#line 78 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 78 "peephole.m"
  MR_Word * peephole__HeadVar__3_3);
#line 71 "peephole.m"
static void MR_CALL peephole__insert_4_p_0(
#line 71 "peephole.m"
  MR_String peephole__HeadVar__1_1,
#line 71 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 71 "peephole.m"
  MR_Word peephole__HeadVar__3_3,
#line 71 "peephole.m"
  MR_Word * peephole__HeadVar__4_4);
#line 34 "peephole.m"
static void MR_CALL peephole__peephole_2_5_p_0(
#line 34 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 34 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 34 "peephole.m"
  MR_Word * peephole__HeadVar__3_3,
#line 34 "peephole.m"
  MR_Word peephole__HeadVar__4_4,
#line 34 "peephole.m"
  MR_Word * peephole__HeadVar__5_5);



const MR_TypeCtorInfo_Struct peephole__peephole__type_ctor_info_peephole_0 = {
		(MR_Integer) 0,
		((MR_Box) (peephole____Unify____peephole_0_0)),
		((MR_Box) (peephole____Unify____peephole_0_0)),
		((MR_Box) (peephole____Compare____peephole_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_NOTAG_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "peephole",
		(MR_String) "peephole",
		(MR_Integer) 4,
		{
		(MR_Box) (&peephole__peephole__notag_functor_desc_peephole_0)},
		{
		(MR_Box) (&peephole__peephole__notag_functor_desc_peephole_0)},
		(MR_Integer) 1,
		(MR_Integer) -1};
static const MR_NotagFunctorDesc peephole__peephole__notag_functor_desc_peephole_0 = {
		(MR_String) "state",
		(MR_PseudoTypeInfo) (&peephole__tree234__type_info_tree234_2__type0_10___string_0__type0_18_gml__token_group_0),
		(MR_String) "known_ids"};
static const MR_FO_PseudoTypeInfo_Struct2 peephole__tree234__type_info_tree234_2__type0_10___string_0__type0_18_gml__token_group_0 = {
		(&mercury__tree234__tree234__type_ctor_info_tree234_2),
		{
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0),
		(MR_PseudoTypeInfo) (&gml__gml__type_ctor_info_token_group_0)}};

#line 15 "peephole.m"
void MR_CALL peephole____Compare____peephole_0_0(
#line 15 "peephole.m"
  MR_Word * peephole__HeadVar__1_1,
#line 15 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 15 "peephole.m"
  MR_Word peephole__HeadVar__3_3)
#line 15 "peephole.m"
{
  {
    bool peephole__succeeded;
    MR_Word peephole__V_4_4 = (MR_Word) peephole__HeadVar__2_2;
    MR_Word peephole__V_5_5 = (MR_Word) peephole__HeadVar__3_3;
    MR_Word peephole__TypeInfo_6_6 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
    MR_Word peephole__TypeInfo_7_7 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 15 "peephole.m"
    {
#line 15 "peephole.m"
      mercury__tree234____Compare____tree234_2_0(peephole__TypeInfo_6_6, peephole__TypeInfo_7_7, peephole__HeadVar__1_1, peephole__V_4_4, peephole__V_5_5);
#line 15 "peephole.m"
      return;
    }
  }
#line 15 "peephole.m"
}

#line 15 "peephole.m"
bool MR_CALL peephole____Unify____peephole_0_0(
#line 15 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 15 "peephole.m"
  MR_Word peephole__HeadVar__2_2)
#line 15 "peephole.m"
{
  {
    bool peephole__succeeded;
    MR_Word peephole__V_3_3 = (MR_Word) peephole__HeadVar__1_1;
    MR_Word peephole__V_4_4 = (MR_Word) peephole__HeadVar__2_2;
    MR_Word peephole__TypeInfo_5_5 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
    MR_Word peephole__TypeInfo_6_6 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

    {
      return peephole__succeeded = mercury__tree234____Unify____tree234_2_0(peephole__TypeInfo_5_5, peephole__TypeInfo_6_6, peephole__V_3_3, peephole__V_4_4);
    }
    return peephole__succeeded;
  }
#line 15 "peephole.m"
}

#line 585 "peephole.m"
static bool MR_CALL peephole__boolean_token_2_f_1(
#line 585 "peephole.m"
  MR_Word * peephole__HeadVar__1_1,
#line 585 "peephole.m"
  MR_Word peephole__HeadVar__2_2)
#line 585 "peephole.m"
{
  {
    bool peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
    MR_Word peephole__V_4_4;

#line 587 "peephole.m"
    if ((MR_tag((MR_Word) peephole__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 587 "peephole.m"
      peephole__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__HeadVar__2_2, (MR_Integer) 0)));
    if (peephole__succeeded)
      {
#line 587 "peephole.m"
        peephole__succeeded = ((MR_tag((MR_Word) peephole__V_4_4) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_4_4, (MR_Integer) 0))) == (MR_Integer) 0));
#line 587 "peephole.m"
        if (((MR_tag((MR_Word) peephole__V_4_4) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_4_4, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 587 "peephole.m"
          *peephole__HeadVar__1_1 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_4_4, (MR_Integer) 1)));
      }
    return peephole__succeeded;
  }
#line 585 "peephole.m"
}

#line 584 "peephole.m"
static MR_Word MR_CALL peephole__boolean_token_2_f_0(
#line 584 "peephole.m"
  MR_Word peephole__HeadVar__1_1)
#line 584 "peephole.m"
{
  {
    bool peephole__succeeded;
    MR_Word peephole__HeadVar__2_2;
    MR_Word peephole__V_4_4;

#line 587 "peephole.m"
    {
#line 587 "peephole.m"
      peephole__V_4_4 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "boolean"));
#line 587 "peephole.m"
      MR_hl_field(MR_mktag(3), peephole__V_4_4, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 0));
#line 587 "peephole.m"
      MR_hl_field(MR_mktag(3), peephole__V_4_4, 1) = ((MR_Box) (peephole__HeadVar__1_1));
#line 587 "peephole.m"
    }
#line 587 "peephole.m"
    {
#line 587 "peephole.m"
      peephole__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "single_token");
#line 587 "peephole.m"
      MR_hl_field(MR_mktag(0), peephole__HeadVar__2_2, 0) = ((MR_Box) (peephole__V_4_4));
#line 587 "peephole.m"
    }
    return peephole__HeadVar__2_2;
  }
#line 584 "peephole.m"
}

#line 579 "peephole.m"
static bool MR_CALL peephole__integer_token_2_f_1(
#line 579 "peephole.m"
  MR_Integer * peephole__HeadVar__1_1,
#line 579 "peephole.m"
  MR_Word peephole__HeadVar__2_2)
#line 579 "peephole.m"
{
  {
    bool peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
    MR_Word peephole__V_4_4;
    MR_Word peephole__V_5_5;

#line 581 "peephole.m"
    if ((MR_tag((MR_Word) peephole__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 581 "peephole.m"
      peephole__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__HeadVar__2_2, (MR_Integer) 0)));
    if (peephole__succeeded)
      {
#line 581 "peephole.m"
        peephole__succeeded = ((MR_tag((MR_Word) peephole__V_4_4) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_4_4, (MR_Integer) 0))) == (MR_Integer) 1));
#line 581 "peephole.m"
        if (((MR_tag((MR_Word) peephole__V_4_4) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_4_4, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 581 "peephole.m"
          peephole__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_4_4, (MR_Integer) 1)));
        if (peephole__succeeded)
          {
#line 581 "peephole.m"
            peephole__succeeded = (MR_tag((MR_Word) peephole__V_5_5) == MR_mktag((MR_Integer) 0));
#line 581 "peephole.m"
            if ((MR_tag((MR_Word) peephole__V_5_5) == MR_mktag((MR_Integer) 0)))
#line 581 "peephole.m"
              *peephole__HeadVar__1_1 = ((MR_Integer) (MR_hl_field(MR_mktag(0), peephole__V_5_5, (MR_Integer) 0)));
          }
      }
    return peephole__succeeded;
  }
#line 579 "peephole.m"
}

#line 578 "peephole.m"
static MR_Word MR_CALL peephole__integer_token_2_f_0(
#line 578 "peephole.m"
  MR_Integer peephole__HeadVar__1_1)
#line 578 "peephole.m"
{
  {
    bool peephole__succeeded;
    MR_Word peephole__HeadVar__2_2;
    MR_Word peephole__V_4_4;
    MR_Word peephole__V_5_5;

#line 581 "peephole.m"
    {
#line 581 "peephole.m"
      peephole__V_5_5 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "integer");
#line 581 "peephole.m"
      MR_hl_field(MR_mktag(0), peephole__V_5_5, 0) = ((MR_Box) (peephole__HeadVar__1_1));
#line 581 "peephole.m"
    }
#line 581 "peephole.m"
    {
#line 581 "peephole.m"
      peephole__V_4_4 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "number"));
#line 581 "peephole.m"
      MR_hl_field(MR_mktag(3), peephole__V_4_4, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 1));
#line 581 "peephole.m"
      MR_hl_field(MR_mktag(3), peephole__V_4_4, 1) = ((MR_Box) (peephole__V_5_5));
#line 581 "peephole.m"
    }
#line 581 "peephole.m"
    {
#line 581 "peephole.m"
      peephole__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "single_token");
#line 581 "peephole.m"
      MR_hl_field(MR_mktag(0), peephole__HeadVar__2_2, 0) = ((MR_Box) (peephole__V_4_4));
#line 581 "peephole.m"
    }
    return peephole__HeadVar__2_2;
  }
#line 578 "peephole.m"
}

#line 573 "peephole.m"
static bool MR_CALL peephole__real_token_2_f_1(
#line 573 "peephole.m"
  MR_Float * peephole__HeadVar__1_1,
#line 573 "peephole.m"
  MR_Word peephole__HeadVar__2_2)
#line 573 "peephole.m"
{
  {
    bool peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
    MR_Word peephole__V_4_4;
    MR_Word peephole__V_5_5;

#line 575 "peephole.m"
    if ((MR_tag((MR_Word) peephole__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 575 "peephole.m"
      peephole__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__HeadVar__2_2, (MR_Integer) 0)));
    if (peephole__succeeded)
      {
#line 575 "peephole.m"
        peephole__succeeded = ((MR_tag((MR_Word) peephole__V_4_4) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_4_4, (MR_Integer) 0))) == (MR_Integer) 1));
#line 575 "peephole.m"
        if (((MR_tag((MR_Word) peephole__V_4_4) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_4_4, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 575 "peephole.m"
          peephole__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_4_4, (MR_Integer) 1)));
        if (peephole__succeeded)
          {
#line 575 "peephole.m"
            peephole__succeeded = (MR_tag((MR_Word) peephole__V_5_5) == MR_mktag((MR_Integer) 1));
#line 575 "peephole.m"
            if ((MR_tag((MR_Word) peephole__V_5_5) == MR_mktag((MR_Integer) 1)))
#line 575 "peephole.m"
              *peephole__HeadVar__1_1 = MR_unbox_float((MR_hl_field(MR_mktag(1), peephole__V_5_5, (MR_Integer) 0)));
          }
      }
    return peephole__succeeded;
  }
#line 573 "peephole.m"
}

#line 572 "peephole.m"
static MR_Word MR_CALL peephole__real_token_2_f_0(
#line 572 "peephole.m"
  MR_Float peephole__HeadVar__1_1)
#line 572 "peephole.m"
{
  {
    bool peephole__succeeded;
    MR_Word peephole__HeadVar__2_2;
    MR_Word peephole__V_4_4;
    MR_Word peephole__V_5_5;

#line 575 "peephole.m"
    {
#line 575 "peephole.m"
      peephole__V_5_5 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 575 "peephole.m"
      MR_hl_field(MR_mktag(1), peephole__V_5_5, 0) = MR_box_float(peephole__HeadVar__1_1);
#line 575 "peephole.m"
    }
#line 575 "peephole.m"
    {
#line 575 "peephole.m"
      peephole__V_4_4 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "number"));
#line 575 "peephole.m"
      MR_hl_field(MR_mktag(3), peephole__V_4_4, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 1));
#line 575 "peephole.m"
      MR_hl_field(MR_mktag(3), peephole__V_4_4, 1) = ((MR_Box) (peephole__V_5_5));
#line 575 "peephole.m"
    }
#line 575 "peephole.m"
    {
#line 575 "peephole.m"
      peephole__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "single_token");
#line 575 "peephole.m"
      MR_hl_field(MR_mktag(0), peephole__HeadVar__2_2, 0) = ((MR_Box) (peephole__V_4_4));
#line 575 "peephole.m"
    }
    return peephole__HeadVar__2_2;
  }
#line 572 "peephole.m"
}

#line 563 "peephole.m"
static bool MR_CALL peephole__top_two_integer_args_4_p_0(
#line 563 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 563 "peephole.m"
  MR_Integer * peephole__HeadVar__2_2,
#line 563 "peephole.m"
  MR_Integer * peephole__HeadVar__3_3,
#line 563 "peephole.m"
  MR_Word * peephole__HeadVar__4_4)
#line 563 "peephole.m"
{
  {
    bool peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 1));
    MR_Word peephole__ArgB_9;
    MR_Word peephole__ArgA_10;
    MR_Word peephole__V_11_11;
    MR_Word peephole__V_13_13;
    MR_Word peephole__V_14_14;
    MR_Word peephole__V_16_16;
    MR_Word peephole__V_17_17;

#line 567 "peephole.m"
    if ((MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 1)))
#line 567 "peephole.m"
      {
#line 567 "peephole.m"
        peephole__ArgB_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 0)));
#line 567 "peephole.m"
        peephole__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 1)));
#line 567 "peephole.m"
      }
    if (peephole__succeeded)
      {
#line 567 "peephole.m"
        peephole__succeeded = (MR_tag((MR_Word) peephole__V_11_11) == MR_mktag((MR_Integer) 1));
#line 567 "peephole.m"
        if ((MR_tag((MR_Word) peephole__V_11_11) == MR_mktag((MR_Integer) 1)))
#line 567 "peephole.m"
          {
#line 567 "peephole.m"
            peephole__ArgA_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_11_11, (MR_Integer) 0)));
#line 567 "peephole.m"
            *peephole__HeadVar__4_4 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_11_11, (MR_Integer) 1)));
#line 567 "peephole.m"
          }
        if (peephole__succeeded)
          {
#line 581 "peephole.m"
            peephole__succeeded = (MR_tag((MR_Word) peephole__ArgA_10) == MR_mktag((MR_Integer) 0));
#line 581 "peephole.m"
            if ((MR_tag((MR_Word) peephole__ArgA_10) == MR_mktag((MR_Integer) 0)))
#line 581 "peephole.m"
              peephole__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__ArgA_10, (MR_Integer) 0)));
            if (peephole__succeeded)
              {
#line 581 "peephole.m"
                peephole__succeeded = ((MR_tag((MR_Word) peephole__V_13_13) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_13_13, (MR_Integer) 0))) == (MR_Integer) 1));
#line 581 "peephole.m"
                if (((MR_tag((MR_Word) peephole__V_13_13) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_13_13, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 581 "peephole.m"
                  peephole__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_13_13, (MR_Integer) 1)));
                if (peephole__succeeded)
                  {
#line 581 "peephole.m"
                    peephole__succeeded = (MR_tag((MR_Word) peephole__V_14_14) == MR_mktag((MR_Integer) 0));
#line 581 "peephole.m"
                    if ((MR_tag((MR_Word) peephole__V_14_14) == MR_mktag((MR_Integer) 0)))
#line 581 "peephole.m"
                      *peephole__HeadVar__2_2 = ((MR_Integer) (MR_hl_field(MR_mktag(0), peephole__V_14_14, (MR_Integer) 0)));
                    if (peephole__succeeded)
                      {
#line 581 "peephole.m"
                        peephole__succeeded = (MR_tag((MR_Word) peephole__ArgB_9) == MR_mktag((MR_Integer) 0));
#line 581 "peephole.m"
                        if ((MR_tag((MR_Word) peephole__ArgB_9) == MR_mktag((MR_Integer) 0)))
#line 581 "peephole.m"
                          peephole__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__ArgB_9, (MR_Integer) 0)));
                        if (peephole__succeeded)
                          {
#line 581 "peephole.m"
                            peephole__succeeded = ((MR_tag((MR_Word) peephole__V_16_16) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 0))) == (MR_Integer) 1));
#line 581 "peephole.m"
                            if (((MR_tag((MR_Word) peephole__V_16_16) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 581 "peephole.m"
                              peephole__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 1)));
                            if (peephole__succeeded)
                              {
#line 581 "peephole.m"
                                peephole__succeeded = (MR_tag((MR_Word) peephole__V_17_17) == MR_mktag((MR_Integer) 0));
#line 581 "peephole.m"
                                if ((MR_tag((MR_Word) peephole__V_17_17) == MR_mktag((MR_Integer) 0)))
#line 581 "peephole.m"
                                  *peephole__HeadVar__3_3 = ((MR_Integer) (MR_hl_field(MR_mktag(0), peephole__V_17_17, (MR_Integer) 0)));
                              }
                          }
                      }
                  }
              }
          }
      }
    return peephole__succeeded;
  }
#line 563 "peephole.m"
}

#line 555 "peephole.m"
static bool MR_CALL peephole__top_two_real_args_4_p_0(
#line 555 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 555 "peephole.m"
  MR_Float * peephole__HeadVar__2_2,
#line 555 "peephole.m"
  MR_Float * peephole__HeadVar__3_3,
#line 555 "peephole.m"
  MR_Word * peephole__HeadVar__4_4)
#line 555 "peephole.m"
{
  {
    bool peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 1));
    MR_Word peephole__ArgB_9;
    MR_Word peephole__ArgA_10;
    MR_Word peephole__V_11_11;
    MR_Word peephole__V_13_13;
    MR_Word peephole__V_14_14;
    MR_Word peephole__V_16_16;
    MR_Word peephole__V_17_17;

#line 559 "peephole.m"
    if ((MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 1)))
#line 559 "peephole.m"
      {
#line 559 "peephole.m"
        peephole__ArgB_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 0)));
#line 559 "peephole.m"
        peephole__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 1)));
#line 559 "peephole.m"
      }
    if (peephole__succeeded)
      {
#line 559 "peephole.m"
        peephole__succeeded = (MR_tag((MR_Word) peephole__V_11_11) == MR_mktag((MR_Integer) 1));
#line 559 "peephole.m"
        if ((MR_tag((MR_Word) peephole__V_11_11) == MR_mktag((MR_Integer) 1)))
#line 559 "peephole.m"
          {
#line 559 "peephole.m"
            peephole__ArgA_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_11_11, (MR_Integer) 0)));
#line 559 "peephole.m"
            *peephole__HeadVar__4_4 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_11_11, (MR_Integer) 1)));
#line 559 "peephole.m"
          }
        if (peephole__succeeded)
          {
#line 575 "peephole.m"
            peephole__succeeded = (MR_tag((MR_Word) peephole__ArgA_10) == MR_mktag((MR_Integer) 0));
#line 575 "peephole.m"
            if ((MR_tag((MR_Word) peephole__ArgA_10) == MR_mktag((MR_Integer) 0)))
#line 575 "peephole.m"
              peephole__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__ArgA_10, (MR_Integer) 0)));
            if (peephole__succeeded)
              {
#line 575 "peephole.m"
                peephole__succeeded = ((MR_tag((MR_Word) peephole__V_13_13) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_13_13, (MR_Integer) 0))) == (MR_Integer) 1));
#line 575 "peephole.m"
                if (((MR_tag((MR_Word) peephole__V_13_13) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_13_13, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 575 "peephole.m"
                  peephole__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_13_13, (MR_Integer) 1)));
                if (peephole__succeeded)
                  {
#line 575 "peephole.m"
                    peephole__succeeded = (MR_tag((MR_Word) peephole__V_14_14) == MR_mktag((MR_Integer) 1));
#line 575 "peephole.m"
                    if ((MR_tag((MR_Word) peephole__V_14_14) == MR_mktag((MR_Integer) 1)))
#line 575 "peephole.m"
                      *peephole__HeadVar__2_2 = MR_unbox_float((MR_hl_field(MR_mktag(1), peephole__V_14_14, (MR_Integer) 0)));
                    if (peephole__succeeded)
                      {
#line 575 "peephole.m"
                        peephole__succeeded = (MR_tag((MR_Word) peephole__ArgB_9) == MR_mktag((MR_Integer) 0));
#line 575 "peephole.m"
                        if ((MR_tag((MR_Word) peephole__ArgB_9) == MR_mktag((MR_Integer) 0)))
#line 575 "peephole.m"
                          peephole__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__ArgB_9, (MR_Integer) 0)));
                        if (peephole__succeeded)
                          {
#line 575 "peephole.m"
                            peephole__succeeded = ((MR_tag((MR_Word) peephole__V_16_16) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 0))) == (MR_Integer) 1));
#line 575 "peephole.m"
                            if (((MR_tag((MR_Word) peephole__V_16_16) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 575 "peephole.m"
                              peephole__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 1)));
                            if (peephole__succeeded)
                              {
#line 575 "peephole.m"
                                peephole__succeeded = (MR_tag((MR_Word) peephole__V_17_17) == MR_mktag((MR_Integer) 1));
#line 575 "peephole.m"
                                if ((MR_tag((MR_Word) peephole__V_17_17) == MR_mktag((MR_Integer) 1)))
#line 575 "peephole.m"
                                  *peephole__HeadVar__3_3 = MR_unbox_float((MR_hl_field(MR_mktag(1), peephole__V_17_17, (MR_Integer) 0)));
                              }
                          }
                      }
                  }
              }
          }
      }
    return peephole__succeeded;
  }
#line 555 "peephole.m"
}

#line 546 "peephole.m"
static bool MR_CALL peephole__top_three_real_args_5_p_0(
#line 546 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 546 "peephole.m"
  MR_Float * peephole__HeadVar__2_2,
#line 546 "peephole.m"
  MR_Float * peephole__HeadVar__3_3,
#line 546 "peephole.m"
  MR_Float * peephole__HeadVar__4_4,
#line 546 "peephole.m"
  MR_Word * peephole__HeadVar__5_5)
#line 546 "peephole.m"
{
  {
    bool peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 1));
    MR_Word peephole__ArgC_11;
    MR_Word peephole__ArgB_12;
    MR_Word peephole__ArgA_13;
    MR_Word peephole__V_14_14;
    MR_Word peephole__V_15_15;
    MR_Word peephole__V_17_17;
    MR_Word peephole__V_18_18;
    MR_Word peephole__V_20_20;
    MR_Word peephole__V_21_21;
    MR_Word peephole__V_23_23;
    MR_Word peephole__V_24_24;

#line 550 "peephole.m"
    if ((MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 1)))
#line 550 "peephole.m"
      {
#line 550 "peephole.m"
        peephole__ArgC_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 0)));
#line 550 "peephole.m"
        peephole__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 1)));
#line 550 "peephole.m"
      }
    if (peephole__succeeded)
      {
#line 550 "peephole.m"
        peephole__succeeded = (MR_tag((MR_Word) peephole__V_14_14) == MR_mktag((MR_Integer) 1));
#line 550 "peephole.m"
        if ((MR_tag((MR_Word) peephole__V_14_14) == MR_mktag((MR_Integer) 1)))
#line 550 "peephole.m"
          {
#line 550 "peephole.m"
            peephole__ArgB_12 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_14_14, (MR_Integer) 0)));
#line 550 "peephole.m"
            peephole__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_14_14, (MR_Integer) 1)));
#line 550 "peephole.m"
          }
        if (peephole__succeeded)
          {
#line 550 "peephole.m"
            peephole__succeeded = (MR_tag((MR_Word) peephole__V_15_15) == MR_mktag((MR_Integer) 1));
#line 550 "peephole.m"
            if ((MR_tag((MR_Word) peephole__V_15_15) == MR_mktag((MR_Integer) 1)))
#line 550 "peephole.m"
              {
#line 550 "peephole.m"
                peephole__ArgA_13 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_15_15, (MR_Integer) 0)));
#line 550 "peephole.m"
                *peephole__HeadVar__5_5 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_15_15, (MR_Integer) 1)));
#line 550 "peephole.m"
              }
            if (peephole__succeeded)
              {
#line 575 "peephole.m"
                peephole__succeeded = (MR_tag((MR_Word) peephole__ArgA_13) == MR_mktag((MR_Integer) 0));
#line 575 "peephole.m"
                if ((MR_tag((MR_Word) peephole__ArgA_13) == MR_mktag((MR_Integer) 0)))
#line 575 "peephole.m"
                  peephole__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__ArgA_13, (MR_Integer) 0)));
                if (peephole__succeeded)
                  {
#line 575 "peephole.m"
                    peephole__succeeded = ((MR_tag((MR_Word) peephole__V_17_17) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_17_17, (MR_Integer) 0))) == (MR_Integer) 1));
#line 575 "peephole.m"
                    if (((MR_tag((MR_Word) peephole__V_17_17) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_17_17, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 575 "peephole.m"
                      peephole__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_17_17, (MR_Integer) 1)));
                    if (peephole__succeeded)
                      {
#line 575 "peephole.m"
                        peephole__succeeded = (MR_tag((MR_Word) peephole__V_18_18) == MR_mktag((MR_Integer) 1));
#line 575 "peephole.m"
                        if ((MR_tag((MR_Word) peephole__V_18_18) == MR_mktag((MR_Integer) 1)))
#line 575 "peephole.m"
                          *peephole__HeadVar__2_2 = MR_unbox_float((MR_hl_field(MR_mktag(1), peephole__V_18_18, (MR_Integer) 0)));
                        if (peephole__succeeded)
                          {
#line 575 "peephole.m"
                            peephole__succeeded = (MR_tag((MR_Word) peephole__ArgB_12) == MR_mktag((MR_Integer) 0));
#line 575 "peephole.m"
                            if ((MR_tag((MR_Word) peephole__ArgB_12) == MR_mktag((MR_Integer) 0)))
#line 575 "peephole.m"
                              peephole__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__ArgB_12, (MR_Integer) 0)));
                            if (peephole__succeeded)
                              {
#line 575 "peephole.m"
                                peephole__succeeded = ((MR_tag((MR_Word) peephole__V_20_20) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_20_20, (MR_Integer) 0))) == (MR_Integer) 1));
#line 575 "peephole.m"
                                if (((MR_tag((MR_Word) peephole__V_20_20) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_20_20, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 575 "peephole.m"
                                  peephole__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_20_20, (MR_Integer) 1)));
                                if (peephole__succeeded)
                                  {
#line 575 "peephole.m"
                                    peephole__succeeded = (MR_tag((MR_Word) peephole__V_21_21) == MR_mktag((MR_Integer) 1));
#line 575 "peephole.m"
                                    if ((MR_tag((MR_Word) peephole__V_21_21) == MR_mktag((MR_Integer) 1)))
#line 575 "peephole.m"
                                      *peephole__HeadVar__3_3 = MR_unbox_float((MR_hl_field(MR_mktag(1), peephole__V_21_21, (MR_Integer) 0)));
                                    if (peephole__succeeded)
                                      {
#line 575 "peephole.m"
                                        peephole__succeeded = (MR_tag((MR_Word) peephole__ArgC_11) == MR_mktag((MR_Integer) 0));
#line 575 "peephole.m"
                                        if ((MR_tag((MR_Word) peephole__ArgC_11) == MR_mktag((MR_Integer) 0)))
#line 575 "peephole.m"
                                          peephole__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__ArgC_11, (MR_Integer) 0)));
                                        if (peephole__succeeded)
                                          {
#line 575 "peephole.m"
                                            peephole__succeeded = ((MR_tag((MR_Word) peephole__V_23_23) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_23_23, (MR_Integer) 0))) == (MR_Integer) 1));
#line 575 "peephole.m"
                                            if (((MR_tag((MR_Word) peephole__V_23_23) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_23_23, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 575 "peephole.m"
                                              peephole__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_23_23, (MR_Integer) 1)));
                                            if (peephole__succeeded)
                                              {
#line 575 "peephole.m"
                                                peephole__succeeded = (MR_tag((MR_Word) peephole__V_24_24) == MR_mktag((MR_Integer) 1));
#line 575 "peephole.m"
                                                if ((MR_tag((MR_Word) peephole__V_24_24) == MR_mktag((MR_Integer) 1)))
#line 575 "peephole.m"
                                                  *peephole__HeadVar__4_4 = MR_unbox_float((MR_hl_field(MR_mktag(1), peephole__V_24_24, (MR_Integer) 0)));
                                              }
                                          }
                                      }
                                  }
                              }
                          }
                      }
                  }
              }
          }
      }
    return peephole__succeeded;
  }
#line 546 "peephole.m"
}

#line 533 "peephole.m"
static bool MR_CALL peephole__remove_n_values_3_p_0(
#line 533 "peephole.m"
  MR_Integer peephole__HeadVar__1_1,
#line 533 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 533 "peephole.m"
  MR_Word * peephole__HeadVar__3_3)
#line 533 "peephole.m"
{
#line 538 "peephole.m"
  {
#line 538 "peephole.m"
    /* tailcall optimized into a loop */
#line 538 "peephole.m"
  loop_top:;
#line 538 "peephole.m"
    {
#line 538 "peephole.m"
      bool peephole__succeeded;
      MR_Integer peephole__V_23_23 = (MR_Integer) 0;

#line 536 "peephole.m"
      peephole__succeeded = (peephole__HeadVar__1_1 <= peephole__V_23_23);
#line 538 "peephole.m"
      if (peephole__succeeded)
#line 537 "peephole.m"
        {
#line 537 "peephole.m"
          *peephole__HeadVar__3_3 = peephole__HeadVar__2_2;
#line 537 "peephole.m"
          peephole__succeeded = TRUE;
#line 537 "peephole.m"
        }
#line 538 "peephole.m"
      else
        {
          MR_Word peephole__Tokens1_7;
          MR_Integer peephole__V_9_9;
          MR_Integer peephole__V_10_10;
          MR_Word peephole__V_21_21;
          MR_Word peephole__V_22_22;

#line 506 "peephole.m"
          peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 506 "peephole.m"
          if ((MR_tag((MR_Word) peephole__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 506 "peephole.m"
            {
#line 506 "peephole.m"
              peephole__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__2_2, (MR_Integer) 0)));
#line 506 "peephole.m"
              peephole__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__2_2, (MR_Integer) 1)));
#line 506 "peephole.m"
            }
          if (peephole__succeeded)
            {
#line 506 "peephole.m"
#line 506 "peephole.m"
              switch (MR_tag((MR_Word) peephole__V_22_22)) {
#line 506 "peephole.m"
                default: /*NOTREACHED*/ MR_assert(0);
#line 506 "peephole.m"
                case (MR_Integer) 0:
                  {
                    MR_Word peephole__Token_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_22_22, (MR_Integer) 0)));

#line 509 "peephole.m"
                    {
#line 509 "peephole.m"
                      peephole__succeeded = peephole__remove_single_3_p_0(peephole__Token_17, peephole__V_21_21, &peephole__Tokens1_7);
                    }
                  }
#line 506 "peephole.m"
                  break;
#line 506 "peephole.m"
                case (MR_Integer) 1:
#line 506 "peephole.m"
                  {
#line 506 "peephole.m"
                    peephole__Tokens1_7 = peephole__V_21_21;
#line 506 "peephole.m"
                    peephole__succeeded = TRUE;
#line 506 "peephole.m"
                  }
#line 506 "peephole.m"
                  break;
#line 506 "peephole.m"
                case (MR_Integer) 2:
#line 507 "peephole.m"
                  {
#line 507 "peephole.m"
                    peephole__Tokens1_7 = peephole__V_21_21;
#line 507 "peephole.m"
                    peephole__succeeded = TRUE;
#line 507 "peephole.m"
                  }
#line 506 "peephole.m"
                  break;
#line 506 "peephole.m"
              }
              if (peephole__succeeded)
                {
#line 540 "peephole.m"
                  peephole__V_10_10 = (MR_Integer) 1;
#line 540 "peephole.m"
                  peephole__V_9_9 = (peephole__HeadVar__1_1 - peephole__V_10_10);
#line 540 "peephole.m"
                  {
#line 540 "peephole.m"
                    /* direct tailcall eliminated */
#line 540 "peephole.m"
                    {
#line 540 "peephole.m"
                      MR_Integer peephole__HeadVar__1__tmp_copy_1 = peephole__V_9_9;
#line 540 "peephole.m"
                      MR_Word peephole__HeadVar__2__tmp_copy_2 = peephole__Tokens1_7;

#line 540 "peephole.m"
                      peephole__HeadVar__1_1 = peephole__HeadVar__1__tmp_copy_1;
#line 540 "peephole.m"
                      peephole__HeadVar__2_2 = peephole__HeadVar__2__tmp_copy_2;
#line 540 "peephole.m"
                    }
#line 540 "peephole.m"
                    goto loop_top;
#line 540 "peephole.m"
                  }
                }
            }
        }
#line 538 "peephole.m"
      return peephole__succeeded;
#line 538 "peephole.m"
    }
#line 538 "peephole.m"
  }
#line 533 "peephole.m"
}

#line 526 "peephole.m"
static bool MR_CALL peephole__remove_op_3_p_0(
#line 526 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 526 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 526 "peephole.m"
  MR_Word * peephole__HeadVar__3_3)
#line 526 "peephole.m"
{
  {
    bool peephole__succeeded;
    MR_Integer peephole__Input_7;
    MR_Word peephole__MaybeOutput_8;
    MR_Integer peephole__V_9_9;

#line 529 "peephole.m"
    {
#line 529 "peephole.m"
      eval__args_3_p_0(peephole__HeadVar__1_1, &peephole__Input_7, &peephole__MaybeOutput_8);
    }
#line 530 "peephole.m"
    peephole__succeeded = (MR_tag((MR_Word) peephole__MaybeOutput_8) == MR_mktag((MR_Integer) 1));
#line 530 "peephole.m"
    if ((MR_tag((MR_Word) peephole__MaybeOutput_8) == MR_mktag((MR_Integer) 1)))
#line 530 "peephole.m"
      peephole__V_9_9 = ((MR_Integer) (MR_hl_field(MR_mktag(1), peephole__MaybeOutput_8, (MR_Integer) 0)));
    if (peephole__succeeded)
      {
#line 530 "peephole.m"
        peephole__succeeded = (peephole__V_9_9 == (MR_Integer) 1);
        if (peephole__succeeded)
#line 531 "peephole.m"
          {
#line 531 "peephole.m"
            return peephole__succeeded = peephole__remove_n_values_3_p_0(peephole__Input_7, peephole__HeadVar__2_2, peephole__HeadVar__3_3);
          }
      }
    return peephole__succeeded;
  }
#line 526 "peephole.m"
}

#line 511 "peephole.m"
static bool MR_CALL peephole__remove_single_3_p_0(
#line 511 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 511 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 511 "peephole.m"
  MR_Word * peephole__HeadVar__3_3)
#line 511 "peephole.m"
{
#line 513 "peephole.m"
  {
#line 513 "peephole.m"
    bool peephole__succeeded;
#line 513 "peephole.m"
    MR_Word peephole__Op_27;
#line 513 "peephole.m"
    MR_Word peephole__V_30_30;

#line 513 "peephole.m"
#line 513 "peephole.m"
    switch (MR_tag((MR_Word) peephole__HeadVar__1_1)) {
#line 513 "peephole.m"
      default:
#line 513 "peephole.m"
        peephole__succeeded = FALSE;
#line 513 "peephole.m"
        break;
#line 513 "peephole.m"
      case (MR_Integer) 3:
#line 513 "peephole.m"
#line 513 "peephole.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__HeadVar__1_1, (MR_Integer) 0)))) {
#line 513 "peephole.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 513 "peephole.m"
          case (MR_Integer) 0:
#line 514 "peephole.m"
            {
#line 514 "peephole.m"
              *peephole__HeadVar__3_3 = peephole__HeadVar__2_2;
#line 514 "peephole.m"
              peephole__succeeded = TRUE;
#line 514 "peephole.m"
            }
#line 513 "peephole.m"
            break;
#line 513 "peephole.m"
          case (MR_Integer) 1:
#line 515 "peephole.m"
            {
#line 515 "peephole.m"
              *peephole__HeadVar__3_3 = peephole__HeadVar__2_2;
#line 515 "peephole.m"
              peephole__succeeded = TRUE;
#line 515 "peephole.m"
            }
#line 513 "peephole.m"
            break;
#line 513 "peephole.m"
          case (MR_Integer) 2:
#line 516 "peephole.m"
            {
#line 516 "peephole.m"
              *peephole__HeadVar__3_3 = peephole__HeadVar__2_2;
#line 516 "peephole.m"
              peephole__succeeded = TRUE;
#line 516 "peephole.m"
            }
#line 513 "peephole.m"
            break;
#line 513 "peephole.m"
          case (MR_Integer) 3:
            {
#line 517 "peephole.m"
              peephole__V_30_30 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__HeadVar__1_1, (MR_Integer) 1)));
#line 513 "peephole.m"
#line 513 "peephole.m"
              switch (MR_tag((MR_Word) peephole__V_30_30)) {
#line 513 "peephole.m"
                default:
#line 513 "peephole.m"
                  peephole__succeeded = FALSE;
#line 513 "peephole.m"
                  break;
#line 513 "peephole.m"
                case (MR_Integer) 3:
#line 513 "peephole.m"
#line 513 "peephole.m"
                  switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_30_30, (MR_Integer) 0)))) {
#line 513 "peephole.m"
                    default:
#line 513 "peephole.m"
                      peephole__succeeded = FALSE;
#line 513 "peephole.m"
                      break;
#line 513 "peephole.m"
                    case (MR_Integer) 1:
#line 521 "peephole.m"
                      {
#line 521 "peephole.m"
                        *peephole__HeadVar__3_3 = peephole__HeadVar__2_2;
#line 521 "peephole.m"
                        peephole__succeeded = TRUE;
#line 521 "peephole.m"
                      }
#line 513 "peephole.m"
                      break;
#line 513 "peephole.m"
                    case (MR_Integer) 2:
#line 519 "peephole.m"
                      {
#line 519 "peephole.m"
                        *peephole__HeadVar__3_3 = peephole__HeadVar__2_2;
#line 519 "peephole.m"
                        peephole__succeeded = TRUE;
#line 519 "peephole.m"
                      }
#line 513 "peephole.m"
                      break;
#line 513 "peephole.m"
                    case (MR_Integer) 3:
#line 520 "peephole.m"
                      {
#line 520 "peephole.m"
                        *peephole__HeadVar__3_3 = peephole__HeadVar__2_2;
#line 520 "peephole.m"
                        peephole__succeeded = TRUE;
#line 520 "peephole.m"
                      }
#line 513 "peephole.m"
                      break;
#line 513 "peephole.m"
                    case (MR_Integer) 4:
#line 517 "peephole.m"
                      {
#line 517 "peephole.m"
                        *peephole__HeadVar__3_3 = peephole__HeadVar__2_2;
#line 517 "peephole.m"
                        peephole__succeeded = TRUE;
#line 517 "peephole.m"
                      }
#line 513 "peephole.m"
                      break;
#line 513 "peephole.m"
                  }
#line 513 "peephole.m"
                  break;
#line 513 "peephole.m"
                case (MR_Integer) 2:
#line 518 "peephole.m"
                  {
#line 518 "peephole.m"
                    *peephole__HeadVar__3_3 = peephole__HeadVar__2_2;
#line 518 "peephole.m"
                    peephole__succeeded = TRUE;
#line 518 "peephole.m"
                  }
#line 513 "peephole.m"
                  break;
#line 513 "peephole.m"
              }
            }
#line 513 "peephole.m"
            break;
#line 513 "peephole.m"
        }
#line 513 "peephole.m"
        break;
#line 513 "peephole.m"
      case (MR_Integer) 0:
        {
#line 523 "peephole.m"
          peephole__Op_27 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__HeadVar__1_1, (MR_Integer) 0)));
#line 524 "peephole.m"
          {
#line 524 "peephole.m"
            return peephole__succeeded = peephole__remove_op_3_p_0(peephole__Op_27, peephole__HeadVar__2_2, peephole__HeadVar__3_3);
          }
        }
#line 513 "peephole.m"
        break;
#line 513 "peephole.m"
      case (MR_Integer) 1:
#line 513 "peephole.m"
        {
#line 513 "peephole.m"
          *peephole__HeadVar__3_3 = peephole__HeadVar__2_2;
#line 513 "peephole.m"
          peephole__succeeded = TRUE;
#line 513 "peephole.m"
        }
#line 513 "peephole.m"
        break;
#line 513 "peephole.m"
    }
#line 513 "peephole.m"
    return peephole__succeeded;
#line 513 "peephole.m"
  }
#line 511 "peephole.m"
}

#line 504 "peephole.m"
static bool MR_CALL peephole__remove_code_to_construct_one_value_2_p_0(
#line 504 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 504 "peephole.m"
  MR_Word * peephole__HeadVar__2_2)
#line 504 "peephole.m"
{
  {
    bool peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 1));
    MR_Word peephole__V_13_13;
    MR_Word peephole__V_14_14;
#line 506 "peephole.m"
    MR_Word peephole__Token_9;

#line 506 "peephole.m"
    if ((MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 1)))
#line 506 "peephole.m"
      {
#line 506 "peephole.m"
        peephole__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 0)));
#line 506 "peephole.m"
        peephole__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 1)));
#line 506 "peephole.m"
      }
    if (peephole__succeeded)
#line 506 "peephole.m"
#line 506 "peephole.m"
      switch (MR_tag((MR_Word) peephole__V_14_14)) {
#line 506 "peephole.m"
        default: /*NOTREACHED*/ MR_assert(0);
#line 506 "peephole.m"
        case (MR_Integer) 0:
          {
#line 508 "peephole.m"
            peephole__Token_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_14_14, (MR_Integer) 0)));
#line 509 "peephole.m"
            {
#line 509 "peephole.m"
              return peephole__succeeded = peephole__remove_single_3_p_0(peephole__Token_9, peephole__V_13_13, peephole__HeadVar__2_2);
            }
          }
#line 506 "peephole.m"
          break;
#line 506 "peephole.m"
        case (MR_Integer) 1:
#line 506 "peephole.m"
          {
#line 506 "peephole.m"
            *peephole__HeadVar__2_2 = peephole__V_13_13;
#line 506 "peephole.m"
            peephole__succeeded = TRUE;
#line 506 "peephole.m"
          }
#line 506 "peephole.m"
          break;
#line 506 "peephole.m"
        case (MR_Integer) 2:
#line 507 "peephole.m"
          {
#line 507 "peephole.m"
            *peephole__HeadVar__2_2 = peephole__V_13_13;
#line 507 "peephole.m"
            peephole__succeeded = TRUE;
#line 507 "peephole.m"
          }
#line 506 "peephole.m"
          break;
#line 506 "peephole.m"
      }
    return peephole__succeeded;
  }
#line 504 "peephole.m"
}

#line 493 "peephole.m"
static bool MR_CALL peephole__constant_value_2_p_0(
#line 493 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 493 "peephole.m"
  MR_Word * peephole__HeadVar__2_2)
#line 493 "peephole.m"
{
  {
    bool peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 0));
    MR_Word peephole__V_16_16;
#line 494 "peephole.m"
    MR_Word peephole__X_3;
#line 494 "peephole.m"
    MR_String peephole__X_11;
#line 494 "peephole.m"
    MR_Word peephole__P_13;
#line 494 "peephole.m"
    MR_Word peephole__V_15_15;
#line 494 "peephole.m"
    MR_Word peephole__V_17_17;

#line 494 "peephole.m"
    if ((MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 0)))
#line 494 "peephole.m"
      peephole__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__HeadVar__1_1, (MR_Integer) 0)));
    if (peephole__succeeded)
#line 494 "peephole.m"
#line 494 "peephole.m"
      switch (MR_tag((MR_Word) peephole__V_16_16)) {
#line 494 "peephole.m"
        default:
#line 494 "peephole.m"
          peephole__succeeded = FALSE;
#line 494 "peephole.m"
          break;
#line 494 "peephole.m"
        case (MR_Integer) 3:
#line 494 "peephole.m"
#line 494 "peephole.m"
          switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 0)))) {
#line 494 "peephole.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 494 "peephole.m"
            case (MR_Integer) 0:
              {
#line 494 "peephole.m"
                peephole__X_3 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 1)));
#line 494 "peephole.m"
                {
#line 494 "peephole.m"
                  *peephole__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "boolean");
#line 494 "peephole.m"
                  MR_hl_field(MR_mktag(0), *peephole__HeadVar__2_2, 0) = ((MR_Box) (peephole__X_3));
#line 494 "peephole.m"
                }
                peephole__succeeded = TRUE;
              }
#line 494 "peephole.m"
              break;
#line 494 "peephole.m"
            case (MR_Integer) 1:
              {
#line 494 "peephole.m"
                MR_Float peephole__X_5;
#line 494 "peephole.m"
                MR_Integer peephole__X_8;

#line 495 "peephole.m"
                peephole__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 1)));
#line 494 "peephole.m"
                if ((MR_tag((MR_Word) peephole__V_17_17) == MR_mktag((MR_Integer) 0)))
                  {
#line 496 "peephole.m"
                    peephole__X_8 = ((MR_Integer) (MR_hl_field(MR_mktag(0), peephole__V_17_17, (MR_Integer) 0)));
#line 496 "peephole.m"
                    {
#line 496 "peephole.m"
                      *peephole__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "int"));
#line 496 "peephole.m"
                      MR_hl_field(MR_mktag(1), *peephole__HeadVar__2_2, 0) = ((MR_Box) (peephole__X_8));
#line 496 "peephole.m"
                    }
                  }
#line 494 "peephole.m"
                else
#line 494 "peephole.m"
                  {
#line 495 "peephole.m"
                    peephole__X_5 = MR_unbox_float((MR_hl_field(MR_mktag(1), peephole__V_17_17, (MR_Integer) 0)));
#line 495 "peephole.m"
                    {
#line 495 "peephole.m"
                      *peephole__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 495 "peephole.m"
                      MR_hl_field(MR_mktag(2), *peephole__HeadVar__2_2, 0) = MR_box_float(peephole__X_5);
#line 495 "peephole.m"
                    }
#line 494 "peephole.m"
                  }
                peephole__succeeded = TRUE;
              }
#line 494 "peephole.m"
              break;
#line 494 "peephole.m"
            case (MR_Integer) 2:
              {
#line 497 "peephole.m"
                peephole__X_11 = ((MR_String) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 1)));
#line 497 "peephole.m"
                {
#line 497 "peephole.m"
                  *peephole__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "string"));
#line 497 "peephole.m"
                  MR_hl_field(MR_mktag(3), *peephole__HeadVar__2_2, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 0));
#line 497 "peephole.m"
                  MR_hl_field(MR_mktag(3), *peephole__HeadVar__2_2, 1) = ((MR_Box) (peephole__X_11));
#line 497 "peephole.m"
                }
                peephole__succeeded = TRUE;
              }
#line 494 "peephole.m"
              break;
#line 494 "peephole.m"
            case (MR_Integer) 3:
              {
#line 498 "peephole.m"
                peephole__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 1)));
#line 498 "peephole.m"
                peephole__succeeded = ((MR_tag((MR_Word) peephole__V_15_15) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_15_15, (MR_Integer) 0))) == (MR_Integer) 4));
#line 498 "peephole.m"
                if (((MR_tag((MR_Word) peephole__V_15_15) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_15_15, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 498 "peephole.m"
                  peephole__P_13 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_15_15, (MR_Integer) 1)));
                if (peephole__succeeded)
                  {
#line 498 "peephole.m"
                    {
#line 498 "peephole.m"
                      *peephole__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "point"));
#line 498 "peephole.m"
                      MR_hl_field(MR_mktag(3), *peephole__HeadVar__2_2, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 3));
#line 498 "peephole.m"
                      MR_hl_field(MR_mktag(3), *peephole__HeadVar__2_2, 1) = ((MR_Box) (peephole__P_13));
#line 498 "peephole.m"
                    }
#line 498 "peephole.m"
                    peephole__succeeded = TRUE;
                  }
              }
#line 494 "peephole.m"
              break;
#line 494 "peephole.m"
          }
#line 494 "peephole.m"
          break;
#line 494 "peephole.m"
      }
    return peephole__succeeded;
  }
#line 493 "peephole.m"
}

#line 481 "peephole.m"
static bool MR_CALL peephole__value_token_group_1_p_0(
#line 481 "peephole.m"
  MR_Word peephole__HeadVar__1_1)
#line 481 "peephole.m"
{
#line 483 "peephole.m"
  {
#line 483 "peephole.m"
    bool peephole__succeeded;
#line 483 "peephole.m"
    MR_Word peephole__V_15_15;

#line 483 "peephole.m"
#line 483 "peephole.m"
    switch (MR_tag((MR_Word) peephole__HeadVar__1_1)) {
#line 483 "peephole.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 483 "peephole.m"
      case (MR_Integer) 0:
        {
#line 483 "peephole.m"
          peephole__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__HeadVar__1_1, (MR_Integer) 0)));
#line 483 "peephole.m"
#line 483 "peephole.m"
          switch (MR_tag((MR_Word) peephole__V_15_15)) {
#line 483 "peephole.m"
            default:
#line 483 "peephole.m"
              peephole__succeeded = FALSE;
#line 483 "peephole.m"
              break;
#line 483 "peephole.m"
            case (MR_Integer) 3:
#line 483 "peephole.m"
#line 483 "peephole.m"
              switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_15_15, (MR_Integer) 0)))) {
#line 483 "peephole.m"
                default: /*NOTREACHED*/ MR_assert(0);
#line 483 "peephole.m"
                case (MR_Integer) 0:
#line 484 "peephole.m"
                  peephole__succeeded = TRUE;
#line 483 "peephole.m"
                  break;
#line 483 "peephole.m"
                case (MR_Integer) 1:
#line 485 "peephole.m"
                  peephole__succeeded = TRUE;
#line 483 "peephole.m"
                  break;
#line 483 "peephole.m"
                case (MR_Integer) 2:
#line 486 "peephole.m"
                  peephole__succeeded = TRUE;
#line 483 "peephole.m"
                  break;
#line 483 "peephole.m"
                case (MR_Integer) 3:
#line 489 "peephole.m"
                  {
#line 489 "peephole.m"
                    MR_Word peephole__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_15_15, (MR_Integer) 1)));
#line 489 "peephole.m"
                    MR_Word peephole__V_12_12;

#line 489 "peephole.m"
                    peephole__succeeded = ((MR_tag((MR_Word) peephole__V_14_14) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_14_14, (MR_Integer) 0))) == (MR_Integer) 4));
#line 489 "peephole.m"
                    if (((MR_tag((MR_Word) peephole__V_14_14) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_14_14, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 489 "peephole.m"
                      peephole__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_14_14, (MR_Integer) 1)));
#line 489 "peephole.m"
                  }
#line 483 "peephole.m"
                  break;
#line 483 "peephole.m"
              }
#line 483 "peephole.m"
              break;
#line 483 "peephole.m"
            case (MR_Integer) 1:
#line 483 "peephole.m"
              peephole__succeeded = TRUE;
#line 483 "peephole.m"
              break;
#line 483 "peephole.m"
          }
        }
#line 483 "peephole.m"
        break;
#line 483 "peephole.m"
      case (MR_Integer) 1:
        peephole__succeeded = TRUE;
#line 483 "peephole.m"
        break;
#line 483 "peephole.m"
      case (MR_Integer) 2:
        peephole__succeeded = TRUE;
#line 483 "peephole.m"
        break;
#line 483 "peephole.m"
    }
#line 483 "peephole.m"
    return peephole__succeeded;
#line 483 "peephole.m"
  }
#line 481 "peephole.m"
}

#line 471 "peephole.m"
static bool MR_CALL peephole__chase_dups_2_p_0(
#line 471 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 471 "peephole.m"
  MR_Word * peephole__HeadVar__2_2)
#line 471 "peephole.m"
{
  {
    /* tailcall optimized into a loop */
  loop_top:;
    {
      bool peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 1));
      MR_Word peephole__Token_3;
      MR_Word peephole__Tokens_4;
#line 476 "peephole.m"
      MR_Word peephole__V_6_6;
#line 476 "peephole.m"
      MR_Word peephole__V_7_7;

#line 473 "peephole.m"
      if ((MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 1)))
#line 473 "peephole.m"
        {
#line 473 "peephole.m"
          peephole__Token_3 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 0)));
#line 473 "peephole.m"
          peephole__Tokens_4 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 1)));
#line 473 "peephole.m"
        }
      if (peephole__succeeded)
        {
#line 474 "peephole.m"
          peephole__succeeded = (MR_tag((MR_Word) peephole__Token_3) == MR_mktag((MR_Integer) 0));
#line 474 "peephole.m"
          if ((MR_tag((MR_Word) peephole__Token_3) == MR_mktag((MR_Integer) 0)))
#line 474 "peephole.m"
            peephole__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__Token_3, (MR_Integer) 0)));
          if (peephole__succeeded)
            {
#line 474 "peephole.m"
              peephole__succeeded = ((MR_tag((MR_Word) peephole__V_6_6) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_6_6, (MR_Integer) 0))) == (MR_Integer) 3));
#line 474 "peephole.m"
              if (((MR_tag((MR_Word) peephole__V_6_6) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_6_6, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 474 "peephole.m"
                peephole__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_6_6, (MR_Integer) 1)));
              if (peephole__succeeded)
#line 474 "peephole.m"
                peephole__succeeded = (peephole__V_7_7 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
            }
#line 476 "peephole.m"
          if (peephole__succeeded)
#line 475 "peephole.m"
            {
#line 475 "peephole.m"
              /* direct tailcall eliminated */
#line 475 "peephole.m"
              {
#line 475 "peephole.m"
                MR_Word peephole__HeadVar__1__tmp_copy_1 = peephole__Tokens_4;

#line 475 "peephole.m"
                peephole__HeadVar__1_1 = peephole__HeadVar__1__tmp_copy_1;
#line 475 "peephole.m"
              }
#line 475 "peephole.m"
              goto loop_top;
#line 475 "peephole.m"
            }
#line 476 "peephole.m"
          else
            {
#line 483 "peephole.m"
              MR_Word peephole__V_21_21;

#line 483 "peephole.m"
#line 483 "peephole.m"
              switch (MR_tag((MR_Word) peephole__Token_3)) {
#line 483 "peephole.m"
                default: /*NOTREACHED*/ MR_assert(0);
#line 483 "peephole.m"
                case (MR_Integer) 0:
                  {
#line 483 "peephole.m"
                    peephole__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__Token_3, (MR_Integer) 0)));
#line 483 "peephole.m"
#line 483 "peephole.m"
                    switch (MR_tag((MR_Word) peephole__V_21_21)) {
#line 483 "peephole.m"
                      default:
#line 483 "peephole.m"
                        peephole__succeeded = FALSE;
#line 483 "peephole.m"
                        break;
#line 483 "peephole.m"
                      case (MR_Integer) 3:
#line 483 "peephole.m"
#line 483 "peephole.m"
                        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_21_21, (MR_Integer) 0)))) {
#line 483 "peephole.m"
                          default: /*NOTREACHED*/ MR_assert(0);
#line 483 "peephole.m"
                          case (MR_Integer) 0:
#line 484 "peephole.m"
                            peephole__succeeded = TRUE;
#line 483 "peephole.m"
                            break;
#line 483 "peephole.m"
                          case (MR_Integer) 1:
#line 485 "peephole.m"
                            peephole__succeeded = TRUE;
#line 483 "peephole.m"
                            break;
#line 483 "peephole.m"
                          case (MR_Integer) 2:
#line 486 "peephole.m"
                            peephole__succeeded = TRUE;
#line 483 "peephole.m"
                            break;
#line 483 "peephole.m"
                          case (MR_Integer) 3:
#line 489 "peephole.m"
                            {
#line 489 "peephole.m"
                              MR_Word peephole__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_21_21, (MR_Integer) 1)));
#line 489 "peephole.m"
                              MR_Word peephole__V_18_18;

#line 489 "peephole.m"
                              peephole__succeeded = ((MR_tag((MR_Word) peephole__V_20_20) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_20_20, (MR_Integer) 0))) == (MR_Integer) 4));
#line 489 "peephole.m"
                              if (((MR_tag((MR_Word) peephole__V_20_20) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_20_20, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 489 "peephole.m"
                                peephole__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_20_20, (MR_Integer) 1)));
#line 489 "peephole.m"
                            }
#line 483 "peephole.m"
                            break;
#line 483 "peephole.m"
                        }
#line 483 "peephole.m"
                        break;
#line 483 "peephole.m"
                      case (MR_Integer) 1:
#line 483 "peephole.m"
                        peephole__succeeded = TRUE;
#line 483 "peephole.m"
                        break;
#line 483 "peephole.m"
                    }
                  }
#line 483 "peephole.m"
                  break;
#line 483 "peephole.m"
                case (MR_Integer) 1:
                  peephole__succeeded = TRUE;
#line 483 "peephole.m"
                  break;
#line 483 "peephole.m"
                case (MR_Integer) 2:
                  peephole__succeeded = TRUE;
#line 483 "peephole.m"
                  break;
#line 483 "peephole.m"
              }
              if (peephole__succeeded)
                {
#line 478 "peephole.m"
                  *peephole__HeadVar__2_2 = peephole__Token_3;
#line 478 "peephole.m"
                  peephole__succeeded = TRUE;
                }
            }
        }
      return peephole__succeeded;
    }
  }
#line 471 "peephole.m"
}

#line 457 "peephole.m"
static bool MR_CALL peephole__constant_surface_function_2_p_0(
#line 457 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 457 "peephole.m"
  MR_Word * peephole__HeadVar__2_2)
#line 457 "peephole.m"
{
  {
    bool peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 1));
    MR_Word peephole__Point_5;
    MR_Float peephole__Diffuse_6;
    MR_Float peephole__Specular_7;
    MR_Float peephole__Phong_8;
    MR_Word peephole__V_9_9;
    MR_Word peephole__V_10_10;
    MR_Word peephole__V_11_11;
    MR_Word peephole__V_12_12;
    MR_Integer peephole__V_13_13;
    MR_Word peephole__V_14_14;
    MR_Word peephole__V_15_15;
    MR_Word peephole__V_16_16;
    MR_Word peephole__V_17_17;
    MR_Word peephole__V_18_18;
    MR_Word peephole__V_19_19;
    MR_Word peephole__V_20_20;
    MR_Word peephole__V_21_21;
    MR_Word peephole__V_22_22;
    MR_Word peephole__V_23_23;
    MR_Word peephole__V_24_24;
    MR_Word peephole__V_25_25;
    MR_Word peephole__V_26_26;
    MR_Word peephole__V_27_27;
    MR_Word peephole__V_28_28;
    MR_Word peephole__V_29_29;

#line 460 "peephole.m"
    if ((MR_tag((MR_Word) peephole__HeadVar__1_1) == MR_mktag((MR_Integer) 1)))
#line 460 "peephole.m"
      {
#line 460 "peephole.m"
        peephole__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 0)));
#line 460 "peephole.m"
        peephole__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 1)));
#line 460 "peephole.m"
      }
    if (peephole__succeeded)
      {
#line 460 "peephole.m"
        peephole__succeeded = (MR_tag((MR_Word) peephole__V_9_9) == MR_mktag((MR_Integer) 0));
#line 460 "peephole.m"
        if ((MR_tag((MR_Word) peephole__V_9_9) == MR_mktag((MR_Integer) 0)))
#line 460 "peephole.m"
          peephole__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_9_9, (MR_Integer) 0)));
        if (peephole__succeeded)
          {
#line 460 "peephole.m"
            peephole__succeeded = ((MR_tag((MR_Word) peephole__V_11_11) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_11_11, (MR_Integer) 0))) == (MR_Integer) 3));
#line 460 "peephole.m"
            if (((MR_tag((MR_Word) peephole__V_11_11) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_11_11, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 460 "peephole.m"
              peephole__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_11_11, (MR_Integer) 1)));
            if (peephole__succeeded)
              {
#line 460 "peephole.m"
                peephole__succeeded = (MR_tag((MR_Word) peephole__V_12_12) == MR_mktag((MR_Integer) 1));
#line 460 "peephole.m"
                if ((MR_tag((MR_Word) peephole__V_12_12) == MR_mktag((MR_Integer) 1)))
#line 460 "peephole.m"
                  peephole__V_13_13 = ((MR_Integer) (MR_hl_field(MR_mktag(1), peephole__V_12_12, (MR_Integer) 0)));
                if (peephole__succeeded)
                  {
#line 460 "peephole.m"
                    peephole__succeeded = (peephole__V_13_13 == (MR_Integer) 3);
                    if (peephole__succeeded)
                      {
#line 460 "peephole.m"
                        peephole__succeeded = (MR_tag((MR_Word) peephole__V_10_10) == MR_mktag((MR_Integer) 1));
#line 460 "peephole.m"
                        if ((MR_tag((MR_Word) peephole__V_10_10) == MR_mktag((MR_Integer) 1)))
#line 460 "peephole.m"
                          {
#line 460 "peephole.m"
                            peephole__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_10_10, (MR_Integer) 0)));
#line 460 "peephole.m"
                            peephole__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_10_10, (MR_Integer) 1)));
#line 460 "peephole.m"
                          }
                        if (peephole__succeeded)
                          {
#line 461 "peephole.m"
                            peephole__succeeded = (MR_tag((MR_Word) peephole__V_14_14) == MR_mktag((MR_Integer) 0));
#line 461 "peephole.m"
                            if ((MR_tag((MR_Word) peephole__V_14_14) == MR_mktag((MR_Integer) 0)))
#line 461 "peephole.m"
                              peephole__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_14_14, (MR_Integer) 0)));
                            if (peephole__succeeded)
                              {
#line 461 "peephole.m"
                                peephole__succeeded = ((MR_tag((MR_Word) peephole__V_16_16) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 0))) == (MR_Integer) 3));
#line 461 "peephole.m"
                                if (((MR_tag((MR_Word) peephole__V_16_16) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 461 "peephole.m"
                                  peephole__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_16_16, (MR_Integer) 1)));
                                if (peephole__succeeded)
                                  {
#line 461 "peephole.m"
                                    peephole__succeeded = ((MR_tag((MR_Word) peephole__V_17_17) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_17_17, (MR_Integer) 0))) == (MR_Integer) 4));
#line 461 "peephole.m"
                                    if (((MR_tag((MR_Word) peephole__V_17_17) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_17_17, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 461 "peephole.m"
                                      peephole__Point_5 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_17_17, (MR_Integer) 1)));
                                    if (peephole__succeeded)
                                      {
#line 461 "peephole.m"
                                        peephole__succeeded = (MR_tag((MR_Word) peephole__V_15_15) == MR_mktag((MR_Integer) 1));
#line 461 "peephole.m"
                                        if ((MR_tag((MR_Word) peephole__V_15_15) == MR_mktag((MR_Integer) 1)))
#line 461 "peephole.m"
                                          {
#line 461 "peephole.m"
                                            peephole__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_15_15, (MR_Integer) 0)));
#line 461 "peephole.m"
                                            peephole__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_15_15, (MR_Integer) 1)));
#line 461 "peephole.m"
                                          }
                                        if (peephole__succeeded)
                                          {
#line 462 "peephole.m"
                                            peephole__succeeded = (MR_tag((MR_Word) peephole__V_18_18) == MR_mktag((MR_Integer) 0));
#line 462 "peephole.m"
                                            if ((MR_tag((MR_Word) peephole__V_18_18) == MR_mktag((MR_Integer) 0)))
#line 462 "peephole.m"
                                              peephole__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_18_18, (MR_Integer) 0)));
                                            if (peephole__succeeded)
                                              {
#line 462 "peephole.m"
                                                peephole__succeeded = ((MR_tag((MR_Word) peephole__V_20_20) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_20_20, (MR_Integer) 0))) == (MR_Integer) 1));
#line 462 "peephole.m"
                                                if (((MR_tag((MR_Word) peephole__V_20_20) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_20_20, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 462 "peephole.m"
                                                  peephole__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_20_20, (MR_Integer) 1)));
                                                if (peephole__succeeded)
                                                  {
#line 462 "peephole.m"
                                                    peephole__succeeded = (MR_tag((MR_Word) peephole__V_21_21) == MR_mktag((MR_Integer) 1));
#line 462 "peephole.m"
                                                    if ((MR_tag((MR_Word) peephole__V_21_21) == MR_mktag((MR_Integer) 1)))
#line 462 "peephole.m"
                                                      peephole__Diffuse_6 = MR_unbox_float((MR_hl_field(MR_mktag(1), peephole__V_21_21, (MR_Integer) 0)));
                                                    if (peephole__succeeded)
                                                      {
#line 462 "peephole.m"
                                                        peephole__succeeded = (MR_tag((MR_Word) peephole__V_19_19) == MR_mktag((MR_Integer) 1));
#line 462 "peephole.m"
                                                        if ((MR_tag((MR_Word) peephole__V_19_19) == MR_mktag((MR_Integer) 1)))
#line 462 "peephole.m"
                                                          {
#line 462 "peephole.m"
                                                            peephole__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_19_19, (MR_Integer) 0)));
#line 462 "peephole.m"
                                                            peephole__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_19_19, (MR_Integer) 1)));
#line 462 "peephole.m"
                                                          }
                                                        if (peephole__succeeded)
                                                          {
#line 463 "peephole.m"
                                                            peephole__succeeded = (MR_tag((MR_Word) peephole__V_22_22) == MR_mktag((MR_Integer) 0));
#line 463 "peephole.m"
                                                            if ((MR_tag((MR_Word) peephole__V_22_22) == MR_mktag((MR_Integer) 0)))
#line 463 "peephole.m"
                                                              peephole__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_22_22, (MR_Integer) 0)));
                                                            if (peephole__succeeded)
                                                              {
#line 463 "peephole.m"
                                                                peephole__succeeded = ((MR_tag((MR_Word) peephole__V_24_24) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_24_24, (MR_Integer) 0))) == (MR_Integer) 1));
#line 463 "peephole.m"
                                                                if (((MR_tag((MR_Word) peephole__V_24_24) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_24_24, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 463 "peephole.m"
                                                                  peephole__V_25_25 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_24_24, (MR_Integer) 1)));
                                                                if (peephole__succeeded)
                                                                  {
#line 463 "peephole.m"
                                                                    peephole__succeeded = (MR_tag((MR_Word) peephole__V_25_25) == MR_mktag((MR_Integer) 1));
#line 463 "peephole.m"
                                                                    if ((MR_tag((MR_Word) peephole__V_25_25) == MR_mktag((MR_Integer) 1)))
#line 463 "peephole.m"
                                                                      peephole__Specular_7 = MR_unbox_float((MR_hl_field(MR_mktag(1), peephole__V_25_25, (MR_Integer) 0)));
                                                                    if (peephole__succeeded)
                                                                      {
#line 463 "peephole.m"
                                                                        peephole__succeeded = (MR_tag((MR_Word) peephole__V_23_23) == MR_mktag((MR_Integer) 1));
#line 463 "peephole.m"
                                                                        if ((MR_tag((MR_Word) peephole__V_23_23) == MR_mktag((MR_Integer) 1)))
#line 463 "peephole.m"
                                                                          {
#line 463 "peephole.m"
                                                                            peephole__V_26_26 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_23_23, (MR_Integer) 0)));
#line 463 "peephole.m"
                                                                            peephole__V_27_27 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_23_23, (MR_Integer) 1)));
#line 463 "peephole.m"
                                                                          }
                                                                        if (peephole__succeeded)
                                                                          {
#line 464 "peephole.m"
                                                                            peephole__succeeded = (peephole__V_27_27 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
                                                                            if (peephole__succeeded)
                                                                              {
#line 464 "peephole.m"
                                                                                peephole__succeeded = (MR_tag((MR_Word) peephole__V_26_26) == MR_mktag((MR_Integer) 0));
#line 464 "peephole.m"
                                                                                if ((MR_tag((MR_Word) peephole__V_26_26) == MR_mktag((MR_Integer) 0)))
#line 464 "peephole.m"
                                                                                  peephole__V_28_28 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_26_26, (MR_Integer) 0)));
                                                                                if (peephole__succeeded)
                                                                                  {
#line 464 "peephole.m"
                                                                                    peephole__succeeded = ((MR_tag((MR_Word) peephole__V_28_28) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_28_28, (MR_Integer) 0))) == (MR_Integer) 1));
#line 464 "peephole.m"
                                                                                    if (((MR_tag((MR_Word) peephole__V_28_28) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_28_28, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 464 "peephole.m"
                                                                                      peephole__V_29_29 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_28_28, (MR_Integer) 1)));
                                                                                    if (peephole__succeeded)
                                                                                      {
#line 464 "peephole.m"
                                                                                        peephole__succeeded = (MR_tag((MR_Word) peephole__V_29_29) == MR_mktag((MR_Integer) 1));
#line 464 "peephole.m"
                                                                                        if ((MR_tag((MR_Word) peephole__V_29_29) == MR_mktag((MR_Integer) 1)))
#line 464 "peephole.m"
                                                                                          peephole__Phong_8 = MR_unbox_float((MR_hl_field(MR_mktag(1), peephole__V_29_29, (MR_Integer) 0)));
                                                                                        if (peephole__succeeded)
                                                                                          {
#line 466 "peephole.m"
                                                                                            {
#line 466 "peephole.m"
                                                                                              *peephole__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 4 * sizeof(MR_Word)), "surface_properties");
#line 466 "peephole.m"
                                                                                              MR_hl_field(MR_mktag(0), *peephole__HeadVar__2_2, 0) = ((MR_Box) (peephole__Point_5));
#line 466 "peephole.m"
                                                                                              MR_hl_field(MR_mktag(0), *peephole__HeadVar__2_2, 1) = MR_box_float(peephole__Diffuse_6);
#line 466 "peephole.m"
                                                                                              MR_hl_field(MR_mktag(0), *peephole__HeadVar__2_2, 2) = MR_box_float(peephole__Specular_7);
#line 466 "peephole.m"
                                                                                              MR_hl_field(MR_mktag(0), *peephole__HeadVar__2_2, 3) = MR_box_float(peephole__Phong_8);
#line 466 "peephole.m"
                                                                                            }
#line 466 "peephole.m"
                                                                                            peephole__succeeded = TRUE;
                                                                                          }
                                                                                      }
                                                                                  }
                                                                              }
                                                                          }
                                                                      }
                                                                  }
                                                              }
                                                          }
                                                      }
                                                  }
                                              }
                                          }
                                      }
                                  }
                              }
                          }
                      }
                  }
              }
          }
      }
    return peephole__succeeded;
  }
#line 457 "peephole.m"
}
#line 420 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_1_V_488_488[1] = {
		((MR_Box) ((MR_Integer) 6))};
#line 420 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_2_V_487_487[1] = {
		((MR_Box) (&peephole__const_6_0_1_V_488_488))};
#line 431 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_3_V_504_504[1] = {
		((MR_Box) ((MR_Integer) 8))};
#line 431 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_4_V_503_503[1] = {
		((MR_Box) (&peephole__const_6_0_3_V_504_504))};
#line 442 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_5_V_520_520[1] = {
		((MR_Box) ((MR_Integer) 9))};
#line 442 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_6_V_519_519[1] = {
		((MR_Box) (&peephole__const_6_0_5_V_520_520))};
#line 409 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_7_V_472_472[1] = {
		((MR_Box) ((MR_Integer) 32))};
#line 409 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_8_V_471_471[1] = {
		((MR_Box) (&peephole__const_6_0_7_V_472_472))};
#line 398 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_9_V_456_456[1] = {
		((MR_Box) ((MR_Integer) 42))};
#line 398 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_10_V_455_455[1] = {
		((MR_Box) (&peephole__const_6_0_9_V_456_456))};
#line 328 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_11_V_353_353[2] = {
		((MR_Box) (MR_Word) ((MR_Integer) 3)),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 328 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_12_V_351_351[1] = {
		((MR_Box) (MR_mkword(MR_mktag(3), &peephole__const_6_0_11_V_353_353)))};
#line 341 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_13_V_363_363[2] = {
		((MR_Box) (MR_Word) ((MR_Integer) 3)),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 342 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_14_V_362_362[1] = {
		((MR_Box) (MR_mkword(MR_mktag(3), &peephole__const_6_0_13_V_363_363)))};
#line 305 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_15_V_335_335[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 305 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_16_V_334_334[2] = {
		((MR_Box) (MR_Word) ((MR_Integer) 3)),
		((MR_Box) (MR_mkword(MR_mktag(1), &peephole__const_6_0_15_V_335_335)))};
#line 305 "peephole.m"
static /* final */ const MR_Box peephole__const_6_0_17_NewToken_323[1] = {
		((MR_Box) (MR_mkword(MR_mktag(3), &peephole__const_6_0_16_V_334_334)))};

#line 132 "peephole.m"
static bool MR_CALL peephole__match_6_p_0(
#line 132 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 132 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 132 "peephole.m"
  MR_Word peephole__HeadVar__3_3,
#line 132 "peephole.m"
  MR_Word * peephole__HeadVar__4_4,
#line 132 "peephole.m"
  MR_Word peephole__HeadVar__5_5,
#line 132 "peephole.m"
  MR_Word * peephole__HeadVar__6_6)
#line 132 "peephole.m"
{
  {
    bool peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
    MR_Word peephole__V_562_562;

#line 142 "peephole.m"
    if ((MR_tag((MR_Word) peephole__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 142 "peephole.m"
      peephole__V_562_562 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__HeadVar__2_2, (MR_Integer) 0)));
    if (peephole__succeeded)
#line 142 "peephole.m"
#line 142 "peephole.m"
      switch (MR_tag((MR_Word) peephole__V_562_562)) {
#line 142 "peephole.m"
        default:
#line 142 "peephole.m"
          peephole__succeeded = FALSE;
#line 142 "peephole.m"
          break;
#line 142 "peephole.m"
        case (MR_Integer) 3:
#line 142 "peephole.m"
#line 142 "peephole.m"
          switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_562_562, (MR_Integer) 0)))) {
#line 142 "peephole.m"
            default:
#line 142 "peephole.m"
              peephole__succeeded = FALSE;
#line 142 "peephole.m"
              break;
#line 142 "peephole.m"
            case (MR_Integer) 3:
              {
                MR_Integer peephole__N1_370;
                MR_Word peephole__V_384_384 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_562_562, (MR_Integer) 1)));
#line 357 "peephole.m"
                MR_Integer peephole__N2_373;
#line 357 "peephole.m"
                MR_Word peephole__Rest_374;
                MR_Word peephole__V_376_376;
                MR_Word peephole__V_377_377;
                MR_Word peephole__V_378_378;

#line 351 "peephole.m"
                peephole__succeeded = (MR_tag((MR_Word) peephole__V_384_384) == MR_mktag((MR_Integer) 1));
#line 351 "peephole.m"
                if ((MR_tag((MR_Word) peephole__V_384_384) == MR_mktag((MR_Integer) 1)))
#line 351 "peephole.m"
                  peephole__N1_370 = ((MR_Integer) (MR_hl_field(MR_mktag(1), peephole__V_384_384, (MR_Integer) 0)));
                if (peephole__succeeded)
                  {
#line 351 "peephole.m"
                    *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 354 "peephole.m"
                    peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 354 "peephole.m"
                    if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 354 "peephole.m"
                      {
#line 354 "peephole.m"
                        peephole__V_376_376 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 354 "peephole.m"
                        peephole__Rest_374 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 354 "peephole.m"
                      }
                    if (peephole__succeeded)
                      {
#line 354 "peephole.m"
                        peephole__succeeded = (MR_tag((MR_Word) peephole__V_376_376) == MR_mktag((MR_Integer) 0));
#line 354 "peephole.m"
                        if ((MR_tag((MR_Word) peephole__V_376_376) == MR_mktag((MR_Integer) 0)))
#line 354 "peephole.m"
                          peephole__V_377_377 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_376_376, (MR_Integer) 0)));
                        if (peephole__succeeded)
                          {
#line 354 "peephole.m"
                            peephole__succeeded = ((MR_tag((MR_Word) peephole__V_377_377) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_377_377, (MR_Integer) 0))) == (MR_Integer) 3));
#line 354 "peephole.m"
                            if (((MR_tag((MR_Word) peephole__V_377_377) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_377_377, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 354 "peephole.m"
                              peephole__V_378_378 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_377_377, (MR_Integer) 1)));
                            if (peephole__succeeded)
                              {
#line 354 "peephole.m"
                                peephole__succeeded = (MR_tag((MR_Word) peephole__V_378_378) == MR_mktag((MR_Integer) 1));
#line 354 "peephole.m"
                                if ((MR_tag((MR_Word) peephole__V_378_378) == MR_mktag((MR_Integer) 1)))
#line 354 "peephole.m"
                                  peephole__N2_373 = ((MR_Integer) (MR_hl_field(MR_mktag(1), peephole__V_378_378, (MR_Integer) 0)));
                              }
                          }
                      }
#line 357 "peephole.m"
                    if (peephole__succeeded)
                      {
                        MR_Word peephole__V_379_379;
                        MR_Word peephole__V_380_380;
                        MR_Word peephole__V_381_381;
                        MR_Integer peephole__V_382_382 = (peephole__N1_370 + peephole__N2_373);

#line 356 "peephole.m"
                        {
#line 356 "peephole.m"
                          peephole__V_381_381 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "popn"));
#line 356 "peephole.m"
                          MR_hl_field(MR_mktag(1), peephole__V_381_381, 0) = ((MR_Box) (peephole__V_382_382));
#line 356 "peephole.m"
                        }
#line 356 "peephole.m"
                        {
#line 356 "peephole.m"
                          peephole__V_380_380 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "extra"));
#line 356 "peephole.m"
                          MR_hl_field(MR_mktag(3), peephole__V_380_380, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 3));
#line 356 "peephole.m"
                          MR_hl_field(MR_mktag(3), peephole__V_380_380, 1) = ((MR_Box) (peephole__V_381_381));
#line 356 "peephole.m"
                        }
#line 356 "peephole.m"
                        {
#line 356 "peephole.m"
                          peephole__V_379_379 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "single_token");
#line 356 "peephole.m"
                          MR_hl_field(MR_mktag(0), peephole__V_379_379, 0) = ((MR_Box) (peephole__V_380_380));
#line 356 "peephole.m"
                        }
#line 356 "peephole.m"
                        {
#line 356 "peephole.m"
                          *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 356 "peephole.m"
                          MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_379_379));
#line 356 "peephole.m"
                          MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_374));
#line 356 "peephole.m"
                        }
                        peephole__succeeded = TRUE;
                      }
#line 357 "peephole.m"
                    else
                      {
#line 360 "peephole.m"
                        peephole__succeeded = (peephole__N1_370 == (MR_Integer) 1);
                        if (peephole__succeeded)
#line 361 "peephole.m"
                          {
#line 361 "peephole.m"
                            return peephole__succeeded = peephole__remove_code_to_construct_one_value_2_p_0(peephole__HeadVar__3_3, peephole__HeadVar__4_4);
                          }
                      }
                  }
              }
#line 142 "peephole.m"
              break;
#line 142 "peephole.m"
          }
#line 142 "peephole.m"
          break;
#line 142 "peephole.m"
        case (MR_Integer) 0:
          {
            MR_Word peephole__V_563_563 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_562_562, (MR_Integer) 0)));

#line 142 "peephole.m"
#line 142 "peephole.m"
            switch (peephole__V_563_563) {
#line 142 "peephole.m"
              default:
#line 142 "peephole.m"
                peephole__succeeded = FALSE;
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 0:
                {
                  MR_Float peephole__A_20;
                  MR_Word peephole__Rest_21;
                  MR_Word peephole__V_23_23;
                  MR_Float peephole__V_24_24;
                  MR_Word peephole__V_25_25;

#line 148 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 149 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 149 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 149 "peephole.m"
                    {
#line 149 "peephole.m"
                      peephole__V_25_25 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 149 "peephole.m"
                      peephole__Rest_21 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 149 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 149 "peephole.m"
                      {
#line 149 "peephole.m"
                        peephole__succeeded = peephole__real_token_2_f_1(&peephole__A_20, peephole__V_25_25);
                      }
                      if (peephole__succeeded)
                        {
#line 150 "peephole.m"
                          {
#line 150 "peephole.m"
                            peephole__V_24_24 = op__op_acos_2_f_0(peephole__A_20);
                          }
#line 150 "peephole.m"
                          {
#line 150 "peephole.m"
                            peephole__V_23_23 = peephole__real_token_2_f_0(peephole__V_24_24);
                          }
#line 150 "peephole.m"
                          {
#line 150 "peephole.m"
                            *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 150 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_23_23));
#line 150 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_21));
#line 150 "peephole.m"
                          }
#line 150 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 1:
                {
                  MR_Integer peephole__A_31;
                  MR_Integer peephole__B_32;
                  MR_Word peephole__Rest_33;
                  MR_Word peephole__V_35_35;
                  MR_Integer peephole__V_36_36;

#line 152 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 153 "peephole.m"
                  {
#line 153 "peephole.m"
                    peephole__succeeded = peephole__top_two_integer_args_4_p_0(peephole__HeadVar__3_3, &peephole__A_31, &peephole__B_32, &peephole__Rest_33);
                  }
                  if (peephole__succeeded)
                    {
#line 154 "peephole.m"
                      {
#line 154 "peephole.m"
                        peephole__V_36_36 = op__op_addi_3_f_0(peephole__A_31, peephole__B_32);
                      }
#line 154 "peephole.m"
                      {
#line 154 "peephole.m"
                        peephole__V_35_35 = peephole__integer_token_2_f_0(peephole__V_36_36);
                      }
#line 154 "peephole.m"
                      {
#line 154 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 154 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_35_35));
#line 154 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_33));
#line 154 "peephole.m"
                      }
#line 154 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 2:
                {
                  MR_Float peephole__A_42;
                  MR_Float peephole__B_43;
                  MR_Word peephole__Rest_44;
                  MR_Word peephole__V_46_46;
                  MR_Float peephole__V_47_47;

#line 156 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 157 "peephole.m"
                  {
#line 157 "peephole.m"
                    peephole__succeeded = peephole__top_two_real_args_4_p_0(peephole__HeadVar__3_3, &peephole__A_42, &peephole__B_43, &peephole__Rest_44);
                  }
                  if (peephole__succeeded)
                    {
#line 158 "peephole.m"
                      {
#line 158 "peephole.m"
                        peephole__V_47_47 = op__op_addf_3_f_0(peephole__A_42, peephole__B_43);
                      }
#line 158 "peephole.m"
                      {
#line 158 "peephole.m"
                        peephole__V_46_46 = peephole__real_token_2_f_0(peephole__V_47_47);
                      }
#line 158 "peephole.m"
                      {
#line 158 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 158 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_46_46));
#line 158 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_44));
#line 158 "peephole.m"
                      }
#line 158 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 3:
                {
                  MR_Word peephole__FunctionTokens_10;
                  MR_Word peephole__Rest_11;
                  MR_Word peephole__V_13_13;
                  MR_Word peephole__V_14_14;
                  MR_Word peephole__TypeInfo_549_549;
                  MR_Word peephole__TypeInfo_550_550;

#line 143 "peephole.m"
                  {
#line 143 "peephole.m"
                    peephole__succeeded = mercury__std_util__semidet_fail_0_p_0();
                  }
                  if (peephole__succeeded)
                    {
#line 142 "peephole.m"
                      *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 144 "peephole.m"
                      peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 144 "peephole.m"
                      if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 144 "peephole.m"
                        {
#line 144 "peephole.m"
                          peephole__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 144 "peephole.m"
                          peephole__Rest_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 144 "peephole.m"
                        }
                      if (peephole__succeeded)
                        {
#line 144 "peephole.m"
                          peephole__succeeded = (MR_tag((MR_Word) peephole__V_14_14) == MR_mktag((MR_Integer) 1));
#line 144 "peephole.m"
                          if ((MR_tag((MR_Word) peephole__V_14_14) == MR_mktag((MR_Integer) 1)))
#line 144 "peephole.m"
                            peephole__FunctionTokens_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_14_14, (MR_Integer) 0)));
                          if (peephole__succeeded)
                            {
                              peephole__TypeInfo_550_550 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 145 "peephole.m"
                              {
#line 145 "peephole.m"
                                peephole__V_13_13 = mercury__list__reverse_2_f_0(peephole__TypeInfo_550_550, peephole__FunctionTokens_10);
                              }
                              peephole__TypeInfo_549_549 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 145 "peephole.m"
                              {
#line 145 "peephole.m"
                                *peephole__HeadVar__4_4 = mercury__list__append_3_f_0(peephole__TypeInfo_549_549, peephole__V_13_13, peephole__Rest_11);
                              }
#line 145 "peephole.m"
                              peephole__succeeded = TRUE;
                            }
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 4:
                {
                  MR_Float peephole__A_53;
                  MR_Word peephole__Rest_54;
                  MR_Word peephole__V_56_56;
                  MR_Float peephole__V_57_57;
                  MR_Word peephole__V_58_58;

#line 160 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 161 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 161 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 161 "peephole.m"
                    {
#line 161 "peephole.m"
                      peephole__V_58_58 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 161 "peephole.m"
                      peephole__Rest_54 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 161 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 161 "peephole.m"
                      {
#line 161 "peephole.m"
                        peephole__succeeded = peephole__real_token_2_f_1(&peephole__A_53, peephole__V_58_58);
                      }
                      if (peephole__succeeded)
                        {
#line 162 "peephole.m"
                          {
#line 162 "peephole.m"
                            peephole__V_57_57 = op__op_asin_2_f_0(peephole__A_53);
                          }
#line 162 "peephole.m"
                          {
#line 162 "peephole.m"
                            peephole__V_56_56 = peephole__real_token_2_f_0(peephole__V_57_57);
                          }
#line 162 "peephole.m"
                          {
#line 162 "peephole.m"
                            *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 162 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_56_56));
#line 162 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_54));
#line 162 "peephole.m"
                          }
#line 162 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 5:
                {
                  MR_Float peephole__A_64;
                  MR_Word peephole__Rest_65;
                  MR_Word peephole__V_67_67;
                  MR_Float peephole__V_68_68;
                  MR_Word peephole__V_69_69;

#line 164 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 165 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 165 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 165 "peephole.m"
                    {
#line 165 "peephole.m"
                      peephole__V_69_69 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 165 "peephole.m"
                      peephole__Rest_65 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 165 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 165 "peephole.m"
                      {
#line 165 "peephole.m"
                        peephole__succeeded = peephole__real_token_2_f_1(&peephole__A_64, peephole__V_69_69);
                      }
                      if (peephole__succeeded)
                        {
#line 166 "peephole.m"
                          {
#line 166 "peephole.m"
                            peephole__V_68_68 = op__op_clampf_2_f_0(peephole__A_64);
                          }
#line 166 "peephole.m"
                          {
#line 166 "peephole.m"
                            peephole__V_67_67 = peephole__real_token_2_f_0(peephole__V_68_68);
                          }
#line 166 "peephole.m"
                          {
#line 166 "peephole.m"
                            *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 166 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_67_67));
#line 166 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_65));
#line 166 "peephole.m"
                          }
#line 166 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 6:
                {
                  MR_Word peephole__SurfaceFunc_480;
                  MR_Word peephole__Rest_481;
                  MR_Word peephole__V_490_490;
#line 419 "peephole.m"
                  MR_Word peephole__SurfaceProperties_482;

#line 412 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 413 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 413 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 413 "peephole.m"
                    {
#line 413 "peephole.m"
                      peephole__V_490_490 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 413 "peephole.m"
                      peephole__Rest_481 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 413 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 413 "peephole.m"
                      peephole__succeeded = (MR_tag((MR_Word) peephole__V_490_490) == MR_mktag((MR_Integer) 1));
#line 413 "peephole.m"
                      if ((MR_tag((MR_Word) peephole__V_490_490) == MR_mktag((MR_Integer) 1)))
#line 413 "peephole.m"
                        peephole__SurfaceFunc_480 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_490_490, (MR_Integer) 0)));
                      if (peephole__succeeded)
                        {
#line 415 "peephole.m"
                          {
#line 415 "peephole.m"
                            peephole__succeeded = peephole__constant_surface_function_2_p_0(peephole__SurfaceFunc_480, &peephole__SurfaceProperties_482);
                          }
#line 419 "peephole.m"
                          if (peephole__succeeded)
                            {
                              MR_Word peephole__ConstantObj_483;
                              MR_Word peephole__V_485_485;
                              MR_Word peephole__V_486_486;

#line 417 "peephole.m"
                              {
#line 417 "peephole.m"
                                peephole__ConstantObj_483 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "constant_cone"));
#line 417 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__ConstantObj_483, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 1));
#line 417 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__ConstantObj_483, 1) = ((MR_Box) (peephole__SurfaceProperties_482));
#line 417 "peephole.m"
                              }
#line 418 "peephole.m"
                              {
#line 418 "peephole.m"
                                peephole__V_486_486 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "extra"));
#line 418 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__V_486_486, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 3));
#line 418 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__V_486_486, 1) = ((MR_Box) (peephole__ConstantObj_483));
#line 418 "peephole.m"
                              }
#line 418 "peephole.m"
                              {
#line 418 "peephole.m"
                                peephole__V_485_485 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "single_token");
#line 418 "peephole.m"
                                MR_hl_field(MR_mktag(0), peephole__V_485_485, 0) = ((MR_Box) (peephole__V_486_486));
#line 418 "peephole.m"
                              }
#line 418 "peephole.m"
                              {
#line 418 "peephole.m"
                                *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 418 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_485_485));
#line 418 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_481));
#line 418 "peephole.m"
                              }
                            }
#line 419 "peephole.m"
                          else
                            {
                              MR_Word peephole__V_487_487 = (MR_Word) &peephole__const_6_0_2_V_487_487;
                              MR_Word peephole__V_488_488 = (MR_Word) &peephole__const_6_0_1_V_488_488;
                              MR_Word peephole__V_489_489 = (MR_Integer) 6;

#line 420 "peephole.m"
                              {
#line 420 "peephole.m"
                                *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 420 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_487_487));
#line 420 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__HeadVar__3_3));
#line 420 "peephole.m"
                              }
                            }
#line 419 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 7:
                {
                  MR_Float peephole__A_75;
                  MR_Word peephole__Rest_76;
                  MR_Word peephole__V_78_78;
                  MR_Float peephole__V_79_79;
                  MR_Word peephole__V_80_80;

#line 168 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 169 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 169 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 169 "peephole.m"
                    {
#line 169 "peephole.m"
                      peephole__V_80_80 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 169 "peephole.m"
                      peephole__Rest_76 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 169 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 169 "peephole.m"
                      {
#line 169 "peephole.m"
                        peephole__succeeded = peephole__real_token_2_f_1(&peephole__A_75, peephole__V_80_80);
                      }
                      if (peephole__succeeded)
                        {
#line 170 "peephole.m"
                          {
#line 170 "peephole.m"
                            peephole__V_79_79 = op__op_cos_2_f_0(peephole__A_75);
                          }
#line 170 "peephole.m"
                          {
#line 170 "peephole.m"
                            peephole__V_78_78 = peephole__real_token_2_f_0(peephole__V_79_79);
                          }
#line 170 "peephole.m"
                          {
#line 170 "peephole.m"
                            *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 170 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_78_78));
#line 170 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_76));
#line 170 "peephole.m"
                          }
#line 170 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 8:
                {
                  MR_Word peephole__SurfaceFunc_496;
                  MR_Word peephole__Rest_497;
                  MR_Word peephole__V_506_506;
#line 430 "peephole.m"
                  MR_Word peephole__SurfaceProperties_498;

#line 423 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 424 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 424 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 424 "peephole.m"
                    {
#line 424 "peephole.m"
                      peephole__V_506_506 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 424 "peephole.m"
                      peephole__Rest_497 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 424 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 424 "peephole.m"
                      peephole__succeeded = (MR_tag((MR_Word) peephole__V_506_506) == MR_mktag((MR_Integer) 1));
#line 424 "peephole.m"
                      if ((MR_tag((MR_Word) peephole__V_506_506) == MR_mktag((MR_Integer) 1)))
#line 424 "peephole.m"
                        peephole__SurfaceFunc_496 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_506_506, (MR_Integer) 0)));
                      if (peephole__succeeded)
                        {
#line 426 "peephole.m"
                          {
#line 426 "peephole.m"
                            peephole__succeeded = peephole__constant_surface_function_2_p_0(peephole__SurfaceFunc_496, &peephole__SurfaceProperties_498);
                          }
#line 430 "peephole.m"
                          if (peephole__succeeded)
                            {
                              MR_Word peephole__ConstantObj_499;
                              MR_Word peephole__V_501_501;
                              MR_Word peephole__V_502_502;

#line 428 "peephole.m"
                              {
#line 428 "peephole.m"
                                peephole__ConstantObj_499 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "constant_cube"));
#line 428 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__ConstantObj_499, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 2));
#line 428 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__ConstantObj_499, 1) = ((MR_Box) (peephole__SurfaceProperties_498));
#line 428 "peephole.m"
                              }
#line 429 "peephole.m"
                              {
#line 429 "peephole.m"
                                peephole__V_502_502 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "extra"));
#line 429 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__V_502_502, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 3));
#line 429 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__V_502_502, 1) = ((MR_Box) (peephole__ConstantObj_499));
#line 429 "peephole.m"
                              }
#line 429 "peephole.m"
                              {
#line 429 "peephole.m"
                                peephole__V_501_501 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "single_token");
#line 429 "peephole.m"
                                MR_hl_field(MR_mktag(0), peephole__V_501_501, 0) = ((MR_Box) (peephole__V_502_502));
#line 429 "peephole.m"
                              }
#line 429 "peephole.m"
                              {
#line 429 "peephole.m"
                                *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 429 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_501_501));
#line 429 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_497));
#line 429 "peephole.m"
                              }
                            }
#line 430 "peephole.m"
                          else
                            {
                              MR_Word peephole__V_503_503 = (MR_Word) &peephole__const_6_0_4_V_503_503;
                              MR_Word peephole__V_504_504 = (MR_Word) &peephole__const_6_0_3_V_504_504;
                              MR_Word peephole__V_505_505 = (MR_Integer) 8;

#line 431 "peephole.m"
                              {
#line 431 "peephole.m"
                                *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 431 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_503_503));
#line 431 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__HeadVar__3_3));
#line 431 "peephole.m"
                              }
                            }
#line 430 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 9:
                {
                  MR_Word peephole__SurfaceFunc_512;
                  MR_Word peephole__Rest_513;
                  MR_Word peephole__V_522_522;
#line 441 "peephole.m"
                  MR_Word peephole__SurfaceProperties_514;

#line 434 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 435 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 435 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 435 "peephole.m"
                    {
#line 435 "peephole.m"
                      peephole__V_522_522 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 435 "peephole.m"
                      peephole__Rest_513 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 435 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 435 "peephole.m"
                      peephole__succeeded = (MR_tag((MR_Word) peephole__V_522_522) == MR_mktag((MR_Integer) 1));
#line 435 "peephole.m"
                      if ((MR_tag((MR_Word) peephole__V_522_522) == MR_mktag((MR_Integer) 1)))
#line 435 "peephole.m"
                        peephole__SurfaceFunc_512 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_522_522, (MR_Integer) 0)));
                      if (peephole__succeeded)
                        {
#line 437 "peephole.m"
                          {
#line 437 "peephole.m"
                            peephole__succeeded = peephole__constant_surface_function_2_p_0(peephole__SurfaceFunc_512, &peephole__SurfaceProperties_514);
                          }
#line 441 "peephole.m"
                          if (peephole__succeeded)
                            {
                              MR_Word peephole__ConstantObj_515;
                              MR_Word peephole__V_517_517;
                              MR_Word peephole__V_518_518;

#line 439 "peephole.m"
                              {
#line 439 "peephole.m"
                                peephole__ConstantObj_515 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "constant_cylinder"));
#line 439 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__ConstantObj_515, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 3));
#line 439 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__ConstantObj_515, 1) = ((MR_Box) (peephole__SurfaceProperties_514));
#line 439 "peephole.m"
                              }
#line 440 "peephole.m"
                              {
#line 440 "peephole.m"
                                peephole__V_518_518 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "extra"));
#line 440 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__V_518_518, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 3));
#line 440 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__V_518_518, 1) = ((MR_Box) (peephole__ConstantObj_515));
#line 440 "peephole.m"
                              }
#line 440 "peephole.m"
                              {
#line 440 "peephole.m"
                                peephole__V_517_517 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "single_token");
#line 440 "peephole.m"
                                MR_hl_field(MR_mktag(0), peephole__V_517_517, 0) = ((MR_Box) (peephole__V_518_518));
#line 440 "peephole.m"
                              }
#line 440 "peephole.m"
                              {
#line 440 "peephole.m"
                                *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 440 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_517_517));
#line 440 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_513));
#line 440 "peephole.m"
                              }
                            }
#line 441 "peephole.m"
                          else
                            {
                              MR_Word peephole__V_519_519 = (MR_Word) &peephole__const_6_0_6_V_519_519;
                              MR_Word peephole__V_520_520 = (MR_Word) &peephole__const_6_0_5_V_520_520;
                              MR_Word peephole__V_521_521 = (MR_Integer) 9;

#line 442 "peephole.m"
                              {
#line 442 "peephole.m"
                                *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 442 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_519_519));
#line 442 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__HeadVar__3_3));
#line 442 "peephole.m"
                              }
                            }
#line 441 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 11:
                {
                  MR_Integer peephole__A_86;
                  MR_Integer peephole__B_87;
                  MR_Word peephole__Rest_88;
                  MR_Word peephole__V_90_90;
                  MR_Integer peephole__V_91_91;

#line 172 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 173 "peephole.m"
                  {
#line 173 "peephole.m"
                    peephole__succeeded = peephole__top_two_integer_args_4_p_0(peephole__HeadVar__3_3, &peephole__A_86, &peephole__B_87, &peephole__Rest_88);
                  }
                  if (peephole__succeeded)
                    {
#line 174 "peephole.m"
                      {
#line 174 "peephole.m"
                        peephole__V_91_91 = op__op_divi_3_f_0(peephole__A_86, peephole__B_87);
                      }
#line 174 "peephole.m"
                      {
#line 174 "peephole.m"
                        peephole__V_90_90 = peephole__integer_token_2_f_0(peephole__V_91_91);
                      }
#line 174 "peephole.m"
                      {
#line 174 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 174 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_90_90));
#line 174 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_88));
#line 174 "peephole.m"
                      }
#line 174 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 12:
                {
                  MR_Float peephole__A_97;
                  MR_Float peephole__B_98;
                  MR_Word peephole__Rest_99;
                  MR_Word peephole__V_101_101;
                  MR_Float peephole__V_102_102;

#line 176 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 178 "peephole.m"
                  {
#line 178 "peephole.m"
                    peephole__succeeded = peephole__top_two_real_args_4_p_0(peephole__HeadVar__3_3, &peephole__A_97, &peephole__B_98, &peephole__Rest_99);
                  }
                  if (peephole__succeeded)
                    {
#line 180 "peephole.m"
                      {
#line 180 "peephole.m"
                        peephole__V_102_102 = op__op_divf_3_f_0(peephole__A_97, peephole__B_98);
                      }
#line 180 "peephole.m"
                      {
#line 180 "peephole.m"
                        peephole__V_101_101 = peephole__real_token_2_f_0(peephole__V_102_102);
                      }
#line 180 "peephole.m"
                      {
#line 180 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 180 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_101_101));
#line 180 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_99));
#line 180 "peephole.m"
                      }
#line 180 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 13:
                {
                  MR_Integer peephole__A_108;
                  MR_Integer peephole__B_109;
                  MR_Word peephole__Rest_110;
                  MR_Word peephole__V_112_112;
                  MR_Word peephole__V_113_113;

#line 185 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 186 "peephole.m"
                  {
#line 186 "peephole.m"
                    peephole__succeeded = peephole__top_two_integer_args_4_p_0(peephole__HeadVar__3_3, &peephole__A_108, &peephole__B_109, &peephole__Rest_110);
                  }
                  if (peephole__succeeded)
                    {
#line 187 "peephole.m"
                      {
#line 187 "peephole.m"
                        peephole__V_113_113 = op__op_eqi_3_f_0(peephole__A_108, peephole__B_109);
                      }
#line 187 "peephole.m"
                      {
#line 187 "peephole.m"
                        peephole__V_112_112 = peephole__boolean_token_2_f_0(peephole__V_113_113);
                      }
#line 187 "peephole.m"
                      {
#line 187 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 187 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_112_112));
#line 187 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_110));
#line 187 "peephole.m"
                      }
#line 187 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 14:
                {
                  MR_Float peephole__A_119;
                  MR_Float peephole__B_120;
                  MR_Word peephole__Rest_121;
                  MR_Word peephole__V_123_123;
                  MR_Word peephole__V_124_124;

#line 189 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 190 "peephole.m"
                  {
#line 190 "peephole.m"
                    peephole__succeeded = peephole__top_two_real_args_4_p_0(peephole__HeadVar__3_3, &peephole__A_119, &peephole__B_120, &peephole__Rest_121);
                  }
                  if (peephole__succeeded)
                    {
#line 191 "peephole.m"
                      {
#line 191 "peephole.m"
                        peephole__V_124_124 = op__op_eqf_3_f_0(peephole__A_119, peephole__B_120);
                      }
#line 191 "peephole.m"
                      {
#line 191 "peephole.m"
                        peephole__V_123_123 = peephole__boolean_token_2_f_0(peephole__V_124_124);
                      }
#line 191 "peephole.m"
                      {
#line 191 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 191 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_123_123));
#line 191 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_121));
#line 191 "peephole.m"
                      }
#line 191 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 15:
                {
                  MR_Float peephole__A_130;
                  MR_Word peephole__Rest_131;
                  MR_Word peephole__V_133_133;
                  MR_Integer peephole__V_134_134;
                  MR_Word peephole__V_135_135;

#line 193 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 194 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 194 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 194 "peephole.m"
                    {
#line 194 "peephole.m"
                      peephole__V_135_135 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 194 "peephole.m"
                      peephole__Rest_131 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 194 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 194 "peephole.m"
                      {
#line 194 "peephole.m"
                        peephole__succeeded = peephole__real_token_2_f_1(&peephole__A_130, peephole__V_135_135);
                      }
                      if (peephole__succeeded)
                        {
#line 195 "peephole.m"
                          {
#line 195 "peephole.m"
                            peephole__V_134_134 = op__op_floor_2_f_0(peephole__A_130);
                          }
#line 195 "peephole.m"
                          {
#line 195 "peephole.m"
                            peephole__V_133_133 = peephole__integer_token_2_f_0(peephole__V_134_134);
                          }
#line 195 "peephole.m"
                          {
#line 195 "peephole.m"
                            *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 195 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_133_133));
#line 195 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_131));
#line 195 "peephole.m"
                          }
#line 195 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 16:
                {
                  MR_Float peephole__A_141;
                  MR_Word peephole__Rest_142;
                  MR_Word peephole__V_144_144;
                  MR_Float peephole__V_145_145;
                  MR_Word peephole__V_146_146;

#line 197 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 198 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 198 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 198 "peephole.m"
                    {
#line 198 "peephole.m"
                      peephole__V_146_146 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 198 "peephole.m"
                      peephole__Rest_142 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 198 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 198 "peephole.m"
                      {
#line 198 "peephole.m"
                        peephole__succeeded = peephole__real_token_2_f_1(&peephole__A_141, peephole__V_146_146);
                      }
                      if (peephole__succeeded)
                        {
#line 199 "peephole.m"
                          {
#line 199 "peephole.m"
                            peephole__V_145_145 = op__op_frac_2_f_0(peephole__A_141);
                          }
#line 199 "peephole.m"
                          {
#line 199 "peephole.m"
                            peephole__V_144_144 = peephole__real_token_2_f_0(peephole__V_145_145);
                          }
#line 199 "peephole.m"
                          {
#line 199 "peephole.m"
                            *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 199 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_144_144));
#line 199 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_142));
#line 199 "peephole.m"
                          }
#line 199 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 17:
                {
                  MR_Integer peephole__I_528;
                  MR_Word peephole__TokenList_529;
                  MR_Word peephole__Rest_530;
                  MR_Word peephole__X_531;
                  MR_Word peephole__V_533_533;
                  MR_Word peephole__V_534_534;
                  MR_Word peephole__V_535_535;
                  MR_Word peephole__TypeInfo_557_557;
#line 448 "peephole.m"
                  MR_Box peephole__conv1_X_531;

#line 446 "peephole.m"
                  {
#line 446 "peephole.m"
                    peephole__succeeded = mercury__std_util__semidet_fail_0_p_0();
                  }
                  if (peephole__succeeded)
                    {
#line 445 "peephole.m"
                      *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 447 "peephole.m"
                      peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 447 "peephole.m"
                      if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 447 "peephole.m"
                        {
#line 447 "peephole.m"
                          peephole__V_533_533 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 447 "peephole.m"
                          peephole__V_534_534 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 447 "peephole.m"
                        }
                      if (peephole__succeeded)
                        {
#line 447 "peephole.m"
                          {
#line 447 "peephole.m"
                            peephole__succeeded = peephole__integer_token_2_f_1(&peephole__I_528, peephole__V_533_533);
                          }
                          if (peephole__succeeded)
                            {
#line 447 "peephole.m"
                              peephole__succeeded = (MR_tag((MR_Word) peephole__V_534_534) == MR_mktag((MR_Integer) 1));
#line 447 "peephole.m"
                              if ((MR_tag((MR_Word) peephole__V_534_534) == MR_mktag((MR_Integer) 1)))
#line 447 "peephole.m"
                                {
#line 447 "peephole.m"
                                  peephole__V_535_535 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_534_534, (MR_Integer) 0)));
#line 447 "peephole.m"
                                  peephole__Rest_530 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_534_534, (MR_Integer) 1)));
#line 447 "peephole.m"
                                }
                              if (peephole__succeeded)
                                {
#line 447 "peephole.m"
                                  peephole__succeeded = (MR_tag((MR_Word) peephole__V_535_535) == MR_mktag((MR_Integer) 2));
#line 447 "peephole.m"
                                  if ((MR_tag((MR_Word) peephole__V_535_535) == MR_mktag((MR_Integer) 2)))
#line 447 "peephole.m"
                                    peephole__TokenList_529 = ((MR_Word) (MR_hl_field(MR_mktag(2), peephole__V_535_535, (MR_Integer) 0)));
                                  if (peephole__succeeded)
                                    {
                                      peephole__TypeInfo_557_557 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 448 "peephole.m"
                                      {
#line 448 "peephole.m"
                                        peephole__conv1_X_531 = mercury__list__index0_det_3_f_0(peephole__TypeInfo_557_557, peephole__TokenList_529, peephole__I_528);
                                      }
#line 448 "peephole.m"
                                      peephole__X_531 = ((MR_Word) peephole__conv1_X_531);
#line 449 "peephole.m"
                                      {
#line 449 "peephole.m"
                                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 449 "peephole.m"
                                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__X_531));
#line 449 "peephole.m"
                                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_530));
#line 449 "peephole.m"
                                      }
#line 449 "peephole.m"
                                      peephole__succeeded = TRUE;
                                    }
                                }
                            }
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 18:
                {
                  MR_Word peephole__Point_403;
                  MR_Word peephole__Rest_404;
                  MR_Float peephole__X_405;
                  MR_Word peephole__V_409_409;
                  MR_Word peephole__V_410_410;
                  MR_Word peephole__V_411_411;
                  MR_Word peephole__V_412_412;
#line 377 "peephole.m"
                  MR_Float peephole___Y_406;
#line 377 "peephole.m"
                  MR_Float peephole___Z_407;

#line 375 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 376 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 376 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 376 "peephole.m"
                    {
#line 376 "peephole.m"
                      peephole__V_410_410 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 376 "peephole.m"
                      peephole__Rest_404 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 376 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 376 "peephole.m"
                      peephole__succeeded = (MR_tag((MR_Word) peephole__V_410_410) == MR_mktag((MR_Integer) 0));
#line 376 "peephole.m"
                      if ((MR_tag((MR_Word) peephole__V_410_410) == MR_mktag((MR_Integer) 0)))
#line 376 "peephole.m"
                        peephole__V_411_411 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_410_410, (MR_Integer) 0)));
                      if (peephole__succeeded)
                        {
#line 376 "peephole.m"
                          peephole__succeeded = ((MR_tag((MR_Word) peephole__V_411_411) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_411_411, (MR_Integer) 0))) == (MR_Integer) 3));
#line 376 "peephole.m"
                          if (((MR_tag((MR_Word) peephole__V_411_411) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_411_411, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 376 "peephole.m"
                            peephole__V_412_412 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_411_411, (MR_Integer) 1)));
                          if (peephole__succeeded)
                            {
#line 376 "peephole.m"
                              peephole__succeeded = ((MR_tag((MR_Word) peephole__V_412_412) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_412_412, (MR_Integer) 0))) == (MR_Integer) 4));
#line 376 "peephole.m"
                              if (((MR_tag((MR_Word) peephole__V_412_412) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_412_412, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 376 "peephole.m"
                                peephole__Point_403 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_412_412, (MR_Integer) 1)));
                              if (peephole__succeeded)
                                {
#line 377 "peephole.m"
                                  peephole__X_405 = MR_unbox_float((MR_hl_field(MR_mktag(0), peephole__Point_403, (MR_Integer) 0)));
#line 377 "peephole.m"
                                  peephole___Y_406 = MR_unbox_float((MR_hl_field(MR_mktag(0), peephole__Point_403, (MR_Integer) 1)));
#line 377 "peephole.m"
                                  peephole___Z_407 = MR_unbox_float((MR_hl_field(MR_mktag(0), peephole__Point_403, (MR_Integer) 2)));
#line 378 "peephole.m"
                                  {
#line 378 "peephole.m"
                                    peephole__V_409_409 = peephole__real_token_2_f_0(peephole__X_405);
                                  }
#line 378 "peephole.m"
                                  {
#line 378 "peephole.m"
                                    *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 378 "peephole.m"
                                    MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_409_409));
#line 378 "peephole.m"
                                    MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_404));
#line 378 "peephole.m"
                                  }
#line 378 "peephole.m"
                                  peephole__succeeded = TRUE;
                                }
                            }
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 19:
                {
                  MR_Word peephole__Point_418;
                  MR_Word peephole__Rest_419;
                  MR_Float peephole__Y_421;
                  MR_Word peephole__V_424_424;
                  MR_Word peephole__V_425_425;
                  MR_Word peephole__V_426_426;
                  MR_Word peephole__V_427_427;
#line 381 "peephole.m"
                  MR_Float peephole___X_420;
#line 381 "peephole.m"
                  MR_Float peephole___Z_422;

#line 379 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 380 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 380 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 380 "peephole.m"
                    {
#line 380 "peephole.m"
                      peephole__V_425_425 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 380 "peephole.m"
                      peephole__Rest_419 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 380 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 380 "peephole.m"
                      peephole__succeeded = (MR_tag((MR_Word) peephole__V_425_425) == MR_mktag((MR_Integer) 0));
#line 380 "peephole.m"
                      if ((MR_tag((MR_Word) peephole__V_425_425) == MR_mktag((MR_Integer) 0)))
#line 380 "peephole.m"
                        peephole__V_426_426 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_425_425, (MR_Integer) 0)));
                      if (peephole__succeeded)
                        {
#line 380 "peephole.m"
                          peephole__succeeded = ((MR_tag((MR_Word) peephole__V_426_426) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_426_426, (MR_Integer) 0))) == (MR_Integer) 3));
#line 380 "peephole.m"
                          if (((MR_tag((MR_Word) peephole__V_426_426) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_426_426, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 380 "peephole.m"
                            peephole__V_427_427 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_426_426, (MR_Integer) 1)));
                          if (peephole__succeeded)
                            {
#line 380 "peephole.m"
                              peephole__succeeded = ((MR_tag((MR_Word) peephole__V_427_427) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_427_427, (MR_Integer) 0))) == (MR_Integer) 4));
#line 380 "peephole.m"
                              if (((MR_tag((MR_Word) peephole__V_427_427) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_427_427, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 380 "peephole.m"
                                peephole__Point_418 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_427_427, (MR_Integer) 1)));
                              if (peephole__succeeded)
                                {
#line 381 "peephole.m"
                                  peephole___X_420 = MR_unbox_float((MR_hl_field(MR_mktag(0), peephole__Point_418, (MR_Integer) 0)));
#line 381 "peephole.m"
                                  peephole__Y_421 = MR_unbox_float((MR_hl_field(MR_mktag(0), peephole__Point_418, (MR_Integer) 1)));
#line 381 "peephole.m"
                                  peephole___Z_422 = MR_unbox_float((MR_hl_field(MR_mktag(0), peephole__Point_418, (MR_Integer) 2)));
#line 382 "peephole.m"
                                  {
#line 382 "peephole.m"
                                    peephole__V_424_424 = peephole__real_token_2_f_0(peephole__Y_421);
                                  }
#line 382 "peephole.m"
                                  {
#line 382 "peephole.m"
                                    *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 382 "peephole.m"
                                    MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_424_424));
#line 382 "peephole.m"
                                    MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_419));
#line 382 "peephole.m"
                                  }
#line 382 "peephole.m"
                                  peephole__succeeded = TRUE;
                                }
                            }
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 20:
                {
                  MR_Word peephole__Point_433;
                  MR_Word peephole__Rest_434;
                  MR_Float peephole__Z_437;
                  MR_Word peephole__V_439_439;
                  MR_Word peephole__V_440_440;
                  MR_Word peephole__V_441_441;
                  MR_Word peephole__V_442_442;
#line 385 "peephole.m"
                  MR_Float peephole___X_435;
#line 385 "peephole.m"
                  MR_Float peephole___Y_436;

#line 383 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 384 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 384 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 384 "peephole.m"
                    {
#line 384 "peephole.m"
                      peephole__V_440_440 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 384 "peephole.m"
                      peephole__Rest_434 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 384 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 384 "peephole.m"
                      peephole__succeeded = (MR_tag((MR_Word) peephole__V_440_440) == MR_mktag((MR_Integer) 0));
#line 384 "peephole.m"
                      if ((MR_tag((MR_Word) peephole__V_440_440) == MR_mktag((MR_Integer) 0)))
#line 384 "peephole.m"
                        peephole__V_441_441 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_440_440, (MR_Integer) 0)));
                      if (peephole__succeeded)
                        {
#line 384 "peephole.m"
                          peephole__succeeded = ((MR_tag((MR_Word) peephole__V_441_441) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_441_441, (MR_Integer) 0))) == (MR_Integer) 3));
#line 384 "peephole.m"
                          if (((MR_tag((MR_Word) peephole__V_441_441) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_441_441, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 384 "peephole.m"
                            peephole__V_442_442 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_441_441, (MR_Integer) 1)));
                          if (peephole__succeeded)
                            {
#line 384 "peephole.m"
                              peephole__succeeded = ((MR_tag((MR_Word) peephole__V_442_442) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_442_442, (MR_Integer) 0))) == (MR_Integer) 4));
#line 384 "peephole.m"
                              if (((MR_tag((MR_Word) peephole__V_442_442) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_442_442, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 384 "peephole.m"
                                peephole__Point_433 = ((MR_Word) (MR_hl_field(MR_mktag(3), peephole__V_442_442, (MR_Integer) 1)));
                              if (peephole__succeeded)
                                {
#line 385 "peephole.m"
                                  peephole___X_435 = MR_unbox_float((MR_hl_field(MR_mktag(0), peephole__Point_433, (MR_Integer) 0)));
#line 385 "peephole.m"
                                  peephole___Y_436 = MR_unbox_float((MR_hl_field(MR_mktag(0), peephole__Point_433, (MR_Integer) 1)));
#line 385 "peephole.m"
                                  peephole__Z_437 = MR_unbox_float((MR_hl_field(MR_mktag(0), peephole__Point_433, (MR_Integer) 2)));
#line 386 "peephole.m"
                                  {
#line 386 "peephole.m"
                                    peephole__V_439_439 = peephole__real_token_2_f_0(peephole__Z_437);
                                  }
#line 386 "peephole.m"
                                  {
#line 386 "peephole.m"
                                    *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 386 "peephole.m"
                                    MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_439_439));
#line 386 "peephole.m"
                                    MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_434));
#line 386 "peephole.m"
                                  }
#line 386 "peephole.m"
                                  peephole__succeeded = TRUE;
                                }
                            }
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 21:
                {
#line 265 "peephole.m"
                  MR_Word peephole__False_285;
#line 265 "peephole.m"
                  MR_Word peephole__True_286;
#line 265 "peephole.m"
                  MR_Word peephole__YesNo_287;
#line 265 "peephole.m"
                  MR_Word peephole__Rest_288;
                  MR_Word peephole__V_294_294;
                  MR_Word peephole__V_295_295;
                  MR_Word peephole__V_296_296;
                  MR_Word peephole__V_297_297;
                  MR_Word peephole__V_298_298;

#line 250 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 253 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 253 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 253 "peephole.m"
                    {
#line 253 "peephole.m"
                      peephole__V_294_294 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 253 "peephole.m"
                      peephole__V_295_295 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 253 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 253 "peephole.m"
                      peephole__succeeded = (MR_tag((MR_Word) peephole__V_294_294) == MR_mktag((MR_Integer) 1));
#line 253 "peephole.m"
                      if ((MR_tag((MR_Word) peephole__V_294_294) == MR_mktag((MR_Integer) 1)))
#line 253 "peephole.m"
                        peephole__False_285 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_294_294, (MR_Integer) 0)));
                      if (peephole__succeeded)
                        {
#line 253 "peephole.m"
                          peephole__succeeded = (MR_tag((MR_Word) peephole__V_295_295) == MR_mktag((MR_Integer) 1));
#line 253 "peephole.m"
                          if ((MR_tag((MR_Word) peephole__V_295_295) == MR_mktag((MR_Integer) 1)))
#line 253 "peephole.m"
                            {
#line 253 "peephole.m"
                              peephole__V_296_296 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_295_295, (MR_Integer) 0)));
#line 253 "peephole.m"
                              peephole__V_297_297 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_295_295, (MR_Integer) 1)));
#line 253 "peephole.m"
                            }
                          if (peephole__succeeded)
                            {
#line 253 "peephole.m"
                              peephole__succeeded = (MR_tag((MR_Word) peephole__V_296_296) == MR_mktag((MR_Integer) 1));
#line 253 "peephole.m"
                              if ((MR_tag((MR_Word) peephole__V_296_296) == MR_mktag((MR_Integer) 1)))
#line 253 "peephole.m"
                                peephole__True_286 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_296_296, (MR_Integer) 0)));
                              if (peephole__succeeded)
                                {
#line 253 "peephole.m"
                                  peephole__succeeded = (MR_tag((MR_Word) peephole__V_297_297) == MR_mktag((MR_Integer) 1));
#line 253 "peephole.m"
                                  if ((MR_tag((MR_Word) peephole__V_297_297) == MR_mktag((MR_Integer) 1)))
#line 253 "peephole.m"
                                    {
#line 253 "peephole.m"
                                      peephole__V_298_298 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_297_297, (MR_Integer) 0)));
#line 253 "peephole.m"
                                      peephole__Rest_288 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_297_297, (MR_Integer) 1)));
#line 253 "peephole.m"
                                    }
                                  if (peephole__succeeded)
#line 254 "peephole.m"
                                    {
#line 254 "peephole.m"
                                      peephole__succeeded = peephole__boolean_token_2_f_1(&peephole__YesNo_287, peephole__V_298_298);
                                    }
                                }
                            }
                        }
                    }
#line 265 "peephole.m"
                  if (peephole__succeeded)
#line 260 "peephole.m"
                    {
#line 260 "peephole.m"
#line 260 "peephole.m"
                      switch (peephole__YesNo_287) {
#line 260 "peephole.m"
                        default: /*NOTREACHED*/ MR_assert(0);
#line 260 "peephole.m"
                        case (MR_Integer) 0:
                          {
                            MR_Word peephole__V_299_299;
                            MR_Word peephole__TypeInfo_553_553;
                            MR_Word peephole__TypeInfo_554_554 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 263 "peephole.m"
                            {
#line 263 "peephole.m"
                              peephole__V_299_299 = mercury__list__reverse_2_f_0(peephole__TypeInfo_554_554, peephole__False_285);
                            }
                            peephole__TypeInfo_553_553 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 262 "peephole.m"
                            {
#line 262 "peephole.m"
                              *peephole__HeadVar__4_4 = mercury__list__append_3_f_0(peephole__TypeInfo_553_553, peephole__V_299_299, peephole__Rest_288);
                            }
                          }
#line 260 "peephole.m"
                          break;
#line 260 "peephole.m"
                        case (MR_Integer) 1:
                          {
                            MR_Word peephole__V_300_300;
                            MR_Word peephole__TypeInfo_551_551;
                            MR_Word peephole__TypeInfo_552_552 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 259 "peephole.m"
                            {
#line 259 "peephole.m"
                              peephole__V_300_300 = mercury__list__reverse_2_f_0(peephole__TypeInfo_552_552, peephole__True_286);
                            }
                            peephole__TypeInfo_551_551 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 258 "peephole.m"
                            {
#line 258 "peephole.m"
                              *peephole__HeadVar__4_4 = mercury__list__append_3_f_0(peephole__TypeInfo_551_551, peephole__V_300_300, peephole__Rest_288);
                            }
                          }
#line 260 "peephole.m"
                          break;
#line 260 "peephole.m"
                      }
#line 260 "peephole.m"
                      peephole__succeeded = TRUE;
#line 260 "peephole.m"
                    }
#line 265 "peephole.m"
                  else
                    {
                      MR_Word peephole__FalseConst_289;
                      MR_Word peephole__TrueConst_290;
                      MR_Word peephole__FalseValue_291;
                      MR_Word peephole__TrueValue_292;
                      MR_Word peephole__V_301_301;
                      MR_Word peephole__V_302_302;
                      MR_Word peephole__V_303_303;
                      MR_Word peephole__V_304_304;
                      MR_Word peephole__V_305_305;
                      MR_Word peephole__V_306_306;
                      MR_Word peephole__V_307_307;
                      MR_Word peephole__V_308_308;
                      MR_Word peephole__False_311;
                      MR_Word peephole__True_312;
                      MR_Word peephole__Rest_315;

#line 267 "peephole.m"
                      peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 267 "peephole.m"
                      if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 267 "peephole.m"
                        {
#line 267 "peephole.m"
                          peephole__V_303_303 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 267 "peephole.m"
                          peephole__V_304_304 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 267 "peephole.m"
                        }
                      if (peephole__succeeded)
                        {
#line 267 "peephole.m"
                          peephole__succeeded = (MR_tag((MR_Word) peephole__V_303_303) == MR_mktag((MR_Integer) 1));
#line 267 "peephole.m"
                          if ((MR_tag((MR_Word) peephole__V_303_303) == MR_mktag((MR_Integer) 1)))
#line 267 "peephole.m"
                            peephole__False_311 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_303_303, (MR_Integer) 0)));
                          if (peephole__succeeded)
                            {
#line 267 "peephole.m"
                              peephole__succeeded = (MR_tag((MR_Word) peephole__V_304_304) == MR_mktag((MR_Integer) 1));
#line 267 "peephole.m"
                              if ((MR_tag((MR_Word) peephole__V_304_304) == MR_mktag((MR_Integer) 1)))
#line 267 "peephole.m"
                                {
#line 267 "peephole.m"
                                  peephole__V_305_305 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_304_304, (MR_Integer) 0)));
#line 267 "peephole.m"
                                  peephole__Rest_315 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_304_304, (MR_Integer) 1)));
#line 267 "peephole.m"
                                }
                              if (peephole__succeeded)
                                {
#line 267 "peephole.m"
                                  peephole__succeeded = (MR_tag((MR_Word) peephole__V_305_305) == MR_mktag((MR_Integer) 1));
#line 267 "peephole.m"
                                  if ((MR_tag((MR_Word) peephole__V_305_305) == MR_mktag((MR_Integer) 1)))
#line 267 "peephole.m"
                                    peephole__True_312 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_305_305, (MR_Integer) 0)));
                                  if (peephole__succeeded)
                                    {
#line 268 "peephole.m"
                                      peephole__succeeded = (MR_tag((MR_Word) peephole__False_311) == MR_mktag((MR_Integer) 1));
#line 268 "peephole.m"
                                      if ((MR_tag((MR_Word) peephole__False_311) == MR_mktag((MR_Integer) 1)))
#line 268 "peephole.m"
                                        {
#line 268 "peephole.m"
                                          peephole__FalseConst_289 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__False_311, (MR_Integer) 0)));
#line 268 "peephole.m"
                                          peephole__V_302_302 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__False_311, (MR_Integer) 1)));
#line 268 "peephole.m"
                                        }
                                      if (peephole__succeeded)
                                        {
#line 268 "peephole.m"
                                          peephole__succeeded = (peephole__V_302_302 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
                                          if (peephole__succeeded)
                                            {
#line 269 "peephole.m"
                                              peephole__succeeded = (MR_tag((MR_Word) peephole__True_312) == MR_mktag((MR_Integer) 1));
#line 269 "peephole.m"
                                              if ((MR_tag((MR_Word) peephole__True_312) == MR_mktag((MR_Integer) 1)))
#line 269 "peephole.m"
                                                {
#line 269 "peephole.m"
                                                  peephole__TrueConst_290 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__True_312, (MR_Integer) 0)));
#line 269 "peephole.m"
                                                  peephole__V_301_301 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__True_312, (MR_Integer) 1)));
#line 269 "peephole.m"
                                                }
                                              if (peephole__succeeded)
                                                {
#line 269 "peephole.m"
                                                  peephole__succeeded = (peephole__V_301_301 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
                                                  if (peephole__succeeded)
                                                    {
#line 270 "peephole.m"
                                                      {
#line 270 "peephole.m"
                                                        peephole__succeeded = peephole__constant_value_2_p_0(peephole__FalseConst_289, &peephole__FalseValue_291);
                                                      }
                                                      if (peephole__succeeded)
                                                        {
#line 271 "peephole.m"
                                                          {
#line 271 "peephole.m"
                                                            peephole__succeeded = peephole__constant_value_2_p_0(peephole__TrueConst_290, &peephole__TrueValue_292);
                                                          }
                                                          if (peephole__succeeded)
                                                            {
#line 273 "peephole.m"
                                                              {
#line 273 "peephole.m"
                                                                peephole__V_308_308 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "constant_if"));
#line 273 "peephole.m"
                                                                MR_hl_field(MR_mktag(3), peephole__V_308_308, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 5));
#line 273 "peephole.m"
                                                                MR_hl_field(MR_mktag(3), peephole__V_308_308, 1) = ((MR_Box) (peephole__TrueValue_292));
#line 273 "peephole.m"
                                                                MR_hl_field(MR_mktag(3), peephole__V_308_308, 2) = ((MR_Box) (peephole__FalseValue_291));
#line 273 "peephole.m"
                                                              }
#line 273 "peephole.m"
                                                              {
#line 273 "peephole.m"
                                                                peephole__V_307_307 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "extra"));
#line 273 "peephole.m"
                                                                MR_hl_field(MR_mktag(3), peephole__V_307_307, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 3));
#line 273 "peephole.m"
                                                                MR_hl_field(MR_mktag(3), peephole__V_307_307, 1) = ((MR_Box) (peephole__V_308_308));
#line 273 "peephole.m"
                                                              }
#line 274 "peephole.m"
                                                              {
#line 274 "peephole.m"
                                                                peephole__V_306_306 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "single_token");
#line 274 "peephole.m"
                                                                MR_hl_field(MR_mktag(0), peephole__V_306_306, 0) = ((MR_Box) (peephole__V_307_307));
#line 274 "peephole.m"
                                                              }
#line 273 "peephole.m"
                                                              {
#line 273 "peephole.m"
                                                                *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 273 "peephole.m"
                                                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_306_306));
#line 273 "peephole.m"
                                                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_315));
#line 273 "peephole.m"
                                                              }
#line 273 "peephole.m"
                                                              peephole__succeeded = TRUE;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 23:
                {
                  MR_Word peephole__TokenList_541;
                  MR_Word peephole__Rest_542;
                  MR_Word peephole__V_544_544;
                  MR_Integer peephole__V_545_545;
                  MR_Word peephole__V_546_546;
                  MR_Word peephole__TypeInfo_558_558;

#line 452 "peephole.m"
                  {
#line 452 "peephole.m"
                    peephole__succeeded = mercury__std_util__semidet_fail_0_p_0();
                  }
                  if (peephole__succeeded)
                    {
#line 451 "peephole.m"
                      *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 453 "peephole.m"
                      peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 453 "peephole.m"
                      if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 453 "peephole.m"
                        {
#line 453 "peephole.m"
                          peephole__V_546_546 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 453 "peephole.m"
                          peephole__Rest_542 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 453 "peephole.m"
                        }
                      if (peephole__succeeded)
                        {
#line 453 "peephole.m"
                          peephole__succeeded = (MR_tag((MR_Word) peephole__V_546_546) == MR_mktag((MR_Integer) 2));
#line 453 "peephole.m"
                          if ((MR_tag((MR_Word) peephole__V_546_546) == MR_mktag((MR_Integer) 2)))
#line 453 "peephole.m"
                            peephole__TokenList_541 = ((MR_Word) (MR_hl_field(MR_mktag(2), peephole__V_546_546, (MR_Integer) 0)));
                          if (peephole__succeeded)
                            {
                              peephole__TypeInfo_558_558 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 454 "peephole.m"
                              {
#line 454 "peephole.m"
                                peephole__V_545_545 = mercury__list__length_2_f_0(peephole__TypeInfo_558_558, peephole__TokenList_541);
                              }
#line 454 "peephole.m"
                              {
#line 454 "peephole.m"
                                peephole__V_544_544 = peephole__integer_token_2_f_0(peephole__V_545_545);
                              }
#line 454 "peephole.m"
                              {
#line 454 "peephole.m"
                                *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 454 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_544_544));
#line 454 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_542));
#line 454 "peephole.m"
                              }
#line 454 "peephole.m"
                              peephole__succeeded = TRUE;
                            }
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 24:
                {
                  MR_Integer peephole__A_152;
                  MR_Integer peephole__B_153;
                  MR_Word peephole__Rest_154;
                  MR_Word peephole__V_156_156;
                  MR_Word peephole__V_157_157;

#line 201 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 202 "peephole.m"
                  {
#line 202 "peephole.m"
                    peephole__succeeded = peephole__top_two_integer_args_4_p_0(peephole__HeadVar__3_3, &peephole__A_152, &peephole__B_153, &peephole__Rest_154);
                  }
                  if (peephole__succeeded)
                    {
#line 203 "peephole.m"
                      {
#line 203 "peephole.m"
                        peephole__V_157_157 = op__op_lessi_3_f_0(peephole__A_152, peephole__B_153);
                      }
#line 203 "peephole.m"
                      {
#line 203 "peephole.m"
                        peephole__V_156_156 = peephole__boolean_token_2_f_0(peephole__V_157_157);
                      }
#line 203 "peephole.m"
                      {
#line 203 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 203 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_156_156));
#line 203 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_154));
#line 203 "peephole.m"
                      }
#line 203 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 25:
                {
                  MR_Float peephole__A_163;
                  MR_Float peephole__B_164;
                  MR_Word peephole__Rest_165;
                  MR_Word peephole__V_167_167;
                  MR_Word peephole__V_168_168;

#line 205 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 206 "peephole.m"
                  {
#line 206 "peephole.m"
                    peephole__succeeded = peephole__top_two_real_args_4_p_0(peephole__HeadVar__3_3, &peephole__A_163, &peephole__B_164, &peephole__Rest_165);
                  }
                  if (peephole__succeeded)
                    {
#line 207 "peephole.m"
                      {
#line 207 "peephole.m"
                        peephole__V_168_168 = op__op_lessf_3_f_0(peephole__A_163, peephole__B_164);
                      }
#line 207 "peephole.m"
                      {
#line 207 "peephole.m"
                        peephole__V_167_167 = peephole__boolean_token_2_f_0(peephole__V_168_168);
                      }
#line 207 "peephole.m"
                      {
#line 207 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 207 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_167_167));
#line 207 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_165));
#line 207 "peephole.m"
                      }
#line 207 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 27:
                {
                  MR_Integer peephole__A_174;
                  MR_Integer peephole__B_175;
                  MR_Word peephole__Rest_176;
                  MR_Word peephole__V_178_178;
                  MR_Integer peephole__V_179_179;

#line 209 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 210 "peephole.m"
                  {
#line 210 "peephole.m"
                    peephole__succeeded = peephole__top_two_integer_args_4_p_0(peephole__HeadVar__3_3, &peephole__A_174, &peephole__B_175, &peephole__Rest_176);
                  }
                  if (peephole__succeeded)
                    {
#line 211 "peephole.m"
                      {
#line 211 "peephole.m"
                        peephole__V_179_179 = op__op_modi_3_f_0(peephole__A_174, peephole__B_175);
                      }
#line 211 "peephole.m"
                      {
#line 211 "peephole.m"
                        peephole__V_178_178 = peephole__integer_token_2_f_0(peephole__V_179_179);
                      }
#line 211 "peephole.m"
                      {
#line 211 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 211 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_178_178));
#line 211 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_176));
#line 211 "peephole.m"
                      }
#line 211 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 28:
                {
                  MR_Integer peephole__A_185;
                  MR_Integer peephole__B_186;
                  MR_Word peephole__Rest_187;
                  MR_Word peephole__V_189_189;
                  MR_Integer peephole__V_190_190;

#line 213 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 214 "peephole.m"
                  {
#line 214 "peephole.m"
                    peephole__succeeded = peephole__top_two_integer_args_4_p_0(peephole__HeadVar__3_3, &peephole__A_185, &peephole__B_186, &peephole__Rest_187);
                  }
                  if (peephole__succeeded)
                    {
#line 215 "peephole.m"
                      {
#line 215 "peephole.m"
                        peephole__V_190_190 = op__op_muli_3_f_0(peephole__A_185, peephole__B_186);
                      }
#line 215 "peephole.m"
                      {
#line 215 "peephole.m"
                        peephole__V_189_189 = peephole__integer_token_2_f_0(peephole__V_190_190);
                      }
#line 215 "peephole.m"
                      {
#line 215 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 215 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_189_189));
#line 215 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_187));
#line 215 "peephole.m"
                      }
#line 215 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 29:
                {
                  MR_Float peephole__A_196;
                  MR_Float peephole__B_197;
                  MR_Word peephole__Rest_198;
                  MR_Word peephole__V_200_200;
                  MR_Float peephole__V_201_201;

#line 217 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 218 "peephole.m"
                  {
#line 218 "peephole.m"
                    peephole__succeeded = peephole__top_two_real_args_4_p_0(peephole__HeadVar__3_3, &peephole__A_196, &peephole__B_197, &peephole__Rest_198);
                  }
                  if (peephole__succeeded)
                    {
#line 219 "peephole.m"
                      {
#line 219 "peephole.m"
                        peephole__V_201_201 = op__op_mulf_3_f_0(peephole__A_196, peephole__B_197);
                      }
#line 219 "peephole.m"
                      {
#line 219 "peephole.m"
                        peephole__V_200_200 = peephole__real_token_2_f_0(peephole__V_201_201);
                      }
#line 219 "peephole.m"
                      {
#line 219 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 219 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_200_200));
#line 219 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_198));
#line 219 "peephole.m"
                      }
#line 219 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 30:
                {
                  MR_Integer peephole__A_207;
                  MR_Word peephole__Rest_208;
                  MR_Word peephole__V_210_210;
                  MR_Integer peephole__V_211_211;
                  MR_Word peephole__V_212_212;

#line 221 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 222 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 222 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 222 "peephole.m"
                    {
#line 222 "peephole.m"
                      peephole__V_212_212 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 222 "peephole.m"
                      peephole__Rest_208 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 222 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 222 "peephole.m"
                      {
#line 222 "peephole.m"
                        peephole__succeeded = peephole__integer_token_2_f_1(&peephole__A_207, peephole__V_212_212);
                      }
                      if (peephole__succeeded)
                        {
#line 223 "peephole.m"
                          {
#line 223 "peephole.m"
                            peephole__V_211_211 = op__op_negi_2_f_0(peephole__A_207);
                          }
#line 223 "peephole.m"
                          {
#line 223 "peephole.m"
                            peephole__V_210_210 = peephole__integer_token_2_f_0(peephole__V_211_211);
                          }
#line 223 "peephole.m"
                          {
#line 223 "peephole.m"
                            *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 223 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_210_210));
#line 223 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_208));
#line 223 "peephole.m"
                          }
#line 223 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 31:
                {
                  MR_Float peephole__A_218;
                  MR_Word peephole__Rest_219;
                  MR_Word peephole__V_221_221;
                  MR_Float peephole__V_222_222;
                  MR_Word peephole__V_223_223;

#line 225 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 226 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 226 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 226 "peephole.m"
                    {
#line 226 "peephole.m"
                      peephole__V_223_223 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 226 "peephole.m"
                      peephole__Rest_219 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 226 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 226 "peephole.m"
                      {
#line 226 "peephole.m"
                        peephole__succeeded = peephole__real_token_2_f_1(&peephole__A_218, peephole__V_223_223);
                      }
                      if (peephole__succeeded)
                        {
#line 227 "peephole.m"
                          {
#line 227 "peephole.m"
                            peephole__V_222_222 = op__op_negf_2_f_0(peephole__A_218);
                          }
#line 227 "peephole.m"
                          {
#line 227 "peephole.m"
                            peephole__V_221_221 = peephole__real_token_2_f_0(peephole__V_222_222);
                          }
#line 227 "peephole.m"
                          {
#line 227 "peephole.m"
                            *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 227 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_221_221));
#line 227 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_219));
#line 227 "peephole.m"
                          }
#line 227 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 32:
                {
                  MR_Word peephole__SurfaceFunc_464;
                  MR_Word peephole__Rest_465;
                  MR_Word peephole__V_474_474;
#line 408 "peephole.m"
                  MR_Word peephole__SurfaceProperties_466;

#line 401 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 402 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 402 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 402 "peephole.m"
                    {
#line 402 "peephole.m"
                      peephole__V_474_474 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 402 "peephole.m"
                      peephole__Rest_465 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 402 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 402 "peephole.m"
                      peephole__succeeded = (MR_tag((MR_Word) peephole__V_474_474) == MR_mktag((MR_Integer) 1));
#line 402 "peephole.m"
                      if ((MR_tag((MR_Word) peephole__V_474_474) == MR_mktag((MR_Integer) 1)))
#line 402 "peephole.m"
                        peephole__SurfaceFunc_464 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_474_474, (MR_Integer) 0)));
                      if (peephole__succeeded)
                        {
#line 404 "peephole.m"
                          {
#line 404 "peephole.m"
                            peephole__succeeded = peephole__constant_surface_function_2_p_0(peephole__SurfaceFunc_464, &peephole__SurfaceProperties_466);
                          }
#line 408 "peephole.m"
                          if (peephole__succeeded)
                            {
                              MR_Word peephole__ConstantObj_467;
                              MR_Word peephole__V_469_469;
                              MR_Word peephole__V_470_470;

#line 406 "peephole.m"
                              {
#line 406 "peephole.m"
                                peephole__ConstantObj_467 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "constant_plane"));
#line 406 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__ConstantObj_467, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 0));
#line 406 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__ConstantObj_467, 1) = ((MR_Box) (peephole__SurfaceProperties_466));
#line 406 "peephole.m"
                              }
#line 407 "peephole.m"
                              {
#line 407 "peephole.m"
                                peephole__V_470_470 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "extra"));
#line 407 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__V_470_470, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 3));
#line 407 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__V_470_470, 1) = ((MR_Box) (peephole__ConstantObj_467));
#line 407 "peephole.m"
                              }
#line 407 "peephole.m"
                              {
#line 407 "peephole.m"
                                peephole__V_469_469 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "single_token");
#line 407 "peephole.m"
                                MR_hl_field(MR_mktag(0), peephole__V_469_469, 0) = ((MR_Box) (peephole__V_470_470));
#line 407 "peephole.m"
                              }
#line 407 "peephole.m"
                              {
#line 407 "peephole.m"
                                *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 407 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_469_469));
#line 407 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_465));
#line 407 "peephole.m"
                              }
                            }
#line 408 "peephole.m"
                          else
                            {
                              MR_Word peephole__V_471_471 = (MR_Word) &peephole__const_6_0_8_V_471_471;
                              MR_Word peephole__V_472_472 = (MR_Word) &peephole__const_6_0_7_V_472_472;
                              MR_Word peephole__V_473_473 = (MR_Integer) 32;

#line 409 "peephole.m"
                              {
#line 409 "peephole.m"
                                *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 409 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_471_471));
#line 409 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__HeadVar__3_3));
#line 409 "peephole.m"
                              }
                            }
#line 408 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 33:
                {
                  MR_Float peephole__R_389;
                  MR_Float peephole__G_390;
                  MR_Float peephole__B_391;
                  MR_Word peephole__Rest_392;
                  MR_Word peephole__Point_393;
                  MR_Word peephole__V_395_395;
                  MR_Word peephole__V_396_396;
                  MR_Word peephole__V_397_397;

#line 369 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 370 "peephole.m"
                  {
#line 370 "peephole.m"
                    peephole__succeeded = peephole__top_three_real_args_5_p_0(peephole__HeadVar__3_3, &peephole__R_389, &peephole__G_390, &peephole__B_391, &peephole__Rest_392);
                  }
                  if (peephole__succeeded)
                    {
#line 371 "peephole.m"
                      {
#line 371 "peephole.m"
                        peephole__Point_393 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 371 "peephole.m"
                        MR_hl_field(MR_mktag(0), peephole__Point_393, 0) = MR_box_float(peephole__R_389);
#line 371 "peephole.m"
                        MR_hl_field(MR_mktag(0), peephole__Point_393, 1) = MR_box_float(peephole__G_390);
#line 371 "peephole.m"
                        MR_hl_field(MR_mktag(0), peephole__Point_393, 2) = MR_box_float(peephole__B_391);
#line 371 "peephole.m"
                      }
#line 372 "peephole.m"
                      {
#line 372 "peephole.m"
                        peephole__V_397_397 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "constant_point"));
#line 372 "peephole.m"
                        MR_hl_field(MR_mktag(3), peephole__V_397_397, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 372 "peephole.m"
                        MR_hl_field(MR_mktag(3), peephole__V_397_397, 1) = ((MR_Box) (peephole__Point_393));
#line 372 "peephole.m"
                      }
#line 372 "peephole.m"
                      {
#line 372 "peephole.m"
                        peephole__V_396_396 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "extra"));
#line 372 "peephole.m"
                        MR_hl_field(MR_mktag(3), peephole__V_396_396, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 3));
#line 372 "peephole.m"
                        MR_hl_field(MR_mktag(3), peephole__V_396_396, 1) = ((MR_Box) (peephole__V_397_397));
#line 372 "peephole.m"
                      }
#line 372 "peephole.m"
                      {
#line 372 "peephole.m"
                        peephole__V_395_395 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "single_token");
#line 372 "peephole.m"
                        MR_hl_field(MR_mktag(0), peephole__V_395_395, 0) = ((MR_Box) (peephole__V_396_396));
#line 372 "peephole.m"
                      }
#line 372 "peephole.m"
                      {
#line 372 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 372 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_395_395));
#line 372 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_392));
#line 372 "peephole.m"
                      }
#line 372 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 35:
                {
                  MR_Integer peephole__A_229;
                  MR_Word peephole__Rest_230;
                  MR_Word peephole__V_232_232;
                  MR_Float peephole__V_233_233;
                  MR_Word peephole__V_234_234;

#line 229 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 230 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 230 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 230 "peephole.m"
                    {
#line 230 "peephole.m"
                      peephole__V_234_234 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 230 "peephole.m"
                      peephole__Rest_230 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 230 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 230 "peephole.m"
                      {
#line 230 "peephole.m"
                        peephole__succeeded = peephole__integer_token_2_f_1(&peephole__A_229, peephole__V_234_234);
                      }
                      if (peephole__succeeded)
                        {
#line 231 "peephole.m"
                          {
#line 231 "peephole.m"
                            peephole__V_233_233 = op__op_real_2_f_0(peephole__A_229);
                          }
#line 231 "peephole.m"
                          {
#line 231 "peephole.m"
                            peephole__V_232_232 = peephole__real_token_2_f_0(peephole__V_233_233);
                          }
#line 231 "peephole.m"
                          {
#line 231 "peephole.m"
                            *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 231 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_232_232));
#line 231 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_230));
#line 231 "peephole.m"
                          }
#line 231 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 41:
                {
                  MR_Float peephole__A_240;
                  MR_Word peephole__Rest_241;
                  MR_Word peephole__V_243_243;
                  MR_Float peephole__V_244_244;
                  MR_Word peephole__V_245_245;

#line 233 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 234 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 234 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 234 "peephole.m"
                    {
#line 234 "peephole.m"
                      peephole__V_245_245 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 234 "peephole.m"
                      peephole__Rest_241 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 234 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 234 "peephole.m"
                      {
#line 234 "peephole.m"
                        peephole__succeeded = peephole__real_token_2_f_1(&peephole__A_240, peephole__V_245_245);
                      }
                      if (peephole__succeeded)
                        {
#line 235 "peephole.m"
                          {
#line 235 "peephole.m"
                            peephole__V_244_244 = op__op_sin_2_f_0(peephole__A_240);
                          }
#line 235 "peephole.m"
                          {
#line 235 "peephole.m"
                            peephole__V_243_243 = peephole__real_token_2_f_0(peephole__V_244_244);
                          }
#line 235 "peephole.m"
                          {
#line 235 "peephole.m"
                            *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 235 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_243_243));
#line 235 "peephole.m"
                            MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_241));
#line 235 "peephole.m"
                          }
#line 235 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 42:
                {
                  MR_Word peephole__SurfaceFunc_448;
                  MR_Word peephole__Rest_449;
                  MR_Word peephole__V_458_458;
#line 397 "peephole.m"
                  MR_Word peephole__SurfaceProperties_450;

#line 390 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 391 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 391 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 391 "peephole.m"
                    {
#line 391 "peephole.m"
                      peephole__V_458_458 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 391 "peephole.m"
                      peephole__Rest_449 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 391 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 391 "peephole.m"
                      peephole__succeeded = (MR_tag((MR_Word) peephole__V_458_458) == MR_mktag((MR_Integer) 1));
#line 391 "peephole.m"
                      if ((MR_tag((MR_Word) peephole__V_458_458) == MR_mktag((MR_Integer) 1)))
#line 391 "peephole.m"
                        peephole__SurfaceFunc_448 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_458_458, (MR_Integer) 0)));
                      if (peephole__succeeded)
                        {
#line 393 "peephole.m"
                          {
#line 393 "peephole.m"
                            peephole__succeeded = peephole__constant_surface_function_2_p_0(peephole__SurfaceFunc_448, &peephole__SurfaceProperties_450);
                          }
#line 397 "peephole.m"
                          if (peephole__succeeded)
                            {
                              MR_Word peephole__ConstantObj_451;
                              MR_Word peephole__V_453_453;
                              MR_Word peephole__V_454_454;

#line 395 "peephole.m"
                              {
#line 395 "peephole.m"
                                peephole__ConstantObj_451 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "constant_sphere"));
#line 395 "peephole.m"
                                MR_hl_field(MR_mktag(2), peephole__ConstantObj_451, 0) = ((MR_Box) (peephole__SurfaceProperties_450));
#line 395 "peephole.m"
                              }
#line 396 "peephole.m"
                              {
#line 396 "peephole.m"
                                peephole__V_454_454 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "extra"));
#line 396 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__V_454_454, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 3));
#line 396 "peephole.m"
                                MR_hl_field(MR_mktag(3), peephole__V_454_454, 1) = ((MR_Box) (peephole__ConstantObj_451));
#line 396 "peephole.m"
                              }
#line 396 "peephole.m"
                              {
#line 396 "peephole.m"
                                peephole__V_453_453 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "single_token");
#line 396 "peephole.m"
                                MR_hl_field(MR_mktag(0), peephole__V_453_453, 0) = ((MR_Box) (peephole__V_454_454));
#line 396 "peephole.m"
                              }
#line 396 "peephole.m"
                              {
#line 396 "peephole.m"
                                *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 396 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_453_453));
#line 396 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_449));
#line 396 "peephole.m"
                              }
                            }
#line 397 "peephole.m"
                          else
                            {
                              MR_Word peephole__V_455_455 = (MR_Word) &peephole__const_6_0_10_V_455_455;
                              MR_Word peephole__V_456_456 = (MR_Word) &peephole__const_6_0_9_V_456_456;
                              MR_Word peephole__V_457_457 = (MR_Integer) 42;

#line 398 "peephole.m"
                              {
#line 398 "peephole.m"
                                *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 398 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_455_455));
#line 398 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__HeadVar__3_3));
#line 398 "peephole.m"
                              }
                            }
#line 397 "peephole.m"
                          peephole__succeeded = TRUE;
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 44:
                {
                  MR_Float peephole__A_251;
                  MR_Word peephole__Rest_252;
                  MR_Word peephole__V_254_254;
                  MR_Float peephole__V_255_255;
                  MR_Word peephole__V_257_257;
                  MR_Float peephole__V_566_566;

#line 237 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 238 "peephole.m"
                  peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 238 "peephole.m"
                  if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 238 "peephole.m"
                    {
#line 238 "peephole.m"
                      peephole__V_257_257 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 238 "peephole.m"
                      peephole__Rest_252 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 238 "peephole.m"
                    }
                  if (peephole__succeeded)
                    {
#line 238 "peephole.m"
                      {
#line 238 "peephole.m"
                        peephole__succeeded = peephole__real_token_2_f_1(&peephole__A_251, peephole__V_257_257);
                      }
                      if (peephole__succeeded)
                        {
#line 239 "peephole.m"
                          peephole__V_566_566 = (MR_Float) 0.00000000000000;
#line 239 "peephole.m"
                          peephole__succeeded = (peephole__A_251 >= peephole__V_566_566);
                          if (peephole__succeeded)
                            {
#line 240 "peephole.m"
                              {
#line 240 "peephole.m"
                                peephole__V_255_255 = op__op_sqrt_2_f_0(peephole__A_251);
                              }
#line 240 "peephole.m"
                              {
#line 240 "peephole.m"
                                peephole__V_254_254 = peephole__real_token_2_f_0(peephole__V_255_255);
                              }
#line 240 "peephole.m"
                              {
#line 240 "peephole.m"
                                *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 240 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_254_254));
#line 240 "peephole.m"
                                MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_252));
#line 240 "peephole.m"
                              }
#line 240 "peephole.m"
                              peephole__succeeded = TRUE;
                            }
                        }
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 45:
                {
                  MR_Integer peephole__A_263;
                  MR_Integer peephole__B_264;
                  MR_Word peephole__Rest_265;
                  MR_Word peephole__V_267_267;
                  MR_Integer peephole__V_268_268;

#line 242 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 243 "peephole.m"
                  {
#line 243 "peephole.m"
                    peephole__succeeded = peephole__top_two_integer_args_4_p_0(peephole__HeadVar__3_3, &peephole__A_263, &peephole__B_264, &peephole__Rest_265);
                  }
                  if (peephole__succeeded)
                    {
#line 244 "peephole.m"
                      {
#line 244 "peephole.m"
                        peephole__V_268_268 = op__op_subi_3_f_0(peephole__A_263, peephole__B_264);
                      }
#line 244 "peephole.m"
                      {
#line 244 "peephole.m"
                        peephole__V_267_267 = peephole__integer_token_2_f_0(peephole__V_268_268);
                      }
#line 244 "peephole.m"
                      {
#line 244 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 244 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_267_267));
#line 244 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_265));
#line 244 "peephole.m"
                      }
#line 244 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
              case (MR_Integer) 46:
                {
                  MR_Float peephole__A_274;
                  MR_Float peephole__B_275;
                  MR_Word peephole__Rest_276;
                  MR_Word peephole__V_278_278;
                  MR_Float peephole__V_279_279;

#line 246 "peephole.m"
                  *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
#line 247 "peephole.m"
                  {
#line 247 "peephole.m"
                    peephole__succeeded = peephole__top_two_real_args_4_p_0(peephole__HeadVar__3_3, &peephole__A_274, &peephole__B_275, &peephole__Rest_276);
                  }
                  if (peephole__succeeded)
                    {
#line 248 "peephole.m"
                      {
#line 248 "peephole.m"
                        peephole__V_279_279 = op__op_subf_3_f_0(peephole__A_274, peephole__B_275);
                      }
#line 248 "peephole.m"
                      {
#line 248 "peephole.m"
                        peephole__V_278_278 = peephole__real_token_2_f_0(peephole__V_279_279);
                      }
#line 248 "peephole.m"
                      {
#line 248 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 248 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_278_278));
#line 248 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__Rest_276));
#line 248 "peephole.m"
                      }
#line 248 "peephole.m"
                      peephole__succeeded = TRUE;
                    }
                }
#line 142 "peephole.m"
                break;
#line 142 "peephole.m"
            }
          }
#line 142 "peephole.m"
          break;
#line 142 "peephole.m"
        case (MR_Integer) 1:
          {
            MR_String peephole__Id_341 = ((MR_String) (MR_hl_field(MR_mktag(1), peephole__V_562_562, (MR_Integer) 0)));
            MR_Word peephole__MaybeNewToken_344;

#line 315 "peephole.m"
            {
#line 315 "peephole.m"
              peephole__search_4_p_0(peephole__Id_341, &peephole__MaybeNewToken_344, peephole__HeadVar__5_5, peephole__HeadVar__6_6);
            }
#line 319 "peephole.m"
            if ((peephole__MaybeNewToken_344 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 331 "peephole.m"
              {
                MR_Word peephole__V_349_349;
                MR_Word peephole__V_350_350;
                MR_String peephole__V_560_560;
#line 325 "peephole.m"
                MR_Word peephole__Rest_346;

#line 325 "peephole.m"
                peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 325 "peephole.m"
                if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 325 "peephole.m"
                  {
#line 325 "peephole.m"
                    peephole__V_349_349 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 325 "peephole.m"
                    peephole__Rest_346 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 325 "peephole.m"
                  }
                if (peephole__succeeded)
                  {
#line 325 "peephole.m"
                    peephole__succeeded = (MR_tag((MR_Word) peephole__V_349_349) == MR_mktag((MR_Integer) 0));
#line 325 "peephole.m"
                    if ((MR_tag((MR_Word) peephole__V_349_349) == MR_mktag((MR_Integer) 0)))
#line 325 "peephole.m"
                      peephole__V_350_350 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_349_349, (MR_Integer) 0)));
                    if (peephole__succeeded)
                      {
#line 325 "peephole.m"
                        peephole__succeeded = (MR_tag((MR_Word) peephole__V_350_350) == MR_mktag((MR_Integer) 1));
#line 325 "peephole.m"
                        if ((MR_tag((MR_Word) peephole__V_350_350) == MR_mktag((MR_Integer) 1)))
#line 325 "peephole.m"
                          peephole__V_560_560 = ((MR_String) (MR_hl_field(MR_mktag(1), peephole__V_350_350, (MR_Integer) 0)));
                        if (peephole__succeeded)
#line 325 "peephole.m"
                          peephole__succeeded = (strcmp(peephole__Id_341, peephole__V_560_560) == 0);
                      }
                  }
#line 331 "peephole.m"
                if (peephole__succeeded)
                  {
                    MR_Word peephole__V_351_351 = (MR_Word) &peephole__const_6_0_12_V_351_351;
                    MR_Word peephole__V_353_353 = (MR_Word) MR_mkword(MR_mktag(3), &peephole__const_6_0_11_V_353_353);
                    MR_Word peephole__V_354_354 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));

#line 327 "peephole.m"
                    {
#line 327 "peephole.m"
                      *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 327 "peephole.m"
                      MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_351_351));
#line 327 "peephole.m"
                      MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__HeadVar__3_3));
#line 327 "peephole.m"
                    }
                  }
#line 331 "peephole.m"
                else
#line 346 "peephole.m"
                  {
#line 346 "peephole.m"
                    MR_Word peephole__V_357_357;
#line 346 "peephole.m"
                    MR_Word peephole__Rest_368;
                    MR_Word peephole__V_358_358;
                    MR_String peephole__V_561_561;

#line 336 "peephole.m"
                    peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 336 "peephole.m"
                    if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 336 "peephole.m"
                      {
#line 336 "peephole.m"
                        peephole__V_357_357 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 336 "peephole.m"
                        peephole__Rest_368 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 336 "peephole.m"
                      }
                    if (peephole__succeeded)
                      {
#line 336 "peephole.m"
                        peephole__succeeded = (MR_tag((MR_Word) peephole__V_357_357) == MR_mktag((MR_Integer) 0));
#line 336 "peephole.m"
                        if ((MR_tag((MR_Word) peephole__V_357_357) == MR_mktag((MR_Integer) 0)))
#line 336 "peephole.m"
                          peephole__V_358_358 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_357_357, (MR_Integer) 0)));
                        if (peephole__succeeded)
                          {
#line 336 "peephole.m"
                            peephole__succeeded = (MR_tag((MR_Word) peephole__V_358_358) == MR_mktag((MR_Integer) 2));
#line 336 "peephole.m"
                            if ((MR_tag((MR_Word) peephole__V_358_358) == MR_mktag((MR_Integer) 2)))
#line 336 "peephole.m"
                              peephole__V_561_561 = ((MR_String) (MR_hl_field(MR_mktag(2), peephole__V_358_358, (MR_Integer) 0)));
                            if (peephole__succeeded)
#line 336 "peephole.m"
                              peephole__succeeded = (strcmp(peephole__Id_341, peephole__V_561_561) == 0);
                          }
                      }
#line 346 "peephole.m"
                    if (peephole__succeeded)
#line 343 "peephole.m"
                      {
                        MR_Word peephole__V_565_565 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 338 "peephole.m"
                        {
#line 338 "peephole.m"
                          peephole__succeeded = mercury__list__member_2_p_0(peephole__V_565_565, ((MR_Box) (peephole__Id_341)), peephole__HeadVar__1_1);
                        }
#line 343 "peephole.m"
                        if (peephole__succeeded)
                          {
                            MR_Word peephole__V_360_360;
                            MR_Word peephole__V_362_362 = (MR_Word) &peephole__const_6_0_14_V_362_362;
                            MR_Word peephole__V_363_363 = (MR_Word) MR_mkword(MR_mktag(3), &peephole__const_6_0_13_V_363_363);
                            MR_Word peephole__V_364_364 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));

#line 340 "peephole.m"
                            {
#line 340 "peephole.m"
                              peephole__V_360_360 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 340 "peephole.m"
                              MR_hl_field(MR_mktag(1), peephole__V_360_360, 0) = ((MR_Box) (peephole__V_362_362));
#line 340 "peephole.m"
                              MR_hl_field(MR_mktag(1), peephole__V_360_360, 1) = ((MR_Box) (peephole__Rest_368));
#line 340 "peephole.m"
                            }
#line 339 "peephole.m"
                            {
#line 339 "peephole.m"
                              *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 339 "peephole.m"
                              MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__V_357_357));
#line 339 "peephole.m"
                              MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__V_360_360));
#line 339 "peephole.m"
                            }
                          }
#line 343 "peephole.m"
                        else
#line 344 "peephole.m"
                          *peephole__HeadVar__4_4 = peephole__Rest_368;
#line 343 "peephole.m"
                      }
#line 346 "peephole.m"
                    else
#line 347 "peephole.m"
                      {
#line 347 "peephole.m"
                        *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 347 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__HeadVar__2_2));
#line 347 "peephole.m"
                        MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__HeadVar__3_3));
#line 347 "peephole.m"
                      }
#line 346 "peephole.m"
                  }
#line 331 "peephole.m"
              }
#line 319 "peephole.m"
            else
#line 319 "peephole.m"
              {
                MR_Word peephole__NewToken_345 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__MaybeNewToken_344, (MR_Integer) 0)));

#line 318 "peephole.m"
                {
#line 318 "peephole.m"
                  *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 318 "peephole.m"
                  MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__NewToken_345));
#line 318 "peephole.m"
                  MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__HeadVar__3_3));
#line 318 "peephole.m"
                }
#line 319 "peephole.m"
              }
            peephole__succeeded = TRUE;
          }
#line 142 "peephole.m"
          break;
#line 142 "peephole.m"
        case (MR_Integer) 2:
          {
            MR_String peephole__Id_317 = ((MR_String) (MR_hl_field(MR_mktag(2), peephole__V_562_562, (MR_Integer) 0)));
#line 289 "peephole.m"
            MR_Word peephole__Rest_320;
            MR_Word peephole__V_330_330;
            MR_Word peephole__V_331_331;
            MR_String peephole__V_559_559;

#line 287 "peephole.m"
            peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 287 "peephole.m"
            if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 287 "peephole.m"
              {
#line 287 "peephole.m"
                peephole__V_330_330 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 287 "peephole.m"
                peephole__Rest_320 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 287 "peephole.m"
              }
            if (peephole__succeeded)
              {
#line 287 "peephole.m"
                peephole__succeeded = (MR_tag((MR_Word) peephole__V_330_330) == MR_mktag((MR_Integer) 0));
#line 287 "peephole.m"
                if ((MR_tag((MR_Word) peephole__V_330_330) == MR_mktag((MR_Integer) 0)))
#line 287 "peephole.m"
                  peephole__V_331_331 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_330_330, (MR_Integer) 0)));
                if (peephole__succeeded)
                  {
#line 287 "peephole.m"
                    peephole__succeeded = (MR_tag((MR_Word) peephole__V_331_331) == MR_mktag((MR_Integer) 1));
#line 287 "peephole.m"
                    if ((MR_tag((MR_Word) peephole__V_331_331) == MR_mktag((MR_Integer) 1)))
#line 287 "peephole.m"
                      peephole__V_559_559 = ((MR_String) (MR_hl_field(MR_mktag(1), peephole__V_331_331, (MR_Integer) 0)));
                    if (peephole__succeeded)
#line 287 "peephole.m"
                      peephole__succeeded = (strcmp(peephole__Id_317, peephole__V_559_559) == 0);
                  }
              }
#line 289 "peephole.m"
            if (peephole__succeeded)
              {
#line 288 "peephole.m"
                *peephole__HeadVar__4_4 = peephole__Rest_320;
#line 289 "peephole.m"
                *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
                peephole__succeeded = TRUE;
              }
#line 289 "peephole.m"
            else
#line 302 "peephole.m"
              {
                MR_Word peephole__V_564_564 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 290 "peephole.m"
                {
#line 290 "peephole.m"
                  peephole__succeeded = mercury__list__member_2_p_0(peephole__V_564_564, ((MR_Box) (peephole__Id_317)), peephole__HeadVar__1_1);
                }
#line 302 "peephole.m"
                if (peephole__succeeded)
                  {
                    MR_Word peephole__Bound_322;
                    MR_Word peephole__Rest_338;
#line 291 "peephole.m"
                    MR_Word peephole__V_321_321;

#line 291 "peephole.m"
                    peephole__succeeded = (MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 291 "peephole.m"
                    if ((MR_tag((MR_Word) peephole__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 291 "peephole.m"
                      {
#line 291 "peephole.m"
                        peephole__V_321_321 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 0)));
#line 291 "peephole.m"
                        peephole__Rest_338 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__3_3, (MR_Integer) 1)));
#line 291 "peephole.m"
                      }
                    if (peephole__succeeded)
                      {
#line 292 "peephole.m"
                        {
#line 292 "peephole.m"
                          peephole__succeeded = peephole__chase_dups_2_p_0(peephole__HeadVar__3_3, &peephole__Bound_322);
                        }
                        if (peephole__succeeded)
                          {
#line 293 "peephole.m"
                            {
#line 293 "peephole.m"
                              peephole__succeeded = peephole__value_token_group_1_p_0(peephole__Bound_322);
                            }
#line 296 "peephole.m"
                            if (peephole__succeeded)
                              {
#line 294 "peephole.m"
                                *peephole__HeadVar__4_4 = peephole__Rest_338;
#line 295 "peephole.m"
                                {
#line 295 "peephole.m"
                                  peephole__insert_4_p_0(peephole__Id_317, peephole__Bound_322, peephole__HeadVar__5_5, peephole__HeadVar__6_6);
                                }
                              }
#line 296 "peephole.m"
                            else
                              {
#line 299 "peephole.m"
                                {
#line 299 "peephole.m"
                                  *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 299 "peephole.m"
                                  MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__HeadVar__2_2));
#line 299 "peephole.m"
                                  MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__HeadVar__3_3));
#line 299 "peephole.m"
                                }
#line 300 "peephole.m"
                                {
#line 300 "peephole.m"
                                  peephole__delete_3_p_0(peephole__Id_317, peephole__HeadVar__5_5, peephole__HeadVar__6_6);
                                }
                              }
#line 296 "peephole.m"
                            peephole__succeeded = TRUE;
                          }
                      }
                  }
#line 302 "peephole.m"
                else
                  {
                    MR_Word peephole__NewToken_323 = (MR_Word) &peephole__const_6_0_17_NewToken_323;
                    MR_Word peephole__V_334_334 = (MR_Word) MR_mkword(MR_mktag(3), &peephole__const_6_0_16_V_334_334);
                    MR_Word peephole__V_335_335 = (MR_Word) MR_mkword(MR_mktag(1), &peephole__const_6_0_15_V_335_335);
                    MR_Integer peephole__V_336_336 = (MR_Integer) 1;
#line 308 "peephole.m"
                    MR_Word peephole__Result0_324;
#line 308 "peephole.m"
                    MR_Word peephole__DCG_3_328;

#line 306 "peephole.m"
                    {
#line 306 "peephole.m"
                      peephole__succeeded = peephole__match_6_p_0(peephole__HeadVar__1_1, peephole__NewToken_323, peephole__HeadVar__3_3, &peephole__Result0_324, peephole__HeadVar__5_5, &peephole__DCG_3_328);
                    }
#line 308 "peephole.m"
                    if (peephole__succeeded)
                      {
#line 307 "peephole.m"
                        *peephole__HeadVar__4_4 = peephole__Result0_324;
#line 308 "peephole.m"
                        *peephole__HeadVar__6_6 = peephole__DCG_3_328;
                      }
#line 308 "peephole.m"
                    else
                      {
#line 309 "peephole.m"
                        {
#line 309 "peephole.m"
                          *peephole__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 309 "peephole.m"
                          MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 0) = ((MR_Box) (peephole__NewToken_323));
#line 309 "peephole.m"
                          MR_hl_field(MR_mktag(1), *peephole__HeadVar__4_4, 1) = ((MR_Box) (peephole__HeadVar__3_3));
#line 309 "peephole.m"
                        }
#line 308 "peephole.m"
                        *peephole__HeadVar__6_6 = peephole__HeadVar__5_5;
                      }
                    peephole__succeeded = TRUE;
                  }
#line 302 "peephole.m"
              }
          }
#line 142 "peephole.m"
          break;
#line 142 "peephole.m"
      }
    return peephole__succeeded;
  }
#line 132 "peephole.m"
}

#line 97 "peephole.m"
static MR_Word MR_CALL peephole__used_ids_2_f_0(
#line 97 "peephole.m"
  MR_Word peephole__HeadVar__1_1)
#line 97 "peephole.m"
{
#line 99 "peephole.m"
  {
#line 99 "peephole.m"
    /* tailcall optimized into a loop */
#line 99 "peephole.m"
  loop_top:;
#line 99 "peephole.m"
    {
#line 99 "peephole.m"
      bool peephole__succeeded;
#line 99 "peephole.m"
      MR_Word peephole__HeadVar__2_2;

#line 99 "peephole.m"
      if ((peephole__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 99 "peephole.m"
        peephole__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 99 "peephole.m"
      else
#line 99 "peephole.m"
        {
          MR_Word peephole__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 1)));
          MR_Word peephole__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__1_1, (MR_Integer) 0)));

#line 99 "peephole.m"
#line 99 "peephole.m"
          switch (MR_tag((MR_Word) peephole__V_21_21)) {
#line 99 "peephole.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 99 "peephole.m"
            case (MR_Integer) 0:
              {
                MR_Word peephole__Single_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), peephole__V_21_21, (MR_Integer) 0)));
#line 100 "peephole.m"
                MR_String peephole__Id_5;

#line 101 "peephole.m"
                peephole__succeeded = (MR_tag((MR_Word) peephole__Single_3) == MR_mktag((MR_Integer) 1));
#line 101 "peephole.m"
                if ((MR_tag((MR_Word) peephole__Single_3) == MR_mktag((MR_Integer) 1)))
#line 101 "peephole.m"
                  peephole__Id_5 = ((MR_String) (MR_hl_field(MR_mktag(1), peephole__Single_3, (MR_Integer) 0)));
#line 100 "peephole.m"
                if (peephole__succeeded)
                  {
                    MR_Word peephole__V_7_7;

#line 102 "peephole.m"
                    {
#line 102 "peephole.m"
                      peephole__V_7_7 = peephole__used_ids_2_f_0(peephole__V_20_20);
                    }
#line 100 "peephole.m"
                    {
#line 100 "peephole.m"
                      peephole__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 100 "peephole.m"
                      MR_hl_field(MR_mktag(1), peephole__HeadVar__2_2, 0) = ((MR_Box) (peephole__Id_5));
#line 100 "peephole.m"
                      MR_hl_field(MR_mktag(1), peephole__HeadVar__2_2, 1) = ((MR_Box) (peephole__V_7_7));
#line 100 "peephole.m"
                    }
                  }
#line 100 "peephole.m"
                else
#line 100 "peephole.m"
                  {
#line 100 "peephole.m"
                    /* direct tailcall eliminated */
#line 100 "peephole.m"
                    {
#line 100 "peephole.m"
                      MR_Word peephole__HeadVar__1__tmp_copy_1 = peephole__V_20_20;

#line 100 "peephole.m"
                      peephole__HeadVar__1_1 = peephole__HeadVar__1__tmp_copy_1;
#line 100 "peephole.m"
                    }
#line 100 "peephole.m"
                    goto loop_top;
#line 100 "peephole.m"
                  }
              }
#line 99 "peephole.m"
              break;
#line 99 "peephole.m"
            case (MR_Integer) 1:
              {
                MR_Word peephole__TokenList_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_21_21, (MR_Integer) 0)));
                MR_Word peephole__V_11_11;
                MR_Word peephole__V_12_12;
                MR_Word peephole__TypeInfo_18_18;

#line 107 "peephole.m"
                {
#line 107 "peephole.m"
                  peephole__V_11_11 = peephole__used_ids_2_f_0(peephole__TokenList_8);
                }
#line 107 "peephole.m"
                {
#line 107 "peephole.m"
                  peephole__V_12_12 = peephole__used_ids_2_f_0(peephole__V_20_20);
                }
                peephole__TypeInfo_18_18 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                  mercury__list__append_3_p_1(peephole__TypeInfo_18_18, peephole__V_11_11, peephole__V_12_12, &peephole__HeadVar__2_2);
                }
              }
#line 99 "peephole.m"
              break;
#line 99 "peephole.m"
            case (MR_Integer) 2:
              {
                MR_Word peephole__TokenList_13 = ((MR_Word) (MR_hl_field(MR_mktag(2), peephole__V_21_21, (MR_Integer) 0)));
                MR_Word peephole__V_16_16;
                MR_Word peephole__V_17_17;
                MR_Word peephole__TypeInfo_19_19;

#line 109 "peephole.m"
                {
#line 109 "peephole.m"
                  peephole__V_16_16 = peephole__used_ids_2_f_0(peephole__TokenList_13);
                }
#line 109 "peephole.m"
                {
#line 109 "peephole.m"
                  peephole__V_17_17 = peephole__used_ids_2_f_0(peephole__V_20_20);
                }
                peephole__TypeInfo_19_19 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                  mercury__list__append_3_p_1(peephole__TypeInfo_19_19, peephole__V_16_16, peephole__V_17_17, &peephole__HeadVar__2_2);
                }
              }
#line 99 "peephole.m"
              break;
#line 99 "peephole.m"
          }
#line 99 "peephole.m"
        }
#line 99 "peephole.m"
      return peephole__HeadVar__2_2;
#line 99 "peephole.m"
    }
#line 99 "peephole.m"
  }
#line 97 "peephole.m"
}

#line 83 "peephole.m"
static void MR_CALL peephole__search_4_p_0(
#line 83 "peephole.m"
  MR_String peephole__HeadVar__1_1,
#line 83 "peephole.m"
  MR_Word * peephole__HeadVar__2_2,
#line 83 "peephole.m"
  MR_Word peephole__HeadVar__3_3,
#line 83 "peephole.m"
  MR_Word * peephole__HeadVar__4_4)
#line 83 "peephole.m"
{
  {
    bool peephole__succeeded;
#line 89 "peephole.m"
    MR_Word peephole__Token_8;
    MR_Word peephole__V_9_9;
    MR_Word peephole__TypeInfo_10_10;
    MR_Word peephole__TypeInfo_11_11;
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
    MR_Box peephole__conv1_Token_8;

#line 86 "peephole.m"
    *peephole__HeadVar__4_4 = peephole__HeadVar__3_3;
#line 87 "peephole.m"
    peephole__V_9_9 = (MR_Word) peephole__HeadVar__3_3;
    peephole__TypeInfo_10_10 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
    peephole__TypeInfo_11_11 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
    {
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
      peephole__succeeded = mercury__tree234__search_3_p_0(peephole__TypeInfo_10_10, peephole__TypeInfo_11_11, peephole__V_9_9, ((MR_Box) (peephole__HeadVar__1_1)), &peephole__conv1_Token_8);
    }
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
    if (peephole__succeeded)
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
      {
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
        peephole__Token_8 = ((MR_Word) peephole__conv1_Token_8);
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
        peephole__succeeded = TRUE;
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
      }
#line 89 "peephole.m"
    if (peephole__succeeded)
#line 88 "peephole.m"
      {
#line 88 "peephole.m"
        *peephole__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "yes"));
#line 88 "peephole.m"
        MR_hl_field(MR_mktag(1), *peephole__HeadVar__2_2, 0) = ((MR_Box) (peephole__Token_8));
#line 88 "peephole.m"
      }
#line 89 "peephole.m"
    else
#line 90 "peephole.m"
      *peephole__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
  }
#line 83 "peephole.m"
}

#line 78 "peephole.m"
static void MR_CALL peephole__delete_3_p_0(
#line 78 "peephole.m"
  MR_String peephole__HeadVar__1_1,
#line 78 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 78 "peephole.m"
  MR_Word * peephole__HeadVar__3_3)
#line 78 "peephole.m"
{
  {
    bool peephole__succeeded;
    MR_Word peephole__V_7_7;
    MR_Word peephole__V_8_8 = (MR_Word) peephole__HeadVar__2_2;
    MR_Word peephole__TypeInfo_10_10 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
    MR_Word peephole__TypeInfo_11_11 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 95 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
    {
#line 95 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
      mercury__tree234__delete_3_p_1(peephole__TypeInfo_10_10, peephole__TypeInfo_11_11, peephole__V_8_8, ((MR_Box) (peephole__HeadVar__1_1)), &peephole__V_7_7);
    }
#line 81 "peephole.m"
    *peephole__HeadVar__3_3 = (MR_Word) peephole__V_7_7;
  }
#line 78 "peephole.m"
}

#line 71 "peephole.m"
static void MR_CALL peephole__insert_4_p_0(
#line 71 "peephole.m"
  MR_String peephole__HeadVar__1_1,
#line 71 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 71 "peephole.m"
  MR_Word peephole__HeadVar__3_3,
#line 71 "peephole.m"
  MR_Word * peephole__HeadVar__4_4)
#line 71 "peephole.m"
{
  {
    bool peephole__succeeded;
    MR_Word peephole__V_9_9;
    MR_Word peephole__V_10_10 = (MR_Word) peephole__HeadVar__3_3;
    MR_Word peephole__TypeInfo_12_12 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
    MR_Word peephole__TypeInfo_13_13 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
    {
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
      mercury__tree234__set_4_p_1(peephole__TypeInfo_12_12, peephole__TypeInfo_13_13, peephole__V_10_10, ((MR_Box) (peephole__HeadVar__1_1)), ((MR_Box) (peephole__HeadVar__2_2)), &peephole__V_9_9);
    }
#line 75 "peephole.m"
    *peephole__HeadVar__4_4 = (MR_Word) peephole__V_9_9;
  }
#line 71 "peephole.m"
}

#line 34 "peephole.m"
static void MR_CALL peephole__peephole_2_5_p_0(
#line 34 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 34 "peephole.m"
  MR_Word peephole__HeadVar__2_2,
#line 34 "peephole.m"
  MR_Word * peephole__HeadVar__3_3,
#line 34 "peephole.m"
  MR_Word peephole__HeadVar__4_4,
#line 34 "peephole.m"
  MR_Word * peephole__HeadVar__5_5)
#line 34 "peephole.m"
{
#line 37 "peephole.m"
  {
#line 37 "peephole.m"
    bool peephole__succeeded;

#line 37 "peephole.m"
    if ((peephole__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
      {
#line 37 "peephole.m"
        *peephole__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 37 "peephole.m"
        *peephole__HeadVar__5_5 = peephole__HeadVar__4_4;
      }
#line 37 "peephole.m"
    else
#line 37 "peephole.m"
      {
        MR_Word peephole__V_63_63 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word peephole__V_64_64 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__HeadVar__2_2, (MR_Integer) 0)));

#line 37 "peephole.m"
#line 37 "peephole.m"
        switch (MR_tag((MR_Word) peephole__V_64_64)) {
#line 37 "peephole.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 37 "peephole.m"
          case (MR_Integer) 0:
            {
              MR_Word peephole__UsedIds_14;
              MR_Word peephole__NewTokens0_15;
              MR_Word peephole__DCG_1_18;
              MR_Word peephole__V_21_21;
              MR_Word peephole__V_22_22;
              MR_Word peephole__V_23_23 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
              MR_Word peephole__TypeInfo_56_56;
#line 44 "peephole.m"
              MR_Word peephole__Result_16;
#line 44 "peephole.m"
              MR_Word peephole__DCG_2_19;

#line 40 "peephole.m"
              {
#line 40 "peephole.m"
                peephole__V_22_22 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 40 "peephole.m"
                MR_hl_field(MR_mktag(1), peephole__V_22_22, 0) = ((MR_Box) (peephole__V_64_64));
#line 40 "peephole.m"
                MR_hl_field(MR_mktag(1), peephole__V_22_22, 1) = ((MR_Box) (peephole__V_23_23));
#line 40 "peephole.m"
              }
#line 40 "peephole.m"
              {
#line 40 "peephole.m"
                peephole__V_21_21 = peephole__used_ids_2_f_0(peephole__V_22_22);
              }
              peephole__TypeInfo_56_56 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                mercury__list__append_3_p_1(peephole__TypeInfo_56_56, peephole__V_21_21, peephole__HeadVar__1_1, &peephole__UsedIds_14);
              }
#line 41 "peephole.m"
              {
#line 41 "peephole.m"
                peephole__peephole_2_5_p_0(peephole__UsedIds_14, peephole__V_63_63, &peephole__NewTokens0_15, peephole__HeadVar__4_4, &peephole__DCG_1_18);
              }
#line 42 "peephole.m"
              {
#line 42 "peephole.m"
                peephole__succeeded = peephole__match_6_p_0(peephole__HeadVar__1_1, peephole__V_64_64, peephole__NewTokens0_15, &peephole__Result_16, peephole__DCG_1_18, &peephole__DCG_2_19);
              }
#line 44 "peephole.m"
              if (peephole__succeeded)
                {
#line 43 "peephole.m"
                  *peephole__HeadVar__3_3 = peephole__Result_16;
#line 44 "peephole.m"
                  *peephole__HeadVar__5_5 = peephole__DCG_2_19;
                }
#line 44 "peephole.m"
              else
                {
#line 45 "peephole.m"
                  {
#line 45 "peephole.m"
                    *peephole__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 45 "peephole.m"
                    MR_hl_field(MR_mktag(1), *peephole__HeadVar__3_3, 0) = ((MR_Box) (peephole__V_64_64));
#line 45 "peephole.m"
                    MR_hl_field(MR_mktag(1), *peephole__HeadVar__3_3, 1) = ((MR_Box) (peephole__NewTokens0_15));
#line 45 "peephole.m"
                  }
#line 44 "peephole.m"
                  *peephole__HeadVar__5_5 = peephole__DCG_1_18;
                }
            }
#line 37 "peephole.m"
            break;
#line 37 "peephole.m"
          case (MR_Integer) 1:
            {
              MR_Word peephole__TokenList_28 = ((MR_Word) (MR_hl_field(MR_mktag(1), peephole__V_64_64, (MR_Integer) 0)));
              MR_Word peephole__UsedIds_29;
              MR_Word peephole__NewTokens0_30;
              MR_Word peephole__OptTokenList_32;
              MR_Word peephole__V_36_36;
              MR_Word peephole__V_37_37;
              MR_Word peephole__V_38_38;
              MR_Word peephole__V_39_39;
              MR_Word peephole__TypeInfo_57_57;
              MR_Word peephole__TypeInfo_58_58;
              MR_Word peephole__TypeInfo_59_59;
              MR_Word peephole__V_5_85;
              MR_Word peephole__V_5_90;
#line 55 "peephole.m"
              MR_Word peephole__V_33_33;

#line 50 "peephole.m"
              {
#line 50 "peephole.m"
                peephole__V_39_39 = peephole__used_ids_2_f_0(peephole__TokenList_28);
              }
              peephole__TypeInfo_57_57 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                mercury__list__append_3_p_1(peephole__TypeInfo_57_57, peephole__V_39_39, peephole__HeadVar__1_1, &peephole__UsedIds_29);
              }
#line 51 "peephole.m"
              {
#line 51 "peephole.m"
                peephole__peephole_2_5_p_0(peephole__UsedIds_29, peephole__V_63_63, &peephole__NewTokens0_30, peephole__HeadVar__4_4, peephole__HeadVar__5_5);
              }
              peephole__TypeInfo_58_58 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              peephole__V_5_85 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                mercury__list__reverse_2_3_p_0(peephole__TypeInfo_58_58, peephole__TokenList_28, peephole__V_5_85, &peephole__V_38_38);
              }
#line 55 "peephole.m"
              {
#line 55 "peephole.m"
                peephole__peephole_2_5_p_0(peephole__HeadVar__1_1, peephole__V_38_38, &peephole__OptTokenList_32, *peephole__HeadVar__5_5, &peephole__V_33_33);
              }
              peephole__TypeInfo_59_59 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              peephole__V_5_90 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                mercury__list__reverse_2_3_p_0(peephole__TypeInfo_59_59, peephole__OptTokenList_32, peephole__V_5_90, &peephole__V_37_37);
              }
#line 57 "peephole.m"
              {
#line 57 "peephole.m"
                peephole__V_36_36 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "function"));
#line 57 "peephole.m"
                MR_hl_field(MR_mktag(1), peephole__V_36_36, 0) = ((MR_Box) (peephole__V_37_37));
#line 57 "peephole.m"
              }
#line 57 "peephole.m"
              {
#line 57 "peephole.m"
                *peephole__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 57 "peephole.m"
                MR_hl_field(MR_mktag(1), *peephole__HeadVar__3_3, 0) = ((MR_Box) (peephole__V_36_36));
#line 57 "peephole.m"
                MR_hl_field(MR_mktag(1), *peephole__HeadVar__3_3, 1) = ((MR_Box) (peephole__NewTokens0_30));
#line 57 "peephole.m"
              }
            }
#line 37 "peephole.m"
            break;
#line 37 "peephole.m"
          case (MR_Integer) 2:
            {
              MR_Word peephole__TokenList_44 = ((MR_Word) (MR_hl_field(MR_mktag(2), peephole__V_64_64, (MR_Integer) 0)));
              MR_Word peephole__UsedIds_45;
              MR_Word peephole__NewTokens0_46;
              MR_Word peephole__OptTokenList_48;
              MR_Word peephole__V_52_52;
              MR_Word peephole__V_53_53;
              MR_Word peephole__V_54_54;
              MR_Word peephole__V_55_55;
              MR_Word peephole__TypeInfo_60_60;
              MR_Word peephole__TypeInfo_61_61;
              MR_Word peephole__TypeInfo_62_62;
              MR_Word peephole__V_5_72;
              MR_Word peephole__V_5_77;
#line 66 "peephole.m"
              MR_Word peephole__V_49_49;

#line 61 "peephole.m"
              {
#line 61 "peephole.m"
                peephole__V_55_55 = peephole__used_ids_2_f_0(peephole__TokenList_44);
              }
              peephole__TypeInfo_60_60 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                mercury__list__append_3_p_1(peephole__TypeInfo_60_60, peephole__V_55_55, peephole__HeadVar__1_1, &peephole__UsedIds_45);
              }
#line 62 "peephole.m"
              {
#line 62 "peephole.m"
                peephole__peephole_2_5_p_0(peephole__UsedIds_45, peephole__V_63_63, &peephole__NewTokens0_46, peephole__HeadVar__4_4, peephole__HeadVar__5_5);
              }
              peephole__TypeInfo_61_61 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              peephole__V_5_72 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                mercury__list__reverse_2_3_p_0(peephole__TypeInfo_61_61, peephole__TokenList_44, peephole__V_5_72, &peephole__V_54_54);
              }
#line 66 "peephole.m"
              {
#line 66 "peephole.m"
                peephole__peephole_2_5_p_0(peephole__HeadVar__1_1, peephole__V_54_54, &peephole__OptTokenList_48, *peephole__HeadVar__5_5, &peephole__V_49_49);
              }
              peephole__TypeInfo_62_62 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              peephole__V_5_77 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                mercury__list__reverse_2_3_p_0(peephole__TypeInfo_62_62, peephole__OptTokenList_48, peephole__V_5_77, &peephole__V_53_53);
              }
#line 68 "peephole.m"
              {
#line 68 "peephole.m"
                peephole__V_52_52 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "array"));
#line 68 "peephole.m"
                MR_hl_field(MR_mktag(2), peephole__V_52_52, 0) = ((MR_Box) (peephole__V_53_53));
#line 68 "peephole.m"
              }
#line 68 "peephole.m"
              {
#line 68 "peephole.m"
                *peephole__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 68 "peephole.m"
                MR_hl_field(MR_mktag(1), *peephole__HeadVar__3_3, 0) = ((MR_Box) (peephole__V_52_52));
#line 68 "peephole.m"
                MR_hl_field(MR_mktag(1), *peephole__HeadVar__3_3, 1) = ((MR_Box) (peephole__NewTokens0_46));
#line 68 "peephole.m"
              }
            }
#line 37 "peephole.m"
            break;
#line 37 "peephole.m"
        }
#line 37 "peephole.m"
      }
#line 37 "peephole.m"
  }
#line 34 "peephole.m"
}

#line 8 "peephole.m"
void MR_CALL peephole__peephole_2_p_0(
#line 8 "peephole.m"
  MR_Word peephole__HeadVar__1_1,
#line 8 "peephole.m"
  MR_Word * peephole__HeadVar__2_2)
#line 8 "peephole.m"
{
  {
    bool peephole__succeeded;
    MR_Word peephole__Tokens1_5;
    MR_Word peephole__V_7_7 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
    MR_Word peephole__V_8_8;
    MR_Word peephole__V_9_9;
    MR_Word peephole__V_10_10;
    MR_Word peephole__TypeInfo_11_11;
    MR_Word peephole__TypeInfo_12_12 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
    MR_Word peephole__TypeInfo_13_13;
    MR_Word peephole__TypeInfo_14_14;
    MR_Word peephole__V_5_19 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
    MR_Word peephole__V_5_26;
#line 22 "peephole.m"
    MR_Word peephole__V_6_6;

#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      mercury__list__reverse_2_3_p_0(peephole__TypeInfo_12_12, peephole__HeadVar__1_1, peephole__V_5_19, &peephole__V_8_8);
    }
    peephole__TypeInfo_13_13 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
    peephole__TypeInfo_14_14 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
    {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
      mercury__tree234__init_1_p_0(peephole__TypeInfo_13_13, peephole__TypeInfo_14_14, &peephole__V_10_10);
    }
#line 22 "peephole.m"
    peephole__V_9_9 = (MR_Word) peephole__V_10_10;
#line 22 "peephole.m"
    {
#line 22 "peephole.m"
      peephole__peephole_2_5_p_0(peephole__V_7_7, peephole__V_8_8, &peephole__Tokens1_5, peephole__V_9_9, &peephole__V_6_6);
    }
    peephole__TypeInfo_11_11 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    peephole__V_5_26 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      mercury__list__reverse_2_3_p_0(peephole__TypeInfo_11_11, peephole__Tokens1_5, peephole__V_5_26, peephole__HeadVar__2_2);
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      return;
    }
  }
#line 8 "peephole.m"
}

void mercury__peephole__init(void)
{
}

void mercury__peephole__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&peephole__peephole__type_ctor_info_peephole_0);
}

void mercury__peephole__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module peephole. */
