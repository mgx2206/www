/*
** Automatically generated from `gml.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module gml. */
/* :- implementation. */

#include "gml.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.benchmarking.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "eval.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "globals.h"
#include "gml.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "op.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "peephole.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "renderer.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "space_partition.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "trans.h"
#include "transform_object.h"
#include "tree.h"
#include "mercury.tree234.h"
#include "mercury.varset.h"
#include "vector.h"



static const MR_FO_PseudoTypeInfo_Struct1 gml__list__type_info_list_1__type0_18_gml__token_group_0;
static const MR_DuFunctorDescPtr gml__gml__du_name_ordered_token_group_0[3];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_group_0_0;
static const MR_PseudoTypeInfo gml__gml__field_types_token_group_0_0[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_group_0_1;
static const MR_PseudoTypeInfo gml__gml__field_types_token_group_0_1[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_group_0_2;
static const MR_PseudoTypeInfo gml__gml__field_types_token_group_0_2[1];
static const MR_DuPtagLayout gml__gml__du_ptag_ordered_token_group_0[3];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_group_0_0[1];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_group_0_1[1];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_group_0_2[1];
static const MR_DuFunctorDescPtr gml__gml__du_name_ordered_token_0[7];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_0;
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_0[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_1;
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_1[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_2;
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_2[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_3;
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_3[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_4;
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_4[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_5;
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_5[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_6;
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_6[1];
static const MR_DuPtagLayout gml__gml__du_ptag_ordered_token_0[4];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_0_0[1];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_0_1[1];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_0_2[1];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_0_3[4];
static const MR_EnumFunctorDescPtr gml__gml__enum_name_ordered_stop_at_0[3];
static const MR_EnumFunctorDescPtr gml__gml__enum_value_ordered_stop_at_0[3];
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_stop_at_0_0;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_stop_at_0_1;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_stop_at_0_2;
static const MR_NotagFunctorDesc gml__gml__notag_functor_desc_parse_error_0;
static const MR_EnumFunctorDescPtr gml__gml__enum_name_ordered_operator_0[50];
static const MR_EnumFunctorDescPtr gml__gml__enum_value_ordered_operator_0[50];
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_0;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_1;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_2;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_3;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_4;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_5;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_6;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_7;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_8;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_9;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_10;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_11;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_12;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_13;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_14;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_15;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_16;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_17;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_18;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_19;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_20;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_21;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_22;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_23;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_24;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_25;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_26;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_27;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_28;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_29;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_30;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_31;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_32;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_33;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_34;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_35;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_36;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_37;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_38;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_39;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_40;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_41;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_42;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_43;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_44;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_45;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_46;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_47;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_48;
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_49;
static const MR_DuFunctorDescPtr gml__gml__du_name_ordered_number_0[2];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_number_0_0;
static const MR_PseudoTypeInfo gml__gml__field_types_number_0_0[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_number_0_1;
static const MR_PseudoTypeInfo gml__gml__field_types_number_0_1[1];
static const MR_DuPtagLayout gml__gml__du_ptag_ordered_number_0[2];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_number_0_0[1];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_number_0_1[1];
static const MR_DuFunctorDescPtr gml__gml__du_name_ordered_lexer_error_0[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_lexer_error_0_0;
static const MR_PseudoTypeInfo gml__gml__field_types_lexer_error_0_0[2];
static const MR_DuPtagLayout gml__gml__du_ptag_ordered_lexer_error_0[1];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_lexer_error_0_0[1];
static const MR_DuFunctorDescPtr gml__gml__du_name_ordered_extra_operator_0[10];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_0;
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_0[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_1;
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_2;
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_2[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_3;
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_3[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_4;
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_4[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_5;
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_5[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_6;
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_6[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_7;
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_7[1];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_8;
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_8[2];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_9;
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_9[1];
static const MR_FO_PseudoTypeInfo_Struct1 gml__list__type_info_list_1__type0_13_eval__value_0;
static const MR_FO_PseudoTypeInfo_Struct2 gml__tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0;
static const MR_HO_PseudoTypeInfo_Struct6 gml____ho_type_info_pred_6__type_18_tree234__tree234_2__type0_10___string_0__type0_13_eval__value_0__type_12_list__list_1__type0_13_eval__value_0__type_18_tree234__tree234_2__type0_10___string_0__type0_13_eval__value_0__type_12_list__list_1__type0_13_eval__value_0__type0_11_io__state_0__type0_11_io__state_0;
static const MR_DuPtagLayout gml__gml__du_ptag_ordered_extra_operator_0[4];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_extra_operator_0_0[1];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_extra_operator_0_1[1];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_extra_operator_0_2[1];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_extra_operator_0_3[7];
static const MR_DuFunctorDescPtr gml__gml__du_name_ordered_basic_token_0[5];
static const MR_DuFunctorDesc gml__gml__du_functor_desc_basic_token_0_0;
static const MR_DuFunctorDesc gml__gml__du_functor_desc_basic_token_0_1;
static const MR_DuFunctorDesc gml__gml__du_functor_desc_basic_token_0_2;
static const MR_DuFunctorDesc gml__gml__du_functor_desc_basic_token_0_3;
static const MR_DuFunctorDesc gml__gml__du_functor_desc_basic_token_0_4;
static const MR_PseudoTypeInfo gml__gml__field_types_basic_token_0_4[1];
static const MR_DuPtagLayout gml__gml__du_ptag_ordered_basic_token_0[2];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_basic_token_0_0[4];
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_basic_token_0_1[1];
#line 24 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.int"
static void MR_CALL gml__builtin_compare_pred__ua0_3_p_in__private_builtin_0(
#line 24 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.int"
  MR_Word * gml__HeadVar__1_1);
#line 22 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.int"
static bool MR_CALL gml__builtin_unify_pred__ua0_2_p_in__private_builtin_0(void);
#line 668 "gml.m"
static void MR_CALL gml__parse_2_5_p_0(
#line 668 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 668 "gml.m"
  MR_Word gml__HeadVar__2_2,
#line 668 "gml.m"
  MR_Word * gml__HeadVar__3_3,
#line 668 "gml.m"
  MR_Word gml__HeadVar__4_4,
#line 668 "gml.m"
  MR_Word * gml__HeadVar__5_5);
#line 594 "gml.m"
static void MR_CALL gml__lexer_read_char_3_p_0(
#line 594 "gml.m"
  MR_Word * gml__HeadVar__1_1);
#line 568 "gml.m"
static /* final */ const MR_Box gml__const_19_0_1_V_26_26[2];
#line 553 "gml.m"
static void MR_CALL gml__rev_char_list_to_int_5_p_0(
#line 553 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 553 "gml.m"
  MR_Integer gml__HeadVar__2_2,
#line 553 "gml.m"
  MR_Word * gml__HeadVar__3_3);
#line 588 "gml.m"
static /* final */ const MR_Box gml__const_18_0_1_V_34_34[2];
#line 588 "gml.m"
static /* final */ const MR_Box gml__const_18_0_2_V_75_75[2];
#line 534 "gml.m"
static void MR_CALL gml__get_float_exponent_3_4_p_0(
#line 534 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 534 "gml.m"
  MR_Word * gml__HeadVar__2_2);
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_17_0_1_V_46_46[2];
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_17_0_2_V_42_42[2];
#line 515 "gml.m"
static void MR_CALL gml__get_float_exponent_2_4_p_0(
#line 515 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 515 "gml.m"
  MR_Word * gml__HeadVar__2_2);
#line 588 "gml.m"
static /* final */ const MR_Box gml__const_16_0_1_V_36_36[2];
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_16_0_2_V_62_62[2];
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_16_0_3_V_58_58[2];
#line 498 "gml.m"
static void MR_CALL gml__get_float_exponent_4_p_0(
#line 498 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 498 "gml.m"
  MR_Word * gml__HeadVar__2_2);
#line 588 "gml.m"
static /* final */ const MR_Box gml__const_15_0_1_V_36_36[2];
#line 588 "gml.m"
static /* final */ const MR_Box gml__const_15_0_2_V_77_77[2];
#line 478 "gml.m"
static void MR_CALL gml__get_float_decimals_4_p_0(
#line 478 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 478 "gml.m"
  MR_Word * gml__HeadVar__2_2);
#line 568 "gml.m"
static /* final */ const MR_Box gml__const_14_0_1_V_56_56[2];
#line 459 "gml.m"
static void MR_CALL gml__get_int_dot_4_p_0(
#line 459 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 459 "gml.m"
  MR_Word * gml__HeadVar__2_2);
#line 568 "gml.m"
static /* final */ const MR_Box gml__const_13_0_1_V_41_41[2];
#line 568 "gml.m"
static /* final */ const MR_Box gml__const_13_0_2_V_82_82[2];
#line 439 "gml.m"
static void MR_CALL gml__get_number_4_p_0(
#line 439 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 439 "gml.m"
  MR_Word * gml__HeadVar__2_2);
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_12_0_1_V_49_49[2];
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_12_0_2_V_45_45[2];
#line 419 "gml.m"
static void MR_CALL gml__get_string_4_p_0(
#line 419 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 419 "gml.m"
  MR_String * gml__HeadVar__2_2);
#line 397 "gml.m"
static void MR_CALL gml__get_identifier_4_p_0(
#line 397 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 397 "gml.m"
  MR_String * gml__HeadVar__2_2);
#line 346 "gml.m"
static /* final */ const int gml__const_10_0_1_next_slots_table[128];
#line 346 "gml.m"
static /* final */ const MR_String gml__const_10_0_2_string_table[128];
#line 343 "gml.m"
static bool MR_CALL gml__is_operator_2_p_0(
#line 343 "gml.m"
  MR_String gml__HeadVar__1_1,
#line 343 "gml.m"
  MR_Word * gml__HeadVar__2_2);
#line 258 "gml.m"
static /* final */ const MR_Box gml__const_6_0_1_V_24_24[2];
#line 258 "gml.m"
static /* final */ const MR_Box gml__const_6_0_2_HeadVar__2_2[1];
#line 260 "gml.m"
static /* final */ const MR_Box gml__const_6_0_3_V_26_26[2];
#line 260 "gml.m"
static /* final */ const MR_Box gml__const_6_0_4_HeadVar__2_2[1];
#line 644 "gml.m"
static /* final */ const MR_Box gml__const_6_0_5_V_54_54[2];
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_6_0_6_V_78_78[2];
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_6_0_7_V_74_74[2];
#line 246 "gml.m"
static void MR_CALL gml__get_token_4_p_0(
#line 246 "gml.m"
  MR_Char gml__HeadVar__1_1,
#line 246 "gml.m"
  MR_Word * gml__HeadVar__2_2);
#line 225 "gml.m"
static void MR_CALL gml__skip_to_end_of_line_2_p_0(void);
#line 196 "gml.m"
static void MR_CALL gml__skip_whitespace_3_p_0(
#line 196 "gml.m"
  MR_Word * gml__HeadVar__1_1);



const MR_TypeCtorInfo_Struct gml__gml__type_ctor_info_token_list_0 = {
		(MR_Integer) 0,
		((MR_Box) (gml____Unify____token_list_0_0)),
		((MR_Box) (gml____Unify____token_list_0_0)),
		((MR_Box) (gml____Compare____token_list_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "gml",
		(MR_String) "token_list",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&gml__list__type_info_list_1__type0_18_gml__token_group_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct gml__gml__type_ctor_info_token_group_0 = {
		(MR_Integer) 0,
		((MR_Box) (gml____Unify____token_group_0_0)),
		((MR_Box) (gml____Unify____token_group_0_0)),
		((MR_Box) (gml____Compare____token_group_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "gml",
		(MR_String) "token_group",
		(MR_Integer) 4,
		{
		(MR_Box) gml__gml__du_name_ordered_token_group_0},
		{
		(MR_Box) gml__gml__du_ptag_ordered_token_group_0},
		(MR_Integer) 3,
		(MR_Integer) 3};
const MR_TypeCtorInfo_Struct gml__gml__type_ctor_info_token_0 = {
		(MR_Integer) 0,
		((MR_Box) (gml____Unify____token_0_0)),
		((MR_Box) (gml____Unify____token_0_0)),
		((MR_Box) (gml____Compare____token_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "gml",
		(MR_String) "token",
		(MR_Integer) 4,
		{
		(MR_Box) gml__gml__du_name_ordered_token_0},
		{
		(MR_Box) gml__gml__du_ptag_ordered_token_0},
		(MR_Integer) 7,
		(MR_Integer) 4};
const MR_TypeCtorInfo_Struct gml__gml__type_ctor_info_stop_at_0 = {
		(MR_Integer) 0,
		((MR_Box) (gml____Unify____stop_at_0_0)),
		((MR_Box) (gml____Unify____stop_at_0_0)),
		((MR_Box) (gml____Compare____stop_at_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_ENUM,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "gml",
		(MR_String) "stop_at",
		(MR_Integer) 4,
		{
		(MR_Box) gml__gml__enum_name_ordered_stop_at_0},
		{
		(MR_Box) gml__gml__enum_value_ordered_stop_at_0},
		(MR_Integer) 3,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct gml__gml__type_ctor_info_parse_error_0 = {
		(MR_Integer) 0,
		((MR_Box) (gml____Unify____parse_error_0_0)),
		((MR_Box) (gml____Unify____parse_error_0_0)),
		((MR_Box) (gml____Compare____parse_error_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_NOTAG_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "gml",
		(MR_String) "parse_error",
		(MR_Integer) 4,
		{
		(MR_Box) (&gml__gml__notag_functor_desc_parse_error_0)},
		{
		(MR_Box) (&gml__gml__notag_functor_desc_parse_error_0)},
		(MR_Integer) 1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct gml__gml__type_ctor_info_operator_0 = {
		(MR_Integer) 0,
		((MR_Box) (gml____Unify____operator_0_0)),
		((MR_Box) (gml____Unify____operator_0_0)),
		((MR_Box) (gml____Compare____operator_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_ENUM,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "gml",
		(MR_String) "operator",
		(MR_Integer) 4,
		{
		(MR_Box) gml__gml__enum_name_ordered_operator_0},
		{
		(MR_Box) gml__gml__enum_value_ordered_operator_0},
		(MR_Integer) 50,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct gml__gml__type_ctor_info_number_0 = {
		(MR_Integer) 0,
		((MR_Box) (gml____Unify____number_0_0)),
		((MR_Box) (gml____Unify____number_0_0)),
		((MR_Box) (gml____Compare____number_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "gml",
		(MR_String) "number",
		(MR_Integer) 4,
		{
		(MR_Box) gml__gml__du_name_ordered_number_0},
		{
		(MR_Box) gml__gml__du_ptag_ordered_number_0},
		(MR_Integer) 2,
		(MR_Integer) 2};
const MR_TypeCtorInfo_Struct gml__gml__type_ctor_info_lexer_error_0 = {
		(MR_Integer) 0,
		((MR_Box) (gml____Unify____lexer_error_0_0)),
		((MR_Box) (gml____Unify____lexer_error_0_0)),
		((MR_Box) (gml____Compare____lexer_error_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "gml",
		(MR_String) "lexer_error",
		(MR_Integer) 4,
		{
		(MR_Box) gml__gml__du_name_ordered_lexer_error_0},
		{
		(MR_Box) gml__gml__du_ptag_ordered_lexer_error_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct gml__gml__type_ctor_info_gml_program_0 = {
		(MR_Integer) 0,
		((MR_Box) (gml____Unify____gml_program_0_0)),
		((MR_Box) (gml____Unify____gml_program_0_0)),
		((MR_Box) (gml____Compare____gml_program_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "gml",
		(MR_String) "gml_program",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&gml__list__type_info_list_1__type0_18_gml__token_group_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct gml__gml__type_ctor_info_extra_operator_0 = {
		(MR_Integer) 0,
		((MR_Box) (gml____Unify____extra_operator_0_0)),
		((MR_Box) (gml____Unify____extra_operator_0_0)),
		((MR_Box) (gml____Compare____extra_operator_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "gml",
		(MR_String) "extra_operator",
		(MR_Integer) 4,
		{
		(MR_Box) gml__gml__du_name_ordered_extra_operator_0},
		{
		(MR_Box) gml__gml__du_ptag_ordered_extra_operator_0},
		(MR_Integer) 10,
		(MR_Integer) 4};
const MR_TypeCtorInfo_Struct gml__gml__type_ctor_info_basic_token_0 = {
		(MR_Integer) 0,
		((MR_Box) (gml____Unify____basic_token_0_0)),
		((MR_Box) (gml____Unify____basic_token_0_0)),
		((MR_Box) (gml____Compare____basic_token_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "gml",
		(MR_String) "basic_token",
		(MR_Integer) 4,
		{
		(MR_Box) gml__gml__du_name_ordered_basic_token_0},
		{
		(MR_Box) gml__gml__du_ptag_ordered_basic_token_0},
		(MR_Integer) 5,
		(MR_Integer) 2};
static const MR_FO_PseudoTypeInfo_Struct1 gml__list__type_info_list_1__type0_18_gml__token_group_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&gml__gml__type_ctor_info_token_group_0)}};
static const MR_DuFunctorDescPtr gml__gml__du_name_ordered_token_group_0[3] = {
		(&gml__gml__du_functor_desc_token_group_0_2),
		(&gml__gml__du_functor_desc_token_group_0_1),
		(&gml__gml__du_functor_desc_token_group_0_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_group_0_0 = {
		(MR_String) "single_token",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		gml__gml__field_types_token_group_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_token_group_0_0[1] = {
		(MR_PseudoTypeInfo) (&gml__gml__type_ctor_info_token_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_group_0_1 = {
		(MR_String) "function",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		gml__gml__field_types_token_group_0_1,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_token_group_0_1[1] = {
		(MR_PseudoTypeInfo) (&gml__list__type_info_list_1__type0_18_gml__token_group_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_group_0_2 = {
		(MR_String) "array",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 2,
		(MR_Integer) 0,
		(MR_Integer) 2,
		gml__gml__field_types_token_group_0_2,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_token_group_0_2[1] = {
		(MR_PseudoTypeInfo) (&gml__list__type_info_list_1__type0_18_gml__token_group_0)};
static const MR_DuPtagLayout gml__gml__du_ptag_ordered_token_group_0[3] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		gml__gml__du_stag_ordered_token_group_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		gml__gml__du_stag_ordered_token_group_0_1},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		gml__gml__du_stag_ordered_token_group_0_2}};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_group_0_0[1] = {
		(&gml__gml__du_functor_desc_token_group_0_0)};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_group_0_1[1] = {
		(&gml__gml__du_functor_desc_token_group_0_1)};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_group_0_2[1] = {
		(&gml__gml__du_functor_desc_token_group_0_2)};
static const MR_DuFunctorDescPtr gml__gml__du_name_ordered_token_0[7] = {
		(&gml__gml__du_functor_desc_token_0_2),
		(&gml__gml__du_functor_desc_token_0_3),
		(&gml__gml__du_functor_desc_token_0_6),
		(&gml__gml__du_functor_desc_token_0_1),
		(&gml__gml__du_functor_desc_token_0_4),
		(&gml__gml__du_functor_desc_token_0_0),
		(&gml__gml__du_functor_desc_token_0_5)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_0 = {
		(MR_String) "operator",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		gml__gml__field_types_token_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_0[1] = {
		(MR_PseudoTypeInfo) (&gml__gml__type_ctor_info_operator_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_1 = {
		(MR_String) "identifier",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		gml__gml__field_types_token_0_1,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_1[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_2 = {
		(MR_String) "binder",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 2,
		(MR_Integer) 0,
		(MR_Integer) 2,
		gml__gml__field_types_token_0_2,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_2[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_3 = {
		(MR_String) "boolean",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 0,
		(MR_Integer) 3,
		gml__gml__field_types_token_0_3,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_3[1] = {
		(MR_PseudoTypeInfo) (&mercury__bool__bool__type_ctor_info_bool_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_4 = {
		(MR_String) "number",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 1,
		(MR_Integer) 4,
		gml__gml__field_types_token_0_4,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_4[1] = {
		(MR_PseudoTypeInfo) (&gml__gml__type_ctor_info_number_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_5 = {
		(MR_String) "string",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 2,
		(MR_Integer) 5,
		gml__gml__field_types_token_0_5,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_5[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_token_0_6 = {
		(MR_String) "extra",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 3,
		(MR_Integer) 6,
		gml__gml__field_types_token_0_6,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_token_0_6[1] = {
		(MR_PseudoTypeInfo) (&gml__gml__type_ctor_info_extra_operator_0)};
static const MR_DuPtagLayout gml__gml__du_ptag_ordered_token_0[4] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		gml__gml__du_stag_ordered_token_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		gml__gml__du_stag_ordered_token_0_1},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		gml__gml__du_stag_ordered_token_0_2},
		{
		(MR_Integer) 4,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		gml__gml__du_stag_ordered_token_0_3}};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_0_0[1] = {
		(&gml__gml__du_functor_desc_token_0_0)};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_0_1[1] = {
		(&gml__gml__du_functor_desc_token_0_1)};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_0_2[1] = {
		(&gml__gml__du_functor_desc_token_0_2)};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_token_0_3[4] = {
		(&gml__gml__du_functor_desc_token_0_3),
		(&gml__gml__du_functor_desc_token_0_4),
		(&gml__gml__du_functor_desc_token_0_5),
		(&gml__gml__du_functor_desc_token_0_6)};
static const MR_EnumFunctorDescPtr gml__gml__enum_name_ordered_stop_at_0[3] = {
		(&gml__gml__enum_functor_desc_stop_at_0_1),
		(&gml__gml__enum_functor_desc_stop_at_0_2),
		(&gml__gml__enum_functor_desc_stop_at_0_0)};
static const MR_EnumFunctorDescPtr gml__gml__enum_value_ordered_stop_at_0[3] = {
		(&gml__gml__enum_functor_desc_stop_at_0_0),
		(&gml__gml__enum_functor_desc_stop_at_0_1),
		(&gml__gml__enum_functor_desc_stop_at_0_2)};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_stop_at_0_0 = {
		(MR_String) "eof",
		(MR_Integer) 0};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_stop_at_0_1 = {
		(MR_String) "end_array",
		(MR_Integer) 1};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_stop_at_0_2 = {
		(MR_String) "end_function",
		(MR_Integer) 2};
static const MR_NotagFunctorDesc gml__gml__notag_functor_desc_parse_error_0 = {
		(MR_String) "parse_error",
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0),
		(MR_Box) NULL};
static const MR_EnumFunctorDescPtr gml__gml__enum_name_ordered_operator_0[50] = {
		(&gml__gml__enum_functor_desc_operator_0_0),
		(&gml__gml__enum_functor_desc_operator_0_2),
		(&gml__gml__enum_functor_desc_operator_0_1),
		(&gml__gml__enum_functor_desc_operator_0_3),
		(&gml__gml__enum_functor_desc_operator_0_4),
		(&gml__gml__enum_functor_desc_operator_0_5),
		(&gml__gml__enum_functor_desc_operator_0_6),
		(&gml__gml__enum_functor_desc_operator_0_7),
		(&gml__gml__enum_functor_desc_operator_0_8),
		(&gml__gml__enum_functor_desc_operator_0_9),
		(&gml__gml__enum_functor_desc_operator_0_10),
		(&gml__gml__enum_functor_desc_operator_0_12),
		(&gml__gml__enum_functor_desc_operator_0_11),
		(&gml__gml__enum_functor_desc_operator_0_14),
		(&gml__gml__enum_functor_desc_operator_0_13),
		(&gml__gml__enum_functor_desc_operator_0_15),
		(&gml__gml__enum_functor_desc_operator_0_16),
		(&gml__gml__enum_functor_desc_operator_0_17),
		(&gml__gml__enum_functor_desc_operator_0_18),
		(&gml__gml__enum_functor_desc_operator_0_19),
		(&gml__gml__enum_functor_desc_operator_0_20),
		(&gml__gml__enum_functor_desc_operator_0_21),
		(&gml__gml__enum_functor_desc_operator_0_22),
		(&gml__gml__enum_functor_desc_operator_0_23),
		(&gml__gml__enum_functor_desc_operator_0_25),
		(&gml__gml__enum_functor_desc_operator_0_24),
		(&gml__gml__enum_functor_desc_operator_0_26),
		(&gml__gml__enum_functor_desc_operator_0_27),
		(&gml__gml__enum_functor_desc_operator_0_29),
		(&gml__gml__enum_functor_desc_operator_0_28),
		(&gml__gml__enum_functor_desc_operator_0_31),
		(&gml__gml__enum_functor_desc_operator_0_30),
		(&gml__gml__enum_functor_desc_operator_0_32),
		(&gml__gml__enum_functor_desc_operator_0_33),
		(&gml__gml__enum_functor_desc_operator_0_34),
		(&gml__gml__enum_functor_desc_operator_0_35),
		(&gml__gml__enum_functor_desc_operator_0_36),
		(&gml__gml__enum_functor_desc_operator_0_37),
		(&gml__gml__enum_functor_desc_operator_0_38),
		(&gml__gml__enum_functor_desc_operator_0_39),
		(&gml__gml__enum_functor_desc_operator_0_40),
		(&gml__gml__enum_functor_desc_operator_0_41),
		(&gml__gml__enum_functor_desc_operator_0_42),
		(&gml__gml__enum_functor_desc_operator_0_43),
		(&gml__gml__enum_functor_desc_operator_0_44),
		(&gml__gml__enum_functor_desc_operator_0_46),
		(&gml__gml__enum_functor_desc_operator_0_45),
		(&gml__gml__enum_functor_desc_operator_0_47),
		(&gml__gml__enum_functor_desc_operator_0_48),
		(&gml__gml__enum_functor_desc_operator_0_49)};
static const MR_EnumFunctorDescPtr gml__gml__enum_value_ordered_operator_0[50] = {
		(&gml__gml__enum_functor_desc_operator_0_0),
		(&gml__gml__enum_functor_desc_operator_0_1),
		(&gml__gml__enum_functor_desc_operator_0_2),
		(&gml__gml__enum_functor_desc_operator_0_3),
		(&gml__gml__enum_functor_desc_operator_0_4),
		(&gml__gml__enum_functor_desc_operator_0_5),
		(&gml__gml__enum_functor_desc_operator_0_6),
		(&gml__gml__enum_functor_desc_operator_0_7),
		(&gml__gml__enum_functor_desc_operator_0_8),
		(&gml__gml__enum_functor_desc_operator_0_9),
		(&gml__gml__enum_functor_desc_operator_0_10),
		(&gml__gml__enum_functor_desc_operator_0_11),
		(&gml__gml__enum_functor_desc_operator_0_12),
		(&gml__gml__enum_functor_desc_operator_0_13),
		(&gml__gml__enum_functor_desc_operator_0_14),
		(&gml__gml__enum_functor_desc_operator_0_15),
		(&gml__gml__enum_functor_desc_operator_0_16),
		(&gml__gml__enum_functor_desc_operator_0_17),
		(&gml__gml__enum_functor_desc_operator_0_18),
		(&gml__gml__enum_functor_desc_operator_0_19),
		(&gml__gml__enum_functor_desc_operator_0_20),
		(&gml__gml__enum_functor_desc_operator_0_21),
		(&gml__gml__enum_functor_desc_operator_0_22),
		(&gml__gml__enum_functor_desc_operator_0_23),
		(&gml__gml__enum_functor_desc_operator_0_24),
		(&gml__gml__enum_functor_desc_operator_0_25),
		(&gml__gml__enum_functor_desc_operator_0_26),
		(&gml__gml__enum_functor_desc_operator_0_27),
		(&gml__gml__enum_functor_desc_operator_0_28),
		(&gml__gml__enum_functor_desc_operator_0_29),
		(&gml__gml__enum_functor_desc_operator_0_30),
		(&gml__gml__enum_functor_desc_operator_0_31),
		(&gml__gml__enum_functor_desc_operator_0_32),
		(&gml__gml__enum_functor_desc_operator_0_33),
		(&gml__gml__enum_functor_desc_operator_0_34),
		(&gml__gml__enum_functor_desc_operator_0_35),
		(&gml__gml__enum_functor_desc_operator_0_36),
		(&gml__gml__enum_functor_desc_operator_0_37),
		(&gml__gml__enum_functor_desc_operator_0_38),
		(&gml__gml__enum_functor_desc_operator_0_39),
		(&gml__gml__enum_functor_desc_operator_0_40),
		(&gml__gml__enum_functor_desc_operator_0_41),
		(&gml__gml__enum_functor_desc_operator_0_42),
		(&gml__gml__enum_functor_desc_operator_0_43),
		(&gml__gml__enum_functor_desc_operator_0_44),
		(&gml__gml__enum_functor_desc_operator_0_45),
		(&gml__gml__enum_functor_desc_operator_0_46),
		(&gml__gml__enum_functor_desc_operator_0_47),
		(&gml__gml__enum_functor_desc_operator_0_48),
		(&gml__gml__enum_functor_desc_operator_0_49)};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_0 = {
		(MR_String) "acos",
		(MR_Integer) 0};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_1 = {
		(MR_String) "addi",
		(MR_Integer) 1};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_2 = {
		(MR_String) "addf",
		(MR_Integer) 2};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_3 = {
		(MR_String) "apply",
		(MR_Integer) 3};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_4 = {
		(MR_String) "asin",
		(MR_Integer) 4};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_5 = {
		(MR_String) "clampf",
		(MR_Integer) 5};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_6 = {
		(MR_String) "cone",
		(MR_Integer) 6};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_7 = {
		(MR_String) "cos",
		(MR_Integer) 7};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_8 = {
		(MR_String) "cube",
		(MR_Integer) 8};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_9 = {
		(MR_String) "cylinder",
		(MR_Integer) 9};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_10 = {
		(MR_String) "difference",
		(MR_Integer) 10};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_11 = {
		(MR_String) "divi",
		(MR_Integer) 11};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_12 = {
		(MR_String) "divf",
		(MR_Integer) 12};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_13 = {
		(MR_String) "eqi",
		(MR_Integer) 13};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_14 = {
		(MR_String) "eqf",
		(MR_Integer) 14};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_15 = {
		(MR_String) "floor",
		(MR_Integer) 15};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_16 = {
		(MR_String) "frac",
		(MR_Integer) 16};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_17 = {
		(MR_String) "get",
		(MR_Integer) 17};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_18 = {
		(MR_String) "getx",
		(MR_Integer) 18};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_19 = {
		(MR_String) "gety",
		(MR_Integer) 19};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_20 = {
		(MR_String) "getz",
		(MR_Integer) 20};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_21 = {
		(MR_String) "if",
		(MR_Integer) 21};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_22 = {
		(MR_String) "intersect",
		(MR_Integer) 22};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_23 = {
		(MR_String) "length",
		(MR_Integer) 23};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_24 = {
		(MR_String) "lessi",
		(MR_Integer) 24};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_25 = {
		(MR_String) "lessf",
		(MR_Integer) 25};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_26 = {
		(MR_String) "light",
		(MR_Integer) 26};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_27 = {
		(MR_String) "modi",
		(MR_Integer) 27};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_28 = {
		(MR_String) "muli",
		(MR_Integer) 28};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_29 = {
		(MR_String) "mulf",
		(MR_Integer) 29};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_30 = {
		(MR_String) "negi",
		(MR_Integer) 30};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_31 = {
		(MR_String) "negf",
		(MR_Integer) 31};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_32 = {
		(MR_String) "plane",
		(MR_Integer) 32};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_33 = {
		(MR_String) "point",
		(MR_Integer) 33};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_34 = {
		(MR_String) "pointlight",
		(MR_Integer) 34};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_35 = {
		(MR_String) "real",
		(MR_Integer) 35};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_36 = {
		(MR_String) "render",
		(MR_Integer) 36};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_37 = {
		(MR_String) "rotatex",
		(MR_Integer) 37};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_38 = {
		(MR_String) "rotatey",
		(MR_Integer) 38};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_39 = {
		(MR_String) "rotatez",
		(MR_Integer) 39};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_40 = {
		(MR_String) "scale",
		(MR_Integer) 40};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_41 = {
		(MR_String) "sin",
		(MR_Integer) 41};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_42 = {
		(MR_String) "sphere",
		(MR_Integer) 42};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_43 = {
		(MR_String) "spotlight",
		(MR_Integer) 43};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_44 = {
		(MR_String) "sqrt",
		(MR_Integer) 44};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_45 = {
		(MR_String) "subi",
		(MR_Integer) 45};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_46 = {
		(MR_String) "subf",
		(MR_Integer) 46};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_47 = {
		(MR_String) "translate",
		(MR_Integer) 47};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_48 = {
		(MR_String) "union",
		(MR_Integer) 48};
static const MR_EnumFunctorDesc gml__gml__enum_functor_desc_operator_0_49 = {
		(MR_String) "uscale",
		(MR_Integer) 49};
static const MR_DuFunctorDescPtr gml__gml__du_name_ordered_number_0[2] = {
		(&gml__gml__du_functor_desc_number_0_0),
		(&gml__gml__du_functor_desc_number_0_1)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_number_0_0 = {
		(MR_String) "integer",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		gml__gml__field_types_number_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_number_0_0[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_number_0_1 = {
		(MR_String) "real",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		gml__gml__field_types_number_0_1,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_number_0_1[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuPtagLayout gml__gml__du_ptag_ordered_number_0[2] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		gml__gml__du_stag_ordered_number_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		gml__gml__du_stag_ordered_number_0_1}};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_number_0_0[1] = {
		(&gml__gml__du_functor_desc_number_0_0)};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_number_0_1[1] = {
		(&gml__gml__du_functor_desc_number_0_1)};
static const MR_DuFunctorDescPtr gml__gml__du_name_ordered_lexer_error_0[1] = {
		(&gml__gml__du_functor_desc_lexer_error_0_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_lexer_error_0_0 = {
		(MR_String) "lexer_error",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		gml__gml__field_types_lexer_error_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_lexer_error_0_0[2] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0)};
static const MR_DuPtagLayout gml__gml__du_ptag_ordered_lexer_error_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		gml__gml__du_stag_ordered_lexer_error_0_0}};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_lexer_error_0_0[1] = {
		(&gml__gml__du_functor_desc_lexer_error_0_0)};
static const MR_DuFunctorDescPtr gml__gml__du_name_ordered_extra_operator_0[10] = {
		(&gml__gml__du_functor_desc_extra_operator_0_4),
		(&gml__gml__du_functor_desc_extra_operator_0_5),
		(&gml__gml__du_functor_desc_extra_operator_0_6),
		(&gml__gml__du_functor_desc_extra_operator_0_8),
		(&gml__gml__du_functor_desc_extra_operator_0_3),
		(&gml__gml__du_functor_desc_extra_operator_0_7),
		(&gml__gml__du_functor_desc_extra_operator_0_2),
		(&gml__gml__du_functor_desc_extra_operator_0_1),
		(&gml__gml__du_functor_desc_extra_operator_0_9),
		(&gml__gml__du_functor_desc_extra_operator_0_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_0 = {
		(MR_String) "popn",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 0,
		gml__gml__field_types_extra_operator_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_0[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_1 = {
		(MR_String) "dup",
		(MR_Integer) 0,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 1,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_2 = {
		(MR_String) "constant_sphere",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 2,
		(MR_Integer) 0,
		(MR_Integer) 2,
		gml__gml__field_types_extra_operator_0_2,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_2[1] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_surface_properties_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_3 = {
		(MR_String) "constant_plane",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 0,
		(MR_Integer) 3,
		gml__gml__field_types_extra_operator_0_3,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_3[1] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_surface_properties_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_4 = {
		(MR_String) "constant_cone",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 1,
		(MR_Integer) 4,
		gml__gml__field_types_extra_operator_0_4,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_4[1] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_surface_properties_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_5 = {
		(MR_String) "constant_cube",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 2,
		(MR_Integer) 5,
		gml__gml__field_types_extra_operator_0_5,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_5[1] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_surface_properties_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_6 = {
		(MR_String) "constant_cylinder",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 3,
		(MR_Integer) 6,
		gml__gml__field_types_extra_operator_0_6,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_6[1] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_surface_properties_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_7 = {
		(MR_String) "constant_point",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 4,
		(MR_Integer) 7,
		gml__gml__field_types_extra_operator_0_7,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_7[1] = {
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_8 = {
		(MR_String) "constant_if",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 5,
		(MR_Integer) 8,
		gml__gml__field_types_extra_operator_0_8,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_8[2] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_value_0),
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_value_0)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_extra_operator_0_9 = {
		(MR_String) "mercury_closure",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 6,
		(MR_Integer) 9,
		gml__gml__field_types_extra_operator_0_9,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_extra_operator_0_9[1] = {
		(MR_PseudoTypeInfo) (&gml____ho_type_info_pred_6__type_18_tree234__tree234_2__type0_10___string_0__type0_13_eval__value_0__type_12_list__list_1__type0_13_eval__value_0__type_18_tree234__tree234_2__type0_10___string_0__type0_13_eval__value_0__type_12_list__list_1__type0_13_eval__value_0__type0_11_io__state_0__type0_11_io__state_0)};
static const MR_FO_PseudoTypeInfo_Struct1 gml__list__type_info_list_1__type0_13_eval__value_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_value_0)}};
static const MR_FO_PseudoTypeInfo_Struct2 gml__tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0 = {
		(&mercury__tree234__tree234__type_ctor_info_tree234_2),
		{
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0),
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_value_0)}};
static const MR_HO_PseudoTypeInfo_Struct6 gml____ho_type_info_pred_6__type_18_tree234__tree234_2__type0_10___string_0__type0_13_eval__value_0__type_12_list__list_1__type0_13_eval__value_0__type_18_tree234__tree234_2__type0_10___string_0__type0_13_eval__value_0__type_12_list__list_1__type0_13_eval__value_0__type0_11_io__state_0__type0_11_io__state_0 = {
		(&mercury__builtin____type_ctor_info_pred_0),
		(MR_Integer) 6,
		{
		(MR_PseudoTypeInfo) (&gml__tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0),
		(MR_PseudoTypeInfo) (&gml__list__type_info_list_1__type0_13_eval__value_0),
		(MR_PseudoTypeInfo) (&gml__tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0),
		(MR_PseudoTypeInfo) (&gml__list__type_info_list_1__type0_13_eval__value_0),
		(MR_PseudoTypeInfo) (&mercury__io__io__type_ctor_info_state_0),
		(MR_PseudoTypeInfo) (&mercury__io__io__type_ctor_info_state_0)}};
static const MR_DuPtagLayout gml__gml__du_ptag_ordered_extra_operator_0[4] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		gml__gml__du_stag_ordered_extra_operator_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		gml__gml__du_stag_ordered_extra_operator_0_1},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		gml__gml__du_stag_ordered_extra_operator_0_2},
		{
		(MR_Integer) 7,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		gml__gml__du_stag_ordered_extra_operator_0_3}};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_extra_operator_0_0[1] = {
		(&gml__gml__du_functor_desc_extra_operator_0_1)};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_extra_operator_0_1[1] = {
		(&gml__gml__du_functor_desc_extra_operator_0_0)};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_extra_operator_0_2[1] = {
		(&gml__gml__du_functor_desc_extra_operator_0_2)};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_extra_operator_0_3[7] = {
		(&gml__gml__du_functor_desc_extra_operator_0_3),
		(&gml__gml__du_functor_desc_extra_operator_0_4),
		(&gml__gml__du_functor_desc_extra_operator_0_5),
		(&gml__gml__du_functor_desc_extra_operator_0_6),
		(&gml__gml__du_functor_desc_extra_operator_0_7),
		(&gml__gml__du_functor_desc_extra_operator_0_8),
		(&gml__gml__du_functor_desc_extra_operator_0_9)};
static const MR_DuFunctorDescPtr gml__gml__du_name_ordered_basic_token_0[5] = {
		(&gml__gml__du_functor_desc_basic_token_0_0),
		(&gml__gml__du_functor_desc_basic_token_0_1),
		(&gml__gml__du_functor_desc_basic_token_0_4),
		(&gml__gml__du_functor_desc_basic_token_0_2),
		(&gml__gml__du_functor_desc_basic_token_0_3)};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_basic_token_0_0 = {
		(MR_String) "[",
		(MR_Integer) 0,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_basic_token_0_1 = {
		(MR_String) "]",
		(MR_Integer) 0,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		(MR_Integer) 0,
		(MR_Integer) 1,
		(MR_Integer) 1,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_basic_token_0_2 = {
		(MR_String) "{",
		(MR_Integer) 0,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		(MR_Integer) 0,
		(MR_Integer) 2,
		(MR_Integer) 2,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_basic_token_0_3 = {
		(MR_String) "}",
		(MR_Integer) 0,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		(MR_Integer) 0,
		(MR_Integer) 3,
		(MR_Integer) 3,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_DuFunctorDesc gml__gml__du_functor_desc_basic_token_0_4 = {
		(MR_String) "token",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 4,
		gml__gml__field_types_basic_token_0_4,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo gml__gml__field_types_basic_token_0_4[1] = {
		(MR_PseudoTypeInfo) (&gml__gml__type_ctor_info_token_0)};
static const MR_DuPtagLayout gml__gml__du_ptag_ordered_basic_token_0[2] = {
		{
		(MR_Integer) 4,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		gml__gml__du_stag_ordered_basic_token_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		gml__gml__du_stag_ordered_basic_token_0_1}};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_basic_token_0_0[4] = {
		(&gml__gml__du_functor_desc_basic_token_0_0),
		(&gml__gml__du_functor_desc_basic_token_0_1),
		(&gml__gml__du_functor_desc_basic_token_0_2),
		(&gml__gml__du_functor_desc_basic_token_0_3)};
static const MR_DuFunctorDescPtr gml__gml__du_stag_ordered_basic_token_0_1[1] = {
		(&gml__gml__du_functor_desc_basic_token_0_4)};

#line 24 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.int"
static void MR_CALL gml__builtin_compare_pred__ua0_3_p_in__private_builtin_0(
#line 24 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.int"
  MR_Word * gml__HeadVar__1_1)
#line 24 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.int"
{
#line 99 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  {
#line 99 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    bool gml__succeeded;

#line 95 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    {
#line 95 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      gml__succeeded = mercury__std_util__semidet_succeed_0_p_0();
    }
#line 99 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (gml__succeeded)
      {
        MR_String gml__V_7_7 = (MR_String) "attempted higher-order comparison";

#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          mercury__require__error_1_p_0(gml__V_7_7);
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          return;
        }
      }
#line 99 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 100 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *gml__HeadVar__1_1 = (MR_Integer) 1;
#line 99 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  }
#line 24 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.int"
}

#line 22 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.int"
static bool MR_CALL gml__builtin_unify_pred__ua0_2_p_in__private_builtin_0(void)
#line 22 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.int"
{
#line 89 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  {
#line 89 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    bool gml__succeeded;

#line 85 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    {
#line 85 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      gml__succeeded = mercury__std_util__semidet_succeed_0_p_0();
    }
#line 89 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (gml__succeeded)
      {
        MR_String gml__V_5_5 = (MR_String) "attempted higher-order unification";

#line 88 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        {
#line 88 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          mercury__require__error_1_p_0(gml__V_5_5);
        }
        gml__succeeded = TRUE;
      }
#line 89 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 90 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 90 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        return gml__succeeded = mercury__std_util__semidet_succeed_0_p_0();
      }
#line 89 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    return gml__succeeded;
#line 89 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  }
#line 22 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.int"
}

#line 662 "gml.m"
void MR_CALL gml____Compare____stop_at_0_0(
#line 662 "gml.m"
  MR_Word * gml__HeadVar__1_1,
#line 662 "gml.m"
  MR_Word gml__HeadVar__2_2,
#line 662 "gml.m"
  MR_Word gml__HeadVar__3_3)
#line 662 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Integer gml__V_4_4 = (MR_Integer) gml__HeadVar__2_2;
    MR_Integer gml__V_5_5 = (MR_Integer) gml__HeadVar__3_3;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    gml__succeeded = (gml__V_4_4 < gml__V_5_5);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (gml__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *gml__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        gml__succeeded = (gml__V_4_4 == gml__V_5_5);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (gml__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *gml__HeadVar__1_1 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *gml__HeadVar__1_1 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
  }
#line 662 "gml.m"
}

#line 662 "gml.m"
bool MR_CALL gml____Unify____stop_at_0_0(
#line 662 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 662 "gml.m"
  MR_Word gml__HeadVar__2_2)
#line 662 "gml.m"
{
#line 662 "gml.m"
  {
#line 662 "gml.m"
    bool gml__succeeded = (gml__HeadVar__1_1 == gml__HeadVar__2_2);

#line 662 "gml.m"
    return gml__succeeded;
#line 662 "gml.m"
  }
#line 662 "gml.m"
}

#line 161 "gml.m"
void MR_CALL gml____Compare____token_group_0_0(
#line 161 "gml.m"
  MR_Word * gml__HeadVar__1_1,
#line 161 "gml.m"
  MR_Word gml__HeadVar__2_2,
#line 161 "gml.m"
  MR_Word gml__HeadVar__3_3)
#line 161 "gml.m"
{
#line 161 "gml.m"
  {
#line 161 "gml.m"
    bool gml__succeeded;

#line 161 "gml.m"
#line 161 "gml.m"
    switch (MR_tag((MR_Word) gml__HeadVar__2_2)) {
#line 161 "gml.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 161 "gml.m"
      case (MR_Integer) 0:
        {
          MR_Word gml__V_31_31 = ((MR_Word) (MR_hl_field(MR_mktag(0), gml__HeadVar__2_2, (MR_Integer) 0)));

#line 161 "gml.m"
#line 161 "gml.m"
          switch (MR_tag((MR_Word) gml__HeadVar__3_3)) {
#line 161 "gml.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 161 "gml.m"
            case (MR_Integer) 0:
              {
                MR_Word gml__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), gml__HeadVar__3_3, (MR_Integer) 0)));

#line 161 "gml.m"
                {
#line 161 "gml.m"
                  gml____Compare____token_0_0(gml__HeadVar__1_1, gml__V_31_31, gml__V_5_5);
#line 161 "gml.m"
                  return;
                }
              }
#line 161 "gml.m"
              break;
#line 161 "gml.m"
            case (MR_Integer) 1:
#line 161 "gml.m"
              *gml__HeadVar__1_1 = (MR_Integer) 1;
#line 161 "gml.m"
              break;
#line 161 "gml.m"
            case (MR_Integer) 2:
#line 161 "gml.m"
              *gml__HeadVar__1_1 = (MR_Integer) 1;
#line 161 "gml.m"
              break;
#line 161 "gml.m"
          }
        }
#line 161 "gml.m"
        break;
#line 161 "gml.m"
      case (MR_Integer) 1:
        {
          MR_Word gml__V_30_30 = ((MR_Word) (MR_hl_field(MR_mktag(1), gml__HeadVar__2_2, (MR_Integer) 0)));

#line 161 "gml.m"
#line 161 "gml.m"
          switch (MR_tag((MR_Word) gml__HeadVar__3_3)) {
#line 161 "gml.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 161 "gml.m"
            case (MR_Integer) 0:
#line 161 "gml.m"
              *gml__HeadVar__1_1 = (MR_Integer) 2;
#line 161 "gml.m"
              break;
#line 161 "gml.m"
            case (MR_Integer) 1:
              {
                MR_Word gml__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), gml__HeadVar__3_3, (MR_Integer) 0)));
                MR_Word gml__TypeInfo_23_23 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 161 "gml.m"
                {
#line 161 "gml.m"
                  mercury__list____Compare____list_1_0(gml__TypeInfo_23_23, gml__HeadVar__1_1, gml__V_30_30, gml__V_7_7);
#line 161 "gml.m"
                  return;
                }
              }
#line 161 "gml.m"
              break;
#line 161 "gml.m"
            case (MR_Integer) 2:
#line 161 "gml.m"
              *gml__HeadVar__1_1 = (MR_Integer) 1;
#line 161 "gml.m"
              break;
#line 161 "gml.m"
          }
        }
#line 161 "gml.m"
        break;
#line 161 "gml.m"
      case (MR_Integer) 2:
        {
          MR_Word gml__V_29_29 = ((MR_Word) (MR_hl_field(MR_mktag(2), gml__HeadVar__2_2, (MR_Integer) 0)));

#line 161 "gml.m"
#line 161 "gml.m"
          switch (MR_tag((MR_Word) gml__HeadVar__3_3)) {
#line 161 "gml.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 161 "gml.m"
            case (MR_Integer) 0:
#line 161 "gml.m"
              *gml__HeadVar__1_1 = (MR_Integer) 2;
#line 161 "gml.m"
              break;
#line 161 "gml.m"
            case (MR_Integer) 1:
#line 161 "gml.m"
              *gml__HeadVar__1_1 = (MR_Integer) 2;
#line 161 "gml.m"
              break;
#line 161 "gml.m"
            case (MR_Integer) 2:
              {
                MR_Word gml__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(2), gml__HeadVar__3_3, (MR_Integer) 0)));
                MR_Word gml__TypeInfo_26_26 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 161 "gml.m"
                {
#line 161 "gml.m"
                  mercury__list____Compare____list_1_0(gml__TypeInfo_26_26, gml__HeadVar__1_1, gml__V_29_29, gml__V_9_9);
#line 161 "gml.m"
                  return;
                }
              }
#line 161 "gml.m"
              break;
#line 161 "gml.m"
          }
        }
#line 161 "gml.m"
        break;
#line 161 "gml.m"
    }
#line 161 "gml.m"
  }
#line 161 "gml.m"
}

#line 161 "gml.m"
bool MR_CALL gml____Unify____token_group_0_0(
#line 161 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 161 "gml.m"
  MR_Word gml__HeadVar__2_2)
#line 161 "gml.m"
{
#line 161 "gml.m"
  {
#line 161 "gml.m"
    bool gml__succeeded;

#line 161 "gml.m"
#line 161 "gml.m"
    switch (MR_tag((MR_Word) gml__HeadVar__1_1)) {
#line 161 "gml.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 161 "gml.m"
      case (MR_Integer) 0:
        {
          MR_Word gml__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), gml__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word gml__V_4_4;

#line 161 "gml.m"
          gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
#line 161 "gml.m"
          if ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 161 "gml.m"
            gml__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), gml__HeadVar__2_2, (MR_Integer) 0)));
          if (gml__succeeded)
            {
              return gml__succeeded = gml____Unify____token_0_0(gml__V_3_3, gml__V_4_4);
            }
        }
#line 161 "gml.m"
        break;
#line 161 "gml.m"
      case (MR_Integer) 1:
        {
          MR_Word gml__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(1), gml__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word gml__V_6_6;
          MR_Word gml__TypeInfo_12_12;

#line 161 "gml.m"
          gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 161 "gml.m"
          if ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 161 "gml.m"
            gml__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), gml__HeadVar__2_2, (MR_Integer) 0)));
          if (gml__succeeded)
            {
              gml__TypeInfo_12_12 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
              {
                return gml__succeeded = mercury__list____Unify____list_1_0(gml__TypeInfo_12_12, gml__V_5_5, gml__V_6_6);
              }
            }
        }
#line 161 "gml.m"
        break;
#line 161 "gml.m"
      case (MR_Integer) 2:
        {
          MR_Word gml__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(2), gml__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word gml__V_8_8;
          MR_Word gml__TypeInfo_9_9;

#line 161 "gml.m"
          gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 2));
#line 161 "gml.m"
          if ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 2)))
#line 161 "gml.m"
            gml__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(2), gml__HeadVar__2_2, (MR_Integer) 0)));
          if (gml__succeeded)
            {
              gml__TypeInfo_9_9 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
              {
                return gml__succeeded = mercury__list____Unify____list_1_0(gml__TypeInfo_9_9, gml__V_7_7, gml__V_8_8);
              }
            }
        }
#line 161 "gml.m"
        break;
#line 161 "gml.m"
    }
#line 161 "gml.m"
    return gml__succeeded;
#line 161 "gml.m"
  }
#line 161 "gml.m"
}

#line 159 "gml.m"
void MR_CALL gml____Compare____token_list_0_0(
#line 159 "gml.m"
  MR_Word * gml__HeadVar__1_1,
#line 159 "gml.m"
  MR_Word gml__HeadVar__2_2,
#line 159 "gml.m"
  MR_Word gml__HeadVar__3_3)
#line 159 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Word gml__conv1_HeadVar__2_2 = (MR_Word) gml__HeadVar__2_2;
    MR_Word gml__conv2_HeadVar__3_3 = (MR_Word) gml__HeadVar__3_3;
    MR_Word gml__TypeInfo_4_4 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 159 "gml.m"
    {
#line 159 "gml.m"
      mercury__list____Compare____list_1_0(gml__TypeInfo_4_4, gml__HeadVar__1_1, gml__conv1_HeadVar__2_2, gml__conv2_HeadVar__3_3);
#line 159 "gml.m"
      return;
    }
  }
#line 159 "gml.m"
}

#line 159 "gml.m"
bool MR_CALL gml____Unify____token_list_0_0(
#line 159 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 159 "gml.m"
  MR_Word gml__HeadVar__2_2)
#line 159 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Word gml__conv1_HeadVar__1_1 = (MR_Word) gml__HeadVar__1_1;
    MR_Word gml__conv2_HeadVar__2_2 = (MR_Word) gml__HeadVar__2_2;
    MR_Word gml__TypeInfo_3_3 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 159 "gml.m"
    {
#line 159 "gml.m"
      gml__succeeded = mercury__list____Unify____list_1_0(gml__TypeInfo_3_3, gml__conv1_HeadVar__1_1, gml__conv2_HeadVar__2_2);
    }
    if (gml__succeeded)
      gml__succeeded = TRUE;
    return gml__succeeded;
  }
#line 159 "gml.m"
}

#line 157 "gml.m"
void MR_CALL gml____Compare____gml_program_0_0(
#line 157 "gml.m"
  MR_Word * gml__HeadVar__1_1,
#line 157 "gml.m"
  MR_Word gml__HeadVar__2_2,
#line 157 "gml.m"
  MR_Word gml__HeadVar__3_3)
#line 157 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Word gml__conv1_HeadVar__2_2 = (MR_Word) gml__HeadVar__2_2;
    MR_Word gml__conv2_HeadVar__3_3 = (MR_Word) gml__HeadVar__3_3;
    MR_Word gml__TypeInfo_4_4 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 157 "gml.m"
    {
#line 157 "gml.m"
      mercury__list____Compare____list_1_0(gml__TypeInfo_4_4, gml__HeadVar__1_1, gml__conv1_HeadVar__2_2, gml__conv2_HeadVar__3_3);
#line 157 "gml.m"
      return;
    }
  }
#line 157 "gml.m"
}

#line 157 "gml.m"
bool MR_CALL gml____Unify____gml_program_0_0(
#line 157 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 157 "gml.m"
  MR_Word gml__HeadVar__2_2)
#line 157 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Word gml__conv1_HeadVar__1_1 = (MR_Word) gml__HeadVar__1_1;
    MR_Word gml__conv2_HeadVar__2_2 = (MR_Word) gml__HeadVar__2_2;
    MR_Word gml__TypeInfo_3_3 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 157 "gml.m"
    {
#line 157 "gml.m"
      gml__succeeded = mercury__list____Unify____list_1_0(gml__TypeInfo_3_3, gml__conv1_HeadVar__1_1, gml__conv2_HeadVar__2_2);
    }
    if (gml__succeeded)
      gml__succeeded = TRUE;
    return gml__succeeded;
  }
#line 157 "gml.m"
}

#line 149 "gml.m"
void MR_CALL gml____Compare____parse_error_0_0(
#line 149 "gml.m"
  MR_Word * gml__HeadVar__1_1,
#line 149 "gml.m"
  MR_Word gml__HeadVar__2_2,
#line 149 "gml.m"
  MR_Word gml__HeadVar__3_3)
#line 149 "gml.m"
{
  {
    bool gml__succeeded;
    MR_String gml__V_4_4 = (MR_String) gml__HeadVar__2_2;
    MR_String gml__V_5_5 = (MR_String) gml__HeadVar__3_3;
    MR_Integer gml__Res_7_10;
    MR_Integer gml__V_8_11;

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL gml____Compare____parse_error_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__V_4_4
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__V_5_5
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__Res_7_10
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    gml__V_8_11 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    gml__succeeded = (gml__Res_7_10 < gml__V_8_11);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (gml__succeeded)
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *gml__HeadVar__1_1 = (MR_Integer) 1;
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        gml__succeeded = (gml__Res_7_10 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (gml__succeeded)
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *gml__HeadVar__1_1 = (MR_Integer) 0;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *gml__HeadVar__1_1 = (MR_Integer) 2;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
  }
#line 149 "gml.m"
}

#line 149 "gml.m"
bool MR_CALL gml____Unify____parse_error_0_0(
#line 149 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 149 "gml.m"
  MR_Word gml__HeadVar__2_2)
#line 149 "gml.m"
{
  {
    bool gml__succeeded;
    MR_String gml__V_3_3 = (MR_String) gml__HeadVar__1_1;
    MR_String gml__V_4_4 = (MR_String) gml__HeadVar__2_2;

    gml__succeeded = (strcmp(gml__V_3_3, gml__V_4_4) == 0);
    return gml__succeeded;
  }
#line 149 "gml.m"
}

#line 146 "gml.m"
void MR_CALL gml____Compare____lexer_error_0_0(
#line 146 "gml.m"
  MR_Word * gml__HeadVar__1_1,
#line 146 "gml.m"
  MR_Word gml__HeadVar__2_2,
#line 146 "gml.m"
  MR_Word gml__HeadVar__3_3)
#line 146 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Integer gml__V_4_4 = ((MR_Integer) (MR_hl_field(MR_mktag(0), gml__HeadVar__2_2, (MR_Integer) 0)));
    MR_String gml__V_5_5 = ((MR_String) (MR_hl_field(MR_mktag(0), gml__HeadVar__2_2, (MR_Integer) 1)));
    MR_Integer gml__V_6_6 = ((MR_Integer) (MR_hl_field(MR_mktag(0), gml__HeadVar__3_3, (MR_Integer) 0)));
    MR_String gml__V_7_7 = ((MR_String) (MR_hl_field(MR_mktag(0), gml__HeadVar__3_3, (MR_Integer) 1)));
#line 146 "gml.m"
    MR_Word gml__V_8_8;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    gml__succeeded = (gml__V_4_4 < gml__V_6_6);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (gml__succeeded)
      {
        MR_Word gml__V_22_22 = (MR_Integer) 1;

#line 146 "gml.m"
        gml__succeeded = (gml__V_22_22 == (MR_Integer) 0);
#line 146 "gml.m"
        gml__succeeded = !(gml__succeeded);
        if (gml__succeeded)
          {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            gml__V_8_8 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            gml__succeeded = TRUE;
          }
      }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        gml__succeeded = (gml__V_4_4 == gml__V_6_6);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (gml__succeeded)
          {
            MR_Word gml__V_23_23 = (MR_Integer) 0;

#line 146 "gml.m"
            gml__succeeded = (gml__V_23_23 == (MR_Integer) 0);
#line 146 "gml.m"
            gml__succeeded = !(gml__succeeded);
            if (gml__succeeded)
              {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                gml__V_8_8 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                gml__succeeded = TRUE;
              }
          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
          {
            MR_Word gml__V_24_24 = (MR_Integer) 2;

#line 146 "gml.m"
            gml__succeeded = (gml__V_24_24 == (MR_Integer) 0);
#line 146 "gml.m"
            gml__succeeded = !(gml__succeeded);
            if (gml__succeeded)
              {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                gml__V_8_8 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                gml__succeeded = TRUE;
              }
          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 146 "gml.m"
    if (gml__succeeded)
#line 146 "gml.m"
      *gml__HeadVar__1_1 = gml__V_8_8;
#line 146 "gml.m"
    else
      {
        MR_Integer gml__Res_7_17;
        MR_Integer gml__V_8_18;

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL gml____Compare____lexer_error_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__V_5_5
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__V_7_7
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__Res_7_17
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        gml__V_8_18 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        gml__succeeded = (gml__Res_7_17 < gml__V_8_18);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (gml__succeeded)
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *gml__HeadVar__1_1 = (MR_Integer) 1;
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            gml__succeeded = (gml__Res_7_17 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (gml__succeeded)
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              *gml__HeadVar__1_1 = (MR_Integer) 0;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              *gml__HeadVar__1_1 = (MR_Integer) 2;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
      }
  }
#line 146 "gml.m"
}

#line 146 "gml.m"
bool MR_CALL gml____Unify____lexer_error_0_0(
#line 146 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 146 "gml.m"
  MR_Word gml__HeadVar__2_2)
#line 146 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Integer gml__V_3_3 = ((MR_Integer) (MR_hl_field(MR_mktag(0), gml__HeadVar__1_1, (MR_Integer) 0)));
    MR_String gml__V_4_4 = ((MR_String) (MR_hl_field(MR_mktag(0), gml__HeadVar__1_1, (MR_Integer) 1)));
    MR_Integer gml__V_5_5 = ((MR_Integer) (MR_hl_field(MR_mktag(0), gml__HeadVar__2_2, (MR_Integer) 0)));
    MR_String gml__V_6_6 = ((MR_String) (MR_hl_field(MR_mktag(0), gml__HeadVar__2_2, (MR_Integer) 1)));

    gml__succeeded = (gml__V_3_3 == gml__V_5_5);
    if (gml__succeeded)
      gml__succeeded = (strcmp(gml__V_4_4, gml__V_6_6) == 0);
    return gml__succeeded;
  }
#line 146 "gml.m"
}

#line 95 "gml.m"
void MR_CALL gml____Compare____extra_operator_0_0(
#line 95 "gml.m"
  MR_Word * gml__HeadVar__1_1,
#line 95 "gml.m"
  MR_Word gml__HeadVar__2_2,
#line 95 "gml.m"
  MR_Word gml__HeadVar__3_3)
#line 95 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Integer gml__V_4_4;
    MR_Integer gml__V_5_5;

#line 95 "gml.m"
    {
#line 95 "gml.m"
      gml____Index____extra_operator_0_0(gml__HeadVar__2_2, &gml__V_4_4);
    }
#line 95 "gml.m"
    {
#line 95 "gml.m"
      gml____Index____extra_operator_0_0(gml__HeadVar__3_3, &gml__V_5_5);
    }
#line 95 "gml.m"
    gml__succeeded = (gml__V_4_4 < gml__V_5_5);
#line 95 "gml.m"
    if (gml__succeeded)
#line 95 "gml.m"
      *gml__HeadVar__1_1 = (MR_Integer) 1;
#line 95 "gml.m"
    else
#line 95 "gml.m"
      {
#line 95 "gml.m"
        gml__succeeded = (gml__V_4_4 > gml__V_5_5);
#line 95 "gml.m"
        if (gml__succeeded)
#line 95 "gml.m"
          *gml__HeadVar__1_1 = (MR_Integer) 2;
#line 95 "gml.m"
        else
#line 95 "gml.m"
          {
#line 95 "gml.m"
            MR_Word gml__V_6_6;

#line 95 "gml.m"
#line 95 "gml.m"
            switch (MR_tag((MR_Word) gml__HeadVar__2_2)) {
#line 95 "gml.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 95 "gml.m"
              case (MR_Integer) 3:
#line 95 "gml.m"
#line 95 "gml.m"
                switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0)))) {
#line 95 "gml.m"
                  default: /*NOTREACHED*/ MR_assert(0);
#line 95 "gml.m"
                  case (MR_Integer) 0:
                    {
                      MR_Word gml__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word gml__V_12_12;

#line 95 "gml.m"
                      gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 0));
#line 95 "gml.m"
                      if (((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 95 "gml.m"
                        gml__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 1)));
                      if (gml__succeeded)
                        {
#line 95 "gml.m"
                          {
#line 95 "gml.m"
                            eval____Compare____surface_properties_0_0(&gml__V_6_6, gml__V_11_11, gml__V_12_12);
                          }
#line 95 "gml.m"
                          gml__succeeded = TRUE;
                        }
                    }
#line 95 "gml.m"
                    break;
#line 95 "gml.m"
                  case (MR_Integer) 1:
                    {
                      MR_Word gml__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word gml__V_14_14;

#line 95 "gml.m"
                      gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 1));
#line 95 "gml.m"
                      if (((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 95 "gml.m"
                        gml__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 1)));
                      if (gml__succeeded)
                        {
#line 95 "gml.m"
                          {
#line 95 "gml.m"
                            eval____Compare____surface_properties_0_0(&gml__V_6_6, gml__V_13_13, gml__V_14_14);
                          }
#line 95 "gml.m"
                          gml__succeeded = TRUE;
                        }
                    }
#line 95 "gml.m"
                    break;
#line 95 "gml.m"
                  case (MR_Integer) 2:
                    {
                      MR_Word gml__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word gml__V_16_16;

#line 95 "gml.m"
                      gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 2));
#line 95 "gml.m"
                      if (((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 2)))
#line 95 "gml.m"
                        gml__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 1)));
                      if (gml__succeeded)
                        {
#line 95 "gml.m"
                          {
#line 95 "gml.m"
                            eval____Compare____surface_properties_0_0(&gml__V_6_6, gml__V_15_15, gml__V_16_16);
                          }
#line 95 "gml.m"
                          gml__succeeded = TRUE;
                        }
                    }
#line 95 "gml.m"
                    break;
#line 95 "gml.m"
                  case (MR_Integer) 3:
                    {
                      MR_Word gml__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word gml__V_18_18;

#line 95 "gml.m"
                      gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 3));
#line 95 "gml.m"
                      if (((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 95 "gml.m"
                        gml__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 1)));
                      if (gml__succeeded)
                        {
#line 95 "gml.m"
                          {
#line 95 "gml.m"
                            eval____Compare____surface_properties_0_0(&gml__V_6_6, gml__V_17_17, gml__V_18_18);
                          }
#line 95 "gml.m"
                          gml__succeeded = TRUE;
                        }
                    }
#line 95 "gml.m"
                    break;
#line 95 "gml.m"
                  case (MR_Integer) 4:
                    {
                      MR_Word gml__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word gml__V_20_20;

#line 95 "gml.m"
                      gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 4));
#line 95 "gml.m"
                      if (((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 95 "gml.m"
                        gml__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 1)));
                      if (gml__succeeded)
                        {
#line 95 "gml.m"
                          {
#line 95 "gml.m"
                            vector____Compare____vector_0_0(&gml__V_6_6, gml__V_19_19, gml__V_20_20);
                          }
#line 95 "gml.m"
                          gml__succeeded = TRUE;
                        }
                    }
#line 95 "gml.m"
                    break;
#line 95 "gml.m"
                  case (MR_Integer) 5:
                    {
                      MR_Word gml__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word gml__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 2)));
                      MR_Word gml__V_23_23;
                      MR_Word gml__V_24_24;
#line 95 "gml.m"
                      MR_Word gml__V_25_25;

#line 95 "gml.m"
                      gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 5));
#line 95 "gml.m"
                      if (((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 5)))
#line 95 "gml.m"
                        {
#line 95 "gml.m"
                          gml__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 1)));
#line 95 "gml.m"
                          gml__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 2)));
#line 95 "gml.m"
                        }
                      if (gml__succeeded)
                        {
#line 95 "gml.m"
                          {
#line 95 "gml.m"
                            eval____Compare____value_0_0(&gml__V_25_25, gml__V_21_21, gml__V_23_23);
                          }
#line 95 "gml.m"
                          gml__succeeded = (gml__V_25_25 == (MR_Integer) 0);
#line 95 "gml.m"
                          gml__succeeded = !(gml__succeeded);
#line 95 "gml.m"
                          if (gml__succeeded)
#line 95 "gml.m"
                            gml__V_6_6 = gml__V_25_25;
#line 95 "gml.m"
                          else
#line 95 "gml.m"
                            {
#line 95 "gml.m"
                              eval____Compare____value_0_0(&gml__V_6_6, gml__V_22_22, gml__V_24_24);
                            }
#line 95 "gml.m"
                          gml__succeeded = TRUE;
                        }
                    }
#line 95 "gml.m"
                    break;
#line 95 "gml.m"
                  case (MR_Integer) 6:
                    {
#line 95 "gml.m"
                      MR_Word gml__V_27_27;

#line 95 "gml.m"
                      gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 6));
#line 95 "gml.m"
                      if (((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 6)))
#line 95 "gml.m"
                        gml__V_27_27 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 1)));
                      if (gml__succeeded)
                        {
#line 95 "gml.m"
                          {
#line 95 "gml.m"
                            gml__builtin_compare_pred__ua0_3_p_in__private_builtin_0(&gml__V_6_6);
                          }
#line 95 "gml.m"
                          gml__succeeded = TRUE;
                        }
                    }
#line 95 "gml.m"
                    break;
#line 95 "gml.m"
                }
#line 95 "gml.m"
                break;
#line 95 "gml.m"
              case (MR_Integer) 0:
                {
#line 95 "gml.m"
                  gml__succeeded = (gml__HeadVar__3_3 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
                  if (gml__succeeded)
                    {
#line 95 "gml.m"
                      gml__V_6_6 = (MR_Integer) 0;
#line 95 "gml.m"
                      gml__succeeded = TRUE;
                    }
                }
#line 95 "gml.m"
                break;
#line 95 "gml.m"
              case (MR_Integer) 1:
                {
                  MR_Integer gml__V_7_7 = ((MR_Integer) (MR_hl_field(MR_mktag(1), gml__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Integer gml__V_8_8;

#line 95 "gml.m"
                  gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 95 "gml.m"
                  if ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 95 "gml.m"
                    gml__V_8_8 = ((MR_Integer) (MR_hl_field(MR_mktag(1), gml__HeadVar__3_3, (MR_Integer) 0)));
                  if (gml__succeeded)
                    {
#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      gml__succeeded = (gml__V_7_7 < gml__V_8_8);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (gml__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        gml__V_6_6 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          gml__succeeded = (gml__V_7_7 == gml__V_8_8);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (gml__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            gml__V_6_6 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            gml__V_6_6 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      gml__succeeded = TRUE;
                    }
                }
#line 95 "gml.m"
                break;
#line 95 "gml.m"
              case (MR_Integer) 2:
                {
                  MR_Word gml__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(2), gml__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Word gml__V_10_10;

#line 95 "gml.m"
                  gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 2));
#line 95 "gml.m"
                  if ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 2)))
#line 95 "gml.m"
                    gml__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(2), gml__HeadVar__3_3, (MR_Integer) 0)));
                  if (gml__succeeded)
                    {
#line 95 "gml.m"
                      {
#line 95 "gml.m"
                        eval____Compare____surface_properties_0_0(&gml__V_6_6, gml__V_9_9, gml__V_10_10);
                      }
#line 95 "gml.m"
                      gml__succeeded = TRUE;
                    }
                }
#line 95 "gml.m"
                break;
#line 95 "gml.m"
            }
#line 95 "gml.m"
            if (gml__succeeded)
#line 95 "gml.m"
              *gml__HeadVar__1_1 = gml__V_6_6;
#line 95 "gml.m"
            else
#line 95 "gml.m"
              {
#line 95 "gml.m"
                mercury__private_builtin__compare_error_0_p_0();
#line 95 "gml.m"
                return;
              }
#line 95 "gml.m"
          }
#line 95 "gml.m"
      }
  }
#line 95 "gml.m"
}

#line 95 "gml.m"
void MR_CALL gml____Index____extra_operator_0_0(
#line 95 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 95 "gml.m"
  MR_Integer * gml__HeadVar__2_2)
#line 95 "gml.m"
{
#line 95 "gml.m"
  {
#line 95 "gml.m"
    bool gml__succeeded;

#line 95 "gml.m"
#line 95 "gml.m"
    switch (MR_tag((MR_Word) gml__HeadVar__1_1)) {
#line 95 "gml.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 95 "gml.m"
      case (MR_Integer) 3:
#line 95 "gml.m"
#line 95 "gml.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 0)))) {
#line 95 "gml.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 95 "gml.m"
          case (MR_Integer) 0:
#line 95 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 3;
#line 95 "gml.m"
            break;
#line 95 "gml.m"
          case (MR_Integer) 1:
#line 95 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 4;
#line 95 "gml.m"
            break;
#line 95 "gml.m"
          case (MR_Integer) 2:
#line 95 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 5;
#line 95 "gml.m"
            break;
#line 95 "gml.m"
          case (MR_Integer) 3:
#line 95 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 6;
#line 95 "gml.m"
            break;
#line 95 "gml.m"
          case (MR_Integer) 4:
#line 95 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 7;
#line 95 "gml.m"
            break;
#line 95 "gml.m"
          case (MR_Integer) 5:
#line 95 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 8;
#line 95 "gml.m"
            break;
#line 95 "gml.m"
          case (MR_Integer) 6:
#line 95 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 9;
#line 95 "gml.m"
            break;
#line 95 "gml.m"
        }
#line 95 "gml.m"
        break;
#line 95 "gml.m"
      case (MR_Integer) 0:
#line 95 "gml.m"
        *gml__HeadVar__2_2 = (MR_Integer) 1;
#line 95 "gml.m"
        break;
#line 95 "gml.m"
      case (MR_Integer) 1:
#line 95 "gml.m"
        *gml__HeadVar__2_2 = (MR_Integer) 0;
#line 95 "gml.m"
        break;
#line 95 "gml.m"
      case (MR_Integer) 2:
#line 95 "gml.m"
        *gml__HeadVar__2_2 = (MR_Integer) 2;
#line 95 "gml.m"
        break;
#line 95 "gml.m"
    }
#line 95 "gml.m"
  }
#line 95 "gml.m"
}

#line 95 "gml.m"
bool MR_CALL gml____Unify____extra_operator_0_0(
#line 95 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 95 "gml.m"
  MR_Word gml__HeadVar__2_2)
#line 95 "gml.m"
{
#line 95 "gml.m"
  {
#line 95 "gml.m"
    bool gml__succeeded;

#line 95 "gml.m"
#line 95 "gml.m"
    switch (MR_tag((MR_Word) gml__HeadVar__1_1)) {
#line 95 "gml.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 95 "gml.m"
      case (MR_Integer) 3:
#line 95 "gml.m"
#line 95 "gml.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 0)))) {
#line 95 "gml.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 95 "gml.m"
          case (MR_Integer) 0:
            {
              MR_Word gml__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word gml__V_8_8;

#line 95 "gml.m"
              gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 0));
#line 95 "gml.m"
              if (((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 95 "gml.m"
                gml__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
              if (gml__succeeded)
                {
                  return gml__succeeded = eval____Unify____surface_properties_0_0(gml__V_7_7, gml__V_8_8);
                }
            }
#line 95 "gml.m"
            break;
#line 95 "gml.m"
          case (MR_Integer) 1:
            {
              MR_Word gml__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word gml__V_10_10;

#line 95 "gml.m"
              gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 1));
#line 95 "gml.m"
              if (((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 95 "gml.m"
                gml__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
              if (gml__succeeded)
                {
                  return gml__succeeded = eval____Unify____surface_properties_0_0(gml__V_9_9, gml__V_10_10);
                }
            }
#line 95 "gml.m"
            break;
#line 95 "gml.m"
          case (MR_Integer) 2:
            {
              MR_Word gml__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word gml__V_12_12;

#line 95 "gml.m"
              gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 2));
#line 95 "gml.m"
              if (((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 2)))
#line 95 "gml.m"
                gml__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
              if (gml__succeeded)
                {
                  return gml__succeeded = eval____Unify____surface_properties_0_0(gml__V_11_11, gml__V_12_12);
                }
            }
#line 95 "gml.m"
            break;
#line 95 "gml.m"
          case (MR_Integer) 3:
            {
              MR_Word gml__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word gml__V_14_14;

#line 95 "gml.m"
              gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 3));
#line 95 "gml.m"
              if (((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 95 "gml.m"
                gml__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
              if (gml__succeeded)
                {
                  return gml__succeeded = eval____Unify____surface_properties_0_0(gml__V_13_13, gml__V_14_14);
                }
            }
#line 95 "gml.m"
            break;
#line 95 "gml.m"
          case (MR_Integer) 4:
            {
              MR_Word gml__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word gml__V_16_16;

#line 95 "gml.m"
              gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 4));
#line 95 "gml.m"
              if (((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 95 "gml.m"
                gml__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
              if (gml__succeeded)
                {
                  return gml__succeeded = vector____Unify____vector_0_0(gml__V_15_15, gml__V_16_16);
                }
            }
#line 95 "gml.m"
            break;
#line 95 "gml.m"
          case (MR_Integer) 5:
            {
              MR_Word gml__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word gml__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 2)));
              MR_Word gml__V_19_19;
              MR_Word gml__V_20_20;

#line 95 "gml.m"
              gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 5));
#line 95 "gml.m"
              if (((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 5)))
#line 95 "gml.m"
                {
#line 95 "gml.m"
                  gml__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
#line 95 "gml.m"
                  gml__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 2)));
#line 95 "gml.m"
                }
              if (gml__succeeded)
                {
                  {
                    gml__succeeded = eval____Unify____value_0_0(gml__V_17_17, gml__V_19_19);
                  }
                  if (gml__succeeded)
                    {
                      return gml__succeeded = eval____Unify____value_0_0(gml__V_18_18, gml__V_20_20);
                    }
                }
            }
#line 95 "gml.m"
            break;
#line 95 "gml.m"
          case (MR_Integer) 6:
            {
#line 95 "gml.m"
              MR_Word gml__V_22_22;

#line 95 "gml.m"
              gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 6));
#line 95 "gml.m"
              if (((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 6)))
#line 95 "gml.m"
                gml__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
              if (gml__succeeded)
                {
                  return gml__succeeded = gml__builtin_unify_pred__ua0_2_p_in__private_builtin_0();
                }
            }
#line 95 "gml.m"
            break;
#line 95 "gml.m"
        }
#line 95 "gml.m"
        break;
#line 95 "gml.m"
      case (MR_Integer) 0:
#line 95 "gml.m"
        gml__succeeded = (gml__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 95 "gml.m"
        break;
#line 95 "gml.m"
      case (MR_Integer) 1:
        {
          MR_Integer gml__V_3_3 = ((MR_Integer) (MR_hl_field(MR_mktag(1), gml__HeadVar__1_1, (MR_Integer) 0)));
          MR_Integer gml__V_4_4;

#line 95 "gml.m"
          gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 95 "gml.m"
          if ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 95 "gml.m"
            gml__V_4_4 = ((MR_Integer) (MR_hl_field(MR_mktag(1), gml__HeadVar__2_2, (MR_Integer) 0)));
          if (gml__succeeded)
            gml__succeeded = (gml__V_3_3 == gml__V_4_4);
        }
#line 95 "gml.m"
        break;
#line 95 "gml.m"
      case (MR_Integer) 2:
        {
          MR_Word gml__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(2), gml__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word gml__V_6_6;

#line 95 "gml.m"
          gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 2));
#line 95 "gml.m"
          if ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 2)))
#line 95 "gml.m"
            gml__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(2), gml__HeadVar__2_2, (MR_Integer) 0)));
          if (gml__succeeded)
            {
              return gml__succeeded = eval____Unify____surface_properties_0_0(gml__V_5_5, gml__V_6_6);
            }
        }
#line 95 "gml.m"
        break;
#line 95 "gml.m"
    }
#line 95 "gml.m"
    return gml__succeeded;
#line 95 "gml.m"
  }
#line 95 "gml.m"
}

#line 38 "gml.m"
void MR_CALL gml____Compare____operator_0_0(
#line 38 "gml.m"
  MR_Word * gml__HeadVar__1_1,
#line 38 "gml.m"
  MR_Word gml__HeadVar__2_2,
#line 38 "gml.m"
  MR_Word gml__HeadVar__3_3)
#line 38 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Integer gml__V_4_4 = (MR_Integer) gml__HeadVar__2_2;
    MR_Integer gml__V_5_5 = (MR_Integer) gml__HeadVar__3_3;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    gml__succeeded = (gml__V_4_4 < gml__V_5_5);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (gml__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *gml__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        gml__succeeded = (gml__V_4_4 == gml__V_5_5);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (gml__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *gml__HeadVar__1_1 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *gml__HeadVar__1_1 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
  }
#line 38 "gml.m"
}

#line 38 "gml.m"
bool MR_CALL gml____Unify____operator_0_0(
#line 38 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 38 "gml.m"
  MR_Word gml__HeadVar__2_2)
#line 38 "gml.m"
{
#line 38 "gml.m"
  {
#line 38 "gml.m"
    bool gml__succeeded = (gml__HeadVar__1_1 == gml__HeadVar__2_2);

#line 38 "gml.m"
    return gml__succeeded;
#line 38 "gml.m"
  }
#line 38 "gml.m"
}

#line 34 "gml.m"
void MR_CALL gml____Compare____number_0_0(
#line 34 "gml.m"
  MR_Word * gml__HeadVar__1_1,
#line 34 "gml.m"
  MR_Word gml__HeadVar__2_2,
#line 34 "gml.m"
  MR_Word gml__HeadVar__3_3)
#line 34 "gml.m"
{
#line 34 "gml.m"
  {
#line 34 "gml.m"
    bool gml__succeeded;
#line 34 "gml.m"
    MR_Integer gml__V_14_14;
#line 34 "gml.m"
    MR_Float gml__V_15_15;

#line 34 "gml.m"
    if ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
      {
#line 34 "gml.m"
        MR_Integer gml__V_5_5;

#line 34 "gml.m"
        gml__V_14_14 = ((MR_Integer) (MR_hl_field(MR_mktag(0), gml__HeadVar__2_2, (MR_Integer) 0)));
#line 34 "gml.m"
        if ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
          {
#line 34 "gml.m"
            gml__V_5_5 = ((MR_Integer) (MR_hl_field(MR_mktag(0), gml__HeadVar__3_3, (MR_Integer) 0)));
#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            gml__succeeded = (gml__V_14_14 < gml__V_5_5);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (gml__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              *gml__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                gml__succeeded = (gml__V_14_14 == gml__V_5_5);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (gml__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *gml__HeadVar__1_1 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *gml__HeadVar__1_1 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              }
          }
#line 34 "gml.m"
        else
#line 34 "gml.m"
          *gml__HeadVar__1_1 = (MR_Integer) 1;
      }
#line 34 "gml.m"
    else
#line 34 "gml.m"
      {
#line 34 "gml.m"
        MR_Float gml__V_7_7;

#line 34 "gml.m"
        gml__V_15_15 = MR_unbox_float((MR_hl_field(MR_mktag(1), gml__HeadVar__2_2, (MR_Integer) 0)));
#line 34 "gml.m"
        if ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
#line 34 "gml.m"
          *gml__HeadVar__1_1 = (MR_Integer) 2;
#line 34 "gml.m"
        else
#line 34 "gml.m"
          {
#line 34 "gml.m"
            gml__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(1), gml__HeadVar__3_3, (MR_Integer) 0)));
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            gml__succeeded = (gml__V_15_15 < gml__V_7_7);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (gml__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              *gml__HeadVar__1_1 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                gml__succeeded = (gml__V_15_15 > gml__V_7_7);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (gml__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *gml__HeadVar__1_1 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *gml__HeadVar__1_1 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              }
#line 34 "gml.m"
          }
#line 34 "gml.m"
      }
#line 34 "gml.m"
  }
#line 34 "gml.m"
}

#line 34 "gml.m"
bool MR_CALL gml____Unify____number_0_0(
#line 34 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 34 "gml.m"
  MR_Word gml__HeadVar__2_2)
#line 34 "gml.m"
{
#line 34 "gml.m"
  {
#line 34 "gml.m"
    bool gml__succeeded;
#line 34 "gml.m"
    MR_Integer gml__V_3_3;
#line 34 "gml.m"
    MR_Integer gml__V_4_4;
#line 34 "gml.m"
    MR_Float gml__V_5_5;
#line 34 "gml.m"
    MR_Float gml__V_6_6;

#line 34 "gml.m"
    if ((MR_tag((MR_Word) gml__HeadVar__1_1) == MR_mktag((MR_Integer) 0)))
      {
#line 34 "gml.m"
        gml__V_3_3 = ((MR_Integer) (MR_hl_field(MR_mktag(0), gml__HeadVar__1_1, (MR_Integer) 0)));
#line 34 "gml.m"
        gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
#line 34 "gml.m"
        if ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 34 "gml.m"
          gml__V_4_4 = ((MR_Integer) (MR_hl_field(MR_mktag(0), gml__HeadVar__2_2, (MR_Integer) 0)));
        if (gml__succeeded)
          gml__succeeded = (gml__V_3_3 == gml__V_4_4);
      }
#line 34 "gml.m"
    else
#line 34 "gml.m"
      {
#line 34 "gml.m"
        gml__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(1), gml__HeadVar__1_1, (MR_Integer) 0)));
#line 34 "gml.m"
        gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 34 "gml.m"
        if ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 34 "gml.m"
          gml__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(1), gml__HeadVar__2_2, (MR_Integer) 0)));
        if (gml__succeeded)
          gml__succeeded = (gml__V_5_5 == gml__V_6_6);
#line 34 "gml.m"
      }
#line 34 "gml.m"
    return gml__succeeded;
#line 34 "gml.m"
  }
#line 34 "gml.m"
}

#line 21 "gml.m"
void MR_CALL gml____Compare____token_0_0(
#line 21 "gml.m"
  MR_Word * gml__HeadVar__1_1,
#line 21 "gml.m"
  MR_Word gml__HeadVar__2_2,
#line 21 "gml.m"
  MR_Word gml__HeadVar__3_3)
#line 21 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Integer gml__V_4_4;
    MR_Integer gml__V_5_5;

#line 21 "gml.m"
    {
#line 21 "gml.m"
      gml____Index____token_0_0(gml__HeadVar__2_2, &gml__V_4_4);
    }
#line 21 "gml.m"
    {
#line 21 "gml.m"
      gml____Index____token_0_0(gml__HeadVar__3_3, &gml__V_5_5);
    }
#line 21 "gml.m"
    gml__succeeded = (gml__V_4_4 < gml__V_5_5);
#line 21 "gml.m"
    if (gml__succeeded)
#line 21 "gml.m"
      *gml__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "gml.m"
    else
#line 21 "gml.m"
      {
#line 21 "gml.m"
        gml__succeeded = (gml__V_4_4 > gml__V_5_5);
#line 21 "gml.m"
        if (gml__succeeded)
#line 21 "gml.m"
          *gml__HeadVar__1_1 = (MR_Integer) 2;
#line 21 "gml.m"
        else
#line 21 "gml.m"
          {
#line 21 "gml.m"
            MR_Word gml__V_6_6;

#line 21 "gml.m"
#line 21 "gml.m"
            switch (MR_tag((MR_Word) gml__HeadVar__2_2)) {
#line 21 "gml.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 21 "gml.m"
              case (MR_Integer) 3:
#line 21 "gml.m"
#line 21 "gml.m"
                switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0)))) {
#line 21 "gml.m"
                  default: /*NOTREACHED*/ MR_assert(0);
#line 21 "gml.m"
                  case (MR_Integer) 0:
                    {
                      MR_Word gml__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word gml__V_14_14;
                      MR_Integer gml__V_28_28;
                      MR_Integer gml__V_29_29;

#line 21 "gml.m"
                      gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 0));
#line 21 "gml.m"
                      if (((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 21 "gml.m"
                        gml__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 1)));
                      if (gml__succeeded)
                        {
                          gml__V_28_28 = (MR_Integer) gml__V_13_13;
                          gml__V_29_29 = (MR_Integer) gml__V_14_14;
#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          gml__succeeded = (gml__V_28_28 < gml__V_29_29);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (gml__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            gml__V_6_6 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              gml__succeeded = (gml__V_28_28 == gml__V_29_29);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              if (gml__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                gml__V_6_6 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                gml__V_6_6 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          gml__succeeded = TRUE;
                        }
                    }
#line 21 "gml.m"
                    break;
#line 21 "gml.m"
                  case (MR_Integer) 1:
                    {
                      MR_Word gml__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word gml__V_16_16;

#line 21 "gml.m"
                      gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 1));
#line 21 "gml.m"
                      if (((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 21 "gml.m"
                        gml__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 1)));
                      if (gml__succeeded)
                        {
#line 21 "gml.m"
                          {
#line 21 "gml.m"
                            gml____Compare____number_0_0(&gml__V_6_6, gml__V_15_15, gml__V_16_16);
                          }
#line 21 "gml.m"
                          gml__succeeded = TRUE;
                        }
                    }
#line 21 "gml.m"
                    break;
#line 21 "gml.m"
                  case (MR_Integer) 2:
                    {
                      MR_String gml__V_17_17 = ((MR_String) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
                      MR_String gml__V_18_18;
                      MR_Integer gml__Res_7_57;
                      MR_Integer gml__V_8_58;

#line 21 "gml.m"
                      gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 2));
#line 21 "gml.m"
                      if (((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 2)))
#line 21 "gml.m"
                        gml__V_18_18 = ((MR_String) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 1)));
                      if (gml__succeeded)
                        {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL gml____Compare____token_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__V_17_17
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__V_18_18
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__Res_7_57
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          gml__V_8_58 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          gml__succeeded = (gml__Res_7_57 < gml__V_8_58);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (gml__succeeded)
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            gml__V_6_6 = (MR_Integer) 1;
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              gml__succeeded = (gml__Res_7_57 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              if (gml__succeeded)
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                gml__V_6_6 = (MR_Integer) 0;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              else
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                gml__V_6_6 = (MR_Integer) 2;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            }
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          gml__succeeded = TRUE;
                        }
                    }
#line 21 "gml.m"
                    break;
#line 21 "gml.m"
                  case (MR_Integer) 3:
                    {
                      MR_Word gml__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word gml__V_20_20;

#line 21 "gml.m"
                      gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 3));
#line 21 "gml.m"
                      if (((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 21 "gml.m"
                        gml__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__3_3, (MR_Integer) 1)));
                      if (gml__succeeded)
                        {
#line 21 "gml.m"
                          {
#line 21 "gml.m"
                            gml____Compare____extra_operator_0_0(&gml__V_6_6, gml__V_19_19, gml__V_20_20);
                          }
#line 21 "gml.m"
                          gml__succeeded = TRUE;
                        }
                    }
#line 21 "gml.m"
                    break;
#line 21 "gml.m"
                }
#line 21 "gml.m"
                break;
#line 21 "gml.m"
              case (MR_Integer) 0:
                {
                  MR_Word gml__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), gml__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Word gml__V_8_8;
                  MR_Integer gml__V_30_30;
                  MR_Integer gml__V_31_31;

#line 21 "gml.m"
                  gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 0));
#line 21 "gml.m"
                  if ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
#line 21 "gml.m"
                    gml__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), gml__HeadVar__3_3, (MR_Integer) 0)));
                  if (gml__succeeded)
                    {
                      gml__V_30_30 = (MR_Integer) gml__V_7_7;
                      gml__V_31_31 = (MR_Integer) gml__V_8_8;
#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      gml__succeeded = (gml__V_30_30 < gml__V_31_31);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (gml__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        gml__V_6_6 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          gml__succeeded = (gml__V_30_30 == gml__V_31_31);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (gml__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            gml__V_6_6 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            gml__V_6_6 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      gml__succeeded = TRUE;
                    }
                }
#line 21 "gml.m"
                break;
#line 21 "gml.m"
              case (MR_Integer) 1:
                {
                  MR_String gml__V_9_9 = ((MR_String) (MR_hl_field(MR_mktag(1), gml__HeadVar__2_2, (MR_Integer) 0)));
                  MR_String gml__V_10_10;
                  MR_Integer gml__Res_7_46;
                  MR_Integer gml__V_8_47;

#line 21 "gml.m"
                  gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 21 "gml.m"
                  if ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 21 "gml.m"
                    gml__V_10_10 = ((MR_String) (MR_hl_field(MR_mktag(1), gml__HeadVar__3_3, (MR_Integer) 0)));
                  if (gml__succeeded)
                    {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL gml____Compare____token_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__V_9_9
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__V_10_10
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__Res_7_46
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      gml__V_8_47 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      gml__succeeded = (gml__Res_7_46 < gml__V_8_47);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (gml__succeeded)
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        gml__V_6_6 = (MR_Integer) 1;
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          gml__succeeded = (gml__Res_7_46 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (gml__succeeded)
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            gml__V_6_6 = (MR_Integer) 0;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            gml__V_6_6 = (MR_Integer) 2;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      gml__succeeded = TRUE;
                    }
                }
#line 21 "gml.m"
                break;
#line 21 "gml.m"
              case (MR_Integer) 2:
                {
                  MR_String gml__V_11_11 = ((MR_String) (MR_hl_field(MR_mktag(2), gml__HeadVar__2_2, (MR_Integer) 0)));
                  MR_String gml__V_12_12;
                  MR_Integer gml__Res_7_35;
                  MR_Integer gml__V_8_36;

#line 21 "gml.m"
                  gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 2));
#line 21 "gml.m"
                  if ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 2)))
#line 21 "gml.m"
                    gml__V_12_12 = ((MR_String) (MR_hl_field(MR_mktag(2), gml__HeadVar__3_3, (MR_Integer) 0)));
                  if (gml__succeeded)
                    {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL gml____Compare____token_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__V_11_11
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__V_12_12
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
gml__Res_7_35
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      gml__V_8_36 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      gml__succeeded = (gml__Res_7_35 < gml__V_8_36);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (gml__succeeded)
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        gml__V_6_6 = (MR_Integer) 1;
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          gml__succeeded = (gml__Res_7_35 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (gml__succeeded)
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            gml__V_6_6 = (MR_Integer) 0;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            gml__V_6_6 = (MR_Integer) 2;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      gml__succeeded = TRUE;
                    }
                }
#line 21 "gml.m"
                break;
#line 21 "gml.m"
            }
#line 21 "gml.m"
            if (gml__succeeded)
#line 21 "gml.m"
              *gml__HeadVar__1_1 = gml__V_6_6;
#line 21 "gml.m"
            else
#line 21 "gml.m"
              {
#line 21 "gml.m"
                mercury__private_builtin__compare_error_0_p_0();
#line 21 "gml.m"
                return;
              }
#line 21 "gml.m"
          }
#line 21 "gml.m"
      }
  }
#line 21 "gml.m"
}

#line 21 "gml.m"
void MR_CALL gml____Index____token_0_0(
#line 21 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 21 "gml.m"
  MR_Integer * gml__HeadVar__2_2)
#line 21 "gml.m"
{
#line 21 "gml.m"
  {
#line 21 "gml.m"
    bool gml__succeeded;

#line 21 "gml.m"
#line 21 "gml.m"
    switch (MR_tag((MR_Word) gml__HeadVar__1_1)) {
#line 21 "gml.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 21 "gml.m"
      case (MR_Integer) 3:
#line 21 "gml.m"
#line 21 "gml.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 0)))) {
#line 21 "gml.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 21 "gml.m"
          case (MR_Integer) 0:
#line 21 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 3;
#line 21 "gml.m"
            break;
#line 21 "gml.m"
          case (MR_Integer) 1:
#line 21 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 4;
#line 21 "gml.m"
            break;
#line 21 "gml.m"
          case (MR_Integer) 2:
#line 21 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 5;
#line 21 "gml.m"
            break;
#line 21 "gml.m"
          case (MR_Integer) 3:
#line 21 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 6;
#line 21 "gml.m"
            break;
#line 21 "gml.m"
        }
#line 21 "gml.m"
        break;
#line 21 "gml.m"
      case (MR_Integer) 0:
#line 21 "gml.m"
        *gml__HeadVar__2_2 = (MR_Integer) 0;
#line 21 "gml.m"
        break;
#line 21 "gml.m"
      case (MR_Integer) 1:
#line 21 "gml.m"
        *gml__HeadVar__2_2 = (MR_Integer) 1;
#line 21 "gml.m"
        break;
#line 21 "gml.m"
      case (MR_Integer) 2:
#line 21 "gml.m"
        *gml__HeadVar__2_2 = (MR_Integer) 2;
#line 21 "gml.m"
        break;
#line 21 "gml.m"
    }
#line 21 "gml.m"
  }
#line 21 "gml.m"
}

#line 21 "gml.m"
bool MR_CALL gml____Unify____token_0_0(
#line 21 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 21 "gml.m"
  MR_Word gml__HeadVar__2_2)
#line 21 "gml.m"
{
#line 21 "gml.m"
  {
#line 21 "gml.m"
    bool gml__succeeded;
#line 21 "gml.m"
    MR_Word gml__V_3_3;
#line 21 "gml.m"
    MR_Word gml__V_4_4;
#line 21 "gml.m"
    MR_String gml__V_5_5;
#line 21 "gml.m"
    MR_String gml__V_6_6;
#line 21 "gml.m"
    MR_String gml__V_7_7;
#line 21 "gml.m"
    MR_String gml__V_8_8;
#line 21 "gml.m"
    MR_Word gml__V_9_9;
#line 21 "gml.m"
    MR_Word gml__V_10_10;
#line 21 "gml.m"
    MR_Word gml__V_11_11;
#line 21 "gml.m"
    MR_Word gml__V_12_12;
#line 21 "gml.m"
    MR_String gml__V_13_13;
#line 21 "gml.m"
    MR_String gml__V_14_14;
#line 21 "gml.m"
    MR_Word gml__V_15_15;
#line 21 "gml.m"
    MR_Word gml__V_16_16;

#line 21 "gml.m"
#line 21 "gml.m"
    switch (MR_tag((MR_Word) gml__HeadVar__1_1)) {
#line 21 "gml.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 21 "gml.m"
      case (MR_Integer) 3:
#line 21 "gml.m"
#line 21 "gml.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 0)))) {
#line 21 "gml.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 21 "gml.m"
          case (MR_Integer) 0:
            {
#line 21 "gml.m"
              gml__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 1)));
#line 21 "gml.m"
              gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 0));
#line 21 "gml.m"
              if (((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 21 "gml.m"
                gml__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
              if (gml__succeeded)
                gml__succeeded = (gml__V_9_9 == gml__V_10_10);
            }
#line 21 "gml.m"
            break;
#line 21 "gml.m"
          case (MR_Integer) 1:
            {
#line 21 "gml.m"
              gml__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 1)));
#line 21 "gml.m"
              gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 1));
#line 21 "gml.m"
              if (((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 21 "gml.m"
                gml__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
              if (gml__succeeded)
#line 34 "gml.m"
                {
#line 34 "gml.m"
                  if ((MR_tag((MR_Word) gml__V_11_11) == MR_mktag((MR_Integer) 0)))
#line 34 "gml.m"
                    {
#line 34 "gml.m"
                      MR_Integer gml__V_17_17 = ((MR_Integer) (MR_hl_field(MR_mktag(0), gml__V_11_11, (MR_Integer) 0)));
#line 34 "gml.m"
                      MR_Integer gml__V_18_18;

#line 34 "gml.m"
                      gml__succeeded = (MR_tag((MR_Word) gml__V_12_12) == MR_mktag((MR_Integer) 0));
#line 34 "gml.m"
                      if ((MR_tag((MR_Word) gml__V_12_12) == MR_mktag((MR_Integer) 0)))
#line 34 "gml.m"
                        gml__V_18_18 = ((MR_Integer) (MR_hl_field(MR_mktag(0), gml__V_12_12, (MR_Integer) 0)));
#line 34 "gml.m"
                      if (gml__succeeded)
                        gml__succeeded = (gml__V_17_17 == gml__V_18_18);
#line 34 "gml.m"
                    }
#line 34 "gml.m"
                  else
#line 34 "gml.m"
                    {
#line 34 "gml.m"
                      MR_Float gml__V_19_19 = MR_unbox_float((MR_hl_field(MR_mktag(1), gml__V_11_11, (MR_Integer) 0)));
#line 34 "gml.m"
                      MR_Float gml__V_20_20;

#line 34 "gml.m"
                      gml__succeeded = (MR_tag((MR_Word) gml__V_12_12) == MR_mktag((MR_Integer) 1));
#line 34 "gml.m"
                      if ((MR_tag((MR_Word) gml__V_12_12) == MR_mktag((MR_Integer) 1)))
#line 34 "gml.m"
                        gml__V_20_20 = MR_unbox_float((MR_hl_field(MR_mktag(1), gml__V_12_12, (MR_Integer) 0)));
#line 34 "gml.m"
                      if (gml__succeeded)
                        gml__succeeded = (gml__V_19_19 == gml__V_20_20);
#line 34 "gml.m"
                    }
#line 34 "gml.m"
                }
            }
#line 21 "gml.m"
            break;
#line 21 "gml.m"
          case (MR_Integer) 2:
            {
#line 21 "gml.m"
              gml__V_13_13 = ((MR_String) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 1)));
#line 21 "gml.m"
              gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 2));
#line 21 "gml.m"
              if (((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 2)))
#line 21 "gml.m"
                gml__V_14_14 = ((MR_String) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
              if (gml__succeeded)
                gml__succeeded = (strcmp(gml__V_13_13, gml__V_14_14) == 0);
            }
#line 21 "gml.m"
            break;
#line 21 "gml.m"
          case (MR_Integer) 3:
            {
#line 21 "gml.m"
              gml__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__1_1, (MR_Integer) 1)));
#line 21 "gml.m"
              gml__succeeded = ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 3));
#line 21 "gml.m"
              if (((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 21 "gml.m"
                gml__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(3), gml__HeadVar__2_2, (MR_Integer) 1)));
              if (gml__succeeded)
                {
                  return gml__succeeded = gml____Unify____extra_operator_0_0(gml__V_15_15, gml__V_16_16);
                }
            }
#line 21 "gml.m"
            break;
#line 21 "gml.m"
        }
#line 21 "gml.m"
        break;
#line 21 "gml.m"
      case (MR_Integer) 0:
        {
#line 21 "gml.m"
          gml__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), gml__HeadVar__1_1, (MR_Integer) 0)));
#line 21 "gml.m"
          gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
#line 21 "gml.m"
          if ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 21 "gml.m"
            gml__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), gml__HeadVar__2_2, (MR_Integer) 0)));
          if (gml__succeeded)
            gml__succeeded = (gml__V_3_3 == gml__V_4_4);
        }
#line 21 "gml.m"
        break;
#line 21 "gml.m"
      case (MR_Integer) 1:
        {
#line 21 "gml.m"
          gml__V_5_5 = ((MR_String) (MR_hl_field(MR_mktag(1), gml__HeadVar__1_1, (MR_Integer) 0)));
#line 21 "gml.m"
          gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 21 "gml.m"
          if ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 21 "gml.m"
            gml__V_6_6 = ((MR_String) (MR_hl_field(MR_mktag(1), gml__HeadVar__2_2, (MR_Integer) 0)));
          if (gml__succeeded)
            gml__succeeded = (strcmp(gml__V_5_5, gml__V_6_6) == 0);
        }
#line 21 "gml.m"
        break;
#line 21 "gml.m"
      case (MR_Integer) 2:
        {
#line 21 "gml.m"
          gml__V_7_7 = ((MR_String) (MR_hl_field(MR_mktag(2), gml__HeadVar__1_1, (MR_Integer) 0)));
#line 21 "gml.m"
          gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 2));
#line 21 "gml.m"
          if ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 2)))
#line 21 "gml.m"
            gml__V_8_8 = ((MR_String) (MR_hl_field(MR_mktag(2), gml__HeadVar__2_2, (MR_Integer) 0)));
          if (gml__succeeded)
            gml__succeeded = (strcmp(gml__V_7_7, gml__V_8_8) == 0);
        }
#line 21 "gml.m"
        break;
#line 21 "gml.m"
    }
#line 21 "gml.m"
    return gml__succeeded;
#line 21 "gml.m"
  }
#line 21 "gml.m"
}

#line 14 "gml.m"
void MR_CALL gml____Compare____basic_token_0_0(
#line 14 "gml.m"
  MR_Word * gml__HeadVar__1_1,
#line 14 "gml.m"
  MR_Word gml__HeadVar__2_2,
#line 14 "gml.m"
  MR_Word gml__HeadVar__3_3)
#line 14 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Integer gml__V_4_4;
    MR_Integer gml__V_5_5;

#line 14 "gml.m"
#line 14 "gml.m"
    switch (MR_tag((MR_Word) gml__HeadVar__2_2)) {
#line 14 "gml.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 14 "gml.m"
      case (MR_Integer) 0:
#line 14 "gml.m"
#line 14 "gml.m"
        switch (MR_unmkbody(gml__HeadVar__2_2)) {
#line 14 "gml.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 14 "gml.m"
          case (MR_Integer) 0:
#line 14 "gml.m"
            gml__V_4_4 = (MR_Integer) 0;
#line 14 "gml.m"
            break;
#line 14 "gml.m"
          case (MR_Integer) 1:
#line 14 "gml.m"
            gml__V_4_4 = (MR_Integer) 1;
#line 14 "gml.m"
            break;
#line 14 "gml.m"
          case (MR_Integer) 2:
#line 14 "gml.m"
            gml__V_4_4 = (MR_Integer) 2;
#line 14 "gml.m"
            break;
#line 14 "gml.m"
          case (MR_Integer) 3:
#line 14 "gml.m"
            gml__V_4_4 = (MR_Integer) 3;
#line 14 "gml.m"
            break;
#line 14 "gml.m"
        }
#line 14 "gml.m"
        break;
#line 14 "gml.m"
      case (MR_Integer) 1:
#line 14 "gml.m"
        gml__V_4_4 = (MR_Integer) 4;
#line 14 "gml.m"
        break;
#line 14 "gml.m"
    }
#line 14 "gml.m"
#line 14 "gml.m"
    switch (MR_tag((MR_Word) gml__HeadVar__3_3)) {
#line 14 "gml.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 14 "gml.m"
      case (MR_Integer) 0:
#line 14 "gml.m"
#line 14 "gml.m"
        switch (MR_unmkbody(gml__HeadVar__3_3)) {
#line 14 "gml.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 14 "gml.m"
          case (MR_Integer) 0:
#line 14 "gml.m"
            gml__V_5_5 = (MR_Integer) 0;
#line 14 "gml.m"
            break;
#line 14 "gml.m"
          case (MR_Integer) 1:
#line 14 "gml.m"
            gml__V_5_5 = (MR_Integer) 1;
#line 14 "gml.m"
            break;
#line 14 "gml.m"
          case (MR_Integer) 2:
#line 14 "gml.m"
            gml__V_5_5 = (MR_Integer) 2;
#line 14 "gml.m"
            break;
#line 14 "gml.m"
          case (MR_Integer) 3:
#line 14 "gml.m"
            gml__V_5_5 = (MR_Integer) 3;
#line 14 "gml.m"
            break;
#line 14 "gml.m"
        }
#line 14 "gml.m"
        break;
#line 14 "gml.m"
      case (MR_Integer) 1:
#line 14 "gml.m"
        gml__V_5_5 = (MR_Integer) 4;
#line 14 "gml.m"
        break;
#line 14 "gml.m"
    }
#line 14 "gml.m"
    gml__succeeded = (gml__V_4_4 < gml__V_5_5);
#line 14 "gml.m"
    if (gml__succeeded)
#line 14 "gml.m"
      *gml__HeadVar__1_1 = (MR_Integer) 1;
#line 14 "gml.m"
    else
#line 14 "gml.m"
      {
#line 14 "gml.m"
        gml__succeeded = (gml__V_4_4 > gml__V_5_5);
#line 14 "gml.m"
        if (gml__succeeded)
#line 14 "gml.m"
          *gml__HeadVar__1_1 = (MR_Integer) 2;
#line 14 "gml.m"
        else
#line 14 "gml.m"
          {
#line 14 "gml.m"
            MR_Word gml__V_6_6;

#line 14 "gml.m"
#line 14 "gml.m"
            switch (MR_tag((MR_Word) gml__HeadVar__2_2)) {
#line 14 "gml.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 14 "gml.m"
              case (MR_Integer) 0:
#line 14 "gml.m"
#line 14 "gml.m"
                switch (MR_unmkbody(gml__HeadVar__2_2)) {
#line 14 "gml.m"
                  default: /*NOTREACHED*/ MR_assert(0);
#line 14 "gml.m"
                  case (MR_Integer) 0:
                    {
#line 14 "gml.m"
                      gml__succeeded = (gml__HeadVar__3_3 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
                      if (gml__succeeded)
                        {
#line 14 "gml.m"
                          gml__V_6_6 = (MR_Integer) 0;
#line 14 "gml.m"
                          gml__succeeded = TRUE;
                        }
                    }
#line 14 "gml.m"
                    break;
#line 14 "gml.m"
                  case (MR_Integer) 1:
                    {
#line 14 "gml.m"
                      gml__succeeded = (gml__HeadVar__3_3 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 1)));
                      if (gml__succeeded)
                        {
#line 14 "gml.m"
                          gml__V_6_6 = (MR_Integer) 0;
#line 14 "gml.m"
                          gml__succeeded = TRUE;
                        }
                    }
#line 14 "gml.m"
                    break;
#line 14 "gml.m"
                  case (MR_Integer) 2:
                    {
#line 14 "gml.m"
                      gml__succeeded = (gml__HeadVar__3_3 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 2)));
                      if (gml__succeeded)
                        {
#line 14 "gml.m"
                          gml__V_6_6 = (MR_Integer) 0;
#line 14 "gml.m"
                          gml__succeeded = TRUE;
                        }
                    }
#line 14 "gml.m"
                    break;
#line 14 "gml.m"
                  case (MR_Integer) 3:
                    {
#line 14 "gml.m"
                      gml__succeeded = (gml__HeadVar__3_3 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 3)));
                      if (gml__succeeded)
                        {
#line 14 "gml.m"
                          gml__V_6_6 = (MR_Integer) 0;
#line 14 "gml.m"
                          gml__succeeded = TRUE;
                        }
                    }
#line 14 "gml.m"
                    break;
#line 14 "gml.m"
                }
#line 14 "gml.m"
                break;
#line 14 "gml.m"
              case (MR_Integer) 1:
                {
                  MR_Word gml__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), gml__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Word gml__V_8_8;

#line 14 "gml.m"
                  gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 14 "gml.m"
                  if ((MR_tag((MR_Word) gml__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 14 "gml.m"
                    gml__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), gml__HeadVar__3_3, (MR_Integer) 0)));
                  if (gml__succeeded)
                    {
#line 14 "gml.m"
                      {
#line 14 "gml.m"
                        gml____Compare____token_0_0(&gml__V_6_6, gml__V_7_7, gml__V_8_8);
                      }
#line 14 "gml.m"
                      gml__succeeded = TRUE;
                    }
                }
#line 14 "gml.m"
                break;
#line 14 "gml.m"
            }
#line 14 "gml.m"
            if (gml__succeeded)
#line 14 "gml.m"
              *gml__HeadVar__1_1 = gml__V_6_6;
#line 14 "gml.m"
            else
#line 14 "gml.m"
              {
#line 14 "gml.m"
                mercury__private_builtin__compare_error_0_p_0();
#line 14 "gml.m"
                return;
              }
#line 14 "gml.m"
          }
#line 14 "gml.m"
      }
  }
#line 14 "gml.m"
}

#line 14 "gml.m"
void MR_CALL gml____Index____basic_token_0_0(
#line 14 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 14 "gml.m"
  MR_Integer * gml__HeadVar__2_2)
#line 14 "gml.m"
{
#line 14 "gml.m"
  {
#line 14 "gml.m"
    bool gml__succeeded;

#line 14 "gml.m"
#line 14 "gml.m"
    switch (MR_tag((MR_Word) gml__HeadVar__1_1)) {
#line 14 "gml.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 14 "gml.m"
      case (MR_Integer) 0:
#line 14 "gml.m"
#line 14 "gml.m"
        switch (MR_unmkbody(gml__HeadVar__1_1)) {
#line 14 "gml.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 14 "gml.m"
          case (MR_Integer) 0:
#line 14 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 0;
#line 14 "gml.m"
            break;
#line 14 "gml.m"
          case (MR_Integer) 1:
#line 14 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 1;
#line 14 "gml.m"
            break;
#line 14 "gml.m"
          case (MR_Integer) 2:
#line 14 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 2;
#line 14 "gml.m"
            break;
#line 14 "gml.m"
          case (MR_Integer) 3:
#line 14 "gml.m"
            *gml__HeadVar__2_2 = (MR_Integer) 3;
#line 14 "gml.m"
            break;
#line 14 "gml.m"
        }
#line 14 "gml.m"
        break;
#line 14 "gml.m"
      case (MR_Integer) 1:
#line 14 "gml.m"
        *gml__HeadVar__2_2 = (MR_Integer) 4;
#line 14 "gml.m"
        break;
#line 14 "gml.m"
    }
#line 14 "gml.m"
  }
#line 14 "gml.m"
}

#line 14 "gml.m"
bool MR_CALL gml____Unify____basic_token_0_0(
#line 14 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 14 "gml.m"
  MR_Word gml__HeadVar__2_2)
#line 14 "gml.m"
{
#line 14 "gml.m"
  {
#line 14 "gml.m"
    bool gml__succeeded;
#line 14 "gml.m"
    MR_Word gml__V_3_3;
#line 14 "gml.m"
    MR_Word gml__V_4_4;

#line 14 "gml.m"
#line 14 "gml.m"
    switch (MR_tag((MR_Word) gml__HeadVar__1_1)) {
#line 14 "gml.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 14 "gml.m"
      case (MR_Integer) 0:
#line 14 "gml.m"
#line 14 "gml.m"
        switch (MR_unmkbody(gml__HeadVar__1_1)) {
#line 14 "gml.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 14 "gml.m"
          case (MR_Integer) 0:
#line 14 "gml.m"
            gml__succeeded = (gml__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 14 "gml.m"
            break;
#line 14 "gml.m"
          case (MR_Integer) 1:
#line 14 "gml.m"
            gml__succeeded = (gml__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 1)));
#line 14 "gml.m"
            break;
#line 14 "gml.m"
          case (MR_Integer) 2:
#line 14 "gml.m"
            gml__succeeded = (gml__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 2)));
#line 14 "gml.m"
            break;
#line 14 "gml.m"
          case (MR_Integer) 3:
#line 14 "gml.m"
            gml__succeeded = (gml__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 3)));
#line 14 "gml.m"
            break;
#line 14 "gml.m"
        }
#line 14 "gml.m"
        break;
#line 14 "gml.m"
      case (MR_Integer) 1:
        {
#line 14 "gml.m"
          gml__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(1), gml__HeadVar__1_1, (MR_Integer) 0)));
#line 14 "gml.m"
          gml__succeeded = (MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 14 "gml.m"
          if ((MR_tag((MR_Word) gml__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 14 "gml.m"
            gml__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(1), gml__HeadVar__2_2, (MR_Integer) 0)));
          if (gml__succeeded)
            {
              return gml__succeeded = gml____Unify____token_0_0(gml__V_3_3, gml__V_4_4);
            }
        }
#line 14 "gml.m"
        break;
#line 14 "gml.m"
    }
#line 14 "gml.m"
    return gml__succeeded;
#line 14 "gml.m"
  }
#line 14 "gml.m"
}

#line 668 "gml.m"
static void MR_CALL gml__parse_2_5_p_0(
#line 668 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 668 "gml.m"
  MR_Word gml__HeadVar__2_2,
#line 668 "gml.m"
  MR_Word * gml__HeadVar__3_3,
#line 668 "gml.m"
  MR_Word gml__HeadVar__4_4,
#line 668 "gml.m"
  MR_Word * gml__HeadVar__5_5)
#line 668 "gml.m"
{
#line 671 "gml.m"
  {
#line 671 "gml.m"
    /* tailcall optimized into a loop */
#line 671 "gml.m"
  loop_top:;
#line 671 "gml.m"
    {
#line 671 "gml.m"
      bool gml__succeeded;

#line 671 "gml.m"
      if ((gml__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 676 "gml.m"
#line 676 "gml.m"
        switch (gml__HeadVar__1_1) {
#line 676 "gml.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 676 "gml.m"
          case (MR_Integer) 0:
            {
#line 674 "gml.m"
              *gml__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 675 "gml.m"
              *gml__HeadVar__5_5 = gml__HeadVar__4_4;
            }
#line 676 "gml.m"
            break;
#line 676 "gml.m"
          case (MR_Integer) 1:
            {
              MR_Word gml__V_12_12;
              MR_String gml__V_13_13 = (MR_String) "unterminated array";
              MR_Word gml__TypeInfo_41_41;

#line 678 "gml.m"
              gml__V_12_12 = (MR_Word) gml__V_13_13;
              gml__TypeInfo_41_41 = (MR_Word) (&gml__gml__type_ctor_info_parse_error_0);
#line 678 "gml.m"
              {
#line 678 "gml.m"
                mercury__exception__throw_1_p_0(gml__TypeInfo_41_41, ((MR_Box) (gml__V_12_12)));
#line 678 "gml.m"
                return;
              }
            }
#line 676 "gml.m"
            break;
#line 676 "gml.m"
          case (MR_Integer) 2:
            {
              MR_Word gml__V_10_10;
              MR_String gml__V_11_11 = (MR_String) "unterminated function";
              MR_Word gml__TypeInfo_42_42;

#line 681 "gml.m"
              gml__V_10_10 = (MR_Word) gml__V_11_11;
              gml__TypeInfo_42_42 = (MR_Word) (&gml__gml__type_ctor_info_parse_error_0);
#line 681 "gml.m"
              {
#line 681 "gml.m"
                mercury__exception__throw_1_p_0(gml__TypeInfo_42_42, ((MR_Box) (gml__V_10_10)));
#line 681 "gml.m"
                return;
              }
            }
#line 676 "gml.m"
            break;
#line 676 "gml.m"
        }
#line 671 "gml.m"
      else
#line 671 "gml.m"
        {
          MR_Word gml__Token_15 = ((MR_Word) (MR_hl_field(MR_mktag(1), gml__HeadVar__2_2, (MR_Integer) 0)));
          MR_Word gml__Tokens_16 = ((MR_Word) (MR_hl_field(MR_mktag(1), gml__HeadVar__2_2, (MR_Integer) 1)));

#line 688 "gml.m"
#line 688 "gml.m"
          switch (MR_tag((MR_Word) gml__Token_15)) {
#line 688 "gml.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 688 "gml.m"
            case (MR_Integer) 0:
#line 688 "gml.m"
#line 688 "gml.m"
              switch (MR_unmkbody(gml__Token_15)) {
#line 688 "gml.m"
                default: /*NOTREACHED*/ MR_assert(0);
#line 688 "gml.m"
                case (MR_Integer) 0:
                  {
                    MR_Word gml__Tokens1_21;
                    MR_Word gml__Array0_22;
                    MR_Word gml__Array_23;
                    MR_Word gml__V_34_34;
                    MR_Word gml__V_35_35;
                    MR_Word gml__V_36_36 = (MR_Integer) 1;
                    MR_Word gml__V_37_37 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
                    MR_Word gml__TypeInfo_43_43;
                    MR_Word gml__V_5_49;

#line 690 "gml.m"
                    {
#line 690 "gml.m"
                      gml__parse_2_5_p_0(gml__V_36_36, gml__Tokens_16, &gml__Tokens1_21, gml__V_37_37, &gml__Array0_22);
                    }
                    gml__TypeInfo_43_43 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                    gml__V_5_49 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                    {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                      mercury__list__reverse_2_3_p_0(gml__TypeInfo_43_43, gml__Array0_22, gml__V_5_49, &gml__Array_23);
                    }
#line 693 "gml.m"
                    {
#line 693 "gml.m"
                      gml__V_35_35 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "array"));
#line 693 "gml.m"
                      MR_hl_field(MR_mktag(2), gml__V_35_35, 0) = ((MR_Box) (gml__Array_23));
#line 693 "gml.m"
                    }
#line 692 "gml.m"
                    {
#line 692 "gml.m"
                      gml__V_34_34 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 692 "gml.m"
                      MR_hl_field(MR_mktag(1), gml__V_34_34, 0) = ((MR_Box) (gml__V_35_35));
#line 692 "gml.m"
                      MR_hl_field(MR_mktag(1), gml__V_34_34, 1) = ((MR_Box) (gml__HeadVar__4_4));
#line 692 "gml.m"
                    }
#line 692 "gml.m"
                    {
#line 692 "gml.m"
                      /* direct tailcall eliminated */
#line 692 "gml.m"
                      {
#line 692 "gml.m"
                        MR_Word gml__HeadVar__2__tmp_copy_2 = gml__Tokens1_21;
#line 692 "gml.m"
                        MR_Word gml__HeadVar__4__tmp_copy_4 = gml__V_34_34;

#line 692 "gml.m"
                        gml__HeadVar__2_2 = gml__HeadVar__2__tmp_copy_2;
#line 692 "gml.m"
                        gml__HeadVar__4_4 = gml__HeadVar__4__tmp_copy_4;
#line 692 "gml.m"
                      }
#line 692 "gml.m"
                      goto loop_top;
#line 692 "gml.m"
                    }
                  }
#line 688 "gml.m"
                  break;
#line 688 "gml.m"
                case (MR_Integer) 1:
#line 699 "gml.m"
                  {
#line 696 "gml.m"
                    gml__succeeded = (gml__HeadVar__1_1 == (MR_Integer) 1);
#line 699 "gml.m"
                    if (gml__succeeded)
                      {
#line 697 "gml.m"
                        *gml__HeadVar__3_3 = gml__Tokens_16;
#line 698 "gml.m"
                        *gml__HeadVar__5_5 = gml__HeadVar__4_4;
                      }
#line 699 "gml.m"
                    else
                      {
                        MR_Word gml__V_32_32;
                        MR_String gml__V_33_33 = (MR_String) "']' without preceding '['";
                        MR_Word gml__TypeInfo_44_44;

#line 700 "gml.m"
                        gml__V_32_32 = (MR_Word) gml__V_33_33;
                        gml__TypeInfo_44_44 = (MR_Word) (&gml__gml__type_ctor_info_parse_error_0);
#line 700 "gml.m"
                        {
#line 700 "gml.m"
                          mercury__exception__throw_1_p_0(gml__TypeInfo_44_44, ((MR_Box) (gml__V_32_32)));
#line 700 "gml.m"
                          return;
                        }
                      }
#line 699 "gml.m"
                  }
#line 688 "gml.m"
                  break;
#line 688 "gml.m"
                case (MR_Integer) 2:
                  {
                    MR_Word gml__Func0_24;
                    MR_Word gml__Func_25;
                    MR_Word gml__V_28_28;
                    MR_Word gml__V_29_29;
                    MR_Word gml__V_30_30 = (MR_Integer) 2;
                    MR_Word gml__V_31_31 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
                    MR_Word gml__Tokens1_40;
                    MR_Word gml__TypeInfo_45_45;
                    MR_Word gml__V_5_52;

#line 704 "gml.m"
                    {
#line 704 "gml.m"
                      gml__parse_2_5_p_0(gml__V_30_30, gml__Tokens_16, &gml__Tokens1_40, gml__V_31_31, &gml__Func0_24);
                    }
                    gml__TypeInfo_45_45 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                    gml__V_5_52 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                    {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
                      mercury__list__reverse_2_3_p_0(gml__TypeInfo_45_45, gml__Func0_24, gml__V_5_52, &gml__Func_25);
                    }
#line 707 "gml.m"
                    {
#line 707 "gml.m"
                      gml__V_29_29 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "function"));
#line 707 "gml.m"
                      MR_hl_field(MR_mktag(1), gml__V_29_29, 0) = ((MR_Box) (gml__Func_25));
#line 707 "gml.m"
                    }
#line 706 "gml.m"
                    {
#line 706 "gml.m"
                      gml__V_28_28 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 706 "gml.m"
                      MR_hl_field(MR_mktag(1), gml__V_28_28, 0) = ((MR_Box) (gml__V_29_29));
#line 706 "gml.m"
                      MR_hl_field(MR_mktag(1), gml__V_28_28, 1) = ((MR_Box) (gml__HeadVar__4_4));
#line 706 "gml.m"
                    }
#line 706 "gml.m"
                    {
#line 706 "gml.m"
                      /* direct tailcall eliminated */
#line 706 "gml.m"
                      {
#line 706 "gml.m"
                        MR_Word gml__HeadVar__2__tmp_copy_2 = gml__Tokens1_40;
#line 706 "gml.m"
                        MR_Word gml__HeadVar__4__tmp_copy_4 = gml__V_28_28;

#line 706 "gml.m"
                        gml__HeadVar__2_2 = gml__HeadVar__2__tmp_copy_2;
#line 706 "gml.m"
                        gml__HeadVar__4_4 = gml__HeadVar__4__tmp_copy_4;
#line 706 "gml.m"
                      }
#line 706 "gml.m"
                      goto loop_top;
#line 706 "gml.m"
                    }
                  }
#line 688 "gml.m"
                  break;
#line 688 "gml.m"
                case (MR_Integer) 3:
#line 713 "gml.m"
                  {
#line 710 "gml.m"
                    gml__succeeded = (gml__HeadVar__1_1 == (MR_Integer) 2);
#line 713 "gml.m"
                    if (gml__succeeded)
                      {
#line 711 "gml.m"
                        *gml__HeadVar__3_3 = gml__Tokens_16;
#line 712 "gml.m"
                        *gml__HeadVar__5_5 = gml__HeadVar__4_4;
                      }
#line 713 "gml.m"
                    else
                      {
                        MR_Word gml__V_26_26;
                        MR_String gml__V_27_27 = (MR_String) "'}' without preceding '{'";
                        MR_Word gml__TypeInfo_46_46;

#line 714 "gml.m"
                        gml__V_26_26 = (MR_Word) gml__V_27_27;
                        gml__TypeInfo_46_46 = (MR_Word) (&gml__gml__type_ctor_info_parse_error_0);
#line 714 "gml.m"
                        {
#line 714 "gml.m"
                          mercury__exception__throw_1_p_0(gml__TypeInfo_46_46, ((MR_Box) (gml__V_26_26)));
#line 714 "gml.m"
                          return;
                        }
                      }
#line 713 "gml.m"
                  }
#line 688 "gml.m"
                  break;
#line 688 "gml.m"
              }
#line 688 "gml.m"
              break;
#line 688 "gml.m"
            case (MR_Integer) 1:
              {
                MR_Word gml__TheToken_20 = ((MR_Word) (MR_hl_field(MR_mktag(1), gml__Token_15, (MR_Integer) 0)));
                MR_Word gml__V_38_38;
                MR_Word gml__V_39_39;

#line 687 "gml.m"
                {
#line 687 "gml.m"
                  gml__V_39_39 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "single_token");
#line 687 "gml.m"
                  MR_hl_field(MR_mktag(0), gml__V_39_39, 0) = ((MR_Box) (gml__TheToken_20));
#line 687 "gml.m"
                }
#line 686 "gml.m"
                {
#line 686 "gml.m"
                  gml__V_38_38 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 686 "gml.m"
                  MR_hl_field(MR_mktag(1), gml__V_38_38, 0) = ((MR_Box) (gml__V_39_39));
#line 686 "gml.m"
                  MR_hl_field(MR_mktag(1), gml__V_38_38, 1) = ((MR_Box) (gml__HeadVar__4_4));
#line 686 "gml.m"
                }
#line 686 "gml.m"
                {
#line 686 "gml.m"
                  /* direct tailcall eliminated */
#line 686 "gml.m"
                  {
#line 686 "gml.m"
                    MR_Word gml__HeadVar__2__tmp_copy_2 = gml__Tokens_16;
#line 686 "gml.m"
                    MR_Word gml__HeadVar__4__tmp_copy_4 = gml__V_38_38;

#line 686 "gml.m"
                    gml__HeadVar__2_2 = gml__HeadVar__2__tmp_copy_2;
#line 686 "gml.m"
                    gml__HeadVar__4_4 = gml__HeadVar__4__tmp_copy_4;
#line 686 "gml.m"
                  }
#line 686 "gml.m"
                  goto loop_top;
#line 686 "gml.m"
                }
              }
#line 688 "gml.m"
              break;
#line 688 "gml.m"
          }
#line 671 "gml.m"
        }
#line 671 "gml.m"
    }
#line 671 "gml.m"
  }
#line 668 "gml.m"
}

#line 594 "gml.m"
static void MR_CALL gml__lexer_read_char_3_p_0(
#line 594 "gml.m"
  MR_Word * gml__HeadVar__1_1)
#line 594 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Word gml__Stream_5_14;
    MR_Integer gml__Code_7_23;

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__lexer_read_char_3_p_0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_14
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__lexer_read_char_3_p_0
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word File;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer CharCode;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	File = 
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_14
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	CharCode = mercury_getc((MercuryFile *) File);
	update_io(IO0, IO);

#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Code_7_23
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = CharCode;
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 731 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 219 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    gml__succeeded = (gml__Code_7_23 == (MR_Integer) -1);
    if (gml__succeeded)
#line 221 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      *gml__HeadVar__1_1 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
    else
      {
        MR_Char gml__Char_8_25;

#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
{
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#define MR_PROC_LABEL gml__lexer_read_char_3_p_0
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	MR_Char Character;
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	MR_Integer Int;
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	Int = 
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
gml__Code_7_23
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
;
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
		{
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

	/*
	** If the integer doesn't fit into a char, then
	** the assignment `Character = Int' below will truncate it.
	** SUCCESS_INDICATOR will be set to true only if
	** the result was not truncated.
	*/
	Character = Int;
	SUCCESS_INDICATOR = ((MR_UnsignedChar) Character == Int);

#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"

		;}
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#undef MR_PROC_LABEL
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	if (SUCCESS_INDICATOR) {
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
gml__Char_8_25
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
 = Character;
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
	}
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
gml__succeeded
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
 = SUCCESS_INDICATOR;
#line 7 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/char.opt"
}
        if (gml__succeeded)
#line 227 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          {
#line 227 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            *gml__HeadVar__1_1 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "ok"));
#line 227 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            MR_hl_field(MR_mktag(1), *gml__HeadVar__1_1, 0) = ((MR_Box) (MR_Word) (gml__Char_8_25));
#line 227 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          }
        else
          {
            MR_String gml__V_14_26 = (MR_String) "read failed: ";
            MR_String gml__Msg_9_27;
            MR_Integer gml__Line_44;
            MR_Word gml__V_48_48;
            MR_Word gml__TypeInfo_10_49;

#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__lexer_read_char_3_p_0
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Msg0;
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Msg;
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Msg0 = 
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__V_14_26
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	ML_maybe_make_err_msg(TRUE, Msg0, MR_PROC_LABEL, Msg);
}
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Msg_9_27
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Msg;
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 735 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__lexer_read_char_3_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_44
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 636 "gml.m"
            {
#line 636 "gml.m"
              gml__V_48_48 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 636 "gml.m"
              MR_hl_field(MR_mktag(0), gml__V_48_48, 0) = ((MR_Box) (gml__Line_44));
#line 636 "gml.m"
              MR_hl_field(MR_mktag(0), gml__V_48_48, 1) = ((MR_Box) (gml__Msg_9_27));
#line 636 "gml.m"
            }
            gml__TypeInfo_10_49 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 636 "gml.m"
            {
#line 636 "gml.m"
              mercury__exception__throw_1_p_0(gml__TypeInfo_10_49, ((MR_Box) (gml__V_48_48)));
#line 636 "gml.m"
              return;
            }
          }
      }
  }
#line 594 "gml.m"
}
#line 568 "gml.m"
static /* final */ const MR_Box gml__const_19_0_1_V_26_26[2] = {
		((MR_Box) ((MR_String) "'")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};

#line 553 "gml.m"
static void MR_CALL gml__rev_char_list_to_int_5_p_0(
#line 553 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 553 "gml.m"
  MR_Integer gml__HeadVar__2_2,
#line 553 "gml.m"
  MR_Word * gml__HeadVar__3_3)
#line 553 "gml.m"
{
  {
    bool gml__succeeded;
    MR_String gml__String_9;
#line 565 "gml.m"
    MR_Integer gml__Int_17;

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__rev_char_list_to_int_5_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__HeadVar__1_1
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_9
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 563 "gml.m"
    {
#line 563 "gml.m"
      gml__succeeded = mercury__string__base_string_to_int_3_p_0(gml__HeadVar__2_2, gml__String_9, &gml__Int_17);
    }
#line 565 "gml.m"
    if (gml__succeeded)
#line 564 "gml.m"
      {
#line 564 "gml.m"
        *gml__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "integer");
#line 564 "gml.m"
        MR_hl_field(MR_mktag(0), *gml__HeadVar__3_3, 0) = ((MR_Box) (gml__Int_17));
#line 564 "gml.m"
      }
#line 565 "gml.m"
    else
      {
        MR_Integer gml__Line_18;
        MR_String gml__Msg_19;
        MR_Word gml__V_22_22;
        MR_Word gml__V_23_23;
        MR_String gml__V_24_24;
        MR_Word gml__V_25_25;
        MR_Word gml__V_26_26;
        MR_String gml__V_27_27;
        MR_Word gml__V_28_28;
        MR_Word gml__TypeInfo_21_29;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__rev_char_list_to_int_5_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_18
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 568 "gml.m"
        gml__V_24_24 = (MR_String) "invalid int token `";
#line 568 "gml.m"
        gml__V_27_27 = (MR_String) "'";
#line 568 "gml.m"
        gml__V_28_28 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 568 "gml.m"
        gml__V_26_26 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_19_0_1_V_26_26);
#line 568 "gml.m"
        {
#line 568 "gml.m"
          gml__V_25_25 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 568 "gml.m"
          MR_hl_field(MR_mktag(1), gml__V_25_25, 0) = ((MR_Box) (gml__String_9));
#line 568 "gml.m"
          MR_hl_field(MR_mktag(1), gml__V_25_25, 1) = ((MR_Box) (gml__V_26_26));
#line 568 "gml.m"
        }
#line 567 "gml.m"
        {
#line 567 "gml.m"
          gml__V_23_23 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 567 "gml.m"
          MR_hl_field(MR_mktag(1), gml__V_23_23, 0) = ((MR_Box) (gml__V_24_24));
#line 567 "gml.m"
          MR_hl_field(MR_mktag(1), gml__V_23_23, 1) = ((MR_Box) (gml__V_25_25));
#line 567 "gml.m"
        }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__rev_char_list_to_int_5_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_23_23
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_19
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 569 "gml.m"
        {
#line 569 "gml.m"
          gml__V_22_22 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 569 "gml.m"
          MR_hl_field(MR_mktag(0), gml__V_22_22, 0) = ((MR_Box) (gml__Line_18));
#line 569 "gml.m"
          MR_hl_field(MR_mktag(0), gml__V_22_22, 1) = ((MR_Box) (gml__Msg_19));
#line 569 "gml.m"
        }
        gml__TypeInfo_21_29 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 569 "gml.m"
        {
#line 569 "gml.m"
          mercury__exception__throw_1_p_0(gml__TypeInfo_21_29, ((MR_Box) (gml__V_22_22)));
#line 569 "gml.m"
          return;
        }
      }
  }
#line 553 "gml.m"
}
#line 588 "gml.m"
static /* final */ const MR_Box gml__const_18_0_1_V_34_34[2] = {
		((MR_Box) ((MR_String) "'")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 588 "gml.m"
static /* final */ const MR_Box gml__const_18_0_2_V_75_75[2] = {
		((MR_Box) ((MR_String) "'")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};

#line 534 "gml.m"
static void MR_CALL gml__get_float_exponent_3_4_p_0(
#line 534 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 534 "gml.m"
  MR_Word * gml__HeadVar__2_2)
#line 534 "gml.m"
{
  {
    /* tailcall optimized into a loop */
  loop_top:;
    {
      bool gml__succeeded;
      MR_Word gml__Result_7;

#line 540 "gml.m"
      {
#line 540 "gml.m"
        gml__lexer_read_char_3_p_0(&gml__Result_7);
      }
#line 543 "gml.m"
      if ((gml__Result_7 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
        {
          MR_String gml__String_18;
#line 585 "gml.m"
          MR_Float gml__Float_25;

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_exponent_3_4_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__HeadVar__1_1
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_18
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_exponent_3_4_p_0
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String FloatString;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Float FloatVal;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	FloatString = 
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_18
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	/* use a temporary, since we can't don't know whether FloatVal
	   is a double or float */
	double tmp;
	SUCCESS_INDICATOR = (sscanf(FloatString, "%lf", &tmp) == 1);
		/* TRUE if sscanf succeeds, FALSE otherwise */
	FloatVal = tmp;
}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	if (SUCCESS_INDICATOR) {
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Float_25
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = FloatVal;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__succeeded
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = SUCCESS_INDICATOR;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 585 "gml.m"
          if (gml__succeeded)
#line 584 "gml.m"
            {
#line 584 "gml.m"
              *gml__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 584 "gml.m"
              MR_hl_field(MR_mktag(1), *gml__HeadVar__2_2, 0) = MR_box_float(gml__Float_25);
#line 584 "gml.m"
            }
#line 585 "gml.m"
          else
            {
              MR_Integer gml__Line_26;
              MR_String gml__Msg_27;
              MR_Word gml__V_30_30;
              MR_Word gml__V_31_31;
              MR_String gml__V_32_32;
              MR_Word gml__V_33_33;
              MR_Word gml__V_34_34;
              MR_String gml__V_35_35;
              MR_Word gml__V_36_36;
              MR_Word gml__TypeInfo_19_37;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_float_exponent_3_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_26
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 588 "gml.m"
              gml__V_32_32 = (MR_String) "invalid float token `";
#line 588 "gml.m"
              gml__V_35_35 = (MR_String) "'";
#line 588 "gml.m"
              gml__V_36_36 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 588 "gml.m"
              gml__V_34_34 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_18_0_1_V_34_34);
#line 588 "gml.m"
              {
#line 588 "gml.m"
                gml__V_33_33 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 588 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_33_33, 0) = ((MR_Box) (gml__String_18));
#line 588 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_33_33, 1) = ((MR_Box) (gml__V_34_34));
#line 588 "gml.m"
              }
#line 587 "gml.m"
              {
#line 587 "gml.m"
                gml__V_31_31 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 587 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_31_31, 0) = ((MR_Box) (gml__V_32_32));
#line 587 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_31_31, 1) = ((MR_Box) (gml__V_33_33));
#line 587 "gml.m"
              }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_exponent_3_4_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_31_31
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_27
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 589 "gml.m"
              {
#line 589 "gml.m"
                gml__V_30_30 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 589 "gml.m"
                MR_hl_field(MR_mktag(0), gml__V_30_30, 0) = ((MR_Box) (gml__Line_26));
#line 589 "gml.m"
                MR_hl_field(MR_mktag(0), gml__V_30_30, 1) = ((MR_Box) (gml__Msg_27));
#line 589 "gml.m"
              }
              gml__TypeInfo_19_37 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 589 "gml.m"
              {
#line 589 "gml.m"
                mercury__exception__throw_1_p_0(gml__TypeInfo_19_37, ((MR_Box) (gml__V_30_30)));
#line 589 "gml.m"
                return;
              }
            }
        }
#line 543 "gml.m"
      else
#line 543 "gml.m"
        {
          MR_Char gml__Char_8 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(1), gml__Result_7, (MR_Integer) 0)));

#line 544 "gml.m"
          {
#line 544 "gml.m"
            gml__succeeded = mercury__char__is_digit_1_p_0(gml__Char_8);
          }
#line 546 "gml.m"
          if (gml__succeeded)
            {
              MR_Word gml__V_15_15;

#line 545 "gml.m"
              {
#line 545 "gml.m"
                gml__V_15_15 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 545 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_15_15, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 545 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_15_15, 1) = ((MR_Box) (gml__HeadVar__1_1));
#line 545 "gml.m"
              }
#line 545 "gml.m"
              {
#line 545 "gml.m"
                /* direct tailcall eliminated */
#line 545 "gml.m"
                {
#line 545 "gml.m"
                  MR_Word gml__HeadVar__1__tmp_copy_1 = gml__V_15_15;

#line 545 "gml.m"
                  gml__HeadVar__1_1 = gml__HeadVar__1__tmp_copy_1;
#line 545 "gml.m"
                }
#line 545 "gml.m"
                goto loop_top;
#line 545 "gml.m"
              }
            }
#line 546 "gml.m"
          else
            {
              MR_Word gml__Stream_5_48;
              MR_String gml__String_59;
#line 585 "gml.m"
              MR_Float gml__Float_66;

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_float_exponent_3_4_p_0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_48
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_float_exponent_3_4_p_0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word File;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Char Character;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	File = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_48
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Character = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Char_8
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_exponent_3_4_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__HeadVar__1_1
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_59
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_exponent_3_4_p_0
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String FloatString;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Float FloatVal;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	FloatString = 
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_59
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	/* use a temporary, since we can't don't know whether FloatVal
	   is a double or float */
	double tmp;
	SUCCESS_INDICATOR = (sscanf(FloatString, "%lf", &tmp) == 1);
		/* TRUE if sscanf succeeds, FALSE otherwise */
	FloatVal = tmp;
}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	if (SUCCESS_INDICATOR) {
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Float_66
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = FloatVal;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__succeeded
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = SUCCESS_INDICATOR;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 585 "gml.m"
              if (gml__succeeded)
#line 584 "gml.m"
                {
#line 584 "gml.m"
                  *gml__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 584 "gml.m"
                  MR_hl_field(MR_mktag(1), *gml__HeadVar__2_2, 0) = MR_box_float(gml__Float_66);
#line 584 "gml.m"
                }
#line 585 "gml.m"
              else
                {
                  MR_Integer gml__Line_67;
                  MR_String gml__Msg_68;
                  MR_Word gml__V_71_71;
                  MR_Word gml__V_72_72;
                  MR_String gml__V_73_73;
                  MR_Word gml__V_74_74;
                  MR_Word gml__V_75_75;
                  MR_String gml__V_76_76;
                  MR_Word gml__V_77_77;
                  MR_Word gml__TypeInfo_19_78;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_float_exponent_3_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_67
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 588 "gml.m"
                  gml__V_73_73 = (MR_String) "invalid float token `";
#line 588 "gml.m"
                  gml__V_76_76 = (MR_String) "'";
#line 588 "gml.m"
                  gml__V_77_77 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 588 "gml.m"
                  gml__V_75_75 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_18_0_2_V_75_75);
#line 588 "gml.m"
                  {
#line 588 "gml.m"
                    gml__V_74_74 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 588 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_74_74, 0) = ((MR_Box) (gml__String_59));
#line 588 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_74_74, 1) = ((MR_Box) (gml__V_75_75));
#line 588 "gml.m"
                  }
#line 587 "gml.m"
                  {
#line 587 "gml.m"
                    gml__V_72_72 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 587 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_72_72, 0) = ((MR_Box) (gml__V_73_73));
#line 587 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_72_72, 1) = ((MR_Box) (gml__V_74_74));
#line 587 "gml.m"
                  }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_exponent_3_4_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_72_72
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_68
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 589 "gml.m"
                  {
#line 589 "gml.m"
                    gml__V_71_71 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 589 "gml.m"
                    MR_hl_field(MR_mktag(0), gml__V_71_71, 0) = ((MR_Box) (gml__Line_67));
#line 589 "gml.m"
                    MR_hl_field(MR_mktag(0), gml__V_71_71, 1) = ((MR_Box) (gml__Msg_68));
#line 589 "gml.m"
                  }
                  gml__TypeInfo_19_78 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 589 "gml.m"
                  {
#line 589 "gml.m"
                    mercury__exception__throw_1_p_0(gml__TypeInfo_19_78, ((MR_Box) (gml__V_71_71)));
#line 589 "gml.m"
                    return;
                  }
                }
            }
#line 543 "gml.m"
        }
    }
  }
#line 534 "gml.m"
}
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_17_0_1_V_46_46[2] = {
		((MR_Box) ((MR_String) "float exponent")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_17_0_2_V_42_42[2] = {
		((MR_Box) ((MR_String) "' in ")),
		((MR_Box) (MR_mkword(MR_mktag(1), &gml__const_17_0_1_V_46_46)))};

#line 515 "gml.m"
static void MR_CALL gml__get_float_exponent_2_4_p_0(
#line 515 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 515 "gml.m"
  MR_Word * gml__HeadVar__2_2)
#line 515 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Word gml__Result_7;

#line 522 "gml.m"
    {
#line 522 "gml.m"
      gml__lexer_read_char_3_p_0(&gml__Result_7);
    }
#line 525 "gml.m"
    if ((gml__Result_7 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
      {
        MR_String gml__V_16_16 = (MR_String) "float exponent";
        MR_Integer gml__Line_18;
        MR_String gml__Msg_19;
        MR_Word gml__V_22_22;
        MR_String gml__V_23_23;
        MR_Word gml__TypeInfo_11_24;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_float_exponent_2_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_18
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 617 "gml.m"
        gml__V_23_23 = (MR_String) "unexpected end-of-file in ";
#line 76 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
        {
#line 76 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
          mercury__string__append_3_p_2(gml__V_23_23, gml__V_16_16, &gml__Msg_19);
        }
#line 618 "gml.m"
        {
#line 618 "gml.m"
          gml__V_22_22 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 618 "gml.m"
          MR_hl_field(MR_mktag(0), gml__V_22_22, 0) = ((MR_Box) (gml__Line_18));
#line 618 "gml.m"
          MR_hl_field(MR_mktag(0), gml__V_22_22, 1) = ((MR_Box) (gml__Msg_19));
#line 618 "gml.m"
        }
        gml__TypeInfo_11_24 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 618 "gml.m"
        {
#line 618 "gml.m"
          mercury__exception__throw_1_p_0(gml__TypeInfo_11_24, ((MR_Box) (gml__V_22_22)));
#line 618 "gml.m"
          return;
        }
      }
#line 525 "gml.m"
    else
#line 525 "gml.m"
      {
        MR_Char gml__Char_8 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(1), gml__Result_7, (MR_Integer) 0)));

#line 526 "gml.m"
        {
#line 526 "gml.m"
          gml__succeeded = mercury__char__is_digit_1_p_0(gml__Char_8);
        }
#line 528 "gml.m"
        if (gml__succeeded)
          {
            MR_Word gml__V_14_14;

#line 527 "gml.m"
            {
#line 527 "gml.m"
              gml__V_14_14 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 527 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_14_14, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 527 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_14_14, 1) = ((MR_Box) (gml__HeadVar__1_1));
#line 527 "gml.m"
            }
#line 527 "gml.m"
            {
#line 527 "gml.m"
              gml__get_float_exponent_3_4_p_0(gml__V_14_14, gml__HeadVar__2_2);
#line 527 "gml.m"
              return;
            }
          }
#line 528 "gml.m"
        else
          {
            MR_String gml__V_15_15 = (MR_String) "float exponent";
            MR_Integer gml__Line_33;
            MR_String gml__Msg_34;
            MR_Word gml__V_37_37;
            MR_Word gml__V_38_38;
            MR_String gml__V_39_39;
            MR_Word gml__V_40_40;
            MR_String gml__V_41_41;
            MR_Word gml__V_42_42;
            MR_Word gml__V_43_43;
            MR_Word gml__V_44_44;
            MR_String gml__V_45_45;
            MR_Word gml__V_46_46;
            MR_Word gml__V_47_47;
            MR_Word gml__TypeInfo_22_48;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_float_exponent_2_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_33
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 626 "gml.m"
            gml__V_39_39 = (MR_String) "unexpected character `";
#line 627 "gml.m"
            gml__V_44_44 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 627 "gml.m"
            {
#line 627 "gml.m"
              gml__V_43_43 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 627 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_43_43, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 627 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_43_43, 1) = ((MR_Box) (gml__V_44_44));
#line 627 "gml.m"
            }
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_exponent_2_4_p_0
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word CharList;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	CharList = 
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_43_43
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
		/* mode (out, in) is det */
	MR_Word char_list_ptr;
	size_t size;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `char_list_ptr'
*/
	size = sizeof(MR_Word);
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		size++;
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** loop to copy the characters from the char_list to the string
*/
	size = 0;
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		Str[size++] = MR_list_head(char_list_ptr);
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** null terminate the string
*/
	Str[size] = '\0';
}
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_41_41
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 627 "gml.m"
            gml__V_45_45 = (MR_String) "' in ";
#line 627 "gml.m"
            gml__V_47_47 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 627 "gml.m"
            gml__V_46_46 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_17_0_1_V_46_46);
#line 627 "gml.m"
            gml__V_42_42 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_17_0_2_V_42_42);
#line 626 "gml.m"
            {
#line 626 "gml.m"
              gml__V_40_40 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 626 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_40_40, 0) = ((MR_Box) (gml__V_41_41));
#line 626 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_40_40, 1) = ((MR_Box) (gml__V_42_42));
#line 626 "gml.m"
            }
#line 625 "gml.m"
            {
#line 625 "gml.m"
              gml__V_38_38 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 625 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_38_38, 0) = ((MR_Box) (gml__V_39_39));
#line 625 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_38_38, 1) = ((MR_Box) (gml__V_40_40));
#line 625 "gml.m"
            }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_exponent_2_4_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_38_38
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_34
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 628 "gml.m"
            {
#line 628 "gml.m"
              gml__V_37_37 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 628 "gml.m"
              MR_hl_field(MR_mktag(0), gml__V_37_37, 0) = ((MR_Box) (gml__Line_33));
#line 628 "gml.m"
              MR_hl_field(MR_mktag(0), gml__V_37_37, 1) = ((MR_Box) (gml__Msg_34));
#line 628 "gml.m"
            }
            gml__TypeInfo_22_48 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 628 "gml.m"
            {
#line 628 "gml.m"
              mercury__exception__throw_1_p_0(gml__TypeInfo_22_48, ((MR_Box) (gml__V_37_37)));
#line 628 "gml.m"
              return;
            }
          }
#line 525 "gml.m"
      }
  }
#line 515 "gml.m"
}
#line 588 "gml.m"
static /* final */ const MR_Box gml__const_16_0_1_V_36_36[2] = {
		((MR_Box) ((MR_String) "'")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_16_0_2_V_62_62[2] = {
		((MR_Box) ((MR_String) "float exponent")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_16_0_3_V_58_58[2] = {
		((MR_Box) ((MR_String) "' in ")),
		((MR_Box) (MR_mkword(MR_mktag(1), &gml__const_16_0_2_V_62_62)))};

#line 498 "gml.m"
static void MR_CALL gml__get_float_exponent_4_p_0(
#line 498 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 498 "gml.m"
  MR_Word * gml__HeadVar__2_2)
#line 498 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Word gml__Result_7;

#line 501 "gml.m"
    {
#line 501 "gml.m"
      gml__lexer_read_char_3_p_0(&gml__Result_7);
    }
#line 504 "gml.m"
    if ((gml__Result_7 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
      {
        MR_String gml__String_20;
#line 585 "gml.m"
        MR_Float gml__Float_27;

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_exponent_4_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__HeadVar__1_1
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_20
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_exponent_4_p_0
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String FloatString;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Float FloatVal;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	FloatString = 
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_20
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	/* use a temporary, since we can't don't know whether FloatVal
	   is a double or float */
	double tmp;
	SUCCESS_INDICATOR = (sscanf(FloatString, "%lf", &tmp) == 1);
		/* TRUE if sscanf succeeds, FALSE otherwise */
	FloatVal = tmp;
}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	if (SUCCESS_INDICATOR) {
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Float_27
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = FloatVal;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__succeeded
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = SUCCESS_INDICATOR;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 585 "gml.m"
        if (gml__succeeded)
#line 584 "gml.m"
          {
#line 584 "gml.m"
            *gml__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 584 "gml.m"
            MR_hl_field(MR_mktag(1), *gml__HeadVar__2_2, 0) = MR_box_float(gml__Float_27);
#line 584 "gml.m"
          }
#line 585 "gml.m"
        else
          {
            MR_Integer gml__Line_28;
            MR_String gml__Msg_29;
            MR_Word gml__V_32_32;
            MR_Word gml__V_33_33;
            MR_String gml__V_34_34;
            MR_Word gml__V_35_35;
            MR_Word gml__V_36_36;
            MR_String gml__V_37_37;
            MR_Word gml__V_38_38;
            MR_Word gml__TypeInfo_19_39;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_float_exponent_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_28
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 588 "gml.m"
            gml__V_34_34 = (MR_String) "invalid float token `";
#line 588 "gml.m"
            gml__V_37_37 = (MR_String) "'";
#line 588 "gml.m"
            gml__V_38_38 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 588 "gml.m"
            gml__V_36_36 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_16_0_1_V_36_36);
#line 588 "gml.m"
            {
#line 588 "gml.m"
              gml__V_35_35 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 588 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_35_35, 0) = ((MR_Box) (gml__String_20));
#line 588 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_35_35, 1) = ((MR_Box) (gml__V_36_36));
#line 588 "gml.m"
            }
#line 587 "gml.m"
            {
#line 587 "gml.m"
              gml__V_33_33 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 587 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_33_33, 0) = ((MR_Box) (gml__V_34_34));
#line 587 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_33_33, 1) = ((MR_Box) (gml__V_35_35));
#line 587 "gml.m"
            }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_exponent_4_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_33_33
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_29
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 589 "gml.m"
            {
#line 589 "gml.m"
              gml__V_32_32 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 589 "gml.m"
              MR_hl_field(MR_mktag(0), gml__V_32_32, 0) = ((MR_Box) (gml__Line_28));
#line 589 "gml.m"
              MR_hl_field(MR_mktag(0), gml__V_32_32, 1) = ((MR_Box) (gml__Msg_29));
#line 589 "gml.m"
            }
            gml__TypeInfo_19_39 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 589 "gml.m"
            {
#line 589 "gml.m"
              mercury__exception__throw_1_p_0(gml__TypeInfo_19_39, ((MR_Box) (gml__V_32_32)));
#line 589 "gml.m"
              return;
            }
          }
      }
#line 504 "gml.m"
    else
#line 504 "gml.m"
      {
        MR_Char gml__Char_8 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(1), gml__Result_7, (MR_Integer) 0)));

#line 505 "gml.m"
        gml__succeeded = (gml__Char_8 == (MR_Integer) 45);
#line 507 "gml.m"
        if (gml__succeeded)
          {
            MR_Word gml__V_15_15;

#line 506 "gml.m"
            {
#line 506 "gml.m"
              gml__V_15_15 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 506 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_15_15, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 506 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_15_15, 1) = ((MR_Box) (gml__HeadVar__1_1));
#line 506 "gml.m"
            }
#line 506 "gml.m"
            {
#line 506 "gml.m"
              gml__get_float_exponent_2_4_p_0(gml__V_15_15, gml__HeadVar__2_2);
#line 506 "gml.m"
              return;
            }
          }
#line 507 "gml.m"
        else
#line 509 "gml.m"
          {
#line 507 "gml.m"
            {
#line 507 "gml.m"
              gml__succeeded = mercury__char__is_digit_1_p_0(gml__Char_8);
            }
#line 509 "gml.m"
            if (gml__succeeded)
              {
                MR_Word gml__V_16_16;

#line 508 "gml.m"
                {
#line 508 "gml.m"
                  gml__V_16_16 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 508 "gml.m"
                  MR_hl_field(MR_mktag(1), gml__V_16_16, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 508 "gml.m"
                  MR_hl_field(MR_mktag(1), gml__V_16_16, 1) = ((MR_Box) (gml__HeadVar__1_1));
#line 508 "gml.m"
                }
#line 508 "gml.m"
                {
#line 508 "gml.m"
                  gml__get_float_exponent_3_4_p_0(gml__V_16_16, gml__HeadVar__2_2);
#line 508 "gml.m"
                  return;
                }
              }
#line 509 "gml.m"
            else
              {
                MR_String gml__V_17_17 = (MR_String) "float exponent";
                MR_Integer gml__Line_49;
                MR_String gml__Msg_50;
                MR_Word gml__V_53_53;
                MR_Word gml__V_54_54;
                MR_String gml__V_55_55;
                MR_Word gml__V_56_56;
                MR_String gml__V_57_57;
                MR_Word gml__V_58_58;
                MR_Word gml__V_59_59;
                MR_Word gml__V_60_60;
                MR_String gml__V_61_61;
                MR_Word gml__V_62_62;
                MR_Word gml__V_63_63;
                MR_Word gml__TypeInfo_22_64;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_float_exponent_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_49
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 626 "gml.m"
                gml__V_55_55 = (MR_String) "unexpected character `";
#line 627 "gml.m"
                gml__V_60_60 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 627 "gml.m"
                {
#line 627 "gml.m"
                  gml__V_59_59 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 627 "gml.m"
                  MR_hl_field(MR_mktag(1), gml__V_59_59, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 627 "gml.m"
                  MR_hl_field(MR_mktag(1), gml__V_59_59, 1) = ((MR_Box) (gml__V_60_60));
#line 627 "gml.m"
                }
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_exponent_4_p_0
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word CharList;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	CharList = 
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_59_59
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
		/* mode (out, in) is det */
	MR_Word char_list_ptr;
	size_t size;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `char_list_ptr'
*/
	size = sizeof(MR_Word);
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		size++;
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** loop to copy the characters from the char_list to the string
*/
	size = 0;
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		Str[size++] = MR_list_head(char_list_ptr);
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** null terminate the string
*/
	Str[size] = '\0';
}
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_57_57
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 627 "gml.m"
                gml__V_61_61 = (MR_String) "' in ";
#line 627 "gml.m"
                gml__V_63_63 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 627 "gml.m"
                gml__V_62_62 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_16_0_2_V_62_62);
#line 627 "gml.m"
                gml__V_58_58 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_16_0_3_V_58_58);
#line 626 "gml.m"
                {
#line 626 "gml.m"
                  gml__V_56_56 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 626 "gml.m"
                  MR_hl_field(MR_mktag(1), gml__V_56_56, 0) = ((MR_Box) (gml__V_57_57));
#line 626 "gml.m"
                  MR_hl_field(MR_mktag(1), gml__V_56_56, 1) = ((MR_Box) (gml__V_58_58));
#line 626 "gml.m"
                }
#line 625 "gml.m"
                {
#line 625 "gml.m"
                  gml__V_54_54 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 625 "gml.m"
                  MR_hl_field(MR_mktag(1), gml__V_54_54, 0) = ((MR_Box) (gml__V_55_55));
#line 625 "gml.m"
                  MR_hl_field(MR_mktag(1), gml__V_54_54, 1) = ((MR_Box) (gml__V_56_56));
#line 625 "gml.m"
                }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_exponent_4_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_54_54
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_50
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 628 "gml.m"
                {
#line 628 "gml.m"
                  gml__V_53_53 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 628 "gml.m"
                  MR_hl_field(MR_mktag(0), gml__V_53_53, 0) = ((MR_Box) (gml__Line_49));
#line 628 "gml.m"
                  MR_hl_field(MR_mktag(0), gml__V_53_53, 1) = ((MR_Box) (gml__Msg_50));
#line 628 "gml.m"
                }
                gml__TypeInfo_22_64 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 628 "gml.m"
                {
#line 628 "gml.m"
                  mercury__exception__throw_1_p_0(gml__TypeInfo_22_64, ((MR_Box) (gml__V_53_53)));
#line 628 "gml.m"
                  return;
                }
              }
#line 509 "gml.m"
          }
#line 504 "gml.m"
      }
  }
#line 498 "gml.m"
}
#line 588 "gml.m"
static /* final */ const MR_Box gml__const_15_0_1_V_36_36[2] = {
		((MR_Box) ((MR_String) "'")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 588 "gml.m"
static /* final */ const MR_Box gml__const_15_0_2_V_77_77[2] = {
		((MR_Box) ((MR_String) "'")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};

#line 478 "gml.m"
static void MR_CALL gml__get_float_decimals_4_p_0(
#line 478 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 478 "gml.m"
  MR_Word * gml__HeadVar__2_2)
#line 478 "gml.m"
{
  {
    /* tailcall optimized into a loop */
  loop_top:;
    {
      bool gml__succeeded;
      MR_Word gml__Result_7;

#line 483 "gml.m"
      {
#line 483 "gml.m"
        gml__lexer_read_char_3_p_0(&gml__Result_7);
      }
#line 486 "gml.m"
      if ((gml__Result_7 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
        {
          MR_String gml__String_20;
#line 585 "gml.m"
          MR_Float gml__Float_27;

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_decimals_4_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__HeadVar__1_1
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_20
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_decimals_4_p_0
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String FloatString;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Float FloatVal;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	FloatString = 
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_20
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	/* use a temporary, since we can't don't know whether FloatVal
	   is a double or float */
	double tmp;
	SUCCESS_INDICATOR = (sscanf(FloatString, "%lf", &tmp) == 1);
		/* TRUE if sscanf succeeds, FALSE otherwise */
	FloatVal = tmp;
}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	if (SUCCESS_INDICATOR) {
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Float_27
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = FloatVal;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__succeeded
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = SUCCESS_INDICATOR;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 585 "gml.m"
          if (gml__succeeded)
#line 584 "gml.m"
            {
#line 584 "gml.m"
              *gml__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 584 "gml.m"
              MR_hl_field(MR_mktag(1), *gml__HeadVar__2_2, 0) = MR_box_float(gml__Float_27);
#line 584 "gml.m"
            }
#line 585 "gml.m"
          else
            {
              MR_Integer gml__Line_28;
              MR_String gml__Msg_29;
              MR_Word gml__V_32_32;
              MR_Word gml__V_33_33;
              MR_String gml__V_34_34;
              MR_Word gml__V_35_35;
              MR_Word gml__V_36_36;
              MR_String gml__V_37_37;
              MR_Word gml__V_38_38;
              MR_Word gml__TypeInfo_19_39;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_float_decimals_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_28
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 588 "gml.m"
              gml__V_34_34 = (MR_String) "invalid float token `";
#line 588 "gml.m"
              gml__V_37_37 = (MR_String) "'";
#line 588 "gml.m"
              gml__V_38_38 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 588 "gml.m"
              gml__V_36_36 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_15_0_1_V_36_36);
#line 588 "gml.m"
              {
#line 588 "gml.m"
                gml__V_35_35 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 588 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_35_35, 0) = ((MR_Box) (gml__String_20));
#line 588 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_35_35, 1) = ((MR_Box) (gml__V_36_36));
#line 588 "gml.m"
              }
#line 587 "gml.m"
              {
#line 587 "gml.m"
                gml__V_33_33 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 587 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_33_33, 0) = ((MR_Box) (gml__V_34_34));
#line 587 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_33_33, 1) = ((MR_Box) (gml__V_35_35));
#line 587 "gml.m"
              }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_decimals_4_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_33_33
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_29
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 589 "gml.m"
              {
#line 589 "gml.m"
                gml__V_32_32 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 589 "gml.m"
                MR_hl_field(MR_mktag(0), gml__V_32_32, 0) = ((MR_Box) (gml__Line_28));
#line 589 "gml.m"
                MR_hl_field(MR_mktag(0), gml__V_32_32, 1) = ((MR_Box) (gml__Msg_29));
#line 589 "gml.m"
              }
              gml__TypeInfo_19_39 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 589 "gml.m"
              {
#line 589 "gml.m"
                mercury__exception__throw_1_p_0(gml__TypeInfo_19_39, ((MR_Box) (gml__V_32_32)));
#line 589 "gml.m"
                return;
              }
            }
        }
#line 486 "gml.m"
      else
#line 486 "gml.m"
        {
          MR_Char gml__Char_8 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(1), gml__Result_7, (MR_Integer) 0)));

#line 487 "gml.m"
          {
#line 487 "gml.m"
            gml__succeeded = mercury__char__is_digit_1_p_0(gml__Char_8);
          }
#line 489 "gml.m"
          if (gml__succeeded)
            {
              MR_Word gml__V_16_16;

#line 488 "gml.m"
              {
#line 488 "gml.m"
                gml__V_16_16 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 488 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_16_16, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 488 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_16_16, 1) = ((MR_Box) (gml__HeadVar__1_1));
#line 488 "gml.m"
              }
#line 488 "gml.m"
              {
#line 488 "gml.m"
                /* direct tailcall eliminated */
#line 488 "gml.m"
                {
#line 488 "gml.m"
                  MR_Word gml__HeadVar__1__tmp_copy_1 = gml__V_16_16;

#line 488 "gml.m"
                  gml__HeadVar__1_1 = gml__HeadVar__1__tmp_copy_1;
#line 488 "gml.m"
                }
#line 488 "gml.m"
                goto loop_top;
#line 488 "gml.m"
              }
            }
#line 489 "gml.m"
          else
#line 491 "gml.m"
            {
#line 489 "gml.m"
#line 489 "gml.m"
              switch (gml__Char_8) {
#line 489 "gml.m"
                default:
#line 489 "gml.m"
                  gml__succeeded = FALSE;
#line 489 "gml.m"
                  break;
#line 489 "gml.m"
                case (MR_Integer) 69:
                  gml__succeeded = TRUE;
#line 489 "gml.m"
                  break;
#line 489 "gml.m"
                case (MR_Integer) 101:
                  gml__succeeded = TRUE;
#line 489 "gml.m"
                  break;
#line 489 "gml.m"
              }
#line 491 "gml.m"
              if (gml__succeeded)
                {
                  MR_Word gml__V_17_17;

#line 490 "gml.m"
                  {
#line 490 "gml.m"
                    gml__V_17_17 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 490 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_17_17, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 490 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_17_17, 1) = ((MR_Box) (gml__HeadVar__1_1));
#line 490 "gml.m"
                  }
#line 490 "gml.m"
                  {
#line 490 "gml.m"
                    gml__get_float_exponent_4_p_0(gml__V_17_17, gml__HeadVar__2_2);
#line 490 "gml.m"
                    return;
                  }
                }
#line 491 "gml.m"
              else
                {
                  MR_Word gml__Stream_5_50;
                  MR_String gml__String_61;
#line 585 "gml.m"
                  MR_Float gml__Float_68;

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_float_decimals_4_p_0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_50
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_float_decimals_4_p_0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word File;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Char Character;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	File = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_50
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Character = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Char_8
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_decimals_4_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__HeadVar__1_1
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_61
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_decimals_4_p_0
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String FloatString;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Float FloatVal;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	FloatString = 
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_61
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	/* use a temporary, since we can't don't know whether FloatVal
	   is a double or float */
	double tmp;
	SUCCESS_INDICATOR = (sscanf(FloatString, "%lf", &tmp) == 1);
		/* TRUE if sscanf succeeds, FALSE otherwise */
	FloatVal = tmp;
}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	if (SUCCESS_INDICATOR) {
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Float_68
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = FloatVal;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	}
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__succeeded
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = SUCCESS_INDICATOR;
#line 268 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 585 "gml.m"
                  if (gml__succeeded)
#line 584 "gml.m"
                    {
#line 584 "gml.m"
                      *gml__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 584 "gml.m"
                      MR_hl_field(MR_mktag(1), *gml__HeadVar__2_2, 0) = MR_box_float(gml__Float_68);
#line 584 "gml.m"
                    }
#line 585 "gml.m"
                  else
                    {
                      MR_Integer gml__Line_69;
                      MR_String gml__Msg_70;
                      MR_Word gml__V_73_73;
                      MR_Word gml__V_74_74;
                      MR_String gml__V_75_75;
                      MR_Word gml__V_76_76;
                      MR_Word gml__V_77_77;
                      MR_String gml__V_78_78;
                      MR_Word gml__V_79_79;
                      MR_Word gml__TypeInfo_19_80;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_float_decimals_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_69
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 588 "gml.m"
                      gml__V_75_75 = (MR_String) "invalid float token `";
#line 588 "gml.m"
                      gml__V_78_78 = (MR_String) "'";
#line 588 "gml.m"
                      gml__V_79_79 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 588 "gml.m"
                      gml__V_77_77 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_15_0_2_V_77_77);
#line 588 "gml.m"
                      {
#line 588 "gml.m"
                        gml__V_76_76 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 588 "gml.m"
                        MR_hl_field(MR_mktag(1), gml__V_76_76, 0) = ((MR_Box) (gml__String_61));
#line 588 "gml.m"
                        MR_hl_field(MR_mktag(1), gml__V_76_76, 1) = ((MR_Box) (gml__V_77_77));
#line 588 "gml.m"
                      }
#line 587 "gml.m"
                      {
#line 587 "gml.m"
                        gml__V_74_74 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 587 "gml.m"
                        MR_hl_field(MR_mktag(1), gml__V_74_74, 0) = ((MR_Box) (gml__V_75_75));
#line 587 "gml.m"
                        MR_hl_field(MR_mktag(1), gml__V_74_74, 1) = ((MR_Box) (gml__V_76_76));
#line 587 "gml.m"
                      }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_float_decimals_4_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_74_74
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_70
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 589 "gml.m"
                      {
#line 589 "gml.m"
                        gml__V_73_73 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 589 "gml.m"
                        MR_hl_field(MR_mktag(0), gml__V_73_73, 0) = ((MR_Box) (gml__Line_69));
#line 589 "gml.m"
                        MR_hl_field(MR_mktag(0), gml__V_73_73, 1) = ((MR_Box) (gml__Msg_70));
#line 589 "gml.m"
                      }
                      gml__TypeInfo_19_80 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 589 "gml.m"
                      {
#line 589 "gml.m"
                        mercury__exception__throw_1_p_0(gml__TypeInfo_19_80, ((MR_Box) (gml__V_73_73)));
#line 589 "gml.m"
                        return;
                      }
                    }
                }
#line 491 "gml.m"
            }
#line 486 "gml.m"
        }
    }
  }
#line 478 "gml.m"
}
#line 568 "gml.m"
static /* final */ const MR_Box gml__const_14_0_1_V_56_56[2] = {
		((MR_Box) ((MR_String) "'")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};

#line 459 "gml.m"
static void MR_CALL gml__get_int_dot_4_p_0(
#line 459 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 459 "gml.m"
  MR_Word * gml__HeadVar__2_2)
#line 459 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Word gml__Result_7;

#line 462 "gml.m"
    {
#line 462 "gml.m"
      gml__lexer_read_char_3_p_0(&gml__Result_7);
    }
#line 466 "gml.m"
    if ((gml__Result_7 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
      {
        MR_Integer gml__V_22_22;
        MR_Char gml__V_23_23 = (MR_Integer) 46;
        MR_Word gml__Stream_5_27;
        MR_String gml__String_39;
#line 565 "gml.m"
        MR_Integer gml__Int_47;

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_int_dot_4_p_0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_27
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_int_dot_4_p_0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word File;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Char Character;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	File = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_27
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Character = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__V_23_23
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 465 "gml.m"
        gml__V_22_22 = (MR_Integer) 10;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_int_dot_4_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__HeadVar__1_1
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_39
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 563 "gml.m"
        {
#line 563 "gml.m"
          gml__succeeded = mercury__string__base_string_to_int_3_p_0(gml__V_22_22, gml__String_39, &gml__Int_47);
        }
#line 565 "gml.m"
        if (gml__succeeded)
#line 564 "gml.m"
          {
#line 564 "gml.m"
            *gml__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "integer");
#line 564 "gml.m"
            MR_hl_field(MR_mktag(0), *gml__HeadVar__2_2, 0) = ((MR_Box) (gml__Int_47));
#line 564 "gml.m"
          }
#line 565 "gml.m"
        else
          {
            MR_Integer gml__Line_48;
            MR_String gml__Msg_49;
            MR_Word gml__V_52_52;
            MR_Word gml__V_53_53;
            MR_String gml__V_54_54;
            MR_Word gml__V_55_55;
            MR_Word gml__V_56_56;
            MR_String gml__V_57_57;
            MR_Word gml__V_58_58;
            MR_Word gml__TypeInfo_21_59;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_int_dot_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_48
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 568 "gml.m"
            gml__V_54_54 = (MR_String) "invalid int token `";
#line 568 "gml.m"
            gml__V_57_57 = (MR_String) "'";
#line 568 "gml.m"
            gml__V_58_58 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 568 "gml.m"
            gml__V_56_56 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_14_0_1_V_56_56);
#line 568 "gml.m"
            {
#line 568 "gml.m"
              gml__V_55_55 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 568 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_55_55, 0) = ((MR_Box) (gml__String_39));
#line 568 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_55_55, 1) = ((MR_Box) (gml__V_56_56));
#line 568 "gml.m"
            }
#line 567 "gml.m"
            {
#line 567 "gml.m"
              gml__V_53_53 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 567 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_53_53, 0) = ((MR_Box) (gml__V_54_54));
#line 567 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_53_53, 1) = ((MR_Box) (gml__V_55_55));
#line 567 "gml.m"
            }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_int_dot_4_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_53_53
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_49
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 569 "gml.m"
            {
#line 569 "gml.m"
              gml__V_52_52 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 569 "gml.m"
              MR_hl_field(MR_mktag(0), gml__V_52_52, 0) = ((MR_Box) (gml__Line_48));
#line 569 "gml.m"
              MR_hl_field(MR_mktag(0), gml__V_52_52, 1) = ((MR_Box) (gml__Msg_49));
#line 569 "gml.m"
            }
            gml__TypeInfo_21_59 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 569 "gml.m"
            {
#line 569 "gml.m"
              mercury__exception__throw_1_p_0(gml__TypeInfo_21_59, ((MR_Box) (gml__V_52_52)));
#line 569 "gml.m"
              return;
            }
          }
      }
#line 466 "gml.m"
    else
#line 466 "gml.m"
      {
        MR_Char gml__Char_8 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(1), gml__Result_7, (MR_Integer) 0)));

#line 467 "gml.m"
        {
#line 467 "gml.m"
          gml__succeeded = mercury__char__is_digit_1_p_0(gml__Char_8);
        }
#line 469 "gml.m"
        if (gml__succeeded)
          {
            MR_Word gml__V_17_17;
            MR_Word gml__V_18_18;
            MR_Char gml__V_19_19 = (MR_Integer) 46;

#line 468 "gml.m"
            {
#line 468 "gml.m"
              gml__V_18_18 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 468 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_18_18, 0) = ((MR_Box) (MR_Word) (gml__V_19_19));
#line 468 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_18_18, 1) = ((MR_Box) (gml__HeadVar__1_1));
#line 468 "gml.m"
            }
#line 468 "gml.m"
            {
#line 468 "gml.m"
              gml__V_17_17 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 468 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_17_17, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 468 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_17_17, 1) = ((MR_Box) (gml__V_18_18));
#line 468 "gml.m"
            }
#line 468 "gml.m"
            {
#line 468 "gml.m"
              gml__get_float_decimals_4_p_0(gml__V_17_17, gml__HeadVar__2_2);
#line 468 "gml.m"
              return;
            }
          }
#line 469 "gml.m"
        else
          {
            MR_Integer gml__V_20_20;
            MR_Char gml__V_21_21;
            MR_Word gml__Stream_5_68;
            MR_Word gml__Stream_5_80;

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_int_dot_4_p_0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_68
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_int_dot_4_p_0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word File;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Char Character;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	File = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_68
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Character = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Char_8
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 471 "gml.m"
            gml__V_21_21 = (MR_Integer) 46;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_int_dot_4_p_0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_80
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_int_dot_4_p_0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word File;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Char Character;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	File = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_80
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Character = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__V_21_21
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 472 "gml.m"
            gml__V_20_20 = (MR_Integer) 10;
#line 472 "gml.m"
            {
#line 472 "gml.m"
              gml__rev_char_list_to_int_5_p_0(gml__HeadVar__1_1, gml__V_20_20, gml__HeadVar__2_2);
#line 472 "gml.m"
              return;
            }
          }
#line 466 "gml.m"
      }
  }
#line 459 "gml.m"
}
#line 568 "gml.m"
static /* final */ const MR_Box gml__const_13_0_1_V_41_41[2] = {
		((MR_Box) ((MR_String) "'")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 568 "gml.m"
static /* final */ const MR_Box gml__const_13_0_2_V_82_82[2] = {
		((MR_Box) ((MR_String) "'")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};

#line 439 "gml.m"
static void MR_CALL gml__get_number_4_p_0(
#line 439 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 439 "gml.m"
  MR_Word * gml__HeadVar__2_2)
#line 439 "gml.m"
{
  {
    /* tailcall optimized into a loop */
  loop_top:;
    {
      bool gml__succeeded;
      MR_Word gml__Result_7;

#line 442 "gml.m"
      {
#line 442 "gml.m"
        gml__lexer_read_char_3_p_0(&gml__Result_7);
      }
#line 445 "gml.m"
      if ((gml__Result_7 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
        {
          MR_Integer gml__V_20_20 = (MR_Integer) 10;
          MR_String gml__String_24;
#line 565 "gml.m"
          MR_Integer gml__Int_32;

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_number_4_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__HeadVar__1_1
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_24
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 563 "gml.m"
          {
#line 563 "gml.m"
            gml__succeeded = mercury__string__base_string_to_int_3_p_0(gml__V_20_20, gml__String_24, &gml__Int_32);
          }
#line 565 "gml.m"
          if (gml__succeeded)
#line 564 "gml.m"
            {
#line 564 "gml.m"
              *gml__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "integer");
#line 564 "gml.m"
              MR_hl_field(MR_mktag(0), *gml__HeadVar__2_2, 0) = ((MR_Box) (gml__Int_32));
#line 564 "gml.m"
            }
#line 565 "gml.m"
          else
            {
              MR_Integer gml__Line_33;
              MR_String gml__Msg_34;
              MR_Word gml__V_37_37;
              MR_Word gml__V_38_38;
              MR_String gml__V_39_39;
              MR_Word gml__V_40_40;
              MR_Word gml__V_41_41;
              MR_String gml__V_42_42;
              MR_Word gml__V_43_43;
              MR_Word gml__TypeInfo_21_44;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_number_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_33
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 568 "gml.m"
              gml__V_39_39 = (MR_String) "invalid int token `";
#line 568 "gml.m"
              gml__V_42_42 = (MR_String) "'";
#line 568 "gml.m"
              gml__V_43_43 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 568 "gml.m"
              gml__V_41_41 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_13_0_1_V_41_41);
#line 568 "gml.m"
              {
#line 568 "gml.m"
                gml__V_40_40 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 568 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_40_40, 0) = ((MR_Box) (gml__String_24));
#line 568 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_40_40, 1) = ((MR_Box) (gml__V_41_41));
#line 568 "gml.m"
              }
#line 567 "gml.m"
              {
#line 567 "gml.m"
                gml__V_38_38 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 567 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_38_38, 0) = ((MR_Box) (gml__V_39_39));
#line 567 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_38_38, 1) = ((MR_Box) (gml__V_40_40));
#line 567 "gml.m"
              }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_number_4_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_38_38
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_34
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 569 "gml.m"
              {
#line 569 "gml.m"
                gml__V_37_37 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 569 "gml.m"
                MR_hl_field(MR_mktag(0), gml__V_37_37, 0) = ((MR_Box) (gml__Line_33));
#line 569 "gml.m"
                MR_hl_field(MR_mktag(0), gml__V_37_37, 1) = ((MR_Box) (gml__Msg_34));
#line 569 "gml.m"
              }
              gml__TypeInfo_21_44 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 569 "gml.m"
              {
#line 569 "gml.m"
                mercury__exception__throw_1_p_0(gml__TypeInfo_21_44, ((MR_Box) (gml__V_37_37)));
#line 569 "gml.m"
                return;
              }
            }
        }
#line 445 "gml.m"
      else
#line 445 "gml.m"
        {
          MR_Char gml__Char_8 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(1), gml__Result_7, (MR_Integer) 0)));

#line 446 "gml.m"
          {
#line 446 "gml.m"
            gml__succeeded = mercury__char__is_digit_1_p_0(gml__Char_8);
          }
#line 448 "gml.m"
          if (gml__succeeded)
            {
              MR_Word gml__V_17_17;

#line 447 "gml.m"
              {
#line 447 "gml.m"
                gml__V_17_17 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 447 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_17_17, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 447 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_17_17, 1) = ((MR_Box) (gml__HeadVar__1_1));
#line 447 "gml.m"
              }
#line 447 "gml.m"
              {
#line 447 "gml.m"
                /* direct tailcall eliminated */
#line 447 "gml.m"
                {
#line 447 "gml.m"
                  MR_Word gml__HeadVar__1__tmp_copy_1 = gml__V_17_17;

#line 447 "gml.m"
                  gml__HeadVar__1_1 = gml__HeadVar__1__tmp_copy_1;
#line 447 "gml.m"
                }
#line 447 "gml.m"
                goto loop_top;
#line 447 "gml.m"
              }
            }
#line 448 "gml.m"
          else
#line 450 "gml.m"
            {
#line 448 "gml.m"
              gml__succeeded = (gml__Char_8 == (MR_Integer) 46);
#line 450 "gml.m"
              if (gml__succeeded)
#line 449 "gml.m"
                {
#line 449 "gml.m"
                  gml__get_int_dot_4_p_0(gml__HeadVar__1_1, gml__HeadVar__2_2);
#line 449 "gml.m"
                  return;
                }
#line 450 "gml.m"
              else
#line 452 "gml.m"
                {
#line 450 "gml.m"
#line 450 "gml.m"
                  switch (gml__Char_8) {
#line 450 "gml.m"
                    default:
#line 450 "gml.m"
                      gml__succeeded = FALSE;
#line 450 "gml.m"
                      break;
#line 450 "gml.m"
                    case (MR_Integer) 69:
                      gml__succeeded = TRUE;
#line 450 "gml.m"
                      break;
#line 450 "gml.m"
                    case (MR_Integer) 101:
                      gml__succeeded = TRUE;
#line 450 "gml.m"
                      break;
#line 450 "gml.m"
                  }
#line 452 "gml.m"
                  if (gml__succeeded)
                    {
                      MR_Word gml__V_18_18;

#line 451 "gml.m"
                      {
#line 451 "gml.m"
                        gml__V_18_18 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 451 "gml.m"
                        MR_hl_field(MR_mktag(1), gml__V_18_18, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 451 "gml.m"
                        MR_hl_field(MR_mktag(1), gml__V_18_18, 1) = ((MR_Box) (gml__HeadVar__1_1));
#line 451 "gml.m"
                      }
#line 451 "gml.m"
                      {
#line 451 "gml.m"
                        gml__get_float_exponent_4_p_0(gml__V_18_18, gml__HeadVar__2_2);
#line 451 "gml.m"
                        return;
                      }
                    }
#line 452 "gml.m"
                  else
                    {
                      MR_Integer gml__V_19_19;
                      MR_Word gml__Stream_5_53;
                      MR_String gml__String_65;
#line 565 "gml.m"
                      MR_Integer gml__Int_73;

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_number_4_p_0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_53
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_number_4_p_0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word File;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Char Character;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	File = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_53
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Character = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Char_8
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 454 "gml.m"
                      gml__V_19_19 = (MR_Integer) 10;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_number_4_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__HeadVar__1_1
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__String_65
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 563 "gml.m"
                      {
#line 563 "gml.m"
                        gml__succeeded = mercury__string__base_string_to_int_3_p_0(gml__V_19_19, gml__String_65, &gml__Int_73);
                      }
#line 565 "gml.m"
                      if (gml__succeeded)
#line 564 "gml.m"
                        {
#line 564 "gml.m"
                          *gml__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "integer");
#line 564 "gml.m"
                          MR_hl_field(MR_mktag(0), *gml__HeadVar__2_2, 0) = ((MR_Box) (gml__Int_73));
#line 564 "gml.m"
                        }
#line 565 "gml.m"
                      else
                        {
                          MR_Integer gml__Line_74;
                          MR_String gml__Msg_75;
                          MR_Word gml__V_78_78;
                          MR_Word gml__V_79_79;
                          MR_String gml__V_80_80;
                          MR_Word gml__V_81_81;
                          MR_Word gml__V_82_82;
                          MR_String gml__V_83_83;
                          MR_Word gml__V_84_84;
                          MR_Word gml__TypeInfo_21_85;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_number_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_74
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 568 "gml.m"
                          gml__V_80_80 = (MR_String) "invalid int token `";
#line 568 "gml.m"
                          gml__V_83_83 = (MR_String) "'";
#line 568 "gml.m"
                          gml__V_84_84 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 568 "gml.m"
                          gml__V_82_82 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_13_0_2_V_82_82);
#line 568 "gml.m"
                          {
#line 568 "gml.m"
                            gml__V_81_81 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 568 "gml.m"
                            MR_hl_field(MR_mktag(1), gml__V_81_81, 0) = ((MR_Box) (gml__String_65));
#line 568 "gml.m"
                            MR_hl_field(MR_mktag(1), gml__V_81_81, 1) = ((MR_Box) (gml__V_82_82));
#line 568 "gml.m"
                          }
#line 567 "gml.m"
                          {
#line 567 "gml.m"
                            gml__V_79_79 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 567 "gml.m"
                            MR_hl_field(MR_mktag(1), gml__V_79_79, 0) = ((MR_Box) (gml__V_80_80));
#line 567 "gml.m"
                            MR_hl_field(MR_mktag(1), gml__V_79_79, 1) = ((MR_Box) (gml__V_81_81));
#line 567 "gml.m"
                          }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_number_4_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_79_79
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_75
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 569 "gml.m"
                          {
#line 569 "gml.m"
                            gml__V_78_78 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 569 "gml.m"
                            MR_hl_field(MR_mktag(0), gml__V_78_78, 0) = ((MR_Box) (gml__Line_74));
#line 569 "gml.m"
                            MR_hl_field(MR_mktag(0), gml__V_78_78, 1) = ((MR_Box) (gml__Msg_75));
#line 569 "gml.m"
                          }
                          gml__TypeInfo_21_85 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 569 "gml.m"
                          {
#line 569 "gml.m"
                            mercury__exception__throw_1_p_0(gml__TypeInfo_21_85, ((MR_Box) (gml__V_78_78)));
#line 569 "gml.m"
                            return;
                          }
                        }
                    }
#line 452 "gml.m"
                }
#line 450 "gml.m"
            }
#line 445 "gml.m"
        }
    }
  }
#line 439 "gml.m"
}
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_12_0_1_V_49_49[2] = {
		((MR_Box) ((MR_String) "string")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_12_0_2_V_45_45[2] = {
		((MR_Box) ((MR_String) "' in ")),
		((MR_Box) (MR_mkword(MR_mktag(1), &gml__const_12_0_1_V_49_49)))};

#line 419 "gml.m"
static void MR_CALL gml__get_string_4_p_0(
#line 419 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 419 "gml.m"
  MR_String * gml__HeadVar__2_2)
#line 419 "gml.m"
{
  {
    /* tailcall optimized into a loop */
  loop_top:;
    {
      bool gml__succeeded;
      MR_Word gml__CharResult_7;

#line 423 "gml.m"
      {
#line 423 "gml.m"
        gml__lexer_read_char_3_p_0(&gml__CharResult_7);
      }
#line 433 "gml.m"
      if ((gml__CharResult_7 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
        {
          MR_String gml__V_14_14 = (MR_String) "string constant";
          MR_Integer gml__Line_18;
          MR_String gml__Msg_19;
          MR_Word gml__V_22_22;
          MR_String gml__V_23_23;
          MR_Word gml__TypeInfo_11_24;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_string_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_18
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 617 "gml.m"
          gml__V_23_23 = (MR_String) "unexpected end-of-file in ";
#line 76 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
          {
#line 76 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
            mercury__string__append_3_p_2(gml__V_23_23, gml__V_14_14, &gml__Msg_19);
          }
#line 618 "gml.m"
          {
#line 618 "gml.m"
            gml__V_22_22 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 618 "gml.m"
            MR_hl_field(MR_mktag(0), gml__V_22_22, 0) = ((MR_Box) (gml__Line_18));
#line 618 "gml.m"
            MR_hl_field(MR_mktag(0), gml__V_22_22, 1) = ((MR_Box) (gml__Msg_19));
#line 618 "gml.m"
          }
          gml__TypeInfo_11_24 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 618 "gml.m"
          {
#line 618 "gml.m"
            mercury__exception__throw_1_p_0(gml__TypeInfo_11_24, ((MR_Box) (gml__V_22_22)));
#line 618 "gml.m"
            return;
          }
        }
#line 433 "gml.m"
      else
#line 433 "gml.m"
        {
          MR_Char gml__Char_8 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(1), gml__CharResult_7, (MR_Integer) 0)));

#line 426 "gml.m"
          gml__succeeded = (gml__Char_8 == (MR_Integer) 34);
#line 428 "gml.m"
          if (gml__succeeded)
            {
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_string_4_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__HeadVar__1_1
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
*gml__HeadVar__2_2
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
            }
#line 428 "gml.m"
          else
#line 430 "gml.m"
            {
#line 299 "gml.m"
              {
#line 299 "gml.m"
                gml__succeeded = mercury__char__is_alnum_or_underscore_1_p_0(gml__Char_8);
              }
#line 300 "gml.m"
              if (!(gml__succeeded))
#line 305 "gml.m"
#line 305 "gml.m"
                switch (gml__Char_8) {
#line 305 "gml.m"
                  default:
#line 305 "gml.m"
                    gml__succeeded = FALSE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 32:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 33:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 34:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 35:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 36:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 37:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 38:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 39:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 40:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 41:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 42:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 43:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 44:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 45:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 46:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 47:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 58:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 59:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 60:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 61:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 62:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 63:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 64:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 91:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 92:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 93:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 94:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 95:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 96:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 123:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 124:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 125:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                  case (MR_Integer) 126:
                    gml__succeeded = TRUE;
#line 305 "gml.m"
                    break;
#line 305 "gml.m"
                }
#line 430 "gml.m"
              if (gml__succeeded)
                {
                  MR_Word gml__V_15_15;

#line 429 "gml.m"
                  {
#line 429 "gml.m"
                    gml__V_15_15 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 429 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_15_15, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 429 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_15_15, 1) = ((MR_Box) (gml__HeadVar__1_1));
#line 429 "gml.m"
                  }
#line 429 "gml.m"
                  {
#line 429 "gml.m"
                    /* direct tailcall eliminated */
#line 429 "gml.m"
                    {
#line 429 "gml.m"
                      MR_Word gml__HeadVar__1__tmp_copy_1 = gml__V_15_15;

#line 429 "gml.m"
                      gml__HeadVar__1_1 = gml__HeadVar__1__tmp_copy_1;
#line 429 "gml.m"
                    }
#line 429 "gml.m"
                    goto loop_top;
#line 429 "gml.m"
                  }
                }
#line 430 "gml.m"
              else
                {
                  MR_String gml__V_16_16 = (MR_String) "string";
                  MR_Integer gml__Line_36;
                  MR_String gml__Msg_37;
                  MR_Word gml__V_40_40;
                  MR_Word gml__V_41_41;
                  MR_String gml__V_42_42;
                  MR_Word gml__V_43_43;
                  MR_String gml__V_44_44;
                  MR_Word gml__V_45_45;
                  MR_Word gml__V_46_46;
                  MR_Word gml__V_47_47;
                  MR_String gml__V_48_48;
                  MR_Word gml__V_49_49;
                  MR_Word gml__V_50_50;
                  MR_Word gml__TypeInfo_22_51;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_string_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_36
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 626 "gml.m"
                  gml__V_42_42 = (MR_String) "unexpected character `";
#line 627 "gml.m"
                  gml__V_47_47 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 627 "gml.m"
                  {
#line 627 "gml.m"
                    gml__V_46_46 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 627 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_46_46, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 627 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_46_46, 1) = ((MR_Box) (gml__V_47_47));
#line 627 "gml.m"
                  }
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_string_4_p_0
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word CharList;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	CharList = 
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_46_46
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
		/* mode (out, in) is det */
	MR_Word char_list_ptr;
	size_t size;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `char_list_ptr'
*/
	size = sizeof(MR_Word);
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		size++;
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** loop to copy the characters from the char_list to the string
*/
	size = 0;
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		Str[size++] = MR_list_head(char_list_ptr);
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** null terminate the string
*/
	Str[size] = '\0';
}
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_44_44
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 627 "gml.m"
                  gml__V_48_48 = (MR_String) "' in ";
#line 627 "gml.m"
                  gml__V_50_50 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 627 "gml.m"
                  gml__V_49_49 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_12_0_1_V_49_49);
#line 627 "gml.m"
                  gml__V_45_45 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_12_0_2_V_45_45);
#line 626 "gml.m"
                  {
#line 626 "gml.m"
                    gml__V_43_43 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 626 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_43_43, 0) = ((MR_Box) (gml__V_44_44));
#line 626 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_43_43, 1) = ((MR_Box) (gml__V_45_45));
#line 626 "gml.m"
                  }
#line 625 "gml.m"
                  {
#line 625 "gml.m"
                    gml__V_41_41 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 625 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_41_41, 0) = ((MR_Box) (gml__V_42_42));
#line 625 "gml.m"
                    MR_hl_field(MR_mktag(1), gml__V_41_41, 1) = ((MR_Box) (gml__V_43_43));
#line 625 "gml.m"
                  }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_string_4_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_41_41
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_37
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 628 "gml.m"
                  {
#line 628 "gml.m"
                    gml__V_40_40 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 628 "gml.m"
                    MR_hl_field(MR_mktag(0), gml__V_40_40, 0) = ((MR_Box) (gml__Line_36));
#line 628 "gml.m"
                    MR_hl_field(MR_mktag(0), gml__V_40_40, 1) = ((MR_Box) (gml__Msg_37));
#line 628 "gml.m"
                  }
                  gml__TypeInfo_22_51 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 628 "gml.m"
                  {
#line 628 "gml.m"
                    mercury__exception__throw_1_p_0(gml__TypeInfo_22_51, ((MR_Box) (gml__V_40_40)));
#line 628 "gml.m"
                    return;
                  }
                }
#line 430 "gml.m"
            }
#line 433 "gml.m"
        }
    }
  }
#line 419 "gml.m"
}

#line 397 "gml.m"
static void MR_CALL gml__get_identifier_4_p_0(
#line 397 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 397 "gml.m"
  MR_String * gml__HeadVar__2_2)
#line 397 "gml.m"
{
  {
    /* tailcall optimized into a loop */
  loop_top:;
    {
      bool gml__succeeded;
      MR_Word gml__CharResult_7;
#line 414 "gml.m"
      MR_Char gml__Char_8;

#line 401 "gml.m"
      {
#line 401 "gml.m"
        gml__lexer_read_char_3_p_0(&gml__CharResult_7);
      }
#line 414 "gml.m"
      if ((gml__CharResult_7 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
        {
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_identifier_4_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__HeadVar__1_1
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
*gml__HeadVar__2_2
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
        }
#line 414 "gml.m"
      else
#line 414 "gml.m"
        {
#line 410 "gml.m"
          MR_Word gml__V_13_13;
#line 410 "gml.m"
          MR_Word gml__Stream_5_19;

#line 403 "gml.m"
          gml__Char_8 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(1), gml__CharResult_7, (MR_Integer) 0)));
#line 405 "gml.m"
          {
#line 405 "gml.m"
            gml__succeeded = mercury__char__is_alnum_or_underscore_1_p_0(gml__Char_8);
          }
#line 406 "gml.m"
          if (!(gml__succeeded))
#line 406 "gml.m"
            gml__succeeded = (gml__Char_8 == (MR_Integer) 45);
#line 410 "gml.m"
          if (gml__succeeded)
            {
#line 409 "gml.m"
              {
#line 409 "gml.m"
                gml__V_13_13 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 409 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_13_13, 0) = ((MR_Box) (MR_Word) (gml__Char_8));
#line 409 "gml.m"
                MR_hl_field(MR_mktag(1), gml__V_13_13, 1) = ((MR_Box) (gml__HeadVar__1_1));
#line 409 "gml.m"
              }
#line 409 "gml.m"
              {
#line 409 "gml.m"
                /* direct tailcall eliminated */
#line 409 "gml.m"
                {
#line 409 "gml.m"
                  MR_Word gml__HeadVar__1__tmp_copy_1 = gml__V_13_13;

#line 409 "gml.m"
                  gml__HeadVar__1_1 = gml__HeadVar__1__tmp_copy_1;
#line 409 "gml.m"
                }
#line 409 "gml.m"
                goto loop_top;
#line 409 "gml.m"
              }
            }
#line 410 "gml.m"
          else
            {
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_identifier_4_p_0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Stream = (MR_Word) mercury_current_text_input;
	update_io(IO0, IO);

#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_19
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Stream;
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 384 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_identifier_4_p_0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word File;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Char Character;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	File = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Stream_5_19
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Character = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Char_8
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
	MercuryFile* mf = (MercuryFile *) File;
	if (Character == '\n') {
		MR_line_number(*mf)--;
	}
	/* XXX should work even if ungetc() fails */
	if (MR_UNGETCH(*mf, Character) == EOF) {
		mercury_io_error(mf, "io__putback_char: ungetc failed");
	}
	update_io(IO0, IO);
}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 239 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_identifier_4_p_0
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Chars;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Chars = 
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__HeadVar__1_1
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

{
	MR_Word list_ptr;
	MR_Word size, len;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `list_ptr' and separately count the length of the string
*/
	size = sizeof(MR_Word);
	len = 1;
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		size++;
		len++;
		list_ptr = MR_list_tail(list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** set size to be the offset of the end of the string
** (ie the \0) and null terminate the string.
*/
	Str[--len] = '\0';
/*
** loop to copy the characters from the list_ptr to the string
** in reverse order.
*/
	list_ptr = Chars;
	while (!MR_list_is_empty(list_ptr)) {
		Str[--len] = (MR_Char) MR_list_head(list_ptr);
		list_ptr = MR_list_tail(list_ptr);
	}
}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
*gml__HeadVar__2_2
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 225 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
            }
#line 414 "gml.m"
        }
    }
  }
#line 397 "gml.m"
}
#line 346 "gml.m"
static /* final */ const int gml__const_10_0_1_next_slots_table[128] = {
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) 1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) 2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) 3,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) 5,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) 8,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -1,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -2,
		(MR_Integer) -1,
		(MR_Integer) -2};
#line 346 "gml.m"
static /* final */ const MR_String gml__const_10_0_2_string_table[128] = {
		NULL,
		(MR_String) "floor",
		(MR_String) "addf",
		(MR_String) "addi",
		(MR_String) "rotatez",
		(MR_String) "divi",
		(MR_String) "rotatex",
		(MR_String) "rotatey",
		(MR_String) "acos",
		NULL,
		(MR_String) "cylinder",
		NULL,
		(MR_String) "intersect",
		NULL,
		NULL,
		NULL,
		NULL,
		(MR_String) "asin",
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		(MR_String) "pointlight",
		NULL,
		NULL,
		NULL,
		(MR_String) "cos",
		(MR_String) "scale",
		NULL,
		NULL,
		(MR_String) "sqrt",
		(MR_String) "negi",
		NULL,
		(MR_String) "cone",
		NULL,
		(MR_String) "lessi",
		(MR_String) "subf",
		NULL,
		NULL,
		(MR_String) "subi",
		(MR_String) "lessf",
		(MR_String) "modi",
		(MR_String) "render",
		(MR_String) "if",
		(MR_String) "negf",
		NULL,
		NULL,
		NULL,
		NULL,
		(MR_String) "plane",
		NULL,
		(MR_String) "cube",
		(MR_String) "mulf",
		NULL,
		NULL,
		(MR_String) "muli",
		NULL,
		NULL,
		NULL,
		(MR_String) "difference",
		NULL,
		(MR_String) "sphere",
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		(MR_String) "point",
		NULL,
		(MR_String) "uscale",
		NULL,
		NULL,
		NULL,
		(MR_String) "spotlight",
		NULL,
		(MR_String) "eqf",
		NULL,
		(MR_String) "clampf",
		NULL,
		(MR_String) "get",
		(MR_String) "union",
		(MR_String) "sin",
		NULL,
		(MR_String) "divf",
		(MR_String) "length",
		(MR_String) "light",
		NULL,
		NULL,
		(MR_String) "eqi",
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		(MR_String) "getz",
		NULL,
		(MR_String) "getx",
		(MR_String) "gety",
		NULL,
		NULL,
		NULL,
		(MR_String) "translate",
		NULL,
		(MR_String) "apply",
		(MR_String) "frac",
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		(MR_String) "real",
		NULL};

#line 343 "gml.m"
static bool MR_CALL gml__is_operator_2_p_0(
#line 343 "gml.m"
  MR_String gml__HeadVar__1_1,
#line 343 "gml.m"
  MR_Word * gml__HeadVar__2_2)
#line 343 "gml.m"
{
#line 346 "gml.m"
  {
#line 346 "gml.m"
    bool gml__succeeded;
#line 346 "gml.m"
    int gml__slot_1;
#line 346 "gml.m"
    MR_String gml__str_2;

#line 346 "gml.m"
    /* hashed string switch */
#line 346 "gml.m"
    /* compute the hash value of the input string */
#line 346 "gml.m"
    gml__slot_1 = (MR_hash_string(gml__HeadVar__1_1) & (MR_Integer) 127);
#line 346 "gml.m"
    /* hash chain loop */
#line 346 "gml.m"
    do
#line 346 "gml.m"
      {
#line 346 "gml.m"
        /* lookup the string for this hash slot */
#line 346 "gml.m"
        gml__str_2 = gml__const_10_0_2_string_table[gml__slot_1];
#line 346 "gml.m"
        /* did we find a match? */
#line 346 "gml.m"
        if (((gml__str_2 != NULL) && (strcmp(gml__str_2, gml__HeadVar__1_1) == 0)))
#line 346 "gml.m"
          {
#line 346 "gml.m"
            /* we found a match */
#line 346 "gml.m"
            /* dispatch to the corresponding code */
#line 346 "gml.m"
#line 346 "gml.m"
            switch (gml__slot_1) {
#line 346 "gml.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 346 "gml.m"
              case (MR_Integer) 1:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "floor" */
#line 361 "gml.m"
                  {
#line 361 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 15;
#line 361 "gml.m"
                    gml__succeeded = TRUE;
#line 361 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 2:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "addf" */
#line 348 "gml.m"
                  {
#line 348 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 2;
#line 348 "gml.m"
                    gml__succeeded = TRUE;
#line 348 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 3:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "addi" */
#line 347 "gml.m"
                  {
#line 347 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 1;
#line 347 "gml.m"
                    gml__succeeded = TRUE;
#line 347 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 4:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "rotatez" */
#line 385 "gml.m"
                  {
#line 385 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 39;
#line 385 "gml.m"
                    gml__succeeded = TRUE;
#line 385 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 5:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "divi" */
#line 357 "gml.m"
                  {
#line 357 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 11;
#line 357 "gml.m"
                    gml__succeeded = TRUE;
#line 357 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 6:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "rotatex" */
#line 383 "gml.m"
                  {
#line 383 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 37;
#line 383 "gml.m"
                    gml__succeeded = TRUE;
#line 383 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 7:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "rotatey" */
#line 384 "gml.m"
                  {
#line 384 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 38;
#line 384 "gml.m"
                    gml__succeeded = TRUE;
#line 384 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 8:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "acos" */
#line 346 "gml.m"
                  {
#line 346 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 0;
#line 346 "gml.m"
                    gml__succeeded = TRUE;
#line 346 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 10:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "cylinder" */
#line 355 "gml.m"
                  {
#line 355 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 9;
#line 355 "gml.m"
                    gml__succeeded = TRUE;
#line 355 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 12:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "intersect" */
#line 368 "gml.m"
                  {
#line 368 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 22;
#line 368 "gml.m"
                    gml__succeeded = TRUE;
#line 368 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 17:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "asin" */
#line 350 "gml.m"
                  {
#line 350 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 4;
#line 350 "gml.m"
                    gml__succeeded = TRUE;
#line 350 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 24:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "pointlight" */
#line 380 "gml.m"
                  {
#line 380 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 34;
#line 380 "gml.m"
                    gml__succeeded = TRUE;
#line 380 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 28:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "cos" */
#line 353 "gml.m"
                  {
#line 353 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 7;
#line 353 "gml.m"
                    gml__succeeded = TRUE;
#line 353 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 29:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "scale" */
#line 386 "gml.m"
                  {
#line 386 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 40;
#line 386 "gml.m"
                    gml__succeeded = TRUE;
#line 386 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 32:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "sqrt" */
#line 390 "gml.m"
                  {
#line 390 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 44;
#line 390 "gml.m"
                    gml__succeeded = TRUE;
#line 390 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 33:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "negi" */
#line 376 "gml.m"
                  {
#line 376 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 30;
#line 376 "gml.m"
                    gml__succeeded = TRUE;
#line 376 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 35:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "cone" */
#line 352 "gml.m"
                  {
#line 352 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 6;
#line 352 "gml.m"
                    gml__succeeded = TRUE;
#line 352 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 37:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "lessi" */
#line 370 "gml.m"
                  {
#line 370 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 24;
#line 370 "gml.m"
                    gml__succeeded = TRUE;
#line 370 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 38:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "subf" */
#line 392 "gml.m"
                  {
#line 392 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 46;
#line 392 "gml.m"
                    gml__succeeded = TRUE;
#line 392 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 41:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "subi" */
#line 391 "gml.m"
                  {
#line 391 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 45;
#line 391 "gml.m"
                    gml__succeeded = TRUE;
#line 391 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 42:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "lessf" */
#line 371 "gml.m"
                  {
#line 371 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 25;
#line 371 "gml.m"
                    gml__succeeded = TRUE;
#line 371 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 43:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "modi" */
#line 373 "gml.m"
                  {
#line 373 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 27;
#line 373 "gml.m"
                    gml__succeeded = TRUE;
#line 373 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 44:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "render" */
#line 382 "gml.m"
                  {
#line 382 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 36;
#line 382 "gml.m"
                    gml__succeeded = TRUE;
#line 382 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 45:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "if" */
#line 367 "gml.m"
                  {
#line 367 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 21;
#line 367 "gml.m"
                    gml__succeeded = TRUE;
#line 367 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 46:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "negf" */
#line 377 "gml.m"
                  {
#line 377 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 31;
#line 377 "gml.m"
                    gml__succeeded = TRUE;
#line 377 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 51:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "plane" */
#line 378 "gml.m"
                  {
#line 378 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 32;
#line 378 "gml.m"
                    gml__succeeded = TRUE;
#line 378 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 53:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "cube" */
#line 354 "gml.m"
                  {
#line 354 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 8;
#line 354 "gml.m"
                    gml__succeeded = TRUE;
#line 354 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 54:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "mulf" */
#line 375 "gml.m"
                  {
#line 375 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 29;
#line 375 "gml.m"
                    gml__succeeded = TRUE;
#line 375 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 57:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "muli" */
#line 374 "gml.m"
                  {
#line 374 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 28;
#line 374 "gml.m"
                    gml__succeeded = TRUE;
#line 374 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 61:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "difference" */
#line 356 "gml.m"
                  {
#line 356 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 10;
#line 356 "gml.m"
                    gml__succeeded = TRUE;
#line 356 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 63:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "sphere" */
#line 388 "gml.m"
                  {
#line 388 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 42;
#line 388 "gml.m"
                    gml__succeeded = TRUE;
#line 388 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 73:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "point" */
#line 379 "gml.m"
                  {
#line 379 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 33;
#line 379 "gml.m"
                    gml__succeeded = TRUE;
#line 379 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 75:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "uscale" */
#line 395 "gml.m"
                  {
#line 395 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 49;
#line 395 "gml.m"
                    gml__succeeded = TRUE;
#line 395 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 79:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "spotlight" */
#line 389 "gml.m"
                  {
#line 389 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 43;
#line 389 "gml.m"
                    gml__succeeded = TRUE;
#line 389 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 81:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "eqf" */
#line 360 "gml.m"
                  {
#line 360 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 14;
#line 360 "gml.m"
                    gml__succeeded = TRUE;
#line 360 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 83:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "clampf" */
#line 351 "gml.m"
                  {
#line 351 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 5;
#line 351 "gml.m"
                    gml__succeeded = TRUE;
#line 351 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 85:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "get" */
#line 363 "gml.m"
                  {
#line 363 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 17;
#line 363 "gml.m"
                    gml__succeeded = TRUE;
#line 363 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 86:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "union" */
#line 394 "gml.m"
                  {
#line 394 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 48;
#line 394 "gml.m"
                    gml__succeeded = TRUE;
#line 394 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 87:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "sin" */
#line 387 "gml.m"
                  {
#line 387 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 41;
#line 387 "gml.m"
                    gml__succeeded = TRUE;
#line 387 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 89:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "divf" */
#line 358 "gml.m"
                  {
#line 358 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 12;
#line 358 "gml.m"
                    gml__succeeded = TRUE;
#line 358 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 90:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "length" */
#line 369 "gml.m"
                  {
#line 369 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 23;
#line 369 "gml.m"
                    gml__succeeded = TRUE;
#line 369 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 91:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "light" */
#line 372 "gml.m"
                  {
#line 372 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 26;
#line 372 "gml.m"
                    gml__succeeded = TRUE;
#line 372 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 94:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "eqi" */
#line 359 "gml.m"
                  {
#line 359 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 13;
#line 359 "gml.m"
                    gml__succeeded = TRUE;
#line 359 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 104:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "getz" */
#line 366 "gml.m"
                  {
#line 366 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 20;
#line 366 "gml.m"
                    gml__succeeded = TRUE;
#line 366 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 106:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "getx" */
#line 364 "gml.m"
                  {
#line 364 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 18;
#line 364 "gml.m"
                    gml__succeeded = TRUE;
#line 364 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 107:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "gety" */
#line 365 "gml.m"
                  {
#line 365 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 19;
#line 365 "gml.m"
                    gml__succeeded = TRUE;
#line 365 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 111:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "translate" */
#line 393 "gml.m"
                  {
#line 393 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 47;
#line 393 "gml.m"
                    gml__succeeded = TRUE;
#line 393 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 113:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "apply" */
#line 349 "gml.m"
                  {
#line 349 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 3;
#line 349 "gml.m"
                    gml__succeeded = TRUE;
#line 349 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 114:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "frac" */
#line 362 "gml.m"
                  {
#line 362 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 16;
#line 362 "gml.m"
                    gml__succeeded = TRUE;
#line 362 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
              case (MR_Integer) 126:
#line 346 "gml.m"
                {
#line 346 "gml.m"
                  /* case "real" */
#line 381 "gml.m"
                  {
#line 381 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Integer) 35;
#line 381 "gml.m"
                    gml__succeeded = TRUE;
#line 381 "gml.m"
                  }
#line 346 "gml.m"
                }
#line 346 "gml.m"
                break;
#line 346 "gml.m"
            }
#line 346 "gml.m"
            goto label_1;
#line 346 "gml.m"
          }
#line 346 "gml.m"
        /* no match yet, so get next slot in hash chain */
#line 346 "gml.m"
        gml__slot_1 = gml__const_10_0_1_next_slots_table[gml__slot_1];
#line 346 "gml.m"
      }
#line 346 "gml.m"
    while ((gml__slot_1 >= (MR_Integer) 0));
#line 346 "gml.m"
    /* no match, so fail */
#line 346 "gml.m"
    gml__succeeded = FALSE;
#line 346 "gml.m"
  label_1:;
#line 346 "gml.m"
    /* end of hashed string switch */
#line 346 "gml.m"
    return gml__succeeded;
#line 346 "gml.m"
  }
#line 343 "gml.m"
}
#line 258 "gml.m"
static /* final */ const MR_Box gml__const_6_0_1_V_24_24[2] = {
		((MR_Box) (MR_Word) ((MR_Integer) 0)),
		((MR_Box) ((MR_Integer) 1))};
#line 258 "gml.m"
static /* final */ const MR_Box gml__const_6_0_2_HeadVar__2_2[1] = {
		((MR_Box) (MR_mkword(MR_mktag(3), &gml__const_6_0_1_V_24_24)))};
#line 260 "gml.m"
static /* final */ const MR_Box gml__const_6_0_3_V_26_26[2] = {
		((MR_Box) (MR_Word) ((MR_Integer) 0)),
		((MR_Box) ((MR_Integer) 0))};
#line 260 "gml.m"
static /* final */ const MR_Box gml__const_6_0_4_HeadVar__2_2[1] = {
		((MR_Box) (MR_mkword(MR_mktag(3), &gml__const_6_0_3_V_26_26)))};
#line 644 "gml.m"
static /* final */ const MR_Box gml__const_6_0_5_V_54_54[2] = {
		((MR_Box) ((MR_String) "'")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_6_0_6_V_78_78[2] = {
		((MR_Box) ((MR_String) "start of token")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};
#line 627 "gml.m"
static /* final */ const MR_Box gml__const_6_0_7_V_74_74[2] = {
		((MR_Box) ((MR_String) "' in ")),
		((MR_Box) (MR_mkword(MR_mktag(1), &gml__const_6_0_6_V_78_78)))};

#line 246 "gml.m"
static void MR_CALL gml__get_token_4_p_0(
#line 246 "gml.m"
  MR_Char gml__HeadVar__1_1,
#line 246 "gml.m"
  MR_Word * gml__HeadVar__2_2)
#line 246 "gml.m"
{
#line 252 "gml.m"
  {
#line 252 "gml.m"
    bool gml__succeeded;
#line 252 "gml.m"
    MR_Word gml__Token0_7;

#line 291 "gml.m"
#line 291 "gml.m"
    switch (gml__HeadVar__1_1) {
#line 291 "gml.m"
      default:
#line 291 "gml.m"
        gml__succeeded = FALSE;
#line 291 "gml.m"
        break;
#line 291 "gml.m"
      case (MR_Integer) 91:
#line 291 "gml.m"
        {
#line 291 "gml.m"
          gml__Token0_7 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 291 "gml.m"
          gml__succeeded = TRUE;
#line 291 "gml.m"
        }
#line 291 "gml.m"
        break;
#line 291 "gml.m"
      case (MR_Integer) 93:
#line 292 "gml.m"
        {
#line 292 "gml.m"
          gml__Token0_7 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 1));
#line 292 "gml.m"
          gml__succeeded = TRUE;
#line 292 "gml.m"
        }
#line 291 "gml.m"
        break;
#line 291 "gml.m"
      case (MR_Integer) 123:
#line 293 "gml.m"
        {
#line 293 "gml.m"
          gml__Token0_7 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 2));
#line 293 "gml.m"
          gml__succeeded = TRUE;
#line 293 "gml.m"
        }
#line 291 "gml.m"
        break;
#line 291 "gml.m"
      case (MR_Integer) 125:
#line 294 "gml.m"
        {
#line 294 "gml.m"
          gml__Token0_7 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 3));
#line 294 "gml.m"
          gml__succeeded = TRUE;
#line 294 "gml.m"
        }
#line 291 "gml.m"
        break;
#line 291 "gml.m"
    }
#line 252 "gml.m"
    if (gml__succeeded)
#line 251 "gml.m"
      *gml__HeadVar__2_2 = gml__Token0_7;
#line 252 "gml.m"
    else
#line 255 "gml.m"
      {
#line 252 "gml.m"
        gml__succeeded = (gml__HeadVar__1_1 == (MR_Integer) 34);
#line 255 "gml.m"
        if (gml__succeeded)
          {
            MR_String gml__String_8;
            MR_Word gml__V_22_22;
            MR_Word gml__V_23_23 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));

#line 253 "gml.m"
            {
#line 253 "gml.m"
              gml__get_string_4_p_0(gml__V_23_23, &gml__String_8);
            }
#line 254 "gml.m"
            {
#line 254 "gml.m"
              gml__V_22_22 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "string"));
#line 254 "gml.m"
              MR_hl_field(MR_mktag(3), gml__V_22_22, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 2));
#line 254 "gml.m"
              MR_hl_field(MR_mktag(3), gml__V_22_22, 1) = ((MR_Box) (gml__String_8));
#line 254 "gml.m"
            }
#line 254 "gml.m"
            {
#line 254 "gml.m"
              *gml__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "token"));
#line 254 "gml.m"
              MR_hl_field(MR_mktag(1), *gml__HeadVar__2_2, 0) = ((MR_Box) (gml__V_22_22));
#line 254 "gml.m"
            }
          }
#line 255 "gml.m"
        else
#line 266 "gml.m"
          {
#line 255 "gml.m"
            {
#line 255 "gml.m"
              gml__succeeded = mercury__char__is_alpha_1_p_0(gml__HeadVar__1_1);
            }
#line 266 "gml.m"
            if (gml__succeeded)
              {
                MR_String gml__Identifier_9;
                MR_Word gml__V_30_30;
                MR_Word gml__V_31_31 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));

#line 256 "gml.m"
                {
#line 256 "gml.m"
                  gml__V_30_30 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 256 "gml.m"
                  MR_hl_field(MR_mktag(1), gml__V_30_30, 0) = ((MR_Box) (MR_Word) (gml__HeadVar__1_1));
#line 256 "gml.m"
                  MR_hl_field(MR_mktag(1), gml__V_30_30, 1) = ((MR_Box) (gml__V_31_31));
#line 256 "gml.m"
                }
#line 256 "gml.m"
                {
#line 256 "gml.m"
                  gml__get_identifier_4_p_0(gml__V_30_30, &gml__Identifier_9);
                }
#line 257 "gml.m"
                gml__succeeded = (strcmp(gml__Identifier_9, (MR_String) "true") == 0);
#line 259 "gml.m"
                if (gml__succeeded)
                  {
                    MR_Word gml__V_24_24 = (MR_Word) MR_mkword(MR_mktag(3), &gml__const_6_0_1_V_24_24);
                    MR_Word gml__V_25_25 = (MR_Integer) 1;

#line 258 "gml.m"
                    *gml__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_6_0_2_HeadVar__2_2);
                  }
#line 259 "gml.m"
                else
#line 261 "gml.m"
                  {
#line 259 "gml.m"
                    gml__succeeded = (strcmp(gml__Identifier_9, (MR_String) "false") == 0);
#line 261 "gml.m"
                    if (gml__succeeded)
                      {
                        MR_Word gml__V_26_26 = (MR_Word) MR_mkword(MR_mktag(3), &gml__const_6_0_3_V_26_26);
                        MR_Word gml__V_27_27 = (MR_Integer) 0;

#line 260 "gml.m"
                        *gml__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_6_0_4_HeadVar__2_2);
                      }
#line 261 "gml.m"
                    else
#line 263 "gml.m"
                      {
#line 263 "gml.m"
                        MR_Word gml__Operator_10;

#line 261 "gml.m"
                        {
#line 261 "gml.m"
                          gml__succeeded = gml__is_operator_2_p_0(gml__Identifier_9, &gml__Operator_10);
                        }
#line 263 "gml.m"
                        if (gml__succeeded)
                          {
                            MR_Word gml__V_28_28;

#line 262 "gml.m"
                            {
#line 262 "gml.m"
                              gml__V_28_28 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "operator");
#line 262 "gml.m"
                              MR_hl_field(MR_mktag(0), gml__V_28_28, 0) = ((MR_Box) (gml__Operator_10));
#line 262 "gml.m"
                            }
#line 262 "gml.m"
                            {
#line 262 "gml.m"
                              *gml__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "token"));
#line 262 "gml.m"
                              MR_hl_field(MR_mktag(1), *gml__HeadVar__2_2, 0) = ((MR_Box) (gml__V_28_28));
#line 262 "gml.m"
                            }
                          }
#line 263 "gml.m"
                        else
                          {
                            MR_Word gml__V_29_29;

#line 264 "gml.m"
                            {
#line 264 "gml.m"
                              gml__V_29_29 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "identifier"));
#line 264 "gml.m"
                              MR_hl_field(MR_mktag(1), gml__V_29_29, 0) = ((MR_Box) (gml__Identifier_9));
#line 264 "gml.m"
                            }
#line 264 "gml.m"
                            {
#line 264 "gml.m"
                              *gml__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "token"));
#line 264 "gml.m"
                              MR_hl_field(MR_mktag(1), *gml__HeadVar__2_2, 0) = ((MR_Box) (gml__V_29_29));
#line 264 "gml.m"
                            }
                          }
#line 263 "gml.m"
                      }
#line 261 "gml.m"
                  }
              }
#line 266 "gml.m"
            else
#line 279 "gml.m"
              {
#line 266 "gml.m"
                gml__succeeded = (gml__HeadVar__1_1 == (MR_Integer) 47);
#line 279 "gml.m"
                if (gml__succeeded)
                  {
                    MR_Word gml__V_32_32;
                    MR_Word gml__V_33_33 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
                    MR_String gml__Identifier_41;

#line 267 "gml.m"
                    {
#line 267 "gml.m"
                      gml__get_identifier_4_p_0(gml__V_33_33, &gml__Identifier_41);
                    }
#line 270 "gml.m"
                    if ((strcmp(gml__Identifier_41, (MR_String) "false") == 0))
                      gml__succeeded = TRUE;
#line 270 "gml.m"
                    else
#line 270 "gml.m"
                      if ((strcmp(gml__Identifier_41, (MR_String) "true") == 0))
                        gml__succeeded = TRUE;
#line 270 "gml.m"
                      else
#line 270 "gml.m"
                        gml__succeeded = FALSE;
#line 270 "gml.m"
                    if (!(gml__succeeded))
#line 270 "gml.m"
                      {
#line 269 "gml.m"
                        MR_Word gml__V_11_11;

#line 269 "gml.m"
                        {
#line 269 "gml.m"
                          gml__succeeded = gml__is_operator_2_p_0(gml__Identifier_41, &gml__V_11_11);
                        }
#line 270 "gml.m"
                      }
#line 275 "gml.m"
                    if (gml__succeeded)
                      {
                        MR_Integer gml__Line_46;
                        MR_String gml__Msg_47;
                        MR_Word gml__V_50_50;
                        MR_Word gml__V_51_51;
                        MR_String gml__V_52_52;
                        MR_Word gml__V_53_53;
                        MR_Word gml__V_54_54;
                        MR_String gml__V_55_55;
                        MR_Word gml__V_56_56;
                        MR_Word gml__TypeInfo_16_57;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_token_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_46
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 644 "gml.m"
                        gml__V_52_52 = (MR_String) "attempt to rebind operator `";
#line 644 "gml.m"
                        gml__V_55_55 = (MR_String) "'";
#line 644 "gml.m"
                        gml__V_56_56 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 644 "gml.m"
                        gml__V_54_54 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_6_0_5_V_54_54);
#line 644 "gml.m"
                        {
#line 644 "gml.m"
                          gml__V_53_53 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 644 "gml.m"
                          MR_hl_field(MR_mktag(1), gml__V_53_53, 0) = ((MR_Box) (gml__Identifier_41));
#line 644 "gml.m"
                          MR_hl_field(MR_mktag(1), gml__V_53_53, 1) = ((MR_Box) (gml__V_54_54));
#line 644 "gml.m"
                        }
#line 643 "gml.m"
                        {
#line 643 "gml.m"
                          gml__V_51_51 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 643 "gml.m"
                          MR_hl_field(MR_mktag(1), gml__V_51_51, 0) = ((MR_Box) (gml__V_52_52));
#line 643 "gml.m"
                          MR_hl_field(MR_mktag(1), gml__V_51_51, 1) = ((MR_Box) (gml__V_53_53));
#line 643 "gml.m"
                        }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_token_4_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_51_51
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_47
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 645 "gml.m"
                        {
#line 645 "gml.m"
                          gml__V_50_50 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 645 "gml.m"
                          MR_hl_field(MR_mktag(0), gml__V_50_50, 0) = ((MR_Box) (gml__Line_46));
#line 645 "gml.m"
                          MR_hl_field(MR_mktag(0), gml__V_50_50, 1) = ((MR_Box) (gml__Msg_47));
#line 645 "gml.m"
                        }
                        gml__TypeInfo_16_57 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 645 "gml.m"
                        {
#line 645 "gml.m"
                          mercury__exception__throw_1_p_0(gml__TypeInfo_16_57, ((MR_Box) (gml__V_50_50)));
                        }
                      }
#line 275 "gml.m"
                    else
#line 276 "gml.m"
                      {
#line 276 "gml.m"
                      }
#line 278 "gml.m"
                    {
#line 278 "gml.m"
                      gml__V_32_32 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "binder"));
#line 278 "gml.m"
                      MR_hl_field(MR_mktag(2), gml__V_32_32, 0) = ((MR_Box) (gml__Identifier_41));
#line 278 "gml.m"
                    }
#line 278 "gml.m"
                    {
#line 278 "gml.m"
                      *gml__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "token"));
#line 278 "gml.m"
                      MR_hl_field(MR_mktag(1), *gml__HeadVar__2_2, 0) = ((MR_Box) (gml__V_32_32));
#line 278 "gml.m"
                    }
                  }
#line 279 "gml.m"
                else
#line 282 "gml.m"
                  {
#line 279 "gml.m"
                    gml__succeeded = (gml__HeadVar__1_1 == (MR_Integer) 45);
#line 282 "gml.m"
                    if (gml__succeeded)
                      {
                        MR_Word gml__Num_12;
                        MR_Word gml__V_34_34;
                        MR_Word gml__V_35_35;
                        MR_Word gml__V_36_36 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));

#line 280 "gml.m"
                        {
#line 280 "gml.m"
                          gml__V_35_35 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 280 "gml.m"
                          MR_hl_field(MR_mktag(1), gml__V_35_35, 0) = ((MR_Box) (MR_Word) (gml__HeadVar__1_1));
#line 280 "gml.m"
                          MR_hl_field(MR_mktag(1), gml__V_35_35, 1) = ((MR_Box) (gml__V_36_36));
#line 280 "gml.m"
                        }
#line 280 "gml.m"
                        {
#line 280 "gml.m"
                          gml__get_number_4_p_0(gml__V_35_35, &gml__Num_12);
                        }
#line 281 "gml.m"
                        {
#line 281 "gml.m"
                          gml__V_34_34 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "number"));
#line 281 "gml.m"
                          MR_hl_field(MR_mktag(3), gml__V_34_34, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 1));
#line 281 "gml.m"
                          MR_hl_field(MR_mktag(3), gml__V_34_34, 1) = ((MR_Box) (gml__Num_12));
#line 281 "gml.m"
                        }
#line 281 "gml.m"
                        {
#line 281 "gml.m"
                          *gml__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "token"));
#line 281 "gml.m"
                          MR_hl_field(MR_mktag(1), *gml__HeadVar__2_2, 0) = ((MR_Box) (gml__V_34_34));
#line 281 "gml.m"
                        }
                      }
#line 282 "gml.m"
                    else
#line 285 "gml.m"
                      {
#line 282 "gml.m"
                        {
#line 282 "gml.m"
                          gml__succeeded = mercury__char__is_digit_1_p_0(gml__HeadVar__1_1);
                        }
#line 285 "gml.m"
                        if (gml__succeeded)
                          {
                            MR_Word gml__V_37_37;
                            MR_Word gml__V_38_38;
                            MR_Word gml__V_39_39 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
                            MR_Word gml__Num_42;

#line 283 "gml.m"
                            {
#line 283 "gml.m"
                              gml__V_38_38 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 283 "gml.m"
                              MR_hl_field(MR_mktag(1), gml__V_38_38, 0) = ((MR_Box) (MR_Word) (gml__HeadVar__1_1));
#line 283 "gml.m"
                              MR_hl_field(MR_mktag(1), gml__V_38_38, 1) = ((MR_Box) (gml__V_39_39));
#line 283 "gml.m"
                            }
#line 283 "gml.m"
                            {
#line 283 "gml.m"
                              gml__get_number_4_p_0(gml__V_38_38, &gml__Num_42);
                            }
#line 284 "gml.m"
                            {
#line 284 "gml.m"
                              gml__V_37_37 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "number"));
#line 284 "gml.m"
                              MR_hl_field(MR_mktag(3), gml__V_37_37, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 1));
#line 284 "gml.m"
                              MR_hl_field(MR_mktag(3), gml__V_37_37, 1) = ((MR_Box) (gml__Num_42));
#line 284 "gml.m"
                            }
#line 284 "gml.m"
                            {
#line 284 "gml.m"
                              *gml__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "token"));
#line 284 "gml.m"
                              MR_hl_field(MR_mktag(1), *gml__HeadVar__2_2, 0) = ((MR_Box) (gml__V_37_37));
#line 284 "gml.m"
                            }
                          }
#line 285 "gml.m"
                        else
                          {
                            MR_String gml__V_40_40 = (MR_String) "start of token";
                            MR_Integer gml__Line_65;
                            MR_String gml__Msg_66;
                            MR_Word gml__V_69_69;
                            MR_Word gml__V_70_70;
                            MR_String gml__V_71_71;
                            MR_Word gml__V_72_72;
                            MR_String gml__V_73_73;
                            MR_Word gml__V_74_74;
                            MR_Word gml__V_75_75;
                            MR_Word gml__V_76_76;
                            MR_String gml__V_77_77;
                            MR_Word gml__V_78_78;
                            MR_Word gml__V_79_79;
                            MR_Word gml__TypeInfo_22_80;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__get_token_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_65
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 626 "gml.m"
                            gml__V_71_71 = (MR_String) "unexpected character `";
#line 627 "gml.m"
                            gml__V_76_76 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 627 "gml.m"
                            {
#line 627 "gml.m"
                              gml__V_75_75 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 627 "gml.m"
                              MR_hl_field(MR_mktag(1), gml__V_75_75, 0) = ((MR_Box) (MR_Word) (gml__HeadVar__1_1));
#line 627 "gml.m"
                              MR_hl_field(MR_mktag(1), gml__V_75_75, 1) = ((MR_Box) (gml__V_76_76));
#line 627 "gml.m"
                            }
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_token_4_p_0
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word CharList;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	CharList = 
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_75_75
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
		/* mode (out, in) is det */
	MR_Word char_list_ptr;
	size_t size;
/*
** loop to calculate list length + sizeof(MR_Word) in `size' using list in
** `char_list_ptr'
*/
	size = sizeof(MR_Word);
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		size++;
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** allocate (length + 1) bytes of heap space for string
** i.e. (length + 1 + sizeof(MR_Word) - 1) / sizeof(MR_Word) words
*/
	MR_allocate_aligned_string_msg(Str, size, MR_PROC_LABEL);

/*
** loop to copy the characters from the char_list to the string
*/
	size = 0;
	char_list_ptr = CharList;
	while (! MR_list_is_empty(char_list_ptr)) {
		Str[size++] = MR_list_head(char_list_ptr);
		char_list_ptr = MR_list_tail(char_list_ptr);
	}
/*
** null terminate the string
*/
	Str[size] = '\0';
}
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_73_73
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 176 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 627 "gml.m"
                            gml__V_77_77 = (MR_String) "' in ";
#line 627 "gml.m"
                            gml__V_79_79 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 627 "gml.m"
                            gml__V_78_78 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_6_0_6_V_78_78);
#line 627 "gml.m"
                            gml__V_74_74 = (MR_Word) MR_mkword(MR_mktag(1), &gml__const_6_0_7_V_74_74);
#line 626 "gml.m"
                            {
#line 626 "gml.m"
                              gml__V_72_72 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 626 "gml.m"
                              MR_hl_field(MR_mktag(1), gml__V_72_72, 0) = ((MR_Box) (gml__V_73_73));
#line 626 "gml.m"
                              MR_hl_field(MR_mktag(1), gml__V_72_72, 1) = ((MR_Box) (gml__V_74_74));
#line 626 "gml.m"
                            }
#line 625 "gml.m"
                            {
#line 625 "gml.m"
                              gml__V_70_70 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 625 "gml.m"
                              MR_hl_field(MR_mktag(1), gml__V_70_70, 0) = ((MR_Box) (gml__V_71_71));
#line 625 "gml.m"
                              MR_hl_field(MR_mktag(1), gml__V_70_70, 1) = ((MR_Box) (gml__V_72_72));
#line 625 "gml.m"
                            }
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#define MR_PROC_LABEL gml__get_token_4_p_0
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_Word Strs;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	MR_String Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	Strs = 
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__V_70_70
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
		{
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
{
	MR_Word	list = Strs;
	MR_Word	tmp;
	size_t	len;

		/* Determine the total length of all strings */
	len = 0;
	while (!MR_list_is_empty(list)) {
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Allocate enough word aligned memory for the string */
	MR_allocate_aligned_string_msg(Str, len, MR_PROC_LABEL);

		/* Copy the strings into the new memory */
	len = 0;
	list = Strs;
	while (!MR_list_is_empty(list)) {
		strcpy((MR_String) Str + len, (MR_String) MR_list_head(list));
		len += strlen((MR_String) MR_list_head(list));
		list = MR_list_tail(list);
	}

		/* Set the last character to the null char */
	Str[len] = '\0';
}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"

		;}
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#undef MR_PROC_LABEL
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
	
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
gml__Msg_66
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
 = Str;
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
#line 438 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/string.opt"
}
#line 628 "gml.m"
                            {
#line 628 "gml.m"
                              gml__V_69_69 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 628 "gml.m"
                              MR_hl_field(MR_mktag(0), gml__V_69_69, 0) = ((MR_Box) (gml__Line_65));
#line 628 "gml.m"
                              MR_hl_field(MR_mktag(0), gml__V_69_69, 1) = ((MR_Box) (gml__Msg_66));
#line 628 "gml.m"
                            }
                            gml__TypeInfo_22_80 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 628 "gml.m"
                            {
#line 628 "gml.m"
                              mercury__exception__throw_1_p_0(gml__TypeInfo_22_80, ((MR_Box) (gml__V_69_69)));
#line 628 "gml.m"
                              return;
                            }
                          }
#line 285 "gml.m"
                      }
#line 282 "gml.m"
                  }
#line 279 "gml.m"
              }
#line 266 "gml.m"
          }
#line 255 "gml.m"
      }
#line 252 "gml.m"
  }
#line 246 "gml.m"
}

#line 225 "gml.m"
static void MR_CALL gml__skip_to_end_of_line_2_p_0(void)
#line 225 "gml.m"
{
  {
    /* tailcall optimized into a loop */
  loop_top:;
    {
      bool gml__succeeded;
      MR_Word gml__CharResult_3;
#line 242 "gml.m"
      MR_Char gml__Char_4;

#line 228 "gml.m"
      {
#line 228 "gml.m"
        gml__lexer_read_char_3_p_0(&gml__CharResult_3);
      }
#line 242 "gml.m"
      if ((gml__CharResult_3 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 242 "gml.m"
        {
#line 242 "gml.m"
        }
#line 242 "gml.m"
      else
#line 242 "gml.m"
        {
#line 230 "gml.m"
          gml__Char_4 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(1), gml__CharResult_3, (MR_Integer) 0)));
#line 231 "gml.m"
          gml__succeeded = (gml__Char_4 == (MR_Integer) 10);
#line 233 "gml.m"
          if (gml__succeeded)
#line 232 "gml.m"
            {
#line 232 "gml.m"
            }
#line 233 "gml.m"
          else
#line 235 "gml.m"
            {
#line 233 "gml.m"
              gml__succeeded = (gml__Char_4 == (MR_Integer) 11);
#line 235 "gml.m"
              if (gml__succeeded)
#line 234 "gml.m"
                {
#line 234 "gml.m"
                }
#line 235 "gml.m"
              else
#line 237 "gml.m"
                {
#line 235 "gml.m"
                  gml__succeeded = (gml__Char_4 == (MR_Integer) 12);
#line 237 "gml.m"
                  if (gml__succeeded)
#line 236 "gml.m"
                    {
#line 236 "gml.m"
                    }
#line 237 "gml.m"
                  else
#line 239 "gml.m"
                    {
#line 237 "gml.m"
                      gml__succeeded = (gml__Char_4 == (MR_Integer) 13);
#line 239 "gml.m"
                      if (gml__succeeded)
#line 238 "gml.m"
                        {
#line 238 "gml.m"
                        }
#line 239 "gml.m"
                      else
#line 240 "gml.m"
                        {
#line 240 "gml.m"
                          /* direct tailcall eliminated */
#line 240 "gml.m"
                          {
#line 240 "gml.m"
                          }
#line 240 "gml.m"
                          goto loop_top;
#line 240 "gml.m"
                        }
#line 239 "gml.m"
                    }
#line 237 "gml.m"
                }
#line 235 "gml.m"
            }
#line 242 "gml.m"
        }
    }
  }
#line 225 "gml.m"
}

#line 196 "gml.m"
static void MR_CALL gml__skip_whitespace_3_p_0(
#line 196 "gml.m"
  MR_Word * gml__HeadVar__1_1)
#line 196 "gml.m"
{
  {
    /* tailcall optimized into a loop */
  loop_top:;
    {
      bool gml__succeeded;
      MR_Word gml__CharResult0_5;

#line 200 "gml.m"
      {
#line 200 "gml.m"
        gml__lexer_read_char_3_p_0(&gml__CharResult0_5);
      }
#line 211 "gml.m"
      if ((gml__CharResult0_5 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 213 "gml.m"
        *gml__HeadVar__1_1 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 211 "gml.m"
      else
#line 211 "gml.m"
        {
          MR_Char gml__FirstChar_6 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(1), gml__CharResult0_5, (MR_Integer) 0)));

#line 203 "gml.m"
          gml__succeeded = (gml__FirstChar_6 == (MR_Integer) 37);
#line 206 "gml.m"
          if (gml__succeeded)
            {
#line 204 "gml.m"
              {
#line 204 "gml.m"
                gml__skip_to_end_of_line_2_p_0();
              }
#line 205 "gml.m"
              {
#line 205 "gml.m"
                /* direct tailcall eliminated */
#line 205 "gml.m"
                {
#line 205 "gml.m"
                }
#line 205 "gml.m"
                goto loop_top;
#line 205 "gml.m"
              }
            }
#line 206 "gml.m"
          else
#line 208 "gml.m"
            {
#line 218 "gml.m"
#line 218 "gml.m"
              switch (gml__FirstChar_6) {
#line 218 "gml.m"
                default:
#line 218 "gml.m"
                  gml__succeeded = FALSE;
#line 218 "gml.m"
                  break;
#line 218 "gml.m"
                case (MR_Integer) 9:
                  gml__succeeded = TRUE;
#line 218 "gml.m"
                  break;
#line 218 "gml.m"
                case (MR_Integer) 10:
                  gml__succeeded = TRUE;
#line 218 "gml.m"
                  break;
#line 218 "gml.m"
                case (MR_Integer) 11:
                  gml__succeeded = TRUE;
#line 218 "gml.m"
                  break;
#line 218 "gml.m"
                case (MR_Integer) 12:
                  gml__succeeded = TRUE;
#line 218 "gml.m"
                  break;
#line 218 "gml.m"
                case (MR_Integer) 13:
                  gml__succeeded = TRUE;
#line 218 "gml.m"
                  break;
#line 218 "gml.m"
                case (MR_Integer) 32:
                  gml__succeeded = TRUE;
#line 218 "gml.m"
                  break;
#line 218 "gml.m"
              }
#line 208 "gml.m"
              if (gml__succeeded)
#line 207 "gml.m"
                {
#line 207 "gml.m"
                  /* direct tailcall eliminated */
#line 207 "gml.m"
                  {
#line 207 "gml.m"
                  }
#line 207 "gml.m"
                  goto loop_top;
#line 207 "gml.m"
                }
#line 208 "gml.m"
              else
#line 209 "gml.m"
                *gml__HeadVar__1_1 = gml__CharResult0_5;
#line 208 "gml.m"
            }
#line 211 "gml.m"
        }
    }
  }
#line 196 "gml.m"
}

#line 179 "gml.m"
void MR_CALL gml__tokenize_2_4_p_0(
#line 179 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 179 "gml.m"
  MR_Word * gml__HeadVar__2_2)
#line 179 "gml.m"
{
  {
    /* tailcall optimized into a loop */
  loop_top:;
    {
      bool gml__succeeded;
      MR_Word gml__FirstCharResult_7;

#line 183 "gml.m"
      {
#line 183 "gml.m"
        gml__skip_whitespace_3_p_0(&gml__FirstCharResult_7);
      }
#line 188 "gml.m"
#line 188 "gml.m"
      switch (MR_tag((MR_Word) gml__FirstCharResult_7)) {
#line 188 "gml.m"
        default: /*NOTREACHED*/ MR_assert(0);
#line 188 "gml.m"
        case (MR_Integer) 0:
#line 190 "gml.m"
          *gml__HeadVar__2_2 = gml__HeadVar__1_1;
#line 188 "gml.m"
          break;
#line 188 "gml.m"
        case (MR_Integer) 1:
          {
            MR_Char gml__FirstChar_8 = ((MR_Char) (MR_Word) (MR_hl_field(MR_mktag(1), gml__FirstCharResult_7, (MR_Integer) 0)));
            MR_Word gml__Token_9;
            MR_Word gml__V_16_16;

#line 186 "gml.m"
            {
#line 186 "gml.m"
              gml__get_token_4_p_0(gml__FirstChar_8, &gml__Token_9);
            }
#line 187 "gml.m"
            {
#line 187 "gml.m"
              gml__V_16_16 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 187 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_16_16, 0) = ((MR_Box) (gml__Token_9));
#line 187 "gml.m"
              MR_hl_field(MR_mktag(1), gml__V_16_16, 1) = ((MR_Box) (gml__HeadVar__1_1));
#line 187 "gml.m"
            }
#line 187 "gml.m"
            {
#line 187 "gml.m"
              /* direct tailcall eliminated */
#line 187 "gml.m"
              {
#line 187 "gml.m"
                MR_Word gml__HeadVar__1__tmp_copy_1 = gml__V_16_16;

#line 187 "gml.m"
                gml__HeadVar__1_1 = gml__HeadVar__1__tmp_copy_1;
#line 187 "gml.m"
              }
#line 187 "gml.m"
              goto loop_top;
#line 187 "gml.m"
            }
          }
#line 188 "gml.m"
          break;
#line 188 "gml.m"
        case (MR_Integer) 2:
          {
            MR_Word gml__Error_10 = ((MR_Word) (MR_hl_field(MR_mktag(2), gml__FirstCharResult_7, (MR_Integer) 0)));
            MR_Integer gml__Line_18;
            MR_String gml__Msg_19;
            MR_Word gml__V_22_22;
            MR_Word gml__TypeInfo_10_23;

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL gml__tokenize_2_4_p_0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	LineNum = MR_line_number(*mercury_current_text_input);
	update_io(IO0, IO);

#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
gml__Line_18
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = LineNum;
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 402 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 694 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            gml__Msg_19 = (MR_String) gml__Error_10;
#line 636 "gml.m"
            {
#line 636 "gml.m"
              gml__V_22_22 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "lexer_error");
#line 636 "gml.m"
              MR_hl_field(MR_mktag(0), gml__V_22_22, 0) = ((MR_Box) (gml__Line_18));
#line 636 "gml.m"
              MR_hl_field(MR_mktag(0), gml__V_22_22, 1) = ((MR_Box) (gml__Msg_19));
#line 636 "gml.m"
            }
            gml__TypeInfo_10_23 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 636 "gml.m"
            {
#line 636 "gml.m"
              mercury__exception__throw_1_p_0(gml__TypeInfo_10_23, ((MR_Box) (gml__V_22_22)));
#line 636 "gml.m"
              return;
            }
          }
#line 188 "gml.m"
          break;
#line 188 "gml.m"
      }
    }
  }
#line 179 "gml.m"
}

#line 167 "gml.m"
void MR_CALL gml__parse_2_p_0(
#line 167 "gml.m"
  MR_Word gml__HeadVar__1_1,
#line 167 "gml.m"
  MR_Word * gml__HeadVar__2_2)
#line 167 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Word gml__StopAt_5 = (MR_Integer) 0;
    MR_Word gml__RemainingTokens_6;
    MR_Word gml__Program0_7;
    MR_Word gml__V_10_10 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
    MR_Word gml__TypeInfo_12_12;
    MR_Word gml__V_5_15;

#line 652 "gml.m"
    {
#line 652 "gml.m"
      gml__parse_2_5_p_0(gml__StopAt_5, gml__HeadVar__1_1, &gml__RemainingTokens_6, gml__V_10_10, &gml__Program0_7);
    }
#line 654 "gml.m"
    gml__succeeded = (gml__RemainingTokens_6 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 657 "gml.m"
    if (gml__succeeded)
      {
      }
#line 657 "gml.m"
    else
      {
        MR_Word gml__V_8_8;
        MR_String gml__V_9_9 = (MR_String) "tokens left over at end of parse";
        MR_Word gml__TypeInfo_11_11;

#line 658 "gml.m"
        gml__V_8_8 = (MR_Word) gml__V_9_9;
        gml__TypeInfo_11_11 = (MR_Word) (&gml__gml__type_ctor_info_parse_error_0);
#line 658 "gml.m"
        {
#line 658 "gml.m"
          mercury__exception__throw_1_p_0(gml__TypeInfo_11_11, ((MR_Box) (gml__V_8_8)));
        }
      }
    gml__TypeInfo_12_12 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    gml__V_5_15 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      mercury__list__reverse_2_3_p_0(gml__TypeInfo_12_12, gml__Program0_7, gml__V_5_15, gml__HeadVar__2_2);
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      return;
    }
  }
#line 167 "gml.m"
}

#line 143 "gml.m"
void MR_CALL gml__tokenize_3_p_0(
#line 143 "gml.m"
  MR_Word * gml__HeadVar__1_1)
#line 143 "gml.m"
{
  {
    bool gml__succeeded;
    MR_Word gml__RevTokens_5;
    MR_Word gml__V_8_8 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
    MR_Word gml__TypeInfo_9_9;
    MR_Word gml__V_5_12;

#line 176 "gml.m"
    {
#line 176 "gml.m"
      gml__tokenize_2_4_p_0(gml__V_8_8, &gml__RevTokens_5);
    }
    gml__TypeInfo_9_9 = (MR_Word) (&gml__gml__type_ctor_info_basic_token_0);
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    gml__V_5_12 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      mercury__list__reverse_2_3_p_0(gml__TypeInfo_9_9, gml__RevTokens_5, gml__V_5_12, gml__HeadVar__1_1);
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      return;
    }
  }
#line 143 "gml.m"
}

void mercury__gml__init(void)
{
}

void mercury__gml__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&gml__gml__type_ctor_info_token_list_0);
	MR_register_type_ctor_info(&gml__gml__type_ctor_info_token_group_0);
	MR_register_type_ctor_info(&gml__gml__type_ctor_info_token_0);
	MR_register_type_ctor_info(&gml__gml__type_ctor_info_stop_at_0);
	MR_register_type_ctor_info(&gml__gml__type_ctor_info_parse_error_0);
	MR_register_type_ctor_info(&gml__gml__type_ctor_info_operator_0);
	MR_register_type_ctor_info(&gml__gml__type_ctor_info_number_0);
	MR_register_type_ctor_info(&gml__gml__type_ctor_info_lexer_error_0);
	MR_register_type_ctor_info(&gml__gml__type_ctor_info_gml_program_0);
	MR_register_type_ctor_info(&gml__gml__type_ctor_info_extra_operator_0);
	MR_register_type_ctor_info(&gml__gml__type_ctor_info_basic_token_0);
}

void mercury__gml__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module gml. */
