/*
** Automatically generated from `tree.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module tree. */
/* :- interface. */

#ifndef MR_HEADER_GUARD_tree
#define MR_HEADER_GUARD_tree

#ifdef __cplusplus
extern "C" {
#endif

#include "mercury.h"


#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif



extern const MR_TypeCtorInfo_Struct tree__tree__type_ctor_info_tree_1;
#line 22 "tree.m"
void MR_CALL tree____Compare____tree_1_0(
#line 22 "tree.m"
  MR_Word tree__TypeInfo_for_T_23,
#line 22 "tree.m"
  MR_Word * tree__HeadVar__1_1,
#line 22 "tree.m"
  MR_Word tree__HeadVar__2_2,
#line 22 "tree.m"
  MR_Word tree__HeadVar__3_3);
#line 22 "tree.m"
bool MR_CALL tree____Unify____tree_1_0(
#line 22 "tree.m"
  MR_Word tree__TypeInfo_for_T_9,
#line 22 "tree.m"
  MR_Word tree__HeadVar__1_1,
#line 22 "tree.m"
  MR_Word tree__HeadVar__2_2);
#line 43 "tree.m"
void MR_CALL tree__flatten_2_3_p_0(
#line 43 "tree.m"
  MR_Word tree__TypeInfo_for_T_12,
#line 43 "tree.m"
  MR_Word tree__HeadVar__1_1,
#line 43 "tree.m"
  MR_Word tree__HeadVar__2_2,
#line 43 "tree.m"
  MR_Word * tree__HeadVar__3_3);
#line 33 "tree.m"
bool MR_CALL tree__tree_of_lists_is_empty_1_p_0(
#line 33 "tree.m"
  MR_Word tree__TypeInfo_for_T_5,
#line 33 "tree.m"
  MR_Word tree__HeadVar__1_1);
#line 30 "tree.m"
bool MR_CALL tree__is_empty_1_p_0(
#line 30 "tree.m"
  MR_Word tree__TypeInfo_for_T_4,
#line 30 "tree.m"
  MR_Word tree__HeadVar__1_1);
#line 27 "tree.m"
void MR_CALL tree__flatten_2_p_0(
#line 27 "tree.m"
  MR_Word tree__TypeInfo_for_T_6,
#line 27 "tree.m"
  MR_Word tree__HeadVar__1_1,
#line 27 "tree.m"
  MR_Word * tree__HeadVar__2_2);

void mercury__tree__init(void);
void mercury__tree__init_type_tables(void);
void mercury__tree__init_debugger(void);

#ifdef __cplusplus
}
#endif

#endif /* MR_HEADER_GUARD_tree */

/* :- end_interface tree. */
