/*
** Automatically generated from `tree.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module tree. */
/* :- implementation. */

#include "tree.h"


#include "mercury.assoc_list.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.enum.h"
#include "mercury.float.h"
#include "mercury.int.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.private_builtin.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.string.h"
#include "mercury.term.h"
#include "mercury.tree234.h"



static const MR_DuFunctorDescPtr tree__tree__du_name_ordered_tree_1[3];
static const MR_DuFunctorDesc tree__tree__du_functor_desc_tree_1_0;
static const MR_DuFunctorDesc tree__tree__du_functor_desc_tree_1_1;
static const MR_PseudoTypeInfo tree__tree__field_types_tree_1_1[1];
static const MR_DuFunctorDesc tree__tree__du_functor_desc_tree_1_2;
static const MR_PseudoTypeInfo tree__tree__field_types_tree_1_2[2];
static const MR_FO_PseudoTypeInfo_Struct1 tree__tree__type_info_tree_1__var_1;
static const MR_DuPtagLayout tree__tree__du_ptag_ordered_tree_1[3];
static const MR_DuFunctorDescPtr tree__tree__du_stag_ordered_tree_1_0[1];
static const MR_DuFunctorDescPtr tree__tree__du_stag_ordered_tree_1_1[1];
static const MR_DuFunctorDescPtr tree__tree__du_stag_ordered_tree_1_2[1];



const MR_TypeCtorInfo_Struct tree__tree__type_ctor_info_tree_1 = {
		(MR_Integer) 1,
		((MR_Box) (tree____Unify____tree_1_0)),
		((MR_Box) (tree____Unify____tree_1_0)),
		((MR_Box) (tree____Compare____tree_1_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "tree",
		(MR_String) "tree",
		(MR_Integer) 4,
		{
		(MR_Box) tree__tree__du_name_ordered_tree_1},
		{
		(MR_Box) tree__tree__du_ptag_ordered_tree_1},
		(MR_Integer) 3,
		(MR_Integer) 3};
static const MR_DuFunctorDescPtr tree__tree__du_name_ordered_tree_1[3] = {
		(&tree__tree__du_functor_desc_tree_1_0),
		(&tree__tree__du_functor_desc_tree_1_1),
		(&tree__tree__du_functor_desc_tree_1_2)};
static const MR_DuFunctorDesc tree__tree__du_functor_desc_tree_1_0 = {
		(MR_String) "empty",
		(MR_Integer) 0,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_DuFunctorDesc tree__tree__du_functor_desc_tree_1_1 = {
		(MR_String) "node",
		(MR_Integer) 1,
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		tree__tree__field_types_tree_1_1,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo tree__tree__field_types_tree_1_1[1] = {
		(MR_PseudoTypeInfo) (MR_Integer) 1};
static const MR_DuFunctorDesc tree__tree__du_functor_desc_tree_1_2 = {
		(MR_String) "tree",
		(MR_Integer) 2,
		(MR_Integer) 3,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 2,
		(MR_Integer) 0,
		(MR_Integer) 2,
		tree__tree__field_types_tree_1_2,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo tree__tree__field_types_tree_1_2[2] = {
		(MR_PseudoTypeInfo) (&tree__tree__type_info_tree_1__var_1),
		(MR_PseudoTypeInfo) (&tree__tree__type_info_tree_1__var_1)};
static const MR_FO_PseudoTypeInfo_Struct1 tree__tree__type_info_tree_1__var_1 = {
		(&tree__tree__type_ctor_info_tree_1),
		{
		(MR_PseudoTypeInfo) (MR_Integer) 1}};
static const MR_DuPtagLayout tree__tree__du_ptag_ordered_tree_1[3] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_LOCAL,
		tree__tree__du_stag_ordered_tree_1_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		tree__tree__du_stag_ordered_tree_1_1},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		tree__tree__du_stag_ordered_tree_1_2}};
static const MR_DuFunctorDescPtr tree__tree__du_stag_ordered_tree_1_0[1] = {
		(&tree__tree__du_functor_desc_tree_1_0)};
static const MR_DuFunctorDescPtr tree__tree__du_stag_ordered_tree_1_1[1] = {
		(&tree__tree__du_functor_desc_tree_1_1)};
static const MR_DuFunctorDescPtr tree__tree__du_stag_ordered_tree_1_2[1] = {
		(&tree__tree__du_functor_desc_tree_1_2)};

#line 22 "tree.m"
void MR_CALL tree____Compare____tree_1_0(
#line 22 "tree.m"
  MR_Word tree__TypeInfo_for_T_23,
#line 22 "tree.m"
  MR_Word * tree__HeadVar__1_1,
#line 22 "tree.m"
  MR_Word tree__HeadVar__2_2,
#line 22 "tree.m"
  MR_Word tree__HeadVar__3_3)
#line 22 "tree.m"
{
#line 22 "tree.m"
  {
#line 22 "tree.m"
    /* tailcall optimized into a loop */
#line 22 "tree.m"
  loop_top:;
#line 22 "tree.m"
    {
#line 22 "tree.m"
      bool tree__succeeded;
#line 22 "tree.m"
      MR_Box tree__V_28_28;
#line 22 "tree.m"
      MR_Word tree__V_29_29;
#line 22 "tree.m"
      MR_Word tree__V_30_30;

#line 22 "tree.m"
#line 22 "tree.m"
      switch (MR_tag((MR_Word) tree__HeadVar__2_2)) {
#line 22 "tree.m"
        default: /*NOTREACHED*/ MR_assert(0);
#line 22 "tree.m"
        case (MR_Integer) 0:
#line 22 "tree.m"
#line 22 "tree.m"
          switch (MR_tag((MR_Word) tree__HeadVar__3_3)) {
#line 22 "tree.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 22 "tree.m"
            case (MR_Integer) 0:
#line 22 "tree.m"
              *tree__HeadVar__1_1 = (MR_Integer) 0;
#line 22 "tree.m"
              break;
#line 22 "tree.m"
            case (MR_Integer) 1:
#line 22 "tree.m"
              *tree__HeadVar__1_1 = (MR_Integer) 1;
#line 22 "tree.m"
              break;
#line 22 "tree.m"
            case (MR_Integer) 2:
#line 22 "tree.m"
              *tree__HeadVar__1_1 = (MR_Integer) 1;
#line 22 "tree.m"
              break;
#line 22 "tree.m"
          }
#line 22 "tree.m"
          break;
#line 22 "tree.m"
        case (MR_Integer) 1:
          {
#line 22 "tree.m"
            MR_Box tree__V_5_5;

#line 22 "tree.m"
            tree__V_28_28 = (MR_hl_field(MR_mktag(1), tree__HeadVar__2_2, (MR_Integer) 0));
#line 22 "tree.m"
#line 22 "tree.m"
            switch (MR_tag((MR_Word) tree__HeadVar__3_3)) {
#line 22 "tree.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 22 "tree.m"
              case (MR_Integer) 0:
#line 22 "tree.m"
                *tree__HeadVar__1_1 = (MR_Integer) 2;
#line 22 "tree.m"
                break;
#line 22 "tree.m"
              case (MR_Integer) 1:
                {
#line 22 "tree.m"
                  tree__V_5_5 = (MR_hl_field(MR_mktag(1), tree__HeadVar__3_3, (MR_Integer) 0));
#line 22 "tree.m"
                  {
#line 22 "tree.m"
                    mercury__builtin__compare_3_p_0(tree__TypeInfo_for_T_23, tree__HeadVar__1_1, tree__V_28_28, tree__V_5_5);
#line 22 "tree.m"
                    return;
                  }
                }
#line 22 "tree.m"
                break;
#line 22 "tree.m"
              case (MR_Integer) 2:
#line 22 "tree.m"
                *tree__HeadVar__1_1 = (MR_Integer) 1;
#line 22 "tree.m"
                break;
#line 22 "tree.m"
            }
          }
#line 22 "tree.m"
          break;
#line 22 "tree.m"
        case (MR_Integer) 2:
          {
#line 22 "tree.m"
            MR_Word tree__V_8_8;
#line 22 "tree.m"
            MR_Word tree__V_9_9;

#line 22 "tree.m"
            tree__V_30_30 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__2_2, (MR_Integer) 0)));
#line 22 "tree.m"
            tree__V_29_29 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__2_2, (MR_Integer) 1)));
#line 22 "tree.m"
#line 22 "tree.m"
            switch (MR_tag((MR_Word) tree__HeadVar__3_3)) {
#line 22 "tree.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 22 "tree.m"
              case (MR_Integer) 0:
#line 22 "tree.m"
                *tree__HeadVar__1_1 = (MR_Integer) 2;
#line 22 "tree.m"
                break;
#line 22 "tree.m"
              case (MR_Integer) 1:
#line 22 "tree.m"
                *tree__HeadVar__1_1 = (MR_Integer) 2;
#line 22 "tree.m"
                break;
#line 22 "tree.m"
              case (MR_Integer) 2:
                {
#line 22 "tree.m"
                  MR_Word tree__V_10_10;

#line 22 "tree.m"
                  tree__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__3_3, (MR_Integer) 0)));
#line 22 "tree.m"
                  tree__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__3_3, (MR_Integer) 1)));
#line 22 "tree.m"
                  {
#line 22 "tree.m"
                    tree____Compare____tree_1_0(tree__TypeInfo_for_T_23, &tree__V_10_10, tree__V_30_30, tree__V_8_8);
                  }
#line 22 "tree.m"
                  tree__succeeded = (tree__V_10_10 == (MR_Integer) 0);
#line 22 "tree.m"
                  tree__succeeded = !(tree__succeeded);
#line 22 "tree.m"
                  if (tree__succeeded)
#line 22 "tree.m"
                    *tree__HeadVar__1_1 = tree__V_10_10;
#line 22 "tree.m"
                  else
#line 22 "tree.m"
                    {
#line 22 "tree.m"
                      /* direct tailcall eliminated */
#line 22 "tree.m"
                      {
#line 22 "tree.m"
                        MR_Word tree__HeadVar__2__tmp_copy_2 = tree__V_29_29;
#line 22 "tree.m"
                        MR_Word tree__HeadVar__3__tmp_copy_3 = tree__V_9_9;

#line 22 "tree.m"
                        tree__HeadVar__2_2 = tree__HeadVar__2__tmp_copy_2;
#line 22 "tree.m"
                        tree__HeadVar__3_3 = tree__HeadVar__3__tmp_copy_3;
#line 22 "tree.m"
                      }
#line 22 "tree.m"
                      goto loop_top;
#line 22 "tree.m"
                    }
                }
#line 22 "tree.m"
                break;
#line 22 "tree.m"
            }
          }
#line 22 "tree.m"
          break;
#line 22 "tree.m"
      }
#line 22 "tree.m"
    }
#line 22 "tree.m"
  }
#line 22 "tree.m"
}

#line 22 "tree.m"
bool MR_CALL tree____Unify____tree_1_0(
#line 22 "tree.m"
  MR_Word tree__TypeInfo_for_T_9,
#line 22 "tree.m"
  MR_Word tree__HeadVar__1_1,
#line 22 "tree.m"
  MR_Word tree__HeadVar__2_2)
#line 22 "tree.m"
{
#line 22 "tree.m"
  {
#line 22 "tree.m"
    /* tailcall optimized into a loop */
#line 22 "tree.m"
  loop_top:;
#line 22 "tree.m"
    {
#line 22 "tree.m"
      bool tree__succeeded;
#line 22 "tree.m"
      MR_Box tree__V_3_3;
#line 22 "tree.m"
      MR_Box tree__V_4_4;
#line 22 "tree.m"
      MR_Word tree__V_5_5;
#line 22 "tree.m"
      MR_Word tree__V_6_6;
#line 22 "tree.m"
      MR_Word tree__V_7_7;
#line 22 "tree.m"
      MR_Word tree__V_8_8;

#line 22 "tree.m"
#line 22 "tree.m"
      switch (MR_tag((MR_Word) tree__HeadVar__1_1)) {
#line 22 "tree.m"
        default: /*NOTREACHED*/ MR_assert(0);
#line 22 "tree.m"
        case (MR_Integer) 0:
#line 22 "tree.m"
          tree__succeeded = (tree__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
#line 22 "tree.m"
          break;
#line 22 "tree.m"
        case (MR_Integer) 1:
          {
#line 22 "tree.m"
            tree__V_3_3 = (MR_hl_field(MR_mktag(1), tree__HeadVar__1_1, (MR_Integer) 0));
#line 22 "tree.m"
            tree__succeeded = (MR_tag((MR_Word) tree__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 22 "tree.m"
            if ((MR_tag((MR_Word) tree__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 22 "tree.m"
              tree__V_4_4 = (MR_hl_field(MR_mktag(1), tree__HeadVar__2_2, (MR_Integer) 0));
            if (tree__succeeded)
              {
                return tree__succeeded = mercury__builtin__unify_2_p_0(tree__TypeInfo_for_T_9, tree__V_3_3, tree__V_4_4);
              }
          }
#line 22 "tree.m"
          break;
#line 22 "tree.m"
        case (MR_Integer) 2:
          {
#line 22 "tree.m"
            tree__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__1_1, (MR_Integer) 0)));
#line 22 "tree.m"
            tree__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__1_1, (MR_Integer) 1)));
#line 22 "tree.m"
            tree__succeeded = (MR_tag((MR_Word) tree__HeadVar__2_2) == MR_mktag((MR_Integer) 2));
#line 22 "tree.m"
            if ((MR_tag((MR_Word) tree__HeadVar__2_2) == MR_mktag((MR_Integer) 2)))
#line 22 "tree.m"
              {
#line 22 "tree.m"
                tree__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__2_2, (MR_Integer) 0)));
#line 22 "tree.m"
                tree__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__2_2, (MR_Integer) 1)));
#line 22 "tree.m"
              }
            if (tree__succeeded)
              {
                {
                  tree__succeeded = tree____Unify____tree_1_0(tree__TypeInfo_for_T_9, tree__V_5_5, tree__V_7_7);
                }
                if (tree__succeeded)
                  {
                    /* direct tailcall eliminated */
                    {
                      MR_Word tree__HeadVar__1__tmp_copy_1 = tree__V_6_6;
                      MR_Word tree__HeadVar__2__tmp_copy_2 = tree__V_8_8;

                      tree__HeadVar__1_1 = tree__HeadVar__1__tmp_copy_1;
                      tree__HeadVar__2_2 = tree__HeadVar__2__tmp_copy_2;
                    }
                    goto loop_top;
                  }
              }
          }
#line 22 "tree.m"
          break;
#line 22 "tree.m"
      }
#line 22 "tree.m"
      return tree__succeeded;
#line 22 "tree.m"
    }
#line 22 "tree.m"
  }
#line 22 "tree.m"
}

#line 43 "tree.m"
void MR_CALL tree__flatten_2_3_p_0(
#line 43 "tree.m"
  MR_Word tree__TypeInfo_for_T_12,
#line 43 "tree.m"
  MR_Word tree__HeadVar__1_1,
#line 43 "tree.m"
  MR_Word tree__HeadVar__2_2,
#line 43 "tree.m"
  MR_Word * tree__HeadVar__3_3)
#line 43 "tree.m"
{
#line 46 "tree.m"
  {
#line 46 "tree.m"
    /* tailcall optimized into a loop */
#line 46 "tree.m"
  loop_top:;
#line 46 "tree.m"
    {
#line 46 "tree.m"
      bool tree__succeeded;
#line 46 "tree.m"
      MR_Box tree__T_5;
#line 46 "tree.m"
      MR_Word tree__T1_7;
#line 46 "tree.m"
      MR_Word tree__T2_8;
#line 46 "tree.m"
      MR_Word tree__L1_11;

#line 46 "tree.m"
#line 46 "tree.m"
      switch (MR_tag((MR_Word) tree__HeadVar__1_1)) {
#line 46 "tree.m"
        default: /*NOTREACHED*/ MR_assert(0);
#line 46 "tree.m"
        case (MR_Integer) 0:
#line 46 "tree.m"
          *tree__HeadVar__3_3 = tree__HeadVar__2_2;
#line 46 "tree.m"
          break;
#line 46 "tree.m"
        case (MR_Integer) 1:
          {
#line 47 "tree.m"
            tree__T_5 = (MR_hl_field(MR_mktag(1), tree__HeadVar__1_1, (MR_Integer) 0));
#line 47 "tree.m"
            {
#line 47 "tree.m"
              *tree__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 47 "tree.m"
              MR_hl_field(MR_mktag(1), *tree__HeadVar__3_3, 0) = ((MR_Box) (tree__T_5));
#line 47 "tree.m"
              MR_hl_field(MR_mktag(1), *tree__HeadVar__3_3, 1) = ((MR_Box) (tree__HeadVar__2_2));
#line 47 "tree.m"
            }
          }
#line 46 "tree.m"
          break;
#line 46 "tree.m"
        case (MR_Integer) 2:
          {
#line 48 "tree.m"
            tree__T1_7 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__1_1, (MR_Integer) 0)));
#line 48 "tree.m"
            tree__T2_8 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__1_1, (MR_Integer) 1)));
#line 49 "tree.m"
            {
#line 49 "tree.m"
              tree__flatten_2_3_p_0(tree__TypeInfo_for_T_12, tree__T2_8, tree__HeadVar__2_2, &tree__L1_11);
            }
#line 50 "tree.m"
            {
#line 50 "tree.m"
              /* direct tailcall eliminated */
#line 50 "tree.m"
              {
#line 50 "tree.m"
                MR_Word tree__HeadVar__1__tmp_copy_1 = tree__T1_7;
#line 50 "tree.m"
                MR_Word tree__HeadVar__2__tmp_copy_2 = tree__L1_11;

#line 50 "tree.m"
                tree__HeadVar__1_1 = tree__HeadVar__1__tmp_copy_1;
#line 50 "tree.m"
                tree__HeadVar__2_2 = tree__HeadVar__2__tmp_copy_2;
#line 50 "tree.m"
              }
#line 50 "tree.m"
              goto loop_top;
#line 50 "tree.m"
            }
          }
#line 46 "tree.m"
          break;
#line 46 "tree.m"
      }
#line 46 "tree.m"
    }
#line 46 "tree.m"
  }
#line 43 "tree.m"
}

#line 33 "tree.m"
bool MR_CALL tree__tree_of_lists_is_empty_1_p_0(
#line 33 "tree.m"
  MR_Word tree__TypeInfo_for_T_5,
#line 33 "tree.m"
  MR_Word tree__HeadVar__1_1)
#line 33 "tree.m"
{
#line 61 "tree.m"
  {
#line 61 "tree.m"
    /* tailcall optimized into a loop */
#line 61 "tree.m"
  loop_top:;
#line 61 "tree.m"
    {
#line 61 "tree.m"
      bool tree__succeeded;
#line 61 "tree.m"
      MR_Word tree__V_2_2;
#line 61 "tree.m"
      MR_Word tree__L_3;
#line 61 "tree.m"
      MR_Word tree__R_4;

#line 61 "tree.m"
#line 61 "tree.m"
      switch (MR_tag((MR_Word) tree__HeadVar__1_1)) {
#line 61 "tree.m"
        default: /*NOTREACHED*/ MR_assert(0);
#line 61 "tree.m"
        case (MR_Integer) 0:
          tree__succeeded = TRUE;
#line 61 "tree.m"
          break;
#line 61 "tree.m"
        case (MR_Integer) 1:
          {
#line 62 "tree.m"
            tree__V_2_2 = ((MR_Word) (MR_hl_field(MR_mktag(1), tree__HeadVar__1_1, (MR_Integer) 0)));
#line 62 "tree.m"
            tree__succeeded = (tree__V_2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));
          }
#line 61 "tree.m"
          break;
#line 61 "tree.m"
        case (MR_Integer) 2:
          {
#line 63 "tree.m"
            tree__L_3 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__1_1, (MR_Integer) 0)));
#line 63 "tree.m"
            tree__R_4 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__1_1, (MR_Integer) 1)));
#line 64 "tree.m"
            {
#line 64 "tree.m"
              tree__succeeded = tree__tree_of_lists_is_empty_1_p_0(tree__TypeInfo_for_T_5, tree__L_3);
            }
            if (tree__succeeded)
#line 65 "tree.m"
              {
#line 65 "tree.m"
                /* direct tailcall eliminated */
#line 65 "tree.m"
                {
#line 65 "tree.m"
                  MR_Word tree__HeadVar__1__tmp_copy_1 = tree__R_4;

#line 65 "tree.m"
                  tree__HeadVar__1_1 = tree__HeadVar__1__tmp_copy_1;
#line 65 "tree.m"
                }
#line 65 "tree.m"
                goto loop_top;
#line 65 "tree.m"
              }
          }
#line 61 "tree.m"
          break;
#line 61 "tree.m"
      }
#line 61 "tree.m"
      return tree__succeeded;
#line 61 "tree.m"
    }
#line 61 "tree.m"
  }
#line 33 "tree.m"
}

#line 30 "tree.m"
bool MR_CALL tree__is_empty_1_p_0(
#line 30 "tree.m"
  MR_Word tree__TypeInfo_for_T_4,
#line 30 "tree.m"
  MR_Word tree__HeadVar__1_1)
#line 30 "tree.m"
{
#line 54 "tree.m"
  {
#line 54 "tree.m"
    /* tailcall optimized into a loop */
#line 54 "tree.m"
  loop_top:;
#line 54 "tree.m"
    {
#line 54 "tree.m"
      bool tree__succeeded;
#line 54 "tree.m"
      MR_Word tree__L_2;
#line 54 "tree.m"
      MR_Word tree__R_3;

#line 54 "tree.m"
      if ((tree__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
        tree__succeeded = TRUE;
#line 54 "tree.m"
      else
#line 54 "tree.m"
        if ((MR_tag((MR_Word) tree__HeadVar__1_1) == MR_mktag((MR_Integer) 2)))
          {
#line 55 "tree.m"
            tree__L_2 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__1_1, (MR_Integer) 0)));
#line 55 "tree.m"
            tree__R_3 = ((MR_Word) (MR_hl_field(MR_mktag(2), tree__HeadVar__1_1, (MR_Integer) 1)));
#line 56 "tree.m"
            {
#line 56 "tree.m"
              tree__succeeded = tree__is_empty_1_p_0(tree__TypeInfo_for_T_4, tree__L_2);
            }
            if (tree__succeeded)
#line 57 "tree.m"
              {
#line 57 "tree.m"
                /* direct tailcall eliminated */
#line 57 "tree.m"
                {
#line 57 "tree.m"
                  MR_Word tree__HeadVar__1__tmp_copy_1 = tree__R_3;

#line 57 "tree.m"
                  tree__HeadVar__1_1 = tree__HeadVar__1__tmp_copy_1;
#line 57 "tree.m"
                }
#line 57 "tree.m"
                goto loop_top;
#line 57 "tree.m"
              }
          }
#line 54 "tree.m"
        else
#line 54 "tree.m"
          tree__succeeded = FALSE;
#line 54 "tree.m"
      return tree__succeeded;
#line 54 "tree.m"
    }
#line 54 "tree.m"
  }
#line 30 "tree.m"
}

#line 27 "tree.m"
void MR_CALL tree__flatten_2_p_0(
#line 27 "tree.m"
  MR_Word tree__TypeInfo_for_T_6,
#line 27 "tree.m"
  MR_Word tree__HeadVar__1_1,
#line 27 "tree.m"
  MR_Word * tree__HeadVar__2_2)
#line 27 "tree.m"
{
  {
    bool tree__succeeded;
    MR_Word tree__V_5_5 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));

#line 40 "tree.m"
    {
#line 40 "tree.m"
      tree__flatten_2_3_p_0(tree__TypeInfo_for_T_6, tree__HeadVar__1_1, tree__V_5_5, tree__HeadVar__2_2);
#line 40 "tree.m"
      return;
    }
  }
#line 27 "tree.m"
}

void mercury__tree__init(void)
{
}

void mercury__tree__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&tree__tree__type_ctor_info_tree_1);
}

void mercury__tree__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module tree. */
