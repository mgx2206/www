/*
** Automatically generated from `eval_util.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module eval_util. */
/* :- implementation. */

#include "eval_util.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.benchmarking.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "eval.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "globals.h"
#include "gml.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "op.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "peephole.h"
#include "mercury.pprint.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "renderer.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "space_partition.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "trans.h"
#include "transform_object.h"
#include "tree.h"
#include "mercury.tree234.h"
#include "mercury.varset.h"
#include "vector.h"



static const MR_DuFunctorDescPtr eval_util__eval_util__du_name_ordered_unequal_stacks_exception_0[1];
static const MR_DuFunctorDesc eval_util__eval_util__du_functor_desc_unequal_stacks_exception_0_0;
static const MR_PseudoTypeInfo eval_util__eval_util__field_types_unequal_stacks_exception_0_0[3];
static const MR_FO_PseudoTypeInfo_Struct1 eval_util__list__type_info_list_1__type0_13_eval__value_0;
static const MR_DuPtagLayout eval_util__eval_util__du_ptag_ordered_unequal_stacks_exception_0[1];
static const MR_DuFunctorDescPtr eval_util__eval_util__du_stag_ordered_unequal_stacks_exception_0_0[1];
#line 154 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL eval_util__foldl__ho10_4_p_in__list_0(
#line 154 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word eval_util__HeadVar__2_2);
#line 154 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL eval_util__foldl__ho5_4_p_in__list_0(
#line 154 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word eval_util__HeadVar__2_2);
#line 136 "eval_util.m"
static void MR_CALL eval_util__indent_3_p_0(
#line 136 "eval_util.m"
  MR_Integer eval_util__HeadVar__1_1);
static void MR_CALL eval_util__write_env_3_p_0_1(
  MR_Box eval_util__closure_arg,
  MR_Box eval_util__wrapper_arg_1,
  MR_Box eval_util__wrapper_arg_2,
  MR_Box eval_util__wrapper_arg_3,
  MR_Box * eval_util__wrapper_arg_4);
static /* final */ const MR_Box eval_util__const_0_0_1_HeadVar__1_20[3];



const MR_TypeCtorInfo_Struct eval_util__eval_util__type_ctor_info_unequal_stacks_exception_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval_util____Unify____unequal_stacks_exception_0_0)),
		((MR_Box) (eval_util____Unify____unequal_stacks_exception_0_0)),
		((MR_Box) (eval_util____Compare____unequal_stacks_exception_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval_util",
		(MR_String) "unequal_stacks_exception",
		(MR_Integer) 4,
		{
		(MR_Box) eval_util__eval_util__du_name_ordered_unequal_stacks_exception_0},
		{
		(MR_Box) eval_util__eval_util__du_ptag_ordered_unequal_stacks_exception_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
static const MR_DuFunctorDescPtr eval_util__eval_util__du_name_ordered_unequal_stacks_exception_0[1] = {
		(&eval_util__eval_util__du_functor_desc_unequal_stacks_exception_0_0)};
static const MR_DuFunctorDesc eval_util__eval_util__du_functor_desc_unequal_stacks_exception_0_0 = {
		(MR_String) "unequal_stacks_exception",
		(MR_Integer) 3,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		eval_util__eval_util__field_types_unequal_stacks_exception_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval_util__eval_util__field_types_unequal_stacks_exception_0_0[3] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0),
		(MR_PseudoTypeInfo) (&eval_util__list__type_info_list_1__type0_13_eval__value_0),
		(MR_PseudoTypeInfo) (&eval_util__list__type_info_list_1__type0_13_eval__value_0)};
static const MR_FO_PseudoTypeInfo_Struct1 eval_util__list__type_info_list_1__type0_13_eval__value_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_value_0)}};
static const MR_DuPtagLayout eval_util__eval_util__du_ptag_ordered_unequal_stacks_exception_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval_util__eval_util__du_stag_ordered_unequal_stacks_exception_0_0}};
static const MR_DuFunctorDescPtr eval_util__eval_util__du_stag_ordered_unequal_stacks_exception_0_0[1] = {
		(&eval_util__eval_util__du_functor_desc_unequal_stacks_exception_0_0)};

#line 154 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL eval_util__foldl__ho10_4_p_in__list_0(
#line 154 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word eval_util__HeadVar__2_2)
#line 154 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    /* tailcall optimized into a loop */
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  loop_top:;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      bool eval_util__succeeded;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_String eval_util__H_8_8;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Word eval_util__T_9_9;

#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      if ((eval_util__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      else
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 150 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          eval_util__H_8_8 = ((MR_String) (MR_hl_field(MR_mktag(1), eval_util__HeadVar__2_2, (MR_Integer) 0)));
#line 150 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          eval_util__T_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval_util__HeadVar__2_2, (MR_Integer) 1)));
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL eval_util__foldl__ho10_4_p_in__list_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
eval_util__H_8_8
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          {
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            /* direct tailcall eliminated */
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            {
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_Word eval_util__HeadVar__2__tmp_copy_2 = eval_util__T_9_9;

#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              eval_util__HeadVar__2_2 = eval_util__HeadVar__2__tmp_copy_2;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            }
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            goto loop_top;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 154 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 154 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL eval_util__foldl__ho5_4_p_in__list_0(
#line 154 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word eval_util__HeadVar__2_2)
#line 154 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    /* tailcall optimized into a loop */
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  loop_top:;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      bool eval_util__succeeded;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Word eval_util__H_8_8;
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      MR_Word eval_util__T_9_9;

#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      if ((eval_util__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      else
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 150 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          eval_util__H_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval_util__HeadVar__2_2, (MR_Integer) 0)));
#line 150 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          eval_util__T_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval_util__HeadVar__2_2, (MR_Integer) 1)));
#line 151 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          {
#line 151 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            eval_util__write_stack_entry_3_p_0(eval_util__H_8_8);
          }
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          {
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            /* direct tailcall eliminated */
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            {
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              MR_Word eval_util__HeadVar__2__tmp_copy_2 = eval_util__T_9_9;

#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
              eval_util__HeadVar__2_2 = eval_util__HeadVar__2__tmp_copy_2;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            }
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            goto loop_top;
#line 152 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    }
#line 149 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 154 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 16 "eval_util.m"
void MR_CALL eval_util____Compare____unequal_stacks_exception_0_0(
#line 16 "eval_util.m"
  MR_Word * eval_util__HeadVar__1_1,
#line 16 "eval_util.m"
  MR_Word eval_util__HeadVar__2_2,
#line 16 "eval_util.m"
  MR_Word eval_util__HeadVar__3_3)
#line 16 "eval_util.m"
{
  {
    bool eval_util__succeeded;
    MR_String eval_util__V_4_4 = ((MR_String) (MR_hl_field(MR_mktag(0), eval_util__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word eval_util__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word eval_util__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__HeadVar__2_2, (MR_Integer) 2)));
    MR_String eval_util__V_7_7 = ((MR_String) (MR_hl_field(MR_mktag(0), eval_util__HeadVar__3_3, (MR_Integer) 0)));
    MR_Word eval_util__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__HeadVar__3_3, (MR_Integer) 1)));
    MR_Word eval_util__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__HeadVar__3_3, (MR_Integer) 2)));
#line 16 "eval_util.m"
    MR_Word eval_util__V_10_10;
    MR_Integer eval_util__Res_7_22;
    MR_Integer eval_util__V_27_27;

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL eval_util____Compare____unequal_stacks_exception_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval_util__V_4_4
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval_util__V_7_7
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval_util__Res_7_22
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    eval_util__V_27_27 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    eval_util__succeeded = (eval_util__Res_7_22 < eval_util__V_27_27);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (eval_util__succeeded)
      {
        MR_Word eval_util__V_28_28 = (MR_Integer) 1;

#line 16 "eval_util.m"
        eval_util__succeeded = (eval_util__V_28_28 == (MR_Integer) 0);
#line 16 "eval_util.m"
        eval_util__succeeded = !(eval_util__succeeded);
        if (eval_util__succeeded)
          {
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            eval_util__V_10_10 = (MR_Integer) 1;
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            eval_util__succeeded = TRUE;
          }
      }
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        eval_util__succeeded = (eval_util__Res_7_22 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (eval_util__succeeded)
          {
            MR_Word eval_util__V_29_29 = (MR_Integer) 0;

#line 16 "eval_util.m"
            eval_util__succeeded = (eval_util__V_29_29 == (MR_Integer) 0);
#line 16 "eval_util.m"
            eval_util__succeeded = !(eval_util__succeeded);
            if (eval_util__succeeded)
              {
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval_util__V_10_10 = (MR_Integer) 0;
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval_util__succeeded = TRUE;
              }
          }
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
          {
            MR_Word eval_util__V_30_30 = (MR_Integer) 2;

#line 16 "eval_util.m"
            eval_util__succeeded = (eval_util__V_30_30 == (MR_Integer) 0);
#line 16 "eval_util.m"
            eval_util__succeeded = !(eval_util__succeeded);
            if (eval_util__succeeded)
              {
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval_util__V_10_10 = (MR_Integer) 2;
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval_util__succeeded = TRUE;
              }
          }
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 16 "eval_util.m"
    if (eval_util__succeeded)
#line 16 "eval_util.m"
      *eval_util__HeadVar__1_1 = eval_util__V_10_10;
#line 16 "eval_util.m"
    else
#line 16 "eval_util.m"
      {
#line 16 "eval_util.m"
        MR_Word eval_util__V_11_11;
        MR_Word eval_util__TypeInfo_13_13 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 16 "eval_util.m"
        {
#line 16 "eval_util.m"
          mercury__list____Compare____list_1_0(eval_util__TypeInfo_13_13, &eval_util__V_11_11, eval_util__V_5_5, eval_util__V_8_8);
        }
#line 16 "eval_util.m"
        eval_util__succeeded = (eval_util__V_11_11 == (MR_Integer) 0);
#line 16 "eval_util.m"
        eval_util__succeeded = !(eval_util__succeeded);
#line 16 "eval_util.m"
        if (eval_util__succeeded)
#line 16 "eval_util.m"
          *eval_util__HeadVar__1_1 = eval_util__V_11_11;
#line 16 "eval_util.m"
        else
          {
            MR_Word eval_util__TypeInfo_16_16 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 16 "eval_util.m"
            {
#line 16 "eval_util.m"
              mercury__list____Compare____list_1_0(eval_util__TypeInfo_16_16, eval_util__HeadVar__1_1, eval_util__V_6_6, eval_util__V_9_9);
#line 16 "eval_util.m"
              return;
            }
          }
#line 16 "eval_util.m"
      }
  }
#line 16 "eval_util.m"
}

#line 16 "eval_util.m"
bool MR_CALL eval_util____Unify____unequal_stacks_exception_0_0(
#line 16 "eval_util.m"
  MR_Word eval_util__HeadVar__1_1,
#line 16 "eval_util.m"
  MR_Word eval_util__HeadVar__2_2)
#line 16 "eval_util.m"
{
  {
    bool eval_util__succeeded;
    MR_String eval_util__V_3_3 = ((MR_String) (MR_hl_field(MR_mktag(0), eval_util__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word eval_util__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word eval_util__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__HeadVar__1_1, (MR_Integer) 2)));
    MR_String eval_util__V_6_6 = ((MR_String) (MR_hl_field(MR_mktag(0), eval_util__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word eval_util__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word eval_util__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word eval_util__TypeInfo_9_9;
    MR_Word eval_util__TypeInfo_12_12;

    eval_util__succeeded = (strcmp(eval_util__V_3_3, eval_util__V_6_6) == 0);
    if (eval_util__succeeded)
      {
        eval_util__TypeInfo_9_9 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
        {
          eval_util__succeeded = mercury__list____Unify____list_1_0(eval_util__TypeInfo_9_9, eval_util__V_4_4, eval_util__V_7_7);
        }
        if (eval_util__succeeded)
          {
            eval_util__TypeInfo_12_12 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
            {
              return eval_util__succeeded = mercury__list____Unify____list_1_0(eval_util__TypeInfo_12_12, eval_util__V_5_5, eval_util__V_8_8);
            }
          }
      }
    return eval_util__succeeded;
  }
#line 16 "eval_util.m"
}

#line 136 "eval_util.m"
static void MR_CALL eval_util__indent_3_p_0(
#line 136 "eval_util.m"
  MR_Integer eval_util__HeadVar__1_1)
#line 136 "eval_util.m"
{
#line 141 "eval_util.m"
  {
#line 141 "eval_util.m"
    /* tailcall optimized into a loop */
#line 141 "eval_util.m"
  loop_top:;
#line 141 "eval_util.m"
    {
#line 141 "eval_util.m"
      bool eval_util__succeeded = (eval_util__HeadVar__1_1 == (MR_Integer) 0);

#line 141 "eval_util.m"
      if (eval_util__succeeded)
#line 140 "eval_util.m"
        {
#line 140 "eval_util.m"
        }
#line 141 "eval_util.m"
      else
        {
          MR_Integer eval_util__V_9_9;
          MR_Integer eval_util__V_10_10;
          MR_String eval_util__V_11_11 = (MR_String) "   ";

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL eval_util__indent_3_p_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
eval_util__V_11_11
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 143 "eval_util.m"
          eval_util__V_10_10 = (MR_Integer) 1;
#line 143 "eval_util.m"
          eval_util__V_9_9 = (eval_util__HeadVar__1_1 - eval_util__V_10_10);
#line 143 "eval_util.m"
          {
#line 143 "eval_util.m"
            /* direct tailcall eliminated */
#line 143 "eval_util.m"
            {
#line 143 "eval_util.m"
              MR_Integer eval_util__HeadVar__1__tmp_copy_1 = eval_util__V_9_9;

#line 143 "eval_util.m"
              eval_util__HeadVar__1_1 = eval_util__HeadVar__1__tmp_copy_1;
#line 143 "eval_util.m"
            }
#line 143 "eval_util.m"
            goto loop_top;
#line 143 "eval_util.m"
          }
        }
#line 141 "eval_util.m"
    }
#line 141 "eval_util.m"
  }
#line 136 "eval_util.m"
}

#line 117 "eval_util.m"
void MR_CALL eval_util__write_group_4_p_0(
#line 117 "eval_util.m"
  MR_Integer eval_util__HeadVar__1_1,
#line 117 "eval_util.m"
  MR_Word eval_util__HeadVar__2_2)
#line 117 "eval_util.m"
{
#line 120 "eval_util.m"
  {
#line 120 "eval_util.m"
    bool eval_util__succeeded;

#line 120 "eval_util.m"
#line 120 "eval_util.m"
    switch (MR_tag((MR_Word) eval_util__HeadVar__2_2)) {
#line 120 "eval_util.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 120 "eval_util.m"
      case (MR_Integer) 0:
        {
          MR_Word eval_util__SingleToken_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__HeadVar__2_2, (MR_Integer) 0)));
          MR_Word eval_util__TypeInfo_34_34;
          MR_Word eval_util__Univ_5_50;
          MR_Integer eval_util__MaxPriority_5_54;
          MR_Integer eval_util__V_8_55;
          MR_Integer eval_util__V_9_56;

#line 121 "eval_util.m"
          {
#line 121 "eval_util.m"
            eval_util__indent_3_p_0(eval_util__HeadVar__1_1);
          }
          eval_util__TypeInfo_34_34 = (MR_Word) (&gml__gml__type_ctor_info_token_0);
#line 270 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          {
#line 270 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            mercury__std_util__type_to_univ_2_p_1(eval_util__TypeInfo_34_34, ((MR_Box) (eval_util__SingleToken_6)), &eval_util__Univ_5_50);
          }
#line 708 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          {
#line 708 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            mercury__ops__max_priority_1_p_0(&eval_util__MaxPriority_5_54);
          }
#line 710 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          eval_util__V_9_56 = (MR_Integer) 1;
#line 709 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          eval_util__V_8_55 = (eval_util__MaxPriority_5_54 + eval_util__V_9_56);
#line 711 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          {
#line 711 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            mercury__io__write_univ_4_p_0(eval_util__Univ_5_50, eval_util__V_8_55);
#line 711 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
            return;
          }
        }
#line 120 "eval_util.m"
        break;
#line 120 "eval_util.m"
      case (MR_Integer) 1:
        {
          MR_Word eval_util__List_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval_util__HeadVar__2_2, (MR_Integer) 0)));
          MR_String eval_util__V_18_18;
          MR_Integer eval_util__V_19_19;
          MR_Integer eval_util__V_20_20;
          MR_String eval_util__V_21_21;

#line 124 "eval_util.m"
          {
#line 124 "eval_util.m"
            eval_util__indent_3_p_0(eval_util__HeadVar__1_1);
          }
#line 125 "eval_util.m"
          eval_util__V_21_21 = (MR_String) "{\n";
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL eval_util__write_group_4_p_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
eval_util__V_21_21
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 126 "eval_util.m"
          eval_util__V_20_20 = (MR_Integer) 1;
#line 126 "eval_util.m"
          eval_util__V_19_19 = (eval_util__HeadVar__1_1 + eval_util__V_20_20);
#line 126 "eval_util.m"
          {
#line 126 "eval_util.m"
            eval_util__write_prog_4_p_0(eval_util__V_19_19, eval_util__List_11);
          }
#line 127 "eval_util.m"
          {
#line 127 "eval_util.m"
            eval_util__indent_3_p_0(eval_util__HeadVar__1_1);
          }
#line 128 "eval_util.m"
          eval_util__V_18_18 = (MR_String) "}";
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL eval_util__write_group_4_p_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
eval_util__V_18_18
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
        }
#line 120 "eval_util.m"
        break;
#line 120 "eval_util.m"
      case (MR_Integer) 2:
        {
          MR_Word eval_util__List_23 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval_util__HeadVar__2_2, (MR_Integer) 0)));
          MR_String eval_util__V_30_30;
          MR_Integer eval_util__V_31_31;
          MR_Integer eval_util__V_32_32;
          MR_String eval_util__V_33_33;

#line 130 "eval_util.m"
          {
#line 130 "eval_util.m"
            eval_util__indent_3_p_0(eval_util__HeadVar__1_1);
          }
#line 131 "eval_util.m"
          eval_util__V_33_33 = (MR_String) "[\n";
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL eval_util__write_group_4_p_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
eval_util__V_33_33
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 132 "eval_util.m"
          eval_util__V_32_32 = (MR_Integer) 1;
#line 132 "eval_util.m"
          eval_util__V_31_31 = (eval_util__HeadVar__1_1 + eval_util__V_32_32);
#line 132 "eval_util.m"
          {
#line 132 "eval_util.m"
            eval_util__write_prog_4_p_0(eval_util__V_31_31, eval_util__List_23);
          }
#line 133 "eval_util.m"
          {
#line 133 "eval_util.m"
            eval_util__indent_3_p_0(eval_util__HeadVar__1_1);
          }
#line 134 "eval_util.m"
          eval_util__V_30_30 = (MR_String) "]";
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL eval_util__write_group_4_p_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
eval_util__V_30_30
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
        }
#line 120 "eval_util.m"
        break;
#line 120 "eval_util.m"
    }
#line 120 "eval_util.m"
  }
#line 117 "eval_util.m"
}

#line 104 "eval_util.m"
void MR_CALL eval_util__write_stack_entry_3_p_0(
#line 104 "eval_util.m"
  MR_Word eval_util__HeadVar__1_1)
#line 104 "eval_util.m"
{
  {
    bool eval_util__succeeded;
    MR_Integer eval_util__V_8_8 = (MR_Integer) 80;
    MR_Word eval_util__V_9_9;
    MR_Integer eval_util__V_10_10 = (MR_Integer) 3;
    MR_Word eval_util__TypeInfo_11_11 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
    MR_Word eval_util__V_11_27;
    MR_Integer eval_util__V_12_28;
    MR_Char eval_util__V_5_39;

#line 106 "eval_util.m"
    {
#line 106 "eval_util.m"
      eval_util__V_9_9 = mercury__pprint__to_doc_3_f_0(eval_util__TypeInfo_11_11, eval_util__V_10_10, ((MR_Box) (eval_util__HeadVar__1_1)));
    }
#line 124 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/pprint.opt"
    eval_util__V_12_28 = (MR_Integer) 0;
#line 123 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/pprint.opt"
    {
#line 123 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/pprint.opt"
      eval_util__V_11_27 = mercury__pprint__best_4_f_0(eval_util__V_8_8, eval_util__V_12_28, eval_util__V_9_9);
    }
#line 127 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/pprint.opt"
    {
#line 127 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/pprint.opt"
      eval_util__foldl__ho10_4_p_in__list_0(eval_util__V_11_27);
    }
#line 277 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    eval_util__V_5_39 = (MR_Integer) 10;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL eval_util__write_stack_entry_3_p_0
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Char Character;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Character = 
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
eval_util__V_5_39
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	if (MR_PUTCH(*mercury_current_text_output, Character) < 0) {
		mercury_output_error(mercury_current_text_output);
	}
	if (Character == '\n') {
		MR_line_number(*mercury_current_text_output)++;
	}
	update_io(IO0, IO);

#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
  }
#line 104 "eval_util.m"
}

#line 93 "eval_util.m"
void MR_CALL eval_util__write_env_entry_4_p_0(
#line 93 "eval_util.m"
  MR_String eval_util__HeadVar__1_1,
#line 93 "eval_util.m"
  MR_Word eval_util__HeadVar__2_2)
#line 93 "eval_util.m"
{
  {
    bool eval_util__succeeded;
    MR_String eval_util__V_12_12;
    MR_Word eval_util__TypeInfo_13_13;
    MR_Word eval_util__Univ_5_23;
    MR_Integer eval_util__MaxPriority_5_27;
    MR_Integer eval_util__V_8_28;
    MR_Integer eval_util__V_9_29;
    MR_Char eval_util__V_5_32;

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL eval_util__write_env_entry_4_p_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
eval_util__HeadVar__1_1
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 96 "eval_util.m"
    eval_util__V_12_12 = (MR_String) "\t: ";
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL eval_util__write_env_entry_4_p_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
eval_util__V_12_12
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
    eval_util__TypeInfo_13_13 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
#line 270 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    {
#line 270 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      mercury__std_util__type_to_univ_2_p_1(eval_util__TypeInfo_13_13, ((MR_Box) (eval_util__HeadVar__2_2)), &eval_util__Univ_5_23);
    }
#line 708 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    {
#line 708 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      mercury__ops__max_priority_1_p_0(&eval_util__MaxPriority_5_27);
    }
#line 710 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    eval_util__V_9_29 = (MR_Integer) 1;
#line 709 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    eval_util__V_8_28 = (eval_util__MaxPriority_5_27 + eval_util__V_9_29);
#line 711 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    {
#line 711 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
      mercury__io__write_univ_4_p_0(eval_util__Univ_5_23, eval_util__V_8_28);
    }
#line 277 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
    eval_util__V_5_32 = (MR_Integer) 10;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL eval_util__write_env_entry_4_p_0
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Char Character;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Character = 
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
eval_util__V_5_32
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	if (MR_PUTCH(*mercury_current_text_output, Character) < 0) {
		mercury_output_error(mercury_current_text_output);
	}
	if (Character == '\n') {
		MR_line_number(*mercury_current_text_output)++;
	}
	update_io(IO0, IO);

#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
  }
#line 93 "eval_util.m"
}

#line 13 "eval_util.m"
void MR_CALL eval_util__write_prog_4_p_0(
#line 13 "eval_util.m"
  MR_Integer eval_util__HeadVar__1_1,
#line 13 "eval_util.m"
  MR_Word eval_util__HeadVar__2_2)
#line 13 "eval_util.m"
{
#line 111 "eval_util.m"
  {
#line 111 "eval_util.m"
    /* tailcall optimized into a loop */
#line 111 "eval_util.m"
  loop_top:;
#line 111 "eval_util.m"
    {
#line 111 "eval_util.m"
      bool eval_util__succeeded;

#line 111 "eval_util.m"
      if ((eval_util__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 111 "eval_util.m"
        {
#line 111 "eval_util.m"
        }
#line 111 "eval_util.m"
      else
#line 111 "eval_util.m"
        {
          MR_Word eval_util__Group_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval_util__HeadVar__2_2, (MR_Integer) 0)));
          MR_Word eval_util__Groups_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval_util__HeadVar__2_2, (MR_Integer) 1)));
          MR_Char eval_util__V_5_17;

#line 113 "eval_util.m"
          {
#line 113 "eval_util.m"
            eval_util__write_group_4_p_0(eval_util__HeadVar__1_1, eval_util__Group_9);
          }
#line 277 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
          eval_util__V_5_17 = (MR_Integer) 10;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL eval_util__write_prog_4_p_0
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Char Character;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Character = 
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
eval_util__V_5_17
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	if (MR_PUTCH(*mercury_current_text_output, Character) < 0) {
		mercury_output_error(mercury_current_text_output);
	}
	if (Character == '\n') {
		MR_line_number(*mercury_current_text_output)++;
	}
	update_io(IO0, IO);

#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 294 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 115 "eval_util.m"
          {
#line 115 "eval_util.m"
            /* direct tailcall eliminated */
#line 115 "eval_util.m"
            {
#line 115 "eval_util.m"
              MR_Word eval_util__HeadVar__2__tmp_copy_2 = eval_util__Groups_10;

#line 115 "eval_util.m"
              eval_util__HeadVar__2_2 = eval_util__HeadVar__2__tmp_copy_2;
#line 115 "eval_util.m"
            }
#line 115 "eval_util.m"
            goto loop_top;
#line 115 "eval_util.m"
          }
#line 111 "eval_util.m"
        }
#line 111 "eval_util.m"
    }
#line 111 "eval_util.m"
  }
#line 13 "eval_util.m"
}

#line 11 "eval_util.m"
void MR_CALL eval_util__write_nice_exception_3_p_0(
#line 11 "eval_util.m"
  MR_Word eval_util__HeadVar__1_1)
#line 11 "eval_util.m"
{
  {
    bool eval_util__succeeded;
    MR_Word eval_util__StdErr_5;
    MR_Word eval_util__OldStream_6;
#line 37 "eval_util.m"
    MR_String eval_util__Msg_7;
#line 37 "eval_util.m"
    MR_Word eval_util__Stack_8;
#line 37 "eval_util.m"
    MR_Word eval_util__Opt_9;
    MR_Word eval_util__V_51_51;
    MR_Word eval_util__TypeInfo_87_87;
#line 28 "eval_util.m"
    MR_Box eval_util__conv1_V_51_51;
#line 86 "eval_util.m"
    MR_Word eval_util__V_14_14;

#line 25 "eval_util.m"
    {
#line 25 "eval_util.m"
      mercury__io__stderr_stream_3_p_0(&eval_util__StdErr_5);
    }
#line 26 "eval_util.m"
    {
#line 26 "eval_util.m"
      mercury__io__set_output_stream_4_p_0(eval_util__StdErr_5, &eval_util__OldStream_6);
    }
    eval_util__TypeInfo_87_87 = (MR_Word) (&eval_util__eval_util__type_ctor_info_unequal_stacks_exception_0);
#line 28 "eval_util.m"
    {
#line 28 "eval_util.m"
      eval_util__succeeded = mercury__std_util__univ_to_type_2_p_0(eval_util__TypeInfo_87_87, eval_util__HeadVar__1_1, &eval_util__conv1_V_51_51);
    }
#line 28 "eval_util.m"
    if (eval_util__succeeded)
#line 28 "eval_util.m"
      {
#line 28 "eval_util.m"
        eval_util__V_51_51 = ((MR_Word) eval_util__conv1_V_51_51);
#line 28 "eval_util.m"
        eval_util__succeeded = TRUE;
#line 28 "eval_util.m"
      }
    if (eval_util__succeeded)
      {
#line 28 "eval_util.m"
        eval_util__Msg_7 = ((MR_String) (MR_hl_field(MR_mktag(0), eval_util__V_51_51, (MR_Integer) 0)));
#line 28 "eval_util.m"
        eval_util__Stack_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__V_51_51, (MR_Integer) 1)));
#line 28 "eval_util.m"
        eval_util__Opt_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__V_51_51, (MR_Integer) 2)));
#line 28 "eval_util.m"
        eval_util__succeeded = TRUE;
      }
#line 37 "eval_util.m"
    if (eval_util__succeeded)
      {
        MR_String eval_util__V_52_52;
        MR_String eval_util__V_53_53;
        MR_String eval_util__V_54_54 = (MR_String) "Exception: ";

#line 30 "eval_util.m"
        {
#line 30 "eval_util.m"
          mercury__io__write_string_3_p_0(eval_util__V_54_54);
        }
#line 31 "eval_util.m"
        {
#line 31 "eval_util.m"
          mercury__io__write_string_3_p_0(eval_util__Msg_7);
        }
#line 32 "eval_util.m"
        {
#line 32 "eval_util.m"
          mercury__io__nl_2_p_0();
        }
#line 33 "eval_util.m"
        eval_util__V_53_53 = (MR_String) "Unoptimized ";
#line 33 "eval_util.m"
        {
#line 33 "eval_util.m"
          mercury__io__write_string_3_p_0(eval_util__V_53_53);
        }
#line 34 "eval_util.m"
        {
#line 34 "eval_util.m"
          eval_util__write_stack_3_p_0(eval_util__Stack_8);
        }
#line 35 "eval_util.m"
        eval_util__V_52_52 = (MR_String) "Optimized ";
#line 35 "eval_util.m"
        {
#line 35 "eval_util.m"
          mercury__io__write_string_3_p_0(eval_util__V_52_52);
        }
#line 36 "eval_util.m"
        {
#line 36 "eval_util.m"
          eval_util__write_stack_3_p_0(eval_util__Opt_9);
        }
      }
#line 37 "eval_util.m"
    else
#line 45 "eval_util.m"
      {
#line 45 "eval_util.m"
        MR_Word eval_util__Env_10;
#line 45 "eval_util.m"
        MR_String eval_util__Msg_85;
#line 45 "eval_util.m"
        MR_Word eval_util__Stack_86;
        MR_Word eval_util__V_55_55;
        MR_Word eval_util__TypeInfo_88_88 = (MR_Word) (&eval__eval__type_ctor_info_stack_env_exception_0);
#line 38 "eval_util.m"
        MR_Box eval_util__conv2_V_55_55;

#line 38 "eval_util.m"
        {
#line 38 "eval_util.m"
          eval_util__succeeded = mercury__std_util__univ_to_type_2_p_0(eval_util__TypeInfo_88_88, eval_util__HeadVar__1_1, &eval_util__conv2_V_55_55);
        }
#line 38 "eval_util.m"
        if (eval_util__succeeded)
#line 38 "eval_util.m"
          {
#line 38 "eval_util.m"
            eval_util__V_55_55 = ((MR_Word) eval_util__conv2_V_55_55);
#line 38 "eval_util.m"
            eval_util__succeeded = TRUE;
#line 38 "eval_util.m"
          }
        if (eval_util__succeeded)
          {
#line 38 "eval_util.m"
            eval_util__Msg_85 = ((MR_String) (MR_hl_field(MR_mktag(0), eval_util__V_55_55, (MR_Integer) 0)));
#line 38 "eval_util.m"
            eval_util__Env_10 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__V_55_55, (MR_Integer) 1)));
#line 38 "eval_util.m"
            eval_util__Stack_86 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__V_55_55, (MR_Integer) 2)));
#line 38 "eval_util.m"
            eval_util__succeeded = TRUE;
          }
#line 45 "eval_util.m"
        if (eval_util__succeeded)
          {
            MR_String eval_util__V_56_56 = (MR_String) "Exception: ";

#line 40 "eval_util.m"
            {
#line 40 "eval_util.m"
              mercury__io__write_string_3_p_0(eval_util__V_56_56);
            }
#line 41 "eval_util.m"
            {
#line 41 "eval_util.m"
              mercury__io__write_string_3_p_0(eval_util__Msg_85);
            }
#line 42 "eval_util.m"
            {
#line 42 "eval_util.m"
              mercury__io__nl_2_p_0();
            }
#line 43 "eval_util.m"
            {
#line 43 "eval_util.m"
              eval_util__write_env_3_p_0(eval_util__Env_10);
            }
#line 44 "eval_util.m"
            {
#line 44 "eval_util.m"
              eval_util__write_stack_3_p_0(eval_util__Stack_86);
            }
          }
#line 45 "eval_util.m"
        else
#line 56 "eval_util.m"
          {
#line 56 "eval_util.m"
            MR_Word eval_util__Token_11;
#line 56 "eval_util.m"
            MR_String eval_util__Msg_82;
#line 56 "eval_util.m"
            MR_Word eval_util__Stack_83;
#line 56 "eval_util.m"
            MR_Word eval_util__Env_84;
            MR_Word eval_util__V_57_57;
            MR_Word eval_util__TypeInfo_89_89 = (MR_Word) (&eval__eval__type_ctor_info_stack_env_token_exception_0);
#line 46 "eval_util.m"
            MR_Box eval_util__conv3_V_57_57;

#line 46 "eval_util.m"
            {
#line 46 "eval_util.m"
              eval_util__succeeded = mercury__std_util__univ_to_type_2_p_0(eval_util__TypeInfo_89_89, eval_util__HeadVar__1_1, &eval_util__conv3_V_57_57);
            }
#line 46 "eval_util.m"
            if (eval_util__succeeded)
#line 46 "eval_util.m"
              {
#line 46 "eval_util.m"
                eval_util__V_57_57 = ((MR_Word) eval_util__conv3_V_57_57);
#line 46 "eval_util.m"
                eval_util__succeeded = TRUE;
#line 46 "eval_util.m"
              }
            if (eval_util__succeeded)
              {
#line 46 "eval_util.m"
                eval_util__Msg_82 = ((MR_String) (MR_hl_field(MR_mktag(0), eval_util__V_57_57, (MR_Integer) 0)));
#line 46 "eval_util.m"
                eval_util__Env_84 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__V_57_57, (MR_Integer) 1)));
#line 46 "eval_util.m"
                eval_util__Stack_83 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__V_57_57, (MR_Integer) 2)));
#line 46 "eval_util.m"
                eval_util__Token_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval_util__V_57_57, (MR_Integer) 3)));
#line 46 "eval_util.m"
                eval_util__succeeded = TRUE;
              }
#line 56 "eval_util.m"
            if (eval_util__succeeded)
              {
                MR_String eval_util__V_58_58;
                MR_String eval_util__V_59_59 = (MR_String) "Exception at token ";
                MR_Word eval_util__TypeInfo_90_90;

#line 49 "eval_util.m"
                {
#line 49 "eval_util.m"
                  mercury__io__write_string_3_p_0(eval_util__V_59_59);
                }
                eval_util__TypeInfo_90_90 = (MR_Word) (&gml__gml__type_ctor_info_token_0);
#line 50 "eval_util.m"
                {
#line 50 "eval_util.m"
                  mercury__io__write_3_p_0(eval_util__TypeInfo_90_90, ((MR_Box) (eval_util__Token_11)));
                }
#line 51 "eval_util.m"
                eval_util__V_58_58 = (MR_String) " : ";
#line 51 "eval_util.m"
                {
#line 51 "eval_util.m"
                  mercury__io__write_string_3_p_0(eval_util__V_58_58);
                }
#line 52 "eval_util.m"
                {
#line 52 "eval_util.m"
                  mercury__io__write_string_3_p_0(eval_util__Msg_82);
                }
#line 53 "eval_util.m"
                {
#line 53 "eval_util.m"
                  mercury__io__nl_2_p_0();
                }
#line 54 "eval_util.m"
                {
#line 54 "eval_util.m"
                  eval_util__write_env_3_p_0(eval_util__Env_84);
                }
#line 55 "eval_util.m"
                {
#line 55 "eval_util.m"
                  eval_util__write_stack_3_p_0(eval_util__Stack_83);
                }
              }
#line 56 "eval_util.m"
            else
#line 61 "eval_util.m"
              {
#line 61 "eval_util.m"
                MR_String eval_util__Msg_80;
                MR_Word eval_util__V_60_60;
                MR_Word eval_util__TypeInfo_91_91 = (MR_Word) (&gml__gml__type_ctor_info_parse_error_0);
#line 57 "eval_util.m"
                MR_Box eval_util__conv4_V_60_60;

#line 57 "eval_util.m"
                {
#line 57 "eval_util.m"
                  eval_util__succeeded = mercury__std_util__univ_to_type_2_p_0(eval_util__TypeInfo_91_91, eval_util__HeadVar__1_1, &eval_util__conv4_V_60_60);
                }
#line 57 "eval_util.m"
                if (eval_util__succeeded)
#line 57 "eval_util.m"
                  {
#line 57 "eval_util.m"
                    eval_util__V_60_60 = ((MR_Word) eval_util__conv4_V_60_60);
#line 57 "eval_util.m"
                    eval_util__succeeded = TRUE;
#line 57 "eval_util.m"
                  }
                if (eval_util__succeeded)
                  {
#line 57 "eval_util.m"
                    eval_util__Msg_80 = (MR_String) eval_util__V_60_60;
#line 57 "eval_util.m"
                    eval_util__succeeded = TRUE;
                  }
#line 61 "eval_util.m"
                if (eval_util__succeeded)
                  {
                    MR_String eval_util__V_61_61 = (MR_String) "Parse error: ";

#line 59 "eval_util.m"
                    {
#line 59 "eval_util.m"
                      mercury__io__write_string_3_p_0(eval_util__V_61_61);
                    }
#line 60 "eval_util.m"
                    {
#line 60 "eval_util.m"
                      mercury__io__write_string_3_p_0(eval_util__Msg_80);
                    }
                  }
#line 61 "eval_util.m"
                else
#line 65 "eval_util.m"
                  {
#line 65 "eval_util.m"
                    MR_Integer eval_util__N_12;
#line 65 "eval_util.m"
                    MR_String eval_util__Msg_78;
                    MR_Word eval_util__V_62_62;
                    MR_Word eval_util__TypeInfo_92_92 = (MR_Word) (&gml__gml__type_ctor_info_lexer_error_0);
#line 62 "eval_util.m"
                    MR_Box eval_util__conv5_V_62_62;

#line 62 "eval_util.m"
                    {
#line 62 "eval_util.m"
                      eval_util__succeeded = mercury__std_util__univ_to_type_2_p_0(eval_util__TypeInfo_92_92, eval_util__HeadVar__1_1, &eval_util__conv5_V_62_62);
                    }
#line 62 "eval_util.m"
                    if (eval_util__succeeded)
#line 62 "eval_util.m"
                      {
#line 62 "eval_util.m"
                        eval_util__V_62_62 = ((MR_Word) eval_util__conv5_V_62_62);
#line 62 "eval_util.m"
                        eval_util__succeeded = TRUE;
#line 62 "eval_util.m"
                      }
                    if (eval_util__succeeded)
                      {
#line 62 "eval_util.m"
                        eval_util__N_12 = ((MR_Integer) (MR_hl_field(MR_mktag(0), eval_util__V_62_62, (MR_Integer) 0)));
#line 62 "eval_util.m"
                        eval_util__Msg_78 = ((MR_String) (MR_hl_field(MR_mktag(0), eval_util__V_62_62, (MR_Integer) 1)));
#line 62 "eval_util.m"
                        eval_util__succeeded = TRUE;
                      }
#line 65 "eval_util.m"
                    if (eval_util__succeeded)
                      {
                        MR_String eval_util__V_63_63 = (MR_String) "Line %d: lexical error: %s ";
                        MR_Word eval_util__V_64_64;
                        MR_Word eval_util__V_65_65;
                        MR_Word eval_util__V_66_66;
                        MR_Word eval_util__V_67_67;
                        MR_Word eval_util__V_68_68;

#line 64 "eval_util.m"
                        {
#line 64 "eval_util.m"
                          eval_util__V_65_65 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "i"));
#line 64 "eval_util.m"
                          MR_hl_field(MR_mktag(1), eval_util__V_65_65, 0) = ((MR_Box) (eval_util__N_12));
#line 64 "eval_util.m"
                        }
#line 64 "eval_util.m"
                        {
#line 64 "eval_util.m"
                          eval_util__V_67_67 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "s"));
#line 64 "eval_util.m"
                          MR_hl_field(MR_mktag(2), eval_util__V_67_67, 0) = ((MR_Box) (eval_util__Msg_78));
#line 64 "eval_util.m"
                        }
#line 64 "eval_util.m"
                        eval_util__V_68_68 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 64 "eval_util.m"
                        {
#line 64 "eval_util.m"
                          eval_util__V_66_66 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 64 "eval_util.m"
                          MR_hl_field(MR_mktag(1), eval_util__V_66_66, 0) = ((MR_Box) (eval_util__V_67_67));
#line 64 "eval_util.m"
                          MR_hl_field(MR_mktag(1), eval_util__V_66_66, 1) = ((MR_Box) (eval_util__V_68_68));
#line 64 "eval_util.m"
                        }
#line 64 "eval_util.m"
                        {
#line 64 "eval_util.m"
                          eval_util__V_64_64 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 64 "eval_util.m"
                          MR_hl_field(MR_mktag(1), eval_util__V_64_64, 0) = ((MR_Box) (eval_util__V_65_65));
#line 64 "eval_util.m"
                          MR_hl_field(MR_mktag(1), eval_util__V_64_64, 1) = ((MR_Box) (eval_util__V_66_66));
#line 64 "eval_util.m"
                        }
#line 64 "eval_util.m"
                        {
#line 64 "eval_util.m"
                          mercury__io__format_4_p_0(eval_util__V_63_63, eval_util__V_64_64);
                        }
                      }
#line 65 "eval_util.m"
                    else
#line 70 "eval_util.m"
                      {
#line 70 "eval_util.m"
                        MR_String eval_util__Msg_76;
                        MR_Word eval_util__V_69_69;
                        MR_Word eval_util__TypeInfo_93_93 = (MR_Word) (&eval__eval__type_ctor_info_program_error_0);
#line 66 "eval_util.m"
                        MR_Box eval_util__conv6_V_69_69;

#line 66 "eval_util.m"
                        {
#line 66 "eval_util.m"
                          eval_util__succeeded = mercury__std_util__univ_to_type_2_p_0(eval_util__TypeInfo_93_93, eval_util__HeadVar__1_1, &eval_util__conv6_V_69_69);
                        }
#line 66 "eval_util.m"
                        if (eval_util__succeeded)
#line 66 "eval_util.m"
                          {
#line 66 "eval_util.m"
                            eval_util__V_69_69 = ((MR_Word) eval_util__conv6_V_69_69);
#line 66 "eval_util.m"
                            eval_util__succeeded = TRUE;
#line 66 "eval_util.m"
                          }
                        if (eval_util__succeeded)
                          {
#line 66 "eval_util.m"
                            eval_util__succeeded = (MR_tag((MR_Word) eval_util__V_69_69) == MR_mktag((MR_Integer) 0));
#line 66 "eval_util.m"
                            if ((MR_tag((MR_Word) eval_util__V_69_69) == MR_mktag((MR_Integer) 0)))
#line 66 "eval_util.m"
                              eval_util__Msg_76 = ((MR_String) (MR_hl_field(MR_mktag(0), eval_util__V_69_69, (MR_Integer) 0)));
                          }
#line 70 "eval_util.m"
                        if (eval_util__succeeded)
                          {
                            MR_String eval_util__V_70_70 = (MR_String) "Program error: ";

#line 68 "eval_util.m"
                            {
#line 68 "eval_util.m"
                              mercury__io__write_string_3_p_0(eval_util__V_70_70);
                            }
#line 69 "eval_util.m"
                            {
#line 69 "eval_util.m"
                              mercury__io__write_string_3_p_0(eval_util__Msg_76);
                            }
                          }
#line 70 "eval_util.m"
                        else
#line 77 "eval_util.m"
                          {
#line 77 "eval_util.m"
                            MR_String eval_util__Msg_74;
#line 77 "eval_util.m"
                            MR_Word eval_util__Stack_75;
                            MR_Word eval_util__V_71_71;
                            MR_Word eval_util__TypeInfo_94_94 = (MR_Word) (&eval__eval__type_ctor_info_program_error_0);
#line 71 "eval_util.m"
                            MR_Box eval_util__conv7_V_71_71;

#line 71 "eval_util.m"
                            {
#line 71 "eval_util.m"
                              eval_util__succeeded = mercury__std_util__univ_to_type_2_p_0(eval_util__TypeInfo_94_94, eval_util__HeadVar__1_1, &eval_util__conv7_V_71_71);
                            }
#line 71 "eval_util.m"
                            if (eval_util__succeeded)
#line 71 "eval_util.m"
                              {
#line 71 "eval_util.m"
                                eval_util__V_71_71 = ((MR_Word) eval_util__conv7_V_71_71);
#line 71 "eval_util.m"
                                eval_util__succeeded = TRUE;
#line 71 "eval_util.m"
                              }
                            if (eval_util__succeeded)
                              {
#line 71 "eval_util.m"
                                eval_util__succeeded = (MR_tag((MR_Word) eval_util__V_71_71) == MR_mktag((MR_Integer) 1));
#line 71 "eval_util.m"
                                if ((MR_tag((MR_Word) eval_util__V_71_71) == MR_mktag((MR_Integer) 1)))
#line 71 "eval_util.m"
                                  {
#line 71 "eval_util.m"
                                    eval_util__Msg_74 = ((MR_String) (MR_hl_field(MR_mktag(1), eval_util__V_71_71, (MR_Integer) 0)));
#line 71 "eval_util.m"
                                    eval_util__Stack_75 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval_util__V_71_71, (MR_Integer) 1)));
#line 71 "eval_util.m"
                                  }
                              }
#line 77 "eval_util.m"
                            if (eval_util__succeeded)
                              {
                                MR_String eval_util__V_72_72 = (MR_String) "Program error: ";

#line 73 "eval_util.m"
                                {
#line 73 "eval_util.m"
                                  mercury__io__write_string_3_p_0(eval_util__V_72_72);
                                }
#line 74 "eval_util.m"
                                {
#line 74 "eval_util.m"
                                  mercury__io__write_string_3_p_0(eval_util__Msg_74);
                                }
#line 75 "eval_util.m"
                                {
#line 75 "eval_util.m"
                                  mercury__io__nl_2_p_0();
                                }
#line 76 "eval_util.m"
                                {
#line 76 "eval_util.m"
                                  eval_util__write_stack_3_p_0(eval_util__Stack_75);
                                }
                              }
#line 77 "eval_util.m"
                            else
#line 82 "eval_util.m"
                              {
#line 82 "eval_util.m"
                                MR_String eval_util__S_13;
                                MR_Word eval_util__TypeInfo_95_95 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
#line 78 "eval_util.m"
                                MR_Box eval_util__conv8_S_13;

#line 78 "eval_util.m"
                                {
#line 78 "eval_util.m"
                                  eval_util__succeeded = mercury__std_util__univ_to_type_2_p_0(eval_util__TypeInfo_95_95, eval_util__HeadVar__1_1, &eval_util__conv8_S_13);
                                }
#line 78 "eval_util.m"
                                if (eval_util__succeeded)
#line 78 "eval_util.m"
                                  {
#line 78 "eval_util.m"
                                    eval_util__S_13 = ((MR_String) eval_util__conv8_S_13);
#line 78 "eval_util.m"
                                    eval_util__succeeded = TRUE;
#line 78 "eval_util.m"
                                  }
#line 82 "eval_util.m"
                                if (eval_util__succeeded)
                                  {
                                    MR_String eval_util__V_73_73 = (MR_String) "Error: ";

#line 80 "eval_util.m"
                                    {
#line 80 "eval_util.m"
                                      mercury__io__write_string_3_p_0(eval_util__V_73_73);
                                    }
#line 81 "eval_util.m"
                                    {
#line 81 "eval_util.m"
                                      mercury__io__write_string_3_p_0(eval_util__S_13);
                                    }
                                  }
#line 82 "eval_util.m"
                                else
                                  {
                                    MR_Word eval_util__TypeInfo_96_96 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);

#line 83 "eval_util.m"
                                    {
#line 83 "eval_util.m"
                                      mercury__io__write_3_p_0(eval_util__TypeInfo_96_96, ((MR_Box) (eval_util__HeadVar__1_1)));
                                    }
                                  }
#line 82 "eval_util.m"
                              }
#line 77 "eval_util.m"
                          }
#line 70 "eval_util.m"
                      }
#line 65 "eval_util.m"
                  }
#line 61 "eval_util.m"
              }
#line 56 "eval_util.m"
          }
#line 45 "eval_util.m"
      }
#line 85 "eval_util.m"
    {
#line 85 "eval_util.m"
      mercury__io__nl_2_p_0();
    }
#line 86 "eval_util.m"
    {
#line 86 "eval_util.m"
      mercury__io__set_output_stream_4_p_0(eval_util__OldStream_6, &eval_util__V_14_14);
    }
  }
#line 11 "eval_util.m"
}

#line 9 "eval_util.m"
void MR_CALL eval_util__write_stack_3_p_0(
#line 9 "eval_util.m"
  MR_Word eval_util__HeadVar__1_1)
#line 9 "eval_util.m"
{
  {
    bool eval_util__succeeded;
    MR_String eval_util__V_9_9 = (MR_String) "Stack:\n";

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL eval_util__write_stack_3_p_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
eval_util__V_9_9
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 102 "eval_util.m"
    {
#line 102 "eval_util.m"
      eval_util__foldl__ho5_4_p_in__list_0(eval_util__HeadVar__1_1);
#line 102 "eval_util.m"
      return;
    }
  }
#line 9 "eval_util.m"
}

static void MR_CALL eval_util__write_env_3_p_0_1(
  MR_Box eval_util__closure_arg,
  MR_Box eval_util__wrapper_arg_1,
  MR_Box eval_util__wrapper_arg_2,
  MR_Box eval_util__wrapper_arg_3,
  MR_Box * eval_util__wrapper_arg_4)
{
  {
    MR_Box eval_util__closure = eval_util__closure_arg;

    {
      eval_util__write_env_entry_4_p_0(((MR_String) eval_util__wrapper_arg_1), ((MR_Word) eval_util__wrapper_arg_2));
      return;
    }
  }
}
static /* final */ const MR_Box eval_util__const_0_0_1_HeadVar__1_20[3] = {
		((MR_Box) (NULL)),
		((MR_Box) (eval_util__write_env_3_p_0_1)),
		((MR_Box) (MR_Word) ((MR_Integer) 0))};

#line 8 "eval_util.m"
void MR_CALL eval_util__write_env_3_p_0(
#line 8 "eval_util.m"
  MR_Word eval_util__HeadVar__1_1)
#line 8 "eval_util.m"
{
  {
    bool eval_util__succeeded;
    MR_String eval_util__V_9_9 = (MR_String) "Environment:\n";
    MR_Word eval_util__HeadVar__1_20;
    MR_Word eval_util__TypeInfo_for_K_25;
    MR_Word eval_util__TypeInfo_for_V_26;
    MR_Word eval_util__TypeInfo_for_T_27;
#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
    MR_Box eval_util__conv1_HeadVar__3_3;

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL eval_util__write_env_3_p_0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_String Message;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Message = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
eval_util__V_9_9
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_print_string(mercury_current_text_output, Message);
	update_io(IO0, IO);

#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 282 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
    eval_util__TypeInfo_for_K_25 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
    eval_util__TypeInfo_for_V_26 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
    eval_util__TypeInfo_for_T_27 = (MR_Word) (&mercury__io__io__type_ctor_info_state_0);
    eval_util__HeadVar__1_20 = (MR_Word) &eval_util__const_0_0_1_HeadVar__1_20;
#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
    {
#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
      mercury__tree234__foldl_4_p_2(eval_util__TypeInfo_for_K_25, eval_util__TypeInfo_for_V_26, eval_util__TypeInfo_for_T_27, eval_util__HeadVar__1_20, eval_util__HeadVar__1_1, ((MR_Box) ((MR_Integer) 0)), &eval_util__conv1_HeadVar__3_3);
    }
  }
#line 8 "eval_util.m"
}

void mercury__eval_util__init(void)
{
}

void mercury__eval_util__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&eval_util__eval_util__type_ctor_info_unequal_stacks_exception_0);
}

void mercury__eval_util__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module eval_util. */
