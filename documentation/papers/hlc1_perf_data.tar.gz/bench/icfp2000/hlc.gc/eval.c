/*
** Automatically generated from `eval.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module eval. */
/* :- implementation. */

#include "eval.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.benchmarking.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "eval.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "globals.h"
#include "gml.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "op.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "peephole.h"
#include "precompute_lights.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "renderer.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "space_partition.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "trans.h"
#include "transform_object.h"
#include "tree.h"
#include "mercury.tree234.h"
#include "mercury.varset.h"
#include "vector.h"



static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_value_0[9];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_0;
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_0[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_1;
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_1[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_2;
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_2[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_3;
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_3[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_4;
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_4[2];
static const MR_FO_PseudoTypeInfo_Struct1 eval__list__type_info_list_1__type0_18_gml__token_group_0;
static const MR_FO_PseudoTypeInfo_Struct2 eval__tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0;
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_5;
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_5[1];
static const MR_FO_PseudoTypeInfo_Struct1 eval__array__type_info_array_1__type0_13_eval__value_0;
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_6;
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_6[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_7;
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_7[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_8;
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_8[1];
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_value_0[4];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_value_0_0[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_value_0_1[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_value_0_2[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_value_0_3[6];
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_transformation_0[7];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_0;
static const MR_ConstString eval__eval__field_names_transformation_0_0[3];
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_0[3];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_1;
static const MR_ConstString eval__eval__field_names_transformation_0_1[3];
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_1[3];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_2;
static const MR_ConstString eval__eval__field_names_transformation_0_2[1];
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_2[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_3;
static const MR_ConstString eval__eval__field_names_transformation_0_3[1];
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_3[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_4;
static const MR_ConstString eval__eval__field_names_transformation_0_4[1];
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_4[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_5;
static const MR_ConstString eval__eval__field_names_transformation_0_5[1];
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_5[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_6;
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_6[1];
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_transformation_0[4];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_transformation_0_0[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_transformation_0_1[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_transformation_0_2[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_transformation_0_3[4];
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_surface_properties_0[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_surface_properties_0_0;
static const MR_ConstString eval__eval__field_names_surface_properties_0_0[4];
static const MR_PseudoTypeInfo eval__eval__field_types_surface_properties_0_0[4];
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_surface_properties_0[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_surface_properties_0_0[1];
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_surface_0[2];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_surface_0_0;
static const MR_PseudoTypeInfo eval__eval__field_types_surface_0_0[2];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_surface_0_1;
static const MR_PseudoTypeInfo eval__eval__field_types_surface_0_1[1];
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_surface_0[2];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_surface_0_0[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_surface_0_1[1];
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_stack_env_token_exception_0[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_stack_env_token_exception_0_0;
static const MR_PseudoTypeInfo eval__eval__field_types_stack_env_token_exception_0_0[4];
static const MR_FO_PseudoTypeInfo_Struct1 eval__list__type_info_list_1__type0_13_eval__value_0;
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_stack_env_token_exception_0[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_stack_env_token_exception_0_0[1];
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_stack_env_exception_0[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_stack_env_exception_0_0;
static const MR_PseudoTypeInfo eval__eval__field_types_stack_env_exception_0_0[3];
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_stack_env_exception_0[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_stack_env_exception_0_0[1];
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_program_error_0[2];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_program_error_0_0;
static const MR_PseudoTypeInfo eval__eval__field_types_program_error_0_0[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_program_error_0_1;
static const MR_PseudoTypeInfo eval__eval__field_types_program_error_0_1[2];
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_program_error_0[2];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_program_error_0_0[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_program_error_0_1[1];
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_object_0[5];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_object_0_0;
static const MR_PseudoTypeInfo eval__eval__field_types_object_0_0[3];
static const MR_FO_PseudoTypeInfo_Struct1 eval__list__type_info_list_1__type0_13_eval__light_0;
static const MR_DuFunctorDesc eval__eval__du_functor_desc_object_0_1;
static const MR_PseudoTypeInfo eval__eval__field_types_object_0_1[2];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_object_0_2;
static const MR_PseudoTypeInfo eval__eval__field_types_object_0_2[2];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_object_0_3;
static const MR_PseudoTypeInfo eval__eval__field_types_object_0_3[2];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_object_0_4;
static const MR_PseudoTypeInfo eval__eval__field_types_object_0_4[2];
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_object_0[4];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_object_0_0[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_object_0_1[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_object_0_2[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_object_0_3[2];
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_light_0[3];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_light_0_0;
static const MR_ConstString eval__eval__field_names_light_0_0[2];
static const MR_PseudoTypeInfo eval__eval__field_types_light_0_0[2];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_light_0_1;
static const MR_ConstString eval__eval__field_names_light_0_1[2];
static const MR_PseudoTypeInfo eval__eval__field_types_light_0_1[2];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_light_0_2;
static const MR_ConstString eval__eval__field_names_light_0_2[5];
static const MR_PseudoTypeInfo eval__eval__field_types_light_0_2[5];
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_light_0[3];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_light_0_0[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_light_0_1[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_light_0_2[1];
static const MR_EnumFunctorDescPtr eval__eval__enum_name_ordered_global_object_counter_0[1];
static const MR_EnumFunctorDescPtr eval__eval__enum_value_ordered_global_object_counter_0[1];
static const MR_EnumFunctorDesc eval__eval__enum_functor_desc_global_object_counter_0_0;
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_basic_object_0[5];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_basic_object_0_0;
static const MR_PseudoTypeInfo eval__eval__field_types_basic_object_0_0[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_basic_object_0_1;
static const MR_PseudoTypeInfo eval__eval__field_types_basic_object_0_1[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_basic_object_0_2;
static const MR_PseudoTypeInfo eval__eval__field_types_basic_object_0_2[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_basic_object_0_3;
static const MR_PseudoTypeInfo eval__eval__field_types_basic_object_0_3[1];
static const MR_DuFunctorDesc eval__eval__du_functor_desc_basic_object_0_4;
static const MR_PseudoTypeInfo eval__eval__field_types_basic_object_0_4[1];
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_basic_object_0[4];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_basic_object_0_0[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_basic_object_0_1[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_basic_object_0_2[1];
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_basic_object_0_3[2];
#line 780 "eval.m"
static void MR_CALL eval__empty_stack_3_p_0(
#line 780 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 780 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 780 "eval.m"
  MR_Word eval__HeadVar__3_3);
#line 749 "eval.m"
static bool MR_CALL eval__popn_3_p_0(
#line 749 "eval.m"
  MR_Integer eval__HeadVar__1_1,
#line 749 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 749 "eval.m"
  MR_Word * eval__HeadVar__3_3);
#line 618 "eval.m"
static void MR_CALL eval__do_extra2_6_p_0(
#line 618 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 618 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 618 "eval.m"
  MR_Word eval__HeadVar__3_3,
#line 618 "eval.m"
  MR_Word * eval__HeadVar__4_4);
#line 610 "eval.m"
static void MR_CALL eval__do_extra_6_p_0(
#line 610 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 610 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 610 "eval.m"
  MR_Word eval__HeadVar__3_3,
#line 610 "eval.m"
  MR_Word * eval__HeadVar__4_4);
#line 601 "eval.m"
static void MR_CALL eval__extra_operator_mode_2_p_0(
#line 601 "eval.m"
  MR_Word eval__A_1,
#line 601 "eval.m"
  MR_Word * eval__B_2);
#line 593 "eval.m"
static void MR_CALL eval__next_object_id_3_p_0(
#line 593 "eval.m"
  MR_Integer * eval__HeadVar__1_1);
#line 576 "eval.m"
static void MR_CALL eval__renameObject_4_p_0(
#line 576 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 576 "eval.m"
  MR_Word * eval__HeadVar__2_2);
#line 543 "eval.m"
static /* final */ const MR_Box eval__const_9_0_1_V_591_591[1];
#line 549 "eval.m"
static /* final */ const MR_Box eval__const_9_0_2_V_605_605[1];
#line 218 "eval.m"
static void MR_CALL eval__do_op_6_p_0(
#line 218 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 218 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 218 "eval.m"
  MR_Word eval__HeadVar__3_3,
#line 218 "eval.m"
  MR_Word * eval__HeadVar__4_4);
#line 185 "eval.m"
static /* final */ const MR_Box eval__const_8_0_1_V_27_27[2];
#line 172 "eval.m"
static void MR_CALL eval__do_token_7_p_0(
#line 172 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 172 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 172 "eval.m"
  MR_Word eval__HeadVar__3_3,
#line 172 "eval.m"
  MR_Word * eval__HeadVar__4_4,
#line 172 "eval.m"
  MR_Word * eval__HeadVar__5_5);
#line 155 "eval.m"
static void MR_CALL eval__do_token_group_7_p_0(
#line 155 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 155 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 155 "eval.m"
  MR_Word eval__HeadVar__3_3,
#line 155 "eval.m"
  MR_Word * eval__HeadVar__4_4,
#line 155 "eval.m"
  MR_Word * eval__HeadVar__5_5);
#line 691 "eval.m"
static /* final */ const MR_Box eval__const_6_0_1_HeadVar__3_3[1];
#line 692 "eval.m"
static /* final */ const MR_Box eval__const_6_0_2_HeadVar__3_3[1];
#line 693 "eval.m"
static /* final */ const MR_Box eval__const_6_0_3_HeadVar__3_3[1];
#line 695 "eval.m"
static /* final */ const MR_Box eval__const_6_0_4_HeadVar__3_3[1];
#line 696 "eval.m"
static /* final */ const MR_Box eval__const_6_0_5_HeadVar__3_3[1];
#line 697 "eval.m"
static /* final */ const MR_Box eval__const_6_0_6_HeadVar__3_3[1];
#line 698 "eval.m"
static /* final */ const MR_Box eval__const_6_0_7_HeadVar__3_3[1];
#line 699 "eval.m"
static /* final */ const MR_Box eval__const_6_0_8_HeadVar__3_3[1];
#line 700 "eval.m"
static /* final */ const MR_Box eval__const_6_0_9_HeadVar__3_3[1];
#line 701 "eval.m"
static /* final */ const MR_Box eval__const_6_0_10_HeadVar__3_3[1];
#line 702 "eval.m"
static /* final */ const MR_Box eval__const_6_0_11_HeadVar__3_3[1];
#line 703 "eval.m"
static /* final */ const MR_Box eval__const_6_0_12_HeadVar__3_3[1];
#line 704 "eval.m"
static /* final */ const MR_Box eval__const_6_0_13_HeadVar__3_3[1];
#line 705 "eval.m"
static /* final */ const MR_Box eval__const_6_0_14_HeadVar__3_3[1];
#line 706 "eval.m"
static /* final */ const MR_Box eval__const_6_0_15_HeadVar__3_3[1];
#line 707 "eval.m"
static /* final */ const MR_Box eval__const_6_0_16_HeadVar__3_3[1];
#line 708 "eval.m"
static /* final */ const MR_Box eval__const_6_0_17_HeadVar__3_3[1];
#line 709 "eval.m"
static /* final */ const MR_Box eval__const_6_0_18_HeadVar__3_3[1];
#line 710 "eval.m"
static /* final */ const MR_Box eval__const_6_0_19_HeadVar__3_3[1];
#line 711 "eval.m"
static /* final */ const MR_Box eval__const_6_0_20_HeadVar__3_3[1];
#line 713 "eval.m"
static /* final */ const MR_Box eval__const_6_0_21_HeadVar__3_3[1];
#line 714 "eval.m"
static /* final */ const MR_Box eval__const_6_0_22_HeadVar__3_3[1];
#line 715 "eval.m"
static /* final */ const MR_Box eval__const_6_0_23_HeadVar__3_3[1];
#line 716 "eval.m"
static /* final */ const MR_Box eval__const_6_0_24_HeadVar__3_3[1];
#line 717 "eval.m"
static /* final */ const MR_Box eval__const_6_0_25_HeadVar__3_3[1];
#line 718 "eval.m"
static /* final */ const MR_Box eval__const_6_0_26_HeadVar__3_3[1];
#line 719 "eval.m"
static /* final */ const MR_Box eval__const_6_0_27_HeadVar__3_3[1];
#line 720 "eval.m"
static /* final */ const MR_Box eval__const_6_0_28_HeadVar__3_3[1];
#line 721 "eval.m"
static /* final */ const MR_Box eval__const_6_0_29_HeadVar__3_3[1];
#line 722 "eval.m"
static /* final */ const MR_Box eval__const_6_0_30_HeadVar__3_3[1];
#line 723 "eval.m"
static /* final */ const MR_Box eval__const_6_0_31_HeadVar__3_3[1];
#line 724 "eval.m"
static /* final */ const MR_Box eval__const_6_0_32_HeadVar__3_3[1];
#line 725 "eval.m"
static /* final */ const MR_Box eval__const_6_0_33_HeadVar__3_3[1];
#line 726 "eval.m"
static /* final */ const MR_Box eval__const_6_0_34_HeadVar__3_3[1];
#line 727 "eval.m"
static /* final */ const MR_Box eval__const_6_0_35_HeadVar__3_3[1];
#line 728 "eval.m"
static /* final */ const MR_Box eval__const_6_0_36_HeadVar__3_3[1];
#line 729 "eval.m"
static /* final */ const MR_Box eval__const_6_0_37_HeadVar__3_3[1];
#line 730 "eval.m"
static /* final */ const MR_Box eval__const_6_0_38_HeadVar__3_3[1];
#line 731 "eval.m"
static /* final */ const MR_Box eval__const_6_0_39_HeadVar__3_3[1];
#line 732 "eval.m"
static /* final */ const MR_Box eval__const_6_0_40_HeadVar__3_3[1];
#line 733 "eval.m"
static /* final */ const MR_Box eval__const_6_0_41_HeadVar__3_3[1];
#line 734 "eval.m"
static /* final */ const MR_Box eval__const_6_0_42_HeadVar__3_3[1];
#line 735 "eval.m"
static /* final */ const MR_Box eval__const_6_0_43_HeadVar__3_3[1];
#line 736 "eval.m"
static /* final */ const MR_Box eval__const_6_0_44_HeadVar__3_3[1];
#line 737 "eval.m"
static /* final */ const MR_Box eval__const_6_0_45_HeadVar__3_3[1];
#line 738 "eval.m"
static /* final */ const MR_Box eval__const_6_0_46_HeadVar__3_3[1];
#line 739 "eval.m"
static /* final */ const MR_Box eval__const_6_0_47_HeadVar__3_3[1];
#line 740 "eval.m"
static /* final */ const MR_Box eval__const_6_0_48_HeadVar__3_3[1];



const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_value_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____value_0_0)),
		((MR_Box) (eval____Unify____value_0_0)),
		((MR_Box) (eval____Compare____value_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "value",
		(MR_Integer) 4,
		{
		(MR_Box) eval__eval__du_name_ordered_value_0},
		{
		(MR_Box) eval__eval__du_ptag_ordered_value_0},
		(MR_Integer) 9,
		(MR_Integer) 4};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_transformation_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____transformation_0_0)),
		((MR_Box) (eval____Unify____transformation_0_0)),
		((MR_Box) (eval____Compare____transformation_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "transformation",
		(MR_Integer) 4,
		{
		(MR_Box) eval__eval__du_name_ordered_transformation_0},
		{
		(MR_Box) eval__eval__du_ptag_ordered_transformation_0},
		(MR_Integer) 7,
		(MR_Integer) 4};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_surface_properties_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____surface_properties_0_0)),
		((MR_Box) (eval____Unify____surface_properties_0_0)),
		((MR_Box) (eval____Compare____surface_properties_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "surface_properties",
		(MR_Integer) 4,
		{
		(MR_Box) eval__eval__du_name_ordered_surface_properties_0},
		{
		(MR_Box) eval__eval__du_ptag_ordered_surface_properties_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_surface_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____surface_0_0)),
		((MR_Box) (eval____Unify____surface_0_0)),
		((MR_Box) (eval____Compare____surface_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "surface",
		(MR_Integer) 4,
		{
		(MR_Box) eval__eval__du_name_ordered_surface_0},
		{
		(MR_Box) eval__eval__du_ptag_ordered_surface_0},
		(MR_Integer) 2,
		(MR_Integer) 2};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_stack_env_token_exception_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____stack_env_token_exception_0_0)),
		((MR_Box) (eval____Unify____stack_env_token_exception_0_0)),
		((MR_Box) (eval____Compare____stack_env_token_exception_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "stack_env_token_exception",
		(MR_Integer) 4,
		{
		(MR_Box) eval__eval__du_name_ordered_stack_env_token_exception_0},
		{
		(MR_Box) eval__eval__du_ptag_ordered_stack_env_token_exception_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_stack_env_exception_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____stack_env_exception_0_0)),
		((MR_Box) (eval____Unify____stack_env_exception_0_0)),
		((MR_Box) (eval____Compare____stack_env_exception_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "stack_env_exception",
		(MR_Integer) 4,
		{
		(MR_Box) eval__eval__du_name_ordered_stack_env_exception_0},
		{
		(MR_Box) eval__eval__du_ptag_ordered_stack_env_exception_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_stack_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____stack_0_0)),
		((MR_Box) (eval____Unify____stack_0_0)),
		((MR_Box) (eval____Compare____stack_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "stack",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&eval__list__type_info_list_1__type0_13_eval__value_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_program_error_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____program_error_0_0)),
		((MR_Box) (eval____Unify____program_error_0_0)),
		((MR_Box) (eval____Compare____program_error_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "program_error",
		(MR_Integer) 4,
		{
		(MR_Box) eval__eval__du_name_ordered_program_error_0},
		{
		(MR_Box) eval__eval__du_ptag_ordered_program_error_0},
		(MR_Integer) 2,
		(MR_Integer) 2};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_object_id_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____object_id_0_0)),
		((MR_Box) (eval____Unify____object_id_0_0)),
		((MR_Box) (eval____Compare____object_id_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "object_id",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&mercury__builtin____type_ctor_info_int_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_object_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____object_0_0)),
		((MR_Box) (eval____Unify____object_0_0)),
		((MR_Box) (eval____Compare____object_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "object",
		(MR_Integer) 4,
		{
		(MR_Box) eval__eval__du_name_ordered_object_0},
		{
		(MR_Box) eval__eval__du_ptag_ordered_object_0},
		(MR_Integer) 5,
		(MR_Integer) 4};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_light_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____light_0_0)),
		((MR_Box) (eval____Unify____light_0_0)),
		((MR_Box) (eval____Compare____light_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "light",
		(MR_Integer) 4,
		{
		(MR_Box) eval__eval__du_name_ordered_light_0},
		{
		(MR_Box) eval__eval__du_ptag_ordered_light_0},
		(MR_Integer) 3,
		(MR_Integer) 3};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_id_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____id_0_0)),
		((MR_Box) (eval____Unify____id_0_0)),
		((MR_Box) (eval____Compare____id_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "id",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&mercury__builtin____type_ctor_info_string_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_global_object_counter_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____global_object_counter_0_0)),
		((MR_Box) (eval____Unify____global_object_counter_0_0)),
		((MR_Box) (eval____Compare____global_object_counter_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_ENUM,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "global_object_counter",
		(MR_Integer) 4,
		{
		(MR_Box) eval__eval__enum_name_ordered_global_object_counter_0},
		{
		(MR_Box) eval__eval__enum_value_ordered_global_object_counter_0},
		(MR_Integer) 1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_env_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____env_0_0)),
		((MR_Box) (eval____Unify____env_0_0)),
		((MR_Box) (eval____Compare____env_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "env",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&eval__tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_degrees_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____degrees_0_0)),
		((MR_Box) (eval____Unify____degrees_0_0)),
		((MR_Box) (eval____Compare____degrees_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "degrees",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&mercury__builtin____type_ctor_info_float_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_color_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____color_0_0)),
		((MR_Box) (eval____Unify____color_0_0)),
		((MR_Box) (eval____Compare____color_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "color",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&vector__vector__type_ctor_info_vector_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_code_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____code_0_0)),
		((MR_Box) (eval____Unify____code_0_0)),
		((MR_Box) (eval____Compare____code_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "code",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&eval__list__type_info_list_1__type0_18_gml__token_group_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_basic_object_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____basic_object_0_0)),
		((MR_Box) (eval____Unify____basic_object_0_0)),
		((MR_Box) (eval____Compare____basic_object_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "basic_object",
		(MR_Integer) 4,
		{
		(MR_Box) eval__eval__du_name_ordered_basic_object_0},
		{
		(MR_Box) eval__eval__du_ptag_ordered_basic_object_0},
		(MR_Integer) 5,
		(MR_Integer) 4};
const MR_TypeCtorInfo_Struct eval__eval__type_ctor_info_array_0 = {
		(MR_Integer) 0,
		((MR_Box) (eval____Unify____array_0_0)),
		((MR_Box) (eval____Unify____array_0_0)),
		((MR_Box) (eval____Compare____array_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "eval",
		(MR_String) "array",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&eval__array__type_info_array_1__type0_13_eval__value_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_value_0[9] = {
		(&eval__eval__du_functor_desc_value_0_5),
		(&eval__eval__du_functor_desc_value_0_0),
		(&eval__eval__du_functor_desc_value_0_4),
		(&eval__eval__du_functor_desc_value_0_1),
		(&eval__eval__du_functor_desc_value_0_8),
		(&eval__eval__du_functor_desc_value_0_7),
		(&eval__eval__du_functor_desc_value_0_6),
		(&eval__eval__du_functor_desc_value_0_2),
		(&eval__eval__du_functor_desc_value_0_3)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_0 = {
		(MR_String) "boolean",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		eval__eval__field_types_value_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_0[1] = {
		(MR_PseudoTypeInfo) (&mercury__bool__bool__type_ctor_info_bool_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_1 = {
		(MR_String) "int",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		eval__eval__field_types_value_0_1,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_1[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_2 = {
		(MR_String) "real",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 2,
		(MR_Integer) 0,
		(MR_Integer) 2,
		eval__eval__field_types_value_0_2,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_2[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_3 = {
		(MR_String) "string",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 0,
		(MR_Integer) 3,
		eval__eval__field_types_value_0_3,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_3[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_4 = {
		(MR_String) "closure",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 1,
		(MR_Integer) 4,
		eval__eval__field_types_value_0_4,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_4[2] = {
		(MR_PseudoTypeInfo) (&eval__tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0),
		(MR_PseudoTypeInfo) (&eval__list__type_info_list_1__type0_18_gml__token_group_0)};
static const MR_FO_PseudoTypeInfo_Struct1 eval__list__type_info_list_1__type0_18_gml__token_group_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&gml__gml__type_ctor_info_token_group_0)}};
static const MR_FO_PseudoTypeInfo_Struct2 eval__tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0 = {
		(&mercury__tree234__tree234__type_ctor_info_tree234_2),
		{
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0),
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_value_0)}};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_5 = {
		(MR_String) "array",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 2,
		(MR_Integer) 5,
		eval__eval__field_types_value_0_5,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_5[1] = {
		(MR_PseudoTypeInfo) (&eval__array__type_info_array_1__type0_13_eval__value_0)};
static const MR_FO_PseudoTypeInfo_Struct1 eval__array__type_info_array_1__type0_13_eval__value_0 = {
		(&mercury__array__array__type_ctor_info_array_1),
		{
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_value_0)}};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_6 = {
		(MR_String) "point",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 3,
		(MR_Integer) 6,
		eval__eval__field_types_value_0_6,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_6[1] = {
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_7 = {
		(MR_String) "object",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 4,
		(MR_Integer) 7,
		eval__eval__field_types_value_0_7,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_7[1] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_object_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_value_0_8 = {
		(MR_String) "light",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 5,
		(MR_Integer) 8,
		eval__eval__field_types_value_0_8,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_value_0_8[1] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_light_0)};
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_value_0[4] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_value_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_value_0_1},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_value_0_2},
		{
		(MR_Integer) 6,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		eval__eval__du_stag_ordered_value_0_3}};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_value_0_0[1] = {
		(&eval__eval__du_functor_desc_value_0_0)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_value_0_1[1] = {
		(&eval__eval__du_functor_desc_value_0_1)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_value_0_2[1] = {
		(&eval__eval__du_functor_desc_value_0_2)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_value_0_3[6] = {
		(&eval__eval__du_functor_desc_value_0_3),
		(&eval__eval__du_functor_desc_value_0_4),
		(&eval__eval__du_functor_desc_value_0_5),
		(&eval__eval__du_functor_desc_value_0_6),
		(&eval__eval__du_functor_desc_value_0_7),
		(&eval__eval__du_functor_desc_value_0_8)};
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_transformation_0[7] = {
		(&eval__eval__du_functor_desc_transformation_0_6),
		(&eval__eval__du_functor_desc_transformation_0_3),
		(&eval__eval__du_functor_desc_transformation_0_4),
		(&eval__eval__du_functor_desc_transformation_0_5),
		(&eval__eval__du_functor_desc_transformation_0_1),
		(&eval__eval__du_functor_desc_transformation_0_0),
		(&eval__eval__du_functor_desc_transformation_0_2)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_0 = {
		(MR_String) "translate",
		(MR_Integer) 3,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		eval__eval__field_types_transformation_0_0,
		eval__eval__field_names_transformation_0_0,
		(MR_Box) NULL};
static const MR_ConstString eval__eval__field_names_transformation_0_0[3] = {
		(MR_String) "tx",
		(MR_String) "ty",
		(MR_String) "tz"};
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_0[3] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_1 = {
		(MR_String) "scale",
		(MR_Integer) 3,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		eval__eval__field_types_transformation_0_1,
		eval__eval__field_names_transformation_0_1,
		(MR_Box) NULL};
static const MR_ConstString eval__eval__field_names_transformation_0_1[3] = {
		(MR_String) "sx",
		(MR_String) "sy",
		(MR_String) "sz"};
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_1[3] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_2 = {
		(MR_String) "uscale",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 2,
		(MR_Integer) 0,
		(MR_Integer) 2,
		eval__eval__field_types_transformation_0_2,
		eval__eval__field_names_transformation_0_2,
		(MR_Box) NULL};
static const MR_ConstString eval__eval__field_names_transformation_0_2[1] = {
		(MR_String) "s"};
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_2[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_3 = {
		(MR_String) "rotatex",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 0,
		(MR_Integer) 3,
		eval__eval__field_types_transformation_0_3,
		eval__eval__field_names_transformation_0_3,
		(MR_Box) NULL};
static const MR_ConstString eval__eval__field_names_transformation_0_3[1] = {
		(MR_String) "rotatex_theta"};
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_3[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_4 = {
		(MR_String) "rotatey",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 1,
		(MR_Integer) 4,
		eval__eval__field_types_transformation_0_4,
		eval__eval__field_names_transformation_0_4,
		(MR_Box) NULL};
static const MR_ConstString eval__eval__field_names_transformation_0_4[1] = {
		(MR_String) "rotatey_theta"};
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_4[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_5 = {
		(MR_String) "rotatez",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 2,
		(MR_Integer) 5,
		eval__eval__field_types_transformation_0_5,
		eval__eval__field_names_transformation_0_5,
		(MR_Box) NULL};
static const MR_ConstString eval__eval__field_names_transformation_0_5[1] = {
		(MR_String) "rotatez_theta"};
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_5[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_transformation_0_6 = {
		(MR_String) "matrix",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 3,
		(MR_Integer) 6,
		eval__eval__field_types_transformation_0_6,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_transformation_0_6[1] = {
		(MR_PseudoTypeInfo) (&trans__trans__type_ctor_info_trans_0)};
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_transformation_0[4] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_transformation_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_transformation_0_1},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_transformation_0_2},
		{
		(MR_Integer) 4,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		eval__eval__du_stag_ordered_transformation_0_3}};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_transformation_0_0[1] = {
		(&eval__eval__du_functor_desc_transformation_0_0)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_transformation_0_1[1] = {
		(&eval__eval__du_functor_desc_transformation_0_1)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_transformation_0_2[1] = {
		(&eval__eval__du_functor_desc_transformation_0_2)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_transformation_0_3[4] = {
		(&eval__eval__du_functor_desc_transformation_0_3),
		(&eval__eval__du_functor_desc_transformation_0_4),
		(&eval__eval__du_functor_desc_transformation_0_5),
		(&eval__eval__du_functor_desc_transformation_0_6)};
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_surface_properties_0[1] = {
		(&eval__eval__du_functor_desc_surface_properties_0_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_surface_properties_0_0 = {
		(MR_String) "surface_properties",
		(MR_Integer) 4,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		eval__eval__field_types_surface_properties_0_0,
		eval__eval__field_names_surface_properties_0_0,
		(MR_Box) NULL};
static const MR_ConstString eval__eval__field_names_surface_properties_0_0[4] = {
		(MR_String) "surface_c",
		(MR_String) "surface_kd",
		(MR_String) "surface_ks",
		(MR_String) "surface_n"};
static const MR_PseudoTypeInfo eval__eval__field_types_surface_properties_0_0[4] = {
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_surface_properties_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_surface_properties_0_0}};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_surface_properties_0_0[1] = {
		(&eval__eval__du_functor_desc_surface_properties_0_0)};
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_surface_0[2] = {
		(&eval__eval__du_functor_desc_surface_0_1),
		(&eval__eval__du_functor_desc_surface_0_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_surface_0_0 = {
		(MR_String) "surface",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		eval__eval__field_types_surface_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_surface_0_0[2] = {
		(MR_PseudoTypeInfo) (&eval__tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0),
		(MR_PseudoTypeInfo) (&eval__list__type_info_list_1__type0_18_gml__token_group_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_surface_0_1 = {
		(MR_String) "constant",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		eval__eval__field_types_surface_0_1,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_surface_0_1[1] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_surface_properties_0)};
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_surface_0[2] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_surface_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_surface_0_1}};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_surface_0_0[1] = {
		(&eval__eval__du_functor_desc_surface_0_0)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_surface_0_1[1] = {
		(&eval__eval__du_functor_desc_surface_0_1)};
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_stack_env_token_exception_0[1] = {
		(&eval__eval__du_functor_desc_stack_env_token_exception_0_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_stack_env_token_exception_0_0 = {
		(MR_String) "stack_env_token_exception",
		(MR_Integer) 4,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		eval__eval__field_types_stack_env_token_exception_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_stack_env_token_exception_0_0[4] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0),
		(MR_PseudoTypeInfo) (&eval__tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0),
		(MR_PseudoTypeInfo) (&eval__list__type_info_list_1__type0_13_eval__value_0),
		(MR_PseudoTypeInfo) (&gml__gml__type_ctor_info_token_0)};
static const MR_FO_PseudoTypeInfo_Struct1 eval__list__type_info_list_1__type0_13_eval__value_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_value_0)}};
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_stack_env_token_exception_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_stack_env_token_exception_0_0}};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_stack_env_token_exception_0_0[1] = {
		(&eval__eval__du_functor_desc_stack_env_token_exception_0_0)};
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_stack_env_exception_0[1] = {
		(&eval__eval__du_functor_desc_stack_env_exception_0_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_stack_env_exception_0_0 = {
		(MR_String) "stack_env_exception",
		(MR_Integer) 3,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		eval__eval__field_types_stack_env_exception_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_stack_env_exception_0_0[3] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0),
		(MR_PseudoTypeInfo) (&eval__tree234__type_info_tree234_2__type0_10___string_0__type0_13_eval__value_0),
		(MR_PseudoTypeInfo) (&eval__list__type_info_list_1__type0_13_eval__value_0)};
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_stack_env_exception_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_stack_env_exception_0_0}};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_stack_env_exception_0_0[1] = {
		(&eval__eval__du_functor_desc_stack_env_exception_0_0)};
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_program_error_0[2] = {
		(&eval__eval__du_functor_desc_program_error_0_0),
		(&eval__eval__du_functor_desc_program_error_0_1)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_program_error_0_0 = {
		(MR_String) "program_error",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		eval__eval__field_types_program_error_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_program_error_0_0[1] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_program_error_0_1 = {
		(MR_String) "program_error",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		eval__eval__field_types_program_error_0_1,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_program_error_0_1[2] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_string_0),
		(MR_PseudoTypeInfo) (&eval__list__type_info_list_1__type0_13_eval__value_0)};
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_program_error_0[2] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_program_error_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_program_error_0_1}};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_program_error_0_0[1] = {
		(&eval__eval__du_functor_desc_program_error_0_0)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_program_error_0_1[1] = {
		(&eval__eval__du_functor_desc_program_error_0_1)};
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_object_0[5] = {
		(&eval__eval__du_functor_desc_object_0_0),
		(&eval__eval__du_functor_desc_object_0_4),
		(&eval__eval__du_functor_desc_object_0_3),
		(&eval__eval__du_functor_desc_object_0_1),
		(&eval__eval__du_functor_desc_object_0_2)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_object_0_0 = {
		(MR_String) "basic_object",
		(MR_Integer) 3,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		eval__eval__field_types_object_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_object_0_0[3] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0),
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_basic_object_0),
		(MR_PseudoTypeInfo) (&eval__list__type_info_list_1__type0_13_eval__light_0)};
static const MR_FO_PseudoTypeInfo_Struct1 eval__list__type_info_list_1__type0_13_eval__light_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_light_0)}};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_object_0_1 = {
		(MR_String) "transform",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		eval__eval__field_types_object_0_1,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_object_0_1[2] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_object_0),
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_transformation_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_object_0_2 = {
		(MR_String) "union",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 2,
		(MR_Integer) 0,
		(MR_Integer) 2,
		eval__eval__field_types_object_0_2,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_object_0_2[2] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_object_0),
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_object_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_object_0_3 = {
		(MR_String) "intersect",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 0,
		(MR_Integer) 3,
		eval__eval__field_types_object_0_3,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_object_0_3[2] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_object_0),
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_object_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_object_0_4 = {
		(MR_String) "difference",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 1,
		(MR_Integer) 4,
		eval__eval__field_types_object_0_4,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_object_0_4[2] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_object_0),
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_object_0)};
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_object_0[4] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_object_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_object_0_1},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_object_0_2},
		{
		(MR_Integer) 2,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		eval__eval__du_stag_ordered_object_0_3}};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_object_0_0[1] = {
		(&eval__eval__du_functor_desc_object_0_0)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_object_0_1[1] = {
		(&eval__eval__du_functor_desc_object_0_1)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_object_0_2[1] = {
		(&eval__eval__du_functor_desc_object_0_2)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_object_0_3[2] = {
		(&eval__eval__du_functor_desc_object_0_3),
		(&eval__eval__du_functor_desc_object_0_4)};
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_light_0[3] = {
		(&eval__eval__du_functor_desc_light_0_0),
		(&eval__eval__du_functor_desc_light_0_1),
		(&eval__eval__du_functor_desc_light_0_2)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_light_0_0 = {
		(MR_String) "directional",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		eval__eval__field_types_light_0_0,
		eval__eval__field_names_light_0_0,
		(MR_Box) NULL};
static const MR_ConstString eval__eval__field_names_light_0_0[2] = {
		(MR_String) "dir",
		(MR_String) "directional_intensity"};
static const MR_PseudoTypeInfo eval__eval__field_types_light_0_0[2] = {
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0),
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_light_0_1 = {
		(MR_String) "pointlight",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		eval__eval__field_types_light_0_1,
		eval__eval__field_names_light_0_1,
		(MR_Box) NULL};
static const MR_ConstString eval__eval__field_names_light_0_1[2] = {
		(MR_String) "pointlight_pos",
		(MR_String) "pointlight_intensity"};
static const MR_PseudoTypeInfo eval__eval__field_types_light_0_1[2] = {
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0),
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_light_0_2 = {
		(MR_String) "spotlight",
		(MR_Integer) 5,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 2,
		(MR_Integer) 0,
		(MR_Integer) 2,
		eval__eval__field_types_light_0_2,
		eval__eval__field_names_light_0_2,
		(MR_Box) NULL};
static const MR_ConstString eval__eval__field_names_light_0_2[5] = {
		(MR_String) "spotlight_pos",
		(MR_String) "at",
		(MR_String) "spotlight_intensity",
		(MR_String) "cutoff",
		(MR_String) "exp"};
static const MR_PseudoTypeInfo eval__eval__field_types_light_0_2[5] = {
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0),
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0),
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_light_0[3] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_light_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_light_0_1},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_light_0_2}};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_light_0_0[1] = {
		(&eval__eval__du_functor_desc_light_0_0)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_light_0_1[1] = {
		(&eval__eval__du_functor_desc_light_0_1)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_light_0_2[1] = {
		(&eval__eval__du_functor_desc_light_0_2)};
static const MR_EnumFunctorDescPtr eval__eval__enum_name_ordered_global_object_counter_0[1] = {
		(&eval__eval__enum_functor_desc_global_object_counter_0_0)};
static const MR_EnumFunctorDescPtr eval__eval__enum_value_ordered_global_object_counter_0[1] = {
		(&eval__eval__enum_functor_desc_global_object_counter_0_0)};
static const MR_EnumFunctorDesc eval__eval__enum_functor_desc_global_object_counter_0_0 = {
		(MR_String) "global_object_counter",
		(MR_Integer) 0};
static const MR_DuFunctorDescPtr eval__eval__du_name_ordered_basic_object_0[5] = {
		(&eval__eval__du_functor_desc_basic_object_0_3),
		(&eval__eval__du_functor_desc_basic_object_0_1),
		(&eval__eval__du_functor_desc_basic_object_0_2),
		(&eval__eval__du_functor_desc_basic_object_0_4),
		(&eval__eval__du_functor_desc_basic_object_0_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_basic_object_0_0 = {
		(MR_String) "sphere",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		eval__eval__field_types_basic_object_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_basic_object_0_0[1] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_surface_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_basic_object_0_1 = {
		(MR_String) "cube",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 1,
		(MR_Integer) 0,
		(MR_Integer) 1,
		eval__eval__field_types_basic_object_0_1,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_basic_object_0_1[1] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_surface_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_basic_object_0_2 = {
		(MR_String) "cylinder",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 2,
		(MR_Integer) 0,
		(MR_Integer) 2,
		eval__eval__field_types_basic_object_0_2,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_basic_object_0_2[1] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_surface_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_basic_object_0_3 = {
		(MR_String) "cone",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 0,
		(MR_Integer) 3,
		eval__eval__field_types_basic_object_0_3,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_basic_object_0_3[1] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_surface_0)};
static const MR_DuFunctorDesc eval__eval__du_functor_desc_basic_object_0_4 = {
		(MR_String) "plane",
		(MR_Integer) 1,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		(MR_Integer) 3,
		(MR_Integer) 1,
		(MR_Integer) 4,
		eval__eval__field_types_basic_object_0_4,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo eval__eval__field_types_basic_object_0_4[1] = {
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_surface_0)};
static const MR_DuPtagLayout eval__eval__du_ptag_ordered_basic_object_0[4] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_basic_object_0_0},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_basic_object_0_1},
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		eval__eval__du_stag_ordered_basic_object_0_2},
		{
		(MR_Integer) 2,
		mercury__private_builtin__MR_SECTAG_REMOTE,
		eval__eval__du_stag_ordered_basic_object_0_3}};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_basic_object_0_0[1] = {
		(&eval__eval__du_functor_desc_basic_object_0_0)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_basic_object_0_1[1] = {
		(&eval__eval__du_functor_desc_basic_object_0_1)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_basic_object_0_2[1] = {
		(&eval__eval__du_functor_desc_basic_object_0_2)};
static const MR_DuFunctorDescPtr eval__eval__du_stag_ordered_basic_object_0_3[2] = {
		(&eval__eval__du_functor_desc_basic_object_0_3),
		(&eval__eval__du_functor_desc_basic_object_0_4)};

#line 130 "eval.m"
void MR_CALL eval____Compare____global_object_counter_0_0(
#line 130 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 130 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 130 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 130 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Integer eval__V_4_4 = (MR_Integer) eval__HeadVar__2_2;
    MR_Integer eval__V_5_5 = (MR_Integer) eval__HeadVar__3_3;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    eval__succeeded = (eval__V_4_4 < eval__V_5_5);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (eval__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        eval__succeeded = (eval__V_4_4 == eval__V_5_5);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (eval__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *eval__HeadVar__1_1 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
  }
#line 130 "eval.m"
}

#line 130 "eval.m"
bool MR_CALL eval____Unify____global_object_counter_0_0(
#line 130 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 130 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 130 "eval.m"
{
#line 130 "eval.m"
  {
#line 130 "eval.m"
    bool eval__succeeded = (eval__HeadVar__1_1 == eval__HeadVar__2_2);

#line 130 "eval.m"
    return eval__succeeded;
#line 130 "eval.m"
  }
#line 130 "eval.m"
}

#line 114 "eval.m"
void MR_CALL eval____Compare____program_error_0_0(
#line 114 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 114 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 114 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 114 "eval.m"
{
#line 114 "eval.m"
  {
#line 114 "eval.m"
    bool eval__succeeded;

#line 114 "eval.m"
    if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
      {
        MR_String eval__V_22_22 = ((MR_String) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));

#line 114 "eval.m"
        if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
          {
            MR_String eval__V_5_5 = ((MR_String) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 0)));
            MR_Integer eval__Res_7_28;
            MR_Integer eval__V_41_41;

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL eval____Compare____program_error_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__V_22_22
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__V_5_5
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__Res_7_28
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            eval__V_41_41 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            eval__succeeded = (eval__Res_7_28 < eval__V_41_41);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (eval__succeeded)
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__succeeded = (eval__Res_7_28 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (eval__succeeded)
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *eval__HeadVar__1_1 = (MR_Integer) 0;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              }
          }
#line 114 "eval.m"
        else
#line 114 "eval.m"
          *eval__HeadVar__1_1 = (MR_Integer) 1;
      }
#line 114 "eval.m"
    else
#line 114 "eval.m"
      {
        MR_Word eval__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 1)));
        MR_String eval__V_24_24 = ((MR_String) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));

#line 114 "eval.m"
        if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
#line 114 "eval.m"
          *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 114 "eval.m"
        else
#line 114 "eval.m"
          {
            MR_String eval__V_8_8 = ((MR_String) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
            MR_Word eval__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 114 "eval.m"
            MR_Word eval__V_10_10;
            MR_Integer eval__Res_7_36;
            MR_Integer eval__V_42_42;

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL eval____Compare____program_error_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__V_24_24
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__V_8_8
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__Res_7_36
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            eval__V_42_42 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            eval__succeeded = (eval__Res_7_36 < eval__V_42_42);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (eval__succeeded)
              {
                MR_Word eval__V_43_43 = (MR_Integer) 1;

#line 114 "eval.m"
                eval__succeeded = (eval__V_43_43 == (MR_Integer) 0);
#line 114 "eval.m"
                eval__succeeded = !(eval__succeeded);
                if (eval__succeeded)
                  {
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    eval__V_10_10 = (MR_Integer) 1;
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    eval__succeeded = TRUE;
                  }
              }
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__succeeded = (eval__Res_7_36 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (eval__succeeded)
                  {
                    MR_Word eval__V_44_44 = (MR_Integer) 0;

#line 114 "eval.m"
                    eval__succeeded = (eval__V_44_44 == (MR_Integer) 0);
#line 114 "eval.m"
                    eval__succeeded = !(eval__succeeded);
                    if (eval__succeeded)
                      {
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        eval__V_10_10 = (MR_Integer) 0;
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        eval__succeeded = TRUE;
                      }
                  }
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
                  {
                    MR_Word eval__V_45_45 = (MR_Integer) 2;

#line 114 "eval.m"
                    eval__succeeded = (eval__V_45_45 == (MR_Integer) 0);
#line 114 "eval.m"
                    eval__succeeded = !(eval__succeeded);
                    if (eval__succeeded)
                      {
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        eval__V_10_10 = (MR_Integer) 2;
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        eval__succeeded = TRUE;
                      }
                  }
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              }
#line 114 "eval.m"
            if (eval__succeeded)
#line 114 "eval.m"
              *eval__HeadVar__1_1 = eval__V_10_10;
#line 114 "eval.m"
            else
              {
                MR_Word eval__TypeInfo_19_19 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 114 "eval.m"
                {
#line 114 "eval.m"
                  mercury__list____Compare____list_1_0(eval__TypeInfo_19_19, eval__HeadVar__1_1, eval__V_23_23, eval__V_9_9);
#line 114 "eval.m"
                  return;
                }
              }
#line 114 "eval.m"
          }
#line 114 "eval.m"
      }
#line 114 "eval.m"
  }
#line 114 "eval.m"
}

#line 114 "eval.m"
bool MR_CALL eval____Unify____program_error_0_0(
#line 114 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 114 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 114 "eval.m"
{
#line 114 "eval.m"
  {
#line 114 "eval.m"
    bool eval__succeeded;

#line 114 "eval.m"
    if ((MR_tag((MR_Word) eval__HeadVar__1_1) == MR_mktag((MR_Integer) 0)))
      {
        MR_String eval__V_3_3 = ((MR_String) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 0)));
        MR_String eval__V_4_4;

#line 114 "eval.m"
        eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
#line 114 "eval.m"
        if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 114 "eval.m"
          eval__V_4_4 = ((MR_String) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
        if (eval__succeeded)
          eval__succeeded = (strcmp(eval__V_3_3, eval__V_4_4) == 0);
      }
#line 114 "eval.m"
    else
#line 114 "eval.m"
      {
        MR_String eval__V_5_5 = ((MR_String) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 0)));
        MR_Word eval__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 1)));
        MR_String eval__V_7_7;
        MR_Word eval__V_8_8;
        MR_Word eval__TypeInfo_9_9;

#line 114 "eval.m"
        eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 114 "eval.m"
        if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 114 "eval.m"
          {
#line 114 "eval.m"
            eval__V_7_7 = ((MR_String) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 114 "eval.m"
            eval__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 114 "eval.m"
          }
        if (eval__succeeded)
          {
            eval__succeeded = (strcmp(eval__V_5_5, eval__V_7_7) == 0);
            if (eval__succeeded)
              {
                eval__TypeInfo_9_9 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
                {
                  return eval__succeeded = mercury__list____Unify____list_1_0(eval__TypeInfo_9_9, eval__V_6_6, eval__V_8_8);
                }
              }
          }
#line 114 "eval.m"
      }
#line 114 "eval.m"
    return eval__succeeded;
#line 114 "eval.m"
  }
#line 114 "eval.m"
}

#line 110 "eval.m"
void MR_CALL eval____Compare____stack_env_token_exception_0_0(
#line 110 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 110 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 110 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 110 "eval.m"
{
  {
    bool eval__succeeded;
    MR_String eval__V_4_4 = ((MR_String) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word eval__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word eval__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word eval__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 3)));
    MR_String eval__V_8_8 = ((MR_String) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 0)));
    MR_Word eval__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 1)));
    MR_Word eval__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 2)));
    MR_Word eval__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 3)));
#line 110 "eval.m"
    MR_Word eval__V_12_12;
    MR_Integer eval__Res_7_27;
    MR_Integer eval__V_32_32;

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL eval____Compare____stack_env_token_exception_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__V_4_4
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__V_8_8
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__Res_7_27
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    eval__V_32_32 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    eval__succeeded = (eval__Res_7_27 < eval__V_32_32);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (eval__succeeded)
      {
        MR_Word eval__V_33_33 = (MR_Integer) 1;

#line 110 "eval.m"
        eval__succeeded = (eval__V_33_33 == (MR_Integer) 0);
#line 110 "eval.m"
        eval__succeeded = !(eval__succeeded);
        if (eval__succeeded)
          {
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            eval__V_12_12 = (MR_Integer) 1;
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            eval__succeeded = TRUE;
          }
      }
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        eval__succeeded = (eval__Res_7_27 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (eval__succeeded)
          {
            MR_Word eval__V_34_34 = (MR_Integer) 0;

#line 110 "eval.m"
            eval__succeeded = (eval__V_34_34 == (MR_Integer) 0);
#line 110 "eval.m"
            eval__succeeded = !(eval__succeeded);
            if (eval__succeeded)
              {
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__V_12_12 = (MR_Integer) 0;
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__succeeded = TRUE;
              }
          }
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
          {
            MR_Word eval__V_35_35 = (MR_Integer) 2;

#line 110 "eval.m"
            eval__succeeded = (eval__V_35_35 == (MR_Integer) 0);
#line 110 "eval.m"
            eval__succeeded = !(eval__succeeded);
            if (eval__succeeded)
              {
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__V_12_12 = (MR_Integer) 2;
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__succeeded = TRUE;
              }
          }
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 110 "eval.m"
    if (eval__succeeded)
#line 110 "eval.m"
      *eval__HeadVar__1_1 = eval__V_12_12;
#line 110 "eval.m"
    else
#line 110 "eval.m"
      {
#line 110 "eval.m"
        MR_Word eval__V_13_13;
        MR_Word eval__TypeInfo_16_16 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
        MR_Word eval__TypeInfo_17_17 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 110 "eval.m"
        {
#line 110 "eval.m"
          mercury__tree234____Compare____tree234_2_0(eval__TypeInfo_16_16, eval__TypeInfo_17_17, &eval__V_13_13, eval__V_5_5, eval__V_9_9);
        }
#line 110 "eval.m"
        eval__succeeded = (eval__V_13_13 == (MR_Integer) 0);
#line 110 "eval.m"
        eval__succeeded = !(eval__succeeded);
#line 110 "eval.m"
        if (eval__succeeded)
#line 110 "eval.m"
          *eval__HeadVar__1_1 = eval__V_13_13;
#line 110 "eval.m"
        else
#line 110 "eval.m"
          {
#line 110 "eval.m"
            MR_Word eval__V_14_14;
            MR_Word eval__TypeInfo_20_20 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 110 "eval.m"
            {
#line 110 "eval.m"
              mercury__list____Compare____list_1_0(eval__TypeInfo_20_20, &eval__V_14_14, eval__V_6_6, eval__V_10_10);
            }
#line 110 "eval.m"
            eval__succeeded = (eval__V_14_14 == (MR_Integer) 0);
#line 110 "eval.m"
            eval__succeeded = !(eval__succeeded);
#line 110 "eval.m"
            if (eval__succeeded)
#line 110 "eval.m"
              *eval__HeadVar__1_1 = eval__V_14_14;
#line 110 "eval.m"
            else
#line 110 "eval.m"
              {
#line 110 "eval.m"
                gml____Compare____token_0_0(eval__HeadVar__1_1, eval__V_7_7, eval__V_11_11);
#line 110 "eval.m"
                return;
              }
#line 110 "eval.m"
          }
#line 110 "eval.m"
      }
  }
#line 110 "eval.m"
}

#line 110 "eval.m"
bool MR_CALL eval____Unify____stack_env_token_exception_0_0(
#line 110 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 110 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 110 "eval.m"
{
  {
    bool eval__succeeded;
    MR_String eval__V_3_3 = ((MR_String) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word eval__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word eval__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 2)));
    MR_Word eval__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 3)));
    MR_String eval__V_7_7 = ((MR_String) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word eval__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word eval__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word eval__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 3)));
    MR_Word eval__TypeInfo_11_11;
    MR_Word eval__TypeInfo_12_12;
    MR_Word eval__TypeInfo_15_15;

    eval__succeeded = (strcmp(eval__V_3_3, eval__V_7_7) == 0);
    if (eval__succeeded)
      {
        eval__TypeInfo_11_11 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
        eval__TypeInfo_12_12 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
        {
          eval__succeeded = mercury__tree234____Unify____tree234_2_0(eval__TypeInfo_11_11, eval__TypeInfo_12_12, eval__V_4_4, eval__V_8_8);
        }
        if (eval__succeeded)
          {
            eval__TypeInfo_15_15 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
            {
              eval__succeeded = mercury__list____Unify____list_1_0(eval__TypeInfo_15_15, eval__V_5_5, eval__V_9_9);
            }
            if (eval__succeeded)
              {
                return eval__succeeded = gml____Unify____token_0_0(eval__V_6_6, eval__V_10_10);
              }
          }
      }
    return eval__succeeded;
  }
#line 110 "eval.m"
}

#line 107 "eval.m"
void MR_CALL eval____Compare____stack_env_exception_0_0(
#line 107 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 107 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 107 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 107 "eval.m"
{
  {
    bool eval__succeeded;
    MR_String eval__V_4_4 = ((MR_String) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word eval__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word eval__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 2)));
    MR_String eval__V_7_7 = ((MR_String) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 0)));
    MR_Word eval__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 1)));
    MR_Word eval__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 2)));
#line 107 "eval.m"
    MR_Word eval__V_10_10;
    MR_Integer eval__Res_7_23;
    MR_Integer eval__V_28_28;

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL eval____Compare____stack_env_exception_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__V_4_4
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__V_7_7
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__Res_7_23
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    eval__V_28_28 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    eval__succeeded = (eval__Res_7_23 < eval__V_28_28);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (eval__succeeded)
      {
        MR_Word eval__V_29_29 = (MR_Integer) 1;

#line 107 "eval.m"
        eval__succeeded = (eval__V_29_29 == (MR_Integer) 0);
#line 107 "eval.m"
        eval__succeeded = !(eval__succeeded);
        if (eval__succeeded)
          {
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            eval__V_10_10 = (MR_Integer) 1;
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            eval__succeeded = TRUE;
          }
      }
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        eval__succeeded = (eval__Res_7_23 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (eval__succeeded)
          {
            MR_Word eval__V_30_30 = (MR_Integer) 0;

#line 107 "eval.m"
            eval__succeeded = (eval__V_30_30 == (MR_Integer) 0);
#line 107 "eval.m"
            eval__succeeded = !(eval__succeeded);
            if (eval__succeeded)
              {
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__V_10_10 = (MR_Integer) 0;
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__succeeded = TRUE;
              }
          }
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
          {
            MR_Word eval__V_31_31 = (MR_Integer) 2;

#line 107 "eval.m"
            eval__succeeded = (eval__V_31_31 == (MR_Integer) 0);
#line 107 "eval.m"
            eval__succeeded = !(eval__succeeded);
            if (eval__succeeded)
              {
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__V_10_10 = (MR_Integer) 2;
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__succeeded = TRUE;
              }
          }
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 107 "eval.m"
    if (eval__succeeded)
#line 107 "eval.m"
      *eval__HeadVar__1_1 = eval__V_10_10;
#line 107 "eval.m"
    else
#line 107 "eval.m"
      {
#line 107 "eval.m"
        MR_Word eval__V_11_11;
        MR_Word eval__TypeInfo_13_13 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
        MR_Word eval__TypeInfo_14_14 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 107 "eval.m"
        {
#line 107 "eval.m"
          mercury__tree234____Compare____tree234_2_0(eval__TypeInfo_13_13, eval__TypeInfo_14_14, &eval__V_11_11, eval__V_5_5, eval__V_8_8);
        }
#line 107 "eval.m"
        eval__succeeded = (eval__V_11_11 == (MR_Integer) 0);
#line 107 "eval.m"
        eval__succeeded = !(eval__succeeded);
#line 107 "eval.m"
        if (eval__succeeded)
#line 107 "eval.m"
          *eval__HeadVar__1_1 = eval__V_11_11;
#line 107 "eval.m"
        else
          {
            MR_Word eval__TypeInfo_17_17 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 107 "eval.m"
            {
#line 107 "eval.m"
              mercury__list____Compare____list_1_0(eval__TypeInfo_17_17, eval__HeadVar__1_1, eval__V_6_6, eval__V_9_9);
#line 107 "eval.m"
              return;
            }
          }
#line 107 "eval.m"
      }
  }
#line 107 "eval.m"
}

#line 107 "eval.m"
bool MR_CALL eval____Unify____stack_env_exception_0_0(
#line 107 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 107 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 107 "eval.m"
{
  {
    bool eval__succeeded;
    MR_String eval__V_3_3 = ((MR_String) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word eval__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word eval__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 2)));
    MR_String eval__V_6_6 = ((MR_String) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word eval__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word eval__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word eval__TypeInfo_9_9;
    MR_Word eval__TypeInfo_10_10;
    MR_Word eval__TypeInfo_13_13;

    eval__succeeded = (strcmp(eval__V_3_3, eval__V_6_6) == 0);
    if (eval__succeeded)
      {
        eval__TypeInfo_9_9 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
        eval__TypeInfo_10_10 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
        {
          eval__succeeded = mercury__tree234____Unify____tree234_2_0(eval__TypeInfo_9_9, eval__TypeInfo_10_10, eval__V_4_4, eval__V_7_7);
        }
        if (eval__succeeded)
          {
            eval__TypeInfo_13_13 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
            {
              return eval__succeeded = mercury__list____Unify____list_1_0(eval__TypeInfo_13_13, eval__V_5_5, eval__V_8_8);
            }
          }
      }
    return eval__succeeded;
  }
#line 107 "eval.m"
}

#line 96 "eval.m"
void MR_CALL eval____Compare____code_0_0(
#line 96 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 96 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 96 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 96 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Word eval__conv1_HeadVar__2_2 = (MR_Word) eval__HeadVar__2_2;
    MR_Word eval__conv2_HeadVar__3_3 = (MR_Word) eval__HeadVar__3_3;
    MR_Word eval__TypeInfo_4_4 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 96 "eval.m"
    {
#line 96 "eval.m"
      mercury__list____Compare____list_1_0(eval__TypeInfo_4_4, eval__HeadVar__1_1, eval__conv1_HeadVar__2_2, eval__conv2_HeadVar__3_3);
#line 96 "eval.m"
      return;
    }
  }
#line 96 "eval.m"
}

#line 96 "eval.m"
bool MR_CALL eval____Unify____code_0_0(
#line 96 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 96 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 96 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Word eval__conv1_HeadVar__1_1 = (MR_Word) eval__HeadVar__1_1;
    MR_Word eval__conv2_HeadVar__2_2 = (MR_Word) eval__HeadVar__2_2;
    MR_Word eval__TypeInfo_3_3 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 96 "eval.m"
    {
#line 96 "eval.m"
      eval__succeeded = mercury__list____Unify____list_1_0(eval__TypeInfo_3_3, eval__conv1_HeadVar__1_1, eval__conv2_HeadVar__2_2);
    }
    if (eval__succeeded)
      eval__succeeded = TRUE;
    return eval__succeeded;
  }
#line 96 "eval.m"
}

#line 94 "eval.m"
void MR_CALL eval____Compare____stack_0_0(
#line 94 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 94 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 94 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 94 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Word eval__conv1_HeadVar__2_2 = (MR_Word) eval__HeadVar__2_2;
    MR_Word eval__conv2_HeadVar__3_3 = (MR_Word) eval__HeadVar__3_3;
    MR_Word eval__TypeInfo_4_4 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 94 "eval.m"
    {
#line 94 "eval.m"
      mercury__list____Compare____list_1_0(eval__TypeInfo_4_4, eval__HeadVar__1_1, eval__conv1_HeadVar__2_2, eval__conv2_HeadVar__3_3);
#line 94 "eval.m"
      return;
    }
  }
#line 94 "eval.m"
}

#line 94 "eval.m"
bool MR_CALL eval____Unify____stack_0_0(
#line 94 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 94 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 94 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Word eval__conv1_HeadVar__1_1 = (MR_Word) eval__HeadVar__1_1;
    MR_Word eval__conv2_HeadVar__2_2 = (MR_Word) eval__HeadVar__2_2;
    MR_Word eval__TypeInfo_3_3 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 94 "eval.m"
    {
#line 94 "eval.m"
      eval__succeeded = mercury__list____Unify____list_1_0(eval__TypeInfo_3_3, eval__conv1_HeadVar__1_1, eval__conv2_HeadVar__2_2);
    }
    if (eval__succeeded)
      eval__succeeded = TRUE;
    return eval__succeeded;
  }
#line 94 "eval.m"
}

#line 92 "eval.m"
void MR_CALL eval____Compare____id_0_0(
#line 92 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 92 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 92 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 92 "eval.m"
{
  {
    bool eval__succeeded;
    MR_String eval__conv1_HeadVar__2_2 = (MR_String) eval__HeadVar__2_2;
    MR_String eval__conv2_HeadVar__3_3 = (MR_String) eval__HeadVar__3_3;
    MR_Integer eval__Res_7_8;
    MR_Integer eval__V_13_13;

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL eval____Compare____id_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__conv1_HeadVar__2_2
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__conv2_HeadVar__3_3
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__Res_7_8
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    eval__V_13_13 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    eval__succeeded = (eval__Res_7_8 < eval__V_13_13);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (eval__succeeded)
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        eval__succeeded = (eval__Res_7_8 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (eval__succeeded)
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *eval__HeadVar__1_1 = (MR_Integer) 0;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
  }
#line 92 "eval.m"
}

#line 92 "eval.m"
bool MR_CALL eval____Unify____id_0_0(
#line 92 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 92 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 92 "eval.m"
{
#line 92 "eval.m"
  {
#line 92 "eval.m"
    bool eval__succeeded;
#line 92 "eval.m"
    MR_String eval__conv1_HeadVar__1_1 = (MR_String) eval__HeadVar__1_1;
#line 92 "eval.m"
    MR_String eval__conv2_HeadVar__2_2 = (MR_String) eval__HeadVar__2_2;

#line 92 "eval.m"
    eval__succeeded = (strcmp(eval__conv1_HeadVar__1_1, eval__conv2_HeadVar__2_2) == 0);
#line 92 "eval.m"
    if (eval__succeeded)
#line 92 "eval.m"
      eval__succeeded = TRUE;
#line 92 "eval.m"
    return eval__succeeded;
#line 92 "eval.m"
  }
#line 92 "eval.m"
}

#line 90 "eval.m"
void MR_CALL eval____Compare____env_0_0(
#line 90 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 90 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 90 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 90 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Word eval__conv1_HeadVar__2_2 = (MR_Word) eval__HeadVar__2_2;
    MR_Word eval__conv2_HeadVar__3_3 = (MR_Word) eval__HeadVar__3_3;
    MR_Word eval__TypeInfo_4_4 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
    MR_Word eval__TypeInfo_5_5 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 90 "eval.m"
    {
#line 90 "eval.m"
      mercury__tree234____Compare____tree234_2_0(eval__TypeInfo_4_4, eval__TypeInfo_5_5, eval__HeadVar__1_1, eval__conv1_HeadVar__2_2, eval__conv2_HeadVar__3_3);
#line 90 "eval.m"
      return;
    }
  }
#line 90 "eval.m"
}

#line 90 "eval.m"
bool MR_CALL eval____Unify____env_0_0(
#line 90 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 90 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 90 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Word eval__conv1_HeadVar__1_1 = (MR_Word) eval__HeadVar__1_1;
    MR_Word eval__conv2_HeadVar__2_2 = (MR_Word) eval__HeadVar__2_2;
    MR_Word eval__TypeInfo_3_3 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
    MR_Word eval__TypeInfo_4_4 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 90 "eval.m"
    {
#line 90 "eval.m"
      eval__succeeded = mercury__tree234____Unify____tree234_2_0(eval__TypeInfo_3_3, eval__TypeInfo_4_4, eval__conv1_HeadVar__1_1, eval__conv2_HeadVar__2_2);
    }
    if (eval__succeeded)
      eval__succeeded = TRUE;
    return eval__succeeded;
  }
#line 90 "eval.m"
}

#line 82 "eval.m"
void MR_CALL eval____Compare____surface_properties_0_0(
#line 82 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 82 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 82 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 82 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Word eval__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float eval__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float eval__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float eval__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 3)));
    MR_Word eval__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float eval__V_9_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 1)));
    MR_Float eval__V_10_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 2)));
    MR_Float eval__V_11_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 3)));
#line 82 "eval.m"
    MR_Word eval__V_12_12;

#line 82 "eval.m"
    {
#line 82 "eval.m"
      vector____Compare____vector_0_0(&eval__V_12_12, eval__V_4_4, eval__V_8_8);
    }
#line 82 "eval.m"
    eval__succeeded = (eval__V_12_12 == (MR_Integer) 0);
#line 82 "eval.m"
    eval__succeeded = !(eval__succeeded);
#line 82 "eval.m"
    if (eval__succeeded)
#line 82 "eval.m"
      *eval__HeadVar__1_1 = eval__V_12_12;
#line 82 "eval.m"
    else
#line 82 "eval.m"
      {
#line 82 "eval.m"
        MR_Word eval__V_13_13;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        eval__succeeded = (eval__V_5_5 < eval__V_9_9);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (eval__succeeded)
          {
            MR_Word eval__V_28_28 = (MR_Integer) 1;

#line 82 "eval.m"
            eval__succeeded = (eval__V_28_28 == (MR_Integer) 0);
#line 82 "eval.m"
            eval__succeeded = !(eval__succeeded);
            if (eval__succeeded)
              {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__V_13_13 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__succeeded = TRUE;
              }
          }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            eval__succeeded = (eval__V_5_5 > eval__V_9_9);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (eval__succeeded)
              {
                MR_Word eval__V_29_29 = (MR_Integer) 2;

#line 82 "eval.m"
                eval__succeeded = (eval__V_29_29 == (MR_Integer) 0);
#line 82 "eval.m"
                eval__succeeded = !(eval__succeeded);
                if (eval__succeeded)
                  {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    eval__V_13_13 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    eval__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
              {
                MR_Word eval__V_30_30 = (MR_Integer) 0;

#line 82 "eval.m"
                eval__succeeded = (eval__V_30_30 == (MR_Integer) 0);
#line 82 "eval.m"
                eval__succeeded = !(eval__succeeded);
                if (eval__succeeded)
                  {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    eval__V_13_13 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    eval__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 82 "eval.m"
        if (eval__succeeded)
#line 82 "eval.m"
          *eval__HeadVar__1_1 = eval__V_13_13;
#line 82 "eval.m"
        else
#line 82 "eval.m"
          {
#line 82 "eval.m"
            MR_Word eval__V_14_14;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            eval__succeeded = (eval__V_6_6 < eval__V_10_10);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (eval__succeeded)
              {
                MR_Word eval__V_31_31 = (MR_Integer) 1;

#line 82 "eval.m"
                eval__succeeded = (eval__V_31_31 == (MR_Integer) 0);
#line 82 "eval.m"
                eval__succeeded = !(eval__succeeded);
                if (eval__succeeded)
                  {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    eval__V_14_14 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    eval__succeeded = TRUE;
                  }
              }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__succeeded = (eval__V_6_6 > eval__V_10_10);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (eval__succeeded)
                  {
                    MR_Word eval__V_32_32 = (MR_Integer) 2;

#line 82 "eval.m"
                    eval__succeeded = (eval__V_32_32 == (MR_Integer) 0);
#line 82 "eval.m"
                    eval__succeeded = !(eval__succeeded);
                    if (eval__succeeded)
                      {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        eval__V_14_14 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        eval__succeeded = TRUE;
                      }
                  }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
                  {
                    MR_Word eval__V_33_33 = (MR_Integer) 0;

#line 82 "eval.m"
                    eval__succeeded = (eval__V_33_33 == (MR_Integer) 0);
#line 82 "eval.m"
                    eval__succeeded = !(eval__succeeded);
                    if (eval__succeeded)
                      {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        eval__V_14_14 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        eval__succeeded = TRUE;
                      }
                  }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              }
#line 82 "eval.m"
            if (eval__succeeded)
#line 82 "eval.m"
              *eval__HeadVar__1_1 = eval__V_14_14;
#line 82 "eval.m"
            else
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                eval__succeeded = (eval__V_7_7 < eval__V_11_11);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (eval__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    eval__succeeded = (eval__V_7_7 > eval__V_11_11);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    if (eval__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      *eval__HeadVar__1_1 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              }
#line 82 "eval.m"
          }
#line 82 "eval.m"
      }
  }
#line 82 "eval.m"
}

#line 82 "eval.m"
bool MR_CALL eval____Unify____surface_properties_0_0(
#line 82 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 82 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 82 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Word eval__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float eval__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float eval__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float eval__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 3)));
    MR_Word eval__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float eval__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float eval__V_9_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float eval__V_10_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 3)));

    {
      eval__succeeded = vector____Unify____vector_0_0(eval__V_3_3, eval__V_7_7);
    }
    if (eval__succeeded)
      {
        eval__succeeded = (eval__V_4_4 == eval__V_8_8);
        if (eval__succeeded)
          {
            eval__succeeded = (eval__V_5_5 == eval__V_9_9);
            if (eval__succeeded)
              eval__succeeded = (eval__V_6_6 == eval__V_10_10);
          }
      }
    return eval__succeeded;
  }
#line 82 "eval.m"
}

#line 78 "eval.m"
void MR_CALL eval____Compare____surface_0_0(
#line 78 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 78 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 78 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 78 "eval.m"
{
#line 78 "eval.m"
  {
#line 78 "eval.m"
    bool eval__succeeded;

#line 78 "eval.m"
    if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
      {
        MR_Word eval__V_26_26 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word eval__V_27_27 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));

#line 78 "eval.m"
        if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
          {
            MR_Word eval__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 0)));
            MR_Word eval__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 78 "eval.m"
            MR_Word eval__V_8_8;
            MR_Word eval__TypeInfo_17_17 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
            MR_Word eval__TypeInfo_18_18 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 78 "eval.m"
            {
#line 78 "eval.m"
              mercury__tree234____Compare____tree234_2_0(eval__TypeInfo_17_17, eval__TypeInfo_18_18, &eval__V_8_8, eval__V_27_27, eval__V_6_6);
            }
#line 78 "eval.m"
            eval__succeeded = (eval__V_8_8 == (MR_Integer) 0);
#line 78 "eval.m"
            eval__succeeded = !(eval__succeeded);
#line 78 "eval.m"
            if (eval__succeeded)
#line 78 "eval.m"
              *eval__HeadVar__1_1 = eval__V_8_8;
#line 78 "eval.m"
            else
              {
                MR_Word eval__TypeInfo_21_21 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 78 "eval.m"
                {
#line 78 "eval.m"
                  mercury__list____Compare____list_1_0(eval__TypeInfo_21_21, eval__HeadVar__1_1, eval__V_26_26, eval__V_7_7);
#line 78 "eval.m"
                  return;
                }
              }
          }
#line 78 "eval.m"
        else
#line 78 "eval.m"
          *eval__HeadVar__1_1 = (MR_Integer) 1;
      }
#line 78 "eval.m"
    else
#line 78 "eval.m"
      {
        MR_Word eval__V_25_25 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));

#line 78 "eval.m"
        if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
#line 78 "eval.m"
          *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 78 "eval.m"
        else
#line 78 "eval.m"
          {
            MR_Word eval__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));

#line 78 "eval.m"
            {
#line 78 "eval.m"
              eval____Compare____surface_properties_0_0(eval__HeadVar__1_1, eval__V_25_25, eval__V_10_10);
#line 78 "eval.m"
              return;
            }
#line 78 "eval.m"
          }
#line 78 "eval.m"
      }
#line 78 "eval.m"
  }
#line 78 "eval.m"
}

#line 78 "eval.m"
bool MR_CALL eval____Unify____surface_0_0(
#line 78 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 78 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 78 "eval.m"
{
#line 78 "eval.m"
  {
#line 78 "eval.m"
    bool eval__succeeded;

#line 78 "eval.m"
    if ((MR_tag((MR_Word) eval__HeadVar__1_1) == MR_mktag((MR_Integer) 0)))
      {
        MR_Word eval__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 0)));
        MR_Word eval__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 1)));
        MR_Word eval__V_5_5;
        MR_Word eval__V_6_6;
        MR_Word eval__TypeInfo_9_9;
        MR_Word eval__TypeInfo_10_10;
        MR_Word eval__TypeInfo_13_13;

#line 78 "eval.m"
        eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
#line 78 "eval.m"
        if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 78 "eval.m"
          {
#line 78 "eval.m"
            eval__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 78 "eval.m"
            eval__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 78 "eval.m"
          }
        if (eval__succeeded)
          {
            eval__TypeInfo_9_9 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
            eval__TypeInfo_10_10 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
            {
              eval__succeeded = mercury__tree234____Unify____tree234_2_0(eval__TypeInfo_9_9, eval__TypeInfo_10_10, eval__V_3_3, eval__V_5_5);
            }
            if (eval__succeeded)
              {
                eval__TypeInfo_13_13 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
                {
                  return eval__succeeded = mercury__list____Unify____list_1_0(eval__TypeInfo_13_13, eval__V_4_4, eval__V_6_6);
                }
              }
          }
      }
#line 78 "eval.m"
    else
#line 78 "eval.m"
      {
        MR_Word eval__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 0)));
        MR_Word eval__V_8_8;
        MR_Word eval__V_16_16;
        MR_Float eval__V_17_17;
        MR_Float eval__V_18_18;
        MR_Float eval__V_19_19;
        MR_Word eval__V_20_20;
        MR_Float eval__V_21_21;
        MR_Float eval__V_22_22;
        MR_Float eval__V_23_23;

#line 78 "eval.m"
        eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 78 "eval.m"
        if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 78 "eval.m"
          eval__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));
        if (eval__succeeded)
          {
#line 82 "eval.m"
            eval__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__V_7_7, (MR_Integer) 0)));
#line 82 "eval.m"
            eval__V_17_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_7_7, (MR_Integer) 1)));
#line 82 "eval.m"
            eval__V_18_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_7_7, (MR_Integer) 2)));
#line 82 "eval.m"
            eval__V_19_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_7_7, (MR_Integer) 3)));
#line 82 "eval.m"
            eval__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__V_8_8, (MR_Integer) 0)));
#line 82 "eval.m"
            eval__V_21_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_8_8, (MR_Integer) 1)));
#line 82 "eval.m"
            eval__V_22_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_8_8, (MR_Integer) 2)));
#line 82 "eval.m"
            eval__V_23_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_8_8, (MR_Integer) 3)));
            {
              eval__succeeded = vector____Unify____vector_0_0(eval__V_16_16, eval__V_20_20);
            }
            if (eval__succeeded)
              {
                eval__succeeded = (eval__V_17_17 == eval__V_21_21);
                if (eval__succeeded)
                  {
                    eval__succeeded = (eval__V_18_18 == eval__V_22_22);
                    if (eval__succeeded)
                      eval__succeeded = (eval__V_19_19 == eval__V_23_23);
                  }
              }
          }
#line 78 "eval.m"
      }
#line 78 "eval.m"
    return eval__succeeded;
#line 78 "eval.m"
  }
#line 78 "eval.m"
}

#line 68 "eval.m"
void MR_CALL eval____Compare____transformation_0_0(
#line 68 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 68 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 68 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 68 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Integer eval__V_4_4;
    MR_Integer eval__V_5_5;

#line 68 "eval.m"
    {
#line 68 "eval.m"
      eval____Index____transformation_0_0(eval__HeadVar__2_2, &eval__V_4_4);
    }
#line 68 "eval.m"
    {
#line 68 "eval.m"
      eval____Index____transformation_0_0(eval__HeadVar__3_3, &eval__V_5_5);
    }
#line 68 "eval.m"
    eval__succeeded = (eval__V_4_4 < eval__V_5_5);
#line 68 "eval.m"
    if (eval__succeeded)
#line 68 "eval.m"
      *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 68 "eval.m"
    else
#line 68 "eval.m"
      {
#line 68 "eval.m"
        eval__succeeded = (eval__V_4_4 > eval__V_5_5);
#line 68 "eval.m"
        if (eval__succeeded)
#line 68 "eval.m"
          *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 68 "eval.m"
        else
#line 68 "eval.m"
          {
#line 68 "eval.m"
            MR_Word eval__V_6_6;

#line 68 "eval.m"
#line 68 "eval.m"
            switch (MR_tag((MR_Word) eval__HeadVar__2_2)) {
#line 68 "eval.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 68 "eval.m"
              case (MR_Integer) 3:
#line 68 "eval.m"
#line 68 "eval.m"
                switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0)))) {
#line 68 "eval.m"
                  default: /*NOTREACHED*/ MR_assert(0);
#line 68 "eval.m"
                  case (MR_Integer) 0:
                    {
                      MR_Float eval__V_25_25 = MR_unbox_float((MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Float eval__V_26_26;

#line 68 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 0));
#line 68 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 68 "eval.m"
                        eval__V_26_26 = MR_unbox_float((MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
                      if (eval__succeeded)
                        {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = (eval__V_25_25 < eval__V_26_26);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (eval__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            eval__V_6_6 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__succeeded = (eval__V_25_25 > eval__V_26_26);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              if (eval__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                eval__V_6_6 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                eval__V_6_6 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = TRUE;
                        }
                    }
#line 68 "eval.m"
                    break;
#line 68 "eval.m"
                  case (MR_Integer) 1:
                    {
                      MR_Float eval__V_27_27 = MR_unbox_float((MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Float eval__V_28_28;

#line 68 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 1));
#line 68 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 68 "eval.m"
                        eval__V_28_28 = MR_unbox_float((MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
                      if (eval__succeeded)
                        {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = (eval__V_27_27 < eval__V_28_28);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (eval__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            eval__V_6_6 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__succeeded = (eval__V_27_27 > eval__V_28_28);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              if (eval__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                eval__V_6_6 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                eval__V_6_6 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = TRUE;
                        }
                    }
#line 68 "eval.m"
                    break;
#line 68 "eval.m"
                  case (MR_Integer) 2:
                    {
                      MR_Float eval__V_29_29 = MR_unbox_float((MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Float eval__V_30_30;

#line 68 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 2));
#line 68 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 2)))
#line 68 "eval.m"
                        eval__V_30_30 = MR_unbox_float((MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
                      if (eval__succeeded)
                        {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = (eval__V_29_29 < eval__V_30_30);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (eval__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            eval__V_6_6 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__succeeded = (eval__V_29_29 > eval__V_30_30);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              if (eval__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                eval__V_6_6 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                eval__V_6_6 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = TRUE;
                        }
                    }
#line 68 "eval.m"
                    break;
#line 68 "eval.m"
                  case (MR_Integer) 3:
                    {
                      MR_Word eval__V_31_31 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word eval__V_32_32;

#line 68 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 3));
#line 68 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 68 "eval.m"
                        eval__V_32_32 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
                      if (eval__succeeded)
                        {
#line 68 "eval.m"
                          {
#line 68 "eval.m"
                            trans____Compare____trans_0_0(&eval__V_6_6, eval__V_31_31, eval__V_32_32);
                          }
#line 68 "eval.m"
                          eval__succeeded = TRUE;
                        }
                    }
#line 68 "eval.m"
                    break;
#line 68 "eval.m"
                }
#line 68 "eval.m"
                break;
#line 68 "eval.m"
              case (MR_Integer) 0:
                {
                  MR_Float eval__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Float eval__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
                  MR_Float eval__V_9_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 2)));
                  MR_Float eval__V_10_10;
                  MR_Float eval__V_11_11;
                  MR_Float eval__V_12_12;
#line 68 "eval.m"
                  MR_Word eval__V_13_13;

#line 68 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 0));
#line 68 "eval.m"
                  if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
#line 68 "eval.m"
                    {
#line 68 "eval.m"
                      eval__V_10_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 68 "eval.m"
                      eval__V_11_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 68 "eval.m"
                      eval__V_12_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 2)));
#line 68 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      eval__succeeded = (eval__V_7_7 < eval__V_10_10);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (eval__succeeded)
                        {
                          MR_Word eval__V_80_80 = (MR_Integer) 1;

#line 68 "eval.m"
                          eval__succeeded = (eval__V_80_80 == (MR_Integer) 0);
#line 68 "eval.m"
                          eval__succeeded = !(eval__succeeded);
                          if (eval__succeeded)
                            {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__V_13_13 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__succeeded = TRUE;
                            }
                        }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = (eval__V_7_7 > eval__V_10_10);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (eval__succeeded)
                            {
                              MR_Word eval__V_81_81 = (MR_Integer) 2;

#line 68 "eval.m"
                              eval__succeeded = (eval__V_81_81 == (MR_Integer) 0);
#line 68 "eval.m"
                              eval__succeeded = !(eval__succeeded);
                              if (eval__succeeded)
                                {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__V_13_13 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__succeeded = TRUE;
                                }
                            }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
                            {
                              MR_Word eval__V_82_82 = (MR_Integer) 0;

#line 68 "eval.m"
                              eval__succeeded = (eval__V_82_82 == (MR_Integer) 0);
#line 68 "eval.m"
                              eval__succeeded = !(eval__succeeded);
                              if (eval__succeeded)
                                {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__V_13_13 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__succeeded = TRUE;
                                }
                            }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 68 "eval.m"
                      if (eval__succeeded)
#line 68 "eval.m"
                        eval__V_6_6 = eval__V_13_13;
#line 68 "eval.m"
                      else
#line 68 "eval.m"
                        {
#line 68 "eval.m"
                          MR_Word eval__V_14_14;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = (eval__V_8_8 < eval__V_11_11);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (eval__succeeded)
                            {
                              MR_Word eval__V_83_83 = (MR_Integer) 1;

#line 68 "eval.m"
                              eval__succeeded = (eval__V_83_83 == (MR_Integer) 0);
#line 68 "eval.m"
                              eval__succeeded = !(eval__succeeded);
                              if (eval__succeeded)
                                {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__V_14_14 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__succeeded = TRUE;
                                }
                            }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__succeeded = (eval__V_8_8 > eval__V_11_11);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              if (eval__succeeded)
                                {
                                  MR_Word eval__V_84_84 = (MR_Integer) 2;

#line 68 "eval.m"
                                  eval__succeeded = (eval__V_84_84 == (MR_Integer) 0);
#line 68 "eval.m"
                                  eval__succeeded = !(eval__succeeded);
                                  if (eval__succeeded)
                                    {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      eval__V_14_14 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      eval__succeeded = TRUE;
                                    }
                                }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              else
                                {
                                  MR_Word eval__V_85_85 = (MR_Integer) 0;

#line 68 "eval.m"
                                  eval__succeeded = (eval__V_85_85 == (MR_Integer) 0);
#line 68 "eval.m"
                                  eval__succeeded = !(eval__succeeded);
                                  if (eval__succeeded)
                                    {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      eval__V_14_14 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      eval__succeeded = TRUE;
                                    }
                                }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            }
#line 68 "eval.m"
                          if (eval__succeeded)
#line 68 "eval.m"
                            eval__V_6_6 = eval__V_14_14;
#line 68 "eval.m"
                          else
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__succeeded = (eval__V_9_9 < eval__V_12_12);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              if (eval__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                eval__V_6_6 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__succeeded = (eval__V_9_9 > eval__V_12_12);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  if (eval__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    eval__V_6_6 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    eval__V_6_6 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            }
#line 68 "eval.m"
                        }
#line 68 "eval.m"
                      eval__succeeded = TRUE;
                    }
                }
#line 68 "eval.m"
                break;
#line 68 "eval.m"
              case (MR_Integer) 1:
                {
                  MR_Float eval__V_15_15 = MR_unbox_float((MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Float eval__V_16_16 = MR_unbox_float((MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 1)));
                  MR_Float eval__V_17_17 = MR_unbox_float((MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 2)));
                  MR_Float eval__V_18_18;
                  MR_Float eval__V_19_19;
                  MR_Float eval__V_20_20;
#line 68 "eval.m"
                  MR_Word eval__V_21_21;

#line 68 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 68 "eval.m"
                  if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 68 "eval.m"
                    {
#line 68 "eval.m"
                      eval__V_18_18 = MR_unbox_float((MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 68 "eval.m"
                      eval__V_19_19 = MR_unbox_float((MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 68 "eval.m"
                      eval__V_20_20 = MR_unbox_float((MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 2)));
#line 68 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      eval__succeeded = (eval__V_15_15 < eval__V_18_18);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (eval__succeeded)
                        {
                          MR_Word eval__V_74_74 = (MR_Integer) 1;

#line 68 "eval.m"
                          eval__succeeded = (eval__V_74_74 == (MR_Integer) 0);
#line 68 "eval.m"
                          eval__succeeded = !(eval__succeeded);
                          if (eval__succeeded)
                            {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__V_21_21 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__succeeded = TRUE;
                            }
                        }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = (eval__V_15_15 > eval__V_18_18);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (eval__succeeded)
                            {
                              MR_Word eval__V_75_75 = (MR_Integer) 2;

#line 68 "eval.m"
                              eval__succeeded = (eval__V_75_75 == (MR_Integer) 0);
#line 68 "eval.m"
                              eval__succeeded = !(eval__succeeded);
                              if (eval__succeeded)
                                {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__V_21_21 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__succeeded = TRUE;
                                }
                            }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
                            {
                              MR_Word eval__V_76_76 = (MR_Integer) 0;

#line 68 "eval.m"
                              eval__succeeded = (eval__V_76_76 == (MR_Integer) 0);
#line 68 "eval.m"
                              eval__succeeded = !(eval__succeeded);
                              if (eval__succeeded)
                                {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__V_21_21 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__succeeded = TRUE;
                                }
                            }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 68 "eval.m"
                      if (eval__succeeded)
#line 68 "eval.m"
                        eval__V_6_6 = eval__V_21_21;
#line 68 "eval.m"
                      else
#line 68 "eval.m"
                        {
#line 68 "eval.m"
                          MR_Word eval__V_22_22;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = (eval__V_16_16 < eval__V_19_19);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (eval__succeeded)
                            {
                              MR_Word eval__V_77_77 = (MR_Integer) 1;

#line 68 "eval.m"
                              eval__succeeded = (eval__V_77_77 == (MR_Integer) 0);
#line 68 "eval.m"
                              eval__succeeded = !(eval__succeeded);
                              if (eval__succeeded)
                                {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__V_22_22 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__succeeded = TRUE;
                                }
                            }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__succeeded = (eval__V_16_16 > eval__V_19_19);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              if (eval__succeeded)
                                {
                                  MR_Word eval__V_78_78 = (MR_Integer) 2;

#line 68 "eval.m"
                                  eval__succeeded = (eval__V_78_78 == (MR_Integer) 0);
#line 68 "eval.m"
                                  eval__succeeded = !(eval__succeeded);
                                  if (eval__succeeded)
                                    {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      eval__V_22_22 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      eval__succeeded = TRUE;
                                    }
                                }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              else
                                {
                                  MR_Word eval__V_79_79 = (MR_Integer) 0;

#line 68 "eval.m"
                                  eval__succeeded = (eval__V_79_79 == (MR_Integer) 0);
#line 68 "eval.m"
                                  eval__succeeded = !(eval__succeeded);
                                  if (eval__succeeded)
                                    {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      eval__V_22_22 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      eval__succeeded = TRUE;
                                    }
                                }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            }
#line 68 "eval.m"
                          if (eval__succeeded)
#line 68 "eval.m"
                            eval__V_6_6 = eval__V_22_22;
#line 68 "eval.m"
                          else
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__succeeded = (eval__V_17_17 < eval__V_20_20);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              if (eval__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                eval__V_6_6 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__succeeded = (eval__V_17_17 > eval__V_20_20);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  if (eval__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    eval__V_6_6 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    eval__V_6_6 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            }
#line 68 "eval.m"
                        }
#line 68 "eval.m"
                      eval__succeeded = TRUE;
                    }
                }
#line 68 "eval.m"
                break;
#line 68 "eval.m"
              case (MR_Integer) 2:
                {
                  MR_Float eval__V_23_23 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Float eval__V_24_24;

#line 68 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 2));
#line 68 "eval.m"
                  if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 2)))
#line 68 "eval.m"
                    eval__V_24_24 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__3_3, (MR_Integer) 0)));
                  if (eval__succeeded)
                    {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      eval__succeeded = (eval__V_23_23 < eval__V_24_24);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (eval__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        eval__V_6_6 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = (eval__V_23_23 > eval__V_24_24);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (eval__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            eval__V_6_6 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            eval__V_6_6 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      eval__succeeded = TRUE;
                    }
                }
#line 68 "eval.m"
                break;
#line 68 "eval.m"
            }
#line 68 "eval.m"
            if (eval__succeeded)
#line 68 "eval.m"
              *eval__HeadVar__1_1 = eval__V_6_6;
#line 68 "eval.m"
            else
#line 68 "eval.m"
              {
#line 68 "eval.m"
                mercury__private_builtin__compare_error_0_p_0();
#line 68 "eval.m"
                return;
              }
#line 68 "eval.m"
          }
#line 68 "eval.m"
      }
  }
#line 68 "eval.m"
}

#line 68 "eval.m"
void MR_CALL eval____Index____transformation_0_0(
#line 68 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 68 "eval.m"
  MR_Integer * eval__HeadVar__2_2)
#line 68 "eval.m"
{
#line 68 "eval.m"
  {
#line 68 "eval.m"
    bool eval__succeeded;

#line 68 "eval.m"
#line 68 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__1_1)) {
#line 68 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 68 "eval.m"
      case (MR_Integer) 3:
#line 68 "eval.m"
#line 68 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 0)))) {
#line 68 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 68 "eval.m"
          case (MR_Integer) 0:
#line 68 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 3;
#line 68 "eval.m"
            break;
#line 68 "eval.m"
          case (MR_Integer) 1:
#line 68 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 4;
#line 68 "eval.m"
            break;
#line 68 "eval.m"
          case (MR_Integer) 2:
#line 68 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 5;
#line 68 "eval.m"
            break;
#line 68 "eval.m"
          case (MR_Integer) 3:
#line 68 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 6;
#line 68 "eval.m"
            break;
#line 68 "eval.m"
        }
#line 68 "eval.m"
        break;
#line 68 "eval.m"
      case (MR_Integer) 0:
#line 68 "eval.m"
        *eval__HeadVar__2_2 = (MR_Integer) 0;
#line 68 "eval.m"
        break;
#line 68 "eval.m"
      case (MR_Integer) 1:
#line 68 "eval.m"
        *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 68 "eval.m"
        break;
#line 68 "eval.m"
      case (MR_Integer) 2:
#line 68 "eval.m"
        *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 68 "eval.m"
        break;
#line 68 "eval.m"
    }
#line 68 "eval.m"
  }
#line 68 "eval.m"
}

#line 68 "eval.m"
bool MR_CALL eval____Unify____transformation_0_0(
#line 68 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 68 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 68 "eval.m"
{
#line 68 "eval.m"
  {
#line 68 "eval.m"
    bool eval__succeeded;
#line 68 "eval.m"
    MR_Float eval__V_3_3;
#line 68 "eval.m"
    MR_Float eval__V_4_4;
#line 68 "eval.m"
    MR_Float eval__V_5_5;
#line 68 "eval.m"
    MR_Float eval__V_6_6;
#line 68 "eval.m"
    MR_Float eval__V_7_7;
#line 68 "eval.m"
    MR_Float eval__V_8_8;
#line 68 "eval.m"
    MR_Float eval__V_9_9;
#line 68 "eval.m"
    MR_Float eval__V_10_10;
#line 68 "eval.m"
    MR_Float eval__V_11_11;
#line 68 "eval.m"
    MR_Float eval__V_12_12;
#line 68 "eval.m"
    MR_Float eval__V_13_13;
#line 68 "eval.m"
    MR_Float eval__V_14_14;
#line 68 "eval.m"
    MR_Float eval__V_15_15;
#line 68 "eval.m"
    MR_Float eval__V_16_16;
#line 68 "eval.m"
    MR_Float eval__V_17_17;
#line 68 "eval.m"
    MR_Float eval__V_18_18;
#line 68 "eval.m"
    MR_Float eval__V_19_19;
#line 68 "eval.m"
    MR_Float eval__V_20_20;
#line 68 "eval.m"
    MR_Float eval__V_21_21;
#line 68 "eval.m"
    MR_Float eval__V_22_22;
#line 68 "eval.m"
    MR_Word eval__V_23_23;
#line 68 "eval.m"
    MR_Word eval__V_24_24;

#line 68 "eval.m"
#line 68 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__1_1)) {
#line 68 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 68 "eval.m"
      case (MR_Integer) 3:
#line 68 "eval.m"
#line 68 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 0)))) {
#line 68 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 68 "eval.m"
          case (MR_Integer) 0:
            {
#line 68 "eval.m"
              eval__V_17_17 = MR_unbox_float((MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 68 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 0));
#line 68 "eval.m"
              if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 68 "eval.m"
                eval__V_18_18 = MR_unbox_float((MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
              if (eval__succeeded)
                eval__succeeded = (eval__V_17_17 == eval__V_18_18);
            }
#line 68 "eval.m"
            break;
#line 68 "eval.m"
          case (MR_Integer) 1:
            {
#line 68 "eval.m"
              eval__V_19_19 = MR_unbox_float((MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 68 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 1));
#line 68 "eval.m"
              if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 68 "eval.m"
                eval__V_20_20 = MR_unbox_float((MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
              if (eval__succeeded)
                eval__succeeded = (eval__V_19_19 == eval__V_20_20);
            }
#line 68 "eval.m"
            break;
#line 68 "eval.m"
          case (MR_Integer) 2:
            {
#line 68 "eval.m"
              eval__V_21_21 = MR_unbox_float((MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 68 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 2));
#line 68 "eval.m"
              if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 2)))
#line 68 "eval.m"
                eval__V_22_22 = MR_unbox_float((MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
              if (eval__succeeded)
                eval__succeeded = (eval__V_21_21 == eval__V_22_22);
            }
#line 68 "eval.m"
            break;
#line 68 "eval.m"
          case (MR_Integer) 3:
            {
#line 68 "eval.m"
              eval__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 68 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 3));
#line 68 "eval.m"
              if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 68 "eval.m"
                eval__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
              if (eval__succeeded)
                {
                  return eval__succeeded = trans____Unify____trans_0_0(eval__V_23_23, eval__V_24_24);
                }
            }
#line 68 "eval.m"
            break;
#line 68 "eval.m"
        }
#line 68 "eval.m"
        break;
#line 68 "eval.m"
      case (MR_Integer) 0:
        {
#line 68 "eval.m"
          eval__V_3_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 68 "eval.m"
          eval__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 68 "eval.m"
          eval__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 2)));
#line 68 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
#line 68 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 68 "eval.m"
            {
#line 68 "eval.m"
              eval__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 68 "eval.m"
              eval__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 68 "eval.m"
              eval__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 2)));
#line 68 "eval.m"
            }
          if (eval__succeeded)
            {
              eval__succeeded = (eval__V_3_3 == eval__V_6_6);
              if (eval__succeeded)
                {
                  eval__succeeded = (eval__V_4_4 == eval__V_7_7);
                  if (eval__succeeded)
                    eval__succeeded = (eval__V_5_5 == eval__V_8_8);
                }
            }
        }
#line 68 "eval.m"
        break;
#line 68 "eval.m"
      case (MR_Integer) 1:
        {
#line 68 "eval.m"
          eval__V_9_9 = MR_unbox_float((MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 68 "eval.m"
          eval__V_10_10 = MR_unbox_float((MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 68 "eval.m"
          eval__V_11_11 = MR_unbox_float((MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 2)));
#line 68 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 68 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 68 "eval.m"
            {
#line 68 "eval.m"
              eval__V_12_12 = MR_unbox_float((MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 68 "eval.m"
              eval__V_13_13 = MR_unbox_float((MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 68 "eval.m"
              eval__V_14_14 = MR_unbox_float((MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 2)));
#line 68 "eval.m"
            }
          if (eval__succeeded)
            {
              eval__succeeded = (eval__V_9_9 == eval__V_12_12);
              if (eval__succeeded)
                {
                  eval__succeeded = (eval__V_10_10 == eval__V_13_13);
                  if (eval__succeeded)
                    eval__succeeded = (eval__V_11_11 == eval__V_14_14);
                }
            }
        }
#line 68 "eval.m"
        break;
#line 68 "eval.m"
      case (MR_Integer) 2:
        {
#line 68 "eval.m"
          eval__V_15_15 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 68 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 2));
#line 68 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 2)))
#line 68 "eval.m"
            eval__V_16_16 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 0)));
          if (eval__succeeded)
            eval__succeeded = (eval__V_15_15 == eval__V_16_16);
        }
#line 68 "eval.m"
        break;
#line 68 "eval.m"
    }
#line 68 "eval.m"
    return eval__succeeded;
#line 68 "eval.m"
  }
#line 68 "eval.m"
}

#line 61 "eval.m"
void MR_CALL eval____Compare____basic_object_0_0(
#line 61 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 61 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 61 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 61 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Integer eval__V_4_4;
    MR_Integer eval__V_5_5;

#line 61 "eval.m"
#line 61 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__2_2)) {
#line 61 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 61 "eval.m"
      case (MR_Integer) 3:
#line 61 "eval.m"
#line 61 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0)))) {
#line 61 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 61 "eval.m"
          case (MR_Integer) 0:
#line 61 "eval.m"
            eval__V_4_4 = (MR_Integer) 3;
#line 61 "eval.m"
            break;
#line 61 "eval.m"
          case (MR_Integer) 1:
#line 61 "eval.m"
            eval__V_4_4 = (MR_Integer) 4;
#line 61 "eval.m"
            break;
#line 61 "eval.m"
        }
#line 61 "eval.m"
        break;
#line 61 "eval.m"
      case (MR_Integer) 0:
#line 61 "eval.m"
        eval__V_4_4 = (MR_Integer) 0;
#line 61 "eval.m"
        break;
#line 61 "eval.m"
      case (MR_Integer) 1:
#line 61 "eval.m"
        eval__V_4_4 = (MR_Integer) 1;
#line 61 "eval.m"
        break;
#line 61 "eval.m"
      case (MR_Integer) 2:
#line 61 "eval.m"
        eval__V_4_4 = (MR_Integer) 2;
#line 61 "eval.m"
        break;
#line 61 "eval.m"
    }
#line 61 "eval.m"
#line 61 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__3_3)) {
#line 61 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 61 "eval.m"
      case (MR_Integer) 3:
#line 61 "eval.m"
#line 61 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0)))) {
#line 61 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 61 "eval.m"
          case (MR_Integer) 0:
#line 61 "eval.m"
            eval__V_5_5 = (MR_Integer) 3;
#line 61 "eval.m"
            break;
#line 61 "eval.m"
          case (MR_Integer) 1:
#line 61 "eval.m"
            eval__V_5_5 = (MR_Integer) 4;
#line 61 "eval.m"
            break;
#line 61 "eval.m"
        }
#line 61 "eval.m"
        break;
#line 61 "eval.m"
      case (MR_Integer) 0:
#line 61 "eval.m"
        eval__V_5_5 = (MR_Integer) 0;
#line 61 "eval.m"
        break;
#line 61 "eval.m"
      case (MR_Integer) 1:
#line 61 "eval.m"
        eval__V_5_5 = (MR_Integer) 1;
#line 61 "eval.m"
        break;
#line 61 "eval.m"
      case (MR_Integer) 2:
#line 61 "eval.m"
        eval__V_5_5 = (MR_Integer) 2;
#line 61 "eval.m"
        break;
#line 61 "eval.m"
    }
#line 61 "eval.m"
    eval__succeeded = (eval__V_4_4 < eval__V_5_5);
#line 61 "eval.m"
    if (eval__succeeded)
#line 61 "eval.m"
      *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 61 "eval.m"
    else
#line 61 "eval.m"
      {
#line 61 "eval.m"
        eval__succeeded = (eval__V_4_4 > eval__V_5_5);
#line 61 "eval.m"
        if (eval__succeeded)
#line 61 "eval.m"
          *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 61 "eval.m"
        else
#line 61 "eval.m"
          {
#line 61 "eval.m"
            MR_Word eval__V_6_6;
#line 61 "eval.m"
            MR_Word eval__V_7_7;
#line 61 "eval.m"
            MR_Word eval__V_8_8;
#line 61 "eval.m"
            MR_Word eval__V_9_9;
#line 61 "eval.m"
            MR_Word eval__V_10_10;
#line 61 "eval.m"
            MR_Word eval__V_11_11;
#line 61 "eval.m"
            MR_Word eval__V_12_12;
#line 61 "eval.m"
            MR_Word eval__V_13_13;
#line 61 "eval.m"
            MR_Word eval__V_14_14;
#line 61 "eval.m"
            MR_Word eval__V_15_15;
#line 61 "eval.m"
            MR_Word eval__V_16_16;

#line 61 "eval.m"
#line 61 "eval.m"
            switch (MR_tag((MR_Word) eval__HeadVar__2_2)) {
#line 61 "eval.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 61 "eval.m"
              case (MR_Integer) 3:
#line 61 "eval.m"
#line 61 "eval.m"
                switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0)))) {
#line 61 "eval.m"
                  default: /*NOTREACHED*/ MR_assert(0);
#line 61 "eval.m"
                  case (MR_Integer) 0:
                    {
#line 61 "eval.m"
                      eval__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 61 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 0));
#line 61 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 61 "eval.m"
                        eval__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
                      if (eval__succeeded)
                        {
#line 61 "eval.m"
                          {
#line 61 "eval.m"
                            eval____Compare____surface_0_0(&eval__V_6_6, eval__V_13_13, eval__V_14_14);
                          }
#line 61 "eval.m"
                          eval__succeeded = TRUE;
                        }
                    }
#line 61 "eval.m"
                    break;
#line 61 "eval.m"
                  case (MR_Integer) 1:
                    {
#line 61 "eval.m"
                      eval__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 61 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 1));
#line 61 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 61 "eval.m"
                        eval__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
                      if (eval__succeeded)
                        {
#line 61 "eval.m"
                          {
#line 61 "eval.m"
                            eval____Compare____surface_0_0(&eval__V_6_6, eval__V_15_15, eval__V_16_16);
                          }
#line 61 "eval.m"
                          eval__succeeded = TRUE;
                        }
                    }
#line 61 "eval.m"
                    break;
#line 61 "eval.m"
                }
#line 61 "eval.m"
                break;
#line 61 "eval.m"
              case (MR_Integer) 0:
                {
#line 61 "eval.m"
                  eval__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 61 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 0));
#line 61 "eval.m"
                  if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
#line 61 "eval.m"
                    eval__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 0)));
                  if (eval__succeeded)
                    {
#line 61 "eval.m"
                      {
#line 61 "eval.m"
                        eval____Compare____surface_0_0(&eval__V_6_6, eval__V_7_7, eval__V_8_8);
                      }
#line 61 "eval.m"
                      eval__succeeded = TRUE;
                    }
                }
#line 61 "eval.m"
                break;
#line 61 "eval.m"
              case (MR_Integer) 1:
                {
#line 61 "eval.m"
                  eval__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 61 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 61 "eval.m"
                  if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 61 "eval.m"
                    eval__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
                  if (eval__succeeded)
                    {
#line 61 "eval.m"
                      {
#line 61 "eval.m"
                        eval____Compare____surface_0_0(&eval__V_6_6, eval__V_9_9, eval__V_10_10);
                      }
#line 61 "eval.m"
                      eval__succeeded = TRUE;
                    }
                }
#line 61 "eval.m"
                break;
#line 61 "eval.m"
              case (MR_Integer) 2:
                {
#line 61 "eval.m"
                  eval__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 61 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 2));
#line 61 "eval.m"
                  if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 2)))
#line 61 "eval.m"
                    eval__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__3_3, (MR_Integer) 0)));
                  if (eval__succeeded)
                    {
#line 61 "eval.m"
                      {
#line 61 "eval.m"
                        eval____Compare____surface_0_0(&eval__V_6_6, eval__V_11_11, eval__V_12_12);
                      }
#line 61 "eval.m"
                      eval__succeeded = TRUE;
                    }
                }
#line 61 "eval.m"
                break;
#line 61 "eval.m"
            }
#line 61 "eval.m"
            if (eval__succeeded)
#line 61 "eval.m"
              *eval__HeadVar__1_1 = eval__V_6_6;
#line 61 "eval.m"
            else
#line 61 "eval.m"
              {
#line 61 "eval.m"
                mercury__private_builtin__compare_error_0_p_0();
#line 61 "eval.m"
                return;
              }
#line 61 "eval.m"
          }
#line 61 "eval.m"
      }
  }
#line 61 "eval.m"
}

#line 61 "eval.m"
void MR_CALL eval____Index____basic_object_0_0(
#line 61 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 61 "eval.m"
  MR_Integer * eval__HeadVar__2_2)
#line 61 "eval.m"
{
#line 61 "eval.m"
  {
#line 61 "eval.m"
    bool eval__succeeded;

#line 61 "eval.m"
#line 61 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__1_1)) {
#line 61 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 61 "eval.m"
      case (MR_Integer) 3:
#line 61 "eval.m"
#line 61 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 0)))) {
#line 61 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 61 "eval.m"
          case (MR_Integer) 0:
#line 61 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 3;
#line 61 "eval.m"
            break;
#line 61 "eval.m"
          case (MR_Integer) 1:
#line 61 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 4;
#line 61 "eval.m"
            break;
#line 61 "eval.m"
        }
#line 61 "eval.m"
        break;
#line 61 "eval.m"
      case (MR_Integer) 0:
#line 61 "eval.m"
        *eval__HeadVar__2_2 = (MR_Integer) 0;
#line 61 "eval.m"
        break;
#line 61 "eval.m"
      case (MR_Integer) 1:
#line 61 "eval.m"
        *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 61 "eval.m"
        break;
#line 61 "eval.m"
      case (MR_Integer) 2:
#line 61 "eval.m"
        *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 61 "eval.m"
        break;
#line 61 "eval.m"
    }
#line 61 "eval.m"
  }
#line 61 "eval.m"
}

#line 61 "eval.m"
bool MR_CALL eval____Unify____basic_object_0_0(
#line 61 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 61 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 61 "eval.m"
{
#line 61 "eval.m"
  {
#line 61 "eval.m"
    bool eval__succeeded;
#line 61 "eval.m"
    MR_Word eval__V_3_3;
#line 61 "eval.m"
    MR_Word eval__V_4_4;
#line 61 "eval.m"
    MR_Word eval__V_5_5;
#line 61 "eval.m"
    MR_Word eval__V_6_6;
#line 61 "eval.m"
    MR_Word eval__V_7_7;
#line 61 "eval.m"
    MR_Word eval__V_8_8;
#line 61 "eval.m"
    MR_Word eval__V_9_9;
#line 61 "eval.m"
    MR_Word eval__V_10_10;
#line 61 "eval.m"
    MR_Word eval__V_11_11;
#line 61 "eval.m"
    MR_Word eval__V_12_12;

#line 61 "eval.m"
#line 61 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__1_1)) {
#line 61 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 61 "eval.m"
      case (MR_Integer) 3:
#line 61 "eval.m"
#line 61 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 0)))) {
#line 61 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 61 "eval.m"
          case (MR_Integer) 0:
            {
#line 61 "eval.m"
              eval__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 61 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 0));
#line 61 "eval.m"
              if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 61 "eval.m"
                eval__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
              if (eval__succeeded)
                {
                  return eval__succeeded = eval____Unify____surface_0_0(eval__V_9_9, eval__V_10_10);
                }
            }
#line 61 "eval.m"
            break;
#line 61 "eval.m"
          case (MR_Integer) 1:
            {
#line 61 "eval.m"
              eval__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 61 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 1));
#line 61 "eval.m"
              if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 61 "eval.m"
                eval__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
              if (eval__succeeded)
                {
                  return eval__succeeded = eval____Unify____surface_0_0(eval__V_11_11, eval__V_12_12);
                }
            }
#line 61 "eval.m"
            break;
#line 61 "eval.m"
        }
#line 61 "eval.m"
        break;
#line 61 "eval.m"
      case (MR_Integer) 0:
        {
#line 61 "eval.m"
          eval__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 61 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
#line 61 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 61 "eval.m"
            eval__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
          if (eval__succeeded)
            {
              return eval__succeeded = eval____Unify____surface_0_0(eval__V_3_3, eval__V_4_4);
            }
        }
#line 61 "eval.m"
        break;
#line 61 "eval.m"
      case (MR_Integer) 1:
        {
#line 61 "eval.m"
          eval__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 61 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 61 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 61 "eval.m"
            eval__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));
          if (eval__succeeded)
            {
              return eval__succeeded = eval____Unify____surface_0_0(eval__V_5_5, eval__V_6_6);
            }
        }
#line 61 "eval.m"
        break;
#line 61 "eval.m"
      case (MR_Integer) 2:
        {
#line 61 "eval.m"
          eval__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 61 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 2));
#line 61 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 2)))
#line 61 "eval.m"
            eval__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 0)));
          if (eval__succeeded)
            {
              return eval__succeeded = eval____Unify____surface_0_0(eval__V_7_7, eval__V_8_8);
            }
        }
#line 61 "eval.m"
        break;
#line 61 "eval.m"
    }
#line 61 "eval.m"
    return eval__succeeded;
#line 61 "eval.m"
  }
#line 61 "eval.m"
}

#line 47 "eval.m"
void MR_CALL eval____Compare____object_0_0(
#line 47 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 47 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 47 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 47 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Integer eval__V_4_4;
    MR_Integer eval__V_5_5;

#line 47 "eval.m"
#line 47 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__2_2)) {
#line 47 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 47 "eval.m"
      case (MR_Integer) 3:
#line 47 "eval.m"
#line 47 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0)))) {
#line 47 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 47 "eval.m"
          case (MR_Integer) 0:
#line 47 "eval.m"
            eval__V_4_4 = (MR_Integer) 3;
#line 47 "eval.m"
            break;
#line 47 "eval.m"
          case (MR_Integer) 1:
#line 47 "eval.m"
            eval__V_4_4 = (MR_Integer) 4;
#line 47 "eval.m"
            break;
#line 47 "eval.m"
        }
#line 47 "eval.m"
        break;
#line 47 "eval.m"
      case (MR_Integer) 0:
#line 47 "eval.m"
        eval__V_4_4 = (MR_Integer) 0;
#line 47 "eval.m"
        break;
#line 47 "eval.m"
      case (MR_Integer) 1:
#line 47 "eval.m"
        eval__V_4_4 = (MR_Integer) 1;
#line 47 "eval.m"
        break;
#line 47 "eval.m"
      case (MR_Integer) 2:
#line 47 "eval.m"
        eval__V_4_4 = (MR_Integer) 2;
#line 47 "eval.m"
        break;
#line 47 "eval.m"
    }
#line 47 "eval.m"
#line 47 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__3_3)) {
#line 47 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 47 "eval.m"
      case (MR_Integer) 3:
#line 47 "eval.m"
#line 47 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0)))) {
#line 47 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 47 "eval.m"
          case (MR_Integer) 0:
#line 47 "eval.m"
            eval__V_5_5 = (MR_Integer) 3;
#line 47 "eval.m"
            break;
#line 47 "eval.m"
          case (MR_Integer) 1:
#line 47 "eval.m"
            eval__V_5_5 = (MR_Integer) 4;
#line 47 "eval.m"
            break;
#line 47 "eval.m"
        }
#line 47 "eval.m"
        break;
#line 47 "eval.m"
      case (MR_Integer) 0:
#line 47 "eval.m"
        eval__V_5_5 = (MR_Integer) 0;
#line 47 "eval.m"
        break;
#line 47 "eval.m"
      case (MR_Integer) 1:
#line 47 "eval.m"
        eval__V_5_5 = (MR_Integer) 1;
#line 47 "eval.m"
        break;
#line 47 "eval.m"
      case (MR_Integer) 2:
#line 47 "eval.m"
        eval__V_5_5 = (MR_Integer) 2;
#line 47 "eval.m"
        break;
#line 47 "eval.m"
    }
#line 47 "eval.m"
    eval__succeeded = (eval__V_4_4 < eval__V_5_5);
#line 47 "eval.m"
    if (eval__succeeded)
#line 47 "eval.m"
      *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 47 "eval.m"
    else
#line 47 "eval.m"
      {
#line 47 "eval.m"
        eval__succeeded = (eval__V_4_4 > eval__V_5_5);
#line 47 "eval.m"
        if (eval__succeeded)
#line 47 "eval.m"
          *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 47 "eval.m"
        else
#line 47 "eval.m"
          {
#line 47 "eval.m"
            MR_Word eval__V_6_6;

#line 47 "eval.m"
#line 47 "eval.m"
            switch (MR_tag((MR_Word) eval__HeadVar__2_2)) {
#line 47 "eval.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 47 "eval.m"
              case (MR_Integer) 3:
#line 47 "eval.m"
#line 47 "eval.m"
                switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0)))) {
#line 47 "eval.m"
                  default: /*NOTREACHED*/ MR_assert(0);
#line 47 "eval.m"
                  case (MR_Integer) 0:
                    {
                      MR_Word eval__V_25_25 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word eval__V_26_26 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 2)));
                      MR_Word eval__V_27_27;
                      MR_Word eval__V_28_28;
#line 47 "eval.m"
                      MR_Word eval__V_29_29;

#line 47 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 0));
#line 47 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 47 "eval.m"
                        {
#line 47 "eval.m"
                          eval__V_27_27 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 47 "eval.m"
                          eval__V_28_28 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 2)));
#line 47 "eval.m"
                        }
                      if (eval__succeeded)
                        {
#line 47 "eval.m"
                          {
#line 47 "eval.m"
                            eval____Compare____object_0_0(&eval__V_29_29, eval__V_25_25, eval__V_27_27);
                          }
#line 47 "eval.m"
                          eval__succeeded = (eval__V_29_29 == (MR_Integer) 0);
#line 47 "eval.m"
                          eval__succeeded = !(eval__succeeded);
#line 47 "eval.m"
                          if (eval__succeeded)
#line 47 "eval.m"
                            eval__V_6_6 = eval__V_29_29;
#line 47 "eval.m"
                          else
#line 47 "eval.m"
                            {
#line 47 "eval.m"
                              eval____Compare____object_0_0(&eval__V_6_6, eval__V_26_26, eval__V_28_28);
                            }
#line 47 "eval.m"
                          eval__succeeded = TRUE;
                        }
                    }
#line 47 "eval.m"
                    break;
#line 47 "eval.m"
                  case (MR_Integer) 1:
                    {
                      MR_Word eval__V_30_30 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word eval__V_31_31 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 2)));
                      MR_Word eval__V_32_32;
                      MR_Word eval__V_33_33;
#line 47 "eval.m"
                      MR_Word eval__V_34_34;

#line 47 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 1));
#line 47 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 47 "eval.m"
                        {
#line 47 "eval.m"
                          eval__V_32_32 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 47 "eval.m"
                          eval__V_33_33 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 2)));
#line 47 "eval.m"
                        }
                      if (eval__succeeded)
                        {
#line 47 "eval.m"
                          {
#line 47 "eval.m"
                            eval____Compare____object_0_0(&eval__V_34_34, eval__V_30_30, eval__V_32_32);
                          }
#line 47 "eval.m"
                          eval__succeeded = (eval__V_34_34 == (MR_Integer) 0);
#line 47 "eval.m"
                          eval__succeeded = !(eval__succeeded);
#line 47 "eval.m"
                          if (eval__succeeded)
#line 47 "eval.m"
                            eval__V_6_6 = eval__V_34_34;
#line 47 "eval.m"
                          else
#line 47 "eval.m"
                            {
#line 47 "eval.m"
                              eval____Compare____object_0_0(&eval__V_6_6, eval__V_31_31, eval__V_33_33);
                            }
#line 47 "eval.m"
                          eval__succeeded = TRUE;
                        }
                    }
#line 47 "eval.m"
                    break;
#line 47 "eval.m"
                }
#line 47 "eval.m"
                break;
#line 47 "eval.m"
              case (MR_Integer) 0:
                {
                  MR_Integer eval__V_7_7 = ((MR_Integer) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Word eval__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
                  MR_Word eval__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 2)));
                  MR_Integer eval__V_10_10;
                  MR_Word eval__V_11_11;
                  MR_Word eval__V_12_12;
#line 47 "eval.m"
                  MR_Word eval__V_13_13;

#line 47 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 0));
#line 47 "eval.m"
                  if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
#line 47 "eval.m"
                    {
#line 47 "eval.m"
                      eval__V_10_10 = ((MR_Integer) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 47 "eval.m"
                      eval__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 47 "eval.m"
                      eval__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 2)));
#line 47 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      eval__succeeded = (eval__V_7_7 < eval__V_10_10);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (eval__succeeded)
                        {
                          MR_Word eval__V_73_73 = (MR_Integer) 1;

#line 47 "eval.m"
                          eval__succeeded = (eval__V_73_73 == (MR_Integer) 0);
#line 47 "eval.m"
                          eval__succeeded = !(eval__succeeded);
                          if (eval__succeeded)
                            {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__V_13_13 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__succeeded = TRUE;
                            }
                        }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = (eval__V_7_7 == eval__V_10_10);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (eval__succeeded)
                            {
                              MR_Word eval__V_74_74 = (MR_Integer) 0;

#line 47 "eval.m"
                              eval__succeeded = (eval__V_74_74 == (MR_Integer) 0);
#line 47 "eval.m"
                              eval__succeeded = !(eval__succeeded);
                              if (eval__succeeded)
                                {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__V_13_13 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__succeeded = TRUE;
                                }
                            }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
                            {
                              MR_Word eval__V_75_75 = (MR_Integer) 2;

#line 47 "eval.m"
                              eval__succeeded = (eval__V_75_75 == (MR_Integer) 0);
#line 47 "eval.m"
                              eval__succeeded = !(eval__succeeded);
                              if (eval__succeeded)
                                {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__V_13_13 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  eval__succeeded = TRUE;
                                }
                            }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 47 "eval.m"
                      if (eval__succeeded)
#line 47 "eval.m"
                        eval__V_6_6 = eval__V_13_13;
#line 47 "eval.m"
                      else
#line 47 "eval.m"
                        {
#line 47 "eval.m"
                          MR_Word eval__V_14_14;

#line 47 "eval.m"
                          {
#line 47 "eval.m"
                            eval____Compare____basic_object_0_0(&eval__V_14_14, eval__V_8_8, eval__V_11_11);
                          }
#line 47 "eval.m"
                          eval__succeeded = (eval__V_14_14 == (MR_Integer) 0);
#line 47 "eval.m"
                          eval__succeeded = !(eval__succeeded);
#line 47 "eval.m"
                          if (eval__succeeded)
#line 47 "eval.m"
                            eval__V_6_6 = eval__V_14_14;
#line 47 "eval.m"
                          else
                            {
                              MR_Word eval__TypeInfo_37_37 = (MR_Word) (&eval__eval__type_ctor_info_light_0);

#line 47 "eval.m"
                              {
#line 47 "eval.m"
                                mercury__list____Compare____list_1_0(eval__TypeInfo_37_37, &eval__V_6_6, eval__V_9_9, eval__V_12_12);
                              }
                            }
#line 47 "eval.m"
                        }
#line 47 "eval.m"
                      eval__succeeded = TRUE;
                    }
                }
#line 47 "eval.m"
                break;
#line 47 "eval.m"
              case (MR_Integer) 1:
                {
                  MR_Word eval__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Word eval__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 1)));
                  MR_Word eval__V_17_17;
                  MR_Word eval__V_18_18;
#line 47 "eval.m"
                  MR_Word eval__V_19_19;

#line 47 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 47 "eval.m"
                  if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 47 "eval.m"
                    {
#line 47 "eval.m"
                      eval__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 47 "eval.m"
                      eval__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 47 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 47 "eval.m"
                      {
#line 47 "eval.m"
                        eval____Compare____object_0_0(&eval__V_19_19, eval__V_15_15, eval__V_17_17);
                      }
#line 47 "eval.m"
                      eval__succeeded = (eval__V_19_19 == (MR_Integer) 0);
#line 47 "eval.m"
                      eval__succeeded = !(eval__succeeded);
#line 47 "eval.m"
                      if (eval__succeeded)
#line 47 "eval.m"
                        eval__V_6_6 = eval__V_19_19;
#line 47 "eval.m"
                      else
#line 47 "eval.m"
                        {
#line 47 "eval.m"
                          eval____Compare____transformation_0_0(&eval__V_6_6, eval__V_16_16, eval__V_18_18);
                        }
#line 47 "eval.m"
                      eval__succeeded = TRUE;
                    }
                }
#line 47 "eval.m"
                break;
#line 47 "eval.m"
              case (MR_Integer) 2:
                {
                  MR_Word eval__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Word eval__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 1)));
                  MR_Word eval__V_22_22;
                  MR_Word eval__V_23_23;
#line 47 "eval.m"
                  MR_Word eval__V_24_24;

#line 47 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 2));
#line 47 "eval.m"
                  if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 2)))
#line 47 "eval.m"
                    {
#line 47 "eval.m"
                      eval__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 47 "eval.m"
                      eval__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 47 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 47 "eval.m"
                      {
#line 47 "eval.m"
                        eval____Compare____object_0_0(&eval__V_24_24, eval__V_20_20, eval__V_22_22);
                      }
#line 47 "eval.m"
                      eval__succeeded = (eval__V_24_24 == (MR_Integer) 0);
#line 47 "eval.m"
                      eval__succeeded = !(eval__succeeded);
#line 47 "eval.m"
                      if (eval__succeeded)
#line 47 "eval.m"
                        eval__V_6_6 = eval__V_24_24;
#line 47 "eval.m"
                      else
#line 47 "eval.m"
                        {
#line 47 "eval.m"
                          eval____Compare____object_0_0(&eval__V_6_6, eval__V_21_21, eval__V_23_23);
                        }
#line 47 "eval.m"
                      eval__succeeded = TRUE;
                    }
                }
#line 47 "eval.m"
                break;
#line 47 "eval.m"
            }
#line 47 "eval.m"
            if (eval__succeeded)
#line 47 "eval.m"
              *eval__HeadVar__1_1 = eval__V_6_6;
#line 47 "eval.m"
            else
#line 47 "eval.m"
              {
#line 47 "eval.m"
                mercury__private_builtin__compare_error_0_p_0();
#line 47 "eval.m"
                return;
              }
#line 47 "eval.m"
          }
#line 47 "eval.m"
      }
  }
#line 47 "eval.m"
}

#line 47 "eval.m"
void MR_CALL eval____Index____object_0_0(
#line 47 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 47 "eval.m"
  MR_Integer * eval__HeadVar__2_2)
#line 47 "eval.m"
{
#line 47 "eval.m"
  {
#line 47 "eval.m"
    bool eval__succeeded;

#line 47 "eval.m"
#line 47 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__1_1)) {
#line 47 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 47 "eval.m"
      case (MR_Integer) 3:
#line 47 "eval.m"
#line 47 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 0)))) {
#line 47 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 47 "eval.m"
          case (MR_Integer) 0:
#line 47 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 3;
#line 47 "eval.m"
            break;
#line 47 "eval.m"
          case (MR_Integer) 1:
#line 47 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 4;
#line 47 "eval.m"
            break;
#line 47 "eval.m"
        }
#line 47 "eval.m"
        break;
#line 47 "eval.m"
      case (MR_Integer) 0:
#line 47 "eval.m"
        *eval__HeadVar__2_2 = (MR_Integer) 0;
#line 47 "eval.m"
        break;
#line 47 "eval.m"
      case (MR_Integer) 1:
#line 47 "eval.m"
        *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 47 "eval.m"
        break;
#line 47 "eval.m"
      case (MR_Integer) 2:
#line 47 "eval.m"
        *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 47 "eval.m"
        break;
#line 47 "eval.m"
    }
#line 47 "eval.m"
  }
#line 47 "eval.m"
}

#line 47 "eval.m"
bool MR_CALL eval____Unify____object_0_0(
#line 47 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 47 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 47 "eval.m"
{
#line 47 "eval.m"
  {
#line 47 "eval.m"
    /* tailcall optimized into a loop */
#line 47 "eval.m"
  loop_top:;
#line 47 "eval.m"
    {
#line 47 "eval.m"
      bool eval__succeeded;

#line 47 "eval.m"
#line 47 "eval.m"
      switch (MR_tag((MR_Word) eval__HeadVar__1_1)) {
#line 47 "eval.m"
        default: /*NOTREACHED*/ MR_assert(0);
#line 47 "eval.m"
        case (MR_Integer) 3:
#line 47 "eval.m"
#line 47 "eval.m"
          switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 0)))) {
#line 47 "eval.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 47 "eval.m"
            case (MR_Integer) 0:
              {
                MR_Word eval__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
                MR_Word eval__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 2)));
                MR_Word eval__V_19_19;
                MR_Word eval__V_20_20;

#line 47 "eval.m"
                eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 0));
#line 47 "eval.m"
                if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 47 "eval.m"
                  {
#line 47 "eval.m"
                    eval__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 47 "eval.m"
                    eval__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 2)));
#line 47 "eval.m"
                  }
                if (eval__succeeded)
                  {
                    {
                      eval__succeeded = eval____Unify____object_0_0(eval__V_17_17, eval__V_19_19);
                    }
                    if (eval__succeeded)
                      {
                        /* direct tailcall eliminated */
                        {
                          MR_Word eval__HeadVar__1__tmp_copy_1 = eval__V_18_18;
                          MR_Word eval__HeadVar__2__tmp_copy_2 = eval__V_20_20;

                          eval__HeadVar__1_1 = eval__HeadVar__1__tmp_copy_1;
                          eval__HeadVar__2_2 = eval__HeadVar__2__tmp_copy_2;
                        }
                        goto loop_top;
                      }
                  }
              }
#line 47 "eval.m"
              break;
#line 47 "eval.m"
            case (MR_Integer) 1:
              {
                MR_Word eval__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
                MR_Word eval__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 2)));
                MR_Word eval__V_23_23;
                MR_Word eval__V_24_24;

#line 47 "eval.m"
                eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 1));
#line 47 "eval.m"
                if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 47 "eval.m"
                  {
#line 47 "eval.m"
                    eval__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 47 "eval.m"
                    eval__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 2)));
#line 47 "eval.m"
                  }
                if (eval__succeeded)
                  {
                    {
                      eval__succeeded = eval____Unify____object_0_0(eval__V_21_21, eval__V_23_23);
                    }
                    if (eval__succeeded)
                      {
                        /* direct tailcall eliminated */
                        {
                          MR_Word eval__HeadVar__1__tmp_copy_1 = eval__V_22_22;
                          MR_Word eval__HeadVar__2__tmp_copy_2 = eval__V_24_24;

                          eval__HeadVar__1_1 = eval__HeadVar__1__tmp_copy_1;
                          eval__HeadVar__2_2 = eval__HeadVar__2__tmp_copy_2;
                        }
                        goto loop_top;
                      }
                  }
              }
#line 47 "eval.m"
              break;
#line 47 "eval.m"
          }
#line 47 "eval.m"
          break;
#line 47 "eval.m"
        case (MR_Integer) 0:
          {
            MR_Integer eval__V_3_3 = ((MR_Integer) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 0)));
            MR_Word eval__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 1)));
            MR_Word eval__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 2)));
            MR_Integer eval__V_6_6;
            MR_Word eval__V_7_7;
            MR_Word eval__V_8_8;
            MR_Word eval__TypeInfo_25_25;

#line 47 "eval.m"
            eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
#line 47 "eval.m"
            if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 47 "eval.m"
              {
#line 47 "eval.m"
                eval__V_6_6 = ((MR_Integer) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 47 "eval.m"
                eval__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 47 "eval.m"
                eval__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 2)));
#line 47 "eval.m"
              }
            if (eval__succeeded)
              {
                eval__succeeded = (eval__V_3_3 == eval__V_6_6);
                if (eval__succeeded)
                  {
                    {
                      eval__succeeded = eval____Unify____basic_object_0_0(eval__V_4_4, eval__V_7_7);
                    }
                    if (eval__succeeded)
                      {
                        eval__TypeInfo_25_25 = (MR_Word) (&eval__eval__type_ctor_info_light_0);
                        {
                          return eval__succeeded = mercury__list____Unify____list_1_0(eval__TypeInfo_25_25, eval__V_5_5, eval__V_8_8);
                        }
                      }
                  }
              }
          }
#line 47 "eval.m"
          break;
#line 47 "eval.m"
        case (MR_Integer) 1:
          {
            MR_Word eval__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 0)));
            MR_Word eval__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 1)));
            MR_Word eval__V_11_11;
            MR_Word eval__V_12_12;

#line 47 "eval.m"
            eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 47 "eval.m"
            if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 47 "eval.m"
              {
#line 47 "eval.m"
                eval__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 47 "eval.m"
                eval__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 47 "eval.m"
              }
            if (eval__succeeded)
              {
                {
                  eval__succeeded = eval____Unify____object_0_0(eval__V_9_9, eval__V_11_11);
                }
                if (eval__succeeded)
                  {
                    return eval__succeeded = eval____Unify____transformation_0_0(eval__V_10_10, eval__V_12_12);
                  }
              }
          }
#line 47 "eval.m"
          break;
#line 47 "eval.m"
        case (MR_Integer) 2:
          {
            MR_Word eval__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 0)));
            MR_Word eval__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 1)));
            MR_Word eval__V_15_15;
            MR_Word eval__V_16_16;

#line 47 "eval.m"
            eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 2));
#line 47 "eval.m"
            if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 2)))
#line 47 "eval.m"
              {
#line 47 "eval.m"
                eval__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 47 "eval.m"
                eval__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 47 "eval.m"
              }
            if (eval__succeeded)
              {
                {
                  eval__succeeded = eval____Unify____object_0_0(eval__V_13_13, eval__V_15_15);
                }
                if (eval__succeeded)
                  {
                    /* direct tailcall eliminated */
                    {
                      MR_Word eval__HeadVar__1__tmp_copy_1 = eval__V_14_14;
                      MR_Word eval__HeadVar__2__tmp_copy_2 = eval__V_16_16;

                      eval__HeadVar__1_1 = eval__HeadVar__1__tmp_copy_1;
                      eval__HeadVar__2_2 = eval__HeadVar__2__tmp_copy_2;
                    }
                    goto loop_top;
                  }
              }
          }
#line 47 "eval.m"
          break;
#line 47 "eval.m"
      }
#line 47 "eval.m"
      return eval__succeeded;
#line 47 "eval.m"
    }
#line 47 "eval.m"
  }
#line 47 "eval.m"
}

#line 44 "eval.m"
void MR_CALL eval____Compare____object_id_0_0(
#line 44 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 44 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 44 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 44 "eval.m"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  {
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    bool eval__succeeded;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Integer eval__conv1_HeadVar__2_2 = (MR_Integer) eval__HeadVar__2_2;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Integer eval__conv2_HeadVar__3_3 = (MR_Integer) eval__HeadVar__3_3;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    eval__succeeded = (eval__conv1_HeadVar__2_2 < eval__conv2_HeadVar__3_3);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (eval__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        eval__succeeded = (eval__conv1_HeadVar__2_2 == eval__conv2_HeadVar__3_3);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (eval__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *eval__HeadVar__1_1 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  }
#line 44 "eval.m"
}

#line 44 "eval.m"
bool MR_CALL eval____Unify____object_id_0_0(
#line 44 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 44 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 44 "eval.m"
{
#line 44 "eval.m"
  {
#line 44 "eval.m"
    bool eval__succeeded;
#line 44 "eval.m"
    MR_Integer eval__conv1_HeadVar__1_1 = (MR_Integer) eval__HeadVar__1_1;
#line 44 "eval.m"
    MR_Integer eval__conv2_HeadVar__2_2 = (MR_Integer) eval__HeadVar__2_2;

#line 44 "eval.m"
    eval__succeeded = (eval__conv1_HeadVar__1_1 == eval__conv2_HeadVar__2_2);
#line 44 "eval.m"
    if (eval__succeeded)
#line 44 "eval.m"
      eval__succeeded = TRUE;
#line 44 "eval.m"
    return eval__succeeded;
#line 44 "eval.m"
  }
#line 44 "eval.m"
}

#line 42 "eval.m"
void MR_CALL eval____Compare____degrees_0_0(
#line 42 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 42 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 42 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 42 "eval.m"
{
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  {
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    bool eval__succeeded;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Float eval__conv1_HeadVar__2_2 = MR_unbox_float((MR_Box) eval__HeadVar__2_2);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Float eval__conv2_HeadVar__3_3 = MR_unbox_float((MR_Box) eval__HeadVar__3_3);

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    eval__succeeded = (eval__conv1_HeadVar__2_2 < eval__conv2_HeadVar__3_3);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (eval__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        eval__succeeded = (eval__conv1_HeadVar__2_2 > eval__conv2_HeadVar__3_3);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (eval__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *eval__HeadVar__1_1 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  }
#line 42 "eval.m"
}

#line 42 "eval.m"
bool MR_CALL eval____Unify____degrees_0_0(
#line 42 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 42 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 42 "eval.m"
{
#line 42 "eval.m"
  {
#line 42 "eval.m"
    bool eval__succeeded;
#line 42 "eval.m"
    MR_Float eval__conv1_HeadVar__1_1 = MR_unbox_float((MR_Box) eval__HeadVar__1_1);
#line 42 "eval.m"
    MR_Float eval__conv2_HeadVar__2_2 = MR_unbox_float((MR_Box) eval__HeadVar__2_2);

#line 42 "eval.m"
    eval__succeeded = (eval__conv1_HeadVar__1_1 == eval__conv2_HeadVar__2_2);
#line 42 "eval.m"
    if (eval__succeeded)
#line 42 "eval.m"
      eval__succeeded = TRUE;
#line 42 "eval.m"
    return eval__succeeded;
#line 42 "eval.m"
  }
#line 42 "eval.m"
}

#line 25 "eval.m"
void MR_CALL eval____Compare____light_0_0(
#line 25 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 25 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 25 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 25 "eval.m"
{
#line 25 "eval.m"
  {
#line 25 "eval.m"
    bool eval__succeeded;

#line 25 "eval.m"
#line 25 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__2_2)) {
#line 25 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 25 "eval.m"
      case (MR_Integer) 0:
        {
          MR_Word eval__V_73_73 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
          MR_Word eval__V_74_74 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));

#line 25 "eval.m"
#line 25 "eval.m"
          switch (MR_tag((MR_Word) eval__HeadVar__3_3)) {
#line 25 "eval.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 25 "eval.m"
            case (MR_Integer) 0:
              {
                MR_Word eval__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 0)));
                MR_Word eval__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 25 "eval.m"
                MR_Word eval__V_8_8;

#line 25 "eval.m"
                {
#line 25 "eval.m"
                  vector____Compare____vector_0_0(&eval__V_8_8, eval__V_74_74, eval__V_6_6);
                }
#line 25 "eval.m"
                eval__succeeded = (eval__V_8_8 == (MR_Integer) 0);
#line 25 "eval.m"
                eval__succeeded = !(eval__succeeded);
#line 25 "eval.m"
                if (eval__succeeded)
#line 25 "eval.m"
                  *eval__HeadVar__1_1 = eval__V_8_8;
#line 25 "eval.m"
                else
#line 25 "eval.m"
                  {
#line 25 "eval.m"
                    vector____Compare____vector_0_0(eval__HeadVar__1_1, eval__V_73_73, eval__V_7_7);
#line 25 "eval.m"
                    return;
                  }
              }
#line 25 "eval.m"
              break;
#line 25 "eval.m"
            case (MR_Integer) 1:
#line 25 "eval.m"
              *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 25 "eval.m"
              break;
#line 25 "eval.m"
            case (MR_Integer) 2:
#line 25 "eval.m"
              *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 25 "eval.m"
              break;
#line 25 "eval.m"
          }
        }
#line 25 "eval.m"
        break;
#line 25 "eval.m"
      case (MR_Integer) 1:
        {
          MR_Word eval__V_75_75 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 1)));
          MR_Word eval__V_76_76 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));

#line 25 "eval.m"
#line 25 "eval.m"
          switch (MR_tag((MR_Word) eval__HeadVar__3_3)) {
#line 25 "eval.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 25 "eval.m"
            case (MR_Integer) 0:
#line 25 "eval.m"
              *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 25 "eval.m"
              break;
#line 25 "eval.m"
            case (MR_Integer) 1:
              {
                MR_Word eval__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
                MR_Word eval__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 25 "eval.m"
                MR_Word eval__V_13_13;

#line 25 "eval.m"
                {
#line 25 "eval.m"
                  vector____Compare____vector_0_0(&eval__V_13_13, eval__V_76_76, eval__V_11_11);
                }
#line 25 "eval.m"
                eval__succeeded = (eval__V_13_13 == (MR_Integer) 0);
#line 25 "eval.m"
                eval__succeeded = !(eval__succeeded);
#line 25 "eval.m"
                if (eval__succeeded)
#line 25 "eval.m"
                  *eval__HeadVar__1_1 = eval__V_13_13;
#line 25 "eval.m"
                else
#line 25 "eval.m"
                  {
#line 25 "eval.m"
                    vector____Compare____vector_0_0(eval__HeadVar__1_1, eval__V_75_75, eval__V_12_12);
#line 25 "eval.m"
                    return;
                  }
              }
#line 25 "eval.m"
              break;
#line 25 "eval.m"
            case (MR_Integer) 2:
#line 25 "eval.m"
              *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 25 "eval.m"
              break;
#line 25 "eval.m"
          }
        }
#line 25 "eval.m"
        break;
#line 25 "eval.m"
      case (MR_Integer) 2:
        {
          MR_Float eval__V_77_77 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 4)));
          MR_Float eval__V_78_78 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 3)));
          MR_Word eval__V_79_79 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 2)));
          MR_Word eval__V_80_80 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 1)));
          MR_Word eval__V_81_81 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 0)));

#line 25 "eval.m"
#line 25 "eval.m"
          switch (MR_tag((MR_Word) eval__HeadVar__3_3)) {
#line 25 "eval.m"
            default: /*NOTREACHED*/ MR_assert(0);
#line 25 "eval.m"
            case (MR_Integer) 0:
#line 25 "eval.m"
              *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 25 "eval.m"
              break;
#line 25 "eval.m"
            case (MR_Integer) 1:
#line 25 "eval.m"
              *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 25 "eval.m"
              break;
#line 25 "eval.m"
            case (MR_Integer) 2:
              {
                MR_Word eval__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__3_3, (MR_Integer) 0)));
                MR_Word eval__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__3_3, (MR_Integer) 1)));
                MR_Word eval__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__3_3, (MR_Integer) 2)));
                MR_Float eval__V_22_22 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__3_3, (MR_Integer) 3)));
                MR_Float eval__V_23_23 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__3_3, (MR_Integer) 4)));
#line 25 "eval.m"
                MR_Word eval__V_24_24;

#line 25 "eval.m"
                {
#line 25 "eval.m"
                  vector____Compare____vector_0_0(&eval__V_24_24, eval__V_81_81, eval__V_19_19);
                }
#line 25 "eval.m"
                eval__succeeded = (eval__V_24_24 == (MR_Integer) 0);
#line 25 "eval.m"
                eval__succeeded = !(eval__succeeded);
#line 25 "eval.m"
                if (eval__succeeded)
#line 25 "eval.m"
                  *eval__HeadVar__1_1 = eval__V_24_24;
#line 25 "eval.m"
                else
#line 25 "eval.m"
                  {
#line 25 "eval.m"
                    MR_Word eval__V_25_25;

#line 25 "eval.m"
                    {
#line 25 "eval.m"
                      vector____Compare____vector_0_0(&eval__V_25_25, eval__V_80_80, eval__V_20_20);
                    }
#line 25 "eval.m"
                    eval__succeeded = (eval__V_25_25 == (MR_Integer) 0);
#line 25 "eval.m"
                    eval__succeeded = !(eval__succeeded);
#line 25 "eval.m"
                    if (eval__succeeded)
#line 25 "eval.m"
                      *eval__HeadVar__1_1 = eval__V_25_25;
#line 25 "eval.m"
                    else
#line 25 "eval.m"
                      {
#line 25 "eval.m"
                        MR_Word eval__V_26_26;

#line 25 "eval.m"
                        {
#line 25 "eval.m"
                          vector____Compare____vector_0_0(&eval__V_26_26, eval__V_79_79, eval__V_21_21);
                        }
#line 25 "eval.m"
                        eval__succeeded = (eval__V_26_26 == (MR_Integer) 0);
#line 25 "eval.m"
                        eval__succeeded = !(eval__succeeded);
#line 25 "eval.m"
                        if (eval__succeeded)
#line 25 "eval.m"
                          *eval__HeadVar__1_1 = eval__V_26_26;
#line 25 "eval.m"
                        else
#line 25 "eval.m"
                          {
#line 25 "eval.m"
                            MR_Word eval__V_27_27;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            eval__succeeded = (eval__V_78_78 < eval__V_22_22);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            if (eval__succeeded)
                              {
                                MR_Word eval__V_88_88 = (MR_Integer) 1;

#line 25 "eval.m"
                                eval__succeeded = (eval__V_88_88 == (MR_Integer) 0);
#line 25 "eval.m"
                                eval__succeeded = !(eval__succeeded);
                                if (eval__succeeded)
                                  {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    eval__V_27_27 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    eval__succeeded = TRUE;
                                  }
                              }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                eval__succeeded = (eval__V_78_78 > eval__V_22_22);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                if (eval__succeeded)
                                  {
                                    MR_Word eval__V_89_89 = (MR_Integer) 2;

#line 25 "eval.m"
                                    eval__succeeded = (eval__V_89_89 == (MR_Integer) 0);
#line 25 "eval.m"
                                    eval__succeeded = !(eval__succeeded);
                                    if (eval__succeeded)
                                      {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        eval__V_27_27 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        eval__succeeded = TRUE;
                                      }
                                  }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                else
                                  {
                                    MR_Word eval__V_90_90 = (MR_Integer) 0;

#line 25 "eval.m"
                                    eval__succeeded = (eval__V_90_90 == (MR_Integer) 0);
#line 25 "eval.m"
                                    eval__succeeded = !(eval__succeeded);
                                    if (eval__succeeded)
                                      {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        eval__V_27_27 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        eval__succeeded = TRUE;
                                      }
                                  }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              }
#line 25 "eval.m"
                            if (eval__succeeded)
#line 25 "eval.m"
                              *eval__HeadVar__1_1 = eval__V_27_27;
#line 25 "eval.m"
                            else
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                eval__succeeded = (eval__V_77_77 < eval__V_23_23);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                if (eval__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    eval__succeeded = (eval__V_77_77 > eval__V_23_23);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    if (eval__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      *eval__HeadVar__1_1 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              }
#line 25 "eval.m"
                          }
#line 25 "eval.m"
                      }
#line 25 "eval.m"
                  }
              }
#line 25 "eval.m"
              break;
#line 25 "eval.m"
          }
        }
#line 25 "eval.m"
        break;
#line 25 "eval.m"
    }
#line 25 "eval.m"
  }
#line 25 "eval.m"
}

#line 25 "eval.m"
bool MR_CALL eval____Unify____light_0_0(
#line 25 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 25 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 25 "eval.m"
{
#line 25 "eval.m"
  {
#line 25 "eval.m"
    bool eval__succeeded;
#line 25 "eval.m"
    MR_Word eval__V_3_3;
#line 25 "eval.m"
    MR_Word eval__V_4_4;
#line 25 "eval.m"
    MR_Word eval__V_5_5;
#line 25 "eval.m"
    MR_Word eval__V_6_6;
#line 25 "eval.m"
    MR_Word eval__V_7_7;
#line 25 "eval.m"
    MR_Word eval__V_8_8;
#line 25 "eval.m"
    MR_Word eval__V_9_9;
#line 25 "eval.m"
    MR_Word eval__V_10_10;
#line 25 "eval.m"
    MR_Word eval__V_11_11;
#line 25 "eval.m"
    MR_Word eval__V_12_12;
#line 25 "eval.m"
    MR_Word eval__V_13_13;
#line 25 "eval.m"
    MR_Float eval__V_14_14;
#line 25 "eval.m"
    MR_Float eval__V_15_15;
#line 25 "eval.m"
    MR_Word eval__V_16_16;
#line 25 "eval.m"
    MR_Word eval__V_17_17;
#line 25 "eval.m"
    MR_Word eval__V_18_18;
#line 25 "eval.m"
    MR_Float eval__V_19_19;
#line 25 "eval.m"
    MR_Float eval__V_20_20;

#line 25 "eval.m"
#line 25 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__1_1)) {
#line 25 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 25 "eval.m"
      case (MR_Integer) 0:
        {
#line 25 "eval.m"
          eval__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 25 "eval.m"
          eval__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 25 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
#line 25 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 25 "eval.m"
            {
#line 25 "eval.m"
              eval__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 25 "eval.m"
              eval__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 25 "eval.m"
            }
          if (eval__succeeded)
            {
              {
                eval__succeeded = vector____Unify____vector_0_0(eval__V_3_3, eval__V_5_5);
              }
              if (eval__succeeded)
                {
                  return eval__succeeded = vector____Unify____vector_0_0(eval__V_4_4, eval__V_6_6);
                }
            }
        }
#line 25 "eval.m"
        break;
#line 25 "eval.m"
      case (MR_Integer) 1:
        {
#line 25 "eval.m"
          eval__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 25 "eval.m"
          eval__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 25 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 25 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 25 "eval.m"
            {
#line 25 "eval.m"
              eval__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 25 "eval.m"
              eval__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 25 "eval.m"
            }
          if (eval__succeeded)
            {
              {
                eval__succeeded = vector____Unify____vector_0_0(eval__V_7_7, eval__V_9_9);
              }
              if (eval__succeeded)
                {
                  return eval__succeeded = vector____Unify____vector_0_0(eval__V_8_8, eval__V_10_10);
                }
            }
        }
#line 25 "eval.m"
        break;
#line 25 "eval.m"
      case (MR_Integer) 2:
        {
#line 25 "eval.m"
          eval__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 25 "eval.m"
          eval__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 25 "eval.m"
          eval__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 2)));
#line 25 "eval.m"
          eval__V_14_14 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 3)));
#line 25 "eval.m"
          eval__V_15_15 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 4)));
#line 25 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 2));
#line 25 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 2)))
#line 25 "eval.m"
            {
#line 25 "eval.m"
              eval__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 25 "eval.m"
              eval__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 25 "eval.m"
              eval__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 2)));
#line 25 "eval.m"
              eval__V_19_19 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 3)));
#line 25 "eval.m"
              eval__V_20_20 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 4)));
#line 25 "eval.m"
            }
          if (eval__succeeded)
            {
              {
                eval__succeeded = vector____Unify____vector_0_0(eval__V_11_11, eval__V_16_16);
              }
              if (eval__succeeded)
                {
                  {
                    eval__succeeded = vector____Unify____vector_0_0(eval__V_12_12, eval__V_17_17);
                  }
                  if (eval__succeeded)
                    {
                      {
                        eval__succeeded = vector____Unify____vector_0_0(eval__V_13_13, eval__V_18_18);
                      }
                      if (eval__succeeded)
                        {
                          eval__succeeded = (eval__V_14_14 == eval__V_19_19);
                          if (eval__succeeded)
                            eval__succeeded = (eval__V_15_15 == eval__V_20_20);
                        }
                    }
                }
            }
        }
#line 25 "eval.m"
        break;
#line 25 "eval.m"
    }
#line 25 "eval.m"
    return eval__succeeded;
#line 25 "eval.m"
  }
#line 25 "eval.m"
}

#line 23 "eval.m"
void MR_CALL eval____Compare____array_0_0(
#line 23 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 23 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 23 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 23 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Array eval__conv1_HeadVar__2_2 = (MR_Array) eval__HeadVar__2_2;
    MR_Array eval__conv2_HeadVar__3_3 = (MR_Array) eval__HeadVar__3_3;
    MR_Word eval__TypeInfo_4_4 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 23 "eval.m"
    {
#line 23 "eval.m"
      mercury__array____Compare____array_1_0(eval__TypeInfo_4_4, eval__HeadVar__1_1, (MR_Array) eval__conv1_HeadVar__2_2, (MR_Array) eval__conv2_HeadVar__3_3);
#line 23 "eval.m"
      return;
    }
  }
#line 23 "eval.m"
}

#line 23 "eval.m"
bool MR_CALL eval____Unify____array_0_0(
#line 23 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 23 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 23 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Array eval__conv1_HeadVar__1_1 = (MR_Array) eval__HeadVar__1_1;
    MR_Array eval__conv2_HeadVar__2_2 = (MR_Array) eval__HeadVar__2_2;
    MR_Word eval__TypeInfo_3_3 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 23 "eval.m"
    {
#line 23 "eval.m"
      eval__succeeded = mercury__array____Unify____array_1_0(eval__TypeInfo_3_3, (MR_Array) eval__conv1_HeadVar__1_1, (MR_Array) eval__conv2_HeadVar__2_2);
    }
    if (eval__succeeded)
      eval__succeeded = TRUE;
    return eval__succeeded;
  }
#line 23 "eval.m"
}

#line 21 "eval.m"
void MR_CALL eval____Compare____color_0_0(
#line 21 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 21 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 21 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 21 "eval.m"
{
#line 21 "eval.m"
  {
#line 21 "eval.m"
    bool eval__succeeded;
#line 21 "eval.m"
    MR_Word eval__conv1_HeadVar__2_2 = (MR_Word) eval__HeadVar__2_2;
#line 21 "eval.m"
    MR_Word eval__conv2_HeadVar__3_3 = (MR_Word) eval__HeadVar__3_3;

#line 21 "eval.m"
    {
#line 21 "eval.m"
      vector____Compare____vector_0_0(eval__HeadVar__1_1, eval__conv1_HeadVar__2_2, eval__conv2_HeadVar__3_3);
#line 21 "eval.m"
      return;
    }
#line 21 "eval.m"
  }
#line 21 "eval.m"
}

#line 21 "eval.m"
bool MR_CALL eval____Unify____color_0_0(
#line 21 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 21 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 21 "eval.m"
{
#line 21 "eval.m"
  {
#line 21 "eval.m"
    bool eval__succeeded;
#line 21 "eval.m"
    MR_Word eval__conv1_HeadVar__1_1 = (MR_Word) eval__HeadVar__1_1;
#line 21 "eval.m"
    MR_Word eval__conv2_HeadVar__2_2 = (MR_Word) eval__HeadVar__2_2;

#line 21 "eval.m"
    {
#line 21 "eval.m"
      eval__succeeded = vector____Unify____vector_0_0(eval__conv1_HeadVar__1_1, eval__conv2_HeadVar__2_2);
    }
#line 21 "eval.m"
    if (eval__succeeded)
#line 21 "eval.m"
      eval__succeeded = TRUE;
#line 21 "eval.m"
    return eval__succeeded;
#line 21 "eval.m"
  }
#line 21 "eval.m"
}

#line 8 "eval.m"
void MR_CALL eval____Compare____value_0_0(
#line 8 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 8 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 8 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 8 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Integer eval__V_4_4;
    MR_Integer eval__V_5_5;

#line 8 "eval.m"
    {
#line 8 "eval.m"
      eval____Index____value_0_0(eval__HeadVar__2_2, &eval__V_4_4);
    }
#line 8 "eval.m"
    {
#line 8 "eval.m"
      eval____Index____value_0_0(eval__HeadVar__3_3, &eval__V_5_5);
    }
#line 8 "eval.m"
    eval__succeeded = (eval__V_4_4 < eval__V_5_5);
#line 8 "eval.m"
    if (eval__succeeded)
#line 8 "eval.m"
      *eval__HeadVar__1_1 = (MR_Integer) 1;
#line 8 "eval.m"
    else
#line 8 "eval.m"
      {
#line 8 "eval.m"
        eval__succeeded = (eval__V_4_4 > eval__V_5_5);
#line 8 "eval.m"
        if (eval__succeeded)
#line 8 "eval.m"
          *eval__HeadVar__1_1 = (MR_Integer) 2;
#line 8 "eval.m"
        else
#line 8 "eval.m"
          {
#line 8 "eval.m"
            MR_Word eval__V_6_6;

#line 8 "eval.m"
#line 8 "eval.m"
            switch (MR_tag((MR_Word) eval__HeadVar__2_2)) {
#line 8 "eval.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 8 "eval.m"
              case (MR_Integer) 3:
#line 8 "eval.m"
#line 8 "eval.m"
                switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0)))) {
#line 8 "eval.m"
                  default: /*NOTREACHED*/ MR_assert(0);
#line 8 "eval.m"
                  case (MR_Integer) 0:
                    {
                      MR_String eval__V_13_13 = ((MR_String) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
                      MR_String eval__V_14_14;
                      MR_Integer eval__Res_7_59;
                      MR_Integer eval__V_64_64;

#line 8 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 0));
#line 8 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 8 "eval.m"
                        eval__V_14_14 = ((MR_String) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
                      if (eval__succeeded)
                        {
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#define MR_PROC_LABEL eval____Compare____value_0_0
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_Integer Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S1;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	MR_String S2;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S1 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__V_13_13
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	S2 = 
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__V_14_14
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
		{
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
Res = strcmp(S1, S2);
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

		;}
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#undef MR_PROC_LABEL
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
	
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
eval__Res_7_59
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
 = Res;
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
#line 102 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
}
#line 53 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__V_64_64 = (MR_Integer) 0;
#line 54 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = (eval__Res_7_59 < eval__V_64_64);
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (eval__succeeded)
#line 56 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            eval__V_6_6 = (MR_Integer) 1;
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            {
#line 59 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              eval__succeeded = (eval__Res_7_59 == (MR_Integer) 0);
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              if (eval__succeeded)
#line 61 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                eval__V_6_6 = (MR_Integer) 0;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              else
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                eval__V_6_6 = (MR_Integer) 2;
#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            }
#line 57 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = TRUE;
                        }
                    }
#line 8 "eval.m"
                    break;
#line 8 "eval.m"
                  case (MR_Integer) 1:
                    {
                      MR_Word eval__V_15_15 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word eval__V_16_16 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 2)));
                      MR_Word eval__V_17_17;
                      MR_Word eval__V_18_18;
#line 8 "eval.m"
                      MR_Word eval__V_19_19;
                      MR_Word eval__TypeInfo_32_32;
                      MR_Word eval__TypeInfo_33_33;

#line 8 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 1));
#line 8 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 8 "eval.m"
                        {
#line 8 "eval.m"
                          eval__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 8 "eval.m"
                          eval__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 2)));
#line 8 "eval.m"
                        }
                      if (eval__succeeded)
                        {
                          eval__TypeInfo_32_32 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
                          eval__TypeInfo_33_33 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
#line 8 "eval.m"
                          {
#line 8 "eval.m"
                            mercury__tree234____Compare____tree234_2_0(eval__TypeInfo_32_32, eval__TypeInfo_33_33, &eval__V_19_19, eval__V_15_15, eval__V_17_17);
                          }
#line 8 "eval.m"
                          eval__succeeded = (eval__V_19_19 == (MR_Integer) 0);
#line 8 "eval.m"
                          eval__succeeded = !(eval__succeeded);
#line 8 "eval.m"
                          if (eval__succeeded)
#line 8 "eval.m"
                            eval__V_6_6 = eval__V_19_19;
#line 8 "eval.m"
                          else
                            {
                              MR_Word eval__TypeInfo_36_36 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);

#line 8 "eval.m"
                              {
#line 8 "eval.m"
                                mercury__list____Compare____list_1_0(eval__TypeInfo_36_36, &eval__V_6_6, eval__V_16_16, eval__V_18_18);
                              }
                            }
#line 8 "eval.m"
                          eval__succeeded = TRUE;
                        }
                    }
#line 8 "eval.m"
                    break;
#line 8 "eval.m"
                  case (MR_Integer) 2:
                    {
                      MR_Array eval__V_20_20 = ((MR_Array) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Array eval__V_21_21;
                      MR_Word eval__TypeInfo_39_39;

#line 8 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 2));
#line 8 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 2)))
#line 8 "eval.m"
                        eval__V_21_21 = ((MR_Array) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
                      if (eval__succeeded)
                        {
                          eval__TypeInfo_39_39 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
#line 8 "eval.m"
                          {
#line 8 "eval.m"
                            mercury__array____Compare____array_1_0(eval__TypeInfo_39_39, &eval__V_6_6, (MR_Array) eval__V_20_20, (MR_Array) eval__V_21_21);
                          }
#line 8 "eval.m"
                          eval__succeeded = TRUE;
                        }
                    }
#line 8 "eval.m"
                    break;
#line 8 "eval.m"
                  case (MR_Integer) 3:
                    {
                      MR_Word eval__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word eval__V_23_23;

#line 8 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 3));
#line 8 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 8 "eval.m"
                        eval__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
                      if (eval__succeeded)
                        {
#line 8 "eval.m"
                          {
#line 8 "eval.m"
                            vector____Compare____vector_0_0(&eval__V_6_6, eval__V_22_22, eval__V_23_23);
                          }
#line 8 "eval.m"
                          eval__succeeded = TRUE;
                        }
                    }
#line 8 "eval.m"
                    break;
#line 8 "eval.m"
                  case (MR_Integer) 4:
                    {
                      MR_Word eval__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word eval__V_25_25;

#line 8 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 4));
#line 8 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 8 "eval.m"
                        eval__V_25_25 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
                      if (eval__succeeded)
                        {
#line 8 "eval.m"
                          {
#line 8 "eval.m"
                            eval____Compare____object_0_0(&eval__V_6_6, eval__V_24_24, eval__V_25_25);
                          }
#line 8 "eval.m"
                          eval__succeeded = TRUE;
                        }
                    }
#line 8 "eval.m"
                    break;
#line 8 "eval.m"
                  case (MR_Integer) 5:
                    {
                      MR_Word eval__V_26_26 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
                      MR_Word eval__V_27_27;

#line 8 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 5));
#line 8 "eval.m"
                      if (((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 0))) == (MR_Integer) 5)))
#line 8 "eval.m"
                        eval__V_27_27 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__3_3, (MR_Integer) 1)));
                      if (eval__succeeded)
                        {
#line 8 "eval.m"
                          {
#line 8 "eval.m"
                            eval____Compare____light_0_0(&eval__V_6_6, eval__V_26_26, eval__V_27_27);
                          }
#line 8 "eval.m"
                          eval__succeeded = TRUE;
                        }
                    }
#line 8 "eval.m"
                    break;
#line 8 "eval.m"
                }
#line 8 "eval.m"
                break;
#line 8 "eval.m"
              case (MR_Integer) 0:
                {
                  MR_Word eval__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Word eval__V_8_8;
                  MR_Integer eval__V_45_45;
                  MR_Integer eval__V_46_46;

#line 8 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 0));
#line 8 "eval.m"
                  if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 0)))
#line 8 "eval.m"
                    eval__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__3_3, (MR_Integer) 0)));
                  if (eval__succeeded)
                    {
                      eval__V_45_45 = (MR_Integer) eval__V_7_7;
                      eval__V_46_46 = (MR_Integer) eval__V_8_8;
#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      eval__succeeded = (eval__V_45_45 < eval__V_46_46);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (eval__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        eval__V_6_6 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = (eval__V_45_45 == eval__V_46_46);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (eval__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            eval__V_6_6 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            eval__V_6_6 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      eval__succeeded = TRUE;
                    }
                }
#line 8 "eval.m"
                break;
#line 8 "eval.m"
              case (MR_Integer) 1:
                {
                  MR_Integer eval__V_9_9 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Integer eval__V_10_10;

#line 8 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 8 "eval.m"
                  if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 8 "eval.m"
                    eval__V_10_10 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
                  if (eval__succeeded)
                    {
#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      eval__succeeded = (eval__V_9_9 < eval__V_10_10);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (eval__succeeded)
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        eval__V_6_6 = (MR_Integer) 1;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = (eval__V_9_9 == eval__V_10_10);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (eval__succeeded)
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            eval__V_6_6 = (MR_Integer) 0;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            eval__V_6_6 = (MR_Integer) 2;
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      eval__succeeded = TRUE;
                    }
                }
#line 8 "eval.m"
                break;
#line 8 "eval.m"
              case (MR_Integer) 2:
                {
                  MR_Float eval__V_11_11 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 0)));
                  MR_Float eval__V_12_12;

#line 8 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 2));
#line 8 "eval.m"
                  if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 2)))
#line 8 "eval.m"
                    eval__V_12_12 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__3_3, (MR_Integer) 0)));
                  if (eval__succeeded)
                    {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      eval__succeeded = (eval__V_11_11 < eval__V_12_12);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      if (eval__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        eval__V_6_6 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          eval__succeeded = (eval__V_11_11 > eval__V_12_12);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          if (eval__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            eval__V_6_6 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            eval__V_6_6 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      eval__succeeded = TRUE;
                    }
                }
#line 8 "eval.m"
                break;
#line 8 "eval.m"
            }
#line 8 "eval.m"
            if (eval__succeeded)
#line 8 "eval.m"
              *eval__HeadVar__1_1 = eval__V_6_6;
#line 8 "eval.m"
            else
#line 8 "eval.m"
              {
#line 8 "eval.m"
                mercury__private_builtin__compare_error_0_p_0();
#line 8 "eval.m"
                return;
              }
#line 8 "eval.m"
          }
#line 8 "eval.m"
      }
  }
#line 8 "eval.m"
}

#line 8 "eval.m"
void MR_CALL eval____Index____value_0_0(
#line 8 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 8 "eval.m"
  MR_Integer * eval__HeadVar__2_2)
#line 8 "eval.m"
{
#line 8 "eval.m"
  {
#line 8 "eval.m"
    bool eval__succeeded;

#line 8 "eval.m"
#line 8 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__1_1)) {
#line 8 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 8 "eval.m"
      case (MR_Integer) 3:
#line 8 "eval.m"
#line 8 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 0)))) {
#line 8 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 8 "eval.m"
          case (MR_Integer) 0:
#line 8 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 3;
#line 8 "eval.m"
            break;
#line 8 "eval.m"
          case (MR_Integer) 1:
#line 8 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 4;
#line 8 "eval.m"
            break;
#line 8 "eval.m"
          case (MR_Integer) 2:
#line 8 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 5;
#line 8 "eval.m"
            break;
#line 8 "eval.m"
          case (MR_Integer) 3:
#line 8 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 6;
#line 8 "eval.m"
            break;
#line 8 "eval.m"
          case (MR_Integer) 4:
#line 8 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 7;
#line 8 "eval.m"
            break;
#line 8 "eval.m"
          case (MR_Integer) 5:
#line 8 "eval.m"
            *eval__HeadVar__2_2 = (MR_Integer) 8;
#line 8 "eval.m"
            break;
#line 8 "eval.m"
        }
#line 8 "eval.m"
        break;
#line 8 "eval.m"
      case (MR_Integer) 0:
#line 8 "eval.m"
        *eval__HeadVar__2_2 = (MR_Integer) 0;
#line 8 "eval.m"
        break;
#line 8 "eval.m"
      case (MR_Integer) 1:
#line 8 "eval.m"
        *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 8 "eval.m"
        break;
#line 8 "eval.m"
      case (MR_Integer) 2:
#line 8 "eval.m"
        *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 8 "eval.m"
        break;
#line 8 "eval.m"
    }
#line 8 "eval.m"
  }
#line 8 "eval.m"
}

#line 8 "eval.m"
bool MR_CALL eval____Unify____value_0_0(
#line 8 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 8 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 8 "eval.m"
{
#line 8 "eval.m"
  {
#line 8 "eval.m"
    bool eval__succeeded;

#line 8 "eval.m"
#line 8 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__1_1)) {
#line 8 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 8 "eval.m"
      case (MR_Integer) 3:
#line 8 "eval.m"
#line 8 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 0)))) {
#line 8 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 8 "eval.m"
          case (MR_Integer) 0:
            {
              MR_String eval__V_9_9 = ((MR_String) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_String eval__V_10_10;

#line 8 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 0));
#line 8 "eval.m"
              if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 8 "eval.m"
                eval__V_10_10 = ((MR_String) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
              if (eval__succeeded)
                eval__succeeded = (strcmp(eval__V_9_9, eval__V_10_10) == 0);
            }
#line 8 "eval.m"
            break;
#line 8 "eval.m"
          case (MR_Integer) 1:
            {
              MR_Word eval__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word eval__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 2)));
              MR_Word eval__V_13_13;
              MR_Word eval__V_14_14;
              MR_Word eval__TypeInfo_26_26;
              MR_Word eval__TypeInfo_27_27;
              MR_Word eval__TypeInfo_30_30;

#line 8 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 1));
#line 8 "eval.m"
              if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 8 "eval.m"
                {
#line 8 "eval.m"
                  eval__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 8 "eval.m"
                  eval__V_14_14 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 2)));
#line 8 "eval.m"
                }
              if (eval__succeeded)
                {
                  eval__TypeInfo_26_26 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
                  eval__TypeInfo_27_27 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
                  {
                    eval__succeeded = mercury__tree234____Unify____tree234_2_0(eval__TypeInfo_26_26, eval__TypeInfo_27_27, eval__V_11_11, eval__V_13_13);
                  }
                  if (eval__succeeded)
                    {
                      eval__TypeInfo_30_30 = (MR_Word) (&gml__gml__type_ctor_info_token_group_0);
                      {
                        return eval__succeeded = mercury__list____Unify____list_1_0(eval__TypeInfo_30_30, eval__V_12_12, eval__V_14_14);
                      }
                    }
                }
            }
#line 8 "eval.m"
            break;
#line 8 "eval.m"
          case (MR_Integer) 2:
            {
              MR_Array eval__V_15_15 = ((MR_Array) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_Array eval__V_16_16;
              MR_Word eval__TypeInfo_23_23;

#line 8 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 2));
#line 8 "eval.m"
              if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 2)))
#line 8 "eval.m"
                eval__V_16_16 = ((MR_Array) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
              if (eval__succeeded)
                {
                  eval__TypeInfo_23_23 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
                  {
                    return eval__succeeded = mercury__array____Unify____array_1_0(eval__TypeInfo_23_23, (MR_Array) eval__V_15_15, (MR_Array) eval__V_16_16);
                  }
                }
            }
#line 8 "eval.m"
            break;
#line 8 "eval.m"
          case (MR_Integer) 3:
            {
              MR_Word eval__V_17_17 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word eval__V_18_18;

#line 8 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 3));
#line 8 "eval.m"
              if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 8 "eval.m"
                eval__V_18_18 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
              if (eval__succeeded)
                {
                  return eval__succeeded = vector____Unify____vector_0_0(eval__V_17_17, eval__V_18_18);
                }
            }
#line 8 "eval.m"
            break;
#line 8 "eval.m"
          case (MR_Integer) 4:
            {
              MR_Word eval__V_19_19 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word eval__V_20_20;

#line 8 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 4));
#line 8 "eval.m"
              if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 8 "eval.m"
                eval__V_20_20 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
              if (eval__succeeded)
                {
                  return eval__succeeded = eval____Unify____object_0_0(eval__V_19_19, eval__V_20_20);
                }
            }
#line 8 "eval.m"
            break;
#line 8 "eval.m"
          case (MR_Integer) 5:
            {
              MR_Word eval__V_21_21 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word eval__V_22_22;

#line 8 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 5));
#line 8 "eval.m"
              if (((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 0))) == (MR_Integer) 5)))
#line 8 "eval.m"
                eval__V_22_22 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__2_2, (MR_Integer) 1)));
              if (eval__succeeded)
                {
                  return eval__succeeded = eval____Unify____light_0_0(eval__V_21_21, eval__V_22_22);
                }
            }
#line 8 "eval.m"
            break;
#line 8 "eval.m"
        }
#line 8 "eval.m"
        break;
#line 8 "eval.m"
      case (MR_Integer) 0:
        {
          MR_Word eval__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word eval__V_4_4;

#line 8 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0));
#line 8 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 0)))
#line 8 "eval.m"
            eval__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__2_2, (MR_Integer) 0)));
          if (eval__succeeded)
            eval__succeeded = (eval__V_3_3 == eval__V_4_4);
        }
#line 8 "eval.m"
        break;
#line 8 "eval.m"
      case (MR_Integer) 1:
        {
          MR_Integer eval__V_5_5 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 0)));
          MR_Integer eval__V_6_6;

#line 8 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 8 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 8 "eval.m"
            eval__V_6_6 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));
          if (eval__succeeded)
            eval__succeeded = (eval__V_5_5 == eval__V_6_6);
        }
#line 8 "eval.m"
        break;
#line 8 "eval.m"
      case (MR_Integer) 2:
        {
          MR_Float eval__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 0)));
          MR_Float eval__V_8_8;

#line 8 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 2));
#line 8 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 2)))
#line 8 "eval.m"
            eval__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__HeadVar__2_2, (MR_Integer) 0)));
          if (eval__succeeded)
            eval__succeeded = (eval__V_7_7 == eval__V_8_8);
        }
#line 8 "eval.m"
        break;
#line 8 "eval.m"
    }
#line 8 "eval.m"
    return eval__succeeded;
#line 8 "eval.m"
  }
#line 8 "eval.m"
}

#line 780 "eval.m"
static void MR_CALL eval__empty_stack_3_p_0(
#line 780 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 780 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 780 "eval.m"
  MR_Word eval__HeadVar__3_3)
#line 780 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Word eval__V_7_7;
    MR_String eval__V_8_8 = (MR_String) "empty stack";
    MR_Word eval__TypeInfo_9_9;

#line 782 "eval.m"
    {
#line 782 "eval.m"
      eval__V_7_7 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 4 * sizeof(MR_Word)), "stack_env_token_exception");
#line 782 "eval.m"
      MR_hl_field(MR_mktag(0), eval__V_7_7, 0) = ((MR_Box) (eval__V_8_8));
#line 782 "eval.m"
      MR_hl_field(MR_mktag(0), eval__V_7_7, 1) = ((MR_Box) (eval__HeadVar__1_1));
#line 782 "eval.m"
      MR_hl_field(MR_mktag(0), eval__V_7_7, 2) = ((MR_Box) (eval__HeadVar__2_2));
#line 782 "eval.m"
      MR_hl_field(MR_mktag(0), eval__V_7_7, 3) = ((MR_Box) (eval__HeadVar__3_3));
#line 782 "eval.m"
    }
    eval__TypeInfo_9_9 = (MR_Word) (&eval__eval__type_ctor_info_stack_env_token_exception_0);
#line 782 "eval.m"
    {
#line 782 "eval.m"
      mercury__exception__throw_1_p_0(eval__TypeInfo_9_9, ((MR_Box) (eval__V_7_7)));
#line 782 "eval.m"
      return;
    }
  }
#line 780 "eval.m"
}

#line 749 "eval.m"
static bool MR_CALL eval__popn_3_p_0(
#line 749 "eval.m"
  MR_Integer eval__HeadVar__1_1,
#line 749 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 749 "eval.m"
  MR_Word * eval__HeadVar__3_3)
#line 749 "eval.m"
{
#line 753 "eval.m"
  {
#line 753 "eval.m"
    /* tailcall optimized into a loop */
#line 753 "eval.m"
  loop_top:;
#line 753 "eval.m"
    {
#line 753 "eval.m"
      bool eval__succeeded;
      MR_Integer eval__V_14_14 = (MR_Integer) 0;

#line 751 "eval.m"
      eval__succeeded = (eval__HeadVar__1_1 <= eval__V_14_14);
#line 753 "eval.m"
      if (eval__succeeded)
#line 752 "eval.m"
        {
#line 752 "eval.m"
          *eval__HeadVar__3_3 = eval__HeadVar__2_2;
#line 752 "eval.m"
          eval__succeeded = TRUE;
#line 752 "eval.m"
        }
#line 753 "eval.m"
      else
        {
          MR_Word eval__Stack1_8;
          MR_Integer eval__V_10_10;
          MR_Integer eval__V_11_11;
#line 746 "eval.m"
          MR_Word eval__V_7_7;

#line 746 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1));
#line 746 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__2_2) == MR_mktag((MR_Integer) 1)))
#line 746 "eval.m"
            {
#line 746 "eval.m"
              eval__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 0)));
#line 746 "eval.m"
              eval__Stack1_8 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__2_2, (MR_Integer) 1)));
#line 746 "eval.m"
            }
          if (eval__succeeded)
            {
#line 755 "eval.m"
              eval__V_11_11 = (MR_Integer) 1;
#line 755 "eval.m"
              eval__V_10_10 = (eval__HeadVar__1_1 - eval__V_11_11);
#line 755 "eval.m"
              {
#line 755 "eval.m"
                /* direct tailcall eliminated */
#line 755 "eval.m"
                {
#line 755 "eval.m"
                  MR_Integer eval__HeadVar__1__tmp_copy_1 = eval__V_10_10;
#line 755 "eval.m"
                  MR_Word eval__HeadVar__2__tmp_copy_2 = eval__Stack1_8;

#line 755 "eval.m"
                  eval__HeadVar__1_1 = eval__HeadVar__1__tmp_copy_1;
#line 755 "eval.m"
                  eval__HeadVar__2_2 = eval__HeadVar__2__tmp_copy_2;
#line 755 "eval.m"
                }
#line 755 "eval.m"
                goto loop_top;
#line 755 "eval.m"
              }
            }
        }
#line 753 "eval.m"
      return eval__succeeded;
#line 753 "eval.m"
    }
#line 753 "eval.m"
  }
#line 749 "eval.m"
}

#line 618 "eval.m"
static void MR_CALL eval__do_extra2_6_p_0(
#line 618 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 618 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 618 "eval.m"
  MR_Word eval__HeadVar__3_3,
#line 618 "eval.m"
  MR_Word * eval__HeadVar__4_4)
#line 618 "eval.m"
{
#line 620 "eval.m"
  {
#line 620 "eval.m"
    bool eval__succeeded;

#line 620 "eval.m"
#line 620 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__1_1)) {
#line 620 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 620 "eval.m"
      case (MR_Integer) 3:
#line 620 "eval.m"
#line 620 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 0)))) {
#line 620 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 620 "eval.m"
          case (MR_Integer) 0:
            {
              MR_Word eval__SurfaceProperties_39 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_Integer eval__Id_43;
              MR_Word eval__V_46_46;
              MR_Word eval__V_47_47;
              MR_Word eval__V_48_48;
              MR_Word eval__V_49_49;
              MR_Word eval__V_50_50;

#line 641 "eval.m"
              {
#line 641 "eval.m"
                eval__next_object_id_3_p_0(&eval__Id_43);
              }
#line 643 "eval.m"
              {
#line 643 "eval.m"
                eval__V_50_50 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "constant"));
#line 643 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_50_50, 0) = ((MR_Box) (eval__SurfaceProperties_39));
#line 643 "eval.m"
              }
#line 643 "eval.m"
              {
#line 643 "eval.m"
                eval__V_48_48 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "plane"));
#line 643 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_48_48, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 1));
#line 643 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_48_48, 1) = ((MR_Box) (eval__V_50_50));
#line 643 "eval.m"
              }
#line 643 "eval.m"
              eval__V_49_49 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 642 "eval.m"
              {
#line 642 "eval.m"
                eval__V_47_47 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 642 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_47_47, 0) = ((MR_Box) (eval__Id_43));
#line 642 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_47_47, 1) = ((MR_Box) (eval__V_48_48));
#line 642 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_47_47, 2) = ((MR_Box) (eval__V_49_49));
#line 642 "eval.m"
              }
#line 642 "eval.m"
              {
#line 642 "eval.m"
                eval__V_46_46 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 642 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_46_46, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 642 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_46_46, 1) = ((MR_Box) (eval__V_47_47));
#line 642 "eval.m"
              }
#line 642 "eval.m"
              {
#line 642 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_46_46, eval__HeadVar__3_3);
              }
            }
#line 620 "eval.m"
            break;
#line 620 "eval.m"
          case (MR_Integer) 1:
            {
              MR_Word eval__SurfaceProperties_51 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_Integer eval__Id_55;
              MR_Word eval__V_58_58;
              MR_Word eval__V_59_59;
              MR_Word eval__V_60_60;
              MR_Word eval__V_61_61;
              MR_Word eval__V_62_62;

#line 647 "eval.m"
              {
#line 647 "eval.m"
                eval__next_object_id_3_p_0(&eval__Id_55);
              }
#line 649 "eval.m"
              {
#line 649 "eval.m"
                eval__V_62_62 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "constant"));
#line 649 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_62_62, 0) = ((MR_Box) (eval__SurfaceProperties_51));
#line 649 "eval.m"
              }
#line 649 "eval.m"
              {
#line 649 "eval.m"
                eval__V_60_60 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "cone"));
#line 649 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_60_60, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 0));
#line 649 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_60_60, 1) = ((MR_Box) (eval__V_62_62));
#line 649 "eval.m"
              }
#line 649 "eval.m"
              eval__V_61_61 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 648 "eval.m"
              {
#line 648 "eval.m"
                eval__V_59_59 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 648 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_59_59, 0) = ((MR_Box) (eval__Id_55));
#line 648 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_59_59, 1) = ((MR_Box) (eval__V_60_60));
#line 648 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_59_59, 2) = ((MR_Box) (eval__V_61_61));
#line 648 "eval.m"
              }
#line 648 "eval.m"
              {
#line 648 "eval.m"
                eval__V_58_58 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 648 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_58_58, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 648 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_58_58, 1) = ((MR_Box) (eval__V_59_59));
#line 648 "eval.m"
              }
#line 648 "eval.m"
              {
#line 648 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_58_58, eval__HeadVar__3_3);
              }
            }
#line 620 "eval.m"
            break;
#line 620 "eval.m"
          case (MR_Integer) 2:
            {
              MR_Word eval__SurfaceProperties_63 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_Integer eval__Id_67;
              MR_Word eval__V_70_70;
              MR_Word eval__V_71_71;
              MR_Word eval__V_72_72;
              MR_Word eval__V_73_73;
              MR_Word eval__V_74_74;

#line 653 "eval.m"
              {
#line 653 "eval.m"
                eval__next_object_id_3_p_0(&eval__Id_67);
              }
#line 655 "eval.m"
              {
#line 655 "eval.m"
                eval__V_74_74 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "constant"));
#line 655 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_74_74, 0) = ((MR_Box) (eval__SurfaceProperties_63));
#line 655 "eval.m"
              }
#line 655 "eval.m"
              {
#line 655 "eval.m"
                eval__V_72_72 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "cube"));
#line 655 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_72_72, 0) = ((MR_Box) (eval__V_74_74));
#line 655 "eval.m"
              }
#line 655 "eval.m"
              eval__V_73_73 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 654 "eval.m"
              {
#line 654 "eval.m"
                eval__V_71_71 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 654 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_71_71, 0) = ((MR_Box) (eval__Id_67));
#line 654 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_71_71, 1) = ((MR_Box) (eval__V_72_72));
#line 654 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_71_71, 2) = ((MR_Box) (eval__V_73_73));
#line 654 "eval.m"
              }
#line 654 "eval.m"
              {
#line 654 "eval.m"
                eval__V_70_70 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 654 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_70_70, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 654 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_70_70, 1) = ((MR_Box) (eval__V_71_71));
#line 654 "eval.m"
              }
#line 654 "eval.m"
              {
#line 654 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_70_70, eval__HeadVar__3_3);
              }
            }
#line 620 "eval.m"
            break;
#line 620 "eval.m"
          case (MR_Integer) 3:
            {
              MR_Word eval__SurfaceProperties_75 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_Integer eval__Id_79;
              MR_Word eval__V_82_82;
              MR_Word eval__V_83_83;
              MR_Word eval__V_84_84;
              MR_Word eval__V_85_85;
              MR_Word eval__V_86_86;

#line 659 "eval.m"
              {
#line 659 "eval.m"
                eval__next_object_id_3_p_0(&eval__Id_79);
              }
#line 661 "eval.m"
              {
#line 661 "eval.m"
                eval__V_86_86 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "constant"));
#line 661 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_86_86, 0) = ((MR_Box) (eval__SurfaceProperties_75));
#line 661 "eval.m"
              }
#line 661 "eval.m"
              {
#line 661 "eval.m"
                eval__V_84_84 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "cylinder"));
#line 661 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_84_84, 0) = ((MR_Box) (eval__V_86_86));
#line 661 "eval.m"
              }
#line 661 "eval.m"
              eval__V_85_85 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 660 "eval.m"
              {
#line 660 "eval.m"
                eval__V_83_83 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 660 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_83_83, 0) = ((MR_Box) (eval__Id_79));
#line 660 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_83_83, 1) = ((MR_Box) (eval__V_84_84));
#line 660 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_83_83, 2) = ((MR_Box) (eval__V_85_85));
#line 660 "eval.m"
              }
#line 660 "eval.m"
              {
#line 660 "eval.m"
                eval__V_82_82 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 660 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_82_82, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 660 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_82_82, 1) = ((MR_Box) (eval__V_83_83));
#line 660 "eval.m"
              }
#line 660 "eval.m"
              {
#line 660 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_82_82, eval__HeadVar__3_3);
              }
            }
#line 620 "eval.m"
            break;
#line 620 "eval.m"
          case (MR_Integer) 4:
            {
              MR_Word eval__Point_87 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word eval__V_92_92;

#line 665 "eval.m"
              {
#line 665 "eval.m"
                eval__V_92_92 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "point"));
#line 665 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_92_92, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 3));
#line 665 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_92_92, 1) = ((MR_Box) (eval__Point_87));
#line 665 "eval.m"
              }
#line 665 "eval.m"
              {
#line 665 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_92_92, eval__HeadVar__3_3);
              }
            }
#line 620 "eval.m"
            break;
#line 620 "eval.m"
          case (MR_Integer) 5:
            {
              MR_Word eval__C1_93 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word eval__C2_94 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 2)));
#line 677 "eval.m"
              MR_Word eval__YesNo_98;
#line 677 "eval.m"
              MR_Word eval__Stack1_99;
              MR_Word eval__V_101_101;

#line 668 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 668 "eval.m"
              if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 668 "eval.m"
                {
#line 668 "eval.m"
                  eval__V_101_101 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 668 "eval.m"
                  eval__Stack1_99 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 668 "eval.m"
                }
              if (eval__succeeded)
                {
#line 668 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_101_101) == MR_mktag((MR_Integer) 0));
#line 668 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_101_101) == MR_mktag((MR_Integer) 0)))
#line 668 "eval.m"
                    eval__YesNo_98 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__V_101_101, (MR_Integer) 0)));
                }
#line 677 "eval.m"
              if (eval__succeeded)
#line 673 "eval.m"
#line 673 "eval.m"
                switch (eval__YesNo_98) {
#line 673 "eval.m"
                  default: /*NOTREACHED*/ MR_assert(0);
#line 673 "eval.m"
                  case (MR_Integer) 0:
#line 675 "eval.m"
                    {
#line 675 "eval.m"
                      *eval__HeadVar__4_4 = eval__push_3_f_0(eval__C2_94, eval__Stack1_99);
                    }
#line 673 "eval.m"
                    break;
#line 673 "eval.m"
                  case (MR_Integer) 1:
#line 672 "eval.m"
                    {
#line 672 "eval.m"
                      *eval__HeadVar__4_4 = eval__push_3_f_0(eval__C1_93, eval__Stack1_99);
                    }
#line 673 "eval.m"
                    break;
#line 673 "eval.m"
                }
#line 677 "eval.m"
              else
#line 678 "eval.m"
                {
#line 678 "eval.m"
                  eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 678 "eval.m"
                  return;
                }
            }
#line 620 "eval.m"
            break;
#line 620 "eval.m"
          case (MR_Integer) 6:
            {
              MR_Word eval__C_7 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 621 "eval.m"
              MR_Word eval__V_11_11;
#line 621 "eval.m"
              void MR_CALL (* eval__func_1)(MR_Box, MR_Box, MR_Box, MR_Box *, MR_Box *, MR_Box, MR_Box *) = ((void MR_CALL (*)(MR_Box, MR_Box, MR_Box, MR_Box *, MR_Box *, MR_Box, MR_Box *)) (MR_hl_field(MR_mktag(0), eval__C_7, (MR_Integer) 1)));
#line 621 "eval.m"
              MR_Box eval__conv4_V_11_11;
#line 621 "eval.m"
              MR_Box eval__conv3_HeadVar__4_4;
#line 621 "eval.m"
              MR_Box eval__conv2_HeadVar__6_6;

#line 621 "eval.m"
              {
#line 621 "eval.m"
                eval__func_1(((MR_Box) eval__C_7), ((MR_Box) (eval__HeadVar__2_2)), ((MR_Box) (eval__HeadVar__3_3)), &eval__conv4_V_11_11, &eval__conv3_HeadVar__4_4, ((MR_Box) ((MR_Integer) 0)), &eval__conv2_HeadVar__6_6);
              }
#line 621 "eval.m"
              eval__V_11_11 = ((MR_Word) eval__conv4_V_11_11);
#line 621 "eval.m"
              *eval__HeadVar__4_4 = ((MR_Word) eval__conv3_HeadVar__4_4);
            }
#line 620 "eval.m"
            break;
#line 620 "eval.m"
        }
#line 620 "eval.m"
        break;
#line 620 "eval.m"
      case (MR_Integer) 0:
        {
#line 625 "eval.m"
          MR_Word eval__Head_17;
#line 623 "eval.m"
          MR_Word eval__Tail_18;

#line 623 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 623 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 623 "eval.m"
            {
#line 623 "eval.m"
              eval__Head_17 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 623 "eval.m"
              eval__Tail_18 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 623 "eval.m"
            }
#line 625 "eval.m"
          if (eval__succeeded)
#line 624 "eval.m"
            {
#line 624 "eval.m"
              *eval__HeadVar__4_4 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 624 "eval.m"
              MR_hl_field(MR_mktag(1), *eval__HeadVar__4_4, 0) = ((MR_Box) (eval__Head_17));
#line 624 "eval.m"
              MR_hl_field(MR_mktag(1), *eval__HeadVar__4_4, 1) = ((MR_Box) (eval__HeadVar__3_3));
#line 624 "eval.m"
            }
#line 625 "eval.m"
          else
#line 626 "eval.m"
            {
#line 626 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 626 "eval.m"
              return;
            }
        }
#line 620 "eval.m"
        break;
#line 620 "eval.m"
      case (MR_Integer) 1:
        {
          MR_Integer eval__N_21 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 631 "eval.m"
          MR_Word eval__Stack1_25;

#line 629 "eval.m"
          {
#line 629 "eval.m"
            eval__succeeded = eval__popn_3_p_0(eval__N_21, eval__HeadVar__3_3, &eval__Stack1_25);
          }
#line 631 "eval.m"
          if (eval__succeeded)
#line 630 "eval.m"
            *eval__HeadVar__4_4 = eval__Stack1_25;
#line 631 "eval.m"
          else
#line 632 "eval.m"
            {
#line 632 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 632 "eval.m"
              return;
            }
        }
#line 620 "eval.m"
        break;
#line 620 "eval.m"
      case (MR_Integer) 2:
        {
          MR_Word eval__SurfaceProperties_27 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 0)));
          MR_Integer eval__Id_31;
          MR_Word eval__V_34_34;
          MR_Word eval__V_35_35;
          MR_Word eval__V_36_36;
          MR_Word eval__V_37_37;
          MR_Word eval__V_38_38;

#line 635 "eval.m"
          {
#line 635 "eval.m"
            eval__next_object_id_3_p_0(&eval__Id_31);
          }
#line 637 "eval.m"
          {
#line 637 "eval.m"
            eval__V_38_38 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "constant"));
#line 637 "eval.m"
            MR_hl_field(MR_mktag(1), eval__V_38_38, 0) = ((MR_Box) (eval__SurfaceProperties_27));
#line 637 "eval.m"
          }
#line 637 "eval.m"
          {
#line 637 "eval.m"
            eval__V_36_36 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "sphere");
#line 637 "eval.m"
            MR_hl_field(MR_mktag(0), eval__V_36_36, 0) = ((MR_Box) (eval__V_38_38));
#line 637 "eval.m"
          }
#line 637 "eval.m"
          eval__V_37_37 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 636 "eval.m"
          {
#line 636 "eval.m"
            eval__V_35_35 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 636 "eval.m"
            MR_hl_field(MR_mktag(0), eval__V_35_35, 0) = ((MR_Box) (eval__Id_31));
#line 636 "eval.m"
            MR_hl_field(MR_mktag(0), eval__V_35_35, 1) = ((MR_Box) (eval__V_36_36));
#line 636 "eval.m"
            MR_hl_field(MR_mktag(0), eval__V_35_35, 2) = ((MR_Box) (eval__V_37_37));
#line 636 "eval.m"
          }
#line 636 "eval.m"
          {
#line 636 "eval.m"
            eval__V_34_34 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 636 "eval.m"
            MR_hl_field(MR_mktag(3), eval__V_34_34, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 636 "eval.m"
            MR_hl_field(MR_mktag(3), eval__V_34_34, 1) = ((MR_Box) (eval__V_35_35));
#line 636 "eval.m"
          }
#line 636 "eval.m"
          {
#line 636 "eval.m"
            *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_34_34, eval__HeadVar__3_3);
          }
        }
#line 620 "eval.m"
        break;
#line 620 "eval.m"
    }
#line 620 "eval.m"
  }
#line 618 "eval.m"
}

#line 610 "eval.m"
static void MR_CALL eval__do_extra_6_p_0(
#line 610 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 610 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 610 "eval.m"
  MR_Word eval__HeadVar__3_3,
#line 610 "eval.m"
  MR_Word * eval__HeadVar__4_4)
#line 610 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Word eval__Extra_11;

#line 604 "eval.m"
#line 604 "eval.m"
{
#line 604 "eval.m"
#define MR_PROC_LABEL eval__do_extra_6_p_0
#line 604 "eval.m"

#line 604 "eval.m"
	MR_Word A;
#line 604 "eval.m"
	MR_Word B;
#line 604 "eval.m"

#line 604 "eval.m"
	A = 
#line 604 "eval.m"
eval__HeadVar__1_1
#line 604 "eval.m"
;
#line 604 "eval.m"
#line 604 "eval.m"
		{
#line 604 "eval.m"
B = A
#line 604 "eval.m"

		;}
#line 604 "eval.m"
#undef MR_PROC_LABEL
#line 604 "eval.m"
#line 604 "eval.m"
	
#line 604 "eval.m"
eval__Extra_11
#line 604 "eval.m"
 = B;
#line 604 "eval.m"
#line 604 "eval.m"
}
#line 613 "eval.m"
    {
#line 613 "eval.m"
      eval__do_extra2_6_p_0(eval__Extra_11, eval__HeadVar__2_2, eval__HeadVar__3_3, eval__HeadVar__4_4);
#line 613 "eval.m"
      return;
    }
  }
#line 610 "eval.m"
}

#line 601 "eval.m"
static void MR_CALL eval__extra_operator_mode_2_p_0(
#line 601 "eval.m"
  MR_Word eval__A_1,
#line 601 "eval.m"
  MR_Word * eval__B_2)
#line 601 "eval.m"
{
#line 604 "eval.m"
  {
#line 604 "eval.m"
    bool eval__succeeded;

#line 604 "eval.m"
#line 604 "eval.m"
{
#line 604 "eval.m"
#define MR_PROC_LABEL eval__extra_operator_mode_2_p_0
#line 604 "eval.m"

#line 604 "eval.m"
	MR_Word A;
#line 604 "eval.m"
	MR_Word B;
#line 604 "eval.m"

#line 604 "eval.m"
	A = 
#line 604 "eval.m"
eval__A_1
#line 604 "eval.m"
;
#line 604 "eval.m"
#line 604 "eval.m"
		{
#line 604 "eval.m"
B = A
#line 604 "eval.m"

		;}
#line 604 "eval.m"
#undef MR_PROC_LABEL
#line 604 "eval.m"
#line 604 "eval.m"
	
#line 604 "eval.m"
*eval__B_2
#line 604 "eval.m"
 = B;
#line 604 "eval.m"
#line 604 "eval.m"
}
#line 604 "eval.m"
  }
#line 601 "eval.m"
}

#line 593 "eval.m"
static void MR_CALL eval__next_object_id_3_p_0(
#line 593 "eval.m"
  MR_Integer * eval__HeadVar__1_1)
#line 593 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Word eval__V_8_8;
    MR_Integer eval__V_9_9;
    MR_Integer eval__V_10_10;
    MR_Word eval__V_11_11 = (MR_Integer) 0;
    MR_Word eval__TypeInfo_12_12 = (MR_Word) (&eval__eval__type_ctor_info_global_object_counter_0);
    MR_Word eval__TypeInfo_13_13 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
    MR_Word eval__TypeInfo_14_14;
    MR_Word eval__TypeInfo_15_15;
#line 596 "eval.m"
    MR_Box eval__conv1_HeadVar__1_1;

#line 596 "eval.m"
    {
#line 596 "eval.m"
      globals__get_4_p_0(eval__TypeInfo_12_12, eval__TypeInfo_13_13, ((MR_Box) (eval__V_11_11)), &eval__conv1_HeadVar__1_1);
    }
#line 596 "eval.m"
    *eval__HeadVar__1_1 = ((MR_Integer) eval__conv1_HeadVar__1_1);
#line 597 "eval.m"
    eval__V_8_8 = (MR_Integer) 0;
#line 597 "eval.m"
    eval__V_10_10 = (MR_Integer) 1;
#line 597 "eval.m"
    eval__V_9_9 = (*eval__HeadVar__1_1 + eval__V_10_10);
    eval__TypeInfo_14_14 = (MR_Word) (&eval__eval__type_ctor_info_global_object_counter_0);
    eval__TypeInfo_15_15 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 597 "eval.m"
    {
#line 597 "eval.m"
      globals__set_4_p_0(eval__TypeInfo_14_14, eval__TypeInfo_15_15, ((MR_Box) (eval__V_8_8)), ((MR_Box) (eval__V_9_9)));
#line 597 "eval.m"
      return;
    }
  }
#line 593 "eval.m"
}

#line 576 "eval.m"
static void MR_CALL eval__renameObject_4_p_0(
#line 576 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 576 "eval.m"
  MR_Word * eval__HeadVar__2_2)
#line 576 "eval.m"
{
#line 579 "eval.m"
  {
#line 579 "eval.m"
    bool eval__succeeded;
#line 579 "eval.m"
    MR_Word eval__BasicObject_6;
#line 579 "eval.m"
    MR_Word eval__L_7;
#line 579 "eval.m"
    MR_Integer eval__Id_8;
#line 579 "eval.m"
    MR_Word eval__Obj0_11;
#line 579 "eval.m"
    MR_Word eval__Trans_12;
#line 579 "eval.m"
    MR_Word eval__Obj_13;
#line 579 "eval.m"
    MR_Word eval__Left0_16;
#line 579 "eval.m"
    MR_Word eval__Right0_17;
#line 579 "eval.m"
    MR_Word eval__Left_18;
#line 579 "eval.m"
    MR_Word eval__Right_19;
#line 579 "eval.m"
    MR_Word eval__Left0_23;
#line 579 "eval.m"
    MR_Word eval__Right0_24;
#line 579 "eval.m"
    MR_Word eval__Left_25;
#line 579 "eval.m"
    MR_Word eval__Right_26;
#line 579 "eval.m"
    MR_Word eval__Left0_30;
#line 579 "eval.m"
    MR_Word eval__Right0_31;
#line 579 "eval.m"
    MR_Word eval__Left_32;
#line 579 "eval.m"
    MR_Word eval__Right_33;

#line 579 "eval.m"
#line 579 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__1_1)) {
#line 579 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 579 "eval.m"
      case (MR_Integer) 3:
#line 579 "eval.m"
#line 579 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 0)))) {
#line 579 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 579 "eval.m"
          case (MR_Integer) 0:
            {
#line 586 "eval.m"
              eval__Left0_23 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 586 "eval.m"
              eval__Right0_24 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 2)));
#line 587 "eval.m"
              {
#line 587 "eval.m"
                eval__renameObject_4_p_0(eval__Left0_23, &eval__Left_25);
              }
#line 588 "eval.m"
              {
#line 588 "eval.m"
                eval__renameObject_4_p_0(eval__Right0_24, &eval__Right_26);
              }
#line 586 "eval.m"
              {
#line 586 "eval.m"
                *eval__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "intersect"));
#line 586 "eval.m"
                MR_hl_field(MR_mktag(3), *eval__HeadVar__2_2, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 0));
#line 586 "eval.m"
                MR_hl_field(MR_mktag(3), *eval__HeadVar__2_2, 1) = ((MR_Box) (eval__Left_25));
#line 586 "eval.m"
                MR_hl_field(MR_mktag(3), *eval__HeadVar__2_2, 2) = ((MR_Box) (eval__Right_26));
#line 586 "eval.m"
              }
            }
#line 579 "eval.m"
            break;
#line 579 "eval.m"
          case (MR_Integer) 1:
            {
#line 589 "eval.m"
              eval__Left0_30 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 589 "eval.m"
              eval__Right0_31 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 2)));
#line 590 "eval.m"
              {
#line 590 "eval.m"
                eval__renameObject_4_p_0(eval__Left0_30, &eval__Left_32);
              }
#line 591 "eval.m"
              {
#line 591 "eval.m"
                eval__renameObject_4_p_0(eval__Right0_31, &eval__Right_33);
              }
#line 589 "eval.m"
              {
#line 589 "eval.m"
                *eval__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "difference"));
#line 589 "eval.m"
                MR_hl_field(MR_mktag(3), *eval__HeadVar__2_2, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 1));
#line 589 "eval.m"
                MR_hl_field(MR_mktag(3), *eval__HeadVar__2_2, 1) = ((MR_Box) (eval__Left_32));
#line 589 "eval.m"
                MR_hl_field(MR_mktag(3), *eval__HeadVar__2_2, 2) = ((MR_Box) (eval__Right_33));
#line 589 "eval.m"
              }
            }
#line 579 "eval.m"
            break;
#line 579 "eval.m"
        }
#line 579 "eval.m"
        break;
#line 579 "eval.m"
      case (MR_Integer) 0:
        {
#line 579 "eval.m"
          MR_Integer eval__V_5_5 = ((MR_Integer) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 0)));

#line 579 "eval.m"
          eval__BasicObject_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 579 "eval.m"
          eval__L_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 2)));
#line 580 "eval.m"
          {
#line 580 "eval.m"
            eval__next_object_id_3_p_0(&eval__Id_8);
          }
#line 579 "eval.m"
          {
#line 579 "eval.m"
            *eval__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 579 "eval.m"
            MR_hl_field(MR_mktag(0), *eval__HeadVar__2_2, 0) = ((MR_Box) (eval__Id_8));
#line 579 "eval.m"
            MR_hl_field(MR_mktag(0), *eval__HeadVar__2_2, 1) = ((MR_Box) (eval__BasicObject_6));
#line 579 "eval.m"
            MR_hl_field(MR_mktag(0), *eval__HeadVar__2_2, 2) = ((MR_Box) (eval__L_7));
#line 579 "eval.m"
          }
        }
#line 579 "eval.m"
        break;
#line 579 "eval.m"
      case (MR_Integer) 1:
        {
#line 581 "eval.m"
          eval__Obj0_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 581 "eval.m"
          eval__Trans_12 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 582 "eval.m"
          {
#line 582 "eval.m"
            eval__renameObject_4_p_0(eval__Obj0_11, &eval__Obj_13);
          }
#line 581 "eval.m"
          {
#line 581 "eval.m"
            *eval__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "transform"));
#line 581 "eval.m"
            MR_hl_field(MR_mktag(1), *eval__HeadVar__2_2, 0) = ((MR_Box) (eval__Obj_13));
#line 581 "eval.m"
            MR_hl_field(MR_mktag(1), *eval__HeadVar__2_2, 1) = ((MR_Box) (eval__Trans_12));
#line 581 "eval.m"
          }
        }
#line 579 "eval.m"
        break;
#line 579 "eval.m"
      case (MR_Integer) 2:
        {
#line 583 "eval.m"
          eval__Left0_16 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 583 "eval.m"
          eval__Right0_17 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 584 "eval.m"
          {
#line 584 "eval.m"
            eval__renameObject_4_p_0(eval__Left0_16, &eval__Left_18);
          }
#line 585 "eval.m"
          {
#line 585 "eval.m"
            eval__renameObject_4_p_0(eval__Right0_17, &eval__Right_19);
          }
#line 583 "eval.m"
          {
#line 583 "eval.m"
            *eval__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "union"));
#line 583 "eval.m"
            MR_hl_field(MR_mktag(2), *eval__HeadVar__2_2, 0) = ((MR_Box) (eval__Left_18));
#line 583 "eval.m"
            MR_hl_field(MR_mktag(2), *eval__HeadVar__2_2, 1) = ((MR_Box) (eval__Right_19));
#line 583 "eval.m"
          }
        }
#line 579 "eval.m"
        break;
#line 579 "eval.m"
    }
#line 579 "eval.m"
  }
#line 576 "eval.m"
}
#line 543 "eval.m"
static /* final */ const MR_Box eval__const_9_0_1_V_591_591[1] = {
		((MR_Box) ((MR_Integer) 45))};
#line 549 "eval.m"
static /* final */ const MR_Box eval__const_9_0_2_V_605_605[1] = {
		((MR_Box) ((MR_Integer) 46))};

#line 218 "eval.m"
static void MR_CALL eval__do_op_6_p_0(
#line 218 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 218 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 218 "eval.m"
  MR_Word eval__HeadVar__3_3,
#line 218 "eval.m"
  MR_Word * eval__HeadVar__4_4)
#line 218 "eval.m"
{
#line 221 "eval.m"
  {
#line 221 "eval.m"
    bool eval__succeeded;

#line 221 "eval.m"
#line 221 "eval.m"
    switch (eval__HeadVar__1_1) {
#line 221 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 221 "eval.m"
      case (MR_Integer) 0:
        {
#line 224 "eval.m"
          MR_Float eval__N_10;
#line 224 "eval.m"
          MR_Word eval__Stack1_11;
          MR_Word eval__V_13_13;

#line 222 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 222 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 222 "eval.m"
            {
#line 222 "eval.m"
              eval__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 222 "eval.m"
              eval__Stack1_11 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 222 "eval.m"
            }
          if (eval__succeeded)
            {
#line 222 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_13_13) == MR_mktag((MR_Integer) 2));
#line 222 "eval.m"
              if ((MR_tag((MR_Word) eval__V_13_13) == MR_mktag((MR_Integer) 2)))
#line 222 "eval.m"
                eval__N_10 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_13_13, (MR_Integer) 0)));
            }
#line 224 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_14_14;
              MR_Float eval__V_15_15;

#line 223 "eval.m"
              {
#line 223 "eval.m"
                eval__V_15_15 = op__op_acos_2_f_0(eval__N_10);
              }
#line 223 "eval.m"
              {
#line 223 "eval.m"
                eval__V_14_14 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 223 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_14_14, 0) = MR_box_float(eval__V_15_15);
#line 223 "eval.m"
              }
#line 223 "eval.m"
              {
#line 223 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_14_14, eval__Stack1_11);
              }
            }
#line 224 "eval.m"
          else
#line 225 "eval.m"
            {
#line 225 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 225 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 1:
        {
#line 230 "eval.m"
          MR_Integer eval__N2_19;
#line 230 "eval.m"
          MR_Integer eval__N1_20;
#line 230 "eval.m"
          MR_Word eval__Stack1_21;
          MR_Word eval__V_23_23;
          MR_Word eval__V_24_24;
          MR_Word eval__V_25_25;

#line 228 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 228 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 228 "eval.m"
            {
#line 228 "eval.m"
              eval__V_23_23 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 228 "eval.m"
              eval__V_24_24 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 228 "eval.m"
            }
          if (eval__succeeded)
            {
#line 228 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_23_23) == MR_mktag((MR_Integer) 1));
#line 228 "eval.m"
              if ((MR_tag((MR_Word) eval__V_23_23) == MR_mktag((MR_Integer) 1)))
#line 228 "eval.m"
                eval__N2_19 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_23_23, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 228 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_24_24) == MR_mktag((MR_Integer) 1));
#line 228 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_24_24) == MR_mktag((MR_Integer) 1)))
#line 228 "eval.m"
                    {
#line 228 "eval.m"
                      eval__V_25_25 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_24_24, (MR_Integer) 0)));
#line 228 "eval.m"
                      eval__Stack1_21 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_24_24, (MR_Integer) 1)));
#line 228 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 228 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_25_25) == MR_mktag((MR_Integer) 1));
#line 228 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_25_25) == MR_mktag((MR_Integer) 1)))
#line 228 "eval.m"
                        eval__N1_20 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_25_25, (MR_Integer) 0)));
                    }
                }
            }
#line 230 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_26_26;
              MR_Integer eval__V_27_27;

#line 229 "eval.m"
              {
#line 229 "eval.m"
                eval__V_27_27 = op__op_addi_3_f_0(eval__N1_20, eval__N2_19);
              }
#line 229 "eval.m"
              {
#line 229 "eval.m"
                eval__V_26_26 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "int"));
#line 229 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_26_26, 0) = ((MR_Box) (eval__V_27_27));
#line 229 "eval.m"
              }
#line 229 "eval.m"
              {
#line 229 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_26_26, eval__Stack1_21);
              }
            }
#line 230 "eval.m"
          else
#line 231 "eval.m"
            {
#line 231 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 231 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 2:
        {
#line 236 "eval.m"
          MR_Float eval__N2_31;
#line 236 "eval.m"
          MR_Float eval__N1_32;
#line 236 "eval.m"
          MR_Word eval__Stack1_33;
          MR_Word eval__V_35_35;
          MR_Word eval__V_36_36;
          MR_Word eval__V_37_37;

#line 234 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 234 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 234 "eval.m"
            {
#line 234 "eval.m"
              eval__V_35_35 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 234 "eval.m"
              eval__V_36_36 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 234 "eval.m"
            }
          if (eval__succeeded)
            {
#line 234 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_35_35) == MR_mktag((MR_Integer) 2));
#line 234 "eval.m"
              if ((MR_tag((MR_Word) eval__V_35_35) == MR_mktag((MR_Integer) 2)))
#line 234 "eval.m"
                eval__N2_31 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_35_35, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 234 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_36_36) == MR_mktag((MR_Integer) 1));
#line 234 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_36_36) == MR_mktag((MR_Integer) 1)))
#line 234 "eval.m"
                    {
#line 234 "eval.m"
                      eval__V_37_37 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_36_36, (MR_Integer) 0)));
#line 234 "eval.m"
                      eval__Stack1_33 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_36_36, (MR_Integer) 1)));
#line 234 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 234 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_37_37) == MR_mktag((MR_Integer) 2));
#line 234 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_37_37) == MR_mktag((MR_Integer) 2)))
#line 234 "eval.m"
                        eval__N1_32 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_37_37, (MR_Integer) 0)));
                    }
                }
            }
#line 236 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_38_38;
              MR_Float eval__V_39_39;

#line 235 "eval.m"
              {
#line 235 "eval.m"
                eval__V_39_39 = op__op_addf_3_f_0(eval__N1_32, eval__N2_31);
              }
#line 235 "eval.m"
              {
#line 235 "eval.m"
                eval__V_38_38 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 235 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_38_38, 0) = MR_box_float(eval__V_39_39);
#line 235 "eval.m"
              }
#line 235 "eval.m"
              {
#line 235 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_38_38, eval__Stack1_33);
              }
            }
#line 236 "eval.m"
          else
#line 237 "eval.m"
            {
#line 237 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 237 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 3:
#line 243 "eval.m"
        {
#line 243 "eval.m"
          MR_Word eval__ClosureEnv_43;
#line 243 "eval.m"
          MR_Word eval__ClosureCode_44;
#line 243 "eval.m"
          MR_Word eval__Stack1_45;
          MR_Word eval__V_49_49;

#line 240 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 240 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 240 "eval.m"
            {
#line 240 "eval.m"
              eval__V_49_49 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 240 "eval.m"
              eval__Stack1_45 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 240 "eval.m"
            }
          if (eval__succeeded)
            {
#line 240 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_49_49) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_49_49, (MR_Integer) 0))) == (MR_Integer) 1));
#line 240 "eval.m"
              if (((MR_tag((MR_Word) eval__V_49_49) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_49_49, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 240 "eval.m"
                {
#line 240 "eval.m"
                  eval__ClosureEnv_43 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_49_49, (MR_Integer) 1)));
#line 240 "eval.m"
                  eval__ClosureCode_44 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_49_49, (MR_Integer) 2)));
#line 240 "eval.m"
                }
            }
#line 243 "eval.m"
          if (eval__succeeded)
#line 241 "eval.m"
            {
#line 241 "eval.m"
              MR_Word eval___ResultEnv_46;

#line 241 "eval.m"
              {
#line 241 "eval.m"
                eval__interpret_7_p_0(eval__ClosureCode_44, eval__ClosureEnv_43, eval__Stack1_45, &eval___ResultEnv_46, eval__HeadVar__4_4);
              }
#line 241 "eval.m"
            }
#line 243 "eval.m"
          else
#line 243 "eval.m"
            {
#line 243 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 243 "eval.m"
              return;
            }
#line 243 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 4:
        {
#line 249 "eval.m"
          MR_Float eval__N_53;
#line 249 "eval.m"
          MR_Word eval__Stack1_54;
          MR_Word eval__V_56_56;

#line 247 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 247 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 247 "eval.m"
            {
#line 247 "eval.m"
              eval__V_56_56 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 247 "eval.m"
              eval__Stack1_54 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 247 "eval.m"
            }
          if (eval__succeeded)
            {
#line 247 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_56_56) == MR_mktag((MR_Integer) 2));
#line 247 "eval.m"
              if ((MR_tag((MR_Word) eval__V_56_56) == MR_mktag((MR_Integer) 2)))
#line 247 "eval.m"
                eval__N_53 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_56_56, (MR_Integer) 0)));
            }
#line 249 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_57_57;
              MR_Float eval__V_58_58;

#line 248 "eval.m"
              {
#line 248 "eval.m"
                eval__V_58_58 = op__op_asin_2_f_0(eval__N_53);
              }
#line 248 "eval.m"
              {
#line 248 "eval.m"
                eval__V_57_57 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 248 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_57_57, 0) = MR_box_float(eval__V_58_58);
#line 248 "eval.m"
              }
#line 248 "eval.m"
              {
#line 248 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_57_57, eval__Stack1_54);
              }
            }
#line 249 "eval.m"
          else
#line 250 "eval.m"
            {
#line 250 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 250 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 5:
        {
#line 255 "eval.m"
          MR_Float eval__N_62;
#line 255 "eval.m"
          MR_Word eval__Stack1_63;
          MR_Word eval__V_65_65;

#line 253 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 253 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 253 "eval.m"
            {
#line 253 "eval.m"
              eval__V_65_65 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 253 "eval.m"
              eval__Stack1_63 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 253 "eval.m"
            }
          if (eval__succeeded)
            {
#line 253 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_65_65) == MR_mktag((MR_Integer) 2));
#line 253 "eval.m"
              if ((MR_tag((MR_Word) eval__V_65_65) == MR_mktag((MR_Integer) 2)))
#line 253 "eval.m"
                eval__N_62 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_65_65, (MR_Integer) 0)));
            }
#line 255 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_66_66;
              MR_Float eval__V_67_67;

#line 254 "eval.m"
              {
#line 254 "eval.m"
                eval__V_67_67 = op__op_clampf_2_f_0(eval__N_62);
              }
#line 254 "eval.m"
              {
#line 254 "eval.m"
                eval__V_66_66 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 254 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_66_66, 0) = MR_box_float(eval__V_67_67);
#line 254 "eval.m"
              }
#line 254 "eval.m"
              {
#line 254 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_66_66, eval__Stack1_63);
              }
            }
#line 255 "eval.m"
          else
#line 256 "eval.m"
            {
#line 256 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 256 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 6:
#line 265 "eval.m"
        {
#line 265 "eval.m"
          MR_Word eval__CEnv_71;
#line 265 "eval.m"
          MR_Word eval__CCode_72;
#line 265 "eval.m"
          MR_Word eval__Stack1_73;
          MR_Word eval__V_77_77;

#line 259 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 259 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 259 "eval.m"
            {
#line 259 "eval.m"
              eval__V_77_77 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 259 "eval.m"
              eval__Stack1_73 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 259 "eval.m"
            }
          if (eval__succeeded)
            {
#line 259 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_77_77) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_77_77, (MR_Integer) 0))) == (MR_Integer) 1));
#line 259 "eval.m"
              if (((MR_tag((MR_Word) eval__V_77_77) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_77_77, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 259 "eval.m"
                {
#line 259 "eval.m"
                  eval__CEnv_71 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_77_77, (MR_Integer) 1)));
#line 259 "eval.m"
                  eval__CCode_72 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_77_77, (MR_Integer) 2)));
#line 259 "eval.m"
                }
            }
#line 265 "eval.m"
          if (eval__succeeded)
            {
              MR_Integer eval__Id_74;
              MR_Word eval__V_78_78;
              MR_Word eval__V_79_79;
              MR_Word eval__V_80_80;
              MR_Word eval__V_81_81;
              MR_Word eval__V_82_82;

#line 260 "eval.m"
              {
#line 260 "eval.m"
                eval__next_object_id_3_p_0(&eval__Id_74);
              }
#line 262 "eval.m"
              {
#line 262 "eval.m"
                eval__V_82_82 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "surface");
#line 262 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_82_82, 0) = ((MR_Box) (eval__CEnv_71));
#line 262 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_82_82, 1) = ((MR_Box) (eval__CCode_72));
#line 262 "eval.m"
              }
#line 262 "eval.m"
              {
#line 262 "eval.m"
                eval__V_80_80 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "cone"));
#line 262 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_80_80, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 0));
#line 262 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_80_80, 1) = ((MR_Box) (eval__V_82_82));
#line 262 "eval.m"
              }
#line 262 "eval.m"
              eval__V_81_81 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 261 "eval.m"
              {
#line 261 "eval.m"
                eval__V_79_79 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 261 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_79_79, 0) = ((MR_Box) (eval__Id_74));
#line 261 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_79_79, 1) = ((MR_Box) (eval__V_80_80));
#line 261 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_79_79, 2) = ((MR_Box) (eval__V_81_81));
#line 261 "eval.m"
              }
#line 261 "eval.m"
              {
#line 261 "eval.m"
                eval__V_78_78 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 261 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_78_78, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 261 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_78_78, 1) = ((MR_Box) (eval__V_79_79));
#line 261 "eval.m"
              }
#line 261 "eval.m"
              {
#line 261 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_78_78, eval__Stack1_73);
              }
            }
#line 265 "eval.m"
          else
#line 265 "eval.m"
            {
#line 265 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 265 "eval.m"
              return;
            }
#line 265 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 7:
        {
#line 271 "eval.m"
          MR_Float eval__N_86;
#line 271 "eval.m"
          MR_Word eval__Stack1_87;
          MR_Word eval__V_89_89;

#line 269 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 269 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 269 "eval.m"
            {
#line 269 "eval.m"
              eval__V_89_89 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 269 "eval.m"
              eval__Stack1_87 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 269 "eval.m"
            }
          if (eval__succeeded)
            {
#line 269 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_89_89) == MR_mktag((MR_Integer) 2));
#line 269 "eval.m"
              if ((MR_tag((MR_Word) eval__V_89_89) == MR_mktag((MR_Integer) 2)))
#line 269 "eval.m"
                eval__N_86 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_89_89, (MR_Integer) 0)));
            }
#line 271 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_90_90;
              MR_Float eval__V_91_91;

#line 270 "eval.m"
              {
#line 270 "eval.m"
                eval__V_91_91 = op__op_cos_2_f_0(eval__N_86);
              }
#line 270 "eval.m"
              {
#line 270 "eval.m"
                eval__V_90_90 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 270 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_90_90, 0) = MR_box_float(eval__V_91_91);
#line 270 "eval.m"
              }
#line 270 "eval.m"
              {
#line 270 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_90_90, eval__Stack1_87);
              }
            }
#line 271 "eval.m"
          else
#line 272 "eval.m"
            {
#line 272 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 272 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 8:
#line 281 "eval.m"
        {
#line 281 "eval.m"
          MR_Word eval__CEnv_95;
#line 281 "eval.m"
          MR_Word eval__CCode_96;
#line 281 "eval.m"
          MR_Word eval__Stack1_97;
          MR_Word eval__V_101_101;

#line 275 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 275 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 275 "eval.m"
            {
#line 275 "eval.m"
              eval__V_101_101 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 275 "eval.m"
              eval__Stack1_97 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 275 "eval.m"
            }
          if (eval__succeeded)
            {
#line 275 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_101_101) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_101_101, (MR_Integer) 0))) == (MR_Integer) 1));
#line 275 "eval.m"
              if (((MR_tag((MR_Word) eval__V_101_101) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_101_101, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 275 "eval.m"
                {
#line 275 "eval.m"
                  eval__CEnv_95 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_101_101, (MR_Integer) 1)));
#line 275 "eval.m"
                  eval__CCode_96 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_101_101, (MR_Integer) 2)));
#line 275 "eval.m"
                }
            }
#line 281 "eval.m"
          if (eval__succeeded)
            {
              MR_Integer eval__Id_98;
              MR_Word eval__V_102_102;
              MR_Word eval__V_103_103;
              MR_Word eval__V_104_104;
              MR_Word eval__V_105_105;
              MR_Word eval__V_106_106;

#line 276 "eval.m"
              {
#line 276 "eval.m"
                eval__next_object_id_3_p_0(&eval__Id_98);
              }
#line 278 "eval.m"
              {
#line 278 "eval.m"
                eval__V_106_106 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "surface");
#line 278 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_106_106, 0) = ((MR_Box) (eval__CEnv_95));
#line 278 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_106_106, 1) = ((MR_Box) (eval__CCode_96));
#line 278 "eval.m"
              }
#line 278 "eval.m"
              {
#line 278 "eval.m"
                eval__V_104_104 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "cube"));
#line 278 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_104_104, 0) = ((MR_Box) (eval__V_106_106));
#line 278 "eval.m"
              }
#line 278 "eval.m"
              eval__V_105_105 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 277 "eval.m"
              {
#line 277 "eval.m"
                eval__V_103_103 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 277 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_103_103, 0) = ((MR_Box) (eval__Id_98));
#line 277 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_103_103, 1) = ((MR_Box) (eval__V_104_104));
#line 277 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_103_103, 2) = ((MR_Box) (eval__V_105_105));
#line 277 "eval.m"
              }
#line 277 "eval.m"
              {
#line 277 "eval.m"
                eval__V_102_102 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 277 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_102_102, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 277 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_102_102, 1) = ((MR_Box) (eval__V_103_103));
#line 277 "eval.m"
              }
#line 277 "eval.m"
              {
#line 277 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_102_102, eval__Stack1_97);
              }
            }
#line 281 "eval.m"
          else
#line 281 "eval.m"
            {
#line 281 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 281 "eval.m"
              return;
            }
#line 281 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 9:
#line 291 "eval.m"
        {
#line 291 "eval.m"
          MR_Word eval__CEnv_110;
#line 291 "eval.m"
          MR_Word eval__CCode_111;
#line 291 "eval.m"
          MR_Word eval__Stack1_112;
          MR_Word eval__V_116_116;

#line 285 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 285 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 285 "eval.m"
            {
#line 285 "eval.m"
              eval__V_116_116 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 285 "eval.m"
              eval__Stack1_112 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 285 "eval.m"
            }
          if (eval__succeeded)
            {
#line 285 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_116_116) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_116_116, (MR_Integer) 0))) == (MR_Integer) 1));
#line 285 "eval.m"
              if (((MR_tag((MR_Word) eval__V_116_116) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_116_116, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 285 "eval.m"
                {
#line 285 "eval.m"
                  eval__CEnv_110 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_116_116, (MR_Integer) 1)));
#line 285 "eval.m"
                  eval__CCode_111 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_116_116, (MR_Integer) 2)));
#line 285 "eval.m"
                }
            }
#line 291 "eval.m"
          if (eval__succeeded)
            {
              MR_Integer eval__Id_113;
              MR_Word eval__V_117_117;
              MR_Word eval__V_118_118;
              MR_Word eval__V_119_119;
              MR_Word eval__V_120_120;
              MR_Word eval__V_121_121;

#line 286 "eval.m"
              {
#line 286 "eval.m"
                eval__next_object_id_3_p_0(&eval__Id_113);
              }
#line 288 "eval.m"
              {
#line 288 "eval.m"
                eval__V_121_121 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "surface");
#line 288 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_121_121, 0) = ((MR_Box) (eval__CEnv_110));
#line 288 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_121_121, 1) = ((MR_Box) (eval__CCode_111));
#line 288 "eval.m"
              }
#line 288 "eval.m"
              {
#line 288 "eval.m"
                eval__V_119_119 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "cylinder"));
#line 288 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_119_119, 0) = ((MR_Box) (eval__V_121_121));
#line 288 "eval.m"
              }
#line 288 "eval.m"
              eval__V_120_120 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 287 "eval.m"
              {
#line 287 "eval.m"
                eval__V_118_118 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 287 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_118_118, 0) = ((MR_Box) (eval__Id_113));
#line 287 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_118_118, 1) = ((MR_Box) (eval__V_119_119));
#line 287 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_118_118, 2) = ((MR_Box) (eval__V_120_120));
#line 287 "eval.m"
              }
#line 287 "eval.m"
              {
#line 287 "eval.m"
                eval__V_117_117 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 287 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_117_117, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 287 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_117_117, 1) = ((MR_Box) (eval__V_118_118));
#line 287 "eval.m"
              }
#line 287 "eval.m"
              {
#line 287 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_117_117, eval__Stack1_112);
              }
            }
#line 291 "eval.m"
          else
#line 291 "eval.m"
            {
#line 291 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 291 "eval.m"
              return;
            }
#line 291 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 10:
        {
#line 297 "eval.m"
          MR_Word eval__O2_125;
#line 297 "eval.m"
          MR_Word eval__O1_126;
#line 297 "eval.m"
          MR_Word eval__Stack1_127;
          MR_Word eval__V_129_129;
          MR_Word eval__V_130_130;
          MR_Word eval__V_131_131;

#line 295 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 295 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 295 "eval.m"
            {
#line 295 "eval.m"
              eval__V_129_129 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 295 "eval.m"
              eval__V_130_130 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 295 "eval.m"
            }
          if (eval__succeeded)
            {
#line 295 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_129_129) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_129_129, (MR_Integer) 0))) == (MR_Integer) 4));
#line 295 "eval.m"
              if (((MR_tag((MR_Word) eval__V_129_129) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_129_129, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 295 "eval.m"
                eval__O2_125 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_129_129, (MR_Integer) 1)));
              if (eval__succeeded)
                {
#line 295 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_130_130) == MR_mktag((MR_Integer) 1));
#line 295 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_130_130) == MR_mktag((MR_Integer) 1)))
#line 295 "eval.m"
                    {
#line 295 "eval.m"
                      eval__V_131_131 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_130_130, (MR_Integer) 0)));
#line 295 "eval.m"
                      eval__Stack1_127 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_130_130, (MR_Integer) 1)));
#line 295 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 295 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__V_131_131) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_131_131, (MR_Integer) 0))) == (MR_Integer) 4));
#line 295 "eval.m"
                      if (((MR_tag((MR_Word) eval__V_131_131) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_131_131, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 295 "eval.m"
                        eval__O1_126 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_131_131, (MR_Integer) 1)));
                    }
                }
            }
#line 297 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_132_132;
              MR_Word eval__V_133_133;

#line 296 "eval.m"
              {
#line 296 "eval.m"
                eval__V_133_133 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "difference"));
#line 296 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_133_133, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 1));
#line 296 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_133_133, 1) = ((MR_Box) (eval__O1_126));
#line 296 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_133_133, 2) = ((MR_Box) (eval__O2_125));
#line 296 "eval.m"
              }
#line 296 "eval.m"
              {
#line 296 "eval.m"
                eval__V_132_132 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 296 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_132_132, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 296 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_132_132, 1) = ((MR_Box) (eval__V_133_133));
#line 296 "eval.m"
              }
#line 296 "eval.m"
              {
#line 296 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_132_132, eval__Stack1_127);
              }
            }
#line 297 "eval.m"
          else
#line 298 "eval.m"
            {
#line 298 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 298 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 11:
        {
#line 303 "eval.m"
          MR_Integer eval__N2_137;
#line 303 "eval.m"
          MR_Integer eval__N1_138;
#line 303 "eval.m"
          MR_Word eval__Stack1_139;
          MR_Word eval__V_141_141;
          MR_Word eval__V_142_142;
          MR_Word eval__V_143_143;

#line 301 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 301 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 301 "eval.m"
            {
#line 301 "eval.m"
              eval__V_141_141 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 301 "eval.m"
              eval__V_142_142 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 301 "eval.m"
            }
          if (eval__succeeded)
            {
#line 301 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_141_141) == MR_mktag((MR_Integer) 1));
#line 301 "eval.m"
              if ((MR_tag((MR_Word) eval__V_141_141) == MR_mktag((MR_Integer) 1)))
#line 301 "eval.m"
                eval__N2_137 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_141_141, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 301 "eval.m"
                  eval__succeeded = (eval__N2_137 == (MR_Integer) 0);
#line 301 "eval.m"
                  eval__succeeded = !(eval__succeeded);
                  if (eval__succeeded)
                    {
#line 301 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_142_142) == MR_mktag((MR_Integer) 1));
#line 301 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_142_142) == MR_mktag((MR_Integer) 1)))
#line 301 "eval.m"
                        {
#line 301 "eval.m"
                          eval__V_143_143 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_142_142, (MR_Integer) 0)));
#line 301 "eval.m"
                          eval__Stack1_139 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_142_142, (MR_Integer) 1)));
#line 301 "eval.m"
                        }
                      if (eval__succeeded)
                        {
#line 301 "eval.m"
                          eval__succeeded = (MR_tag((MR_Word) eval__V_143_143) == MR_mktag((MR_Integer) 1));
#line 301 "eval.m"
                          if ((MR_tag((MR_Word) eval__V_143_143) == MR_mktag((MR_Integer) 1)))
#line 301 "eval.m"
                            eval__N1_138 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_143_143, (MR_Integer) 0)));
                        }
                    }
                }
            }
#line 303 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_144_144;
              MR_Integer eval__V_145_145;

#line 302 "eval.m"
              {
#line 302 "eval.m"
                eval__V_145_145 = op__op_divi_3_f_0(eval__N1_138, eval__N2_137);
              }
#line 302 "eval.m"
              {
#line 302 "eval.m"
                eval__V_144_144 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "int"));
#line 302 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_144_144, 0) = ((MR_Box) (eval__V_145_145));
#line 302 "eval.m"
              }
#line 302 "eval.m"
              {
#line 302 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_144_144, eval__Stack1_139);
              }
            }
#line 303 "eval.m"
          else
#line 304 "eval.m"
            {
#line 304 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 304 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 12:
        {
#line 309 "eval.m"
          MR_Float eval__N2_149;
#line 309 "eval.m"
          MR_Float eval__N1_150;
#line 309 "eval.m"
          MR_Word eval__Stack1_151;
          MR_Word eval__V_153_153;
          MR_Word eval__V_154_154;
          MR_Word eval__V_155_155;

#line 307 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 307 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 307 "eval.m"
            {
#line 307 "eval.m"
              eval__V_153_153 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 307 "eval.m"
              eval__V_154_154 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 307 "eval.m"
            }
          if (eval__succeeded)
            {
#line 307 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_153_153) == MR_mktag((MR_Integer) 2));
#line 307 "eval.m"
              if ((MR_tag((MR_Word) eval__V_153_153) == MR_mktag((MR_Integer) 2)))
#line 307 "eval.m"
                eval__N2_149 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_153_153, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 307 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_154_154) == MR_mktag((MR_Integer) 1));
#line 307 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_154_154) == MR_mktag((MR_Integer) 1)))
#line 307 "eval.m"
                    {
#line 307 "eval.m"
                      eval__V_155_155 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_154_154, (MR_Integer) 0)));
#line 307 "eval.m"
                      eval__Stack1_151 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_154_154, (MR_Integer) 1)));
#line 307 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 307 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_155_155) == MR_mktag((MR_Integer) 2));
#line 307 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_155_155) == MR_mktag((MR_Integer) 2)))
#line 307 "eval.m"
                        eval__N1_150 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_155_155, (MR_Integer) 0)));
                    }
                }
            }
#line 309 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_156_156;
              MR_Float eval__V_157_157;

#line 308 "eval.m"
              {
#line 308 "eval.m"
                eval__V_157_157 = op__op_divf_3_f_0(eval__N1_150, eval__N2_149);
              }
#line 308 "eval.m"
              {
#line 308 "eval.m"
                eval__V_156_156 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 308 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_156_156, 0) = MR_box_float(eval__V_157_157);
#line 308 "eval.m"
              }
#line 308 "eval.m"
              {
#line 308 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_156_156, eval__Stack1_151);
              }
            }
#line 309 "eval.m"
          else
#line 310 "eval.m"
            {
#line 310 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 310 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 13:
        {
#line 315 "eval.m"
          MR_Integer eval__N2_161;
#line 315 "eval.m"
          MR_Integer eval__N1_162;
#line 315 "eval.m"
          MR_Word eval__Stack1_163;
          MR_Word eval__V_165_165;
          MR_Word eval__V_166_166;
          MR_Word eval__V_167_167;

#line 313 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 313 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 313 "eval.m"
            {
#line 313 "eval.m"
              eval__V_165_165 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 313 "eval.m"
              eval__V_166_166 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 313 "eval.m"
            }
          if (eval__succeeded)
            {
#line 313 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_165_165) == MR_mktag((MR_Integer) 1));
#line 313 "eval.m"
              if ((MR_tag((MR_Word) eval__V_165_165) == MR_mktag((MR_Integer) 1)))
#line 313 "eval.m"
                eval__N2_161 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_165_165, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 313 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_166_166) == MR_mktag((MR_Integer) 1));
#line 313 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_166_166) == MR_mktag((MR_Integer) 1)))
#line 313 "eval.m"
                    {
#line 313 "eval.m"
                      eval__V_167_167 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_166_166, (MR_Integer) 0)));
#line 313 "eval.m"
                      eval__Stack1_163 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_166_166, (MR_Integer) 1)));
#line 313 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 313 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_167_167) == MR_mktag((MR_Integer) 1));
#line 313 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_167_167) == MR_mktag((MR_Integer) 1)))
#line 313 "eval.m"
                        eval__N1_162 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_167_167, (MR_Integer) 0)));
                    }
                }
            }
#line 315 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_168_168;
              MR_Word eval__V_169_169;

#line 314 "eval.m"
              {
#line 314 "eval.m"
                eval__V_169_169 = op__op_eqi_3_f_0(eval__N1_162, eval__N2_161);
              }
#line 314 "eval.m"
              {
#line 314 "eval.m"
                eval__V_168_168 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "boolean");
#line 314 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_168_168, 0) = ((MR_Box) (eval__V_169_169));
#line 314 "eval.m"
              }
#line 314 "eval.m"
              {
#line 314 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_168_168, eval__Stack1_163);
              }
            }
#line 315 "eval.m"
          else
#line 316 "eval.m"
            {
#line 316 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 316 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 14:
        {
#line 321 "eval.m"
          MR_Float eval__N2_173;
#line 321 "eval.m"
          MR_Float eval__N1_174;
#line 321 "eval.m"
          MR_Word eval__Stack1_175;
          MR_Word eval__V_177_177;
          MR_Word eval__V_178_178;
          MR_Word eval__V_179_179;

#line 319 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 319 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 319 "eval.m"
            {
#line 319 "eval.m"
              eval__V_177_177 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 319 "eval.m"
              eval__V_178_178 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 319 "eval.m"
            }
          if (eval__succeeded)
            {
#line 319 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_177_177) == MR_mktag((MR_Integer) 2));
#line 319 "eval.m"
              if ((MR_tag((MR_Word) eval__V_177_177) == MR_mktag((MR_Integer) 2)))
#line 319 "eval.m"
                eval__N2_173 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_177_177, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 319 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_178_178) == MR_mktag((MR_Integer) 1));
#line 319 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_178_178) == MR_mktag((MR_Integer) 1)))
#line 319 "eval.m"
                    {
#line 319 "eval.m"
                      eval__V_179_179 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_178_178, (MR_Integer) 0)));
#line 319 "eval.m"
                      eval__Stack1_175 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_178_178, (MR_Integer) 1)));
#line 319 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 319 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_179_179) == MR_mktag((MR_Integer) 2));
#line 319 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_179_179) == MR_mktag((MR_Integer) 2)))
#line 319 "eval.m"
                        eval__N1_174 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_179_179, (MR_Integer) 0)));
                    }
                }
            }
#line 321 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_180_180;
              MR_Word eval__V_181_181;

#line 320 "eval.m"
              {
#line 320 "eval.m"
                eval__V_181_181 = op__op_eqf_3_f_0(eval__N1_174, eval__N2_173);
              }
#line 320 "eval.m"
              {
#line 320 "eval.m"
                eval__V_180_180 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "boolean");
#line 320 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_180_180, 0) = ((MR_Box) (eval__V_181_181));
#line 320 "eval.m"
              }
#line 320 "eval.m"
              {
#line 320 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_180_180, eval__Stack1_175);
              }
            }
#line 321 "eval.m"
          else
#line 322 "eval.m"
            {
#line 322 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 322 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 15:
        {
#line 327 "eval.m"
          MR_Float eval__N_185;
#line 327 "eval.m"
          MR_Word eval__Stack1_186;
          MR_Word eval__V_188_188;

#line 325 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 325 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 325 "eval.m"
            {
#line 325 "eval.m"
              eval__V_188_188 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 325 "eval.m"
              eval__Stack1_186 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 325 "eval.m"
            }
          if (eval__succeeded)
            {
#line 325 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_188_188) == MR_mktag((MR_Integer) 2));
#line 325 "eval.m"
              if ((MR_tag((MR_Word) eval__V_188_188) == MR_mktag((MR_Integer) 2)))
#line 325 "eval.m"
                eval__N_185 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_188_188, (MR_Integer) 0)));
            }
#line 327 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_189_189;
              MR_Integer eval__V_190_190;

#line 326 "eval.m"
              {
#line 326 "eval.m"
                eval__V_190_190 = op__op_floor_2_f_0(eval__N_185);
              }
#line 326 "eval.m"
              {
#line 326 "eval.m"
                eval__V_189_189 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "int"));
#line 326 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_189_189, 0) = ((MR_Box) (eval__V_190_190));
#line 326 "eval.m"
              }
#line 326 "eval.m"
              {
#line 326 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_189_189, eval__Stack1_186);
              }
            }
#line 327 "eval.m"
          else
#line 328 "eval.m"
            {
#line 328 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 328 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 16:
        {
#line 333 "eval.m"
          MR_Float eval__N_194;
#line 333 "eval.m"
          MR_Word eval__Stack1_195;
          MR_Word eval__V_197_197;

#line 331 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 331 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 331 "eval.m"
            {
#line 331 "eval.m"
              eval__V_197_197 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 331 "eval.m"
              eval__Stack1_195 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 331 "eval.m"
            }
          if (eval__succeeded)
            {
#line 331 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_197_197) == MR_mktag((MR_Integer) 2));
#line 331 "eval.m"
              if ((MR_tag((MR_Word) eval__V_197_197) == MR_mktag((MR_Integer) 2)))
#line 331 "eval.m"
                eval__N_194 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_197_197, (MR_Integer) 0)));
            }
#line 333 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_198_198;
              MR_Float eval__V_199_199;

#line 332 "eval.m"
              {
#line 332 "eval.m"
                eval__V_199_199 = op__op_frac_2_f_0(eval__N_194);
              }
#line 332 "eval.m"
              {
#line 332 "eval.m"
                eval__V_198_198 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 332 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_198_198, 0) = MR_box_float(eval__V_199_199);
#line 332 "eval.m"
              }
#line 332 "eval.m"
              {
#line 332 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_198_198, eval__Stack1_195);
              }
            }
#line 333 "eval.m"
          else
#line 334 "eval.m"
            {
#line 334 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 334 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 17:
        {
#line 340 "eval.m"
          MR_Integer eval__I_203;
#line 340 "eval.m"
          MR_Array eval__A_204;
#line 340 "eval.m"
          MR_Word eval__Stack1_205;
          MR_Word eval__V_208_208;
          MR_Word eval__V_209_209;
          MR_Word eval__V_210_210;
          MR_Word eval__V_658_658;

#line 337 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 337 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 337 "eval.m"
            {
#line 337 "eval.m"
              eval__V_208_208 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 337 "eval.m"
              eval__V_209_209 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 337 "eval.m"
            }
          if (eval__succeeded)
            {
#line 337 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_208_208) == MR_mktag((MR_Integer) 1));
#line 337 "eval.m"
              if ((MR_tag((MR_Word) eval__V_208_208) == MR_mktag((MR_Integer) 1)))
#line 337 "eval.m"
                eval__I_203 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_208_208, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 337 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_209_209) == MR_mktag((MR_Integer) 1));
#line 337 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_209_209) == MR_mktag((MR_Integer) 1)))
#line 337 "eval.m"
                    {
#line 337 "eval.m"
                      eval__V_210_210 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_209_209, (MR_Integer) 0)));
#line 337 "eval.m"
                      eval__Stack1_205 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_209_209, (MR_Integer) 1)));
#line 337 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 337 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__V_210_210) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_210_210, (MR_Integer) 0))) == (MR_Integer) 2));
#line 337 "eval.m"
                      if (((MR_tag((MR_Word) eval__V_210_210) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_210_210, (MR_Integer) 0))) == (MR_Integer) 2)))
#line 337 "eval.m"
                        eval__A_204 = ((MR_Array) (MR_hl_field(MR_mktag(3), eval__V_210_210, (MR_Integer) 1)));
                      if (eval__succeeded)
                        {
                          eval__V_658_658 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
#line 337 "eval.m"
                          {
#line 337 "eval.m"
                            eval__succeeded = mercury__array__in_bounds_2_p_1(eval__V_658_658, (MR_Array) eval__A_204, eval__I_203);
                          }
                        }
                    }
                }
            }
#line 340 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__Val_206;
              MR_Word eval__TypeInfo_656_656 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
#line 338 "eval.m"
              MR_Box eval__conv1_Val_206;

#line 338 "eval.m"
              {
#line 338 "eval.m"
                mercury__array__lookup_3_p_1(eval__TypeInfo_656_656, (MR_Array) eval__A_204, eval__I_203, &eval__conv1_Val_206);
              }
#line 338 "eval.m"
              eval__Val_206 = ((MR_Word) eval__conv1_Val_206);
#line 339 "eval.m"
              {
#line 339 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__Val_206, eval__Stack1_205);
              }
            }
#line 340 "eval.m"
          else
#line 341 "eval.m"
            {
#line 341 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 341 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 18:
        {
#line 346 "eval.m"
          MR_Float eval__X_214;
#line 346 "eval.m"
          MR_Word eval__Stack1_217;
          MR_Word eval__V_219_219;
          MR_Word eval__V_220_220;
#line 344 "eval.m"
          MR_Float eval___Y_215;
#line 344 "eval.m"
          MR_Float eval___Z_216;

#line 344 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 344 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 344 "eval.m"
            {
#line 344 "eval.m"
              eval__V_219_219 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 344 "eval.m"
              eval__Stack1_217 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 344 "eval.m"
            }
          if (eval__succeeded)
            {
#line 344 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_219_219) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_219_219, (MR_Integer) 0))) == (MR_Integer) 3));
#line 344 "eval.m"
              if (((MR_tag((MR_Word) eval__V_219_219) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_219_219, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 344 "eval.m"
                eval__V_220_220 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_219_219, (MR_Integer) 1)));
              if (eval__succeeded)
                {
#line 344 "eval.m"
                  eval__X_214 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_220_220, (MR_Integer) 0)));
#line 344 "eval.m"
                  eval___Y_215 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_220_220, (MR_Integer) 1)));
#line 344 "eval.m"
                  eval___Z_216 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_220_220, (MR_Integer) 2)));
#line 344 "eval.m"
                  eval__succeeded = TRUE;
                }
            }
#line 346 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_221_221;

#line 345 "eval.m"
              {
#line 345 "eval.m"
                eval__V_221_221 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 345 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_221_221, 0) = MR_box_float(eval__X_214);
#line 345 "eval.m"
              }
#line 345 "eval.m"
              {
#line 345 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_221_221, eval__Stack1_217);
              }
            }
#line 346 "eval.m"
          else
#line 347 "eval.m"
            {
#line 347 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 347 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 19:
        {
#line 352 "eval.m"
          MR_Float eval__Y_226;
#line 352 "eval.m"
          MR_Word eval__Stack1_228;
          MR_Word eval__V_230_230;
          MR_Word eval__V_231_231;
#line 350 "eval.m"
          MR_Float eval___X_225;
#line 350 "eval.m"
          MR_Float eval___Z_227;

#line 350 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 350 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 350 "eval.m"
            {
#line 350 "eval.m"
              eval__V_230_230 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 350 "eval.m"
              eval__Stack1_228 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 350 "eval.m"
            }
          if (eval__succeeded)
            {
#line 350 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_230_230) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_230_230, (MR_Integer) 0))) == (MR_Integer) 3));
#line 350 "eval.m"
              if (((MR_tag((MR_Word) eval__V_230_230) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_230_230, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 350 "eval.m"
                eval__V_231_231 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_230_230, (MR_Integer) 1)));
              if (eval__succeeded)
                {
#line 350 "eval.m"
                  eval___X_225 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_231_231, (MR_Integer) 0)));
#line 350 "eval.m"
                  eval__Y_226 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_231_231, (MR_Integer) 1)));
#line 350 "eval.m"
                  eval___Z_227 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_231_231, (MR_Integer) 2)));
#line 350 "eval.m"
                  eval__succeeded = TRUE;
                }
            }
#line 352 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_232_232;

#line 351 "eval.m"
              {
#line 351 "eval.m"
                eval__V_232_232 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 351 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_232_232, 0) = MR_box_float(eval__Y_226);
#line 351 "eval.m"
              }
#line 351 "eval.m"
              {
#line 351 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_232_232, eval__Stack1_228);
              }
            }
#line 352 "eval.m"
          else
#line 353 "eval.m"
            {
#line 353 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 353 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 20:
        {
#line 358 "eval.m"
          MR_Float eval__Z_238;
#line 358 "eval.m"
          MR_Word eval__Stack1_239;
          MR_Word eval__V_241_241;
          MR_Word eval__V_242_242;
#line 356 "eval.m"
          MR_Float eval___X_236;
#line 356 "eval.m"
          MR_Float eval___Y_237;

#line 356 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 356 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 356 "eval.m"
            {
#line 356 "eval.m"
              eval__V_241_241 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 356 "eval.m"
              eval__Stack1_239 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 356 "eval.m"
            }
          if (eval__succeeded)
            {
#line 356 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_241_241) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_241_241, (MR_Integer) 0))) == (MR_Integer) 3));
#line 356 "eval.m"
              if (((MR_tag((MR_Word) eval__V_241_241) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_241_241, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 356 "eval.m"
                eval__V_242_242 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_241_241, (MR_Integer) 1)));
              if (eval__succeeded)
                {
#line 356 "eval.m"
                  eval___X_236 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_242_242, (MR_Integer) 0)));
#line 356 "eval.m"
                  eval___Y_237 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_242_242, (MR_Integer) 1)));
#line 356 "eval.m"
                  eval__Z_238 = MR_unbox_float((MR_hl_field(MR_mktag(0), eval__V_242_242, (MR_Integer) 2)));
#line 356 "eval.m"
                  eval__succeeded = TRUE;
                }
            }
#line 358 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_243_243;

#line 357 "eval.m"
              {
#line 357 "eval.m"
                eval__V_243_243 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 357 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_243_243, 0) = MR_box_float(eval__Z_238);
#line 357 "eval.m"
              }
#line 357 "eval.m"
              {
#line 357 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_243_243, eval__Stack1_239);
              }
            }
#line 358 "eval.m"
          else
#line 359 "eval.m"
            {
#line 359 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 359 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 21:
#line 371 "eval.m"
        {
#line 371 "eval.m"
          MR_Word eval__CE2_247;
#line 371 "eval.m"
          MR_Word eval__CC2_248;
#line 371 "eval.m"
          MR_Word eval__CE1_249;
#line 371 "eval.m"
          MR_Word eval__CC1_250;
#line 371 "eval.m"
          MR_Word eval__YesNo_251;
#line 371 "eval.m"
          MR_Word eval__Stack1_252;
          MR_Word eval__V_257_257;
          MR_Word eval__V_258_258;
          MR_Word eval__V_259_259;
          MR_Word eval__V_260_260;
          MR_Word eval__V_261_261;

#line 362 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 362 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 362 "eval.m"
            {
#line 362 "eval.m"
              eval__V_257_257 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 362 "eval.m"
              eval__V_258_258 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 362 "eval.m"
            }
          if (eval__succeeded)
            {
#line 362 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_257_257) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_257_257, (MR_Integer) 0))) == (MR_Integer) 1));
#line 362 "eval.m"
              if (((MR_tag((MR_Word) eval__V_257_257) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_257_257, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 362 "eval.m"
                {
#line 362 "eval.m"
                  eval__CE2_247 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_257_257, (MR_Integer) 1)));
#line 362 "eval.m"
                  eval__CC2_248 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_257_257, (MR_Integer) 2)));
#line 362 "eval.m"
                }
              if (eval__succeeded)
                {
#line 362 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_258_258) == MR_mktag((MR_Integer) 1));
#line 362 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_258_258) == MR_mktag((MR_Integer) 1)))
#line 362 "eval.m"
                    {
#line 362 "eval.m"
                      eval__V_259_259 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_258_258, (MR_Integer) 0)));
#line 362 "eval.m"
                      eval__V_260_260 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_258_258, (MR_Integer) 1)));
#line 362 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 362 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__V_259_259) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_259_259, (MR_Integer) 0))) == (MR_Integer) 1));
#line 362 "eval.m"
                      if (((MR_tag((MR_Word) eval__V_259_259) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_259_259, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 362 "eval.m"
                        {
#line 362 "eval.m"
                          eval__CE1_249 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_259_259, (MR_Integer) 1)));
#line 362 "eval.m"
                          eval__CC1_250 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_259_259, (MR_Integer) 2)));
#line 362 "eval.m"
                        }
                      if (eval__succeeded)
                        {
#line 362 "eval.m"
                          eval__succeeded = (MR_tag((MR_Word) eval__V_260_260) == MR_mktag((MR_Integer) 1));
#line 362 "eval.m"
                          if ((MR_tag((MR_Word) eval__V_260_260) == MR_mktag((MR_Integer) 1)))
#line 362 "eval.m"
                            {
#line 362 "eval.m"
                              eval__V_261_261 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_260_260, (MR_Integer) 0)));
#line 362 "eval.m"
                              eval__Stack1_252 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_260_260, (MR_Integer) 1)));
#line 362 "eval.m"
                            }
                          if (eval__succeeded)
                            {
#line 363 "eval.m"
                              eval__succeeded = (MR_tag((MR_Word) eval__V_261_261) == MR_mktag((MR_Integer) 0));
#line 363 "eval.m"
                              if ((MR_tag((MR_Word) eval__V_261_261) == MR_mktag((MR_Integer) 0)))
#line 363 "eval.m"
                                eval__YesNo_251 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__V_261_261, (MR_Integer) 0)));
                            }
                        }
                    }
                }
            }
#line 371 "eval.m"
          if (eval__succeeded)
#line 367 "eval.m"
#line 367 "eval.m"
            switch (eval__YesNo_251) {
#line 367 "eval.m"
              default: /*NOTREACHED*/ MR_assert(0);
#line 367 "eval.m"
              case (MR_Integer) 0:
#line 369 "eval.m"
                {
#line 369 "eval.m"
                  MR_Word eval___ResultEnv_262;

#line 369 "eval.m"
                  {
#line 369 "eval.m"
                    eval__interpret_7_p_0(eval__CC2_248, eval__CE2_247, eval__Stack1_252, &eval___ResultEnv_262, eval__HeadVar__4_4);
                  }
#line 369 "eval.m"
                }
#line 367 "eval.m"
                break;
#line 367 "eval.m"
              case (MR_Integer) 1:
#line 366 "eval.m"
                {
#line 366 "eval.m"
                  MR_Word eval___ResultEnv_253;

#line 366 "eval.m"
                  {
#line 366 "eval.m"
                    eval__interpret_7_p_0(eval__CC1_250, eval__CE1_249, eval__Stack1_252, &eval___ResultEnv_253, eval__HeadVar__4_4);
                  }
#line 366 "eval.m"
                }
#line 367 "eval.m"
                break;
#line 367 "eval.m"
            }
#line 371 "eval.m"
          else
#line 371 "eval.m"
            {
#line 371 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 371 "eval.m"
              return;
            }
#line 371 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 22:
        {
#line 377 "eval.m"
          MR_Word eval__O2_267;
#line 377 "eval.m"
          MR_Word eval__O1_268;
#line 377 "eval.m"
          MR_Word eval__Stack1_269;
          MR_Word eval__V_271_271;
          MR_Word eval__V_272_272;
          MR_Word eval__V_273_273;

#line 375 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 375 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 375 "eval.m"
            {
#line 375 "eval.m"
              eval__V_271_271 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 375 "eval.m"
              eval__V_272_272 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 375 "eval.m"
            }
          if (eval__succeeded)
            {
#line 375 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_271_271) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_271_271, (MR_Integer) 0))) == (MR_Integer) 4));
#line 375 "eval.m"
              if (((MR_tag((MR_Word) eval__V_271_271) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_271_271, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 375 "eval.m"
                eval__O2_267 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_271_271, (MR_Integer) 1)));
              if (eval__succeeded)
                {
#line 375 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_272_272) == MR_mktag((MR_Integer) 1));
#line 375 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_272_272) == MR_mktag((MR_Integer) 1)))
#line 375 "eval.m"
                    {
#line 375 "eval.m"
                      eval__V_273_273 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_272_272, (MR_Integer) 0)));
#line 375 "eval.m"
                      eval__Stack1_269 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_272_272, (MR_Integer) 1)));
#line 375 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 375 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__V_273_273) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_273_273, (MR_Integer) 0))) == (MR_Integer) 4));
#line 375 "eval.m"
                      if (((MR_tag((MR_Word) eval__V_273_273) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_273_273, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 375 "eval.m"
                        eval__O1_268 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_273_273, (MR_Integer) 1)));
                    }
                }
            }
#line 377 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_274_274;
              MR_Word eval__V_275_275;

#line 376 "eval.m"
              {
#line 376 "eval.m"
                eval__V_275_275 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "intersect"));
#line 376 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_275_275, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 0));
#line 376 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_275_275, 1) = ((MR_Box) (eval__O1_268));
#line 376 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_275_275, 2) = ((MR_Box) (eval__O2_267));
#line 376 "eval.m"
              }
#line 376 "eval.m"
              {
#line 376 "eval.m"
                eval__V_274_274 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 376 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_274_274, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 376 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_274_274, 1) = ((MR_Box) (eval__V_275_275));
#line 376 "eval.m"
              }
#line 376 "eval.m"
              {
#line 376 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_274_274, eval__Stack1_269);
              }
            }
#line 377 "eval.m"
          else
#line 378 "eval.m"
            {
#line 378 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 378 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 23:
        {
#line 384 "eval.m"
          MR_Array eval__A_279;
#line 384 "eval.m"
          MR_Word eval__Stack1_280;
          MR_Word eval__V_283_283;

#line 381 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 381 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 381 "eval.m"
            {
#line 381 "eval.m"
              eval__V_283_283 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 381 "eval.m"
              eval__Stack1_280 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 381 "eval.m"
            }
          if (eval__succeeded)
            {
#line 381 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_283_283) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_283_283, (MR_Integer) 0))) == (MR_Integer) 2));
#line 381 "eval.m"
              if (((MR_tag((MR_Word) eval__V_283_283) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_283_283, (MR_Integer) 0))) == (MR_Integer) 2)))
#line 381 "eval.m"
                eval__A_279 = ((MR_Array) (MR_hl_field(MR_mktag(3), eval__V_283_283, (MR_Integer) 1)));
            }
#line 384 "eval.m"
          if (eval__succeeded)
            {
              MR_Integer eval__Size_281;
              MR_Word eval__V_284_284;
              MR_Word eval__TypeInfo_657_657 = (MR_Word) (&eval__eval__type_ctor_info_value_0);

#line 382 "eval.m"
              {
#line 382 "eval.m"
                mercury__array__size_2_p_1(eval__TypeInfo_657_657, (MR_Array) eval__A_279, &eval__Size_281);
              }
#line 383 "eval.m"
              {
#line 383 "eval.m"
                eval__V_284_284 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "int"));
#line 383 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_284_284, 0) = ((MR_Box) (eval__Size_281));
#line 383 "eval.m"
              }
#line 383 "eval.m"
              {
#line 383 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_284_284, eval__Stack1_280);
              }
            }
#line 384 "eval.m"
          else
#line 385 "eval.m"
            {
#line 385 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 385 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 24:
        {
#line 390 "eval.m"
          MR_Integer eval__N2_288;
#line 390 "eval.m"
          MR_Integer eval__N1_289;
#line 390 "eval.m"
          MR_Word eval__Stack1_290;
          MR_Word eval__V_292_292;
          MR_Word eval__V_293_293;
          MR_Word eval__V_294_294;

#line 388 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 388 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 388 "eval.m"
            {
#line 388 "eval.m"
              eval__V_292_292 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 388 "eval.m"
              eval__V_293_293 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 388 "eval.m"
            }
          if (eval__succeeded)
            {
#line 388 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_292_292) == MR_mktag((MR_Integer) 1));
#line 388 "eval.m"
              if ((MR_tag((MR_Word) eval__V_292_292) == MR_mktag((MR_Integer) 1)))
#line 388 "eval.m"
                eval__N2_288 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_292_292, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 388 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_293_293) == MR_mktag((MR_Integer) 1));
#line 388 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_293_293) == MR_mktag((MR_Integer) 1)))
#line 388 "eval.m"
                    {
#line 388 "eval.m"
                      eval__V_294_294 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_293_293, (MR_Integer) 0)));
#line 388 "eval.m"
                      eval__Stack1_290 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_293_293, (MR_Integer) 1)));
#line 388 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 388 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_294_294) == MR_mktag((MR_Integer) 1));
#line 388 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_294_294) == MR_mktag((MR_Integer) 1)))
#line 388 "eval.m"
                        eval__N1_289 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_294_294, (MR_Integer) 0)));
                    }
                }
            }
#line 390 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_295_295;
              MR_Word eval__V_296_296;

#line 389 "eval.m"
              {
#line 389 "eval.m"
                eval__V_296_296 = op__op_lessi_3_f_0(eval__N1_289, eval__N2_288);
              }
#line 389 "eval.m"
              {
#line 389 "eval.m"
                eval__V_295_295 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "boolean");
#line 389 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_295_295, 0) = ((MR_Box) (eval__V_296_296));
#line 389 "eval.m"
              }
#line 389 "eval.m"
              {
#line 389 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_295_295, eval__Stack1_290);
              }
            }
#line 390 "eval.m"
          else
#line 391 "eval.m"
            {
#line 391 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 391 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 25:
        {
#line 396 "eval.m"
          MR_Float eval__N2_300;
#line 396 "eval.m"
          MR_Float eval__N1_301;
#line 396 "eval.m"
          MR_Word eval__Stack1_302;
          MR_Word eval__V_304_304;
          MR_Word eval__V_305_305;
          MR_Word eval__V_306_306;

#line 394 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 394 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 394 "eval.m"
            {
#line 394 "eval.m"
              eval__V_304_304 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 394 "eval.m"
              eval__V_305_305 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 394 "eval.m"
            }
          if (eval__succeeded)
            {
#line 394 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_304_304) == MR_mktag((MR_Integer) 2));
#line 394 "eval.m"
              if ((MR_tag((MR_Word) eval__V_304_304) == MR_mktag((MR_Integer) 2)))
#line 394 "eval.m"
                eval__N2_300 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_304_304, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 394 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_305_305) == MR_mktag((MR_Integer) 1));
#line 394 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_305_305) == MR_mktag((MR_Integer) 1)))
#line 394 "eval.m"
                    {
#line 394 "eval.m"
                      eval__V_306_306 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_305_305, (MR_Integer) 0)));
#line 394 "eval.m"
                      eval__Stack1_302 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_305_305, (MR_Integer) 1)));
#line 394 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 394 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_306_306) == MR_mktag((MR_Integer) 2));
#line 394 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_306_306) == MR_mktag((MR_Integer) 2)))
#line 394 "eval.m"
                        eval__N1_301 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_306_306, (MR_Integer) 0)));
                    }
                }
            }
#line 396 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_307_307;
              MR_Word eval__V_308_308;

#line 395 "eval.m"
              {
#line 395 "eval.m"
                eval__V_308_308 = op__op_lessf_3_f_0(eval__N1_301, eval__N2_300);
              }
#line 395 "eval.m"
              {
#line 395 "eval.m"
                eval__V_307_307 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "boolean");
#line 395 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_307_307, 0) = ((MR_Box) (eval__V_308_308));
#line 395 "eval.m"
              }
#line 395 "eval.m"
              {
#line 395 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_307_307, eval__Stack1_302);
              }
            }
#line 396 "eval.m"
          else
#line 397 "eval.m"
            {
#line 397 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 397 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 26:
        {
#line 402 "eval.m"
          MR_Word eval__Colour_312;
#line 402 "eval.m"
          MR_Word eval__Dir_313;
#line 402 "eval.m"
          MR_Word eval__Stack1_314;
          MR_Word eval__V_316_316;
          MR_Word eval__V_317_317;
          MR_Word eval__V_318_318;

#line 400 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 400 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 400 "eval.m"
            {
#line 400 "eval.m"
              eval__V_316_316 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 400 "eval.m"
              eval__V_317_317 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 400 "eval.m"
            }
          if (eval__succeeded)
            {
#line 400 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_316_316) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_316_316, (MR_Integer) 0))) == (MR_Integer) 3));
#line 400 "eval.m"
              if (((MR_tag((MR_Word) eval__V_316_316) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_316_316, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 400 "eval.m"
                eval__Colour_312 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_316_316, (MR_Integer) 1)));
              if (eval__succeeded)
                {
#line 400 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_317_317) == MR_mktag((MR_Integer) 1));
#line 400 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_317_317) == MR_mktag((MR_Integer) 1)))
#line 400 "eval.m"
                    {
#line 400 "eval.m"
                      eval__V_318_318 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_317_317, (MR_Integer) 0)));
#line 400 "eval.m"
                      eval__Stack1_314 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_317_317, (MR_Integer) 1)));
#line 400 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 400 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__V_318_318) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_318_318, (MR_Integer) 0))) == (MR_Integer) 3));
#line 400 "eval.m"
                      if (((MR_tag((MR_Word) eval__V_318_318) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_318_318, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 400 "eval.m"
                        eval__Dir_313 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_318_318, (MR_Integer) 1)));
                    }
                }
            }
#line 402 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_319_319;
              MR_Word eval__V_320_320;

#line 401 "eval.m"
              {
#line 401 "eval.m"
                eval__V_320_320 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "directional");
#line 401 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_320_320, 0) = ((MR_Box) (eval__Dir_313));
#line 401 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_320_320, 1) = ((MR_Box) (eval__Colour_312));
#line 401 "eval.m"
              }
#line 401 "eval.m"
              {
#line 401 "eval.m"
                eval__V_319_319 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "light"));
#line 401 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_319_319, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 5));
#line 401 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_319_319, 1) = ((MR_Box) (eval__V_320_320));
#line 401 "eval.m"
              }
#line 401 "eval.m"
              {
#line 401 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_319_319, eval__Stack1_314);
              }
            }
#line 402 "eval.m"
          else
#line 403 "eval.m"
            {
#line 403 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 403 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 27:
        {
#line 408 "eval.m"
          MR_Integer eval__N2_324;
#line 408 "eval.m"
          MR_Integer eval__N1_325;
#line 408 "eval.m"
          MR_Word eval__Stack1_326;
          MR_Word eval__V_328_328;
          MR_Word eval__V_329_329;
          MR_Word eval__V_330_330;

#line 406 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 406 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 406 "eval.m"
            {
#line 406 "eval.m"
              eval__V_328_328 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 406 "eval.m"
              eval__V_329_329 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 406 "eval.m"
            }
          if (eval__succeeded)
            {
#line 406 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_328_328) == MR_mktag((MR_Integer) 1));
#line 406 "eval.m"
              if ((MR_tag((MR_Word) eval__V_328_328) == MR_mktag((MR_Integer) 1)))
#line 406 "eval.m"
                eval__N2_324 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_328_328, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 406 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_329_329) == MR_mktag((MR_Integer) 1));
#line 406 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_329_329) == MR_mktag((MR_Integer) 1)))
#line 406 "eval.m"
                    {
#line 406 "eval.m"
                      eval__V_330_330 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_329_329, (MR_Integer) 0)));
#line 406 "eval.m"
                      eval__Stack1_326 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_329_329, (MR_Integer) 1)));
#line 406 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 406 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_330_330) == MR_mktag((MR_Integer) 1));
#line 406 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_330_330) == MR_mktag((MR_Integer) 1)))
#line 406 "eval.m"
                        eval__N1_325 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_330_330, (MR_Integer) 0)));
                    }
                }
            }
#line 408 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_331_331;
              MR_Integer eval__V_332_332;

#line 407 "eval.m"
              {
#line 407 "eval.m"
                eval__V_332_332 = op__op_modi_3_f_0(eval__N1_325, eval__N2_324);
              }
#line 407 "eval.m"
              {
#line 407 "eval.m"
                eval__V_331_331 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "int"));
#line 407 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_331_331, 0) = ((MR_Box) (eval__V_332_332));
#line 407 "eval.m"
              }
#line 407 "eval.m"
              {
#line 407 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_331_331, eval__Stack1_326);
              }
            }
#line 408 "eval.m"
          else
#line 409 "eval.m"
            {
#line 409 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 409 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 28:
        {
#line 414 "eval.m"
          MR_Integer eval__N2_336;
#line 414 "eval.m"
          MR_Integer eval__N1_337;
#line 414 "eval.m"
          MR_Word eval__Stack1_338;
          MR_Word eval__V_340_340;
          MR_Word eval__V_341_341;
          MR_Word eval__V_342_342;

#line 412 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 412 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 412 "eval.m"
            {
#line 412 "eval.m"
              eval__V_340_340 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 412 "eval.m"
              eval__V_341_341 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 412 "eval.m"
            }
          if (eval__succeeded)
            {
#line 412 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_340_340) == MR_mktag((MR_Integer) 1));
#line 412 "eval.m"
              if ((MR_tag((MR_Word) eval__V_340_340) == MR_mktag((MR_Integer) 1)))
#line 412 "eval.m"
                eval__N2_336 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_340_340, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 412 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_341_341) == MR_mktag((MR_Integer) 1));
#line 412 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_341_341) == MR_mktag((MR_Integer) 1)))
#line 412 "eval.m"
                    {
#line 412 "eval.m"
                      eval__V_342_342 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_341_341, (MR_Integer) 0)));
#line 412 "eval.m"
                      eval__Stack1_338 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_341_341, (MR_Integer) 1)));
#line 412 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 412 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_342_342) == MR_mktag((MR_Integer) 1));
#line 412 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_342_342) == MR_mktag((MR_Integer) 1)))
#line 412 "eval.m"
                        eval__N1_337 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_342_342, (MR_Integer) 0)));
                    }
                }
            }
#line 414 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_343_343;
              MR_Integer eval__V_344_344;

#line 413 "eval.m"
              {
#line 413 "eval.m"
                eval__V_344_344 = op__op_muli_3_f_0(eval__N1_337, eval__N2_336);
              }
#line 413 "eval.m"
              {
#line 413 "eval.m"
                eval__V_343_343 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "int"));
#line 413 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_343_343, 0) = ((MR_Box) (eval__V_344_344));
#line 413 "eval.m"
              }
#line 413 "eval.m"
              {
#line 413 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_343_343, eval__Stack1_338);
              }
            }
#line 414 "eval.m"
          else
#line 415 "eval.m"
            {
#line 415 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 415 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 29:
        {
#line 420 "eval.m"
          MR_Float eval__N2_348;
#line 420 "eval.m"
          MR_Float eval__N1_349;
#line 420 "eval.m"
          MR_Word eval__Stack1_350;
          MR_Word eval__V_352_352;
          MR_Word eval__V_353_353;
          MR_Word eval__V_354_354;

#line 418 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 418 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 418 "eval.m"
            {
#line 418 "eval.m"
              eval__V_352_352 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 418 "eval.m"
              eval__V_353_353 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 418 "eval.m"
            }
          if (eval__succeeded)
            {
#line 418 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_352_352) == MR_mktag((MR_Integer) 2));
#line 418 "eval.m"
              if ((MR_tag((MR_Word) eval__V_352_352) == MR_mktag((MR_Integer) 2)))
#line 418 "eval.m"
                eval__N2_348 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_352_352, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 418 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_353_353) == MR_mktag((MR_Integer) 1));
#line 418 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_353_353) == MR_mktag((MR_Integer) 1)))
#line 418 "eval.m"
                    {
#line 418 "eval.m"
                      eval__V_354_354 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_353_353, (MR_Integer) 0)));
#line 418 "eval.m"
                      eval__Stack1_350 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_353_353, (MR_Integer) 1)));
#line 418 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 418 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_354_354) == MR_mktag((MR_Integer) 2));
#line 418 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_354_354) == MR_mktag((MR_Integer) 2)))
#line 418 "eval.m"
                        eval__N1_349 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_354_354, (MR_Integer) 0)));
                    }
                }
            }
#line 420 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_355_355;
              MR_Float eval__V_356_356;

#line 419 "eval.m"
              {
#line 419 "eval.m"
                eval__V_356_356 = op__op_mulf_3_f_0(eval__N1_349, eval__N2_348);
              }
#line 419 "eval.m"
              {
#line 419 "eval.m"
                eval__V_355_355 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 419 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_355_355, 0) = MR_box_float(eval__V_356_356);
#line 419 "eval.m"
              }
#line 419 "eval.m"
              {
#line 419 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_355_355, eval__Stack1_350);
              }
            }
#line 420 "eval.m"
          else
#line 421 "eval.m"
            {
#line 421 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 421 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 30:
        {
#line 426 "eval.m"
          MR_Integer eval__N_360;
#line 426 "eval.m"
          MR_Word eval__Stack1_361;
          MR_Word eval__V_363_363;

#line 424 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 424 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 424 "eval.m"
            {
#line 424 "eval.m"
              eval__V_363_363 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 424 "eval.m"
              eval__Stack1_361 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 424 "eval.m"
            }
          if (eval__succeeded)
            {
#line 424 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_363_363) == MR_mktag((MR_Integer) 1));
#line 424 "eval.m"
              if ((MR_tag((MR_Word) eval__V_363_363) == MR_mktag((MR_Integer) 1)))
#line 424 "eval.m"
                eval__N_360 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_363_363, (MR_Integer) 0)));
            }
#line 426 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_364_364;
              MR_Integer eval__V_365_365;

#line 425 "eval.m"
              {
#line 425 "eval.m"
                eval__V_365_365 = op__op_negi_2_f_0(eval__N_360);
              }
#line 425 "eval.m"
              {
#line 425 "eval.m"
                eval__V_364_364 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "int"));
#line 425 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_364_364, 0) = ((MR_Box) (eval__V_365_365));
#line 425 "eval.m"
              }
#line 425 "eval.m"
              {
#line 425 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_364_364, eval__Stack1_361);
              }
            }
#line 426 "eval.m"
          else
#line 427 "eval.m"
            {
#line 427 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 427 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 31:
        {
#line 432 "eval.m"
          MR_Float eval__N_369;
#line 432 "eval.m"
          MR_Word eval__Stack1_370;
          MR_Word eval__V_372_372;

#line 430 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 430 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 430 "eval.m"
            {
#line 430 "eval.m"
              eval__V_372_372 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 430 "eval.m"
              eval__Stack1_370 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 430 "eval.m"
            }
          if (eval__succeeded)
            {
#line 430 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_372_372) == MR_mktag((MR_Integer) 2));
#line 430 "eval.m"
              if ((MR_tag((MR_Word) eval__V_372_372) == MR_mktag((MR_Integer) 2)))
#line 430 "eval.m"
                eval__N_369 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_372_372, (MR_Integer) 0)));
            }
#line 432 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_373_373;
              MR_Float eval__V_374_374;

#line 431 "eval.m"
              {
#line 431 "eval.m"
                eval__V_374_374 = op__op_negf_2_f_0(eval__N_369);
              }
#line 431 "eval.m"
              {
#line 431 "eval.m"
                eval__V_373_373 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 431 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_373_373, 0) = MR_box_float(eval__V_374_374);
#line 431 "eval.m"
              }
#line 431 "eval.m"
              {
#line 431 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_373_373, eval__Stack1_370);
              }
            }
#line 432 "eval.m"
          else
#line 433 "eval.m"
            {
#line 433 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 433 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 32:
#line 442 "eval.m"
        {
#line 442 "eval.m"
          MR_Word eval__CEnv_378;
#line 442 "eval.m"
          MR_Word eval__CCode_379;
#line 442 "eval.m"
          MR_Word eval__Stack1_380;
          MR_Word eval__V_384_384;

#line 436 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 436 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 436 "eval.m"
            {
#line 436 "eval.m"
              eval__V_384_384 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 436 "eval.m"
              eval__Stack1_380 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 436 "eval.m"
            }
          if (eval__succeeded)
            {
#line 436 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_384_384) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_384_384, (MR_Integer) 0))) == (MR_Integer) 1));
#line 436 "eval.m"
              if (((MR_tag((MR_Word) eval__V_384_384) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_384_384, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 436 "eval.m"
                {
#line 436 "eval.m"
                  eval__CEnv_378 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_384_384, (MR_Integer) 1)));
#line 436 "eval.m"
                  eval__CCode_379 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_384_384, (MR_Integer) 2)));
#line 436 "eval.m"
                }
            }
#line 442 "eval.m"
          if (eval__succeeded)
            {
              MR_Integer eval__Id_381;
              MR_Word eval__V_385_385;
              MR_Word eval__V_386_386;
              MR_Word eval__V_387_387;
              MR_Word eval__V_388_388;
              MR_Word eval__V_389_389;

#line 437 "eval.m"
              {
#line 437 "eval.m"
                eval__next_object_id_3_p_0(&eval__Id_381);
              }
#line 439 "eval.m"
              {
#line 439 "eval.m"
                eval__V_389_389 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "surface");
#line 439 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_389_389, 0) = ((MR_Box) (eval__CEnv_378));
#line 439 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_389_389, 1) = ((MR_Box) (eval__CCode_379));
#line 439 "eval.m"
              }
#line 439 "eval.m"
              {
#line 439 "eval.m"
                eval__V_387_387 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "plane"));
#line 439 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_387_387, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 1));
#line 439 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_387_387, 1) = ((MR_Box) (eval__V_389_389));
#line 439 "eval.m"
              }
#line 439 "eval.m"
              eval__V_388_388 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 438 "eval.m"
              {
#line 438 "eval.m"
                eval__V_386_386 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 438 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_386_386, 0) = ((MR_Box) (eval__Id_381));
#line 438 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_386_386, 1) = ((MR_Box) (eval__V_387_387));
#line 438 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_386_386, 2) = ((MR_Box) (eval__V_388_388));
#line 438 "eval.m"
              }
#line 438 "eval.m"
              {
#line 438 "eval.m"
                eval__V_385_385 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 438 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_385_385, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 438 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_385_385, 1) = ((MR_Box) (eval__V_386_386));
#line 438 "eval.m"
              }
#line 438 "eval.m"
              {
#line 438 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_385_385, eval__Stack1_380);
              }
            }
#line 442 "eval.m"
          else
#line 442 "eval.m"
            {
#line 442 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 442 "eval.m"
              return;
            }
#line 442 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 33:
        {
#line 448 "eval.m"
          MR_Float eval__Z_393;
#line 448 "eval.m"
          MR_Float eval__Y_394;
#line 448 "eval.m"
          MR_Float eval__X_395;
#line 448 "eval.m"
          MR_Word eval__Stack1_396;
          MR_Word eval__V_398_398;
          MR_Word eval__V_399_399;
          MR_Word eval__V_400_400;
          MR_Word eval__V_401_401;
          MR_Word eval__V_402_402;

#line 446 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 446 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 446 "eval.m"
            {
#line 446 "eval.m"
              eval__V_398_398 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 446 "eval.m"
              eval__V_399_399 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 446 "eval.m"
            }
          if (eval__succeeded)
            {
#line 446 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_398_398) == MR_mktag((MR_Integer) 2));
#line 446 "eval.m"
              if ((MR_tag((MR_Word) eval__V_398_398) == MR_mktag((MR_Integer) 2)))
#line 446 "eval.m"
                eval__Z_393 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_398_398, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 446 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_399_399) == MR_mktag((MR_Integer) 1));
#line 446 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_399_399) == MR_mktag((MR_Integer) 1)))
#line 446 "eval.m"
                    {
#line 446 "eval.m"
                      eval__V_400_400 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_399_399, (MR_Integer) 0)));
#line 446 "eval.m"
                      eval__V_401_401 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_399_399, (MR_Integer) 1)));
#line 446 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 446 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_400_400) == MR_mktag((MR_Integer) 2));
#line 446 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_400_400) == MR_mktag((MR_Integer) 2)))
#line 446 "eval.m"
                        eval__Y_394 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_400_400, (MR_Integer) 0)));
                      if (eval__succeeded)
                        {
#line 446 "eval.m"
                          eval__succeeded = (MR_tag((MR_Word) eval__V_401_401) == MR_mktag((MR_Integer) 1));
#line 446 "eval.m"
                          if ((MR_tag((MR_Word) eval__V_401_401) == MR_mktag((MR_Integer) 1)))
#line 446 "eval.m"
                            {
#line 446 "eval.m"
                              eval__V_402_402 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_401_401, (MR_Integer) 0)));
#line 446 "eval.m"
                              eval__Stack1_396 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_401_401, (MR_Integer) 1)));
#line 446 "eval.m"
                            }
                          if (eval__succeeded)
                            {
#line 446 "eval.m"
                              eval__succeeded = (MR_tag((MR_Word) eval__V_402_402) == MR_mktag((MR_Integer) 2));
#line 446 "eval.m"
                              if ((MR_tag((MR_Word) eval__V_402_402) == MR_mktag((MR_Integer) 2)))
#line 446 "eval.m"
                                eval__X_395 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_402_402, (MR_Integer) 0)));
                            }
                        }
                    }
                }
            }
#line 448 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_403_403;
              MR_Word eval__V_404_404;

#line 447 "eval.m"
              {
#line 447 "eval.m"
                eval__V_404_404 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 447 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_404_404, 0) = MR_box_float(eval__X_395);
#line 447 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_404_404, 1) = MR_box_float(eval__Y_394);
#line 447 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_404_404, 2) = MR_box_float(eval__Z_393);
#line 447 "eval.m"
              }
#line 447 "eval.m"
              {
#line 447 "eval.m"
                eval__V_403_403 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "point"));
#line 447 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_403_403, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 3));
#line 447 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_403_403, 1) = ((MR_Box) (eval__V_404_404));
#line 447 "eval.m"
              }
#line 447 "eval.m"
              {
#line 447 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_403_403, eval__Stack1_396);
              }
            }
#line 448 "eval.m"
          else
#line 449 "eval.m"
            {
#line 449 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 449 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 34:
        {
#line 454 "eval.m"
          MR_Word eval__Colour_408;
#line 454 "eval.m"
          MR_Word eval__Pos_409;
#line 454 "eval.m"
          MR_Word eval__Stack1_410;
          MR_Word eval__V_412_412;
          MR_Word eval__V_413_413;
          MR_Word eval__V_414_414;

#line 452 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 452 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 452 "eval.m"
            {
#line 452 "eval.m"
              eval__V_412_412 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 452 "eval.m"
              eval__V_413_413 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 452 "eval.m"
            }
          if (eval__succeeded)
            {
#line 452 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_412_412) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_412_412, (MR_Integer) 0))) == (MR_Integer) 3));
#line 452 "eval.m"
              if (((MR_tag((MR_Word) eval__V_412_412) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_412_412, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 452 "eval.m"
                eval__Colour_408 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_412_412, (MR_Integer) 1)));
              if (eval__succeeded)
                {
#line 452 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_413_413) == MR_mktag((MR_Integer) 1));
#line 452 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_413_413) == MR_mktag((MR_Integer) 1)))
#line 452 "eval.m"
                    {
#line 452 "eval.m"
                      eval__V_414_414 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_413_413, (MR_Integer) 0)));
#line 452 "eval.m"
                      eval__Stack1_410 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_413_413, (MR_Integer) 1)));
#line 452 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 452 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__V_414_414) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_414_414, (MR_Integer) 0))) == (MR_Integer) 3));
#line 452 "eval.m"
                      if (((MR_tag((MR_Word) eval__V_414_414) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_414_414, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 452 "eval.m"
                        eval__Pos_409 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_414_414, (MR_Integer) 1)));
                    }
                }
            }
#line 454 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_415_415;
              MR_Word eval__V_416_416;

#line 453 "eval.m"
              {
#line 453 "eval.m"
                eval__V_416_416 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "pointlight"));
#line 453 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_416_416, 0) = ((MR_Box) (eval__Pos_409));
#line 453 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_416_416, 1) = ((MR_Box) (eval__Colour_408));
#line 453 "eval.m"
              }
#line 453 "eval.m"
              {
#line 453 "eval.m"
                eval__V_415_415 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "light"));
#line 453 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_415_415, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 5));
#line 453 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_415_415, 1) = ((MR_Box) (eval__V_416_416));
#line 453 "eval.m"
              }
#line 453 "eval.m"
              {
#line 453 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_415_415, eval__Stack1_410);
              }
            }
#line 454 "eval.m"
          else
#line 455 "eval.m"
            {
#line 455 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 455 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 35:
        {
#line 460 "eval.m"
          MR_Integer eval__N_420;
#line 460 "eval.m"
          MR_Word eval__Stack1_421;
          MR_Word eval__V_423_423;

#line 458 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 458 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 458 "eval.m"
            {
#line 458 "eval.m"
              eval__V_423_423 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 458 "eval.m"
              eval__Stack1_421 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 458 "eval.m"
            }
          if (eval__succeeded)
            {
#line 458 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_423_423) == MR_mktag((MR_Integer) 1));
#line 458 "eval.m"
              if ((MR_tag((MR_Word) eval__V_423_423) == MR_mktag((MR_Integer) 1)))
#line 458 "eval.m"
                eval__N_420 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_423_423, (MR_Integer) 0)));
            }
#line 460 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_424_424;
              MR_Float eval__V_425_425;

#line 459 "eval.m"
              {
#line 459 "eval.m"
                eval__V_425_425 = op__op_real_2_f_0(eval__N_420);
              }
#line 459 "eval.m"
              {
#line 459 "eval.m"
                eval__V_424_424 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 459 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_424_424, 0) = MR_box_float(eval__V_425_425);
#line 459 "eval.m"
              }
#line 459 "eval.m"
              {
#line 459 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_424_424, eval__Stack1_421);
              }
            }
#line 460 "eval.m"
          else
#line 461 "eval.m"
            {
#line 461 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 461 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 36:
#line 474 "eval.m"
        {
#line 474 "eval.m"
          MR_String eval__File_429;
#line 474 "eval.m"
          MR_Integer eval__Ht_430;
#line 474 "eval.m"
          MR_Integer eval__Wid_431;
#line 474 "eval.m"
          MR_Float eval__FOV_432;
#line 474 "eval.m"
          MR_Integer eval__Depth_433;
#line 474 "eval.m"
          MR_Word eval__Obj_434;
#line 474 "eval.m"
          MR_Array eval__Lights_435;
#line 474 "eval.m"
          MR_Word eval__Amb_436;
#line 474 "eval.m"
          MR_Word eval__Stack1_437;
          MR_Word eval__V_442_442;
          MR_Word eval__V_443_443;
          MR_Word eval__V_444_444;
          MR_Word eval__V_445_445;
          MR_Word eval__V_446_446;
          MR_Word eval__V_447_447;
          MR_Word eval__V_448_448;
          MR_Word eval__V_449_449;
          MR_Word eval__V_450_450;
          MR_Word eval__V_451_451;
          MR_Word eval__V_452_452;
          MR_Word eval__V_453_453;
          MR_Word eval__V_454_454;
          MR_Word eval__V_455_455;
          MR_Word eval__V_456_456;

#line 465 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 465 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 465 "eval.m"
            {
#line 465 "eval.m"
              eval__V_442_442 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 465 "eval.m"
              eval__V_443_443 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 465 "eval.m"
            }
          if (eval__succeeded)
            {
#line 465 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_442_442) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_442_442, (MR_Integer) 0))) == (MR_Integer) 0));
#line 465 "eval.m"
              if (((MR_tag((MR_Word) eval__V_442_442) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_442_442, (MR_Integer) 0))) == (MR_Integer) 0)))
#line 465 "eval.m"
                eval__File_429 = ((MR_String) (MR_hl_field(MR_mktag(3), eval__V_442_442, (MR_Integer) 1)));
              if (eval__succeeded)
                {
#line 465 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_443_443) == MR_mktag((MR_Integer) 1));
#line 465 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_443_443) == MR_mktag((MR_Integer) 1)))
#line 465 "eval.m"
                    {
#line 465 "eval.m"
                      eval__V_444_444 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_443_443, (MR_Integer) 0)));
#line 465 "eval.m"
                      eval__V_445_445 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_443_443, (MR_Integer) 1)));
#line 465 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 465 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_444_444) == MR_mktag((MR_Integer) 1));
#line 465 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_444_444) == MR_mktag((MR_Integer) 1)))
#line 465 "eval.m"
                        eval__Ht_430 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_444_444, (MR_Integer) 0)));
                      if (eval__succeeded)
                        {
#line 465 "eval.m"
                          eval__succeeded = (MR_tag((MR_Word) eval__V_445_445) == MR_mktag((MR_Integer) 1));
#line 465 "eval.m"
                          if ((MR_tag((MR_Word) eval__V_445_445) == MR_mktag((MR_Integer) 1)))
#line 465 "eval.m"
                            {
#line 465 "eval.m"
                              eval__V_446_446 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_445_445, (MR_Integer) 0)));
#line 465 "eval.m"
                              eval__V_447_447 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_445_445, (MR_Integer) 1)));
#line 465 "eval.m"
                            }
                          if (eval__succeeded)
                            {
#line 465 "eval.m"
                              eval__succeeded = (MR_tag((MR_Word) eval__V_446_446) == MR_mktag((MR_Integer) 1));
#line 465 "eval.m"
                              if ((MR_tag((MR_Word) eval__V_446_446) == MR_mktag((MR_Integer) 1)))
#line 465 "eval.m"
                                eval__Wid_431 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_446_446, (MR_Integer) 0)));
                              if (eval__succeeded)
                                {
#line 465 "eval.m"
                                  eval__succeeded = (MR_tag((MR_Word) eval__V_447_447) == MR_mktag((MR_Integer) 1));
#line 465 "eval.m"
                                  if ((MR_tag((MR_Word) eval__V_447_447) == MR_mktag((MR_Integer) 1)))
#line 465 "eval.m"
                                    {
#line 465 "eval.m"
                                      eval__V_448_448 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_447_447, (MR_Integer) 0)));
#line 465 "eval.m"
                                      eval__V_449_449 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_447_447, (MR_Integer) 1)));
#line 465 "eval.m"
                                    }
                                  if (eval__succeeded)
                                    {
#line 465 "eval.m"
                                      eval__succeeded = (MR_tag((MR_Word) eval__V_448_448) == MR_mktag((MR_Integer) 2));
#line 465 "eval.m"
                                      if ((MR_tag((MR_Word) eval__V_448_448) == MR_mktag((MR_Integer) 2)))
#line 465 "eval.m"
                                        eval__FOV_432 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_448_448, (MR_Integer) 0)));
                                      if (eval__succeeded)
                                        {
#line 465 "eval.m"
                                          eval__succeeded = (MR_tag((MR_Word) eval__V_449_449) == MR_mktag((MR_Integer) 1));
#line 465 "eval.m"
                                          if ((MR_tag((MR_Word) eval__V_449_449) == MR_mktag((MR_Integer) 1)))
#line 465 "eval.m"
                                            {
#line 465 "eval.m"
                                              eval__V_450_450 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_449_449, (MR_Integer) 0)));
#line 465 "eval.m"
                                              eval__V_451_451 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_449_449, (MR_Integer) 1)));
#line 465 "eval.m"
                                            }
                                          if (eval__succeeded)
                                            {
#line 466 "eval.m"
                                              eval__succeeded = (MR_tag((MR_Word) eval__V_450_450) == MR_mktag((MR_Integer) 1));
#line 466 "eval.m"
                                              if ((MR_tag((MR_Word) eval__V_450_450) == MR_mktag((MR_Integer) 1)))
#line 466 "eval.m"
                                                eval__Depth_433 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_450_450, (MR_Integer) 0)));
                                              if (eval__succeeded)
                                                {
#line 466 "eval.m"
                                                  eval__succeeded = (MR_tag((MR_Word) eval__V_451_451) == MR_mktag((MR_Integer) 1));
#line 466 "eval.m"
                                                  if ((MR_tag((MR_Word) eval__V_451_451) == MR_mktag((MR_Integer) 1)))
#line 466 "eval.m"
                                                    {
#line 466 "eval.m"
                                                      eval__V_452_452 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_451_451, (MR_Integer) 0)));
#line 466 "eval.m"
                                                      eval__V_453_453 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_451_451, (MR_Integer) 1)));
#line 466 "eval.m"
                                                    }
                                                  if (eval__succeeded)
                                                    {
#line 466 "eval.m"
                                                      eval__succeeded = ((MR_tag((MR_Word) eval__V_452_452) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_452_452, (MR_Integer) 0))) == (MR_Integer) 4));
#line 466 "eval.m"
                                                      if (((MR_tag((MR_Word) eval__V_452_452) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_452_452, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 466 "eval.m"
                                                        eval__Obj_434 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_452_452, (MR_Integer) 1)));
                                                      if (eval__succeeded)
                                                        {
#line 466 "eval.m"
                                                          eval__succeeded = (MR_tag((MR_Word) eval__V_453_453) == MR_mktag((MR_Integer) 1));
#line 466 "eval.m"
                                                          if ((MR_tag((MR_Word) eval__V_453_453) == MR_mktag((MR_Integer) 1)))
#line 466 "eval.m"
                                                            {
#line 466 "eval.m"
                                                              eval__V_454_454 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_453_453, (MR_Integer) 0)));
#line 466 "eval.m"
                                                              eval__V_455_455 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_453_453, (MR_Integer) 1)));
#line 466 "eval.m"
                                                            }
                                                          if (eval__succeeded)
                                                            {
#line 466 "eval.m"
                                                              eval__succeeded = ((MR_tag((MR_Word) eval__V_454_454) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_454_454, (MR_Integer) 0))) == (MR_Integer) 2));
#line 466 "eval.m"
                                                              if (((MR_tag((MR_Word) eval__V_454_454) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_454_454, (MR_Integer) 0))) == (MR_Integer) 2)))
#line 466 "eval.m"
                                                                eval__Lights_435 = ((MR_Array) (MR_hl_field(MR_mktag(3), eval__V_454_454, (MR_Integer) 1)));
                                                              if (eval__succeeded)
                                                                {
#line 466 "eval.m"
                                                                  eval__succeeded = (MR_tag((MR_Word) eval__V_455_455) == MR_mktag((MR_Integer) 1));
#line 466 "eval.m"
                                                                  if ((MR_tag((MR_Word) eval__V_455_455) == MR_mktag((MR_Integer) 1)))
#line 466 "eval.m"
                                                                    {
#line 466 "eval.m"
                                                                      eval__V_456_456 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_455_455, (MR_Integer) 0)));
#line 466 "eval.m"
                                                                      eval__Stack1_437 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_455_455, (MR_Integer) 1)));
#line 466 "eval.m"
                                                                    }
                                                                  if (eval__succeeded)
                                                                    {
#line 467 "eval.m"
                                                                      eval__succeeded = ((MR_tag((MR_Word) eval__V_456_456) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_456_456, (MR_Integer) 0))) == (MR_Integer) 3));
#line 467 "eval.m"
                                                                      if (((MR_tag((MR_Word) eval__V_456_456) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_456_456, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 467 "eval.m"
                                                                        eval__Amb_436 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_456_456, (MR_Integer) 1)));
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
#line 474 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__Scene_438;
              MR_Word eval__Params_439;
              MR_Word eval__V_457_457;

#line 469 "eval.m"
              {
#line 469 "eval.m"
                eval__V_457_457 = transform_object__push_transformations_2_f_0(eval__Obj_434);
              }
#line 469 "eval.m"
              {
#line 469 "eval.m"
                eval__Scene_438 = space_partition__create_scene_2_f_0(eval__V_457_457);
              }
#line 470 "eval.m"
              {
#line 470 "eval.m"
                eval__Params_439 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 8 * sizeof(MR_Word)), "render_params");
#line 470 "eval.m"
                MR_hl_field(MR_mktag(0), eval__Params_439, 0) = ((MR_Box) (eval__Amb_436));
#line 470 "eval.m"
                MR_hl_field(MR_mktag(0), eval__Params_439, 1) = ((MR_Box) (eval__Lights_435));
#line 470 "eval.m"
                MR_hl_field(MR_mktag(0), eval__Params_439, 2) = ((MR_Box) (eval__Scene_438));
#line 470 "eval.m"
                MR_hl_field(MR_mktag(0), eval__Params_439, 3) = ((MR_Box) (eval__Depth_433));
#line 470 "eval.m"
                MR_hl_field(MR_mktag(0), eval__Params_439, 4) = MR_box_float(eval__FOV_432);
#line 470 "eval.m"
                MR_hl_field(MR_mktag(0), eval__Params_439, 5) = ((MR_Box) (eval__Wid_431));
#line 470 "eval.m"
                MR_hl_field(MR_mktag(0), eval__Params_439, 6) = ((MR_Box) (eval__Ht_430));
#line 470 "eval.m"
                MR_hl_field(MR_mktag(0), eval__Params_439, 7) = ((MR_Box) (eval__File_429));
#line 470 "eval.m"
              }
#line 472 "eval.m"
              {
#line 472 "eval.m"
                renderer__render_3_p_0(eval__Params_439);
              }
#line 473 "eval.m"
              *eval__HeadVar__4_4 = eval__Stack1_437;
            }
#line 474 "eval.m"
          else
#line 474 "eval.m"
            {
#line 474 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 474 "eval.m"
              return;
            }
#line 474 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 37:
#line 482 "eval.m"
        {
#line 482 "eval.m"
          MR_Float eval__Theta_461;
#line 482 "eval.m"
          MR_Word eval__Obj0_462;
#line 482 "eval.m"
          MR_Word eval__Stack1_463;
          MR_Word eval__V_467_467;
          MR_Word eval__V_468_468;
          MR_Word eval__V_469_469;

#line 478 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 478 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 478 "eval.m"
            {
#line 478 "eval.m"
              eval__V_467_467 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 478 "eval.m"
              eval__V_468_468 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 478 "eval.m"
            }
          if (eval__succeeded)
            {
#line 478 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_467_467) == MR_mktag((MR_Integer) 2));
#line 478 "eval.m"
              if ((MR_tag((MR_Word) eval__V_467_467) == MR_mktag((MR_Integer) 2)))
#line 478 "eval.m"
                eval__Theta_461 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_467_467, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 478 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_468_468) == MR_mktag((MR_Integer) 1));
#line 478 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_468_468) == MR_mktag((MR_Integer) 1)))
#line 478 "eval.m"
                    {
#line 478 "eval.m"
                      eval__V_469_469 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_468_468, (MR_Integer) 0)));
#line 478 "eval.m"
                      eval__Stack1_463 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_468_468, (MR_Integer) 1)));
#line 478 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 478 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__V_469_469) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_469_469, (MR_Integer) 0))) == (MR_Integer) 4));
#line 478 "eval.m"
                      if (((MR_tag((MR_Word) eval__V_469_469) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_469_469, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 478 "eval.m"
                        eval__Obj0_462 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_469_469, (MR_Integer) 1)));
                    }
                }
            }
#line 482 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__Obj_464;
              MR_Word eval__V_470_470;
              MR_Word eval__V_471_471;
              MR_Word eval__V_472_472;

#line 479 "eval.m"
              {
#line 479 "eval.m"
                eval__renameObject_4_p_0(eval__Obj0_462, &eval__Obj_464);
              }
#line 480 "eval.m"
              {
#line 480 "eval.m"
                eval__V_472_472 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "rotatex"));
#line 480 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_472_472, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 0));
#line 480 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_472_472, 1) = MR_box_float(eval__Theta_461);
#line 480 "eval.m"
              }
#line 480 "eval.m"
              {
#line 480 "eval.m"
                eval__V_471_471 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "transform"));
#line 480 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_471_471, 0) = ((MR_Box) (eval__Obj_464));
#line 480 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_471_471, 1) = ((MR_Box) (eval__V_472_472));
#line 480 "eval.m"
              }
#line 480 "eval.m"
              {
#line 480 "eval.m"
                eval__V_470_470 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 480 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_470_470, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 480 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_470_470, 1) = ((MR_Box) (eval__V_471_471));
#line 480 "eval.m"
              }
#line 480 "eval.m"
              {
#line 480 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_470_470, eval__Stack1_463);
              }
            }
#line 482 "eval.m"
          else
#line 482 "eval.m"
            {
#line 482 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 482 "eval.m"
              return;
            }
#line 482 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 38:
#line 490 "eval.m"
        {
#line 490 "eval.m"
          MR_Float eval__Theta_476;
#line 490 "eval.m"
          MR_Word eval__Obj0_477;
#line 490 "eval.m"
          MR_Word eval__Stack1_478;
          MR_Word eval__V_482_482;
          MR_Word eval__V_483_483;
          MR_Word eval__V_484_484;

#line 486 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 486 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 486 "eval.m"
            {
#line 486 "eval.m"
              eval__V_482_482 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 486 "eval.m"
              eval__V_483_483 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 486 "eval.m"
            }
          if (eval__succeeded)
            {
#line 486 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_482_482) == MR_mktag((MR_Integer) 2));
#line 486 "eval.m"
              if ((MR_tag((MR_Word) eval__V_482_482) == MR_mktag((MR_Integer) 2)))
#line 486 "eval.m"
                eval__Theta_476 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_482_482, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 486 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_483_483) == MR_mktag((MR_Integer) 1));
#line 486 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_483_483) == MR_mktag((MR_Integer) 1)))
#line 486 "eval.m"
                    {
#line 486 "eval.m"
                      eval__V_484_484 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_483_483, (MR_Integer) 0)));
#line 486 "eval.m"
                      eval__Stack1_478 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_483_483, (MR_Integer) 1)));
#line 486 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 486 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__V_484_484) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_484_484, (MR_Integer) 0))) == (MR_Integer) 4));
#line 486 "eval.m"
                      if (((MR_tag((MR_Word) eval__V_484_484) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_484_484, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 486 "eval.m"
                        eval__Obj0_477 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_484_484, (MR_Integer) 1)));
                    }
                }
            }
#line 490 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__Obj_479;
              MR_Word eval__V_485_485;
              MR_Word eval__V_486_486;
              MR_Word eval__V_487_487;

#line 487 "eval.m"
              {
#line 487 "eval.m"
                eval__renameObject_4_p_0(eval__Obj0_477, &eval__Obj_479);
              }
#line 488 "eval.m"
              {
#line 488 "eval.m"
                eval__V_487_487 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "rotatey"));
#line 488 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_487_487, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 1));
#line 488 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_487_487, 1) = MR_box_float(eval__Theta_476);
#line 488 "eval.m"
              }
#line 488 "eval.m"
              {
#line 488 "eval.m"
                eval__V_486_486 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "transform"));
#line 488 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_486_486, 0) = ((MR_Box) (eval__Obj_479));
#line 488 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_486_486, 1) = ((MR_Box) (eval__V_487_487));
#line 488 "eval.m"
              }
#line 488 "eval.m"
              {
#line 488 "eval.m"
                eval__V_485_485 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 488 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_485_485, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 488 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_485_485, 1) = ((MR_Box) (eval__V_486_486));
#line 488 "eval.m"
              }
#line 488 "eval.m"
              {
#line 488 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_485_485, eval__Stack1_478);
              }
            }
#line 490 "eval.m"
          else
#line 490 "eval.m"
            {
#line 490 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 490 "eval.m"
              return;
            }
#line 490 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 39:
#line 498 "eval.m"
        {
#line 498 "eval.m"
          MR_Float eval__Theta_491;
#line 498 "eval.m"
          MR_Word eval__Obj0_492;
#line 498 "eval.m"
          MR_Word eval__Stack1_493;
          MR_Word eval__V_497_497;
          MR_Word eval__V_498_498;
          MR_Word eval__V_499_499;

#line 494 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 494 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 494 "eval.m"
            {
#line 494 "eval.m"
              eval__V_497_497 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 494 "eval.m"
              eval__V_498_498 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 494 "eval.m"
            }
          if (eval__succeeded)
            {
#line 494 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_497_497) == MR_mktag((MR_Integer) 2));
#line 494 "eval.m"
              if ((MR_tag((MR_Word) eval__V_497_497) == MR_mktag((MR_Integer) 2)))
#line 494 "eval.m"
                eval__Theta_491 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_497_497, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 494 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_498_498) == MR_mktag((MR_Integer) 1));
#line 494 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_498_498) == MR_mktag((MR_Integer) 1)))
#line 494 "eval.m"
                    {
#line 494 "eval.m"
                      eval__V_499_499 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_498_498, (MR_Integer) 0)));
#line 494 "eval.m"
                      eval__Stack1_493 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_498_498, (MR_Integer) 1)));
#line 494 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 494 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__V_499_499) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_499_499, (MR_Integer) 0))) == (MR_Integer) 4));
#line 494 "eval.m"
                      if (((MR_tag((MR_Word) eval__V_499_499) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_499_499, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 494 "eval.m"
                        eval__Obj0_492 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_499_499, (MR_Integer) 1)));
                    }
                }
            }
#line 498 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__Obj_494;
              MR_Word eval__V_500_500;
              MR_Word eval__V_501_501;
              MR_Word eval__V_502_502;

#line 495 "eval.m"
              {
#line 495 "eval.m"
                eval__renameObject_4_p_0(eval__Obj0_492, &eval__Obj_494);
              }
#line 496 "eval.m"
              {
#line 496 "eval.m"
                eval__V_502_502 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "rotatez"));
#line 496 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_502_502, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 2));
#line 496 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_502_502, 1) = MR_box_float(eval__Theta_491);
#line 496 "eval.m"
              }
#line 496 "eval.m"
              {
#line 496 "eval.m"
                eval__V_501_501 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "transform"));
#line 496 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_501_501, 0) = ((MR_Box) (eval__Obj_494));
#line 496 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_501_501, 1) = ((MR_Box) (eval__V_502_502));
#line 496 "eval.m"
              }
#line 496 "eval.m"
              {
#line 496 "eval.m"
                eval__V_500_500 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 496 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_500_500, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 496 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_500_500, 1) = ((MR_Box) (eval__V_501_501));
#line 496 "eval.m"
              }
#line 496 "eval.m"
              {
#line 496 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_500_500, eval__Stack1_493);
              }
            }
#line 498 "eval.m"
          else
#line 498 "eval.m"
            {
#line 498 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 498 "eval.m"
              return;
            }
#line 498 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 40:
#line 506 "eval.m"
        {
#line 506 "eval.m"
          MR_Float eval__Z_506;
#line 506 "eval.m"
          MR_Float eval__Y_507;
#line 506 "eval.m"
          MR_Float eval__X_508;
#line 506 "eval.m"
          MR_Word eval__Obj0_509;
#line 506 "eval.m"
          MR_Word eval__Stack1_510;
          MR_Word eval__V_514_514;
          MR_Word eval__V_515_515;
          MR_Word eval__V_516_516;
          MR_Word eval__V_517_517;
          MR_Word eval__V_518_518;
          MR_Word eval__V_519_519;
          MR_Word eval__V_520_520;

#line 502 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 502 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 502 "eval.m"
            {
#line 502 "eval.m"
              eval__V_514_514 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 502 "eval.m"
              eval__V_515_515 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 502 "eval.m"
            }
          if (eval__succeeded)
            {
#line 502 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_514_514) == MR_mktag((MR_Integer) 2));
#line 502 "eval.m"
              if ((MR_tag((MR_Word) eval__V_514_514) == MR_mktag((MR_Integer) 2)))
#line 502 "eval.m"
                eval__Z_506 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_514_514, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 502 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_515_515) == MR_mktag((MR_Integer) 1));
#line 502 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_515_515) == MR_mktag((MR_Integer) 1)))
#line 502 "eval.m"
                    {
#line 502 "eval.m"
                      eval__V_516_516 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_515_515, (MR_Integer) 0)));
#line 502 "eval.m"
                      eval__V_517_517 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_515_515, (MR_Integer) 1)));
#line 502 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 502 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_516_516) == MR_mktag((MR_Integer) 2));
#line 502 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_516_516) == MR_mktag((MR_Integer) 2)))
#line 502 "eval.m"
                        eval__Y_507 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_516_516, (MR_Integer) 0)));
                      if (eval__succeeded)
                        {
#line 502 "eval.m"
                          eval__succeeded = (MR_tag((MR_Word) eval__V_517_517) == MR_mktag((MR_Integer) 1));
#line 502 "eval.m"
                          if ((MR_tag((MR_Word) eval__V_517_517) == MR_mktag((MR_Integer) 1)))
#line 502 "eval.m"
                            {
#line 502 "eval.m"
                              eval__V_518_518 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_517_517, (MR_Integer) 0)));
#line 502 "eval.m"
                              eval__V_519_519 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_517_517, (MR_Integer) 1)));
#line 502 "eval.m"
                            }
                          if (eval__succeeded)
                            {
#line 502 "eval.m"
                              eval__succeeded = (MR_tag((MR_Word) eval__V_518_518) == MR_mktag((MR_Integer) 2));
#line 502 "eval.m"
                              if ((MR_tag((MR_Word) eval__V_518_518) == MR_mktag((MR_Integer) 2)))
#line 502 "eval.m"
                                eval__X_508 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_518_518, (MR_Integer) 0)));
                              if (eval__succeeded)
                                {
#line 502 "eval.m"
                                  eval__succeeded = (MR_tag((MR_Word) eval__V_519_519) == MR_mktag((MR_Integer) 1));
#line 502 "eval.m"
                                  if ((MR_tag((MR_Word) eval__V_519_519) == MR_mktag((MR_Integer) 1)))
#line 502 "eval.m"
                                    {
#line 502 "eval.m"
                                      eval__V_520_520 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_519_519, (MR_Integer) 0)));
#line 502 "eval.m"
                                      eval__Stack1_510 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_519_519, (MR_Integer) 1)));
#line 502 "eval.m"
                                    }
                                  if (eval__succeeded)
                                    {
#line 502 "eval.m"
                                      eval__succeeded = ((MR_tag((MR_Word) eval__V_520_520) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_520_520, (MR_Integer) 0))) == (MR_Integer) 4));
#line 502 "eval.m"
                                      if (((MR_tag((MR_Word) eval__V_520_520) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_520_520, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 502 "eval.m"
                                        eval__Obj0_509 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_520_520, (MR_Integer) 1)));
                                    }
                                }
                            }
                        }
                    }
                }
            }
#line 506 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__Obj_511;
              MR_Word eval__V_521_521;
              MR_Word eval__V_522_522;
              MR_Word eval__V_523_523;

#line 503 "eval.m"
              {
#line 503 "eval.m"
                eval__renameObject_4_p_0(eval__Obj0_509, &eval__Obj_511);
              }
#line 504 "eval.m"
              {
#line 504 "eval.m"
                eval__V_523_523 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "scale"));
#line 504 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_523_523, 0) = MR_box_float(eval__X_508);
#line 504 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_523_523, 1) = MR_box_float(eval__Y_507);
#line 504 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_523_523, 2) = MR_box_float(eval__Z_506);
#line 504 "eval.m"
              }
#line 504 "eval.m"
              {
#line 504 "eval.m"
                eval__V_522_522 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "transform"));
#line 504 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_522_522, 0) = ((MR_Box) (eval__Obj_511));
#line 504 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_522_522, 1) = ((MR_Box) (eval__V_523_523));
#line 504 "eval.m"
              }
#line 504 "eval.m"
              {
#line 504 "eval.m"
                eval__V_521_521 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 504 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_521_521, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 504 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_521_521, 1) = ((MR_Box) (eval__V_522_522));
#line 504 "eval.m"
              }
#line 504 "eval.m"
              {
#line 504 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_521_521, eval__Stack1_510);
              }
            }
#line 506 "eval.m"
          else
#line 506 "eval.m"
            {
#line 506 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 506 "eval.m"
              return;
            }
#line 506 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 41:
        {
#line 512 "eval.m"
          MR_Float eval__N_527;
#line 512 "eval.m"
          MR_Word eval__Stack1_528;
          MR_Word eval__V_530_530;

#line 510 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 510 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 510 "eval.m"
            {
#line 510 "eval.m"
              eval__V_530_530 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 510 "eval.m"
              eval__Stack1_528 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 510 "eval.m"
            }
          if (eval__succeeded)
            {
#line 510 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_530_530) == MR_mktag((MR_Integer) 2));
#line 510 "eval.m"
              if ((MR_tag((MR_Word) eval__V_530_530) == MR_mktag((MR_Integer) 2)))
#line 510 "eval.m"
                eval__N_527 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_530_530, (MR_Integer) 0)));
            }
#line 512 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_531_531;
              MR_Float eval__V_532_532;

#line 511 "eval.m"
              {
#line 511 "eval.m"
                eval__V_532_532 = op__op_sin_2_f_0(eval__N_527);
              }
#line 511 "eval.m"
              {
#line 511 "eval.m"
                eval__V_531_531 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 511 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_531_531, 0) = MR_box_float(eval__V_532_532);
#line 511 "eval.m"
              }
#line 511 "eval.m"
              {
#line 511 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_531_531, eval__Stack1_528);
              }
            }
#line 512 "eval.m"
          else
#line 513 "eval.m"
            {
#line 513 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 513 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 42:
#line 522 "eval.m"
        {
#line 522 "eval.m"
          MR_Word eval__CEnv_536;
#line 522 "eval.m"
          MR_Word eval__CCode_537;
#line 522 "eval.m"
          MR_Word eval__Stack1_538;
          MR_Word eval__V_542_542;

#line 516 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 516 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 516 "eval.m"
            {
#line 516 "eval.m"
              eval__V_542_542 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 516 "eval.m"
              eval__Stack1_538 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 516 "eval.m"
            }
          if (eval__succeeded)
            {
#line 516 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_542_542) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_542_542, (MR_Integer) 0))) == (MR_Integer) 1));
#line 516 "eval.m"
              if (((MR_tag((MR_Word) eval__V_542_542) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_542_542, (MR_Integer) 0))) == (MR_Integer) 1)))
#line 516 "eval.m"
                {
#line 516 "eval.m"
                  eval__CEnv_536 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_542_542, (MR_Integer) 1)));
#line 516 "eval.m"
                  eval__CCode_537 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_542_542, (MR_Integer) 2)));
#line 516 "eval.m"
                }
            }
#line 522 "eval.m"
          if (eval__succeeded)
            {
              MR_Integer eval__Id_539;
              MR_Word eval__V_543_543;
              MR_Word eval__V_544_544;
              MR_Word eval__V_545_545;
              MR_Word eval__V_546_546;
              MR_Word eval__V_547_547;

#line 517 "eval.m"
              {
#line 517 "eval.m"
                eval__next_object_id_3_p_0(&eval__Id_539);
              }
#line 519 "eval.m"
              {
#line 519 "eval.m"
                eval__V_547_547 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "surface");
#line 519 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_547_547, 0) = ((MR_Box) (eval__CEnv_536));
#line 519 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_547_547, 1) = ((MR_Box) (eval__CCode_537));
#line 519 "eval.m"
              }
#line 519 "eval.m"
              {
#line 519 "eval.m"
                eval__V_545_545 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "sphere");
#line 519 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_545_545, 0) = ((MR_Box) (eval__V_547_547));
#line 519 "eval.m"
              }
#line 519 "eval.m"
              eval__V_546_546 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 518 "eval.m"
              {
#line 518 "eval.m"
                eval__V_544_544 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "basic_object");
#line 518 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_544_544, 0) = ((MR_Box) (eval__Id_539));
#line 518 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_544_544, 1) = ((MR_Box) (eval__V_545_545));
#line 518 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_544_544, 2) = ((MR_Box) (eval__V_546_546));
#line 518 "eval.m"
              }
#line 518 "eval.m"
              {
#line 518 "eval.m"
                eval__V_543_543 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 518 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_543_543, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 518 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_543_543, 1) = ((MR_Box) (eval__V_544_544));
#line 518 "eval.m"
              }
#line 518 "eval.m"
              {
#line 518 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_543_543, eval__Stack1_538);
              }
            }
#line 522 "eval.m"
          else
#line 522 "eval.m"
            {
#line 522 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 522 "eval.m"
              return;
            }
#line 522 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 43:
        {
#line 530 "eval.m"
          MR_Float eval__Exp_551;
#line 530 "eval.m"
          MR_Float eval__Cutoff_552;
#line 530 "eval.m"
          MR_Word eval__Colour_553;
#line 530 "eval.m"
          MR_Word eval__At_554;
#line 530 "eval.m"
          MR_Word eval__Pos_555;
#line 530 "eval.m"
          MR_Word eval__Stack1_556;
          MR_Word eval__V_558_558;
          MR_Word eval__V_559_559;
          MR_Word eval__V_560_560;
          MR_Word eval__V_561_561;
          MR_Word eval__V_562_562;
          MR_Word eval__V_563_563;
          MR_Word eval__V_564_564;
          MR_Word eval__V_565_565;
          MR_Word eval__V_566_566;

#line 526 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 526 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 526 "eval.m"
            {
#line 526 "eval.m"
              eval__V_558_558 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 526 "eval.m"
              eval__V_559_559 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 526 "eval.m"
            }
          if (eval__succeeded)
            {
#line 526 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_558_558) == MR_mktag((MR_Integer) 2));
#line 526 "eval.m"
              if ((MR_tag((MR_Word) eval__V_558_558) == MR_mktag((MR_Integer) 2)))
#line 526 "eval.m"
                eval__Exp_551 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_558_558, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 526 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_559_559) == MR_mktag((MR_Integer) 1));
#line 526 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_559_559) == MR_mktag((MR_Integer) 1)))
#line 526 "eval.m"
                    {
#line 526 "eval.m"
                      eval__V_560_560 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_559_559, (MR_Integer) 0)));
#line 526 "eval.m"
                      eval__V_561_561 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_559_559, (MR_Integer) 1)));
#line 526 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 526 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_560_560) == MR_mktag((MR_Integer) 2));
#line 526 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_560_560) == MR_mktag((MR_Integer) 2)))
#line 526 "eval.m"
                        eval__Cutoff_552 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_560_560, (MR_Integer) 0)));
                      if (eval__succeeded)
                        {
#line 526 "eval.m"
                          eval__succeeded = (MR_tag((MR_Word) eval__V_561_561) == MR_mktag((MR_Integer) 1));
#line 526 "eval.m"
                          if ((MR_tag((MR_Word) eval__V_561_561) == MR_mktag((MR_Integer) 1)))
#line 526 "eval.m"
                            {
#line 526 "eval.m"
                              eval__V_562_562 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_561_561, (MR_Integer) 0)));
#line 526 "eval.m"
                              eval__V_563_563 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_561_561, (MR_Integer) 1)));
#line 526 "eval.m"
                            }
                          if (eval__succeeded)
                            {
#line 526 "eval.m"
                              eval__succeeded = ((MR_tag((MR_Word) eval__V_562_562) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_562_562, (MR_Integer) 0))) == (MR_Integer) 3));
#line 526 "eval.m"
                              if (((MR_tag((MR_Word) eval__V_562_562) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_562_562, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 526 "eval.m"
                                eval__Colour_553 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_562_562, (MR_Integer) 1)));
                              if (eval__succeeded)
                                {
#line 526 "eval.m"
                                  eval__succeeded = (MR_tag((MR_Word) eval__V_563_563) == MR_mktag((MR_Integer) 1));
#line 526 "eval.m"
                                  if ((MR_tag((MR_Word) eval__V_563_563) == MR_mktag((MR_Integer) 1)))
#line 526 "eval.m"
                                    {
#line 526 "eval.m"
                                      eval__V_564_564 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_563_563, (MR_Integer) 0)));
#line 526 "eval.m"
                                      eval__V_565_565 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_563_563, (MR_Integer) 1)));
#line 526 "eval.m"
                                    }
                                  if (eval__succeeded)
                                    {
#line 527 "eval.m"
                                      eval__succeeded = ((MR_tag((MR_Word) eval__V_564_564) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_564_564, (MR_Integer) 0))) == (MR_Integer) 3));
#line 527 "eval.m"
                                      if (((MR_tag((MR_Word) eval__V_564_564) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_564_564, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 527 "eval.m"
                                        eval__At_554 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_564_564, (MR_Integer) 1)));
                                      if (eval__succeeded)
                                        {
#line 527 "eval.m"
                                          eval__succeeded = (MR_tag((MR_Word) eval__V_565_565) == MR_mktag((MR_Integer) 1));
#line 527 "eval.m"
                                          if ((MR_tag((MR_Word) eval__V_565_565) == MR_mktag((MR_Integer) 1)))
#line 527 "eval.m"
                                            {
#line 527 "eval.m"
                                              eval__V_566_566 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_565_565, (MR_Integer) 0)));
#line 527 "eval.m"
                                              eval__Stack1_556 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_565_565, (MR_Integer) 1)));
#line 527 "eval.m"
                                            }
                                          if (eval__succeeded)
                                            {
#line 527 "eval.m"
                                              eval__succeeded = ((MR_tag((MR_Word) eval__V_566_566) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_566_566, (MR_Integer) 0))) == (MR_Integer) 3));
#line 527 "eval.m"
                                              if (((MR_tag((MR_Word) eval__V_566_566) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_566_566, (MR_Integer) 0))) == (MR_Integer) 3)))
#line 527 "eval.m"
                                                eval__Pos_555 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_566_566, (MR_Integer) 1)));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
#line 530 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_567_567;
              MR_Word eval__V_568_568;

#line 528 "eval.m"
              {
#line 528 "eval.m"
                eval__V_568_568 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 5 * sizeof(MR_Word)), "spotlight"));
#line 528 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_568_568, 0) = ((MR_Box) (eval__Pos_555));
#line 528 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_568_568, 1) = ((MR_Box) (eval__At_554));
#line 528 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_568_568, 2) = ((MR_Box) (eval__Colour_553));
#line 528 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_568_568, 3) = MR_box_float(eval__Cutoff_552);
#line 528 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_568_568, 4) = MR_box_float(eval__Exp_551);
#line 528 "eval.m"
              }
#line 528 "eval.m"
              {
#line 528 "eval.m"
                eval__V_567_567 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "light"));
#line 528 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_567_567, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 5));
#line 528 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_567_567, 1) = ((MR_Box) (eval__V_568_568));
#line 528 "eval.m"
              }
#line 528 "eval.m"
              {
#line 528 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_567_567, eval__Stack1_556);
              }
            }
#line 530 "eval.m"
          else
#line 531 "eval.m"
            {
#line 531 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 531 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 44:
        {
#line 536 "eval.m"
          MR_Float eval__N_572;
#line 536 "eval.m"
          MR_Word eval__Stack1_573;
          MR_Word eval__V_576_576;
          MR_Float eval__V_659_659;

#line 534 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 534 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 534 "eval.m"
            {
#line 534 "eval.m"
              eval__V_576_576 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 534 "eval.m"
              eval__Stack1_573 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 534 "eval.m"
            }
          if (eval__succeeded)
            {
#line 534 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_576_576) == MR_mktag((MR_Integer) 2));
#line 534 "eval.m"
              if ((MR_tag((MR_Word) eval__V_576_576) == MR_mktag((MR_Integer) 2)))
#line 534 "eval.m"
                eval__N_572 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_576_576, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 534 "eval.m"
                  eval__V_659_659 = (MR_Float) 0.00000000000000;
#line 534 "eval.m"
                  eval__succeeded = (eval__N_572 >= eval__V_659_659);
                }
            }
#line 536 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_577_577;
              MR_Float eval__V_578_578;

#line 535 "eval.m"
              {
#line 535 "eval.m"
                eval__V_578_578 = op__op_sqrt_2_f_0(eval__N_572);
              }
#line 535 "eval.m"
              {
#line 535 "eval.m"
                eval__V_577_577 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 535 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_577_577, 0) = MR_box_float(eval__V_578_578);
#line 535 "eval.m"
              }
#line 535 "eval.m"
              {
#line 535 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_577_577, eval__Stack1_573);
              }
            }
#line 536 "eval.m"
          else
#line 537 "eval.m"
            {
#line 537 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 537 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 45:
        {
#line 542 "eval.m"
          MR_Integer eval__N2_582;
#line 542 "eval.m"
          MR_Integer eval__N1_583;
#line 542 "eval.m"
          MR_Word eval__Stack1_584;
          MR_Word eval__V_586_586;
          MR_Word eval__V_587_587;
          MR_Word eval__V_588_588;

#line 540 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 540 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 540 "eval.m"
            {
#line 540 "eval.m"
              eval__V_586_586 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 540 "eval.m"
              eval__V_587_587 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 540 "eval.m"
            }
          if (eval__succeeded)
            {
#line 540 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_586_586) == MR_mktag((MR_Integer) 1));
#line 540 "eval.m"
              if ((MR_tag((MR_Word) eval__V_586_586) == MR_mktag((MR_Integer) 1)))
#line 540 "eval.m"
                eval__N2_582 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_586_586, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 540 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_587_587) == MR_mktag((MR_Integer) 1));
#line 540 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_587_587) == MR_mktag((MR_Integer) 1)))
#line 540 "eval.m"
                    {
#line 540 "eval.m"
                      eval__V_588_588 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_587_587, (MR_Integer) 0)));
#line 540 "eval.m"
                      eval__Stack1_584 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_587_587, (MR_Integer) 1)));
#line 540 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 540 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_588_588) == MR_mktag((MR_Integer) 1));
#line 540 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_588_588) == MR_mktag((MR_Integer) 1)))
#line 540 "eval.m"
                        eval__N1_583 = ((MR_Integer) (MR_hl_field(MR_mktag(1), eval__V_588_588, (MR_Integer) 0)));
                    }
                }
            }
#line 542 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_589_589;
              MR_Integer eval__V_590_590;

#line 541 "eval.m"
              {
#line 541 "eval.m"
                eval__V_590_590 = op__op_subi_3_f_0(eval__N1_583, eval__N2_582);
              }
#line 541 "eval.m"
              {
#line 541 "eval.m"
                eval__V_589_589 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "int"));
#line 541 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_589_589, 0) = ((MR_Box) (eval__V_590_590));
#line 541 "eval.m"
              }
#line 541 "eval.m"
              {
#line 541 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_589_589, eval__Stack1_584);
              }
            }
#line 542 "eval.m"
          else
            {
              MR_Word eval__V_591_591 = (MR_Word) &eval__const_9_0_1_V_591_591;
              MR_Word eval__V_592_592 = (MR_Integer) 45;

#line 543 "eval.m"
              {
#line 543 "eval.m"
                eval__empty_stack_3_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3, eval__V_591_591);
#line 543 "eval.m"
                return;
              }
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 46:
        {
#line 548 "eval.m"
          MR_Float eval__N2_596;
#line 548 "eval.m"
          MR_Float eval__N1_597;
#line 548 "eval.m"
          MR_Word eval__Stack1_598;
          MR_Word eval__V_600_600;
          MR_Word eval__V_601_601;
          MR_Word eval__V_602_602;

#line 546 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 546 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 546 "eval.m"
            {
#line 546 "eval.m"
              eval__V_600_600 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 546 "eval.m"
              eval__V_601_601 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 546 "eval.m"
            }
          if (eval__succeeded)
            {
#line 546 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_600_600) == MR_mktag((MR_Integer) 2));
#line 546 "eval.m"
              if ((MR_tag((MR_Word) eval__V_600_600) == MR_mktag((MR_Integer) 2)))
#line 546 "eval.m"
                eval__N2_596 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_600_600, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 546 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_601_601) == MR_mktag((MR_Integer) 1));
#line 546 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_601_601) == MR_mktag((MR_Integer) 1)))
#line 546 "eval.m"
                    {
#line 546 "eval.m"
                      eval__V_602_602 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_601_601, (MR_Integer) 0)));
#line 546 "eval.m"
                      eval__Stack1_598 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_601_601, (MR_Integer) 1)));
#line 546 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 546 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_602_602) == MR_mktag((MR_Integer) 2));
#line 546 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_602_602) == MR_mktag((MR_Integer) 2)))
#line 546 "eval.m"
                        eval__N1_597 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_602_602, (MR_Integer) 0)));
                    }
                }
            }
#line 548 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_603_603;
              MR_Float eval__V_604_604;

#line 547 "eval.m"
              {
#line 547 "eval.m"
                eval__V_604_604 = op__op_subf_3_f_0(eval__N1_597, eval__N2_596);
              }
#line 547 "eval.m"
              {
#line 547 "eval.m"
                eval__V_603_603 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 547 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_603_603, 0) = MR_box_float(eval__V_604_604);
#line 547 "eval.m"
              }
#line 547 "eval.m"
              {
#line 547 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_603_603, eval__Stack1_598);
              }
            }
#line 548 "eval.m"
          else
            {
              MR_Word eval__V_605_605 = (MR_Word) &eval__const_9_0_2_V_605_605;
              MR_Word eval__V_606_606 = (MR_Integer) 46;

#line 549 "eval.m"
              {
#line 549 "eval.m"
                eval__empty_stack_3_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3, eval__V_605_605);
#line 549 "eval.m"
                return;
              }
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 47:
#line 556 "eval.m"
        {
#line 556 "eval.m"
          MR_Float eval__Z_610;
#line 556 "eval.m"
          MR_Float eval__Y_611;
#line 556 "eval.m"
          MR_Float eval__X_612;
#line 556 "eval.m"
          MR_Word eval__Obj0_613;
#line 556 "eval.m"
          MR_Word eval__Stack1_614;
          MR_Word eval__V_618_618;
          MR_Word eval__V_619_619;
          MR_Word eval__V_620_620;
          MR_Word eval__V_621_621;
          MR_Word eval__V_622_622;
          MR_Word eval__V_623_623;
          MR_Word eval__V_624_624;

#line 552 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 552 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 552 "eval.m"
            {
#line 552 "eval.m"
              eval__V_618_618 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 552 "eval.m"
              eval__V_619_619 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 552 "eval.m"
            }
          if (eval__succeeded)
            {
#line 552 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_618_618) == MR_mktag((MR_Integer) 2));
#line 552 "eval.m"
              if ((MR_tag((MR_Word) eval__V_618_618) == MR_mktag((MR_Integer) 2)))
#line 552 "eval.m"
                eval__Z_610 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_618_618, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 552 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_619_619) == MR_mktag((MR_Integer) 1));
#line 552 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_619_619) == MR_mktag((MR_Integer) 1)))
#line 552 "eval.m"
                    {
#line 552 "eval.m"
                      eval__V_620_620 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_619_619, (MR_Integer) 0)));
#line 552 "eval.m"
                      eval__V_621_621 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_619_619, (MR_Integer) 1)));
#line 552 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 552 "eval.m"
                      eval__succeeded = (MR_tag((MR_Word) eval__V_620_620) == MR_mktag((MR_Integer) 2));
#line 552 "eval.m"
                      if ((MR_tag((MR_Word) eval__V_620_620) == MR_mktag((MR_Integer) 2)))
#line 552 "eval.m"
                        eval__Y_611 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_620_620, (MR_Integer) 0)));
                      if (eval__succeeded)
                        {
#line 552 "eval.m"
                          eval__succeeded = (MR_tag((MR_Word) eval__V_621_621) == MR_mktag((MR_Integer) 1));
#line 552 "eval.m"
                          if ((MR_tag((MR_Word) eval__V_621_621) == MR_mktag((MR_Integer) 1)))
#line 552 "eval.m"
                            {
#line 552 "eval.m"
                              eval__V_622_622 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_621_621, (MR_Integer) 0)));
#line 552 "eval.m"
                              eval__V_623_623 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_621_621, (MR_Integer) 1)));
#line 552 "eval.m"
                            }
                          if (eval__succeeded)
                            {
#line 552 "eval.m"
                              eval__succeeded = (MR_tag((MR_Word) eval__V_622_622) == MR_mktag((MR_Integer) 2));
#line 552 "eval.m"
                              if ((MR_tag((MR_Word) eval__V_622_622) == MR_mktag((MR_Integer) 2)))
#line 552 "eval.m"
                                eval__X_612 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_622_622, (MR_Integer) 0)));
                              if (eval__succeeded)
                                {
#line 552 "eval.m"
                                  eval__succeeded = (MR_tag((MR_Word) eval__V_623_623) == MR_mktag((MR_Integer) 1));
#line 552 "eval.m"
                                  if ((MR_tag((MR_Word) eval__V_623_623) == MR_mktag((MR_Integer) 1)))
#line 552 "eval.m"
                                    {
#line 552 "eval.m"
                                      eval__V_624_624 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_623_623, (MR_Integer) 0)));
#line 552 "eval.m"
                                      eval__Stack1_614 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_623_623, (MR_Integer) 1)));
#line 552 "eval.m"
                                    }
                                  if (eval__succeeded)
                                    {
#line 552 "eval.m"
                                      eval__succeeded = ((MR_tag((MR_Word) eval__V_624_624) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_624_624, (MR_Integer) 0))) == (MR_Integer) 4));
#line 552 "eval.m"
                                      if (((MR_tag((MR_Word) eval__V_624_624) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_624_624, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 552 "eval.m"
                                        eval__Obj0_613 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_624_624, (MR_Integer) 1)));
                                    }
                                }
                            }
                        }
                    }
                }
            }
#line 556 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__Obj_615;
              MR_Word eval__V_625_625;
              MR_Word eval__V_626_626;
              MR_Word eval__V_627_627;

#line 553 "eval.m"
              {
#line 553 "eval.m"
                eval__renameObject_4_p_0(eval__Obj0_613, &eval__Obj_615);
              }
#line 554 "eval.m"
              {
#line 554 "eval.m"
                eval__V_627_627 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "translate");
#line 554 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_627_627, 0) = MR_box_float(eval__X_612);
#line 554 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_627_627, 1) = MR_box_float(eval__Y_611);
#line 554 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_627_627, 2) = MR_box_float(eval__Z_610);
#line 554 "eval.m"
              }
#line 554 "eval.m"
              {
#line 554 "eval.m"
                eval__V_626_626 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "transform"));
#line 554 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_626_626, 0) = ((MR_Box) (eval__Obj_615));
#line 554 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_626_626, 1) = ((MR_Box) (eval__V_627_627));
#line 554 "eval.m"
              }
#line 554 "eval.m"
              {
#line 554 "eval.m"
                eval__V_625_625 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 554 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_625_625, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 554 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_625_625, 1) = ((MR_Box) (eval__V_626_626));
#line 554 "eval.m"
              }
#line 554 "eval.m"
              {
#line 554 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_625_625, eval__Stack1_614);
              }
            }
#line 556 "eval.m"
          else
#line 556 "eval.m"
            {
#line 556 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 556 "eval.m"
              return;
            }
#line 556 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 48:
        {
#line 562 "eval.m"
          MR_Word eval__O2_631;
#line 562 "eval.m"
          MR_Word eval__O1_632;
#line 562 "eval.m"
          MR_Word eval__Stack1_633;
          MR_Word eval__V_635_635;
          MR_Word eval__V_636_636;
          MR_Word eval__V_637_637;

#line 560 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 560 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 560 "eval.m"
            {
#line 560 "eval.m"
              eval__V_635_635 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 560 "eval.m"
              eval__V_636_636 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 560 "eval.m"
            }
          if (eval__succeeded)
            {
#line 560 "eval.m"
              eval__succeeded = ((MR_tag((MR_Word) eval__V_635_635) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_635_635, (MR_Integer) 0))) == (MR_Integer) 4));
#line 560 "eval.m"
              if (((MR_tag((MR_Word) eval__V_635_635) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_635_635, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 560 "eval.m"
                eval__O2_631 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_635_635, (MR_Integer) 1)));
              if (eval__succeeded)
                {
#line 560 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_636_636) == MR_mktag((MR_Integer) 1));
#line 560 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_636_636) == MR_mktag((MR_Integer) 1)))
#line 560 "eval.m"
                    {
#line 560 "eval.m"
                      eval__V_637_637 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_636_636, (MR_Integer) 0)));
#line 560 "eval.m"
                      eval__Stack1_633 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_636_636, (MR_Integer) 1)));
#line 560 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 560 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__V_637_637) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_637_637, (MR_Integer) 0))) == (MR_Integer) 4));
#line 560 "eval.m"
                      if (((MR_tag((MR_Word) eval__V_637_637) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_637_637, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 560 "eval.m"
                        eval__O1_632 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_637_637, (MR_Integer) 1)));
                    }
                }
            }
#line 562 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__V_638_638;
              MR_Word eval__V_639_639;

#line 561 "eval.m"
              {
#line 561 "eval.m"
                eval__V_639_639 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "union"));
#line 561 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_639_639, 0) = ((MR_Box) (eval__O1_632));
#line 561 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_639_639, 1) = ((MR_Box) (eval__O2_631));
#line 561 "eval.m"
              }
#line 561 "eval.m"
              {
#line 561 "eval.m"
                eval__V_638_638 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 561 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_638_638, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 561 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_638_638, 1) = ((MR_Box) (eval__V_639_639));
#line 561 "eval.m"
              }
#line 561 "eval.m"
              {
#line 561 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_638_638, eval__Stack1_633);
              }
            }
#line 562 "eval.m"
          else
#line 563 "eval.m"
            {
#line 563 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 563 "eval.m"
              return;
            }
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
      case (MR_Integer) 49:
#line 569 "eval.m"
        {
#line 569 "eval.m"
          MR_Float eval__S_643;
#line 569 "eval.m"
          MR_Word eval__Obj0_644;
#line 569 "eval.m"
          MR_Word eval__Stack1_645;
          MR_Word eval__V_649_649;
          MR_Word eval__V_650_650;
          MR_Word eval__V_651_651;

#line 566 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 566 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 566 "eval.m"
            {
#line 566 "eval.m"
              eval__V_649_649 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 566 "eval.m"
              eval__V_650_650 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 566 "eval.m"
            }
          if (eval__succeeded)
            {
#line 566 "eval.m"
              eval__succeeded = (MR_tag((MR_Word) eval__V_649_649) == MR_mktag((MR_Integer) 2));
#line 566 "eval.m"
              if ((MR_tag((MR_Word) eval__V_649_649) == MR_mktag((MR_Integer) 2)))
#line 566 "eval.m"
                eval__S_643 = MR_unbox_float((MR_hl_field(MR_mktag(2), eval__V_649_649, (MR_Integer) 0)));
              if (eval__succeeded)
                {
#line 566 "eval.m"
                  eval__succeeded = (MR_tag((MR_Word) eval__V_650_650) == MR_mktag((MR_Integer) 1));
#line 566 "eval.m"
                  if ((MR_tag((MR_Word) eval__V_650_650) == MR_mktag((MR_Integer) 1)))
#line 566 "eval.m"
                    {
#line 566 "eval.m"
                      eval__V_651_651 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_650_650, (MR_Integer) 0)));
#line 566 "eval.m"
                      eval__Stack1_645 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__V_650_650, (MR_Integer) 1)));
#line 566 "eval.m"
                    }
                  if (eval__succeeded)
                    {
#line 566 "eval.m"
                      eval__succeeded = ((MR_tag((MR_Word) eval__V_651_651) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_651_651, (MR_Integer) 0))) == (MR_Integer) 4));
#line 566 "eval.m"
                      if (((MR_tag((MR_Word) eval__V_651_651) == MR_mktag((MR_Integer) 3)) && (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__V_651_651, (MR_Integer) 0))) == (MR_Integer) 4)))
#line 566 "eval.m"
                        eval__Obj0_644 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__V_651_651, (MR_Integer) 1)));
                    }
                }
            }
#line 569 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__Obj_646;
              MR_Word eval__V_652_652;
              MR_Word eval__V_653_653;
              MR_Word eval__V_654_654;

#line 567 "eval.m"
              {
#line 567 "eval.m"
                eval__renameObject_4_p_0(eval__Obj0_644, &eval__Obj_646);
              }
#line 568 "eval.m"
              {
#line 568 "eval.m"
                eval__V_654_654 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "uscale"));
#line 568 "eval.m"
                MR_hl_field(MR_mktag(2), eval__V_654_654, 0) = MR_box_float(eval__S_643);
#line 568 "eval.m"
              }
#line 568 "eval.m"
              {
#line 568 "eval.m"
                eval__V_653_653 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "transform"));
#line 568 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_653_653, 0) = ((MR_Box) (eval__Obj_646));
#line 568 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_653_653, 1) = ((MR_Box) (eval__V_654_654));
#line 568 "eval.m"
              }
#line 568 "eval.m"
              {
#line 568 "eval.m"
                eval__V_652_652 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "object"));
#line 568 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_652_652, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 4));
#line 568 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_652_652, 1) = ((MR_Box) (eval__V_653_653));
#line 568 "eval.m"
              }
#line 568 "eval.m"
              {
#line 568 "eval.m"
                *eval__HeadVar__4_4 = eval__push_3_f_0(eval__V_652_652, eval__Stack1_645);
              }
            }
#line 569 "eval.m"
          else
#line 569 "eval.m"
            {
#line 569 "eval.m"
              eval__eval_error_2_p_0(eval__HeadVar__2_2, eval__HeadVar__3_3);
#line 569 "eval.m"
              return;
            }
#line 569 "eval.m"
        }
#line 221 "eval.m"
        break;
#line 221 "eval.m"
    }
#line 221 "eval.m"
  }
#line 218 "eval.m"
}
#line 185 "eval.m"
static /* final */ const MR_Box eval__const_8_0_1_V_27_27[2] = {
		((MR_Box) ((MR_String) "' is unknown")),
		((MR_Box) (MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))};

#line 172 "eval.m"
static void MR_CALL eval__do_token_7_p_0(
#line 172 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 172 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 172 "eval.m"
  MR_Word eval__HeadVar__3_3,
#line 172 "eval.m"
  MR_Word * eval__HeadVar__4_4,
#line 172 "eval.m"
  MR_Word * eval__HeadVar__5_5)
#line 172 "eval.m"
{
#line 174 "eval.m"
  {
#line 174 "eval.m"
    bool eval__succeeded;

#line 174 "eval.m"
#line 174 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__1_1)) {
#line 174 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 174 "eval.m"
      case (MR_Integer) 3:
#line 174 "eval.m"
#line 174 "eval.m"
        switch (((int) (MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 0)))) {
#line 174 "eval.m"
          default: /*NOTREACHED*/ MR_assert(0);
#line 174 "eval.m"
          case (MR_Integer) 0:
            {
              MR_Word eval__Bool_39 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word eval__V_45_45;

#line 200 "eval.m"
              {
#line 200 "eval.m"
                eval__V_45_45 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "boolean");
#line 200 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_45_45, 0) = ((MR_Box) (eval__Bool_39));
#line 200 "eval.m"
              }
#line 744 "eval.m"
              {
#line 744 "eval.m"
                *eval__HeadVar__5_5 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 744 "eval.m"
                MR_hl_field(MR_mktag(1), *eval__HeadVar__5_5, 0) = ((MR_Box) (eval__V_45_45));
#line 744 "eval.m"
                MR_hl_field(MR_mktag(1), *eval__HeadVar__5_5, 1) = ((MR_Box) (eval__HeadVar__3_3));
#line 744 "eval.m"
              }
#line 199 "eval.m"
              *eval__HeadVar__4_4 = eval__HeadVar__2_2;
            }
#line 174 "eval.m"
            break;
#line 174 "eval.m"
          case (MR_Integer) 1:
            {
              MR_Word eval__V_81_81 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));

#line 174 "eval.m"
              if ((MR_tag((MR_Word) eval__V_81_81) == MR_mktag((MR_Integer) 0)))
                {
                  MR_Integer eval__Int_46 = ((MR_Integer) (MR_hl_field(MR_mktag(0), eval__V_81_81, (MR_Integer) 0)));
                  MR_Word eval__V_52_52;

#line 203 "eval.m"
                  {
#line 203 "eval.m"
                    eval__V_52_52 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "int"));
#line 203 "eval.m"
                    MR_hl_field(MR_mktag(1), eval__V_52_52, 0) = ((MR_Box) (eval__Int_46));
#line 203 "eval.m"
                  }
#line 203 "eval.m"
                  {
#line 203 "eval.m"
                    *eval__HeadVar__5_5 = eval__push_3_f_0(eval__V_52_52, eval__HeadVar__3_3);
                  }
#line 202 "eval.m"
                  *eval__HeadVar__4_4 = eval__HeadVar__2_2;
                }
#line 174 "eval.m"
              else
#line 174 "eval.m"
                {
                  MR_Float eval__Real_54 = MR_unbox_float((MR_hl_field(MR_mktag(1), eval__V_81_81, (MR_Integer) 0)));
                  MR_Word eval__V_60_60;

#line 206 "eval.m"
                  {
#line 206 "eval.m"
                    eval__V_60_60 = (MR_Word) MR_mkword(MR_mktag(2), MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "real"));
#line 206 "eval.m"
                    MR_hl_field(MR_mktag(2), eval__V_60_60, 0) = MR_box_float(eval__Real_54);
#line 206 "eval.m"
                  }
#line 206 "eval.m"
                  {
#line 206 "eval.m"
                    *eval__HeadVar__5_5 = eval__push_3_f_0(eval__V_60_60, eval__HeadVar__3_3);
                  }
#line 205 "eval.m"
                  *eval__HeadVar__4_4 = eval__HeadVar__2_2;
#line 174 "eval.m"
                }
            }
#line 174 "eval.m"
            break;
#line 174 "eval.m"
          case (MR_Integer) 2:
            {
              MR_String eval__String_62 = ((MR_String) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));
              MR_Word eval__V_68_68;

#line 209 "eval.m"
              {
#line 209 "eval.m"
                eval__V_68_68 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "string"));
#line 209 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_68_68, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 0));
#line 209 "eval.m"
                MR_hl_field(MR_mktag(3), eval__V_68_68, 1) = ((MR_Box) (eval__String_62));
#line 209 "eval.m"
              }
#line 209 "eval.m"
              {
#line 209 "eval.m"
                *eval__HeadVar__5_5 = eval__push_3_f_0(eval__V_68_68, eval__HeadVar__3_3);
              }
#line 208 "eval.m"
              *eval__HeadVar__4_4 = eval__HeadVar__2_2;
            }
#line 174 "eval.m"
            break;
#line 174 "eval.m"
          case (MR_Integer) 3:
            {
              MR_Word eval__Operator_69 = ((MR_Word) (MR_hl_field(MR_mktag(3), eval__HeadVar__1_1, (MR_Integer) 1)));

#line 211 "eval.m"
              *eval__HeadVar__4_4 = eval__HeadVar__2_2;
#line 213 "eval.m"
              {
#line 213 "eval.m"
                eval__do_extra_6_p_0(eval__Operator_69, eval__HeadVar__2_2, eval__HeadVar__3_3, eval__HeadVar__5_5);
#line 213 "eval.m"
                return;
              }
            }
#line 174 "eval.m"
            break;
#line 174 "eval.m"
        }
#line 174 "eval.m"
        break;
#line 174 "eval.m"
      case (MR_Integer) 0:
        {
          MR_Word eval__Operator_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 0)));

#line 174 "eval.m"
          *eval__HeadVar__4_4 = eval__HeadVar__2_2;
#line 176 "eval.m"
          {
#line 176 "eval.m"
            eval__do_op_6_p_0(eval__Operator_8, eval__HeadVar__2_2, eval__HeadVar__3_3, eval__HeadVar__5_5);
#line 176 "eval.m"
            return;
          }
        }
#line 174 "eval.m"
        break;
#line 174 "eval.m"
      case (MR_Integer) 1:
        {
          MR_String eval__Id_15 = ((MR_String) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 183 "eval.m"
          MR_Word eval__Val_20;
          MR_Word eval__TypeInfo_76_76 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
          MR_Word eval__TypeInfo_77_77 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
#line 179 "eval.m"
          MR_Box eval__conv1_Val_20;

#line 179 "eval.m"
          {
#line 179 "eval.m"
            eval__succeeded = mercury__map__search_3_p_0(eval__TypeInfo_76_76, eval__TypeInfo_77_77, eval__HeadVar__2_2, ((MR_Box) (eval__Id_15)), &eval__conv1_Val_20);
          }
#line 179 "eval.m"
          if (eval__succeeded)
#line 179 "eval.m"
            {
#line 179 "eval.m"
              eval__Val_20 = ((MR_Word) eval__conv1_Val_20);
#line 179 "eval.m"
              eval__succeeded = TRUE;
#line 179 "eval.m"
            }
#line 183 "eval.m"
          if (eval__succeeded)
            {
#line 744 "eval.m"
              {
#line 744 "eval.m"
                *eval__HeadVar__5_5 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 744 "eval.m"
                MR_hl_field(MR_mktag(1), *eval__HeadVar__5_5, 0) = ((MR_Box) (eval__Val_20));
#line 744 "eval.m"
                MR_hl_field(MR_mktag(1), *eval__HeadVar__5_5, 1) = ((MR_Box) (eval__HeadVar__3_3));
#line 744 "eval.m"
              }
#line 182 "eval.m"
              *eval__HeadVar__4_4 = eval__HeadVar__2_2;
            }
#line 183 "eval.m"
          else
            {
              MR_Word eval__V_22_22;
              MR_String eval__V_23_23;
              MR_Word eval__V_24_24;
              MR_String eval__V_25_25 = (MR_String) "identifier `";
              MR_Word eval__V_26_26;
              MR_Word eval__V_27_27 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_8_0_1_V_27_27);
              MR_String eval__V_28_28 = (MR_String) "' is unknown";
              MR_Word eval__V_29_29 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
              MR_Word eval__TypeInfo_78_78;

#line 185 "eval.m"
              {
#line 185 "eval.m"
                eval__V_26_26 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 185 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_26_26, 0) = ((MR_Box) (eval__Id_15));
#line 185 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_26_26, 1) = ((MR_Box) (eval__V_27_27));
#line 185 "eval.m"
              }
#line 184 "eval.m"
              {
#line 184 "eval.m"
                eval__V_24_24 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 184 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_24_24, 0) = ((MR_Box) (eval__V_25_25));
#line 184 "eval.m"
                MR_hl_field(MR_mktag(1), eval__V_24_24, 1) = ((MR_Box) (eval__V_26_26));
#line 184 "eval.m"
              }
#line 184 "eval.m"
              {
#line 184 "eval.m"
                eval__V_23_23 = mercury__string__append_list_2_f_0(eval__V_24_24);
              }
#line 184 "eval.m"
              {
#line 184 "eval.m"
                eval__V_22_22 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "program_error");
#line 184 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_22_22, 0) = ((MR_Box) (eval__V_23_23));
#line 184 "eval.m"
              }
              eval__TypeInfo_78_78 = (MR_Word) (&eval__eval__type_ctor_info_program_error_0);
#line 184 "eval.m"
              {
#line 184 "eval.m"
                mercury__exception__throw_1_p_0(eval__TypeInfo_78_78, ((MR_Box) (eval__V_22_22)));
#line 184 "eval.m"
                return;
              }
            }
        }
#line 174 "eval.m"
        break;
#line 174 "eval.m"
      case (MR_Integer) 2:
        {
          MR_String eval__Id_30 = ((MR_String) (MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 196 "eval.m"
          MR_Word eval__Val_35;
#line 196 "eval.m"
          MR_Word eval__Stack1_36;

#line 746 "eval.m"
          eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1));
#line 746 "eval.m"
          if ((MR_tag((MR_Word) eval__HeadVar__3_3) == MR_mktag((MR_Integer) 1)))
#line 746 "eval.m"
            {
#line 746 "eval.m"
              eval__Val_35 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 0)));
#line 746 "eval.m"
              eval__Stack1_36 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, (MR_Integer) 1)));
#line 746 "eval.m"
            }
#line 196 "eval.m"
          if (eval__succeeded)
            {
              MR_Word eval__TypeInfo_79_79;
              MR_Word eval__TypeInfo_80_80;

#line 189 "eval.m"
              *eval__HeadVar__5_5 = eval__Stack1_36;
              eval__TypeInfo_79_79 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
              eval__TypeInfo_80_80 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
              {
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
                mercury__tree234__set_4_p_1(eval__TypeInfo_79_79, eval__TypeInfo_80_80, eval__HeadVar__2_2, ((MR_Box) (eval__Id_30)), ((MR_Box) (eval__Val_35)), eval__HeadVar__4_4);
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
                return;
              }
            }
#line 196 "eval.m"
          else
            {
              MR_Word eval__V_91_91;
              MR_String eval__V_92_92 = (MR_String) "empty stack";
              MR_Word eval__TypeInfo_9_93;

#line 782 "eval.m"
              {
#line 782 "eval.m"
                eval__V_91_91 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 4 * sizeof(MR_Word)), "stack_env_token_exception");
#line 782 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_91_91, 0) = ((MR_Box) (eval__V_92_92));
#line 782 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_91_91, 1) = ((MR_Box) (eval__HeadVar__2_2));
#line 782 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_91_91, 2) = ((MR_Box) (eval__HeadVar__3_3));
#line 782 "eval.m"
                MR_hl_field(MR_mktag(0), eval__V_91_91, 3) = ((MR_Box) (eval__HeadVar__1_1));
#line 782 "eval.m"
              }
              eval__TypeInfo_9_93 = (MR_Word) (&eval__eval__type_ctor_info_stack_env_token_exception_0);
#line 782 "eval.m"
              {
#line 782 "eval.m"
                mercury__exception__throw_1_p_0(eval__TypeInfo_9_93, ((MR_Box) (eval__V_91_91)));
#line 782 "eval.m"
                return;
              }
            }
        }
#line 174 "eval.m"
        break;
#line 174 "eval.m"
    }
#line 174 "eval.m"
  }
#line 172 "eval.m"
}

#line 155 "eval.m"
static void MR_CALL eval__do_token_group_7_p_0(
#line 155 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 155 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 155 "eval.m"
  MR_Word eval__HeadVar__3_3,
#line 155 "eval.m"
  MR_Word * eval__HeadVar__4_4,
#line 155 "eval.m"
  MR_Word * eval__HeadVar__5_5)
#line 155 "eval.m"
{
#line 158 "eval.m"
  {
#line 158 "eval.m"
    bool eval__succeeded;

#line 158 "eval.m"
#line 158 "eval.m"
    switch (MR_tag((MR_Word) eval__HeadVar__1_1)) {
#line 158 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 158 "eval.m"
      case (MR_Integer) 0:
        {
          MR_Word eval__Token_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), eval__HeadVar__1_1, (MR_Integer) 0)));

#line 159 "eval.m"
          {
#line 159 "eval.m"
            eval__do_token_7_p_0(eval__Token_8, eval__HeadVar__2_2, eval__HeadVar__3_3, eval__HeadVar__4_4, eval__HeadVar__5_5);
#line 159 "eval.m"
            return;
          }
        }
#line 158 "eval.m"
        break;
#line 158 "eval.m"
      case (MR_Integer) 1:
        {
          MR_Word eval__TokenList_15 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word eval__V_22_22;

#line 165 "eval.m"
          {
#line 165 "eval.m"
            eval__V_22_22 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "closure"));
#line 165 "eval.m"
            MR_hl_field(MR_mktag(3), eval__V_22_22, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 1));
#line 165 "eval.m"
            MR_hl_field(MR_mktag(3), eval__V_22_22, 1) = ((MR_Box) (eval__HeadVar__2_2));
#line 165 "eval.m"
            MR_hl_field(MR_mktag(3), eval__V_22_22, 2) = ((MR_Box) (eval__TokenList_15));
#line 165 "eval.m"
          }
#line 744 "eval.m"
          {
#line 744 "eval.m"
            *eval__HeadVar__5_5 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 744 "eval.m"
            MR_hl_field(MR_mktag(1), *eval__HeadVar__5_5, 0) = ((MR_Box) (eval__V_22_22));
#line 744 "eval.m"
            MR_hl_field(MR_mktag(1), *eval__HeadVar__5_5, 1) = ((MR_Box) (eval__HeadVar__3_3));
#line 744 "eval.m"
          }
#line 160 "eval.m"
          *eval__HeadVar__4_4 = eval__HeadVar__2_2;
        }
#line 158 "eval.m"
        break;
#line 158 "eval.m"
      case (MR_Integer) 2:
        {
          MR_Word eval__TokenList_23 = ((MR_Word) (MR_hl_field(MR_mktag(2), eval__HeadVar__1_1, (MR_Integer) 0)));
          MR_Word eval__ArrayStack_29;
          MR_Word eval__V_32_32;
          MR_Array eval__V_33_33;
          MR_Word eval__V_34_34;
          MR_Word eval__V_35_35 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
          MR_Word eval__TypeInfo_36_36;
          MR_Word eval__TypeInfo_37_37;
          MR_Word eval__V_5_42;
#line 168 "eval.m"
          MR_Word eval___ResultEnv_28;
#line 67 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          MR_Array eval__conv1_V_33_33;

#line 168 "eval.m"
          {
#line 168 "eval.m"
            eval__interpret_7_p_0(eval__TokenList_23, eval__HeadVar__2_2, eval__V_35_35, &eval___ResultEnv_28, &eval__ArrayStack_29);
          }
          eval__TypeInfo_37_37 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
#line 97 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          eval__V_5_42 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          {
#line 98 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
            mercury__list__reverse_2_3_p_0(eval__TypeInfo_37_37, eval__ArrayStack_29, eval__V_5_42, &eval__V_34_34);
          }
          eval__TypeInfo_36_36 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
#line 67 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          {
#line 67 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
            mercury__array__from_list_2_p_0(eval__TypeInfo_36_36, eval__V_34_34, &eval__conv1_V_33_33);
          }
#line 67 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/array.opt"
          eval__V_33_33 = (MR_Array) eval__conv1_V_33_33;
#line 169 "eval.m"
          {
#line 169 "eval.m"
            eval__V_32_32 = (MR_Word) MR_mkword(MR_mktag(3), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "array"));
#line 169 "eval.m"
            MR_hl_field(MR_mktag(3), eval__V_32_32, 0) = ((MR_Box) (MR_Word) ((MR_Integer) 2));
#line 169 "eval.m"
            MR_hl_field(MR_mktag(3), eval__V_32_32, 1) = ((MR_Box) (eval__V_33_33));
#line 169 "eval.m"
          }
#line 744 "eval.m"
          {
#line 744 "eval.m"
            *eval__HeadVar__5_5 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 744 "eval.m"
            MR_hl_field(MR_mktag(1), *eval__HeadVar__5_5, 0) = ((MR_Box) (eval__V_32_32));
#line 744 "eval.m"
            MR_hl_field(MR_mktag(1), *eval__HeadVar__5_5, 1) = ((MR_Box) (eval__HeadVar__3_3));
#line 744 "eval.m"
          }
#line 167 "eval.m"
          *eval__HeadVar__4_4 = eval__HeadVar__2_2;
        }
#line 158 "eval.m"
        break;
#line 158 "eval.m"
    }
#line 158 "eval.m"
  }
#line 155 "eval.m"
}
#line 691 "eval.m"
static /* final */ const MR_Box eval__const_6_0_1_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 692 "eval.m"
static /* final */ const MR_Box eval__const_6_0_2_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 693 "eval.m"
static /* final */ const MR_Box eval__const_6_0_3_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 695 "eval.m"
static /* final */ const MR_Box eval__const_6_0_4_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 696 "eval.m"
static /* final */ const MR_Box eval__const_6_0_5_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 697 "eval.m"
static /* final */ const MR_Box eval__const_6_0_6_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 698 "eval.m"
static /* final */ const MR_Box eval__const_6_0_7_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 699 "eval.m"
static /* final */ const MR_Box eval__const_6_0_8_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 700 "eval.m"
static /* final */ const MR_Box eval__const_6_0_9_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 701 "eval.m"
static /* final */ const MR_Box eval__const_6_0_10_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 702 "eval.m"
static /* final */ const MR_Box eval__const_6_0_11_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 703 "eval.m"
static /* final */ const MR_Box eval__const_6_0_12_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 704 "eval.m"
static /* final */ const MR_Box eval__const_6_0_13_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 705 "eval.m"
static /* final */ const MR_Box eval__const_6_0_14_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 706 "eval.m"
static /* final */ const MR_Box eval__const_6_0_15_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 707 "eval.m"
static /* final */ const MR_Box eval__const_6_0_16_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 708 "eval.m"
static /* final */ const MR_Box eval__const_6_0_17_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 709 "eval.m"
static /* final */ const MR_Box eval__const_6_0_18_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 710 "eval.m"
static /* final */ const MR_Box eval__const_6_0_19_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 711 "eval.m"
static /* final */ const MR_Box eval__const_6_0_20_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 713 "eval.m"
static /* final */ const MR_Box eval__const_6_0_21_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 714 "eval.m"
static /* final */ const MR_Box eval__const_6_0_22_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 715 "eval.m"
static /* final */ const MR_Box eval__const_6_0_23_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 716 "eval.m"
static /* final */ const MR_Box eval__const_6_0_24_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 717 "eval.m"
static /* final */ const MR_Box eval__const_6_0_25_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 718 "eval.m"
static /* final */ const MR_Box eval__const_6_0_26_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 719 "eval.m"
static /* final */ const MR_Box eval__const_6_0_27_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 720 "eval.m"
static /* final */ const MR_Box eval__const_6_0_28_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 721 "eval.m"
static /* final */ const MR_Box eval__const_6_0_29_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 722 "eval.m"
static /* final */ const MR_Box eval__const_6_0_30_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 723 "eval.m"
static /* final */ const MR_Box eval__const_6_0_31_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 724 "eval.m"
static /* final */ const MR_Box eval__const_6_0_32_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 725 "eval.m"
static /* final */ const MR_Box eval__const_6_0_33_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 726 "eval.m"
static /* final */ const MR_Box eval__const_6_0_34_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 727 "eval.m"
static /* final */ const MR_Box eval__const_6_0_35_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 0))};
#line 728 "eval.m"
static /* final */ const MR_Box eval__const_6_0_36_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 729 "eval.m"
static /* final */ const MR_Box eval__const_6_0_37_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 730 "eval.m"
static /* final */ const MR_Box eval__const_6_0_38_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 731 "eval.m"
static /* final */ const MR_Box eval__const_6_0_39_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 732 "eval.m"
static /* final */ const MR_Box eval__const_6_0_40_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 733 "eval.m"
static /* final */ const MR_Box eval__const_6_0_41_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 734 "eval.m"
static /* final */ const MR_Box eval__const_6_0_42_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 735 "eval.m"
static /* final */ const MR_Box eval__const_6_0_43_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 736 "eval.m"
static /* final */ const MR_Box eval__const_6_0_44_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 737 "eval.m"
static /* final */ const MR_Box eval__const_6_0_45_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 738 "eval.m"
static /* final */ const MR_Box eval__const_6_0_46_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 739 "eval.m"
static /* final */ const MR_Box eval__const_6_0_47_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};
#line 740 "eval.m"
static /* final */ const MR_Box eval__const_6_0_48_HeadVar__3_3[1] = {
		((MR_Box) ((MR_Integer) 1))};

#line 128 "eval.m"
void MR_CALL eval__args_3_p_0(
#line 128 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 128 "eval.m"
  MR_Integer * eval__HeadVar__2_2,
#line 128 "eval.m"
  MR_Word * eval__HeadVar__3_3)
#line 128 "eval.m"
{
#line 691 "eval.m"
  {
#line 691 "eval.m"
    bool eval__succeeded;

#line 691 "eval.m"
#line 691 "eval.m"
    switch (eval__HeadVar__1_1) {
#line 691 "eval.m"
      default: /*NOTREACHED*/ MR_assert(0);
#line 691 "eval.m"
      case (MR_Integer) 0:
        {
          MR_Integer eval__V_4_4;

#line 691 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 691 "eval.m"
          eval__V_4_4 = (MR_Integer) 1;
#line 691 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_1_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 1:
        {
          MR_Integer eval__V_5_5;

#line 692 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 692 "eval.m"
          eval__V_5_5 = (MR_Integer) 1;
#line 692 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_2_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 2:
        {
          MR_Integer eval__V_6_6;

#line 693 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 693 "eval.m"
          eval__V_6_6 = (MR_Integer) 1;
#line 693 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_3_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 3:
        {
#line 694 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 694 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 4:
        {
          MR_Integer eval__V_7_7;

#line 695 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 695 "eval.m"
          eval__V_7_7 = (MR_Integer) 1;
#line 695 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_4_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 5:
        {
          MR_Integer eval__V_8_8;

#line 696 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 696 "eval.m"
          eval__V_8_8 = (MR_Integer) 1;
#line 696 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_5_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 6:
        {
          MR_Integer eval__V_9_9;

#line 697 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 697 "eval.m"
          eval__V_9_9 = (MR_Integer) 1;
#line 697 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_6_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 7:
        {
          MR_Integer eval__V_10_10;

#line 698 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 698 "eval.m"
          eval__V_10_10 = (MR_Integer) 1;
#line 698 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_7_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 8:
        {
          MR_Integer eval__V_11_11;

#line 699 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 699 "eval.m"
          eval__V_11_11 = (MR_Integer) 1;
#line 699 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_8_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 9:
        {
          MR_Integer eval__V_12_12;

#line 700 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 700 "eval.m"
          eval__V_12_12 = (MR_Integer) 1;
#line 700 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_9_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 10:
        {
          MR_Integer eval__V_13_13;

#line 701 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 701 "eval.m"
          eval__V_13_13 = (MR_Integer) 1;
#line 701 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_10_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 11:
        {
          MR_Integer eval__V_14_14;

#line 702 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 702 "eval.m"
          eval__V_14_14 = (MR_Integer) 1;
#line 702 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_11_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 12:
        {
          MR_Integer eval__V_15_15;

#line 703 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 703 "eval.m"
          eval__V_15_15 = (MR_Integer) 1;
#line 703 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_12_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 13:
        {
          MR_Integer eval__V_16_16;

#line 704 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 704 "eval.m"
          eval__V_16_16 = (MR_Integer) 1;
#line 704 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_13_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 14:
        {
          MR_Integer eval__V_17_17;

#line 705 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 705 "eval.m"
          eval__V_17_17 = (MR_Integer) 1;
#line 705 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_14_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 15:
        {
          MR_Integer eval__V_18_18;

#line 706 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 706 "eval.m"
          eval__V_18_18 = (MR_Integer) 1;
#line 706 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_15_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 16:
        {
          MR_Integer eval__V_19_19;

#line 707 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 707 "eval.m"
          eval__V_19_19 = (MR_Integer) 1;
#line 707 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_16_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 17:
        {
          MR_Integer eval__V_20_20;

#line 708 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 708 "eval.m"
          eval__V_20_20 = (MR_Integer) 1;
#line 708 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_17_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 18:
        {
          MR_Integer eval__V_21_21;

#line 709 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 709 "eval.m"
          eval__V_21_21 = (MR_Integer) 1;
#line 709 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_18_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 19:
        {
          MR_Integer eval__V_22_22;

#line 710 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 710 "eval.m"
          eval__V_22_22 = (MR_Integer) 1;
#line 710 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_19_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 20:
        {
          MR_Integer eval__V_23_23;

#line 711 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 711 "eval.m"
          eval__V_23_23 = (MR_Integer) 1;
#line 711 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_20_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 21:
        {
#line 712 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 3;
#line 712 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 22:
        {
          MR_Integer eval__V_24_24;

#line 713 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 713 "eval.m"
          eval__V_24_24 = (MR_Integer) 1;
#line 713 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_21_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 23:
        {
          MR_Integer eval__V_25_25;

#line 714 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 714 "eval.m"
          eval__V_25_25 = (MR_Integer) 1;
#line 714 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_22_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 24:
        {
          MR_Integer eval__V_26_26;

#line 715 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 715 "eval.m"
          eval__V_26_26 = (MR_Integer) 1;
#line 715 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_23_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 25:
        {
          MR_Integer eval__V_27_27;

#line 716 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 716 "eval.m"
          eval__V_27_27 = (MR_Integer) 1;
#line 716 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_24_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 26:
        {
          MR_Integer eval__V_28_28;

#line 717 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 717 "eval.m"
          eval__V_28_28 = (MR_Integer) 1;
#line 717 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_25_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 27:
        {
          MR_Integer eval__V_29_29;

#line 718 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 718 "eval.m"
          eval__V_29_29 = (MR_Integer) 1;
#line 718 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_26_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 28:
        {
          MR_Integer eval__V_30_30;

#line 719 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 719 "eval.m"
          eval__V_30_30 = (MR_Integer) 1;
#line 719 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_27_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 29:
        {
          MR_Integer eval__V_31_31;

#line 720 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 720 "eval.m"
          eval__V_31_31 = (MR_Integer) 1;
#line 720 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_28_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 30:
        {
          MR_Integer eval__V_32_32;

#line 721 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 721 "eval.m"
          eval__V_32_32 = (MR_Integer) 1;
#line 721 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_29_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 31:
        {
          MR_Integer eval__V_33_33;

#line 722 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 722 "eval.m"
          eval__V_33_33 = (MR_Integer) 1;
#line 722 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_30_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 32:
        {
          MR_Integer eval__V_34_34;

#line 723 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 723 "eval.m"
          eval__V_34_34 = (MR_Integer) 1;
#line 723 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_31_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 33:
        {
          MR_Integer eval__V_35_35;

#line 724 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 3;
#line 724 "eval.m"
          eval__V_35_35 = (MR_Integer) 1;
#line 724 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_32_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 34:
        {
          MR_Integer eval__V_36_36;

#line 725 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 725 "eval.m"
          eval__V_36_36 = (MR_Integer) 1;
#line 725 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_33_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 35:
        {
          MR_Integer eval__V_37_37;

#line 726 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 726 "eval.m"
          eval__V_37_37 = (MR_Integer) 1;
#line 726 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_34_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 36:
        {
          MR_Integer eval__V_38_38;

#line 727 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 8;
#line 727 "eval.m"
          eval__V_38_38 = (MR_Integer) 0;
#line 727 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_35_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 37:
        {
          MR_Integer eval__V_39_39;

#line 728 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 728 "eval.m"
          eval__V_39_39 = (MR_Integer) 1;
#line 728 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_36_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 38:
        {
          MR_Integer eval__V_40_40;

#line 729 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 729 "eval.m"
          eval__V_40_40 = (MR_Integer) 1;
#line 729 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_37_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 39:
        {
          MR_Integer eval__V_41_41;

#line 730 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 730 "eval.m"
          eval__V_41_41 = (MR_Integer) 1;
#line 730 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_38_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 40:
        {
          MR_Integer eval__V_42_42;

#line 731 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 4;
#line 731 "eval.m"
          eval__V_42_42 = (MR_Integer) 1;
#line 731 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_39_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 41:
        {
          MR_Integer eval__V_43_43;

#line 732 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 732 "eval.m"
          eval__V_43_43 = (MR_Integer) 1;
#line 732 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_40_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 42:
        {
          MR_Integer eval__V_44_44;

#line 733 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 733 "eval.m"
          eval__V_44_44 = (MR_Integer) 1;
#line 733 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_41_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 43:
        {
          MR_Integer eval__V_45_45;

#line 734 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 5;
#line 734 "eval.m"
          eval__V_45_45 = (MR_Integer) 1;
#line 734 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_42_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 44:
        {
          MR_Integer eval__V_46_46;

#line 735 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 1;
#line 735 "eval.m"
          eval__V_46_46 = (MR_Integer) 1;
#line 735 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_43_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 45:
        {
          MR_Integer eval__V_47_47;

#line 736 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 736 "eval.m"
          eval__V_47_47 = (MR_Integer) 1;
#line 736 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_44_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 46:
        {
          MR_Integer eval__V_48_48;

#line 737 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 737 "eval.m"
          eval__V_48_48 = (MR_Integer) 1;
#line 737 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_45_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 47:
        {
          MR_Integer eval__V_49_49;

#line 738 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 4;
#line 738 "eval.m"
          eval__V_49_49 = (MR_Integer) 1;
#line 738 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_46_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 48:
        {
          MR_Integer eval__V_50_50;

#line 739 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 739 "eval.m"
          eval__V_50_50 = (MR_Integer) 1;
#line 739 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_47_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
      case (MR_Integer) 49:
        {
          MR_Integer eval__V_51_51;

#line 740 "eval.m"
          *eval__HeadVar__2_2 = (MR_Integer) 2;
#line 740 "eval.m"
          eval__V_51_51 = (MR_Integer) 1;
#line 740 "eval.m"
          *eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), &eval__const_6_0_48_HeadVar__3_3);
        }
#line 691 "eval.m"
        break;
#line 691 "eval.m"
    }
#line 691 "eval.m"
  }
#line 128 "eval.m"
}

#line 122 "eval.m"
void MR_CALL eval__eval_error_2_p_0(
#line 122 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 122 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 122 "eval.m"
{
#line 769 "eval.m"
  {
#line 769 "eval.m"
    bool eval__succeeded = (eval__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0)));

#line 769 "eval.m"
    if (eval__succeeded)
      {
        MR_Word eval__V_5_5;
        MR_String eval__V_6_6 = (MR_String) "empty stack during evaluation";
        MR_Word eval__TypeInfo_9_9;

#line 766 "eval.m"
        {
#line 766 "eval.m"
          eval__V_5_5 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "stack_env_exception");
#line 766 "eval.m"
          MR_hl_field(MR_mktag(0), eval__V_5_5, 0) = ((MR_Box) (eval__V_6_6));
#line 766 "eval.m"
          MR_hl_field(MR_mktag(0), eval__V_5_5, 1) = ((MR_Box) (eval__HeadVar__1_1));
#line 766 "eval.m"
          MR_hl_field(MR_mktag(0), eval__V_5_5, 2) = ((MR_Box) (eval__HeadVar__2_2));
#line 766 "eval.m"
        }
        eval__TypeInfo_9_9 = (MR_Word) (&eval__eval__type_ctor_info_stack_env_exception_0);
#line 766 "eval.m"
        {
#line 766 "eval.m"
          mercury__exception__throw_1_p_0(eval__TypeInfo_9_9, ((MR_Box) (eval__V_5_5)));
#line 766 "eval.m"
          return;
        }
      }
#line 769 "eval.m"
    else
      {
        MR_Word eval__V_7_7;
        MR_String eval__V_8_8 = (MR_String) "type error during evalutation";
        MR_Word eval__TypeInfo_10_10;

#line 770 "eval.m"
        {
#line 770 "eval.m"
          eval__V_7_7 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "program_error"));
#line 770 "eval.m"
          MR_hl_field(MR_mktag(1), eval__V_7_7, 0) = ((MR_Box) (eval__V_8_8));
#line 770 "eval.m"
          MR_hl_field(MR_mktag(1), eval__V_7_7, 1) = ((MR_Box) (eval__HeadVar__2_2));
#line 770 "eval.m"
        }
        eval__TypeInfo_10_10 = (MR_Word) (&eval__eval__type_ctor_info_program_error_0);
#line 770 "eval.m"
        {
#line 770 "eval.m"
          mercury__exception__throw_1_p_0(eval__TypeInfo_10_10, ((MR_Box) (eval__V_7_7)));
#line 770 "eval.m"
          return;
        }
      }
#line 769 "eval.m"
  }
#line 122 "eval.m"
}

#line 121 "eval.m"
bool MR_CALL eval__pop_3_p_0(
#line 121 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 121 "eval.m"
  MR_Word * eval__HeadVar__2_2,
#line 121 "eval.m"
  MR_Word * eval__HeadVar__3_3)
#line 121 "eval.m"
{
#line 746 "eval.m"
  {
#line 746 "eval.m"
    bool eval__succeeded = (MR_tag((MR_Word) eval__HeadVar__1_1) == MR_mktag((MR_Integer) 1));

#line 746 "eval.m"
    if ((MR_tag((MR_Word) eval__HeadVar__1_1) == MR_mktag((MR_Integer) 1)))
#line 746 "eval.m"
      {
#line 746 "eval.m"
        *eval__HeadVar__2_2 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 746 "eval.m"
        *eval__HeadVar__3_3 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 746 "eval.m"
      }
#line 746 "eval.m"
    return eval__succeeded;
#line 746 "eval.m"
  }
#line 121 "eval.m"
}

#line 120 "eval.m"
MR_Word MR_CALL eval__push_3_f_0(
#line 120 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 120 "eval.m"
  MR_Word eval__HeadVar__2_2)
#line 120 "eval.m"
{
#line 744 "eval.m"
  {
#line 744 "eval.m"
    bool eval__succeeded;
#line 744 "eval.m"
    MR_Word eval__HeadVar__3_3;

#line 744 "eval.m"
    {
#line 744 "eval.m"
      eval__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 744 "eval.m"
      MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, 0) = ((MR_Box) (eval__HeadVar__1_1));
#line 744 "eval.m"
      MR_hl_field(MR_mktag(1), eval__HeadVar__3_3, 1) = ((MR_Box) (eval__HeadVar__2_2));
#line 744 "eval.m"
    }
#line 744 "eval.m"
    return eval__HeadVar__3_3;
#line 744 "eval.m"
  }
#line 120 "eval.m"
}

#line 103 "eval.m"
void MR_CALL eval__interpret_7_p_0(
#line 103 "eval.m"
  MR_Word eval__HeadVar__1_1,
#line 103 "eval.m"
  MR_Word eval__HeadVar__2_2,
#line 103 "eval.m"
  MR_Word eval__HeadVar__3_3,
#line 103 "eval.m"
  MR_Word * eval__HeadVar__4_4,
#line 103 "eval.m"
  MR_Word * eval__HeadVar__5_5)
#line 103 "eval.m"
{
#line 150 "eval.m"
  {
#line 150 "eval.m"
    /* tailcall optimized into a loop */
#line 150 "eval.m"
  loop_top:;
#line 150 "eval.m"
    {
#line 150 "eval.m"
      bool eval__succeeded;
#line 150 "eval.m"
      MR_Word eval__Token_12;
#line 150 "eval.m"
      MR_Word eval__Tokens_13;
#line 150 "eval.m"
      MR_Word eval__Env1_18;
#line 150 "eval.m"
      MR_Word eval__Stack1_19;

#line 150 "eval.m"
      if ((eval__HeadVar__1_1 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
        {
#line 150 "eval.m"
          *eval__HeadVar__4_4 = eval__HeadVar__2_2;
#line 150 "eval.m"
          *eval__HeadVar__5_5 = eval__HeadVar__3_3;
        }
#line 150 "eval.m"
      else
#line 150 "eval.m"
        {
#line 151 "eval.m"
          eval__Token_12 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 0)));
#line 151 "eval.m"
          eval__Tokens_13 = ((MR_Word) (MR_hl_field(MR_mktag(1), eval__HeadVar__1_1, (MR_Integer) 1)));
#line 152 "eval.m"
          {
#line 152 "eval.m"
            eval__do_token_group_7_p_0(eval__Token_12, eval__HeadVar__2_2, eval__HeadVar__3_3, &eval__Env1_18, &eval__Stack1_19);
          }
#line 153 "eval.m"
          {
#line 153 "eval.m"
            /* direct tailcall eliminated */
#line 153 "eval.m"
            {
#line 153 "eval.m"
              MR_Word eval__HeadVar__1__tmp_copy_1 = eval__Tokens_13;
#line 153 "eval.m"
              MR_Word eval__HeadVar__2__tmp_copy_2 = eval__Env1_18;
#line 153 "eval.m"
              MR_Word eval__HeadVar__3__tmp_copy_3 = eval__Stack1_19;

#line 153 "eval.m"
              eval__HeadVar__1_1 = eval__HeadVar__1__tmp_copy_1;
#line 153 "eval.m"
              eval__HeadVar__2_2 = eval__HeadVar__2__tmp_copy_2;
#line 153 "eval.m"
              eval__HeadVar__3_3 = eval__HeadVar__3__tmp_copy_3;
#line 153 "eval.m"
            }
#line 153 "eval.m"
            goto loop_top;
#line 153 "eval.m"
          }
#line 150 "eval.m"
        }
#line 150 "eval.m"
    }
#line 150 "eval.m"
  }
#line 103 "eval.m"
}

#line 100 "eval.m"
void MR_CALL eval__initial_setup_4_p_0(
#line 100 "eval.m"
  MR_Word * eval__HeadVar__1_1,
#line 100 "eval.m"
  MR_Word * eval__HeadVar__2_2)
#line 100 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Word eval__V_8_8;
    MR_Integer eval__V_9_9;
    MR_Word eval__TypeInfo_10_10;
    MR_Word eval__TypeInfo_11_11;
    MR_Word eval__TypeInfo_12_12;
    MR_Word eval__TypeInfo_13_13;

#line 146 "eval.m"
    *eval__HeadVar__2_2 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
    eval__TypeInfo_10_10 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
    eval__TypeInfo_11_11 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
    {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
      mercury__tree234__init_1_p_0(eval__TypeInfo_10_10, eval__TypeInfo_11_11, eval__HeadVar__1_1);
    }
#line 148 "eval.m"
    eval__V_8_8 = (MR_Integer) 0;
#line 148 "eval.m"
    eval__V_9_9 = (MR_Integer) 1;
    eval__TypeInfo_12_12 = (MR_Word) (&eval__eval__type_ctor_info_global_object_counter_0);
    eval__TypeInfo_13_13 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 148 "eval.m"
    {
#line 148 "eval.m"
      globals__set_4_p_0(eval__TypeInfo_12_12, eval__TypeInfo_13_13, ((MR_Box) (eval__V_8_8)), ((MR_Box) (eval__V_9_9)));
#line 148 "eval.m"
      return;
    }
  }
#line 100 "eval.m"
}

#line 98 "eval.m"
void MR_CALL eval__interpret_3_p_0(
#line 98 "eval.m"
  MR_Word eval__HeadVar__1_1)
#line 98 "eval.m"
{
  {
    bool eval__succeeded;
    MR_Word eval__Env0_5;
    MR_Word eval__Stack0_6;
#line 144 "eval.m"
    MR_Word eval___Env_7;
#line 144 "eval.m"
    MR_Word eval___Stack_8;

#line 143 "eval.m"
    {
#line 143 "eval.m"
      eval__initial_setup_4_p_0(&eval__Env0_5, &eval__Stack0_6);
    }
#line 144 "eval.m"
    {
#line 144 "eval.m"
      eval__interpret_7_p_0(eval__HeadVar__1_1, eval__Env0_5, eval__Stack0_6, &eval___Env_7, &eval___Stack_8);
    }
  }
#line 98 "eval.m"
}

void mercury__eval__init(void)
{
}

void mercury__eval__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&eval__eval__type_ctor_info_value_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_transformation_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_surface_properties_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_surface_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_stack_env_token_exception_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_stack_env_exception_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_stack_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_program_error_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_object_id_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_object_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_light_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_id_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_global_object_counter_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_env_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_degrees_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_color_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_code_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_basic_object_0);
	MR_register_type_ctor_info(&eval__eval__type_ctor_info_array_0);
}

void mercury__eval__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module eval. */
