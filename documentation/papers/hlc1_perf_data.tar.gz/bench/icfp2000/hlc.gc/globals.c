/*
** Automatically generated from `globals.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module globals. */
/* :- implementation. */

#include "globals.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.benchmarking.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "mercury.tree234.h"
#include "mercury.varset.h"



static /* final */ const MR_Box globals__const_2_0_1_TypeInfo_23_23[3];
static /* final */ const MR_Box globals__const_2_0_2_TypeInfo_29_29[3];
static /* final */ const MR_Box globals__const_1_0_1_TypeInfo_22_22[3];
static /* final */ const MR_Box globals__const_0_0_1_TypeInfo_11_11[3];




#line 62 "globals.m"
void MR_CALL globals__my_map_init_1_p_0(
#line 62 "globals.m"
  MR_Word * globals__HeadVar__1_1)
#line 62 "globals.m"
{
  {
    bool globals__succeeded;
    MR_Word globals__TypeInfo_3_3 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
    MR_Word globals__TypeInfo_4_4 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);

#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
    {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
      mercury__tree234__init_1_p_0(globals__TypeInfo_3_3, globals__TypeInfo_4_4, globals__HeadVar__1_1);
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
      return;
    }
  }
#line 62 "globals.m"
}
static /* final */ const MR_Box globals__const_2_0_1_TypeInfo_23_23[3] = {
		((MR_Box) ((&mercury__tree234__tree234__type_ctor_info_tree234_2))),
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_univ_0))),
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_univ_0)))};
static /* final */ const MR_Box globals__const_2_0_2_TypeInfo_29_29[3] = {
		((MR_Box) ((&mercury__tree234__tree234__type_ctor_info_tree234_2))),
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_univ_0))),
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_univ_0)))};

#line 14 "globals.m"
void MR_CALL globals__set_4_p_0(
#line 14 "globals.m"
  MR_Word globals__TypeInfo_for_T1_18,
#line 14 "globals.m"
  MR_Word globals__TypeInfo_for_T2_19,
#line 14 "globals.m"
  MR_Box globals__HeadVar__1_1,
#line 14 "globals.m"
  MR_Box globals__HeadVar__2_2)
#line 14 "globals.m"
{
  {
    bool globals__succeeded;
    MR_Word globals__UMap0_7;
#line 58 "globals.m"
    MR_Word globals__Map0_8;
    MR_Word globals__TypeInfo_20_20;
    MR_Word globals__TypeInfo_21_21;
    MR_Word globals__TypeInfo_22_22;
    MR_Word globals__TypeInfo_23_23;
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
    MR_Box globals__conv1_Map0_8;

#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL globals__set_4_p_0
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Globals;
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IOState0;
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IOState;
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IOState0 = 
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Globals = ML_io_user_globals;
	update_io(IOState0, IOState);

#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
globals__UMap0_7
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Globals;
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
    globals__TypeInfo_22_22 = (MR_Word) (&mercury__tree234__tree234__type_ctor_info_tree234_2);
    globals__TypeInfo_20_20 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
    globals__TypeInfo_21_21 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
    globals__TypeInfo_23_23 = (MR_Word) &globals__const_2_0_1_TypeInfo_23_23;
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
    {
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
      globals__succeeded = mercury__std_util__type_to_univ_2_p_2(globals__TypeInfo_23_23, &globals__conv1_Map0_8, globals__UMap0_7);
    }
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
    if (globals__succeeded)
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
      {
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
        globals__Map0_8 = ((MR_Word) globals__conv1_Map0_8);
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
        globals__succeeded = TRUE;
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
      }
#line 58 "globals.m"
    if (globals__succeeded)
      {
        MR_Word globals__UValue_9;
        MR_Word globals__Map_10;
        MR_Word globals__UMap1_11;
        MR_Word globals__UMap_12;
        MR_Word globals__V_16_16;
        MR_Word globals__TypeInfo_24_24;
        MR_Word globals__TypeInfo_25_25;
        MR_Word globals__TypeInfo_26_26;
        MR_Word globals__TypeInfo_27_27;
        MR_Word globals__TypeInfo_28_28;
        MR_Word globals__TypeInfo_29_29;

#line 53 "globals.m"
        {
#line 53 "globals.m"
          mercury__std_util__type_to_univ_2_p_1(globals__TypeInfo_for_T2_19, globals__HeadVar__2_2, &globals__UValue_9);
        }
#line 320 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
        {
#line 320 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
          mercury__std_util__type_to_univ_2_p_1(globals__TypeInfo_for_T1_18, globals__HeadVar__1_1, &globals__V_16_16);
        }
        globals__TypeInfo_24_24 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
        globals__TypeInfo_25_25 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
        {
#line 63 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
          mercury__tree234__set_4_p_1(globals__TypeInfo_24_24, globals__TypeInfo_25_25, globals__Map0_8, ((MR_Box) (globals__V_16_16)), ((MR_Box) (globals__UValue_9)), &globals__Map_10);
        }
        globals__TypeInfo_28_28 = (MR_Word) (&mercury__tree234__tree234__type_ctor_info_tree234_2);
        globals__TypeInfo_26_26 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
        globals__TypeInfo_27_27 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
        globals__TypeInfo_29_29 = (MR_Word) &globals__const_2_0_2_TypeInfo_29_29;
#line 55 "globals.m"
        {
#line 55 "globals.m"
          mercury__std_util__type_to_univ_2_p_1(globals__TypeInfo_29_29, ((MR_Box) (globals__Map_10)), &globals__UMap1_11);
        }
#line 56 "globals.m"
        globals__UMap_12 = globals__UMap1_11;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL globals__set_4_p_0
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Globals;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IOState0;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IOState;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Globals = 
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
globals__UMap_12
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IOState0 = 
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	/* XXX need to globalize the memory */
	ML_io_user_globals = Globals;
	update_io(IOState0, IOState);

#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
      }
#line 58 "globals.m"
    else
      {
        MR_String globals__V_17_17 = (MR_String) "globals: global store stuffed up";

#line 59 "globals.m"
        {
#line 59 "globals.m"
          mercury__require__error_1_p_0(globals__V_17_17);
#line 59 "globals.m"
          return;
        }
      }
  }
#line 14 "globals.m"
}
static /* final */ const MR_Box globals__const_1_0_1_TypeInfo_22_22[3] = {
		((MR_Box) ((&mercury__tree234__tree234__type_ctor_info_tree234_2))),
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_univ_0))),
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_univ_0)))};

#line 11 "globals.m"
void MR_CALL globals__get_4_p_0(
#line 11 "globals.m"
  MR_Word globals__TypeInfo_for_T1_17,
#line 11 "globals.m"
  MR_Word globals__TypeInfo_for_T2_18,
#line 11 "globals.m"
  MR_Box globals__HeadVar__1_1,
#line 11 "globals.m"
  MR_Box * globals__HeadVar__2_2)
#line 11 "globals.m"
{
  {
    bool globals__succeeded;
    MR_Word globals__UMap0_7;
#line 44 "globals.m"
    MR_Word globals__Map0_8;
    MR_Word globals__TypeInfo_19_19;
    MR_Word globals__TypeInfo_20_20;
    MR_Word globals__TypeInfo_21_21;
    MR_Word globals__TypeInfo_22_22;
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
    MR_Box globals__conv1_Map0_8;

#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL globals__get_4_p_0
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Globals;
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IOState0;
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IOState;
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IOState0 = 
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	Globals = ML_io_user_globals;
	update_io(IOState0, IOState);

#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
globals__UMap0_7
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
 = Globals;
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 671 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
    globals__TypeInfo_21_21 = (MR_Word) (&mercury__tree234__tree234__type_ctor_info_tree234_2);
    globals__TypeInfo_19_19 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
    globals__TypeInfo_20_20 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
    globals__TypeInfo_22_22 = (MR_Word) &globals__const_1_0_1_TypeInfo_22_22;
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
    {
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
      globals__succeeded = mercury__std_util__type_to_univ_2_p_2(globals__TypeInfo_22_22, &globals__conv1_Map0_8, globals__UMap0_7);
    }
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
    if (globals__succeeded)
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
      {
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
        globals__Map0_8 = ((MR_Word) globals__conv1_Map0_8);
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
        globals__succeeded = TRUE;
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
      }
#line 44 "globals.m"
    if (globals__succeeded)
#line 41 "globals.m"
      {
#line 41 "globals.m"
        MR_Word globals__UValue_9;
        MR_Word globals__V_13_13;
        MR_Word globals__TypeInfo_23_23;
        MR_Word globals__TypeInfo_24_24;
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
        MR_Box globals__conv2_UValue_9;

#line 320 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
        {
#line 320 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
          mercury__std_util__type_to_univ_2_p_1(globals__TypeInfo_for_T1_17, globals__HeadVar__1_1, &globals__V_13_13);
        }
        globals__TypeInfo_23_23 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
        globals__TypeInfo_24_24 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
        {
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
          globals__succeeded = mercury__tree234__search_3_p_0(globals__TypeInfo_23_23, globals__TypeInfo_24_24, globals__Map0_8, ((MR_Box) (globals__V_13_13)), &globals__conv2_UValue_9);
        }
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
        if (globals__succeeded)
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
          {
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
            globals__UValue_9 = ((MR_Word) globals__conv2_UValue_9);
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
            globals__succeeded = TRUE;
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
          }
#line 41 "globals.m"
        if (globals__succeeded)
#line 38 "globals.m"
          {
#line 38 "globals.m"
            MR_Box globals__Value0_10;

#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
            {
#line 318 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/std_util.opt"
              globals__succeeded = mercury__std_util__type_to_univ_2_p_2(globals__TypeInfo_for_T2_18, &globals__Value0_10, globals__UValue_9);
            }
#line 38 "globals.m"
            if (globals__succeeded)
#line 37 "globals.m"
              *globals__HeadVar__2_2 = globals__Value0_10;
#line 38 "globals.m"
            else
              {
                MR_String globals__V_14_14 = (MR_String) "globals: value has bad type";

#line 39 "globals.m"
                {
#line 39 "globals.m"
                  mercury__require__error_1_p_0(globals__V_14_14);
#line 39 "globals.m"
                  return;
                }
              }
#line 38 "globals.m"
          }
#line 41 "globals.m"
        else
          {
            MR_String globals__V_15_15 = (MR_String) "get: global not found";

#line 42 "globals.m"
            {
#line 42 "globals.m"
              mercury__require__error_1_p_0(globals__V_15_15);
#line 42 "globals.m"
              return;
            }
          }
#line 41 "globals.m"
      }
#line 44 "globals.m"
    else
      {
        MR_String globals__V_16_16 = (MR_String) "globals: global store stuffed up";

#line 45 "globals.m"
        {
#line 45 "globals.m"
          mercury__require__error_1_p_0(globals__V_16_16);
#line 45 "globals.m"
          return;
        }
      }
  }
#line 11 "globals.m"
}
static /* final */ const MR_Box globals__const_0_0_1_TypeInfo_11_11[3] = {
		((MR_Box) ((&mercury__tree234__tree234__type_ctor_info_tree234_2))),
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_univ_0))),
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_univ_0)))};

#line 8 "globals.m"
void MR_CALL globals__init_2_p_0(void)
#line 8 "globals.m"
{
  {
    bool globals__succeeded;
    MR_Word globals__Map_3;
    MR_Word globals__UMap1_4;
    MR_Word globals__UMap_5;
    MR_Word globals__TypeInfo_8_8;
    MR_Word globals__TypeInfo_9_9;
    MR_Word globals__TypeInfo_10_10;
    MR_Word globals__TypeInfo_11_11;
    MR_Word globals__TypeInfo_3_13 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
    MR_Word globals__TypeInfo_4_14 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);

#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
    {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/map.opt"
      mercury__tree234__init_1_p_0(globals__TypeInfo_3_13, globals__TypeInfo_4_14, &globals__Map_3);
    }
    globals__TypeInfo_10_10 = (MR_Word) (&mercury__tree234__tree234__type_ctor_info_tree234_2);
    globals__TypeInfo_8_8 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
    globals__TypeInfo_9_9 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
    globals__TypeInfo_11_11 = (MR_Word) &globals__const_0_0_1_TypeInfo_11_11;
#line 22 "globals.m"
    {
#line 22 "globals.m"
      mercury__std_util__type_to_univ_2_p_1(globals__TypeInfo_11_11, ((MR_Box) (globals__Map_3)), &globals__UMap1_4);
    }
#line 23 "globals.m"
    globals__UMap_5 = globals__UMap1_4;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL globals__init_2_p_0
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Globals;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IOState0;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IOState;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Globals = 
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
globals__UMap_5
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IOState0 = 
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	/* XXX need to globalize the memory */
	ML_io_user_globals = Globals;
	update_io(IOState0, IOState);

#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
  }
#line 8 "globals.m"
}

void mercury__globals__init(void)
{
}

void mercury__globals__init_type_tables(void)
{
}

void mercury__globals__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module globals. */
