/*
** Automatically generated from `op.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module op. */
/* :- interface. */

#ifndef MR_HEADER_GUARD_op
#define MR_HEADER_GUARD_op

#ifdef __cplusplus
extern "C" {
#endif

#include "mercury.h"


#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

	#include "mercury_heap.h"	/* for MR_free_heap() */

#line 6 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"

#ifdef MR_DEEP_PROFILING
#include "mercury_deep_profiling.h"
#endif

#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"


	#include <math.h>

	/*
	** Mathematical constants.
	**
	** The maximum number of significant decimal digits which
	** can be packed into an IEEE-754 extended precision
	** floating point number is 18.  Therefore 20 significant
	** decimal digits for these constants should be plenty.
	*/

	#define	ML_FLOAT_E		2.7182818284590452354
	#define	ML_FLOAT_PI		3.1415926535897932384
	#define	ML_FLOAT_LN2		0.69314718055994530941


#line 3 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#include <float.h>
	#include <math.h>


#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"


	#define	ML_FLOAT_RADIX	FLT_RADIX	/* There is no DBL_RADIX. */

	#if defined USE_SINGLE_PREC_FLOAT
		#define	ML_FLOAT_MAX		FLT_MAX
		#define	ML_FLOAT_MIN		FLT_MIN
		#define	ML_FLOAT_EPSILON	FLT_EPSILON
		#define	ML_FLOAT_MANT_DIG	FLT_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	FLT_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	FLT_MAX_EXP
	#else
		#define	ML_FLOAT_MAX		DBL_MAX
		#define	ML_FLOAT_MIN		DBL_MIN
		#define	ML_FLOAT_EPSILON	DBL_EPSILON
		#define	ML_FLOAT_MANT_DIG	DBL_MANT_DIG
		#define	ML_FLOAT_MIN_EXP	DBL_MIN_EXP
		#define	ML_FLOAT_MAX_EXP	DBL_MAX_EXP
	#endif


#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	#include <limits.h>

	#define ML_BITS_PER_INT		(sizeof(MR_Integer) * CHAR_BIT)

#line 4 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"
#include "mercury_type_info.h"
#line 5 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#include "mercury_deep_copy.h"
#include "mercury_deep_profiling_hand.h"

#line 9 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/builtin.opt"

#ifdef MR_HIGHLEVEL_CODE
  void MR_CALL mercury__builtin__copy_2_p_0(MR_Mercury_Type_Info, MR_Box, MR_Box *);
  void MR_CALL mercury__builtin__copy_2_p_1(MR_Mercury_Type_Info, MR_Box, MR_Box *);
#endif



#line 33 "op.m"
MR_Float MR_CALL op__degrees_2_f_0(
#line 33 "op.m"
  MR_Float op__HeadVar__1_1);
#line 32 "op.m"
MR_Float MR_CALL op__radians_2_f_0(
#line 32 "op.m"
  MR_Float op__HeadVar__1_1);
#line 30 "op.m"
MR_Float MR_CALL op__op_subf_3_f_0(
#line 30 "op.m"
  MR_Float op__HeadVar__1_1,
#line 30 "op.m"
  MR_Float op__HeadVar__2_2);
#line 29 "op.m"
MR_Integer MR_CALL op__op_subi_3_f_0(
#line 29 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 29 "op.m"
  MR_Integer op__HeadVar__2_2);
#line 28 "op.m"
MR_Float MR_CALL op__op_sqrt_2_f_0(
#line 28 "op.m"
  MR_Float op__HeadVar__1_1);
#line 27 "op.m"
MR_Float MR_CALL op__op_sin_2_f_0(
#line 27 "op.m"
  MR_Float op__HeadVar__1_1);
#line 26 "op.m"
MR_Float MR_CALL op__op_real_2_f_0(
#line 26 "op.m"
  MR_Integer op__HeadVar__1_1);
#line 25 "op.m"
MR_Float MR_CALL op__op_negf_2_f_0(
#line 25 "op.m"
  MR_Float op__HeadVar__1_1);
#line 24 "op.m"
MR_Integer MR_CALL op__op_negi_2_f_0(
#line 24 "op.m"
  MR_Integer op__HeadVar__1_1);
#line 23 "op.m"
MR_Float MR_CALL op__op_mulf_3_f_0(
#line 23 "op.m"
  MR_Float op__HeadVar__1_1,
#line 23 "op.m"
  MR_Float op__HeadVar__2_2);
#line 22 "op.m"
MR_Integer MR_CALL op__op_muli_3_f_0(
#line 22 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 22 "op.m"
  MR_Integer op__HeadVar__2_2);
#line 21 "op.m"
MR_Integer MR_CALL op__op_modi_3_f_0(
#line 21 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 21 "op.m"
  MR_Integer op__HeadVar__2_2);
#line 20 "op.m"
MR_Word MR_CALL op__op_lessf_3_f_0(
#line 20 "op.m"
  MR_Float op__HeadVar__1_1,
#line 20 "op.m"
  MR_Float op__HeadVar__2_2);
#line 19 "op.m"
MR_Word MR_CALL op__op_lessi_3_f_0(
#line 19 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 19 "op.m"
  MR_Integer op__HeadVar__2_2);
#line 18 "op.m"
MR_Float MR_CALL op__op_frac_2_f_0(
#line 18 "op.m"
  MR_Float op__HeadVar__1_1);
#line 17 "op.m"
MR_Integer MR_CALL op__op_floor_2_f_0(
#line 17 "op.m"
  MR_Float op__HeadVar__1_1);
#line 16 "op.m"
MR_Word MR_CALL op__op_eqf_3_f_0(
#line 16 "op.m"
  MR_Float op__HeadVar__1_1,
#line 16 "op.m"
  MR_Float op__HeadVar__2_2);
#line 15 "op.m"
MR_Word MR_CALL op__op_eqi_3_f_0(
#line 15 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 15 "op.m"
  MR_Integer op__HeadVar__2_2);
#line 14 "op.m"
MR_Float MR_CALL op__op_divf_3_f_0(
#line 14 "op.m"
  MR_Float op__HeadVar__1_1,
#line 14 "op.m"
  MR_Float op__HeadVar__2_2);
#line 13 "op.m"
MR_Integer MR_CALL op__op_divi_3_f_0(
#line 13 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 13 "op.m"
  MR_Integer op__HeadVar__2_2);
#line 12 "op.m"
MR_Float MR_CALL op__op_cos_2_f_0(
#line 12 "op.m"
  MR_Float op__HeadVar__1_1);
#line 11 "op.m"
MR_Float MR_CALL op__op_clampf_2_f_0(
#line 11 "op.m"
  MR_Float op__HeadVar__1_1);
#line 10 "op.m"
MR_Float MR_CALL op__op_asin_2_f_0(
#line 10 "op.m"
  MR_Float op__HeadVar__1_1);
#line 9 "op.m"
MR_Float MR_CALL op__op_addf_3_f_0(
#line 9 "op.m"
  MR_Float op__HeadVar__1_1,
#line 9 "op.m"
  MR_Float op__HeadVar__2_2);
#line 8 "op.m"
MR_Integer MR_CALL op__op_addi_3_f_0(
#line 8 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 8 "op.m"
  MR_Integer op__HeadVar__2_2);
#line 7 "op.m"
MR_Float MR_CALL op__op_acos_2_f_0(
#line 7 "op.m"
  MR_Float op__HeadVar__1_1);

void mercury__op__init(void);
void mercury__op__init_type_tables(void);
void mercury__op__init_debugger(void);

#ifdef __cplusplus
}
#endif

#endif /* MR_HEADER_GUARD_op */

/* :- end_interface op. */
