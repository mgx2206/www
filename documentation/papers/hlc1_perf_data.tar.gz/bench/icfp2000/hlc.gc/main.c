/*
** Automatically generated from `main.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module main. */
/* :- implementation. */

#include "main.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.benchmarking.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "eval.h"
#include "eval_util.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "globals.h"
#include "gml.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "op.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "peephole.h"
#include "mercury.pprint.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "renderer.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "space_partition.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "trans.h"
#include "transform_object.h"
#include "tree.h"
#include "mercury.tree234.h"
#include "mercury.varset.h"
#include "vector.h"



#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
static void MR_CALL main__try_io__ho2__ua0_5_p_in__exception_0_2(
#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
  MR_Box main__closure_arg,
#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
  MR_Box * main__wrapper_arg_1);
static void MR_CALL main__try_io__ho2__ua0_5_p_in__exception_0_1(
  MR_Box main__closure_arg,
  MR_Box * main__wrapper_arg_1,
  MR_Box main__wrapper_arg_2,
  MR_Box * main__wrapper_arg_3);
static /* final */ const MR_Box main__const_1202_0_1_HeadVar__2_2[3];
#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
static /* final */ const MR_Box main__const_1202_0_2_Goal_8_9[5];
#line 166 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
static void MR_CALL main__try_io__ho2__ua0_5_p_in__exception_0(
#line 166 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
  MR_Word * main__HeadVar__3_3);
static /* final */ const MR_Box main__const_1195_0_1_TypeInfo_11_33[3];
#line 15 "main.m"
static void MR_CALL main__IntroducedFrom__pred__main__15__1_3_p_0(
#line 15 "main.m"
  MR_Word * main__V_21_21);
static void MR_CALL main_2_p_0_1(
  MR_Box main__closure_arg,
  MR_Box * main__wrapper_arg_1,
  MR_Box main__wrapper_arg_2,
  MR_Box * main__wrapper_arg_3);
static /* final */ const MR_Box main__const_0_0_1_HeadVar__1_25[3];




#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
static void MR_CALL main__try_io__ho2__ua0_5_p_in__exception_0_2(
#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
  MR_Box main__closure_arg,
#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
  MR_Box * main__wrapper_arg_1)
#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
{
#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
  {
#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
    MR_Box main__closure = main__closure_arg;

#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
    {
#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
      mercury__exception__very_unsafe_perform_io_2_p_0(((MR_Word) (MR_hl_field(MR_mktag(0), main__closure, (MR_Integer) 3))), ((MR_Word) (MR_hl_field(MR_mktag(0), main__closure, (MR_Integer) 4))), main__wrapper_arg_1);
#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
      return;
    }
#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
  }
#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
}

static void MR_CALL main__try_io__ho2__ua0_5_p_in__exception_0_1(
  MR_Box main__closure_arg,
  MR_Box * main__wrapper_arg_1,
  MR_Box main__wrapper_arg_2,
  MR_Box * main__wrapper_arg_3)
{
  {
    MR_Box main__closure = main__closure_arg;
    MR_Word main__conv1_V_21_21;

    {
      main__IntroducedFrom__pred__main__15__1_3_p_0(&main__conv1_V_21_21);
    }
    *main__wrapper_arg_1 = ((MR_Box) (main__conv1_V_21_21));
  }
}
static /* final */ const MR_Box main__const_1202_0_1_HeadVar__2_2[3] = {
		((MR_Box) (NULL)),
		((MR_Box) (main__try_io__ho2__ua0_5_p_in__exception_0_1)),
		((MR_Box) (MR_Word) ((MR_Integer) 0))};
#line 238 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
static /* final */ const MR_Box main__const_1202_0_2_Goal_8_9[5] = {
		((MR_Box) (NULL)),
		((MR_Box) (main__try_io__ho2__ua0_5_p_in__exception_0_2)),
		((MR_Box) (MR_Word) ((MR_Integer) 2)),
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_unit_0))),
		((MR_Box) (&main__const_1202_0_1_HeadVar__2_2))};

#line 166 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
static void MR_CALL main__try_io__ho2__ua0_5_p_in__exception_0(
#line 166 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
  MR_Word * main__HeadVar__3_3)
#line 166 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
{
  {
    bool main__succeeded;
    MR_Word main__HeadVar__2_2 = (MR_Word) &main__const_1202_0_1_HeadVar__2_2;
    MR_Word main__Goal_8_9 = (MR_Word) &main__const_1202_0_2_Goal_8_9;
    MR_Word main__V_11_12 = (MR_Integer) 0;
    MR_Word main__TypeInfo_for_T_1_24 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_unit_0);

#line 245 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
    {
#line 245 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
      mercury__exception__try_3_p_0(main__TypeInfo_for_T_1_24, main__V_11_12, main__Goal_8_9, main__HeadVar__3_3);
#line 245 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
      return;
    }
  }
#line 166 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
}
static /* final */ const MR_Box main__const_1195_0_1_TypeInfo_11_33[3] = {
		((MR_Box) ((&mercury__tree234__tree234__type_ctor_info_tree234_2))),
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_univ_0))),
		((MR_Box) ((&mercury__std_util__std_util__type_ctor_info_univ_0)))};

#line 15 "main.m"
static void MR_CALL main__IntroducedFrom__pred__main__15__1_3_p_0(
#line 15 "main.m"
  MR_Word * main__V_21_21)
#line 15 "main.m"
{
  {
    bool main__succeeded;
    MR_Word main__BasicTokens_3;
    MR_Word main__Program_4;
    MR_Word main__OptProgram_5;
    MR_Word main__Map_3_27;
    MR_Word main__UMap1_4_28;
    MR_Word main__UMap_5_29;
    MR_Word main__TypeInfo_8_30;
    MR_Word main__TypeInfo_9_31;
    MR_Word main__TypeInfo_10_32;
    MR_Word main__TypeInfo_11_33;
    MR_Word main__TypeInfo_3_35;
    MR_Word main__TypeInfo_4_36;
    MR_Word main__V_8_43;
    MR_Word main__RevTokens_5_44;
    MR_Word main__TypeInfo_9_45;
    MR_Word main__Env0_5_49;
    MR_Word main__Stack0_6_50;
    MR_Word main__V_8_57;
    MR_Integer main__V_9_58;
    MR_Word main__TypeInfo_10_59;
    MR_Word main__TypeInfo_11_60;
    MR_Word main__TypeInfo_12_61;
    MR_Word main__TypeInfo_13_62;
#line 5 "eval.opt"
    MR_Word main___Env_7_52;
#line 5 "eval.opt"
    MR_Word main___Stack_8_53;

#line 15 "main.m"
    *main__V_21_21 = (MR_Integer) 0;
    main__TypeInfo_3_35 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
    main__TypeInfo_4_36 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
#line 11 "globals.opt"
    {
#line 11 "globals.opt"
      mercury__map__init_1_p_0(main__TypeInfo_3_35, main__TypeInfo_4_36, &main__Map_3_27);
    }
    main__TypeInfo_10_32 = (MR_Word) (&mercury__tree234__tree234__type_ctor_info_tree234_2);
    main__TypeInfo_8_30 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
    main__TypeInfo_9_31 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_univ_0);
    main__TypeInfo_11_33 = (MR_Word) &main__const_1195_0_1_TypeInfo_11_33;
#line 7 "globals.opt"
    {
#line 7 "globals.opt"
      mercury__std_util__type_to_univ_2_p_1(main__TypeInfo_11_33, ((MR_Box) (main__Map_3_27)), &main__UMap1_4_28);
    }
#line 8 "globals.opt"
    main__UMap_5_29 = main__UMap1_4_28;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL main__IntroducedFrom__pred__main__15__1_3_p_0
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word Globals;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IOState0;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IOState;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	Globals = 
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
main__UMap_5_29
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IOState0 = 
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	/* XXX need to globalize the memory */
	ML_io_user_globals = Globals;
	update_io(IOState0, IOState);

#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 675 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
#line 10 "gml.opt"
    main__V_8_43 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 11 "gml.opt"
    {
#line 11 "gml.opt"
      gml__tokenize_2_4_p_0(main__V_8_43, &main__RevTokens_5_44);
    }
    main__TypeInfo_9_45 = (MR_Word) (&gml__gml__type_ctor_info_basic_token_0);
#line 12 "gml.opt"
    {
#line 12 "gml.opt"
      mercury__list__reverse_2_p_0(main__TypeInfo_9_45, main__RevTokens_5_44, &main__BasicTokens_3);
    }
#line 19 "main.m"
    {
#line 19 "main.m"
      gml__parse_2_p_0(main__BasicTokens_3, &main__Program_4);
    }
#line 20 "main.m"
    {
#line 20 "main.m"
      peephole__peephole_2_p_0(main__Program_4, &main__OptProgram_5);
    }
#line 6 "eval.opt"
    main__Stack0_6_50 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
    main__TypeInfo_10_59 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);
    main__TypeInfo_11_60 = (MR_Word) (&eval__eval__type_ctor_info_value_0);
#line 7 "eval.opt"
    {
#line 7 "eval.opt"
      mercury__map__init_1_p_0(main__TypeInfo_10_59, main__TypeInfo_11_60, &main__Env0_5_49);
    }
#line 8 "eval.opt"
    main__V_8_57 = (MR_Integer) 0;
#line 9 "eval.opt"
    main__V_9_58 = (MR_Integer) 1;
    main__TypeInfo_12_61 = (MR_Word) (&eval__eval__type_ctor_info_global_object_counter_0);
    main__TypeInfo_13_62 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_int_0);
#line 10 "eval.opt"
    {
#line 10 "eval.opt"
      globals__set_4_p_0(main__TypeInfo_12_61, main__TypeInfo_13_62, ((MR_Box) (main__V_8_57)), ((MR_Box) (main__V_9_58)));
    }
#line 5 "eval.opt"
    {
#line 5 "eval.opt"
      eval__interpret_7_p_0(main__OptProgram_5, main__Env0_5_49, main__Stack0_6_50, &main___Env_7_52, &main___Stack_8_53);
    }
  }
#line 15 "main.m"
}

static void MR_CALL main_2_p_0_1(
  MR_Box main__closure_arg,
  MR_Box * main__wrapper_arg_1,
  MR_Box main__wrapper_arg_2,
  MR_Box * main__wrapper_arg_3)
{
  {
    MR_Box main__closure = main__closure_arg;
    MR_Word main__conv1_V_21_21;

    {
      main__IntroducedFrom__pred__main__15__1_3_p_0(&main__conv1_V_21_21);
    }
    *main__wrapper_arg_1 = ((MR_Box) (main__conv1_V_21_21));
  }
}
static /* final */ const MR_Box main__const_0_0_1_HeadVar__1_25[3] = {
		((MR_Box) (NULL)),
		((MR_Box) (main_2_p_0_1)),
		((MR_Box) (MR_Word) ((MR_Integer) 0))};

#line 7 "main.m"
void MR_CALL main_2_p_0(void)
#line 7 "main.m"
{
  {
    bool main__succeeded;
    MR_Word main__ExceptionResult_6;
    MR_Word main__HeadVar__1_25 = (MR_Word) &main__const_0_0_1_HeadVar__1_25;
    MR_Word main__TypeInfo_for_T_31 = (MR_Word) (&mercury__std_util__std_util__type_ctor_info_unit_0);
    MR_Word main__TypeInfo_11_32 = (MR_Word) (&mercury__io__io__type_ctor_info_state_0);
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
    MR_Word main__Detism_7_30;
#line 31 "main.m"
    MR_Word main__E_7;

#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
{
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
#define MR_PROC_LABEL main_2_p_0
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
	MR_Word TypeInfo_for_T;
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
	MR_Word TypeInfo_for_S;
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
	MR_Word Det;
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
	TypeInfo_for_T = 
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
main__TypeInfo_for_T_31
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
;
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
	TypeInfo_for_S = 
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
main__TypeInfo_11_32
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
;
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
		{
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
Det = ML_DET
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"

		;}
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
#undef MR_PROC_LABEL
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
	
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
main__Detism_7_30
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
 = Det;
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
#line 284 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
}
#line 214 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
    {
#line 214 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/exception.opt"
      main__try_io__ho2__ua0_5_p_in__exception_0(&main__ExceptionResult_6);
    }
#line 27 "main.m"
    main__succeeded = (MR_tag((MR_Word) main__ExceptionResult_6) == MR_mktag((MR_Integer) 2));
#line 27 "main.m"
    if ((MR_tag((MR_Word) main__ExceptionResult_6) == MR_mktag((MR_Integer) 2)))
#line 27 "main.m"
      main__E_7 = ((MR_Word) (MR_hl_field(MR_mktag(2), main__ExceptionResult_6, (MR_Integer) 0)));
#line 31 "main.m"
    if (main__succeeded)
      {
        MR_Integer main__V_13_13;

#line 29 "main.m"
        {
#line 29 "main.m"
          eval_util__write_nice_exception_3_p_0(main__E_7);
        }
#line 30 "main.m"
        main__V_13_13 = (MR_Integer) 1;
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
{
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#define MR_PROC_LABEL main_2_p_0
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Integer ExitStatus;
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO0;
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	MR_Word IO;
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	ExitStatus = 
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
main__V_13_13
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
	IO0 = 
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
(MR_Integer) 0
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
;
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
		{
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

	mercury_exit_status = ExitStatus;
	update_io(IO0, IO);

#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"

		;}
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#undef MR_PROC_LABEL
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
#line 667 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/io.opt"
}
      }
#line 31 "main.m"
    else
#line 32 "main.m"
      {
#line 32 "main.m"
      }
  }
#line 7 "main.m"
}

void mercury__main__init(void)
{
}

void mercury__main__init_type_tables(void)
{
}

void mercury__main__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module main. */
