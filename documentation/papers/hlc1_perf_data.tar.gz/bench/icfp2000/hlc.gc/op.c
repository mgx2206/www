/*
** Automatically generated from `op.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module op. */
/* :- implementation. */

#include "op.h"


#include "mercury.assoc_list.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.enum.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "mercury.ops.h"
#include "mercury.private_builtin.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.term.h"
#include "mercury.time.h"
#include "mercury.tree234.h"







#line 33 "op.m"
MR_Float MR_CALL op__degrees_2_f_0(
#line 33 "op.m"
  MR_Float op__HeadVar__1_1)
#line 33 "op.m"
{
  {
    bool op__succeeded;
    MR_Float op__HeadVar__2_2;
    MR_Float op__V_4_4;
    MR_Float op__V_5_5;
    MR_Float op__V_6_6 = (MR_Float) 180.000000000000;

#line 65 "op.m"
    op__V_4_4 = (op__HeadVar__1_1 * op__V_6_6);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL op__degrees_2_f_0
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
op__V_5_5
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL op__degrees_2_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
op__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (op__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      op__succeeded = (op__V_5_5 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (op__succeeded)
      {
        MR_Word op__V_7_11;
        MR_String op__V_8_12 = (MR_String) "float:'/'";
        MR_Word op__TypeInfo_9_13;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        op__V_7_11 = (MR_Word) op__V_8_12;
        op__TypeInfo_9_13 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(op__TypeInfo_9_13, ((MR_Box) (op__V_7_11)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      op__HeadVar__2_2 = (op__V_4_4 / op__V_5_5);
    return op__HeadVar__2_2;
  }
#line 33 "op.m"
}

#line 32 "op.m"
MR_Float MR_CALL op__radians_2_f_0(
#line 32 "op.m"
  MR_Float op__HeadVar__1_1)
#line 32 "op.m"
{
  {
    bool op__succeeded;
    MR_Float op__HeadVar__2_2;
    MR_Float op__V_4_4;
    MR_Float op__V_5_5;
    MR_Float op__V_6_6;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL op__radians_2_f_0
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
op__V_6_6
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 64 "op.m"
    op__V_4_4 = (op__HeadVar__1_1 * op__V_6_6);
#line 64 "op.m"
    op__V_5_5 = (MR_Float) 180.000000000000;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL op__radians_2_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
op__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (op__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      op__succeeded = (op__V_5_5 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (op__succeeded)
      {
        MR_Word op__V_7_11;
        MR_String op__V_8_12 = (MR_String) "float:'/'";
        MR_Word op__TypeInfo_9_13;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        op__V_7_11 = (MR_Word) op__V_8_12;
        op__TypeInfo_9_13 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(op__TypeInfo_9_13, ((MR_Box) (op__V_7_11)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      op__HeadVar__2_2 = (op__V_4_4 / op__V_5_5);
    return op__HeadVar__2_2;
  }
#line 32 "op.m"
}

#line 30 "op.m"
MR_Float MR_CALL op__op_subf_3_f_0(
#line 30 "op.m"
  MR_Float op__HeadVar__1_1,
#line 30 "op.m"
  MR_Float op__HeadVar__2_2)
#line 30 "op.m"
{
#line 62 "op.m"
  {
#line 62 "op.m"
    bool op__succeeded;
#line 62 "op.m"
    MR_Float op__HeadVar__3_3 = (op__HeadVar__1_1 - op__HeadVar__2_2);

#line 62 "op.m"
    return op__HeadVar__3_3;
#line 62 "op.m"
  }
#line 30 "op.m"
}

#line 29 "op.m"
MR_Integer MR_CALL op__op_subi_3_f_0(
#line 29 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 29 "op.m"
  MR_Integer op__HeadVar__2_2)
#line 29 "op.m"
{
#line 61 "op.m"
  {
#line 61 "op.m"
    bool op__succeeded;
#line 61 "op.m"
    MR_Integer op__HeadVar__3_3 = (op__HeadVar__1_1 - op__HeadVar__2_2);

#line 61 "op.m"
    return op__HeadVar__3_3;
#line 61 "op.m"
  }
#line 29 "op.m"
}

#line 28 "op.m"
MR_Float MR_CALL op__op_sqrt_2_f_0(
#line 28 "op.m"
  MR_Float op__HeadVar__1_1)
#line 28 "op.m"
{
#line 60 "op.m"
  {
#line 60 "op.m"
    bool op__succeeded;
#line 60 "op.m"
    MR_Float op__HeadVar__2_2;

#line 60 "op.m"
    {
#line 60 "op.m"
      return op__HeadVar__2_2 = mercury__math__sqrt_2_f_0(op__HeadVar__1_1);
    }
#line 60 "op.m"
    return op__HeadVar__2_2;
#line 60 "op.m"
  }
#line 28 "op.m"
}

#line 27 "op.m"
MR_Float MR_CALL op__op_sin_2_f_0(
#line 27 "op.m"
  MR_Float op__HeadVar__1_1)
#line 27 "op.m"
{
  {
    bool op__succeeded;
    MR_Float op__HeadVar__2_2;
    MR_Float op__V_4_4;

#line 59 "op.m"
    {
#line 59 "op.m"
      op__V_4_4 = op__radians_2_f_0(op__HeadVar__1_1);
    }
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL op__op_sin_2_f_0
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Sin;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
op__V_4_4
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);

#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
op__HeadVar__2_2
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Sin;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
    return op__HeadVar__2_2;
  }
#line 27 "op.m"
}

#line 26 "op.m"
MR_Float MR_CALL op__op_real_2_f_0(
#line 26 "op.m"
  MR_Integer op__HeadVar__1_1)
#line 26 "op.m"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
  {
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
    bool op__succeeded;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
    MR_Float op__HeadVar__2_2;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#define MR_PROC_LABEL op__op_real_2_f_0
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	MR_Integer IntVal;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	MR_Float FloatVal;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	IntVal = 
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
op__HeadVar__1_1
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
		{
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

	FloatVal = IntVal;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

		;}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#undef MR_PROC_LABEL
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
op__HeadVar__2_2
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
 = FloatVal;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
}
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
    return op__HeadVar__2_2;
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
  }
#line 26 "op.m"
}

#line 25 "op.m"
MR_Float MR_CALL op__op_negf_2_f_0(
#line 25 "op.m"
  MR_Float op__HeadVar__1_1)
#line 25 "op.m"
{
#line 57 "op.m"
  {
#line 57 "op.m"
    bool op__succeeded;
#line 57 "op.m"
    MR_Float op__HeadVar__2_2 = (((MR_Float) 0.00000000000000) - op__HeadVar__1_1);

#line 57 "op.m"
    return op__HeadVar__2_2;
#line 57 "op.m"
  }
#line 25 "op.m"
}

#line 24 "op.m"
MR_Integer MR_CALL op__op_negi_2_f_0(
#line 24 "op.m"
  MR_Integer op__HeadVar__1_1)
#line 24 "op.m"
{
#line 56 "op.m"
  {
#line 56 "op.m"
    bool op__succeeded;
#line 56 "op.m"
    MR_Integer op__HeadVar__2_2 = ((MR_Integer) 0 - op__HeadVar__1_1);

#line 56 "op.m"
    return op__HeadVar__2_2;
#line 56 "op.m"
  }
#line 24 "op.m"
}

#line 23 "op.m"
MR_Float MR_CALL op__op_mulf_3_f_0(
#line 23 "op.m"
  MR_Float op__HeadVar__1_1,
#line 23 "op.m"
  MR_Float op__HeadVar__2_2)
#line 23 "op.m"
{
#line 55 "op.m"
  {
#line 55 "op.m"
    bool op__succeeded;
#line 55 "op.m"
    MR_Float op__HeadVar__3_3 = (op__HeadVar__1_1 * op__HeadVar__2_2);

#line 55 "op.m"
    return op__HeadVar__3_3;
#line 55 "op.m"
  }
#line 23 "op.m"
}

#line 22 "op.m"
MR_Integer MR_CALL op__op_muli_3_f_0(
#line 22 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 22 "op.m"
  MR_Integer op__HeadVar__2_2)
#line 22 "op.m"
{
#line 54 "op.m"
  {
#line 54 "op.m"
    bool op__succeeded;
#line 54 "op.m"
    MR_Integer op__HeadVar__3_3 = (op__HeadVar__1_1 * op__HeadVar__2_2);

#line 54 "op.m"
    return op__HeadVar__3_3;
#line 54 "op.m"
  }
#line 22 "op.m"
}

#line 21 "op.m"
MR_Integer MR_CALL op__op_modi_3_f_0(
#line 21 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 21 "op.m"
  MR_Integer op__HeadVar__2_2)
#line 21 "op.m"
{
#line 53 "op.m"
  {
#line 53 "op.m"
    bool op__succeeded;
#line 53 "op.m"
    MR_Integer op__HeadVar__3_3 = (op__HeadVar__1_1 % op__HeadVar__2_2);

#line 53 "op.m"
    return op__HeadVar__3_3;
#line 53 "op.m"
  }
#line 21 "op.m"
}

#line 20 "op.m"
MR_Word MR_CALL op__op_lessf_3_f_0(
#line 20 "op.m"
  MR_Float op__HeadVar__1_1,
#line 20 "op.m"
  MR_Float op__HeadVar__2_2)
#line 20 "op.m"
{
#line 52 "op.m"
  {
#line 52 "op.m"
    bool op__succeeded = (op__HeadVar__1_1 < op__HeadVar__2_2);
#line 52 "op.m"
    MR_Word op__HeadVar__3_3;

#line 52 "op.m"
    if (op__succeeded)
#line 52 "op.m"
      op__HeadVar__3_3 = (MR_Integer) 1;
#line 52 "op.m"
    else
#line 52 "op.m"
      op__HeadVar__3_3 = (MR_Integer) 0;
#line 52 "op.m"
    return op__HeadVar__3_3;
#line 52 "op.m"
  }
#line 20 "op.m"
}

#line 19 "op.m"
MR_Word MR_CALL op__op_lessi_3_f_0(
#line 19 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 19 "op.m"
  MR_Integer op__HeadVar__2_2)
#line 19 "op.m"
{
#line 51 "op.m"
  {
#line 51 "op.m"
    bool op__succeeded = (op__HeadVar__1_1 < op__HeadVar__2_2);
#line 51 "op.m"
    MR_Word op__HeadVar__3_3;

#line 51 "op.m"
    if (op__succeeded)
#line 51 "op.m"
      op__HeadVar__3_3 = (MR_Integer) 1;
#line 51 "op.m"
    else
#line 51 "op.m"
      op__HeadVar__3_3 = (MR_Integer) 0;
#line 51 "op.m"
    return op__HeadVar__3_3;
#line 51 "op.m"
  }
#line 19 "op.m"
}

#line 18 "op.m"
MR_Float MR_CALL op__op_frac_2_f_0(
#line 18 "op.m"
  MR_Float op__HeadVar__1_1)
#line 18 "op.m"
{
  {
    bool op__succeeded;
    MR_Float op__HeadVar__2_2;
    MR_Float op__V_4_4;
    MR_Float op__V_12_12 = (MR_Float) 0.00000000000000;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
    op__succeeded = (op__HeadVar__1_1 < op__V_12_12);
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
    if (op__succeeded)
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
      {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL op__op_frac_2_f_0
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Num;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Ceil;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	Num = 
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
op__HeadVar__1_1
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Ceil = ceil(Num);

#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
op__V_4_4
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Ceil;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
    else
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
      {
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL op__op_frac_2_f_0
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Num;
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Floor;
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	Num = 
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
op__HeadVar__1_1
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Floor = floor(Num);

#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
op__V_4_4
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Floor;
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 30 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
      }
#line 50 "op.m"
    op__HeadVar__2_2 = (op__HeadVar__1_1 - op__V_4_4);
    return op__HeadVar__2_2;
  }
#line 18 "op.m"
}

#line 17 "op.m"
MR_Integer MR_CALL op__op_floor_2_f_0(
#line 17 "op.m"
  MR_Float op__HeadVar__1_1)
#line 17 "op.m"
{
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
  {
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    bool op__succeeded;
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    MR_Integer op__HeadVar__2_2;

#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL op__op_floor_2_f_0
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Float X;
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Integer Floor;
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	X = 
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
op__HeadVar__1_1
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
;
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

	Floor = (MR_Integer) floor(X);

#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
op__HeadVar__2_2
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = Floor;
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    return op__HeadVar__2_2;
#line 50 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
  }
#line 17 "op.m"
}

#line 16 "op.m"
MR_Word MR_CALL op__op_eqf_3_f_0(
#line 16 "op.m"
  MR_Float op__HeadVar__1_1,
#line 16 "op.m"
  MR_Float op__HeadVar__2_2)
#line 16 "op.m"
{
#line 48 "op.m"
  {
#line 48 "op.m"
    bool op__succeeded = (op__HeadVar__1_1 == op__HeadVar__2_2);
#line 48 "op.m"
    MR_Word op__HeadVar__3_3;

#line 48 "op.m"
    if (op__succeeded)
#line 48 "op.m"
      op__HeadVar__3_3 = (MR_Integer) 1;
#line 48 "op.m"
    else
#line 48 "op.m"
      op__HeadVar__3_3 = (MR_Integer) 0;
#line 48 "op.m"
    return op__HeadVar__3_3;
#line 48 "op.m"
  }
#line 16 "op.m"
}

#line 15 "op.m"
MR_Word MR_CALL op__op_eqi_3_f_0(
#line 15 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 15 "op.m"
  MR_Integer op__HeadVar__2_2)
#line 15 "op.m"
{
#line 47 "op.m"
  {
#line 47 "op.m"
    bool op__succeeded = (op__HeadVar__1_1 == op__HeadVar__2_2);
#line 47 "op.m"
    MR_Word op__HeadVar__3_3;

#line 47 "op.m"
    if (op__succeeded)
#line 47 "op.m"
      op__HeadVar__3_3 = (MR_Integer) 1;
#line 47 "op.m"
    else
#line 47 "op.m"
      op__HeadVar__3_3 = (MR_Integer) 0;
#line 47 "op.m"
    return op__HeadVar__3_3;
#line 47 "op.m"
  }
#line 15 "op.m"
}

#line 14 "op.m"
MR_Float MR_CALL op__op_divf_3_f_0(
#line 14 "op.m"
  MR_Float op__HeadVar__1_1,
#line 14 "op.m"
  MR_Float op__HeadVar__2_2)
#line 14 "op.m"
{
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
  {
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    bool op__succeeded;
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    MR_Float op__HeadVar__3_3;

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL op__op_divf_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
op__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (op__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      op__succeeded = (op__HeadVar__2_2 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (op__succeeded)
      {
        MR_Word op__V_7_9;
        MR_String op__V_8_10 = (MR_String) "float:'/'";
        MR_Word op__TypeInfo_9_11;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        op__V_7_9 = (MR_Word) op__V_8_10;
        op__TypeInfo_9_11 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(op__TypeInfo_9_11, ((MR_Box) (op__V_7_9)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      op__HeadVar__3_3 = (op__HeadVar__1_1 / op__HeadVar__2_2);
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    return op__HeadVar__3_3;
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
  }
#line 14 "op.m"
}

#line 13 "op.m"
MR_Integer MR_CALL op__op_divi_3_f_0(
#line 13 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 13 "op.m"
  MR_Integer op__HeadVar__2_2)
#line 13 "op.m"
{
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
  {
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
    bool op__succeeded;
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
    MR_Integer op__HeadVar__3_3;

#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
{
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#define MR_PROC_LABEL op__op_divi_3_f_0
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
		{
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"

		;}
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#undef MR_PROC_LABEL
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	if (SUCCESS_INDICATOR) {
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
	}
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
op__succeeded
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
 = SUCCESS_INDICATOR;
#line 120 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
}
    if (op__succeeded)
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
      op__succeeded = (op__HeadVar__2_2 == (MR_Integer) 0);
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
    if (op__succeeded)
      {
        MR_Word op__V_7_9;
        MR_String op__V_8_10 = (MR_String) "int:'//'";
        MR_Word op__TypeInfo_9_11;

#line 62 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
        op__V_7_9 = (MR_Word) op__V_8_10;
        op__TypeInfo_9_11 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 64 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
        {
#line 64 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
          mercury__exception__throw_1_p_0(op__TypeInfo_9_11, ((MR_Box) (op__V_7_9)));
        }
      }
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
    else
#line 66 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
      op__HeadVar__3_3 = (op__HeadVar__1_1 / op__HeadVar__2_2);
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
    return op__HeadVar__3_3;
#line 65 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/int.opt"
  }
#line 13 "op.m"
}

#line 12 "op.m"
MR_Float MR_CALL op__op_cos_2_f_0(
#line 12 "op.m"
  MR_Float op__HeadVar__1_1)
#line 12 "op.m"
{
  {
    bool op__succeeded;
    MR_Float op__HeadVar__2_2;
    MR_Float op__V_4_4;

#line 44 "op.m"
    {
#line 44 "op.m"
      op__V_4_4 = op__radians_2_f_0(op__HeadVar__1_1);
    }
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL op__op_cos_2_f_0
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Cos;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
op__V_4_4
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
op__HeadVar__2_2
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Cos;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
    return op__HeadVar__2_2;
  }
#line 12 "op.m"
}

#line 11 "op.m"
MR_Float MR_CALL op__op_clampf_2_f_0(
#line 11 "op.m"
  MR_Float op__HeadVar__1_1)
#line 11 "op.m"
{
#line 43 "op.m"
  {
#line 43 "op.m"
    bool op__succeeded;
#line 43 "op.m"
    MR_Float op__HeadVar__2_2;
    MR_Float op__V_6_6 = (MR_Float) 0.00000000000000;

#line 43 "op.m"
    op__succeeded = (op__HeadVar__1_1 < op__V_6_6);
#line 43 "op.m"
    if (op__succeeded)
#line 43 "op.m"
      op__HeadVar__2_2 = (MR_Float) 0.00000000000000;
#line 43 "op.m"
    else
#line 43 "op.m"
      {
        MR_Float op__V_7_7 = (MR_Float) 1.00000000000000;

#line 43 "op.m"
        op__succeeded = (op__HeadVar__1_1 > op__V_7_7);
#line 43 "op.m"
        if (op__succeeded)
#line 43 "op.m"
          op__HeadVar__2_2 = (MR_Float) 1.00000000000000;
#line 43 "op.m"
        else
#line 43 "op.m"
          op__HeadVar__2_2 = op__HeadVar__1_1;
#line 43 "op.m"
      }
#line 43 "op.m"
    return op__HeadVar__2_2;
#line 43 "op.m"
  }
#line 11 "op.m"
}

#line 10 "op.m"
MR_Float MR_CALL op__op_asin_2_f_0(
#line 10 "op.m"
  MR_Float op__HeadVar__1_1)
#line 10 "op.m"
{
  {
    bool op__succeeded;
    MR_Float op__HeadVar__2_2;
    MR_Float op__V_4_4;

#line 42 "op.m"
    {
#line 42 "op.m"
      op__V_4_4 = mercury__math__asin_2_f_0(op__HeadVar__1_1);
    }
#line 42 "op.m"
    {
#line 42 "op.m"
      return op__HeadVar__2_2 = op__degrees_2_f_0(op__V_4_4);
    }
    return op__HeadVar__2_2;
  }
#line 10 "op.m"
}

#line 9 "op.m"
MR_Float MR_CALL op__op_addf_3_f_0(
#line 9 "op.m"
  MR_Float op__HeadVar__1_1,
#line 9 "op.m"
  MR_Float op__HeadVar__2_2)
#line 9 "op.m"
{
#line 41 "op.m"
  {
#line 41 "op.m"
    bool op__succeeded;
#line 41 "op.m"
    MR_Float op__HeadVar__3_3 = (op__HeadVar__1_1 + op__HeadVar__2_2);

#line 41 "op.m"
    return op__HeadVar__3_3;
#line 41 "op.m"
  }
#line 9 "op.m"
}

#line 8 "op.m"
MR_Integer MR_CALL op__op_addi_3_f_0(
#line 8 "op.m"
  MR_Integer op__HeadVar__1_1,
#line 8 "op.m"
  MR_Integer op__HeadVar__2_2)
#line 8 "op.m"
{
#line 40 "op.m"
  {
#line 40 "op.m"
    bool op__succeeded;
#line 40 "op.m"
    MR_Integer op__HeadVar__3_3 = (op__HeadVar__1_1 + op__HeadVar__2_2);

#line 40 "op.m"
    return op__HeadVar__3_3;
#line 40 "op.m"
  }
#line 8 "op.m"
}

#line 7 "op.m"
MR_Float MR_CALL op__op_acos_2_f_0(
#line 7 "op.m"
  MR_Float op__HeadVar__1_1)
#line 7 "op.m"
{
  {
    bool op__succeeded;
    MR_Float op__HeadVar__2_2;
    MR_Float op__V_4_4;

#line 39 "op.m"
    {
#line 39 "op.m"
      op__V_4_4 = mercury__math__acos_2_f_0(op__HeadVar__1_1);
    }
#line 39 "op.m"
    {
#line 39 "op.m"
      return op__HeadVar__2_2 = op__degrees_2_f_0(op__V_4_4);
    }
    return op__HeadVar__2_2;
  }
#line 7 "op.m"
}

void mercury__op__init(void)
{
}

void mercury__op__init_type_tables(void)
{
}

void mercury__op__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module op. */
