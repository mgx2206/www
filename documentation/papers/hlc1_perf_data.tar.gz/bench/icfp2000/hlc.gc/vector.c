/*
** Automatically generated from `vector.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module vector. */
/* :- implementation. */

#include "vector.h"


#include "mercury.assoc_list.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.enum.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "mercury.ops.h"
#include "mercury.private_builtin.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.term.h"
#include "mercury.time.h"
#include "mercury.tree234.h"



static const MR_DuFunctorDescPtr vector__vector__du_name_ordered_vector_0[1];
static const MR_DuFunctorDesc vector__vector__du_functor_desc_vector_0_0;
static const MR_PseudoTypeInfo vector__vector__field_types_vector_0_0[3];
static const MR_DuPtagLayout vector__vector__du_ptag_ordered_vector_0[1];
static const MR_DuFunctorDescPtr vector__vector__du_stag_ordered_vector_0_0[1];
#line 132 "vector.m"
static /* final */ const MR_Float vector__float_22_0_1;
#line 132 "vector.m"
static /* final */ const MR_Float vector__float_22_0_2;
#line 132 "vector.m"
static /* final */ const MR_Float vector__float_22_0_3;
#line 132 "vector.m"
static /* final */ const MR_Box vector__const_22_0_4_HeadVar__1_1[3];
#line 131 "vector.m"
static /* final */ const MR_Float vector__float_21_0_1;
#line 131 "vector.m"
static /* final */ const MR_Float vector__float_21_0_2;
#line 131 "vector.m"
static /* final */ const MR_Float vector__float_21_0_3;
#line 131 "vector.m"
static /* final */ const MR_Box vector__const_21_0_4_HeadVar__1_1[3];
#line 130 "vector.m"
static /* final */ const MR_Float vector__float_20_0_1;
#line 130 "vector.m"
static /* final */ const MR_Float vector__float_20_0_2;
#line 130 "vector.m"
static /* final */ const MR_Float vector__float_20_0_3;
#line 130 "vector.m"
static /* final */ const MR_Box vector__const_20_0_4_HeadVar__1_1[3];
#line 129 "vector.m"
static /* final */ const MR_Float vector__float_19_0_1;
#line 129 "vector.m"
static /* final */ const MR_Float vector__float_19_0_2;
#line 129 "vector.m"
static /* final */ const MR_Float vector__float_19_0_3;
#line 129 "vector.m"
static /* final */ const MR_Box vector__const_19_0_4_HeadVar__1_1[3];



const MR_TypeCtorInfo_Struct vector__vector__type_ctor_info_vector_0 = {
		(MR_Integer) 0,
		((MR_Box) (vector____Unify____vector_0_0)),
		((MR_Box) (vector____Unify____vector_0_0)),
		((MR_Box) (vector____Compare____vector_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "vector",
		(MR_String) "vector",
		(MR_Integer) 4,
		{
		(MR_Box) vector__vector__du_name_ordered_vector_0},
		{
		(MR_Box) vector__vector__du_ptag_ordered_vector_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct vector__vector__type_ctor_info_real_0 = {
		(MR_Integer) 0,
		((MR_Box) (vector____Unify____real_0_0)),
		((MR_Box) (vector____Unify____real_0_0)),
		((MR_Box) (vector____Compare____real_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "vector",
		(MR_String) "real",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&mercury__builtin____type_ctor_info_float_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct vector__vector__type_ctor_info_position_0 = {
		(MR_Integer) 0,
		((MR_Box) (vector____Unify____position_0_0)),
		((MR_Box) (vector____Unify____position_0_0)),
		((MR_Box) (vector____Compare____position_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "vector",
		(MR_String) "position",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&vector__vector__type_ctor_info_vector_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct vector__vector__type_ctor_info_point_0 = {
		(MR_Integer) 0,
		((MR_Box) (vector____Unify____point_0_0)),
		((MR_Box) (vector____Unify____point_0_0)),
		((MR_Box) (vector____Compare____point_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "vector",
		(MR_String) "point",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&vector__vector__type_ctor_info_vector_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
static const MR_DuFunctorDescPtr vector__vector__du_name_ordered_vector_0[1] = {
		(&vector__vector__du_functor_desc_vector_0_0)};
static const MR_DuFunctorDesc vector__vector__du_functor_desc_vector_0_0 = {
		(MR_String) "point",
		(MR_Integer) 3,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		vector__vector__field_types_vector_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo vector__vector__field_types_vector_0_0[3] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuPtagLayout vector__vector__du_ptag_ordered_vector_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		vector__vector__du_stag_ordered_vector_0_0}};
static const MR_DuFunctorDescPtr vector__vector__du_stag_ordered_vector_0_0[1] = {
		(&vector__vector__du_functor_desc_vector_0_0)};

#line 11 "vector.m"
void MR_CALL vector____Compare____point_0_0(
#line 11 "vector.m"
  MR_Word * vector__HeadVar__1_1,
#line 11 "vector.m"
  MR_Word vector__HeadVar__2_2,
#line 11 "vector.m"
  MR_Word vector__HeadVar__3_3)
#line 11 "vector.m"
{
#line 11 "vector.m"
  {
#line 11 "vector.m"
    bool vector__succeeded;
#line 11 "vector.m"
    MR_Word vector__conv1_HeadVar__2_2 = (MR_Word) vector__HeadVar__2_2;
#line 11 "vector.m"
    MR_Word vector__conv2_HeadVar__3_3 = (MR_Word) vector__HeadVar__3_3;

#line 11 "vector.m"
    {
#line 11 "vector.m"
      vector____Compare____vector_0_0(vector__HeadVar__1_1, vector__conv1_HeadVar__2_2, vector__conv2_HeadVar__3_3);
#line 11 "vector.m"
      return;
    }
#line 11 "vector.m"
  }
#line 11 "vector.m"
}

#line 11 "vector.m"
bool MR_CALL vector____Unify____point_0_0(
#line 11 "vector.m"
  MR_Word vector__HeadVar__1_1,
#line 11 "vector.m"
  MR_Word vector__HeadVar__2_2)
#line 11 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__conv1_HeadVar__1_1 = (MR_Word) vector__HeadVar__1_1;
    MR_Word vector__conv2_HeadVar__2_2 = (MR_Word) vector__HeadVar__2_2;
    MR_Float vector__V_3_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__conv1_HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__conv1_HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__conv1_HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__conv2_HeadVar__2_2, (MR_Integer) 0)));
    MR_Float vector__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__conv2_HeadVar__2_2, (MR_Integer) 1)));
    MR_Float vector__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__conv2_HeadVar__2_2, (MR_Integer) 2)));

    vector__succeeded = (vector__V_3_3 == vector__V_6_6);
    if (vector__succeeded)
      {
        vector__succeeded = (vector__V_4_4 == vector__V_7_7);
        if (vector__succeeded)
          vector__succeeded = (vector__V_5_5 == vector__V_8_8);
      }
    if (vector__succeeded)
      vector__succeeded = TRUE;
    return vector__succeeded;
  }
#line 11 "vector.m"
}

#line 10 "vector.m"
void MR_CALL vector____Compare____position_0_0(
#line 10 "vector.m"
  MR_Word * vector__HeadVar__1_1,
#line 10 "vector.m"
  MR_Word vector__HeadVar__2_2,
#line 10 "vector.m"
  MR_Word vector__HeadVar__3_3)
#line 10 "vector.m"
{
#line 10 "vector.m"
  {
#line 10 "vector.m"
    bool vector__succeeded;
#line 10 "vector.m"
    MR_Word vector__conv1_HeadVar__2_2 = (MR_Word) vector__HeadVar__2_2;
#line 10 "vector.m"
    MR_Word vector__conv2_HeadVar__3_3 = (MR_Word) vector__HeadVar__3_3;

#line 10 "vector.m"
    {
#line 10 "vector.m"
      vector____Compare____vector_0_0(vector__HeadVar__1_1, vector__conv1_HeadVar__2_2, vector__conv2_HeadVar__3_3);
#line 10 "vector.m"
      return;
    }
#line 10 "vector.m"
  }
#line 10 "vector.m"
}

#line 10 "vector.m"
bool MR_CALL vector____Unify____position_0_0(
#line 10 "vector.m"
  MR_Word vector__HeadVar__1_1,
#line 10 "vector.m"
  MR_Word vector__HeadVar__2_2)
#line 10 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__conv1_HeadVar__1_1 = (MR_Word) vector__HeadVar__1_1;
    MR_Word vector__conv2_HeadVar__2_2 = (MR_Word) vector__HeadVar__2_2;
    MR_Float vector__V_3_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__conv1_HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__conv1_HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__conv1_HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__conv2_HeadVar__2_2, (MR_Integer) 0)));
    MR_Float vector__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__conv2_HeadVar__2_2, (MR_Integer) 1)));
    MR_Float vector__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__conv2_HeadVar__2_2, (MR_Integer) 2)));

    vector__succeeded = (vector__V_3_3 == vector__V_6_6);
    if (vector__succeeded)
      {
        vector__succeeded = (vector__V_4_4 == vector__V_7_7);
        if (vector__succeeded)
          vector__succeeded = (vector__V_5_5 == vector__V_8_8);
      }
    if (vector__succeeded)
      vector__succeeded = TRUE;
    return vector__succeeded;
  }
#line 10 "vector.m"
}

#line 9 "vector.m"
void MR_CALL vector____Compare____vector_0_0(
#line 9 "vector.m"
  MR_Word * vector__HeadVar__1_1,
#line 9 "vector.m"
  MR_Word vector__HeadVar__2_2,
#line 9 "vector.m"
  MR_Word vector__HeadVar__3_3)
#line 9 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Float vector__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float vector__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float vector__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float vector__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float vector__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, (MR_Integer) 1)));
    MR_Float vector__V_9_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, (MR_Integer) 2)));
#line 9 "vector.m"
    MR_Word vector__V_10_10;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    vector__succeeded = (vector__V_4_4 < vector__V_7_7);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (vector__succeeded)
      {
        MR_Word vector__V_24_24 = (MR_Integer) 1;

#line 9 "vector.m"
        vector__succeeded = (vector__V_24_24 == (MR_Integer) 0);
#line 9 "vector.m"
        vector__succeeded = !(vector__succeeded);
        if (vector__succeeded)
          {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            vector__V_10_10 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            vector__succeeded = TRUE;
          }
      }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        vector__succeeded = (vector__V_4_4 > vector__V_7_7);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (vector__succeeded)
          {
            MR_Word vector__V_25_25 = (MR_Integer) 2;

#line 9 "vector.m"
            vector__succeeded = (vector__V_25_25 == (MR_Integer) 0);
#line 9 "vector.m"
            vector__succeeded = !(vector__succeeded);
            if (vector__succeeded)
              {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                vector__V_10_10 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                vector__succeeded = TRUE;
              }
          }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
          {
            MR_Word vector__V_26_26 = (MR_Integer) 0;

#line 9 "vector.m"
            vector__succeeded = (vector__V_26_26 == (MR_Integer) 0);
#line 9 "vector.m"
            vector__succeeded = !(vector__succeeded);
            if (vector__succeeded)
              {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                vector__V_10_10 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                vector__succeeded = TRUE;
              }
          }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 9 "vector.m"
    if (vector__succeeded)
#line 9 "vector.m"
      *vector__HeadVar__1_1 = vector__V_10_10;
#line 9 "vector.m"
    else
#line 9 "vector.m"
      {
#line 9 "vector.m"
        MR_Word vector__V_11_11;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        vector__succeeded = (vector__V_5_5 < vector__V_8_8);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (vector__succeeded)
          {
            MR_Word vector__V_27_27 = (MR_Integer) 1;

#line 9 "vector.m"
            vector__succeeded = (vector__V_27_27 == (MR_Integer) 0);
#line 9 "vector.m"
            vector__succeeded = !(vector__succeeded);
            if (vector__succeeded)
              {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                vector__V_11_11 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                vector__succeeded = TRUE;
              }
          }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            vector__succeeded = (vector__V_5_5 > vector__V_8_8);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (vector__succeeded)
              {
                MR_Word vector__V_28_28 = (MR_Integer) 2;

#line 9 "vector.m"
                vector__succeeded = (vector__V_28_28 == (MR_Integer) 0);
#line 9 "vector.m"
                vector__succeeded = !(vector__succeeded);
                if (vector__succeeded)
                  {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    vector__V_11_11 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    vector__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
              {
                MR_Word vector__V_29_29 = (MR_Integer) 0;

#line 9 "vector.m"
                vector__succeeded = (vector__V_29_29 == (MR_Integer) 0);
#line 9 "vector.m"
                vector__succeeded = !(vector__succeeded);
                if (vector__succeeded)
                  {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    vector__V_11_11 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    vector__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 9 "vector.m"
        if (vector__succeeded)
#line 9 "vector.m"
          *vector__HeadVar__1_1 = vector__V_11_11;
#line 9 "vector.m"
        else
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            vector__succeeded = (vector__V_6_6 < vector__V_9_9);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (vector__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              *vector__HeadVar__1_1 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                vector__succeeded = (vector__V_6_6 > vector__V_9_9);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (vector__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *vector__HeadVar__1_1 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *vector__HeadVar__1_1 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 9 "vector.m"
      }
  }
#line 9 "vector.m"
}

#line 9 "vector.m"
bool MR_CALL vector____Unify____vector_0_0(
#line 9 "vector.m"
  MR_Word vector__HeadVar__1_1,
#line 9 "vector.m"
  MR_Word vector__HeadVar__2_2)
#line 9 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Float vector__V_3_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float vector__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float vector__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 2)));

    vector__succeeded = (vector__V_3_3 == vector__V_6_6);
    if (vector__succeeded)
      {
        vector__succeeded = (vector__V_4_4 == vector__V_7_7);
        if (vector__succeeded)
          vector__succeeded = (vector__V_5_5 == vector__V_8_8);
      }
    return vector__succeeded;
  }
#line 9 "vector.m"
}

#line 8 "vector.m"
void MR_CALL vector____Compare____real_0_0(
#line 8 "vector.m"
  MR_Word * vector__HeadVar__1_1,
#line 8 "vector.m"
  MR_Word vector__HeadVar__2_2,
#line 8 "vector.m"
  MR_Word vector__HeadVar__3_3)
#line 8 "vector.m"
{
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  {
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    bool vector__succeeded;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Float vector__conv1_HeadVar__2_2 = MR_unbox_float((MR_Box) vector__HeadVar__2_2);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    MR_Float vector__conv2_HeadVar__3_3 = MR_unbox_float((MR_Box) vector__HeadVar__3_3);

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    vector__succeeded = (vector__conv1_HeadVar__2_2 < vector__conv2_HeadVar__3_3);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (vector__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      *vector__HeadVar__1_1 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        vector__succeeded = (vector__conv1_HeadVar__2_2 > vector__conv2_HeadVar__3_3);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (vector__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *vector__HeadVar__1_1 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          *vector__HeadVar__1_1 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
  }
#line 8 "vector.m"
}

#line 8 "vector.m"
bool MR_CALL vector____Unify____real_0_0(
#line 8 "vector.m"
  MR_Word vector__HeadVar__1_1,
#line 8 "vector.m"
  MR_Word vector__HeadVar__2_2)
#line 8 "vector.m"
{
#line 8 "vector.m"
  {
#line 8 "vector.m"
    bool vector__succeeded;
#line 8 "vector.m"
    MR_Float vector__conv1_HeadVar__1_1 = MR_unbox_float((MR_Box) vector__HeadVar__1_1);
#line 8 "vector.m"
    MR_Float vector__conv2_HeadVar__2_2 = MR_unbox_float((MR_Box) vector__HeadVar__2_2);

#line 8 "vector.m"
    vector__succeeded = (vector__conv1_HeadVar__1_1 == vector__conv2_HeadVar__2_2);
#line 8 "vector.m"
    if (vector__succeeded)
#line 8 "vector.m"
      vector__succeeded = TRUE;
#line 8 "vector.m"
    return vector__succeeded;
#line 8 "vector.m"
  }
#line 8 "vector.m"
}

#line 65 "vector.m"
MR_Float MR_CALL vector__real_max_1_f_0(void)
#line 65 "vector.m"
{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
  {
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    bool vector__succeeded;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    MR_Float vector__HeadVar__1_1;

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL vector__real_max_1_f_0
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Float Max;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
Max = ML_FLOAT_MAX;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
vector__HeadVar__1_1
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = Max;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    return vector__HeadVar__1_1;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
  }
#line 65 "vector.m"
}

#line 64 "vector.m"
MR_Float MR_CALL vector__real_epsilon_1_f_0(void)
#line 64 "vector.m"
{
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
  {
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    bool vector__succeeded;
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    MR_Float vector__HeadVar__1_1;

#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL vector__real_epsilon_1_f_0
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Float Eps;
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
Eps = ML_FLOAT_EPSILON;
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
vector__HeadVar__1_1
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = Eps;
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    return vector__HeadVar__1_1;
#line 80 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
  }
#line 64 "vector.m"
}
#line 132 "vector.m"
static /* final */ const MR_Float vector__float_22_0_1 = (MR_Float) 0.00000000000000;
#line 132 "vector.m"
static /* final */ const MR_Float vector__float_22_0_2 = (MR_Float) 0.00000000000000;
#line 132 "vector.m"
static /* final */ const MR_Float vector__float_22_0_3 = (MR_Float) 1.00000000000000;
#line 132 "vector.m"
static /* final */ const MR_Box vector__const_22_0_4_HeadVar__1_1[3] = {
		(MR_Box) &vector__float_22_0_1,
		(MR_Box) &vector__float_22_0_2,
		(MR_Box) &vector__float_22_0_3};

#line 62 "vector.m"
MR_Word MR_CALL vector__k_1_f_0(void)
#line 62 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__1_1 = (MR_Word) &vector__const_22_0_4_HeadVar__1_1;
    MR_Float vector__V_2_2 = (MR_Float) 0.00000000000000;
    MR_Float vector__V_3_3 = (MR_Float) 0.00000000000000;
    MR_Float vector__V_4_4 = (MR_Float) 1.00000000000000;

    return vector__HeadVar__1_1;
  }
#line 62 "vector.m"
}
#line 131 "vector.m"
static /* final */ const MR_Float vector__float_21_0_1 = (MR_Float) 0.00000000000000;
#line 131 "vector.m"
static /* final */ const MR_Float vector__float_21_0_2 = (MR_Float) 1.00000000000000;
#line 131 "vector.m"
static /* final */ const MR_Float vector__float_21_0_3 = (MR_Float) 0.00000000000000;
#line 131 "vector.m"
static /* final */ const MR_Box vector__const_21_0_4_HeadVar__1_1[3] = {
		(MR_Box) &vector__float_21_0_1,
		(MR_Box) &vector__float_21_0_2,
		(MR_Box) &vector__float_21_0_3};

#line 61 "vector.m"
MR_Word MR_CALL vector__j_1_f_0(void)
#line 61 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__1_1 = (MR_Word) &vector__const_21_0_4_HeadVar__1_1;
    MR_Float vector__V_2_2 = (MR_Float) 0.00000000000000;
    MR_Float vector__V_3_3 = (MR_Float) 1.00000000000000;
    MR_Float vector__V_4_4 = (MR_Float) 0.00000000000000;

    return vector__HeadVar__1_1;
  }
#line 61 "vector.m"
}
#line 130 "vector.m"
static /* final */ const MR_Float vector__float_20_0_1 = (MR_Float) 1.00000000000000;
#line 130 "vector.m"
static /* final */ const MR_Float vector__float_20_0_2 = (MR_Float) 0.00000000000000;
#line 130 "vector.m"
static /* final */ const MR_Float vector__float_20_0_3 = (MR_Float) 0.00000000000000;
#line 130 "vector.m"
static /* final */ const MR_Box vector__const_20_0_4_HeadVar__1_1[3] = {
		(MR_Box) &vector__float_20_0_1,
		(MR_Box) &vector__float_20_0_2,
		(MR_Box) &vector__float_20_0_3};

#line 60 "vector.m"
MR_Word MR_CALL vector__i_1_f_0(void)
#line 60 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__1_1 = (MR_Word) &vector__const_20_0_4_HeadVar__1_1;
    MR_Float vector__V_2_2 = (MR_Float) 1.00000000000000;
    MR_Float vector__V_3_3 = (MR_Float) 0.00000000000000;
    MR_Float vector__V_4_4 = (MR_Float) 0.00000000000000;

    return vector__HeadVar__1_1;
  }
#line 60 "vector.m"
}
#line 129 "vector.m"
static /* final */ const MR_Float vector__float_19_0_1 = (MR_Float) 0.00000000000000;
#line 129 "vector.m"
static /* final */ const MR_Float vector__float_19_0_2 = (MR_Float) 0.00000000000000;
#line 129 "vector.m"
static /* final */ const MR_Float vector__float_19_0_3 = (MR_Float) 0.00000000000000;
#line 129 "vector.m"
static /* final */ const MR_Box vector__const_19_0_4_HeadVar__1_1[3] = {
		(MR_Box) &vector__float_19_0_1,
		(MR_Box) &vector__float_19_0_2,
		(MR_Box) &vector__float_19_0_3};

#line 59 "vector.m"
MR_Word MR_CALL vector__zero_1_f_0(void)
#line 59 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__1_1 = (MR_Word) &vector__const_19_0_4_HeadVar__1_1;
    MR_Float vector__V_2_2 = (MR_Float) 0.00000000000000;
    MR_Float vector__V_3_3 = (MR_Float) 0.00000000000000;
    MR_Float vector__V_4_4 = (MR_Float) 0.00000000000000;

    return vector__HeadVar__1_1;
  }
#line 59 "vector.m"
}

#line 56 "vector.m"
MR_Word MR_CALL vector__zy_2_f_0(
#line 56 "vector.m"
  MR_Word vector__HeadVar__1_1)
#line 56 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__2_2;
    MR_Float vector__Y_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__Z_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
#line 127 "vector.m"
    MR_Float vector__V_3_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));

#line 127 "vector.m"
    {
#line 127 "vector.m"
      vector__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 127 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 0) = MR_box_float(vector__Z_5);
#line 127 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 1) = MR_box_float(vector__Y_4);
#line 127 "vector.m"
    }
    return vector__HeadVar__2_2;
  }
#line 56 "vector.m"
}

#line 54 "vector.m"
MR_Word MR_CALL vector__xz_2_f_0(
#line 54 "vector.m"
  MR_Word vector__HeadVar__1_1)
#line 54 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__2_2;
    MR_Float vector__X_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Z_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
#line 125 "vector.m"
    MR_Float vector__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));

#line 125 "vector.m"
    {
#line 125 "vector.m"
      vector__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 125 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 0) = MR_box_float(vector__X_3);
#line 125 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 1) = MR_box_float(vector__Z_5);
#line 125 "vector.m"
    }
    return vector__HeadVar__2_2;
  }
#line 54 "vector.m"
}

#line 52 "vector.m"
MR_Word MR_CALL vector__xy_2_f_0(
#line 52 "vector.m"
  MR_Word vector__HeadVar__1_1)
#line 52 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__2_2;
    MR_Float vector__X_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Y_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
#line 123 "vector.m"
    MR_Float vector__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));

#line 123 "vector.m"
    {
#line 123 "vector.m"
      vector__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "-");
#line 123 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 0) = MR_box_float(vector__X_3);
#line 123 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 1) = MR_box_float(vector__Y_4);
#line 123 "vector.m"
    }
    return vector__HeadVar__2_2;
  }
#line 52 "vector.m"
}

#line 49 "vector.m"
MR_Word MR_CALL vector__projectZY_2_f_0(
#line 49 "vector.m"
  MR_Word vector__HeadVar__1_1)
#line 49 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__2_2;
    MR_Float vector__Y_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__Z_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__V_6_6 = (MR_Float) 0.00000000000000;
#line 121 "vector.m"
    MR_Float vector__V_3_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));

#line 121 "vector.m"
    {
#line 121 "vector.m"
      vector__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 121 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 0) = MR_box_float(vector__V_6_6);
#line 121 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 1) = MR_box_float(vector__Y_4);
#line 121 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 2) = MR_box_float(vector__Z_5);
#line 121 "vector.m"
    }
    return vector__HeadVar__2_2;
  }
#line 49 "vector.m"
}

#line 47 "vector.m"
MR_Word MR_CALL vector__projectXZ_2_f_0(
#line 47 "vector.m"
  MR_Word vector__HeadVar__1_1)
#line 47 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__2_2;
    MR_Float vector__X_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Z_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__V_6_6 = (MR_Float) 0.00000000000000;
#line 119 "vector.m"
    MR_Float vector__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));

#line 119 "vector.m"
    {
#line 119 "vector.m"
      vector__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 119 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 0) = MR_box_float(vector__X_3);
#line 119 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 1) = MR_box_float(vector__V_6_6);
#line 119 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 2) = MR_box_float(vector__Z_5);
#line 119 "vector.m"
    }
    return vector__HeadVar__2_2;
  }
#line 47 "vector.m"
}

#line 45 "vector.m"
MR_Word MR_CALL vector__projectXY_2_f_0(
#line 45 "vector.m"
  MR_Word vector__HeadVar__1_1)
#line 45 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__2_2;
    MR_Float vector__X_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Y_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__V_6_6 = (MR_Float) 0.00000000000000;
#line 117 "vector.m"
    MR_Float vector__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));

#line 117 "vector.m"
    {
#line 117 "vector.m"
      vector__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 117 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 0) = MR_box_float(vector__X_3);
#line 117 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 1) = MR_box_float(vector__Y_4);
#line 117 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 2) = MR_box_float(vector__V_6_6);
#line 117 "vector.m"
    }
    return vector__HeadVar__2_2;
  }
#line 45 "vector.m"
}

#line 42 "vector.m"
MR_Word MR_CALL vector__project_3_f_0(
#line 42 "vector.m"
  MR_Word vector__HeadVar__1_1,
#line 42 "vector.m"
  MR_Word vector__HeadVar__2_2)
#line 42 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__3_3;
    MR_Float vector__V_8_8;
    MR_Float vector__Ax_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float vector__Ay_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float vector__Az_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float vector__Mag_12;
    MR_Float vector__V_14_14;
    MR_Float vector__V_15_15;
    MR_Float vector__V_16_16;
    MR_Float vector__V_18_18;
    MR_Float vector__V_22_22;
    MR_Float vector__V_23_23;
    MR_Float vector__V_24_24 = (vector__Ax_9 * vector__Ax_9);
    MR_Float vector__V_25_25 = (vector__Ay_10 * vector__Ay_10);
    MR_Float vector__Ax_47;
    MR_Float vector__Ay_48;
    MR_Float vector__Az_49;
    MR_Float vector__V_53_53;
    MR_Float vector__V_54_54;
    MR_Float vector__V_55_55;
    MR_Float vector__V_56_56;
    MR_Float vector__V_61_61;
    MR_Float vector__V_62_62;
    MR_Float vector__V_63_63;

#line 95 "vector.m"
    vector__V_22_22 = (vector__V_24_24 + vector__V_25_25);
#line 95 "vector.m"
    vector__V_23_23 = (vector__Az_11 * vector__Az_11);
#line 95 "vector.m"
    vector__V_18_18 = (vector__V_22_22 + vector__V_23_23);
#line 92 "vector.m"
    {
#line 92 "vector.m"
      vector__Mag_12 = mercury__math__sqrt_2_f_0(vector__V_18_18);
    }
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL vector__project_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
vector__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (vector__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__succeeded = (vector__Mag_12 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (vector__succeeded)
      {
        MR_Word vector__V_7_32;
        MR_String vector__V_8_33 = (MR_String) "float:'/'";
        MR_Word vector__TypeInfo_9_34;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        vector__V_7_32 = (MR_Word) vector__V_8_33;
        vector__TypeInfo_9_34 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(vector__TypeInfo_9_34, ((MR_Box) (vector__V_7_32)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__V_14_14 = (vector__Ax_9 / vector__Mag_12);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL vector__project_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
vector__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (vector__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__succeeded = (vector__Mag_12 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (vector__succeeded)
      {
        MR_Word vector__V_7_38;
        MR_String vector__V_8_39 = (MR_String) "float:'/'";
        MR_Word vector__TypeInfo_9_40;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        vector__V_7_38 = (MR_Word) vector__V_8_39;
        vector__TypeInfo_9_40 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(vector__TypeInfo_9_40, ((MR_Box) (vector__V_7_38)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__V_15_15 = (vector__Ay_10 / vector__Mag_12);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL vector__project_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
vector__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (vector__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__succeeded = (vector__Mag_12 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (vector__succeeded)
      {
        MR_Word vector__V_7_44;
        MR_String vector__V_8_45 = (MR_String) "float:'/'";
        MR_Word vector__TypeInfo_9_46;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        vector__V_7_44 = (MR_Word) vector__V_8_45;
        vector__TypeInfo_9_46 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(vector__TypeInfo_9_46, ((MR_Box) (vector__V_7_44)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__V_16_16 = (vector__Az_11 / vector__Mag_12);
#line 77 "vector.m"
    vector__Ax_47 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
#line 77 "vector.m"
    vector__Ay_48 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
#line 77 "vector.m"
    vector__Az_49 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
#line 77 "vector.m"
    vector__V_55_55 = (vector__Ax_47 * vector__V_14_14);
#line 77 "vector.m"
    vector__V_56_56 = (vector__Ay_48 * vector__V_15_15);
#line 77 "vector.m"
    vector__V_53_53 = (vector__V_55_55 + vector__V_56_56);
#line 77 "vector.m"
    vector__V_54_54 = (vector__Az_49 * vector__V_16_16);
#line 77 "vector.m"
    vector__V_8_8 = (vector__V_53_53 + vector__V_54_54);
#line 107 "vector.m"
    vector__V_61_61 = (vector__V_8_8 * vector__V_14_14);
#line 107 "vector.m"
    vector__V_62_62 = (vector__V_8_8 * vector__V_15_15);
#line 107 "vector.m"
    vector__V_63_63 = (vector__V_8_8 * vector__V_16_16);
#line 107 "vector.m"
    {
#line 107 "vector.m"
      vector__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 107 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 0) = MR_box_float(vector__V_61_61);
#line 107 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 1) = MR_box_float(vector__V_62_62);
#line 107 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 2) = MR_box_float(vector__V_63_63);
#line 107 "vector.m"
    }
    return vector__HeadVar__3_3;
  }
#line 42 "vector.m"
}

#line 38 "vector.m"
MR_Float MR_CALL vector__angle_3_f_0(
#line 38 "vector.m"
  MR_Word vector__HeadVar__1_1,
#line 38 "vector.m"
  MR_Word vector__HeadVar__2_2)
#line 38 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Float vector__HeadVar__3_3;
    MR_Float vector__V_6_6;
    MR_Float vector__V_7_7;
    MR_Float vector__V_8_8;
    MR_Float vector__V_9_9;
    MR_Float vector__V_10_10;
    MR_Float vector__Ax_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Ay_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__Az_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__Bx_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float vector__By_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float vector__Bz_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float vector__V_17_17;
    MR_Float vector__V_18_18;
    MR_Float vector__V_19_19 = (vector__Ax_11 * vector__Bx_14);
    MR_Float vector__V_20_20 = (vector__Ay_12 * vector__By_15);
    MR_Float vector__V_22_22;
    MR_Float vector__V_26_26;
    MR_Float vector__V_27_27;
    MR_Float vector__V_28_28;
    MR_Float vector__V_29_29;
    MR_Float vector__V_40_40;
    MR_Float vector__Ax_41;
    MR_Float vector__Ay_42;
    MR_Float vector__Az_43;
    MR_Float vector__V_44_44;
    MR_Float vector__V_45_45;
    MR_Float vector__V_46_46;
    MR_Float vector__V_47_47;

#line 77 "vector.m"
    vector__V_17_17 = (vector__V_19_19 + vector__V_20_20);
#line 77 "vector.m"
    vector__V_18_18 = (vector__Az_13 * vector__Bz_16);
#line 77 "vector.m"
    vector__V_9_9 = (vector__V_17_17 + vector__V_18_18);
#line 95 "vector.m"
    vector__V_28_28 = (vector__Ax_11 * vector__Ax_11);
#line 95 "vector.m"
    vector__V_29_29 = (vector__Ay_12 * vector__Ay_12);
#line 95 "vector.m"
    vector__V_26_26 = (vector__V_28_28 + vector__V_29_29);
#line 95 "vector.m"
    vector__V_27_27 = (vector__Az_13 * vector__Az_13);
#line 95 "vector.m"
    vector__V_22_22 = (vector__V_26_26 + vector__V_27_27);
#line 92 "vector.m"
    {
#line 92 "vector.m"
      vector__V_10_10 = mercury__math__sqrt_2_f_0(vector__V_22_22);
    }
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL vector__angle_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
vector__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (vector__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__succeeded = (vector__V_10_10 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (vector__succeeded)
      {
        MR_Word vector__V_7_36;
        MR_String vector__V_8_37 = (MR_String) "float:'/'";
        MR_Word vector__TypeInfo_9_38;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        vector__V_7_36 = (MR_Word) vector__V_8_37;
        vector__TypeInfo_9_38 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(vector__TypeInfo_9_38, ((MR_Box) (vector__V_7_36)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__V_7_7 = (vector__V_9_9 / vector__V_10_10);
#line 95 "vector.m"
    vector__Ax_41 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 0)));
#line 95 "vector.m"
    vector__Ay_42 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 1)));
#line 95 "vector.m"
    vector__Az_43 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 2)));
#line 95 "vector.m"
    vector__V_46_46 = (vector__Ax_41 * vector__Ax_41);
#line 95 "vector.m"
    vector__V_47_47 = (vector__Ay_42 * vector__Ay_42);
#line 95 "vector.m"
    vector__V_44_44 = (vector__V_46_46 + vector__V_47_47);
#line 95 "vector.m"
    vector__V_45_45 = (vector__Az_43 * vector__Az_43);
#line 95 "vector.m"
    vector__V_40_40 = (vector__V_44_44 + vector__V_45_45);
#line 92 "vector.m"
    {
#line 92 "vector.m"
      vector__V_8_8 = mercury__math__sqrt_2_f_0(vector__V_40_40);
    }
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL vector__angle_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
vector__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (vector__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__succeeded = (vector__V_8_8 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (vector__succeeded)
      {
        MR_Word vector__V_7_54;
        MR_String vector__V_8_55 = (MR_String) "float:'/'";
        MR_Word vector__TypeInfo_9_56;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        vector__V_7_54 = (MR_Word) vector__V_8_55;
        vector__TypeInfo_9_56 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(vector__TypeInfo_9_56, ((MR_Box) (vector__V_7_54)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__V_6_6 = (vector__V_7_7 / vector__V_8_8);
#line 110 "vector.m"
    {
#line 110 "vector.m"
      return vector__HeadVar__3_3 = mercury__math__acos_2_f_0(vector__V_6_6);
    }
    return vector__HeadVar__3_3;
  }
#line 38 "vector.m"
}

#line 36 "vector.m"
MR_Word MR_CALL vector__scale_3_f_0(
#line 36 "vector.m"
  MR_Float vector__HeadVar__1_1,
#line 36 "vector.m"
  MR_Word vector__HeadVar__2_2)
#line 36 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__3_3;
    MR_Float vector__Ax_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float vector__Ay_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float vector__Az_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float vector__V_8_8 = (vector__HeadVar__1_1 * vector__Ax_5);
    MR_Float vector__V_9_9 = (vector__HeadVar__1_1 * vector__Ay_6);
    MR_Float vector__V_10_10 = (vector__HeadVar__1_1 * vector__Az_7);

#line 107 "vector.m"
    {
#line 107 "vector.m"
      vector__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 107 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 0) = MR_box_float(vector__V_8_8);
#line 107 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 1) = MR_box_float(vector__V_9_9);
#line 107 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 2) = MR_box_float(vector__V_10_10);
#line 107 "vector.m"
    }
    return vector__HeadVar__3_3;
  }
#line 36 "vector.m"
}

#line 34 "vector.m"
MR_Word MR_CALL vector__unit_2_f_0(
#line 34 "vector.m"
  MR_Word vector__HeadVar__1_1)
#line 34 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__2_2;
    MR_Float vector__Ax_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Ay_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__Az_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__Mag_6;
    MR_Float vector__V_8_8;
    MR_Float vector__V_9_9;
    MR_Float vector__V_10_10;
    MR_Float vector__V_12_12;
    MR_Float vector__V_16_16;
    MR_Float vector__V_17_17;
    MR_Float vector__V_18_18 = (vector__Ax_3 * vector__Ax_3);
    MR_Float vector__V_19_19 = (vector__Ay_4 * vector__Ay_4);

#line 95 "vector.m"
    vector__V_16_16 = (vector__V_18_18 + vector__V_19_19);
#line 95 "vector.m"
    vector__V_17_17 = (vector__Az_5 * vector__Az_5);
#line 95 "vector.m"
    vector__V_12_12 = (vector__V_16_16 + vector__V_17_17);
#line 92 "vector.m"
    {
#line 92 "vector.m"
      vector__Mag_6 = mercury__math__sqrt_2_f_0(vector__V_12_12);
    }
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL vector__unit_2_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
vector__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (vector__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__succeeded = (vector__Mag_6 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (vector__succeeded)
      {
        MR_Word vector__V_7_26;
        MR_String vector__V_8_27 = (MR_String) "float:'/'";
        MR_Word vector__TypeInfo_9_28;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        vector__V_7_26 = (MR_Word) vector__V_8_27;
        vector__TypeInfo_9_28 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(vector__TypeInfo_9_28, ((MR_Box) (vector__V_7_26)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__V_8_8 = (vector__Ax_3 / vector__Mag_6);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL vector__unit_2_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
vector__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (vector__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__succeeded = (vector__Mag_6 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (vector__succeeded)
      {
        MR_Word vector__V_7_32;
        MR_String vector__V_8_33 = (MR_String) "float:'/'";
        MR_Word vector__TypeInfo_9_34;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        vector__V_7_32 = (MR_Word) vector__V_8_33;
        vector__TypeInfo_9_34 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(vector__TypeInfo_9_34, ((MR_Box) (vector__V_7_32)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__V_9_9 = (vector__Ay_4 / vector__Mag_6);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL vector__unit_2_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
vector__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (vector__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__succeeded = (vector__Mag_6 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (vector__succeeded)
      {
        MR_Word vector__V_7_38;
        MR_String vector__V_8_39 = (MR_String) "float:'/'";
        MR_Word vector__TypeInfo_9_40;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        vector__V_7_38 = (MR_Word) vector__V_8_39;
        vector__TypeInfo_9_40 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(vector__TypeInfo_9_40, ((MR_Box) (vector__V_7_38)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      vector__V_10_10 = (vector__Az_5 / vector__Mag_6);
#line 104 "vector.m"
    {
#line 104 "vector.m"
      vector__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 104 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 0) = MR_box_float(vector__V_8_8);
#line 104 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 1) = MR_box_float(vector__V_9_9);
#line 104 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 2) = MR_box_float(vector__V_10_10);
#line 104 "vector.m"
    }
    return vector__HeadVar__2_2;
  }
#line 34 "vector.m"
}

#line 32 "vector.m"
MR_Float MR_CALL vector__distance_squared_3_f_0(
#line 32 "vector.m"
  MR_Word vector__HeadVar__1_1,
#line 32 "vector.m"
  MR_Word vector__HeadVar__2_2)
#line 32 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Float vector__HeadVar__3_3;
    MR_Float vector__X1_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Y1_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__Z1_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__X2_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float vector__Y2_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float vector__Z2_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float vector__DX_11 = (vector__X1_4 - vector__X2_7);
    MR_Float vector__DY_12 = (vector__Y1_5 - vector__Y2_8);
    MR_Float vector__DZ_13 = (vector__Z1_6 - vector__Z2_9);
    MR_Float vector__V_14_14;
    MR_Float vector__V_15_15;
    MR_Float vector__V_16_16 = (vector__DX_11 * vector__DX_11);
    MR_Float vector__V_17_17 = (vector__DY_12 * vector__DY_12);

#line 101 "vector.m"
    vector__V_14_14 = (vector__V_16_16 + vector__V_17_17);
#line 101 "vector.m"
    vector__V_15_15 = (vector__DZ_13 * vector__DZ_13);
#line 101 "vector.m"
    vector__HeadVar__3_3 = (vector__V_14_14 + vector__V_15_15);
    return vector__HeadVar__3_3;
  }
#line 32 "vector.m"
}

#line 29 "vector.m"
MR_Float MR_CALL vector__mag2_2_f_0(
#line 29 "vector.m"
  MR_Word vector__HeadVar__1_1)
#line 29 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Float vector__HeadVar__2_2;
    MR_Float vector__Ax_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Ay_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__Az_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__V_6_6;
    MR_Float vector__V_7_7;
    MR_Float vector__V_8_8 = (vector__Ax_3 * vector__Ax_3);
    MR_Float vector__V_9_9 = (vector__Ay_4 * vector__Ay_4);

#line 95 "vector.m"
    vector__V_6_6 = (vector__V_8_8 + vector__V_9_9);
#line 95 "vector.m"
    vector__V_7_7 = (vector__Az_5 * vector__Az_5);
#line 95 "vector.m"
    vector__HeadVar__2_2 = (vector__V_6_6 + vector__V_7_7);
    return vector__HeadVar__2_2;
  }
#line 29 "vector.m"
}

#line 26 "vector.m"
MR_Float MR_CALL vector__mag_2_f_0(
#line 26 "vector.m"
  MR_Word vector__HeadVar__1_1)
#line 26 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Float vector__HeadVar__2_2;
    MR_Float vector__V_4_4;
    MR_Float vector__Ax_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Ay_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__Az_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__V_8_8;
    MR_Float vector__V_9_9;
    MR_Float vector__V_10_10 = (vector__Ax_5 * vector__Ax_5);
    MR_Float vector__V_11_11 = (vector__Ay_6 * vector__Ay_6);

#line 95 "vector.m"
    vector__V_8_8 = (vector__V_10_10 + vector__V_11_11);
#line 95 "vector.m"
    vector__V_9_9 = (vector__Az_7 * vector__Az_7);
#line 95 "vector.m"
    vector__V_4_4 = (vector__V_8_8 + vector__V_9_9);
#line 92 "vector.m"
    {
#line 92 "vector.m"
      return vector__HeadVar__2_2 = mercury__math__sqrt_2_f_0(vector__V_4_4);
    }
    return vector__HeadVar__2_2;
  }
#line 26 "vector.m"
}

#line 24 "vector.m"
MR_Word MR_CALL vector__cross_3_f_0(
#line 24 "vector.m"
  MR_Word vector__HeadVar__1_1,
#line 24 "vector.m"
  MR_Word vector__HeadVar__2_2)
#line 24 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__3_3;
    MR_Float vector__Ax_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Ay_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__Az_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__Bx_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float vector__By_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float vector__Bz_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float vector__Cx_10;
    MR_Float vector__Cy_11;
    MR_Float vector__Cz_12;
    MR_Float vector__V_13_13;
    MR_Float vector__V_14_14;
    MR_Float vector__V_15_15;
    MR_Float vector__V_16_16;
    MR_Float vector__V_17_17 = (vector__Ay_5 * vector__Bz_9);
    MR_Float vector__V_18_18 = (vector__Az_6 * vector__By_8);

#line 88 "vector.m"
    vector__Cx_10 = (vector__V_17_17 - vector__V_18_18);
#line 89 "vector.m"
    vector__V_15_15 = (vector__Az_6 * vector__Bx_7);
#line 89 "vector.m"
    vector__V_16_16 = (vector__Ax_4 * vector__Bz_9);
#line 89 "vector.m"
    vector__Cy_11 = (vector__V_15_15 - vector__V_16_16);
#line 90 "vector.m"
    vector__V_13_13 = (vector__Ax_4 * vector__By_8);
#line 90 "vector.m"
    vector__V_14_14 = (vector__Ay_5 * vector__Bx_7);
#line 90 "vector.m"
    vector__Cz_12 = (vector__V_13_13 - vector__V_14_14);
#line 87 "vector.m"
    {
#line 87 "vector.m"
      vector__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 87 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 0) = MR_box_float(vector__Cx_10);
#line 87 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 1) = MR_box_float(vector__Cy_11);
#line 87 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 2) = MR_box_float(vector__Cz_12);
#line 87 "vector.m"
    }
    return vector__HeadVar__3_3;
  }
#line 24 "vector.m"
}

#line 22 "vector.m"
MR_Float MR_CALL vector__positive_dot_3_f_0(
#line 22 "vector.m"
  MR_Word vector__HeadVar__1_1,
#line 22 "vector.m"
  MR_Word vector__HeadVar__2_2)
#line 22 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Float vector__HeadVar__3_3;
    MR_Float vector__Dot_7;
    MR_Float vector__Ax_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Ay_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__Az_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__Bx_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float vector__By_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float vector__Bz_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float vector__V_15_15;
    MR_Float vector__V_16_16;
    MR_Float vector__V_17_17 = (vector__Ax_9 * vector__Bx_12);
    MR_Float vector__V_18_18 = (vector__Ay_10 * vector__By_13);
    MR_Float vector__V_19_19;

#line 77 "vector.m"
    vector__V_15_15 = (vector__V_17_17 + vector__V_18_18);
#line 77 "vector.m"
    vector__V_16_16 = (vector__Az_11 * vector__Bz_14);
#line 77 "vector.m"
    vector__Dot_7 = (vector__V_15_15 + vector__V_16_16);
#line 81 "vector.m"
    vector__V_19_19 = (MR_Float) 0.00000000000000;
#line 81 "vector.m"
    vector__succeeded = (vector__Dot_7 < vector__V_19_19);
#line 83 "vector.m"
    if (vector__succeeded)
#line 82 "vector.m"
      vector__HeadVar__3_3 = (MR_Float) 0.00000000000000;
#line 83 "vector.m"
    else
#line 84 "vector.m"
      vector__HeadVar__3_3 = vector__Dot_7;
    return vector__HeadVar__3_3;
  }
#line 22 "vector.m"
}

#line 19 "vector.m"
MR_Float MR_CALL vector__dot_3_f_0(
#line 19 "vector.m"
  MR_Word vector__HeadVar__1_1,
#line 19 "vector.m"
  MR_Word vector__HeadVar__2_2)
#line 19 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Float vector__HeadVar__3_3;
    MR_Float vector__Ax_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Ay_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__Az_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__Bx_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float vector__By_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float vector__Bz_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float vector__V_10_10;
    MR_Float vector__V_11_11;
    MR_Float vector__V_12_12 = (vector__Ax_4 * vector__Bx_7);
    MR_Float vector__V_13_13 = (vector__Ay_5 * vector__By_8);

#line 77 "vector.m"
    vector__V_10_10 = (vector__V_12_12 + vector__V_13_13);
#line 77 "vector.m"
    vector__V_11_11 = (vector__Az_6 * vector__Bz_9);
#line 77 "vector.m"
    vector__HeadVar__3_3 = (vector__V_10_10 + vector__V_11_11);
    return vector__HeadVar__3_3;
  }
#line 19 "vector.m"
}

#line 17 "vector.m"
MR_Word MR_CALL vector__f_minus_2_f_0(
#line 17 "vector.m"
  MR_Word vector__HeadVar__1_1)
#line 17 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__2_2;
    MR_Float vector__X_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Y_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__Z_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__V_6_6 = (((MR_Float) 0.00000000000000) - vector__X_3);
    MR_Float vector__V_7_7 = (((MR_Float) 0.00000000000000) - vector__Y_4);
    MR_Float vector__V_8_8 = (((MR_Float) 0.00000000000000) - vector__Z_5);

#line 75 "vector.m"
    {
#line 75 "vector.m"
      vector__HeadVar__2_2 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 75 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 0) = MR_box_float(vector__V_6_6);
#line 75 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 1) = MR_box_float(vector__V_7_7);
#line 75 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, 2) = MR_box_float(vector__V_8_8);
#line 75 "vector.m"
    }
    return vector__HeadVar__2_2;
  }
#line 17 "vector.m"
}

#line 15 "vector.m"
MR_Word MR_CALL vector__f_minus_3_f_0(
#line 15 "vector.m"
  MR_Word vector__HeadVar__1_1,
#line 15 "vector.m"
  MR_Word vector__HeadVar__2_2)
#line 15 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__3_3;
    MR_Float vector__Ax_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Ay_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__Az_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__Bx_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float vector__By_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float vector__Bz_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float vector__V_10_10 = (vector__Ax_4 - vector__Bx_7);
    MR_Float vector__V_11_11 = (vector__Ay_5 - vector__By_8);
    MR_Float vector__V_12_12 = (vector__Az_6 - vector__Bz_9);

#line 73 "vector.m"
    {
#line 73 "vector.m"
      vector__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 73 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 0) = MR_box_float(vector__V_10_10);
#line 73 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 1) = MR_box_float(vector__V_11_11);
#line 73 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 2) = MR_box_float(vector__V_12_12);
#line 73 "vector.m"
    }
    return vector__HeadVar__3_3;
  }
#line 15 "vector.m"
}

#line 13 "vector.m"
MR_Word MR_CALL vector__f_plus_3_f_0(
#line 13 "vector.m"
  MR_Word vector__HeadVar__1_1,
#line 13 "vector.m"
  MR_Word vector__HeadVar__2_2)
#line 13 "vector.m"
{
  {
    bool vector__succeeded;
    MR_Word vector__HeadVar__3_3;
    MR_Float vector__Ax_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float vector__Ay_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float vector__Az_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float vector__Bx_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float vector__By_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float vector__Bz_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), vector__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float vector__V_10_10 = (vector__Ax_4 + vector__Bx_7);
    MR_Float vector__V_11_11 = (vector__Ay_5 + vector__By_8);
    MR_Float vector__V_12_12 = (vector__Az_6 + vector__Bz_9);

#line 71 "vector.m"
    {
#line 71 "vector.m"
      vector__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 71 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 0) = MR_box_float(vector__V_10_10);
#line 71 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 1) = MR_box_float(vector__V_11_11);
#line 71 "vector.m"
      MR_hl_field(MR_mktag(0), vector__HeadVar__3_3, 2) = MR_box_float(vector__V_12_12);
#line 71 "vector.m"
    }
    return vector__HeadVar__3_3;
  }
#line 13 "vector.m"
}

void mercury__vector__init(void)
{
}

void mercury__vector__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&vector__vector__type_ctor_info_vector_0);
	MR_register_type_ctor_info(&vector__vector__type_ctor_info_real_0);
	MR_register_type_ctor_info(&vector__vector__type_ctor_info_position_0);
	MR_register_type_ctor_info(&vector__vector__type_ctor_info_point_0);
}

void mercury__vector__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module vector. */
