/*
** Automatically generated from `trans.m' by the Mercury compiler,
** version DEV, configured for i686-pc-linux-gnu.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/

/* :- module trans. */
/* :- implementation. */

#include "trans.h"


#include "mercury.array.h"
#include "mercury.assoc_list.h"
#include "mercury.benchmarking.h"
#include "mercury.bintree_set.h"
#include "mercury.bool.h"
#include "mercury.builtin.h"
#include "mercury.char.h"
#include "mercury.dir.h"
#include "mercury.enum.h"
#include "eval.h"
#include "mercury.exception.h"
#include "mercury.float.h"
#include "globals.h"
#include "gml.h"
#include "mercury.int.h"
#include "mercury.io.h"
#include "mercury.lexer.h"
#include "mercury.list.h"
#include "mercury.map.h"
#include "mercury.math.h"
#include "op.h"
#include "mercury.ops.h"
#include "mercury.parser.h"
#include "peephole.h"
#include "mercury.private_builtin.h"
#include "mercury.random.h"
#include "renderer.h"
#include "mercury.require.h"
#include "mercury.rtti_implementation.h"
#include "mercury.set.h"
#include "space_partition.h"
#include "mercury.std_util.h"
#include "mercury.store.h"
#include "mercury.string.h"
#include "mercury.table_builtin.h"
#include "mercury.term.h"
#include "mercury.term_io.h"
#include "mercury.time.h"
#include "trans.h"
#include "transform_object.h"
#include "tree.h"
#include "mercury.tree234.h"
#include "mercury.varset.h"
#include "vector.h"



static const MR_DuFunctorDescPtr trans__trans__du_name_ordered_trans_0[1];
static const MR_DuFunctorDesc trans__trans__du_functor_desc_trans_0_0;
static const MR_PseudoTypeInfo trans__trans__field_types_trans_0_0[2];
static const MR_DuPtagLayout trans__trans__du_ptag_ordered_trans_0[1];
static const MR_DuFunctorDescPtr trans__trans__du_stag_ordered_trans_0_0[1];
static const MR_DuFunctorDescPtr trans__trans__du_name_ordered_surface_coordinates_0[1];
static const MR_DuFunctorDesc trans__trans__du_functor_desc_surface_coordinates_0_0;
static const MR_ConstString trans__trans__field_names_surface_coordinates_0_0[3];
static const MR_PseudoTypeInfo trans__trans__field_types_surface_coordinates_0_0[3];
static const MR_DuPtagLayout trans__trans__du_ptag_ordered_surface_coordinates_0[1];
static const MR_DuFunctorDescPtr trans__trans__du_stag_ordered_surface_coordinates_0_0[1];
static const MR_DuFunctorDescPtr trans__trans__du_name_ordered_matrix_0[1];
static const MR_DuFunctorDesc trans__trans__du_functor_desc_matrix_0_0;
static const MR_PseudoTypeInfo trans__trans__field_types_matrix_0_0[12];
static const MR_DuPtagLayout trans__trans__du_ptag_ordered_matrix_0[1];
static const MR_DuFunctorDescPtr trans__trans__du_stag_ordered_matrix_0_0[1];
static const MR_FO_PseudoTypeInfo_Struct1 trans__list__type_info_list_1__type0_21_trans__intersection_0;
static const MR_DuFunctorDescPtr trans__trans__du_name_ordered_intersection_0[1];
static const MR_DuFunctorDesc trans__trans__du_functor_desc_intersection_0_0;
static const MR_ConstString trans__trans__field_names_intersection_0_0[5];
static const MR_PseudoTypeInfo trans__trans__field_types_intersection_0_0[5];
static const MR_DuPtagLayout trans__trans__du_ptag_ordered_intersection_0[1];
static const MR_DuFunctorDescPtr trans__trans__du_stag_ordered_intersection_0_0[1];
static const MR_FO_PseudoTypeInfo_Struct1 trans__list__type_info_list_1__type0_26_trans__face_intersection_0;
static const MR_DuFunctorDescPtr trans__trans__du_name_ordered_face_intersection_0[1];
static const MR_DuFunctorDesc trans__trans__du_functor_desc_face_intersection_0_0;
static const MR_PseudoTypeInfo trans__trans__field_types_face_intersection_0_0[4];
static const MR_DuPtagLayout trans__trans__du_ptag_ordered_face_intersection_0[1];
static const MR_DuFunctorDescPtr trans__trans__du_stag_ordered_face_intersection_0_0[1];
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL trans__map__ho7__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Integer trans__V_17_17,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_16_16,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_15_15,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * trans__HeadVar__3_3);
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL trans__map__ho6__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Integer trans__V_17_17,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_16_16,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_15_15,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * trans__HeadVar__3_3);
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL trans__map__ho5__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Integer trans__V_17_17,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_16_16,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_15_15,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * trans__HeadVar__3_3);
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static MR_Word MR_CALL trans__map__ho4__ua0_3_f_in__list_0(
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Integer trans__V_20_20,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_19_19,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_18_18,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__HeadVar__2_2);
#line 997 "trans.m"
static MR_Float MR_CALL trans__calc_u_3_f_0(
#line 997 "trans.m"
  MR_Float trans__HeadVar__1_1,
#line 997 "trans.m"
  MR_Float trans__HeadVar__2_2);
#line 922 "trans.m"
static MR_Word MR_CALL trans__disc_intersection_9_f_0(
#line 922 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 922 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 922 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 922 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 922 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 922 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 922 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 922 "trans.m"
  MR_Float trans__HeadVar__8_8);
#line 901 "trans.m"
static void MR_CALL trans__maybe_add_intersection_10_p_0(
#line 901 "trans.m"
  MR_Float trans__HeadVar__1_1,
#line 901 "trans.m"
  MR_Integer trans__HeadVar__2_2,
#line 901 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 901 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 901 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 901 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 901 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 901 "trans.m"
  MR_Float trans__HeadVar__8_8,
#line 901 "trans.m"
  MR_Word trans__HeadVar__9_9,
#line 901 "trans.m"
  MR_Word * trans__HeadVar__10_10);
#line 881 "trans.m"
static MR_Word MR_CALL trans__solve_quadratic_11_f_0(
#line 881 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 881 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 881 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 881 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 881 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 881 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 881 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 881 "trans.m"
  MR_Float trans__HeadVar__8_8,
#line 881 "trans.m"
  MR_Float trans__HeadVar__9_9,
#line 881 "trans.m"
  MR_Float trans__HeadVar__10_10);
#line 869 "trans.m"
static MR_Word MR_CALL trans__cone_intersection_8_f_0(
#line 869 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 869 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 869 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 869 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 869 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 869 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 869 "trans.m"
  MR_Float trans__HeadVar__7_7);
#line 857 "trans.m"
static MR_Word MR_CALL trans__cylinder_intersection_8_f_0(
#line 857 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 857 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 857 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 857 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 857 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 857 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 857 "trans.m"
  MR_Float trans__HeadVar__7_7);
#line 831 "trans.m"
static MR_Word MR_CALL trans__process_cone_intersections_5_f_0(
#line 831 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 831 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 831 "trans.m"
  MR_Word trans__HeadVar__3_3,
#line 831 "trans.m"
  MR_Word trans__HeadVar__4_4);
#line 785 "trans.m"
static MR_Word MR_CALL trans__process_cylinder_intersections_5_f_0(
#line 785 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 785 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 785 "trans.m"
  MR_Word trans__HeadVar__3_3,
#line 785 "trans.m"
  MR_Word trans__HeadVar__4_4);
#line 725 "trans.m"
static MR_Word MR_CALL trans__y_face_intersection_9_f_0(
#line 725 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 725 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 725 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 725 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 725 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 725 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 725 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 725 "trans.m"
  MR_Float trans__HeadVar__8_8);
#line 702 "trans.m"
static MR_Word MR_CALL trans__x_face_intersection_9_f_0(
#line 702 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 702 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 702 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 702 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 702 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 702 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 702 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 702 "trans.m"
  MR_Float trans__HeadVar__8_8);
#line 679 "trans.m"
static MR_Word MR_CALL trans__z_face_intersection_9_f_0(
#line 679 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 679 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 679 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 679 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 679 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 679 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 679 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 679 "trans.m"
  MR_Float trans__HeadVar__8_8);
#line 654 "trans.m"
static MR_Word MR_CALL trans__process_cube_intersections_5_f_0(
#line 654 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 654 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 654 "trans.m"
  MR_Word trans__HeadVar__3_3,
#line 654 "trans.m"
  MR_Word trans__HeadVar__4_4);
#line 574 "trans.m"
static void MR_CALL trans__intersects_sphere_2_11_p_0(
#line 574 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 574 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 574 "trans.m"
  MR_Word trans__HeadVar__3_3,
#line 574 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 574 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 574 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 574 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 574 "trans.m"
  MR_Float trans__HeadVar__8_8,
#line 574 "trans.m"
  MR_Float trans__HeadVar__9_9,
#line 574 "trans.m"
  MR_Word trans__HeadVar__10_10,
#line 574 "trans.m"
  MR_Word * trans__HeadVar__11_11);
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_1;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_2;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_3;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_4;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_5;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_6;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_7;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_8;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_9;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_10;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_11;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_12;
#line 303 "trans.m"
static /* final */ const MR_Box trans__const_24_0_13_HeadVar__1_1[12];
#line 498 "trans.m"
static /* final */ const MR_Float trans__float_13_0_1;
#line 498 "trans.m"
static /* final */ const MR_Float trans__float_13_0_2;
#line 498 "trans.m"
static /* final */ const MR_Float trans__float_13_0_3;
#line 498 "trans.m"
static /* final */ const MR_Box trans__const_13_0_4_V_28_28[3];
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_1;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_2;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_3;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_4;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_5;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_6;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_7;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_8;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_9;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_10;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_11;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_12;
#line 303 "trans.m"
static /* final */ const MR_Box trans__const_6_0_13_I_2[12];
#line 298 "trans.m"
static /* final */ const MR_Box trans__const_6_0_14_HeadVar__1_1[2];



const MR_TypeCtorInfo_Struct trans__trans__type_ctor_info_trans_0 = {
		(MR_Integer) 0,
		((MR_Box) (trans____Unify____trans_0_0)),
		((MR_Box) (trans____Unify____trans_0_0)),
		((MR_Box) (trans____Compare____trans_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "trans",
		(MR_String) "trans",
		(MR_Integer) 4,
		{
		(MR_Box) trans__trans__du_name_ordered_trans_0},
		{
		(MR_Box) trans__trans__du_ptag_ordered_trans_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct trans__trans__type_ctor_info_surface_coordinates_0 = {
		(MR_Integer) 0,
		((MR_Box) (trans____Unify____surface_coordinates_0_0)),
		((MR_Box) (trans____Unify____surface_coordinates_0_0)),
		((MR_Box) (trans____Compare____surface_coordinates_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "trans",
		(MR_String) "surface_coordinates",
		(MR_Integer) 4,
		{
		(MR_Box) trans__trans__du_name_ordered_surface_coordinates_0},
		{
		(MR_Box) trans__trans__du_ptag_ordered_surface_coordinates_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct trans__trans__type_ctor_info_matrix_0 = {
		(MR_Integer) 0,
		((MR_Box) (trans____Unify____matrix_0_0)),
		((MR_Box) (trans____Unify____matrix_0_0)),
		((MR_Box) (trans____Compare____matrix_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "trans",
		(MR_String) "matrix",
		(MR_Integer) 4,
		{
		(MR_Box) trans__trans__du_name_ordered_matrix_0},
		{
		(MR_Box) trans__trans__du_ptag_ordered_matrix_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct trans__trans__type_ctor_info_intersections_0 = {
		(MR_Integer) 0,
		((MR_Box) (trans____Unify____intersections_0_0)),
		((MR_Box) (trans____Unify____intersections_0_0)),
		((MR_Box) (trans____Compare____intersections_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "trans",
		(MR_String) "intersections",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&trans__list__type_info_list_1__type0_21_trans__intersection_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct trans__trans__type_ctor_info_intersection_0 = {
		(MR_Integer) 0,
		((MR_Box) (trans____Unify____intersection_0_0)),
		((MR_Box) (trans____Unify____intersection_0_0)),
		((MR_Box) (trans____Compare____intersection_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "trans",
		(MR_String) "intersection",
		(MR_Integer) 4,
		{
		(MR_Box) trans__trans__du_name_ordered_intersection_0},
		{
		(MR_Box) trans__trans__du_ptag_ordered_intersection_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
const MR_TypeCtorInfo_Struct trans__trans__type_ctor_info_face_intersections_0 = {
		(MR_Integer) 0,
		((MR_Box) (trans____Unify____face_intersections_0_0)),
		((MR_Box) (trans____Unify____face_intersections_0_0)),
		((MR_Box) (trans____Compare____face_intersections_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_EQUIV_GROUND,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "trans",
		(MR_String) "face_intersections",
		(MR_Integer) 4,
		{
		(MR_Box) NULL},
		{
		(MR_Box) (&trans__list__type_info_list_1__type0_26_trans__face_intersection_0)},
		(MR_Integer) -1,
		(MR_Integer) -1};
const MR_TypeCtorInfo_Struct trans__trans__type_ctor_info_face_intersection_0 = {
		(MR_Integer) 0,
		((MR_Box) (trans____Unify____face_intersection_0_0)),
		((MR_Box) (trans____Unify____face_intersection_0_0)),
		((MR_Box) (trans____Compare____face_intersection_0_0)),
		mercury__private_builtin__MR_TYPECTOR_REP_DU,
		(MR_Box) NULL,
		(MR_Box) NULL,
		(MR_String) "trans",
		(MR_String) "face_intersection",
		(MR_Integer) 4,
		{
		(MR_Box) trans__trans__du_name_ordered_face_intersection_0},
		{
		(MR_Box) trans__trans__du_ptag_ordered_face_intersection_0},
		(MR_Integer) 1,
		(MR_Integer) 1};
static const MR_DuFunctorDescPtr trans__trans__du_name_ordered_trans_0[1] = {
		(&trans__trans__du_functor_desc_trans_0_0)};
static const MR_DuFunctorDesc trans__trans__du_functor_desc_trans_0_0 = {
		(MR_String) "trans",
		(MR_Integer) 2,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		trans__trans__field_types_trans_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo trans__trans__field_types_trans_0_0[2] = {
		(MR_PseudoTypeInfo) (&trans__trans__type_ctor_info_matrix_0),
		(MR_PseudoTypeInfo) (&trans__trans__type_ctor_info_matrix_0)};
static const MR_DuPtagLayout trans__trans__du_ptag_ordered_trans_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		trans__trans__du_stag_ordered_trans_0_0}};
static const MR_DuFunctorDescPtr trans__trans__du_stag_ordered_trans_0_0[1] = {
		(&trans__trans__du_functor_desc_trans_0_0)};
static const MR_DuFunctorDescPtr trans__trans__du_name_ordered_surface_coordinates_0[1] = {
		(&trans__trans__du_functor_desc_surface_coordinates_0_0)};
static const MR_DuFunctorDesc trans__trans__du_functor_desc_surface_coordinates_0_0 = {
		(MR_String) "surface_coordinates",
		(MR_Integer) 3,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		trans__trans__field_types_surface_coordinates_0_0,
		trans__trans__field_names_surface_coordinates_0_0,
		(MR_Box) NULL};
static const MR_ConstString trans__trans__field_names_surface_coordinates_0_0[3] = {
		(MR_String) "face",
		(MR_String) "surface_u",
		(MR_String) "surface_v"};
static const MR_PseudoTypeInfo trans__trans__field_types_surface_coordinates_0_0[3] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuPtagLayout trans__trans__du_ptag_ordered_surface_coordinates_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		trans__trans__du_stag_ordered_surface_coordinates_0_0}};
static const MR_DuFunctorDescPtr trans__trans__du_stag_ordered_surface_coordinates_0_0[1] = {
		(&trans__trans__du_functor_desc_surface_coordinates_0_0)};
static const MR_DuFunctorDescPtr trans__trans__du_name_ordered_matrix_0[1] = {
		(&trans__trans__du_functor_desc_matrix_0_0)};
static const MR_DuFunctorDesc trans__trans__du_functor_desc_matrix_0_0 = {
		(MR_String) "matrix",
		(MR_Integer) 12,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		trans__trans__field_types_matrix_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo trans__trans__field_types_matrix_0_0[12] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuPtagLayout trans__trans__du_ptag_ordered_matrix_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		trans__trans__du_stag_ordered_matrix_0_0}};
static const MR_DuFunctorDescPtr trans__trans__du_stag_ordered_matrix_0_0[1] = {
		(&trans__trans__du_functor_desc_matrix_0_0)};
static const MR_FO_PseudoTypeInfo_Struct1 trans__list__type_info_list_1__type0_21_trans__intersection_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&trans__trans__type_ctor_info_intersection_0)}};
static const MR_DuFunctorDescPtr trans__trans__du_name_ordered_intersection_0[1] = {
		(&trans__trans__du_functor_desc_intersection_0_0)};
static const MR_DuFunctorDesc trans__trans__du_functor_desc_intersection_0_0 = {
		(MR_String) "intersection",
		(MR_Integer) 5,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		trans__trans__field_types_intersection_0_0,
		trans__trans__field_names_intersection_0_0,
		(MR_Box) NULL};
static const MR_ConstString trans__trans__field_names_intersection_0_0[5] = {
		(MR_String) "object_id",
		(MR_String) "intersection_point",
		(MR_String) "surface_normal",
		(MR_String) "surface_coordinates",
		(MR_String) "surface"};
static const MR_PseudoTypeInfo trans__trans__field_types_intersection_0_0[5] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0),
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0),
		(MR_PseudoTypeInfo) (&vector__vector__type_ctor_info_vector_0),
		(MR_PseudoTypeInfo) (&trans__trans__type_ctor_info_surface_coordinates_0),
		(MR_PseudoTypeInfo) (&eval__eval__type_ctor_info_surface_0)};
static const MR_DuPtagLayout trans__trans__du_ptag_ordered_intersection_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		trans__trans__du_stag_ordered_intersection_0_0}};
static const MR_DuFunctorDescPtr trans__trans__du_stag_ordered_intersection_0_0[1] = {
		(&trans__trans__du_functor_desc_intersection_0_0)};
static const MR_FO_PseudoTypeInfo_Struct1 trans__list__type_info_list_1__type0_26_trans__face_intersection_0 = {
		(&mercury__list__list__type_ctor_info_list_1),
		{
		(MR_PseudoTypeInfo) (&trans__trans__type_ctor_info_face_intersection_0)}};
static const MR_DuFunctorDescPtr trans__trans__du_name_ordered_face_intersection_0[1] = {
		(&trans__trans__du_functor_desc_face_intersection_0_0)};
static const MR_DuFunctorDesc trans__trans__du_functor_desc_face_intersection_0_0 = {
		(MR_String) "fi",
		(MR_Integer) 4,
		(MR_Integer) 0,
		mercury__private_builtin__MR_SECTAG_NONE,
		(MR_Integer) 0,
		(MR_Integer) 0,
		(MR_Integer) 0,
		trans__trans__field_types_face_intersection_0_0,
		(MR_Box) NULL,
		(MR_Box) NULL};
static const MR_PseudoTypeInfo trans__trans__field_types_face_intersection_0_0[4] = {
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_int_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0),
		(MR_PseudoTypeInfo) (&mercury__builtin____type_ctor_info_float_0)};
static const MR_DuPtagLayout trans__trans__du_ptag_ordered_face_intersection_0[1] = {
		{
		(MR_Integer) 1,
		mercury__private_builtin__MR_SECTAG_NONE,
		trans__trans__du_stag_ordered_face_intersection_0_0}};
static const MR_DuFunctorDescPtr trans__trans__du_stag_ordered_face_intersection_0_0[1] = {
		(&trans__trans__du_functor_desc_face_intersection_0_0)};

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL trans__map__ho7__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Integer trans__V_17_17,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_16_16,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_15_15,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * trans__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool trans__succeeded;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((trans__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *trans__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
        MR_Word trans__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), trans__HeadVar__2_2, (MR_Integer) 0)));
        MR_Word trans__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), trans__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word trans__H_8_8;
        MR_Word trans__T_9_9;

#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          trans__H_8_8 = trans__process_cone_intersections_5_f_0(trans__V_17_17, trans__V_16_16, trans__V_15_15, trans__H0_6_6);
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          trans__map__ho7__ua0_3_p_in__list_0(trans__V_17_17, trans__V_16_16, trans__V_15_15, trans__T0_7_7, &trans__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *trans__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *trans__HeadVar__3_3, 0) = ((MR_Box) (trans__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *trans__HeadVar__3_3, 1) = ((MR_Box) (trans__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL trans__map__ho6__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Integer trans__V_17_17,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_16_16,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_15_15,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * trans__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool trans__succeeded;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((trans__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *trans__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
        MR_Word trans__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), trans__HeadVar__2_2, (MR_Integer) 0)));
        MR_Word trans__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), trans__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word trans__H_8_8;
        MR_Word trans__T_9_9;

#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          trans__H_8_8 = trans__process_cylinder_intersections_5_f_0(trans__V_17_17, trans__V_16_16, trans__V_15_15, trans__H0_6_6);
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          trans__map__ho6__ua0_3_p_in__list_0(trans__V_17_17, trans__V_16_16, trans__V_15_15, trans__T0_7_7, &trans__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *trans__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *trans__HeadVar__3_3, 0) = ((MR_Box) (trans__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *trans__HeadVar__3_3, 1) = ((MR_Box) (trans__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static void MR_CALL trans__map__ho5__ua0_3_p_in__list_0(
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Integer trans__V_17_17,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_16_16,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_15_15,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__HeadVar__2_2,
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word * trans__HeadVar__3_3)
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool trans__succeeded;

#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    if ((trans__HeadVar__2_2 == (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0))))
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      *trans__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    else
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      {
        MR_Word trans__H0_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(1), trans__HeadVar__2_2, (MR_Integer) 0)));
        MR_Word trans__T0_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(1), trans__HeadVar__2_2, (MR_Integer) 1)));
        MR_Word trans__H_8_8;
        MR_Word trans__T_9_9;

#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 137 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          trans__H_8_8 = trans__process_cube_intersections_5_f_0(trans__V_17_17, trans__V_16_16, trans__V_15_15, trans__H0_6_6);
        }
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 131 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          trans__map__ho5__ua0_3_p_in__list_0(trans__V_17_17, trans__V_16_16, trans__V_15_15, trans__T0_7_7, &trans__T_9_9);
        }
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        {
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          *trans__HeadVar__3_3 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *trans__HeadVar__3_3, 0) = ((MR_Box) (trans__H_8_8));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
          MR_hl_field(MR_mktag(1), *trans__HeadVar__3_3, 1) = ((MR_Box) (trans__T_9_9));
#line 129 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
        }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      }
#line 128 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 135 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
static MR_Word MR_CALL trans__map__ho4__ua0_3_f_in__list_0(
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Integer trans__V_20_20,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_19_19,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__V_18_18,
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
  MR_Word trans__HeadVar__2_2)
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
{
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  {
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    bool trans__succeeded;
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    MR_Word trans__HeadVar__3_3;

#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      trans__map__ho5__ua0_3_p_in__list_0(trans__V_20_20, trans__V_19_19, trans__V_18_18, trans__HeadVar__2_2, &trans__HeadVar__3_3);
    }
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    return trans__HeadVar__3_3;
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
  }
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.int"
}

#line 604 "trans.m"
void MR_CALL trans____Compare____face_intersections_0_0(
#line 604 "trans.m"
  MR_Word * trans__HeadVar__1_1,
#line 604 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 604 "trans.m"
  MR_Word trans__HeadVar__3_3)
#line 604 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__conv1_HeadVar__2_2 = (MR_Word) trans__HeadVar__2_2;
    MR_Word trans__conv2_HeadVar__3_3 = (MR_Word) trans__HeadVar__3_3;
    MR_Word trans__TypeInfo_4_4 = (MR_Word) (&trans__trans__type_ctor_info_face_intersection_0);

#line 604 "trans.m"
    {
#line 604 "trans.m"
      mercury__list____Compare____list_1_0(trans__TypeInfo_4_4, trans__HeadVar__1_1, trans__conv1_HeadVar__2_2, trans__conv2_HeadVar__3_3);
#line 604 "trans.m"
      return;
    }
  }
#line 604 "trans.m"
}

#line 604 "trans.m"
bool MR_CALL trans____Unify____face_intersections_0_0(
#line 604 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 604 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 604 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__conv1_HeadVar__1_1 = (MR_Word) trans__HeadVar__1_1;
    MR_Word trans__conv2_HeadVar__2_2 = (MR_Word) trans__HeadVar__2_2;
    MR_Word trans__TypeInfo_3_3 = (MR_Word) (&trans__trans__type_ctor_info_face_intersection_0);

#line 604 "trans.m"
    {
#line 604 "trans.m"
      trans__succeeded = mercury__list____Unify____list_1_0(trans__TypeInfo_3_3, trans__conv1_HeadVar__1_1, trans__conv2_HeadVar__2_2);
    }
    if (trans__succeeded)
      trans__succeeded = TRUE;
    return trans__succeeded;
  }
#line 604 "trans.m"
}

#line 601 "trans.m"
void MR_CALL trans____Compare____face_intersection_0_0(
#line 601 "trans.m"
  MR_Word * trans__HeadVar__1_1,
#line 601 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 601 "trans.m"
  MR_Word trans__HeadVar__3_3)
#line 601 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Integer trans__V_4_4 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float trans__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 3)));
    MR_Integer trans__V_8_8 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float trans__V_9_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 1)));
    MR_Float trans__V_10_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 2)));
    MR_Float trans__V_11_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 3)));
#line 601 "trans.m"
    MR_Word trans__V_12_12;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    trans__succeeded = (trans__V_4_4 < trans__V_8_8);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (trans__succeeded)
      {
        MR_Word trans__V_31_31 = (MR_Integer) 1;

#line 601 "trans.m"
        trans__succeeded = (trans__V_31_31 == (MR_Integer) 0);
#line 601 "trans.m"
        trans__succeeded = !(trans__succeeded);
        if (trans__succeeded)
          {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__V_12_12 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__succeeded = TRUE;
          }
      }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        trans__succeeded = (trans__V_4_4 == trans__V_8_8);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_32_32 = (MR_Integer) 0;

#line 601 "trans.m"
            trans__succeeded = (trans__V_32_32 == (MR_Integer) 0);
#line 601 "trans.m"
            trans__succeeded = !(trans__succeeded);
            if (trans__succeeded)
              {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__V_12_12 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = TRUE;
              }
          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
          {
            MR_Word trans__V_33_33 = (MR_Integer) 2;

#line 601 "trans.m"
            trans__succeeded = (trans__V_33_33 == (MR_Integer) 0);
#line 601 "trans.m"
            trans__succeeded = !(trans__succeeded);
            if (trans__succeeded)
              {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__V_12_12 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = TRUE;
              }
          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 601 "trans.m"
    if (trans__succeeded)
#line 601 "trans.m"
      *trans__HeadVar__1_1 = trans__V_12_12;
#line 601 "trans.m"
    else
#line 601 "trans.m"
      {
#line 601 "trans.m"
        MR_Word trans__V_13_13;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        trans__succeeded = (trans__V_5_5 < trans__V_9_9);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_34_34 = (MR_Integer) 1;

#line 601 "trans.m"
            trans__succeeded = (trans__V_34_34 == (MR_Integer) 0);
#line 601 "trans.m"
            trans__succeeded = !(trans__succeeded);
            if (trans__succeeded)
              {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__V_13_13 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = TRUE;
              }
          }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__succeeded = (trans__V_5_5 > trans__V_9_9);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (trans__succeeded)
              {
                MR_Word trans__V_35_35 = (MR_Integer) 2;

#line 601 "trans.m"
                trans__succeeded = (trans__V_35_35 == (MR_Integer) 0);
#line 601 "trans.m"
                trans__succeeded = !(trans__succeeded);
                if (trans__succeeded)
                  {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__V_13_13 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
              {
                MR_Word trans__V_36_36 = (MR_Integer) 0;

#line 601 "trans.m"
                trans__succeeded = (trans__V_36_36 == (MR_Integer) 0);
#line 601 "trans.m"
                trans__succeeded = !(trans__succeeded);
                if (trans__succeeded)
                  {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__V_13_13 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 601 "trans.m"
        if (trans__succeeded)
#line 601 "trans.m"
          *trans__HeadVar__1_1 = trans__V_13_13;
#line 601 "trans.m"
        else
#line 601 "trans.m"
          {
#line 601 "trans.m"
            MR_Word trans__V_14_14;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__succeeded = (trans__V_6_6 < trans__V_10_10);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (trans__succeeded)
              {
                MR_Word trans__V_37_37 = (MR_Integer) 1;

#line 601 "trans.m"
                trans__succeeded = (trans__V_37_37 == (MR_Integer) 0);
#line 601 "trans.m"
                trans__succeeded = !(trans__succeeded);
                if (trans__succeeded)
                  {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__V_14_14 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__succeeded = TRUE;
                  }
              }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = (trans__V_6_6 > trans__V_10_10);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (trans__succeeded)
                  {
                    MR_Word trans__V_38_38 = (MR_Integer) 2;

#line 601 "trans.m"
                    trans__succeeded = (trans__V_38_38 == (MR_Integer) 0);
#line 601 "trans.m"
                    trans__succeeded = !(trans__succeeded);
                    if (trans__succeeded)
                      {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        trans__V_14_14 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        trans__succeeded = TRUE;
                      }
                  }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
                  {
                    MR_Word trans__V_39_39 = (MR_Integer) 0;

#line 601 "trans.m"
                    trans__succeeded = (trans__V_39_39 == (MR_Integer) 0);
#line 601 "trans.m"
                    trans__succeeded = !(trans__succeeded);
                    if (trans__succeeded)
                      {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        trans__V_14_14 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        trans__succeeded = TRUE;
                      }
                  }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              }
#line 601 "trans.m"
            if (trans__succeeded)
#line 601 "trans.m"
              *trans__HeadVar__1_1 = trans__V_14_14;
#line 601 "trans.m"
            else
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = (trans__V_7_7 < trans__V_11_11);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (trans__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *trans__HeadVar__1_1 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__succeeded = (trans__V_7_7 > trans__V_11_11);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    if (trans__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      *trans__HeadVar__1_1 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      *trans__HeadVar__1_1 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              }
#line 601 "trans.m"
          }
#line 601 "trans.m"
      }
  }
#line 601 "trans.m"
}

#line 601 "trans.m"
bool MR_CALL trans____Unify____face_intersection_0_0(
#line 601 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 601 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 601 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Integer trans__V_3_3 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float trans__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 3)));
    MR_Integer trans__V_7_7 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__V_9_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float trans__V_10_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 3)));

    trans__succeeded = (trans__V_3_3 == trans__V_7_7);
    if (trans__succeeded)
      {
        trans__succeeded = (trans__V_4_4 == trans__V_8_8);
        if (trans__succeeded)
          {
            trans__succeeded = (trans__V_5_5 == trans__V_9_9);
            if (trans__succeeded)
              trans__succeeded = (trans__V_6_6 == trans__V_10_10);
          }
      }
    return trans__succeeded;
  }
#line 601 "trans.m"
}

#line 222 "trans.m"
void MR_CALL trans____Compare____matrix_0_0(
#line 222 "trans.m"
  MR_Word * trans__HeadVar__1_1,
#line 222 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 222 "trans.m"
  MR_Word trans__HeadVar__3_3)
#line 222 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Float trans__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float trans__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 3)));
    MR_Float trans__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 4)));
    MR_Float trans__V_9_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 5)));
    MR_Float trans__V_10_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 6)));
    MR_Float trans__V_11_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 7)));
    MR_Float trans__V_12_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 8)));
    MR_Float trans__V_13_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 9)));
    MR_Float trans__V_14_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 10)));
    MR_Float trans__V_15_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 11)));
    MR_Float trans__V_16_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float trans__V_17_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 1)));
    MR_Float trans__V_18_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 2)));
    MR_Float trans__V_19_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 3)));
    MR_Float trans__V_20_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 4)));
    MR_Float trans__V_21_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 5)));
    MR_Float trans__V_22_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 6)));
    MR_Float trans__V_23_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 7)));
    MR_Float trans__V_24_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 8)));
    MR_Float trans__V_25_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 9)));
    MR_Float trans__V_26_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 10)));
    MR_Float trans__V_27_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 11)));
#line 222 "trans.m"
    MR_Word trans__V_28_28;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    trans__succeeded = (trans__V_4_4 < trans__V_16_16);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (trans__succeeded)
      {
        MR_Word trans__V_87_87 = (MR_Integer) 1;

#line 222 "trans.m"
        trans__succeeded = (trans__V_87_87 == (MR_Integer) 0);
#line 222 "trans.m"
        trans__succeeded = !(trans__succeeded);
        if (trans__succeeded)
          {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__V_28_28 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__succeeded = TRUE;
          }
      }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        trans__succeeded = (trans__V_4_4 > trans__V_16_16);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_88_88 = (MR_Integer) 2;

#line 222 "trans.m"
            trans__succeeded = (trans__V_88_88 == (MR_Integer) 0);
#line 222 "trans.m"
            trans__succeeded = !(trans__succeeded);
            if (trans__succeeded)
              {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__V_28_28 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = TRUE;
              }
          }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
          {
            MR_Word trans__V_89_89 = (MR_Integer) 0;

#line 222 "trans.m"
            trans__succeeded = (trans__V_89_89 == (MR_Integer) 0);
#line 222 "trans.m"
            trans__succeeded = !(trans__succeeded);
            if (trans__succeeded)
              {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__V_28_28 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = TRUE;
              }
          }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 222 "trans.m"
    if (trans__succeeded)
#line 222 "trans.m"
      *trans__HeadVar__1_1 = trans__V_28_28;
#line 222 "trans.m"
    else
#line 222 "trans.m"
      {
#line 222 "trans.m"
        MR_Word trans__V_29_29;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        trans__succeeded = (trans__V_5_5 < trans__V_17_17);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_90_90 = (MR_Integer) 1;

#line 222 "trans.m"
            trans__succeeded = (trans__V_90_90 == (MR_Integer) 0);
#line 222 "trans.m"
            trans__succeeded = !(trans__succeeded);
            if (trans__succeeded)
              {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__V_29_29 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = TRUE;
              }
          }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__succeeded = (trans__V_5_5 > trans__V_17_17);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (trans__succeeded)
              {
                MR_Word trans__V_91_91 = (MR_Integer) 2;

#line 222 "trans.m"
                trans__succeeded = (trans__V_91_91 == (MR_Integer) 0);
#line 222 "trans.m"
                trans__succeeded = !(trans__succeeded);
                if (trans__succeeded)
                  {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__V_29_29 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
              {
                MR_Word trans__V_92_92 = (MR_Integer) 0;

#line 222 "trans.m"
                trans__succeeded = (trans__V_92_92 == (MR_Integer) 0);
#line 222 "trans.m"
                trans__succeeded = !(trans__succeeded);
                if (trans__succeeded)
                  {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__V_29_29 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 222 "trans.m"
        if (trans__succeeded)
#line 222 "trans.m"
          *trans__HeadVar__1_1 = trans__V_29_29;
#line 222 "trans.m"
        else
#line 222 "trans.m"
          {
#line 222 "trans.m"
            MR_Word trans__V_30_30;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__succeeded = (trans__V_6_6 < trans__V_18_18);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (trans__succeeded)
              {
                MR_Word trans__V_93_93 = (MR_Integer) 1;

#line 222 "trans.m"
                trans__succeeded = (trans__V_93_93 == (MR_Integer) 0);
#line 222 "trans.m"
                trans__succeeded = !(trans__succeeded);
                if (trans__succeeded)
                  {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__V_30_30 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__succeeded = TRUE;
                  }
              }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = (trans__V_6_6 > trans__V_18_18);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (trans__succeeded)
                  {
                    MR_Word trans__V_94_94 = (MR_Integer) 2;

#line 222 "trans.m"
                    trans__succeeded = (trans__V_94_94 == (MR_Integer) 0);
#line 222 "trans.m"
                    trans__succeeded = !(trans__succeeded);
                    if (trans__succeeded)
                      {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        trans__V_30_30 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        trans__succeeded = TRUE;
                      }
                  }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
                  {
                    MR_Word trans__V_95_95 = (MR_Integer) 0;

#line 222 "trans.m"
                    trans__succeeded = (trans__V_95_95 == (MR_Integer) 0);
#line 222 "trans.m"
                    trans__succeeded = !(trans__succeeded);
                    if (trans__succeeded)
                      {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        trans__V_30_30 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        trans__succeeded = TRUE;
                      }
                  }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              }
#line 222 "trans.m"
            if (trans__succeeded)
#line 222 "trans.m"
              *trans__HeadVar__1_1 = trans__V_30_30;
#line 222 "trans.m"
            else
#line 222 "trans.m"
              {
#line 222 "trans.m"
                MR_Word trans__V_31_31;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = (trans__V_7_7 < trans__V_19_19);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (trans__succeeded)
                  {
                    MR_Word trans__V_96_96 = (MR_Integer) 1;

#line 222 "trans.m"
                    trans__succeeded = (trans__V_96_96 == (MR_Integer) 0);
#line 222 "trans.m"
                    trans__succeeded = !(trans__succeeded);
                    if (trans__succeeded)
                      {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        trans__V_31_31 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        trans__succeeded = TRUE;
                      }
                  }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__succeeded = (trans__V_7_7 > trans__V_19_19);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    if (trans__succeeded)
                      {
                        MR_Word trans__V_97_97 = (MR_Integer) 2;

#line 222 "trans.m"
                        trans__succeeded = (trans__V_97_97 == (MR_Integer) 0);
#line 222 "trans.m"
                        trans__succeeded = !(trans__succeeded);
                        if (trans__succeeded)
                          {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            trans__V_31_31 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            trans__succeeded = TRUE;
                          }
                      }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    else
                      {
                        MR_Word trans__V_98_98 = (MR_Integer) 0;

#line 222 "trans.m"
                        trans__succeeded = (trans__V_98_98 == (MR_Integer) 0);
#line 222 "trans.m"
                        trans__succeeded = !(trans__succeeded);
                        if (trans__succeeded)
                          {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            trans__V_31_31 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            trans__succeeded = TRUE;
                          }
                      }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  }
#line 222 "trans.m"
                if (trans__succeeded)
#line 222 "trans.m"
                  *trans__HeadVar__1_1 = trans__V_31_31;
#line 222 "trans.m"
                else
#line 222 "trans.m"
                  {
#line 222 "trans.m"
                    MR_Word trans__V_32_32;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__succeeded = (trans__V_8_8 < trans__V_20_20);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    if (trans__succeeded)
                      {
                        MR_Word trans__V_99_99 = (MR_Integer) 1;

#line 222 "trans.m"
                        trans__succeeded = (trans__V_99_99 == (MR_Integer) 0);
#line 222 "trans.m"
                        trans__succeeded = !(trans__succeeded);
                        if (trans__succeeded)
                          {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            trans__V_32_32 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            trans__succeeded = TRUE;
                          }
                      }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        trans__succeeded = (trans__V_8_8 > trans__V_20_20);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        if (trans__succeeded)
                          {
                            MR_Word trans__V_100_100 = (MR_Integer) 2;

#line 222 "trans.m"
                            trans__succeeded = (trans__V_100_100 == (MR_Integer) 0);
#line 222 "trans.m"
                            trans__succeeded = !(trans__succeeded);
                            if (trans__succeeded)
                              {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                trans__V_32_32 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                trans__succeeded = TRUE;
                              }
                          }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        else
                          {
                            MR_Word trans__V_101_101 = (MR_Integer) 0;

#line 222 "trans.m"
                            trans__succeeded = (trans__V_101_101 == (MR_Integer) 0);
#line 222 "trans.m"
                            trans__succeeded = !(trans__succeeded);
                            if (trans__succeeded)
                              {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                trans__V_32_32 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                trans__succeeded = TRUE;
                              }
                          }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                      }
#line 222 "trans.m"
                    if (trans__succeeded)
#line 222 "trans.m"
                      *trans__HeadVar__1_1 = trans__V_32_32;
#line 222 "trans.m"
                    else
#line 222 "trans.m"
                      {
#line 222 "trans.m"
                        MR_Word trans__V_33_33;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        trans__succeeded = (trans__V_9_9 < trans__V_21_21);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        if (trans__succeeded)
                          {
                            MR_Word trans__V_102_102 = (MR_Integer) 1;

#line 222 "trans.m"
                            trans__succeeded = (trans__V_102_102 == (MR_Integer) 0);
#line 222 "trans.m"
                            trans__succeeded = !(trans__succeeded);
                            if (trans__succeeded)
                              {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                trans__V_33_33 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                trans__succeeded = TRUE;
                              }
                          }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                        else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            trans__succeeded = (trans__V_9_9 > trans__V_21_21);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            if (trans__succeeded)
                              {
                                MR_Word trans__V_103_103 = (MR_Integer) 2;

#line 222 "trans.m"
                                trans__succeeded = (trans__V_103_103 == (MR_Integer) 0);
#line 222 "trans.m"
                                trans__succeeded = !(trans__succeeded);
                                if (trans__succeeded)
                                  {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    trans__V_33_33 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    trans__succeeded = TRUE;
                                  }
                              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            else
                              {
                                MR_Word trans__V_104_104 = (MR_Integer) 0;

#line 222 "trans.m"
                                trans__succeeded = (trans__V_104_104 == (MR_Integer) 0);
#line 222 "trans.m"
                                trans__succeeded = !(trans__succeeded);
                                if (trans__succeeded)
                                  {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    trans__V_33_33 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    trans__succeeded = TRUE;
                                  }
                              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                          }
#line 222 "trans.m"
                        if (trans__succeeded)
#line 222 "trans.m"
                          *trans__HeadVar__1_1 = trans__V_33_33;
#line 222 "trans.m"
                        else
#line 222 "trans.m"
                          {
#line 222 "trans.m"
                            MR_Word trans__V_34_34;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            trans__succeeded = (trans__V_10_10 < trans__V_22_22);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            if (trans__succeeded)
                              {
                                MR_Word trans__V_105_105 = (MR_Integer) 1;

#line 222 "trans.m"
                                trans__succeeded = (trans__V_105_105 == (MR_Integer) 0);
#line 222 "trans.m"
                                trans__succeeded = !(trans__succeeded);
                                if (trans__succeeded)
                                  {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    trans__V_34_34 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    trans__succeeded = TRUE;
                                  }
                              }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                            else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                trans__succeeded = (trans__V_10_10 > trans__V_22_22);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                if (trans__succeeded)
                                  {
                                    MR_Word trans__V_106_106 = (MR_Integer) 2;

#line 222 "trans.m"
                                    trans__succeeded = (trans__V_106_106 == (MR_Integer) 0);
#line 222 "trans.m"
                                    trans__succeeded = !(trans__succeeded);
                                    if (trans__succeeded)
                                      {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        trans__V_34_34 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        trans__succeeded = TRUE;
                                      }
                                  }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                else
                                  {
                                    MR_Word trans__V_107_107 = (MR_Integer) 0;

#line 222 "trans.m"
                                    trans__succeeded = (trans__V_107_107 == (MR_Integer) 0);
#line 222 "trans.m"
                                    trans__succeeded = !(trans__succeeded);
                                    if (trans__succeeded)
                                      {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        trans__V_34_34 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        trans__succeeded = TRUE;
                                      }
                                  }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                              }
#line 222 "trans.m"
                            if (trans__succeeded)
#line 222 "trans.m"
                              *trans__HeadVar__1_1 = trans__V_34_34;
#line 222 "trans.m"
                            else
#line 222 "trans.m"
                              {
#line 222 "trans.m"
                                MR_Word trans__V_35_35;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                trans__succeeded = (trans__V_11_11 < trans__V_23_23);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                if (trans__succeeded)
                                  {
                                    MR_Word trans__V_108_108 = (MR_Integer) 1;

#line 222 "trans.m"
                                    trans__succeeded = (trans__V_108_108 == (MR_Integer) 0);
#line 222 "trans.m"
                                    trans__succeeded = !(trans__succeeded);
                                    if (trans__succeeded)
                                      {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        trans__V_35_35 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        trans__succeeded = TRUE;
                                      }
                                  }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    trans__succeeded = (trans__V_11_11 > trans__V_23_23);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    if (trans__succeeded)
                                      {
                                        MR_Word trans__V_109_109 = (MR_Integer) 2;

#line 222 "trans.m"
                                        trans__succeeded = (trans__V_109_109 == (MR_Integer) 0);
#line 222 "trans.m"
                                        trans__succeeded = !(trans__succeeded);
                                        if (trans__succeeded)
                                          {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                            trans__V_35_35 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                            trans__succeeded = TRUE;
                                          }
                                      }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    else
                                      {
                                        MR_Word trans__V_110_110 = (MR_Integer) 0;

#line 222 "trans.m"
                                        trans__succeeded = (trans__V_110_110 == (MR_Integer) 0);
#line 222 "trans.m"
                                        trans__succeeded = !(trans__succeeded);
                                        if (trans__succeeded)
                                          {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                            trans__V_35_35 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                            trans__succeeded = TRUE;
                                          }
                                      }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                  }
#line 222 "trans.m"
                                if (trans__succeeded)
#line 222 "trans.m"
                                  *trans__HeadVar__1_1 = trans__V_35_35;
#line 222 "trans.m"
                                else
#line 222 "trans.m"
                                  {
#line 222 "trans.m"
                                    MR_Word trans__V_36_36;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    trans__succeeded = (trans__V_12_12 < trans__V_24_24);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    if (trans__succeeded)
                                      {
                                        MR_Word trans__V_111_111 = (MR_Integer) 1;

#line 222 "trans.m"
                                        trans__succeeded = (trans__V_111_111 == (MR_Integer) 0);
#line 222 "trans.m"
                                        trans__succeeded = !(trans__succeeded);
                                        if (trans__succeeded)
                                          {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                            trans__V_36_36 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                            trans__succeeded = TRUE;
                                          }
                                      }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                    else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        trans__succeeded = (trans__V_12_12 > trans__V_24_24);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        if (trans__succeeded)
                                          {
                                            MR_Word trans__V_112_112 = (MR_Integer) 2;

#line 222 "trans.m"
                                            trans__succeeded = (trans__V_112_112 == (MR_Integer) 0);
#line 222 "trans.m"
                                            trans__succeeded = !(trans__succeeded);
                                            if (trans__succeeded)
                                              {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                trans__V_36_36 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                trans__succeeded = TRUE;
                                              }
                                          }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        else
                                          {
                                            MR_Word trans__V_113_113 = (MR_Integer) 0;

#line 222 "trans.m"
                                            trans__succeeded = (trans__V_113_113 == (MR_Integer) 0);
#line 222 "trans.m"
                                            trans__succeeded = !(trans__succeeded);
                                            if (trans__succeeded)
                                              {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                trans__V_36_36 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                trans__succeeded = TRUE;
                                              }
                                          }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                      }
#line 222 "trans.m"
                                    if (trans__succeeded)
#line 222 "trans.m"
                                      *trans__HeadVar__1_1 = trans__V_36_36;
#line 222 "trans.m"
                                    else
#line 222 "trans.m"
                                      {
#line 222 "trans.m"
                                        MR_Word trans__V_37_37;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        trans__succeeded = (trans__V_13_13 < trans__V_25_25);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        if (trans__succeeded)
                                          {
                                            MR_Word trans__V_114_114 = (MR_Integer) 1;

#line 222 "trans.m"
                                            trans__succeeded = (trans__V_114_114 == (MR_Integer) 0);
#line 222 "trans.m"
                                            trans__succeeded = !(trans__succeeded);
                                            if (trans__succeeded)
                                              {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                trans__V_37_37 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                trans__succeeded = TRUE;
                                              }
                                          }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                        else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                          {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                            trans__succeeded = (trans__V_13_13 > trans__V_25_25);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                            if (trans__succeeded)
                                              {
                                                MR_Word trans__V_115_115 = (MR_Integer) 2;

#line 222 "trans.m"
                                                trans__succeeded = (trans__V_115_115 == (MR_Integer) 0);
#line 222 "trans.m"
                                                trans__succeeded = !(trans__succeeded);
                                                if (trans__succeeded)
                                                  {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                    trans__V_37_37 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                    trans__succeeded = TRUE;
                                                  }
                                              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                            else
                                              {
                                                MR_Word trans__V_116_116 = (MR_Integer) 0;

#line 222 "trans.m"
                                                trans__succeeded = (trans__V_116_116 == (MR_Integer) 0);
#line 222 "trans.m"
                                                trans__succeeded = !(trans__succeeded);
                                                if (trans__succeeded)
                                                  {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                    trans__V_37_37 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                    trans__succeeded = TRUE;
                                                  }
                                              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                          }
#line 222 "trans.m"
                                        if (trans__succeeded)
#line 222 "trans.m"
                                          *trans__HeadVar__1_1 = trans__V_37_37;
#line 222 "trans.m"
                                        else
#line 222 "trans.m"
                                          {
#line 222 "trans.m"
                                            MR_Word trans__V_38_38;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                            trans__succeeded = (trans__V_14_14 < trans__V_26_26);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                            if (trans__succeeded)
                                              {
                                                MR_Word trans__V_117_117 = (MR_Integer) 1;

#line 222 "trans.m"
                                                trans__succeeded = (trans__V_117_117 == (MR_Integer) 0);
#line 222 "trans.m"
                                                trans__succeeded = !(trans__succeeded);
                                                if (trans__succeeded)
                                                  {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                    trans__V_38_38 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                    trans__succeeded = TRUE;
                                                  }
                                              }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                            else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                              {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                trans__succeeded = (trans__V_14_14 > trans__V_26_26);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                if (trans__succeeded)
                                                  {
                                                    MR_Word trans__V_118_118 = (MR_Integer) 2;

#line 222 "trans.m"
                                                    trans__succeeded = (trans__V_118_118 == (MR_Integer) 0);
#line 222 "trans.m"
                                                    trans__succeeded = !(trans__succeeded);
                                                    if (trans__succeeded)
                                                      {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                        trans__V_38_38 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                        trans__succeeded = TRUE;
                                                      }
                                                  }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                else
                                                  {
                                                    MR_Word trans__V_119_119 = (MR_Integer) 0;

#line 222 "trans.m"
                                                    trans__succeeded = (trans__V_119_119 == (MR_Integer) 0);
#line 222 "trans.m"
                                                    trans__succeeded = !(trans__succeeded);
                                                    if (trans__succeeded)
                                                      {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                        trans__V_38_38 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                        trans__succeeded = TRUE;
                                                      }
                                                  }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                              }
#line 222 "trans.m"
                                            if (trans__succeeded)
#line 222 "trans.m"
                                              *trans__HeadVar__1_1 = trans__V_38_38;
#line 222 "trans.m"
                                            else
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                              {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                trans__succeeded = (trans__V_15_15 < trans__V_27_27);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                if (trans__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                  *trans__HeadVar__1_1 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                  {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                    trans__succeeded = (trans__V_15_15 > trans__V_27_27);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                    if (trans__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                      *trans__HeadVar__1_1 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                    else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                      *trans__HeadVar__1_1 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                                  }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                                              }
#line 222 "trans.m"
                                          }
#line 222 "trans.m"
                                      }
#line 222 "trans.m"
                                  }
#line 222 "trans.m"
                              }
#line 222 "trans.m"
                          }
#line 222 "trans.m"
                      }
#line 222 "trans.m"
                  }
#line 222 "trans.m"
              }
#line 222 "trans.m"
          }
#line 222 "trans.m"
      }
  }
#line 222 "trans.m"
}

#line 222 "trans.m"
bool MR_CALL trans____Unify____matrix_0_0(
#line 222 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 222 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 222 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Float trans__V_3_3 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float trans__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 3)));
    MR_Float trans__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 4)));
    MR_Float trans__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 5)));
    MR_Float trans__V_9_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 6)));
    MR_Float trans__V_10_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 7)));
    MR_Float trans__V_11_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 8)));
    MR_Float trans__V_12_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 9)));
    MR_Float trans__V_13_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 10)));
    MR_Float trans__V_14_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 11)));
    MR_Float trans__V_15_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__V_16_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__V_17_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float trans__V_18_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 3)));
    MR_Float trans__V_19_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 4)));
    MR_Float trans__V_20_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 5)));
    MR_Float trans__V_21_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 6)));
    MR_Float trans__V_22_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 7)));
    MR_Float trans__V_23_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 8)));
    MR_Float trans__V_24_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 9)));
    MR_Float trans__V_25_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 10)));
    MR_Float trans__V_26_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 11)));

    trans__succeeded = (trans__V_3_3 == trans__V_15_15);
    if (trans__succeeded)
      {
        trans__succeeded = (trans__V_4_4 == trans__V_16_16);
        if (trans__succeeded)
          {
            trans__succeeded = (trans__V_5_5 == trans__V_17_17);
            if (trans__succeeded)
              {
                trans__succeeded = (trans__V_6_6 == trans__V_18_18);
                if (trans__succeeded)
                  {
                    trans__succeeded = (trans__V_7_7 == trans__V_19_19);
                    if (trans__succeeded)
                      {
                        trans__succeeded = (trans__V_8_8 == trans__V_20_20);
                        if (trans__succeeded)
                          {
                            trans__succeeded = (trans__V_9_9 == trans__V_21_21);
                            if (trans__succeeded)
                              {
                                trans__succeeded = (trans__V_10_10 == trans__V_22_22);
                                if (trans__succeeded)
                                  {
                                    trans__succeeded = (trans__V_11_11 == trans__V_23_23);
                                    if (trans__succeeded)
                                      {
                                        trans__succeeded = (trans__V_12_12 == trans__V_24_24);
                                        if (trans__succeeded)
                                          {
                                            trans__succeeded = (trans__V_13_13 == trans__V_25_25);
                                            if (trans__succeeded)
                                              trans__succeeded = (trans__V_14_14 == trans__V_26_26);
                                          }
                                      }
                                  }
                              }
                          }
                      }
                  }
              }
          }
      }
    return trans__succeeded;
  }
#line 222 "trans.m"
}

#line 139 "trans.m"
void MR_CALL trans____Compare____intersections_0_0(
#line 139 "trans.m"
  MR_Word * trans__HeadVar__1_1,
#line 139 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 139 "trans.m"
  MR_Word trans__HeadVar__3_3)
#line 139 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__conv1_HeadVar__2_2 = (MR_Word) trans__HeadVar__2_2;
    MR_Word trans__conv2_HeadVar__3_3 = (MR_Word) trans__HeadVar__3_3;
    MR_Word trans__TypeInfo_4_4 = (MR_Word) (&trans__trans__type_ctor_info_intersection_0);

#line 139 "trans.m"
    {
#line 139 "trans.m"
      mercury__list____Compare____list_1_0(trans__TypeInfo_4_4, trans__HeadVar__1_1, trans__conv1_HeadVar__2_2, trans__conv2_HeadVar__3_3);
#line 139 "trans.m"
      return;
    }
  }
#line 139 "trans.m"
}

#line 139 "trans.m"
bool MR_CALL trans____Unify____intersections_0_0(
#line 139 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 139 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 139 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__conv1_HeadVar__1_1 = (MR_Word) trans__HeadVar__1_1;
    MR_Word trans__conv2_HeadVar__2_2 = (MR_Word) trans__HeadVar__2_2;
    MR_Word trans__TypeInfo_3_3 = (MR_Word) (&trans__trans__type_ctor_info_intersection_0);

#line 139 "trans.m"
    {
#line 139 "trans.m"
      trans__succeeded = mercury__list____Unify____list_1_0(trans__TypeInfo_3_3, trans__conv1_HeadVar__1_1, trans__conv2_HeadVar__2_2);
    }
    if (trans__succeeded)
      trans__succeeded = TRUE;
    return trans__succeeded;
  }
#line 139 "trans.m"
}

#line 130 "trans.m"
void MR_CALL trans____Compare____intersection_0_0(
#line 130 "trans.m"
  MR_Word * trans__HeadVar__1_1,
#line 130 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 130 "trans.m"
  MR_Word trans__HeadVar__3_3)
#line 130 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Integer trans__V_4_4 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word trans__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word trans__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word trans__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 3)));
    MR_Word trans__V_8_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 4)));
    MR_Integer trans__V_9_9 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 0)));
    MR_Word trans__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 1)));
    MR_Word trans__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 2)));
    MR_Word trans__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 3)));
    MR_Word trans__V_13_13 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 4)));
#line 130 "trans.m"
    MR_Word trans__V_14_14;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    trans__succeeded = (trans__V_4_4 < trans__V_9_9);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (trans__succeeded)
      {
        MR_Word trans__V_26_26 = (MR_Integer) 1;

#line 130 "trans.m"
        trans__succeeded = (trans__V_26_26 == (MR_Integer) 0);
#line 130 "trans.m"
        trans__succeeded = !(trans__succeeded);
        if (trans__succeeded)
          {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__V_14_14 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__succeeded = TRUE;
          }
      }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        trans__succeeded = (trans__V_4_4 == trans__V_9_9);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_27_27 = (MR_Integer) 0;

#line 130 "trans.m"
            trans__succeeded = (trans__V_27_27 == (MR_Integer) 0);
#line 130 "trans.m"
            trans__succeeded = !(trans__succeeded);
            if (trans__succeeded)
              {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__V_14_14 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = TRUE;
              }
          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
          {
            MR_Word trans__V_28_28 = (MR_Integer) 2;

#line 130 "trans.m"
            trans__succeeded = (trans__V_28_28 == (MR_Integer) 0);
#line 130 "trans.m"
            trans__succeeded = !(trans__succeeded);
            if (trans__succeeded)
              {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__V_14_14 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = TRUE;
              }
          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 130 "trans.m"
    if (trans__succeeded)
#line 130 "trans.m"
      *trans__HeadVar__1_1 = trans__V_14_14;
#line 130 "trans.m"
    else
#line 130 "trans.m"
      {
#line 130 "trans.m"
        MR_Word trans__V_15_15;

#line 130 "trans.m"
        {
#line 130 "trans.m"
          vector____Compare____vector_0_0(&trans__V_15_15, trans__V_5_5, trans__V_10_10);
        }
#line 130 "trans.m"
        trans__succeeded = (trans__V_15_15 == (MR_Integer) 0);
#line 130 "trans.m"
        trans__succeeded = !(trans__succeeded);
#line 130 "trans.m"
        if (trans__succeeded)
#line 130 "trans.m"
          *trans__HeadVar__1_1 = trans__V_15_15;
#line 130 "trans.m"
        else
#line 130 "trans.m"
          {
#line 130 "trans.m"
            MR_Word trans__V_16_16;

#line 130 "trans.m"
            {
#line 130 "trans.m"
              vector____Compare____vector_0_0(&trans__V_16_16, trans__V_6_6, trans__V_11_11);
            }
#line 130 "trans.m"
            trans__succeeded = (trans__V_16_16 == (MR_Integer) 0);
#line 130 "trans.m"
            trans__succeeded = !(trans__succeeded);
#line 130 "trans.m"
            if (trans__succeeded)
#line 130 "trans.m"
              *trans__HeadVar__1_1 = trans__V_16_16;
#line 130 "trans.m"
            else
#line 130 "trans.m"
              {
#line 130 "trans.m"
                MR_Word trans__V_17_17;

#line 130 "trans.m"
                {
#line 130 "trans.m"
                  trans____Compare____surface_coordinates_0_0(&trans__V_17_17, trans__V_7_7, trans__V_12_12);
                }
#line 130 "trans.m"
                trans__succeeded = (trans__V_17_17 == (MR_Integer) 0);
#line 130 "trans.m"
                trans__succeeded = !(trans__succeeded);
#line 130 "trans.m"
                if (trans__succeeded)
#line 130 "trans.m"
                  *trans__HeadVar__1_1 = trans__V_17_17;
#line 130 "trans.m"
                else
#line 130 "trans.m"
                  {
#line 130 "trans.m"
                    eval____Compare____surface_0_0(trans__HeadVar__1_1, trans__V_8_8, trans__V_13_13);
#line 130 "trans.m"
                    return;
                  }
#line 130 "trans.m"
              }
#line 130 "trans.m"
          }
#line 130 "trans.m"
      }
  }
#line 130 "trans.m"
}

#line 130 "trans.m"
bool MR_CALL trans____Unify____intersection_0_0(
#line 130 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 130 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 130 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Integer trans__V_3_3 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word trans__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word trans__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 2)));
    MR_Word trans__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 3)));
    MR_Word trans__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 4)));
    MR_Integer trans__V_8_8 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word trans__V_9_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word trans__V_10_10 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Word trans__V_11_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 3)));
    MR_Word trans__V_12_12 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 4)));
    MR_Integer trans__V_16_16;
    MR_Float trans__V_17_17;
    MR_Float trans__V_18_18;
    MR_Integer trans__V_19_19;
    MR_Float trans__V_20_20;
    MR_Float trans__V_21_21;

    trans__succeeded = (trans__V_3_3 == trans__V_8_8);
    if (trans__succeeded)
      {
        {
          trans__succeeded = vector____Unify____vector_0_0(trans__V_4_4, trans__V_9_9);
        }
        if (trans__succeeded)
          {
            {
              trans__succeeded = vector____Unify____vector_0_0(trans__V_5_5, trans__V_10_10);
            }
            if (trans__succeeded)
              {
#line 60 "trans.m"
                trans__V_16_16 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 0)));
#line 60 "trans.m"
                trans__V_17_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 1)));
#line 60 "trans.m"
                trans__V_18_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 2)));
#line 60 "trans.m"
                trans__V_19_19 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__V_11_11, (MR_Integer) 0)));
#line 60 "trans.m"
                trans__V_20_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_11_11, (MR_Integer) 1)));
#line 60 "trans.m"
                trans__V_21_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_11_11, (MR_Integer) 2)));
                trans__succeeded = (trans__V_16_16 == trans__V_19_19);
                if (trans__succeeded)
                  {
                    trans__succeeded = (trans__V_17_17 == trans__V_20_20);
                    if (trans__succeeded)
                      {
                        trans__succeeded = (trans__V_18_18 == trans__V_21_21);
                        if (trans__succeeded)
                          {
                            return trans__succeeded = eval____Unify____surface_0_0(trans__V_7_7, trans__V_12_12);
                          }
                      }
                  }
              }
          }
      }
    return trans__succeeded;
  }
#line 130 "trans.m"
}

#line 72 "trans.m"
void MR_CALL trans____Compare____trans_0_0(
#line 72 "trans.m"
  MR_Word * trans__HeadVar__1_1,
#line 72 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 72 "trans.m"
  MR_Word trans__HeadVar__3_3)
#line 72 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word trans__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word trans__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 0)));
    MR_Word trans__V_7_7 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 1)));
#line 219 "trans.m"
    MR_Word trans__V_8_8;

#line 219 "trans.m"
    {
#line 219 "trans.m"
      trans____Compare____matrix_0_0(&trans__V_8_8, trans__V_4_4, trans__V_6_6);
    }
#line 219 "trans.m"
    trans__succeeded = (trans__V_8_8 == (MR_Integer) 0);
#line 219 "trans.m"
    trans__succeeded = !(trans__succeeded);
#line 219 "trans.m"
    if (trans__succeeded)
#line 219 "trans.m"
      *trans__HeadVar__1_1 = trans__V_8_8;
#line 219 "trans.m"
    else
#line 219 "trans.m"
      {
#line 219 "trans.m"
        trans____Compare____matrix_0_0(trans__HeadVar__1_1, trans__V_5_5, trans__V_7_7);
#line 219 "trans.m"
        return;
      }
  }
#line 72 "trans.m"
}

#line 72 "trans.m"
bool MR_CALL trans____Unify____trans_0_0(
#line 72 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 72 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 72 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__V_3_3 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word trans__V_4_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Word trans__V_5_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word trans__V_6_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_3_3, (MR_Integer) 0)));
    MR_Float trans__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_3_3, (MR_Integer) 1)));
    MR_Float trans__V_9_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_3_3, (MR_Integer) 2)));
    MR_Float trans__V_10_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_3_3, (MR_Integer) 3)));
    MR_Float trans__V_11_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_3_3, (MR_Integer) 4)));
    MR_Float trans__V_12_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_3_3, (MR_Integer) 5)));
    MR_Float trans__V_13_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_3_3, (MR_Integer) 6)));
    MR_Float trans__V_14_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_3_3, (MR_Integer) 7)));
    MR_Float trans__V_15_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_3_3, (MR_Integer) 8)));
    MR_Float trans__V_16_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_3_3, (MR_Integer) 9)));
    MR_Float trans__V_17_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_3_3, (MR_Integer) 10)));
    MR_Float trans__V_18_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_3_3, (MR_Integer) 11)));
    MR_Float trans__V_19_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_5_5, (MR_Integer) 0)));
    MR_Float trans__V_20_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_5_5, (MR_Integer) 1)));
    MR_Float trans__V_21_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_5_5, (MR_Integer) 2)));
    MR_Float trans__V_22_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_5_5, (MR_Integer) 3)));
    MR_Float trans__V_23_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_5_5, (MR_Integer) 4)));
    MR_Float trans__V_24_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_5_5, (MR_Integer) 5)));
    MR_Float trans__V_25_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_5_5, (MR_Integer) 6)));
    MR_Float trans__V_26_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_5_5, (MR_Integer) 7)));
    MR_Float trans__V_27_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_5_5, (MR_Integer) 8)));
    MR_Float trans__V_28_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_5_5, (MR_Integer) 9)));
    MR_Float trans__V_29_29 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_5_5, (MR_Integer) 10)));
    MR_Float trans__V_30_30 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_5_5, (MR_Integer) 11)));
    MR_Float trans__V_31_31;
    MR_Float trans__V_32_32;
    MR_Float trans__V_33_33;
    MR_Float trans__V_34_34;
    MR_Float trans__V_35_35;
    MR_Float trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40;
    MR_Float trans__V_41_41;
    MR_Float trans__V_42_42;
    MR_Float trans__V_43_43;
    MR_Float trans__V_44_44;
    MR_Float trans__V_45_45;
    MR_Float trans__V_46_46;
    MR_Float trans__V_47_47;
    MR_Float trans__V_48_48;
    MR_Float trans__V_49_49;
    MR_Float trans__V_50_50;
    MR_Float trans__V_51_51;
    MR_Float trans__V_52_52;
    MR_Float trans__V_53_53;
    MR_Float trans__V_54_54;

    trans__succeeded = (trans__V_7_7 == trans__V_19_19);
    if (trans__succeeded)
      {
        trans__succeeded = (trans__V_8_8 == trans__V_20_20);
        if (trans__succeeded)
          {
            trans__succeeded = (trans__V_9_9 == trans__V_21_21);
            if (trans__succeeded)
              {
                trans__succeeded = (trans__V_10_10 == trans__V_22_22);
                if (trans__succeeded)
                  {
                    trans__succeeded = (trans__V_11_11 == trans__V_23_23);
                    if (trans__succeeded)
                      {
                        trans__succeeded = (trans__V_12_12 == trans__V_24_24);
                        if (trans__succeeded)
                          {
                            trans__succeeded = (trans__V_13_13 == trans__V_25_25);
                            if (trans__succeeded)
                              {
                                trans__succeeded = (trans__V_14_14 == trans__V_26_26);
                                if (trans__succeeded)
                                  {
                                    trans__succeeded = (trans__V_15_15 == trans__V_27_27);
                                    if (trans__succeeded)
                                      {
                                        trans__succeeded = (trans__V_16_16 == trans__V_28_28);
                                        if (trans__succeeded)
                                          {
                                            trans__succeeded = (trans__V_17_17 == trans__V_29_29);
                                            if (trans__succeeded)
                                              {
                                                trans__succeeded = (trans__V_18_18 == trans__V_30_30);
                                                if (trans__succeeded)
                                                  {
#line 222 "trans.m"
                                                    trans__V_31_31 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_4_4, (MR_Integer) 0)));
#line 222 "trans.m"
                                                    trans__V_32_32 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_4_4, (MR_Integer) 1)));
#line 222 "trans.m"
                                                    trans__V_33_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_4_4, (MR_Integer) 2)));
#line 222 "trans.m"
                                                    trans__V_34_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_4_4, (MR_Integer) 3)));
#line 222 "trans.m"
                                                    trans__V_35_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_4_4, (MR_Integer) 4)));
#line 222 "trans.m"
                                                    trans__V_36_36 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_4_4, (MR_Integer) 5)));
#line 222 "trans.m"
                                                    trans__V_37_37 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_4_4, (MR_Integer) 6)));
#line 222 "trans.m"
                                                    trans__V_38_38 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_4_4, (MR_Integer) 7)));
#line 222 "trans.m"
                                                    trans__V_39_39 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_4_4, (MR_Integer) 8)));
#line 222 "trans.m"
                                                    trans__V_40_40 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_4_4, (MR_Integer) 9)));
#line 222 "trans.m"
                                                    trans__V_41_41 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_4_4, (MR_Integer) 10)));
#line 222 "trans.m"
                                                    trans__V_42_42 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_4_4, (MR_Integer) 11)));
#line 222 "trans.m"
                                                    trans__V_43_43 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 0)));
#line 222 "trans.m"
                                                    trans__V_44_44 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 1)));
#line 222 "trans.m"
                                                    trans__V_45_45 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 2)));
#line 222 "trans.m"
                                                    trans__V_46_46 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 3)));
#line 222 "trans.m"
                                                    trans__V_47_47 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 4)));
#line 222 "trans.m"
                                                    trans__V_48_48 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 5)));
#line 222 "trans.m"
                                                    trans__V_49_49 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 6)));
#line 222 "trans.m"
                                                    trans__V_50_50 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 7)));
#line 222 "trans.m"
                                                    trans__V_51_51 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 8)));
#line 222 "trans.m"
                                                    trans__V_52_52 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 9)));
#line 222 "trans.m"
                                                    trans__V_53_53 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 10)));
#line 222 "trans.m"
                                                    trans__V_54_54 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_6_6, (MR_Integer) 11)));
                                                    trans__succeeded = (trans__V_31_31 == trans__V_43_43);
                                                    if (trans__succeeded)
                                                      {
                                                        trans__succeeded = (trans__V_32_32 == trans__V_44_44);
                                                        if (trans__succeeded)
                                                          {
                                                            trans__succeeded = (trans__V_33_33 == trans__V_45_45);
                                                            if (trans__succeeded)
                                                              {
                                                                trans__succeeded = (trans__V_34_34 == trans__V_46_46);
                                                                if (trans__succeeded)
                                                                  {
                                                                    trans__succeeded = (trans__V_35_35 == trans__V_47_47);
                                                                    if (trans__succeeded)
                                                                      {
                                                                        trans__succeeded = (trans__V_36_36 == trans__V_48_48);
                                                                        if (trans__succeeded)
                                                                          {
                                                                            trans__succeeded = (trans__V_37_37 == trans__V_49_49);
                                                                            if (trans__succeeded)
                                                                              {
                                                                                trans__succeeded = (trans__V_38_38 == trans__V_50_50);
                                                                                if (trans__succeeded)
                                                                                  {
                                                                                    trans__succeeded = (trans__V_39_39 == trans__V_51_51);
                                                                                    if (trans__succeeded)
                                                                                      {
                                                                                        trans__succeeded = (trans__V_40_40 == trans__V_52_52);
                                                                                        if (trans__succeeded)
                                                                                          {
                                                                                            trans__succeeded = (trans__V_41_41 == trans__V_53_53);
                                                                                            if (trans__succeeded)
                                                                                              trans__succeeded = (trans__V_42_42 == trans__V_54_54);
                                                                                          }
                                                                                      }
                                                                                  }
                                                                              }
                                                                          }
                                                                      }
                                                                  }
                                                              }
                                                          }
                                                      }
                                                  }
                                              }
                                          }
                                      }
                                  }
                              }
                          }
                      }
                  }
              }
          }
      }
    return trans__succeeded;
  }
#line 72 "trans.m"
}

#line 60 "trans.m"
void MR_CALL trans____Compare____surface_coordinates_0_0(
#line 60 "trans.m"
  MR_Word * trans__HeadVar__1_1,
#line 60 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 60 "trans.m"
  MR_Word trans__HeadVar__3_3)
#line 60 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Integer trans__V_4_4 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__V_6_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Integer trans__V_7_7 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float trans__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 1)));
    MR_Float trans__V_9_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 2)));
#line 60 "trans.m"
    MR_Word trans__V_10_10;

#line 18 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    trans__succeeded = (trans__V_4_4 < trans__V_7_7);
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    if (trans__succeeded)
      {
        MR_Word trans__V_24_24 = (MR_Integer) 1;

#line 60 "trans.m"
        trans__succeeded = (trans__V_24_24 == (MR_Integer) 0);
#line 60 "trans.m"
        trans__succeeded = !(trans__succeeded);
        if (trans__succeeded)
          {
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__V_10_10 = (MR_Integer) 1;
#line 20 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__succeeded = TRUE;
          }
      }
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
    else
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      {
#line 23 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        trans__succeeded = (trans__V_4_4 == trans__V_7_7);
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_25_25 = (MR_Integer) 0;

#line 60 "trans.m"
            trans__succeeded = (trans__V_25_25 == (MR_Integer) 0);
#line 60 "trans.m"
            trans__succeeded = !(trans__succeeded);
            if (trans__succeeded)
              {
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__V_10_10 = (MR_Integer) 0;
#line 25 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = TRUE;
              }
          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
          {
            MR_Word trans__V_26_26 = (MR_Integer) 2;

#line 60 "trans.m"
            trans__succeeded = (trans__V_26_26 == (MR_Integer) 0);
#line 60 "trans.m"
            trans__succeeded = !(trans__succeeded);
            if (trans__succeeded)
              {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__V_10_10 = (MR_Integer) 2;
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = TRUE;
              }
          }
#line 26 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
      }
#line 60 "trans.m"
    if (trans__succeeded)
#line 60 "trans.m"
      *trans__HeadVar__1_1 = trans__V_10_10;
#line 60 "trans.m"
    else
#line 60 "trans.m"
      {
#line 60 "trans.m"
        MR_Word trans__V_11_11;

#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        trans__succeeded = (trans__V_5_5 < trans__V_8_8);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_27_27 = (MR_Integer) 1;

#line 60 "trans.m"
            trans__succeeded = (trans__V_27_27 == (MR_Integer) 0);
#line 60 "trans.m"
            trans__succeeded = !(trans__succeeded);
            if (trans__succeeded)
              {
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__V_11_11 = (MR_Integer) 1;
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = TRUE;
              }
          }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
        else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__succeeded = (trans__V_5_5 > trans__V_8_8);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (trans__succeeded)
              {
                MR_Word trans__V_28_28 = (MR_Integer) 2;

#line 60 "trans.m"
                trans__succeeded = (trans__V_28_28 == (MR_Integer) 0);
#line 60 "trans.m"
                trans__succeeded = !(trans__succeeded);
                if (trans__succeeded)
                  {
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__V_11_11 = (MR_Integer) 2;
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
              {
                MR_Word trans__V_29_29 = (MR_Integer) 0;

#line 60 "trans.m"
                trans__succeeded = (trans__V_29_29 == (MR_Integer) 0);
#line 60 "trans.m"
                trans__succeeded = !(trans__succeeded);
                if (trans__succeeded)
                  {
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__V_11_11 = (MR_Integer) 0;
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                    trans__succeeded = TRUE;
                  }
              }
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 60 "trans.m"
        if (trans__succeeded)
#line 60 "trans.m"
          *trans__HeadVar__1_1 = trans__V_11_11;
#line 60 "trans.m"
        else
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          {
#line 70 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            trans__succeeded = (trans__V_6_6 < trans__V_9_9);
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            if (trans__succeeded)
#line 72 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              *trans__HeadVar__1_1 = (MR_Integer) 1;
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
            else
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              {
#line 75 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                trans__succeeded = (trans__V_6_6 > trans__V_9_9);
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                if (trans__succeeded)
#line 77 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *trans__HeadVar__1_1 = (MR_Integer) 2;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                else
#line 79 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
                  *trans__HeadVar__1_1 = (MR_Integer) 0;
#line 78 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
              }
#line 73 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/private_builtin.opt"
          }
#line 60 "trans.m"
      }
  }
#line 60 "trans.m"
}

#line 60 "trans.m"
bool MR_CALL trans____Unify____surface_coordinates_0_0(
#line 60 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 60 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 60 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Integer trans__V_3_3 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__V_4_4 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__V_5_5 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 2)));
    MR_Integer trans__V_6_6 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__V_7_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__V_8_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));

    trans__succeeded = (trans__V_3_3 == trans__V_6_6);
    if (trans__succeeded)
      {
        trans__succeeded = (trans__V_4_4 == trans__V_7_7);
        if (trans__succeeded)
          trans__succeeded = (trans__V_5_5 == trans__V_8_8);
      }
    return trans__succeeded;
  }
#line 60 "trans.m"
}

#line 997 "trans.m"
static MR_Float MR_CALL trans__calc_u_3_f_0(
#line 997 "trans.m"
  MR_Float trans__HeadVar__1_1,
#line 997 "trans.m"
  MR_Float trans__HeadVar__2_2)
#line 997 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Float trans__HeadVar__3_3;
    MR_Float trans__U0_7;
    MR_Float trans__V_10_10;
    MR_Float trans__V_11_11;
    MR_Float trans__V_12_12;
    MR_Float trans__V_13_13;
    MR_Float trans__V_25_25;

#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__calc_u_3_f_0
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Y;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float ATan2;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	Y = 
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__HeadVar__1_1
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__HeadVar__2_2
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	ATan2 = atan2(Y, X);

#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__V_10_10
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = ATan2;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__calc_u_3_f_0
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__V_12_12
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__calc_u_3_f_0
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__V_13_13
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 1000 "trans.m"
    trans__V_11_11 = (trans__V_12_12 + trans__V_13_13);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__calc_u_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      trans__succeeded = (trans__V_11_11 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (trans__succeeded)
      {
        MR_Word trans__V_7_22;
        MR_String trans__V_8_23 = (MR_String) "float:'/'";
        MR_Word trans__TypeInfo_9_24;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        trans__V_7_22 = (MR_Word) trans__V_8_23;
        trans__TypeInfo_9_24 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(trans__TypeInfo_9_24, ((MR_Box) (trans__V_7_22)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      trans__U0_7 = (trans__V_10_10 / trans__V_11_11);
#line 1002 "trans.m"
    trans__V_25_25 = (MR_Float) 0.00000000000000;
#line 1002 "trans.m"
    trans__succeeded = (trans__U0_7 > trans__V_25_25);
#line 1002 "trans.m"
    if (trans__succeeded)
#line 1002 "trans.m"
      trans__HeadVar__3_3 = trans__U0_7;
#line 1002 "trans.m"
    else
      {
        MR_Float trans__V_9_9 = (MR_Float) 1.00000000000000;

#line 1002 "trans.m"
        trans__HeadVar__3_3 = (trans__V_9_9 + trans__U0_7);
      }
    return trans__HeadVar__3_3;
  }
#line 997 "trans.m"
}

#line 922 "trans.m"
static MR_Word MR_CALL trans__disc_intersection_9_f_0(
#line 922 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 922 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 922 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 922 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 922 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 922 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 922 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 922 "trans.m"
  MR_Float trans__HeadVar__8_8)
#line 922 "trans.m"
{
#line 928 "trans.m"
  {
#line 928 "trans.m"
    bool trans__succeeded = (trans__HeadVar__7_7 == ((MR_Float) 0.00000000000000));
#line 928 "trans.m"
    MR_Word trans__HeadVar__9_9;

#line 928 "trans.m"
    if (trans__succeeded)
#line 927 "trans.m"
      trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 928 "trans.m"
    else
      {
        MR_Float trans__K_19;
        MR_Float trans__V_33_33 = (trans__HeadVar__2_2 - trans__HeadVar__4_4);
        MR_Float trans__V_40_40;

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__disc_intersection_9_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__7_7 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_37;
            MR_String trans__V_8_38 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_39;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_37 = (MR_Word) trans__V_8_38;
            trans__TypeInfo_9_39 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_39, ((MR_Box) (trans__V_7_37)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__K_19 = (trans__V_33_33 / trans__HeadVar__7_7);
#line 930 "trans.m"
        trans__V_40_40 = (MR_Float) 0.00000000000000;
#line 930 "trans.m"
        trans__succeeded = (trans__K_19 < trans__V_40_40);
#line 932 "trans.m"
        if (trans__succeeded)
#line 931 "trans.m"
          trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 932 "trans.m"
        else
          {
            MR_Float trans__IX_20;
            MR_Float trans__IZ_21;
            MR_Float trans__V_31_31;
            MR_Float trans__V_32_32 = (trans__K_19 * trans__HeadVar__6_6);
            MR_Float trans__V_23_23;
            MR_Float trans__V_25_25;
            MR_Float trans__V_26_26;
            MR_Float trans__V_41_41;

#line 933 "trans.m"
            trans__IX_20 = (trans__HeadVar__3_3 + trans__V_32_32);
#line 934 "trans.m"
            trans__V_31_31 = (trans__K_19 * trans__HeadVar__8_8);
#line 934 "trans.m"
            trans__IZ_21 = (trans__HeadVar__5_5 + trans__V_31_31);
#line 935 "trans.m"
            trans__V_25_25 = (trans__IX_20 * trans__IX_20);
#line 935 "trans.m"
            trans__V_26_26 = (trans__IZ_21 * trans__IZ_21);
#line 935 "trans.m"
            trans__V_23_23 = (trans__V_25_25 + trans__V_26_26);
#line 935 "trans.m"
            trans__V_41_41 = (MR_Float) 1.00000000000000;
#line 935 "trans.m"
            trans__succeeded = (trans__V_23_23 <= trans__V_41_41);
#line 937 "trans.m"
            if (trans__succeeded)
              {
                MR_Word trans__V_29_29;
                MR_Word trans__V_30_30;

#line 936 "trans.m"
                {
#line 936 "trans.m"
                  trans__V_29_29 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 4 * sizeof(MR_Word)), "fi");
#line 936 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_29_29, 0) = ((MR_Box) (trans__HeadVar__1_1));
#line 936 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_29_29, 1) = MR_box_float(trans__IX_20);
#line 936 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_29_29, 2) = MR_box_float(trans__HeadVar__2_2);
#line 936 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_29_29, 3) = MR_box_float(trans__IZ_21);
#line 936 "trans.m"
                }
#line 936 "trans.m"
                trans__V_30_30 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 936 "trans.m"
                {
#line 936 "trans.m"
                  trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 936 "trans.m"
                  MR_hl_field(MR_mktag(1), trans__HeadVar__9_9, 0) = ((MR_Box) (trans__V_29_29));
#line 936 "trans.m"
                  MR_hl_field(MR_mktag(1), trans__HeadVar__9_9, 1) = ((MR_Box) (trans__V_30_30));
#line 936 "trans.m"
                }
              }
#line 937 "trans.m"
            else
#line 938 "trans.m"
              trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
          }
      }
#line 928 "trans.m"
    return trans__HeadVar__9_9;
#line 928 "trans.m"
  }
#line 922 "trans.m"
}

#line 901 "trans.m"
static void MR_CALL trans__maybe_add_intersection_10_p_0(
#line 901 "trans.m"
  MR_Float trans__HeadVar__1_1,
#line 901 "trans.m"
  MR_Integer trans__HeadVar__2_2,
#line 901 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 901 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 901 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 901 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 901 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 901 "trans.m"
  MR_Float trans__HeadVar__8_8,
#line 901 "trans.m"
  MR_Word trans__HeadVar__9_9,
#line 901 "trans.m"
  MR_Word * trans__HeadVar__10_10)
#line 901 "trans.m"
{
#line 916 "trans.m"
  {
#line 916 "trans.m"
    bool trans__succeeded;
#line 916 "trans.m"
    MR_Float trans__IY_21;
    MR_Float trans__V_26_26;
    MR_Float trans__V_31_31;
    MR_Float trans__V_32_32;
    MR_Float trans__V_33_33 = (MR_Float) 0.00000000000000;

#line 908 "trans.m"
    trans__succeeded = (trans__HeadVar__1_1 >= trans__V_33_33);
    if (trans__succeeded)
      {
#line 909 "trans.m"
        trans__V_26_26 = (trans__HeadVar__1_1 * trans__HeadVar__7_7);
#line 909 "trans.m"
        trans__IY_21 = (trans__HeadVar__4_4 + trans__V_26_26);
#line 910 "trans.m"
        trans__V_32_32 = (MR_Float) 0.00000000000000;
#line 910 "trans.m"
        trans__succeeded = (trans__V_32_32 <= trans__IY_21);
        if (trans__succeeded)
          {
#line 911 "trans.m"
            trans__V_31_31 = (MR_Float) 1.00000000000000;
#line 911 "trans.m"
            trans__succeeded = (trans__IY_21 <= trans__V_31_31);
          }
      }
#line 916 "trans.m"
    if (trans__succeeded)
      {
        MR_Float trans__IX_22;
        MR_Float trans__IZ_23;
        MR_Word trans__V_28_28;
        MR_Float trans__V_29_29;
        MR_Float trans__V_30_30 = (trans__HeadVar__1_1 * trans__HeadVar__6_6);

#line 913 "trans.m"
        trans__IX_22 = (trans__HeadVar__3_3 + trans__V_30_30);
#line 914 "trans.m"
        trans__V_29_29 = (trans__HeadVar__1_1 * trans__HeadVar__8_8);
#line 914 "trans.m"
        trans__IZ_23 = (trans__HeadVar__5_5 + trans__V_29_29);
#line 915 "trans.m"
        {
#line 915 "trans.m"
          trans__V_28_28 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 4 * sizeof(MR_Word)), "fi");
#line 915 "trans.m"
          MR_hl_field(MR_mktag(0), trans__V_28_28, 0) = ((MR_Box) (trans__HeadVar__2_2));
#line 915 "trans.m"
          MR_hl_field(MR_mktag(0), trans__V_28_28, 1) = MR_box_float(trans__IX_22);
#line 915 "trans.m"
          MR_hl_field(MR_mktag(0), trans__V_28_28, 2) = MR_box_float(trans__IY_21);
#line 915 "trans.m"
          MR_hl_field(MR_mktag(0), trans__V_28_28, 3) = MR_box_float(trans__IZ_23);
#line 915 "trans.m"
        }
#line 915 "trans.m"
        {
#line 915 "trans.m"
          *trans__HeadVar__10_10 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 915 "trans.m"
          MR_hl_field(MR_mktag(1), *trans__HeadVar__10_10, 0) = ((MR_Box) (trans__V_28_28));
#line 915 "trans.m"
          MR_hl_field(MR_mktag(1), *trans__HeadVar__10_10, 1) = ((MR_Box) (trans__HeadVar__9_9));
#line 915 "trans.m"
        }
      }
#line 916 "trans.m"
    else
#line 917 "trans.m"
      *trans__HeadVar__10_10 = trans__HeadVar__9_9;
#line 916 "trans.m"
  }
#line 901 "trans.m"
}

#line 881 "trans.m"
static MR_Word MR_CALL trans__solve_quadratic_11_f_0(
#line 881 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 881 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 881 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 881 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 881 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 881 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 881 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 881 "trans.m"
  MR_Float trans__HeadVar__8_8,
#line 881 "trans.m"
  MR_Float trans__HeadVar__9_9,
#line 881 "trans.m"
  MR_Float trans__HeadVar__10_10)
#line 881 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__11_11;
    MR_Float trans__BB4AC_23;
    MR_Float trans__V_36_36 = (trans__HeadVar__9_9 * trans__HeadVar__9_9);
    MR_Float trans__V_37_37;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40 = (MR_Float) 4.00000000000000;
    MR_Float trans__V_73_73;

#line 887 "trans.m"
    trans__V_39_39 = (trans__V_40_40 * trans__HeadVar__8_8);
#line 887 "trans.m"
    trans__V_37_37 = (trans__V_39_39 * trans__HeadVar__10_10);
#line 887 "trans.m"
    trans__BB4AC_23 = (trans__V_36_36 - trans__V_37_37);
#line 888 "trans.m"
    trans__V_73_73 = (MR_Float) 0.00000000000000;
#line 888 "trans.m"
    trans__succeeded = (trans__BB4AC_23 < trans__V_73_73);
#line 890 "trans.m"
    if (trans__succeeded)
#line 889 "trans.m"
      trans__HeadVar__11_11 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 890 "trans.m"
    else
      {
        MR_Float trans__SgnB_24;
        MR_Float trans__Q_25;
        MR_Float trans__K1_26;
        MR_Float trans__K2_27;
        MR_Word trans__Intersections0_28;
        MR_Word trans__V_30_30;
        MR_Float trans__V_31_31;
        MR_Float trans__V_32_32;
        MR_Float trans__V_33_33;
        MR_Float trans__V_34_34;
        MR_Float trans__V_74_74 = (MR_Float) 0.00000000000000;
#line 916 "trans.m"
        MR_Float trans__IY_63;
        MR_Float trans__V_68_68;
        MR_Float trans__V_75_75;
        MR_Float trans__V_76_76;
        MR_Float trans__V_77_77;

#line 891 "trans.m"
        trans__succeeded = (trans__HeadVar__9_9 < trans__V_74_74);
#line 891 "trans.m"
        if (trans__succeeded)
#line 891 "trans.m"
          trans__SgnB_24 = (MR_Float) -1.00000000000000;
#line 891 "trans.m"
        else
#line 891 "trans.m"
          trans__SgnB_24 = (MR_Float) 1.00000000000000;
#line 892 "trans.m"
        trans__V_31_31 = (MR_Float) -0.500000000000000;
#line 892 "trans.m"
        {
#line 892 "trans.m"
          trans__V_34_34 = mercury__math__sqrt_2_f_0(trans__BB4AC_23);
        }
#line 892 "trans.m"
        trans__V_33_33 = (trans__SgnB_24 * trans__V_34_34);
#line 892 "trans.m"
        trans__V_32_32 = (trans__HeadVar__9_9 + trans__V_33_33);
#line 892 "trans.m"
        trans__Q_25 = (trans__V_31_31 * trans__V_32_32);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__solve_quadratic_11_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__8_8 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_44;
            MR_String trans__V_8_45 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_46;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_44 = (MR_Word) trans__V_8_45;
            trans__TypeInfo_9_46 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_46, ((MR_Box) (trans__V_7_44)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__K1_26 = (trans__Q_25 / trans__HeadVar__8_8);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__solve_quadratic_11_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__Q_25 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_50;
            MR_String trans__V_8_51 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_52;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_50 = (MR_Word) trans__V_8_51;
            trans__TypeInfo_9_52 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_52, ((MR_Box) (trans__V_7_50)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__K2_27 = (trans__HeadVar__10_10 / trans__Q_25);
#line 895 "trans.m"
        trans__V_30_30 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 908 "trans.m"
        trans__V_77_77 = (MR_Float) 0.00000000000000;
#line 908 "trans.m"
        trans__succeeded = (trans__K1_26 >= trans__V_77_77);
        if (trans__succeeded)
          {
#line 909 "trans.m"
            trans__V_68_68 = (trans__K1_26 * trans__HeadVar__6_6);
#line 909 "trans.m"
            trans__IY_63 = (trans__HeadVar__3_3 + trans__V_68_68);
#line 910 "trans.m"
            trans__V_76_76 = (MR_Float) 0.00000000000000;
#line 910 "trans.m"
            trans__succeeded = (trans__V_76_76 <= trans__IY_63);
            if (trans__succeeded)
              {
#line 911 "trans.m"
                trans__V_75_75 = (MR_Float) 1.00000000000000;
#line 911 "trans.m"
                trans__succeeded = (trans__IY_63 <= trans__V_75_75);
              }
          }
#line 916 "trans.m"
        if (trans__succeeded)
          {
            MR_Float trans__IX_64;
            MR_Float trans__IZ_65;
            MR_Word trans__V_70_70;
            MR_Float trans__V_71_71;
            MR_Float trans__V_72_72 = (trans__K1_26 * trans__HeadVar__5_5);

#line 913 "trans.m"
            trans__IX_64 = (trans__HeadVar__2_2 + trans__V_72_72);
#line 914 "trans.m"
            trans__V_71_71 = (trans__K1_26 * trans__HeadVar__7_7);
#line 914 "trans.m"
            trans__IZ_65 = (trans__HeadVar__4_4 + trans__V_71_71);
#line 915 "trans.m"
            {
#line 915 "trans.m"
              trans__V_70_70 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 4 * sizeof(MR_Word)), "fi");
#line 915 "trans.m"
              MR_hl_field(MR_mktag(0), trans__V_70_70, 0) = ((MR_Box) (trans__HeadVar__1_1));
#line 915 "trans.m"
              MR_hl_field(MR_mktag(0), trans__V_70_70, 1) = MR_box_float(trans__IX_64);
#line 915 "trans.m"
              MR_hl_field(MR_mktag(0), trans__V_70_70, 2) = MR_box_float(trans__IY_63);
#line 915 "trans.m"
              MR_hl_field(MR_mktag(0), trans__V_70_70, 3) = MR_box_float(trans__IZ_65);
#line 915 "trans.m"
            }
#line 915 "trans.m"
            {
#line 915 "trans.m"
              trans__Intersections0_28 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 915 "trans.m"
              MR_hl_field(MR_mktag(1), trans__Intersections0_28, 0) = ((MR_Box) (trans__V_70_70));
#line 915 "trans.m"
              MR_hl_field(MR_mktag(1), trans__Intersections0_28, 1) = ((MR_Box) (trans__V_30_30));
#line 915 "trans.m"
            }
          }
#line 916 "trans.m"
        else
#line 917 "trans.m"
          trans__Intersections0_28 = trans__V_30_30;
#line 897 "trans.m"
        {
#line 897 "trans.m"
          trans__maybe_add_intersection_10_p_0(trans__K2_27, trans__HeadVar__1_1, trans__HeadVar__2_2, trans__HeadVar__3_3, trans__HeadVar__4_4, trans__HeadVar__5_5, trans__HeadVar__6_6, trans__HeadVar__7_7, trans__Intersections0_28, &trans__HeadVar__11_11);
        }
      }
    return trans__HeadVar__11_11;
  }
#line 881 "trans.m"
}

#line 869 "trans.m"
static MR_Word MR_CALL trans__cone_intersection_8_f_0(
#line 869 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 869 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 869 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 869 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 869 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 869 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 869 "trans.m"
  MR_Float trans__HeadVar__7_7)
#line 869 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__8_8;
    MR_Float trans__A_16;
    MR_Float trans__B_17;
    MR_Float trans__C_18;
    MR_Float trans__V_19_19;
    MR_Float trans__V_20_20;
    MR_Float trans__V_21_21;
    MR_Float trans__V_22_22;
    MR_Float trans__V_26_26;
    MR_Float trans__V_27_27;
    MR_Float trans__V_28_28;
    MR_Float trans__V_29_29;
    MR_Float trans__V_30_30;
    MR_Float trans__V_31_31;
    MR_Float trans__V_32_32;
    MR_Float trans__V_33_33;
    MR_Float trans__V_34_34 = (trans__HeadVar__5_5 * trans__HeadVar__5_5);
    MR_Float trans__V_35_35 = (trans__HeadVar__7_7 * trans__HeadVar__7_7);

#line 875 "trans.m"
    trans__V_32_32 = (trans__V_34_34 + trans__V_35_35);
#line 875 "trans.m"
    trans__V_33_33 = (trans__HeadVar__6_6 * trans__HeadVar__6_6);
#line 875 "trans.m"
    trans__A_16 = (trans__V_32_32 - trans__V_33_33);
#line 876 "trans.m"
    trans__V_26_26 = (MR_Float) 2.00000000000000;
#line 876 "trans.m"
    trans__V_30_30 = (trans__HeadVar__2_2 * trans__HeadVar__5_5);
#line 876 "trans.m"
    trans__V_31_31 = (trans__HeadVar__4_4 * trans__HeadVar__7_7);
#line 876 "trans.m"
    trans__V_28_28 = (trans__V_30_30 + trans__V_31_31);
#line 876 "trans.m"
    trans__V_29_29 = (trans__HeadVar__3_3 * trans__HeadVar__6_6);
#line 876 "trans.m"
    trans__V_27_27 = (trans__V_28_28 - trans__V_29_29);
#line 876 "trans.m"
    trans__B_17 = (trans__V_26_26 * trans__V_27_27);
#line 877 "trans.m"
    trans__V_21_21 = (trans__HeadVar__2_2 * trans__HeadVar__2_2);
#line 877 "trans.m"
    trans__V_22_22 = (trans__HeadVar__4_4 * trans__HeadVar__4_4);
#line 877 "trans.m"
    trans__V_19_19 = (trans__V_21_21 + trans__V_22_22);
#line 877 "trans.m"
    trans__V_20_20 = (trans__HeadVar__3_3 * trans__HeadVar__3_3);
#line 877 "trans.m"
    trans__C_18 = (trans__V_19_19 - trans__V_20_20);
#line 874 "trans.m"
    {
#line 874 "trans.m"
      return trans__HeadVar__8_8 = trans__solve_quadratic_11_f_0(trans__HeadVar__1_1, trans__HeadVar__2_2, trans__HeadVar__3_3, trans__HeadVar__4_4, trans__HeadVar__5_5, trans__HeadVar__6_6, trans__HeadVar__7_7, trans__A_16, trans__B_17, trans__C_18);
    }
    return trans__HeadVar__8_8;
  }
#line 869 "trans.m"
}

#line 857 "trans.m"
static MR_Word MR_CALL trans__cylinder_intersection_8_f_0(
#line 857 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 857 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 857 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 857 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 857 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 857 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 857 "trans.m"
  MR_Float trans__HeadVar__7_7)
#line 857 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__8_8;
    MR_Float trans__A_16;
    MR_Float trans__B_17;
    MR_Float trans__C_18;
    MR_Float trans__V_19_19;
    MR_Float trans__V_20_20;
    MR_Float trans__V_21_21;
    MR_Float trans__V_22_22;
    MR_Float trans__V_25_25;
    MR_Float trans__V_26_26;
    MR_Float trans__V_27_27;
    MR_Float trans__V_28_28;
    MR_Float trans__V_29_29 = (trans__HeadVar__5_5 * trans__HeadVar__5_5);
    MR_Float trans__V_30_30 = (trans__HeadVar__7_7 * trans__HeadVar__7_7);

#line 863 "trans.m"
    trans__A_16 = (trans__V_29_29 + trans__V_30_30);
#line 864 "trans.m"
    trans__V_25_25 = (MR_Float) 2.00000000000000;
#line 864 "trans.m"
    trans__V_27_27 = (trans__HeadVar__2_2 * trans__HeadVar__5_5);
#line 864 "trans.m"
    trans__V_28_28 = (trans__HeadVar__4_4 * trans__HeadVar__7_7);
#line 864 "trans.m"
    trans__V_26_26 = (trans__V_27_27 + trans__V_28_28);
#line 864 "trans.m"
    trans__B_17 = (trans__V_25_25 * trans__V_26_26);
#line 865 "trans.m"
    trans__V_21_21 = (trans__HeadVar__2_2 * trans__HeadVar__2_2);
#line 865 "trans.m"
    trans__V_22_22 = (trans__HeadVar__4_4 * trans__HeadVar__4_4);
#line 865 "trans.m"
    trans__V_19_19 = (trans__V_21_21 + trans__V_22_22);
#line 865 "trans.m"
    trans__V_20_20 = (MR_Float) 1.00000000000000;
#line 865 "trans.m"
    trans__C_18 = (trans__V_19_19 - trans__V_20_20);
#line 862 "trans.m"
    {
#line 862 "trans.m"
      return trans__HeadVar__8_8 = trans__solve_quadratic_11_f_0(trans__HeadVar__1_1, trans__HeadVar__2_2, trans__HeadVar__3_3, trans__HeadVar__4_4, trans__HeadVar__5_5, trans__HeadVar__6_6, trans__HeadVar__7_7, trans__A_16, trans__B_17, trans__C_18);
    }
    return trans__HeadVar__8_8;
  }
#line 857 "trans.m"
}

#line 831 "trans.m"
static MR_Word MR_CALL trans__process_cone_intersections_5_f_0(
#line 831 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 831 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 831 "trans.m"
  MR_Word trans__HeadVar__3_3,
#line 831 "trans.m"
  MR_Word trans__HeadVar__4_4)
#line 831 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__5_5;
    MR_Integer trans__Face_9 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 0)));
    MR_Float trans__IX_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 1)));
    MR_Float trans__IY_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 2)));
    MR_Float trans__IZ_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 3)));
    MR_Float trans__U_14;
    MR_Float trans__V_15;
    MR_Float trans__NX_16;
    MR_Float trans__NY_17;
    MR_Float trans__NZ_18;
    MR_Word trans__POI_19;
    MR_Word trans__TC_20;
    MR_Word trans__N_21;
    MR_Word trans__V_22_22;
    MR_Word trans__V_24_24;
    MR_Word trans__W_61;
    MR_Float trans__M11_66;
    MR_Float trans__M12_67;
    MR_Float trans__M13_68;
    MR_Float trans__M21_70;
    MR_Float trans__M22_71;
    MR_Float trans__M23_72;
    MR_Float trans__M31_74;
    MR_Float trans__M32_75;
    MR_Float trans__M33_76;
    MR_Float trans__V_81_81;
    MR_Float trans__V_82_82;
    MR_Float trans__V_83_83;
    MR_Float trans__V_84_84;
    MR_Float trans__V_85_85;
    MR_Float trans__V_86_86;
    MR_Float trans__V_87_87;
    MR_Float trans__V_88_88;
    MR_Float trans__V_89_89;
    MR_Float trans__V_90_90;
    MR_Float trans__V_91_91;
    MR_Float trans__V_92_92;
    MR_Float trans__V_93_93;
    MR_Float trans__V_94_94;
    MR_Float trans__V_95_95;
#line 294 "trans.m"
    MR_Word trans___M_60;
#line 274 "trans.m"
    MR_Float trans___M14_69;
#line 274 "trans.m"
    MR_Float trans___M24_73;
#line 274 "trans.m"
    MR_Float trans___M34_77;

#line 836 "trans.m"
    trans__succeeded = (trans__Face_9 == (MR_Integer) 0);
#line 843 "trans.m"
    if (trans__succeeded)
      {
        MR_Float trans__V_25_25;
        MR_Float trans__V_26_26;
        MR_Float trans__V_27_27;
        MR_Float trans__V_28_28;
        MR_Float trans__U0_42;
        MR_Float trans__V_45_45;
        MR_Float trans__V_46_46;
        MR_Float trans__V_47_47;
        MR_Float trans__V_48_48;
        MR_Float trans__V_96_96;

#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__process_cone_intersections_5_f_0
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Y;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float ATan2;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	Y = 
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__IX_10
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__IZ_12
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	ATan2 = atan2(Y, X);

#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__V_45_45
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = ATan2;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__process_cone_intersections_5_f_0
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__V_47_47
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__process_cone_intersections_5_f_0
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__V_48_48
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 1000 "trans.m"
        trans__V_46_46 = (trans__V_47_47 + trans__V_48_48);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__process_cone_intersections_5_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__V_46_46 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_57;
            MR_String trans__V_8_58 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_59;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_57 = (MR_Word) trans__V_8_58;
            trans__TypeInfo_9_59 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_59, ((MR_Box) (trans__V_7_57)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__U0_42 = (trans__V_45_45 / trans__V_46_46);
#line 1002 "trans.m"
        trans__V_96_96 = (MR_Float) 0.00000000000000;
#line 1002 "trans.m"
        trans__succeeded = (trans__U0_42 > trans__V_96_96);
#line 1002 "trans.m"
        if (trans__succeeded)
#line 1002 "trans.m"
          trans__U_14 = trans__U0_42;
#line 1002 "trans.m"
        else
          {
            MR_Float trans__V_44_44 = (MR_Float) 1.00000000000000;

#line 1002 "trans.m"
            trans__U_14 = (trans__V_44_44 + trans__U0_42);
          }
#line 841 "trans.m"
        trans__V_15 = trans__IY_11;
#line 842 "trans.m"
        trans__NX_16 = trans__IX_10;
#line 842 "trans.m"
        trans__V_27_27 = (trans__IX_10 * trans__IX_10);
#line 842 "trans.m"
        trans__V_28_28 = (trans__IZ_12 * trans__IZ_12);
#line 842 "trans.m"
        trans__V_26_26 = (trans__V_27_27 + trans__V_28_28);
#line 842 "trans.m"
        {
#line 842 "trans.m"
          trans__V_25_25 = mercury__math__sqrt_2_f_0(trans__V_26_26);
        }
#line 842 "trans.m"
        trans__NY_17 = (((MR_Float) 0.00000000000000) - trans__V_25_25);
#line 842 "trans.m"
        trans__NZ_18 = trans__IZ_12;
      }
#line 843 "trans.m"
    else
#line 845 "trans.m"
      {
#line 843 "trans.m"
        trans__succeeded = (trans__Face_9 == (MR_Integer) 1);
#line 845 "trans.m"
        if (trans__succeeded)
          {
            MR_Float trans__V_31_31;
            MR_Float trans__V_32_32;
            MR_Float trans__V_33_33;
            MR_Float trans__V_34_34;
            MR_Float trans__V_35_35;
            MR_Float trans__V_36_36 = (MR_Float) 0.500000000000000;

#line 844 "trans.m"
            trans__V_34_34 = (trans__V_36_36 * trans__IX_10);
#line 844 "trans.m"
            trans__V_35_35 = (MR_Float) 0.500000000000000;
#line 844 "trans.m"
            trans__U_14 = (trans__V_34_34 + trans__V_35_35);
#line 844 "trans.m"
            trans__V_33_33 = (MR_Float) 0.500000000000000;
#line 844 "trans.m"
            trans__V_31_31 = (trans__V_33_33 * trans__IZ_12);
#line 844 "trans.m"
            trans__V_32_32 = (MR_Float) 0.500000000000000;
#line 844 "trans.m"
            trans__V_15 = (trans__V_31_31 + trans__V_32_32);
#line 844 "trans.m"
            trans__NX_16 = (MR_Float) 0.00000000000000;
#line 844 "trans.m"
            trans__NY_17 = (MR_Float) 1.00000000000000;
#line 844 "trans.m"
            trans__NZ_18 = (MR_Float) 0.00000000000000;
          }
#line 845 "trans.m"
        else
          {
            MR_String trans__V_37_37 = (MR_String) "trans: intersects_cylinder/6: not a face!";
            MR_Word trans__TypeInfo_38_38 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 846 "trans.m"
            {
#line 846 "trans.m"
              mercury__exception__throw_1_p_0(trans__TypeInfo_38_38, ((MR_Box) (trans__V_37_37)));
            }
          }
#line 845 "trans.m"
      }
#line 849 "trans.m"
    {
#line 849 "trans.m"
      trans__V_24_24 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 849 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_24_24, 0) = MR_box_float(trans__IX_10);
#line 849 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_24_24, 1) = MR_box_float(trans__IY_11);
#line 849 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_24_24, 2) = MR_box_float(trans__IZ_12);
#line 849 "trans.m"
    }
#line 849 "trans.m"
    {
#line 849 "trans.m"
      trans__POI_19 = trans__point_to_world_space_3_f_0(trans__HeadVar__2_2, trans__V_24_24);
    }
#line 850 "trans.m"
    {
#line 850 "trans.m"
      trans__TC_20 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "surface_coordinates");
#line 850 "trans.m"
      MR_hl_field(MR_mktag(0), trans__TC_20, 0) = ((MR_Box) (trans__Face_9));
#line 850 "trans.m"
      MR_hl_field(MR_mktag(0), trans__TC_20, 1) = MR_box_float(trans__U_14);
#line 850 "trans.m"
      MR_hl_field(MR_mktag(0), trans__TC_20, 2) = MR_box_float(trans__V_15);
#line 850 "trans.m"
    }
#line 294 "trans.m"
    trans___M_60 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
#line 294 "trans.m"
    trans__W_61 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
#line 274 "trans.m"
    trans__M11_66 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 0)));
#line 274 "trans.m"
    trans__M12_67 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 1)));
#line 274 "trans.m"
    trans__M13_68 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 2)));
#line 274 "trans.m"
    trans___M14_69 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 3)));
#line 274 "trans.m"
    trans__M21_70 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 4)));
#line 274 "trans.m"
    trans__M22_71 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 5)));
#line 274 "trans.m"
    trans__M23_72 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 6)));
#line 274 "trans.m"
    trans___M24_73 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 7)));
#line 274 "trans.m"
    trans__M31_74 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 8)));
#line 274 "trans.m"
    trans__M32_75 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 9)));
#line 274 "trans.m"
    trans__M33_76 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 10)));
#line 274 "trans.m"
    trans___M34_77 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 11)));
#line 280 "trans.m"
    trans__V_86_86 = (trans__M11_66 * trans__NX_16);
#line 280 "trans.m"
    trans__V_87_87 = (trans__M21_70 * trans__NY_17);
#line 280 "trans.m"
    trans__V_84_84 = (trans__V_86_86 + trans__V_87_87);
#line 280 "trans.m"
    trans__V_85_85 = (trans__M31_74 * trans__NZ_18);
#line 280 "trans.m"
    trans__V_81_81 = (trans__V_84_84 + trans__V_85_85);
#line 281 "trans.m"
    trans__V_90_90 = (trans__M12_67 * trans__NX_16);
#line 281 "trans.m"
    trans__V_91_91 = (trans__M22_71 * trans__NY_17);
#line 281 "trans.m"
    trans__V_88_88 = (trans__V_90_90 + trans__V_91_91);
#line 281 "trans.m"
    trans__V_89_89 = (trans__M32_75 * trans__NZ_18);
#line 280 "trans.m"
    trans__V_82_82 = (trans__V_88_88 + trans__V_89_89);
#line 282 "trans.m"
    trans__V_94_94 = (trans__M13_68 * trans__NX_16);
#line 282 "trans.m"
    trans__V_95_95 = (trans__M23_72 * trans__NY_17);
#line 282 "trans.m"
    trans__V_92_92 = (trans__V_94_94 + trans__V_95_95);
#line 282 "trans.m"
    trans__V_93_93 = (trans__M33_76 * trans__NZ_18);
#line 280 "trans.m"
    trans__V_83_83 = (trans__V_92_92 + trans__V_93_93);
#line 280 "trans.m"
    {
#line 280 "trans.m"
      trans__V_22_22 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_22_22, 0) = MR_box_float(trans__V_81_81);
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_22_22, 1) = MR_box_float(trans__V_82_82);
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_22_22, 2) = MR_box_float(trans__V_83_83);
#line 280 "trans.m"
    }
#line 851 "trans.m"
    {
#line 851 "trans.m"
      trans__N_21 = vector__unit_2_f_0(trans__V_22_22);
    }
#line 853 "trans.m"
    {
#line 853 "trans.m"
      trans__HeadVar__5_5 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 5 * sizeof(MR_Word)), "intersection");
#line 853 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 0) = ((MR_Box) (trans__HeadVar__1_1));
#line 853 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 1) = ((MR_Box) (trans__POI_19));
#line 853 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 2) = ((MR_Box) (trans__N_21));
#line 853 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 3) = ((MR_Box) (trans__TC_20));
#line 853 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 4) = ((MR_Box) (trans__HeadVar__3_3));
#line 853 "trans.m"
    }
    return trans__HeadVar__5_5;
  }
#line 831 "trans.m"
}

#line 785 "trans.m"
static MR_Word MR_CALL trans__process_cylinder_intersections_5_f_0(
#line 785 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 785 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 785 "trans.m"
  MR_Word trans__HeadVar__3_3,
#line 785 "trans.m"
  MR_Word trans__HeadVar__4_4)
#line 785 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__5_5;
    MR_Integer trans__Face_9 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 0)));
    MR_Float trans__IX_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 1)));
    MR_Float trans__IY_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 2)));
    MR_Float trans__IZ_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 3)));
    MR_Float trans__U_14;
    MR_Float trans__V_15;
    MR_Float trans__NX_16;
    MR_Float trans__NY_17;
    MR_Float trans__NZ_18;
    MR_Word trans__POI_19;
    MR_Word trans__TC_20;
    MR_Word trans__N_21;
    MR_Word trans__V_22_22;
    MR_Word trans__V_24_24;
    MR_Word trans__W_61;
    MR_Float trans__M11_66;
    MR_Float trans__M12_67;
    MR_Float trans__M13_68;
    MR_Float trans__M21_70;
    MR_Float trans__M22_71;
    MR_Float trans__M23_72;
    MR_Float trans__M31_74;
    MR_Float trans__M32_75;
    MR_Float trans__M33_76;
    MR_Float trans__V_81_81;
    MR_Float trans__V_82_82;
    MR_Float trans__V_83_83;
    MR_Float trans__V_84_84;
    MR_Float trans__V_85_85;
    MR_Float trans__V_86_86;
    MR_Float trans__V_87_87;
    MR_Float trans__V_88_88;
    MR_Float trans__V_89_89;
    MR_Float trans__V_90_90;
    MR_Float trans__V_91_91;
    MR_Float trans__V_92_92;
    MR_Float trans__V_93_93;
    MR_Float trans__V_94_94;
    MR_Float trans__V_95_95;
#line 294 "trans.m"
    MR_Word trans___M_60;
#line 274 "trans.m"
    MR_Float trans___M14_69;
#line 274 "trans.m"
    MR_Float trans___M24_73;
#line 274 "trans.m"
    MR_Float trans___M34_77;

#line 790 "trans.m"
    trans__succeeded = (trans__Face_9 == (MR_Integer) 0);
#line 795 "trans.m"
    if (trans__succeeded)
      {
        MR_Float trans__U0_42;
        MR_Float trans__V_45_45;
        MR_Float trans__V_46_46;
        MR_Float trans__V_47_47;
        MR_Float trans__V_48_48;
        MR_Float trans__V_96_96;

#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__process_cylinder_intersections_5_f_0
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Y;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float ATan2;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	Y = 
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__IX_10
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__IZ_12
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	ATan2 = atan2(Y, X);

#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__V_45_45
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = ATan2;
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 60 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__process_cylinder_intersections_5_f_0
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__V_47_47
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__process_cylinder_intersections_5_f_0
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__V_48_48
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 1000 "trans.m"
        trans__V_46_46 = (trans__V_47_47 + trans__V_48_48);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__process_cylinder_intersections_5_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__V_46_46 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_57;
            MR_String trans__V_8_58 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_59;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_57 = (MR_Word) trans__V_8_58;
            trans__TypeInfo_9_59 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_59, ((MR_Box) (trans__V_7_57)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__U0_42 = (trans__V_45_45 / trans__V_46_46);
#line 1002 "trans.m"
        trans__V_96_96 = (MR_Float) 0.00000000000000;
#line 1002 "trans.m"
        trans__succeeded = (trans__U0_42 > trans__V_96_96);
#line 1002 "trans.m"
        if (trans__succeeded)
#line 1002 "trans.m"
          trans__U_14 = trans__U0_42;
#line 1002 "trans.m"
        else
          {
            MR_Float trans__V_44_44 = (MR_Float) 1.00000000000000;

#line 1002 "trans.m"
            trans__U_14 = (trans__V_44_44 + trans__U0_42);
          }
#line 793 "trans.m"
        trans__V_15 = trans__IY_11;
#line 794 "trans.m"
        trans__NX_16 = trans__IX_10;
#line 794 "trans.m"
        trans__NY_17 = (MR_Float) 0.00000000000000;
#line 794 "trans.m"
        trans__NZ_18 = trans__IZ_12;
      }
#line 795 "trans.m"
    else
#line 797 "trans.m"
      {
#line 795 "trans.m"
        trans__succeeded = (trans__Face_9 == (MR_Integer) 1);
#line 797 "trans.m"
        if (trans__succeeded)
          {
            MR_Float trans__V_25_25;
            MR_Float trans__V_26_26;
            MR_Float trans__V_27_27;
            MR_Float trans__V_28_28;
            MR_Float trans__V_29_29;
            MR_Float trans__V_30_30 = (MR_Float) 0.500000000000000;

#line 796 "trans.m"
            trans__V_28_28 = (trans__V_30_30 * trans__IX_10);
#line 796 "trans.m"
            trans__V_29_29 = (MR_Float) 0.500000000000000;
#line 796 "trans.m"
            trans__U_14 = (trans__V_28_28 + trans__V_29_29);
#line 796 "trans.m"
            trans__V_27_27 = (MR_Float) 0.500000000000000;
#line 796 "trans.m"
            trans__V_25_25 = (trans__V_27_27 * trans__IZ_12);
#line 796 "trans.m"
            trans__V_26_26 = (MR_Float) 0.500000000000000;
#line 796 "trans.m"
            trans__V_15 = (trans__V_25_25 + trans__V_26_26);
#line 796 "trans.m"
            trans__NX_16 = (MR_Float) 0.00000000000000;
#line 796 "trans.m"
            trans__NY_17 = (MR_Float) 1.00000000000000;
#line 796 "trans.m"
            trans__NZ_18 = (MR_Float) 0.00000000000000;
          }
#line 797 "trans.m"
        else
#line 799 "trans.m"
          {
#line 797 "trans.m"
            trans__succeeded = (trans__Face_9 == (MR_Integer) 2);
#line 799 "trans.m"
            if (trans__succeeded)
              {
                MR_Float trans__V_31_31;
                MR_Float trans__V_32_32;
                MR_Float trans__V_33_33;
                MR_Float trans__V_34_34;
                MR_Float trans__V_35_35;
                MR_Float trans__V_36_36 = (MR_Float) 0.500000000000000;

#line 798 "trans.m"
                trans__V_34_34 = (trans__V_36_36 * trans__IX_10);
#line 798 "trans.m"
                trans__V_35_35 = (MR_Float) 0.500000000000000;
#line 798 "trans.m"
                trans__U_14 = (trans__V_34_34 + trans__V_35_35);
#line 798 "trans.m"
                trans__V_33_33 = (MR_Float) 0.500000000000000;
#line 798 "trans.m"
                trans__V_31_31 = (trans__V_33_33 * trans__IZ_12);
#line 798 "trans.m"
                trans__V_32_32 = (MR_Float) 0.500000000000000;
#line 798 "trans.m"
                trans__V_15 = (trans__V_31_31 + trans__V_32_32);
#line 798 "trans.m"
                trans__NX_16 = (MR_Float) 0.00000000000000;
#line 798 "trans.m"
                trans__NY_17 = (MR_Float) -1.00000000000000;
#line 798 "trans.m"
                trans__NZ_18 = (MR_Float) 0.00000000000000;
              }
#line 799 "trans.m"
            else
              {
                MR_String trans__V_37_37 = (MR_String) "trans: intersects_cylinder/6: not a face!";
                MR_Word trans__TypeInfo_38_38 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 800 "trans.m"
                {
#line 800 "trans.m"
                  mercury__exception__throw_1_p_0(trans__TypeInfo_38_38, ((MR_Box) (trans__V_37_37)));
                }
              }
#line 799 "trans.m"
          }
#line 797 "trans.m"
      }
#line 803 "trans.m"
    {
#line 803 "trans.m"
      trans__V_24_24 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 803 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_24_24, 0) = MR_box_float(trans__IX_10);
#line 803 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_24_24, 1) = MR_box_float(trans__IY_11);
#line 803 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_24_24, 2) = MR_box_float(trans__IZ_12);
#line 803 "trans.m"
    }
#line 803 "trans.m"
    {
#line 803 "trans.m"
      trans__POI_19 = trans__point_to_world_space_3_f_0(trans__HeadVar__2_2, trans__V_24_24);
    }
#line 804 "trans.m"
    {
#line 804 "trans.m"
      trans__TC_20 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "surface_coordinates");
#line 804 "trans.m"
      MR_hl_field(MR_mktag(0), trans__TC_20, 0) = ((MR_Box) (trans__Face_9));
#line 804 "trans.m"
      MR_hl_field(MR_mktag(0), trans__TC_20, 1) = MR_box_float(trans__U_14);
#line 804 "trans.m"
      MR_hl_field(MR_mktag(0), trans__TC_20, 2) = MR_box_float(trans__V_15);
#line 804 "trans.m"
    }
#line 294 "trans.m"
    trans___M_60 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
#line 294 "trans.m"
    trans__W_61 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
#line 274 "trans.m"
    trans__M11_66 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 0)));
#line 274 "trans.m"
    trans__M12_67 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 1)));
#line 274 "trans.m"
    trans__M13_68 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 2)));
#line 274 "trans.m"
    trans___M14_69 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 3)));
#line 274 "trans.m"
    trans__M21_70 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 4)));
#line 274 "trans.m"
    trans__M22_71 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 5)));
#line 274 "trans.m"
    trans__M23_72 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 6)));
#line 274 "trans.m"
    trans___M24_73 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 7)));
#line 274 "trans.m"
    trans__M31_74 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 8)));
#line 274 "trans.m"
    trans__M32_75 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 9)));
#line 274 "trans.m"
    trans__M33_76 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 10)));
#line 274 "trans.m"
    trans___M34_77 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_61, (MR_Integer) 11)));
#line 280 "trans.m"
    trans__V_86_86 = (trans__M11_66 * trans__NX_16);
#line 280 "trans.m"
    trans__V_87_87 = (trans__M21_70 * trans__NY_17);
#line 280 "trans.m"
    trans__V_84_84 = (trans__V_86_86 + trans__V_87_87);
#line 280 "trans.m"
    trans__V_85_85 = (trans__M31_74 * trans__NZ_18);
#line 280 "trans.m"
    trans__V_81_81 = (trans__V_84_84 + trans__V_85_85);
#line 281 "trans.m"
    trans__V_90_90 = (trans__M12_67 * trans__NX_16);
#line 281 "trans.m"
    trans__V_91_91 = (trans__M22_71 * trans__NY_17);
#line 281 "trans.m"
    trans__V_88_88 = (trans__V_90_90 + trans__V_91_91);
#line 281 "trans.m"
    trans__V_89_89 = (trans__M32_75 * trans__NZ_18);
#line 280 "trans.m"
    trans__V_82_82 = (trans__V_88_88 + trans__V_89_89);
#line 282 "trans.m"
    trans__V_94_94 = (trans__M13_68 * trans__NX_16);
#line 282 "trans.m"
    trans__V_95_95 = (trans__M23_72 * trans__NY_17);
#line 282 "trans.m"
    trans__V_92_92 = (trans__V_94_94 + trans__V_95_95);
#line 282 "trans.m"
    trans__V_93_93 = (trans__M33_76 * trans__NZ_18);
#line 280 "trans.m"
    trans__V_83_83 = (trans__V_92_92 + trans__V_93_93);
#line 280 "trans.m"
    {
#line 280 "trans.m"
      trans__V_22_22 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_22_22, 0) = MR_box_float(trans__V_81_81);
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_22_22, 1) = MR_box_float(trans__V_82_82);
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_22_22, 2) = MR_box_float(trans__V_83_83);
#line 280 "trans.m"
    }
#line 805 "trans.m"
    {
#line 805 "trans.m"
      trans__N_21 = vector__unit_2_f_0(trans__V_22_22);
    }
#line 807 "trans.m"
    {
#line 807 "trans.m"
      trans__HeadVar__5_5 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 5 * sizeof(MR_Word)), "intersection");
#line 807 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 0) = ((MR_Box) (trans__HeadVar__1_1));
#line 807 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 1) = ((MR_Box) (trans__POI_19));
#line 807 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 2) = ((MR_Box) (trans__N_21));
#line 807 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 3) = ((MR_Box) (trans__TC_20));
#line 807 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 4) = ((MR_Box) (trans__HeadVar__3_3));
#line 807 "trans.m"
    }
    return trans__HeadVar__5_5;
  }
#line 785 "trans.m"
}

#line 725 "trans.m"
static MR_Word MR_CALL trans__y_face_intersection_9_f_0(
#line 725 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 725 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 725 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 725 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 725 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 725 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 725 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 725 "trans.m"
  MR_Float trans__HeadVar__8_8)
#line 725 "trans.m"
{
#line 731 "trans.m"
  {
#line 731 "trans.m"
    bool trans__succeeded = (trans__HeadVar__7_7 == ((MR_Float) 0.00000000000000));
#line 731 "trans.m"
    MR_Word trans__HeadVar__9_9;

#line 731 "trans.m"
    if (trans__succeeded)
#line 730 "trans.m"
      trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 731 "trans.m"
    else
      {
        MR_Float trans__K_19;
        MR_Float trans__V_31_31 = (trans__HeadVar__2_2 - trans__HeadVar__4_4);
        MR_Float trans__V_38_38;

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__y_face_intersection_9_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__7_7 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_35;
            MR_String trans__V_8_36 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_37;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_35 = (MR_Word) trans__V_8_36;
            trans__TypeInfo_9_37 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_37, ((MR_Box) (trans__V_7_35)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__K_19 = (trans__V_31_31 / trans__HeadVar__7_7);
#line 733 "trans.m"
        trans__V_38_38 = (MR_Float) 0.00000000000000;
#line 733 "trans.m"
        trans__succeeded = (trans__K_19 < trans__V_38_38);
#line 735 "trans.m"
        if (trans__succeeded)
#line 734 "trans.m"
          trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 735 "trans.m"
        else
          {
            MR_Float trans__IX_20;
            MR_Float trans__IZ_21;
            MR_Float trans__V_29_29;
            MR_Float trans__V_30_30 = (trans__K_19 * trans__HeadVar__6_6);
            MR_Float trans__V_39_39;
            MR_Float trans__V_40_40;
            MR_Float trans__V_41_41;
            MR_Float trans__V_42_42;

#line 736 "trans.m"
            trans__IX_20 = (trans__HeadVar__3_3 + trans__V_30_30);
#line 737 "trans.m"
            trans__V_29_29 = (trans__K_19 * trans__HeadVar__8_8);
#line 737 "trans.m"
            trans__IZ_21 = (trans__HeadVar__5_5 + trans__V_29_29);
#line 738 "trans.m"
            trans__V_42_42 = (MR_Float) 0.00000000000000;
#line 738 "trans.m"
            trans__succeeded = (trans__V_42_42 <= trans__IZ_21);
            if (trans__succeeded)
              {
#line 738 "trans.m"
                trans__V_41_41 = (MR_Float) 1.00000000000000;
#line 738 "trans.m"
                trans__succeeded = (trans__IZ_21 <= trans__V_41_41);
                if (trans__succeeded)
                  {
#line 738 "trans.m"
                    trans__V_40_40 = (MR_Float) 0.00000000000000;
#line 738 "trans.m"
                    trans__succeeded = (trans__V_40_40 <= trans__IX_20);
                    if (trans__succeeded)
                      {
#line 738 "trans.m"
                        trans__V_39_39 = (MR_Float) 1.00000000000000;
#line 738 "trans.m"
                        trans__succeeded = (trans__IX_20 <= trans__V_39_39);
                      }
                  }
              }
#line 740 "trans.m"
            if (trans__succeeded)
              {
                MR_Word trans__V_27_27;
                MR_Word trans__V_28_28;

#line 739 "trans.m"
                {
#line 739 "trans.m"
                  trans__V_27_27 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 4 * sizeof(MR_Word)), "fi");
#line 739 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_27_27, 0) = ((MR_Box) (trans__HeadVar__1_1));
#line 739 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_27_27, 1) = MR_box_float(trans__IX_20);
#line 739 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_27_27, 2) = MR_box_float(trans__HeadVar__2_2);
#line 739 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_27_27, 3) = MR_box_float(trans__IZ_21);
#line 739 "trans.m"
                }
#line 739 "trans.m"
                trans__V_28_28 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 739 "trans.m"
                {
#line 739 "trans.m"
                  trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 739 "trans.m"
                  MR_hl_field(MR_mktag(1), trans__HeadVar__9_9, 0) = ((MR_Box) (trans__V_27_27));
#line 739 "trans.m"
                  MR_hl_field(MR_mktag(1), trans__HeadVar__9_9, 1) = ((MR_Box) (trans__V_28_28));
#line 739 "trans.m"
                }
              }
#line 740 "trans.m"
            else
#line 741 "trans.m"
              trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
          }
      }
#line 731 "trans.m"
    return trans__HeadVar__9_9;
#line 731 "trans.m"
  }
#line 725 "trans.m"
}

#line 702 "trans.m"
static MR_Word MR_CALL trans__x_face_intersection_9_f_0(
#line 702 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 702 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 702 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 702 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 702 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 702 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 702 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 702 "trans.m"
  MR_Float trans__HeadVar__8_8)
#line 702 "trans.m"
{
#line 708 "trans.m"
  {
#line 708 "trans.m"
    bool trans__succeeded = (trans__HeadVar__6_6 == ((MR_Float) 0.00000000000000));
#line 708 "trans.m"
    MR_Word trans__HeadVar__9_9;

#line 708 "trans.m"
    if (trans__succeeded)
#line 707 "trans.m"
      trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 708 "trans.m"
    else
      {
        MR_Float trans__K_19;
        MR_Float trans__V_31_31 = (trans__HeadVar__2_2 - trans__HeadVar__3_3);
        MR_Float trans__V_38_38;

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__x_face_intersection_9_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__6_6 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_35;
            MR_String trans__V_8_36 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_37;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_35 = (MR_Word) trans__V_8_36;
            trans__TypeInfo_9_37 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_37, ((MR_Box) (trans__V_7_35)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__K_19 = (trans__V_31_31 / trans__HeadVar__6_6);
#line 710 "trans.m"
        trans__V_38_38 = (MR_Float) 0.00000000000000;
#line 710 "trans.m"
        trans__succeeded = (trans__K_19 < trans__V_38_38);
#line 712 "trans.m"
        if (trans__succeeded)
#line 711 "trans.m"
          trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 712 "trans.m"
        else
          {
            MR_Float trans__IY_20;
            MR_Float trans__IZ_21;
            MR_Float trans__V_29_29;
            MR_Float trans__V_30_30 = (trans__K_19 * trans__HeadVar__7_7);
            MR_Float trans__V_39_39;
            MR_Float trans__V_40_40;
            MR_Float trans__V_41_41;
            MR_Float trans__V_42_42;

#line 713 "trans.m"
            trans__IY_20 = (trans__HeadVar__4_4 + trans__V_30_30);
#line 714 "trans.m"
            trans__V_29_29 = (trans__K_19 * trans__HeadVar__8_8);
#line 714 "trans.m"
            trans__IZ_21 = (trans__HeadVar__5_5 + trans__V_29_29);
#line 715 "trans.m"
            trans__V_42_42 = (MR_Float) 0.00000000000000;
#line 715 "trans.m"
            trans__succeeded = (trans__V_42_42 <= trans__IZ_21);
            if (trans__succeeded)
              {
#line 715 "trans.m"
                trans__V_41_41 = (MR_Float) 1.00000000000000;
#line 715 "trans.m"
                trans__succeeded = (trans__IZ_21 <= trans__V_41_41);
                if (trans__succeeded)
                  {
#line 715 "trans.m"
                    trans__V_40_40 = (MR_Float) 0.00000000000000;
#line 715 "trans.m"
                    trans__succeeded = (trans__V_40_40 <= trans__IY_20);
                    if (trans__succeeded)
                      {
#line 715 "trans.m"
                        trans__V_39_39 = (MR_Float) 1.00000000000000;
#line 715 "trans.m"
                        trans__succeeded = (trans__IY_20 <= trans__V_39_39);
                      }
                  }
              }
#line 717 "trans.m"
            if (trans__succeeded)
              {
                MR_Word trans__V_27_27;
                MR_Word trans__V_28_28;

#line 716 "trans.m"
                {
#line 716 "trans.m"
                  trans__V_27_27 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 4 * sizeof(MR_Word)), "fi");
#line 716 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_27_27, 0) = ((MR_Box) (trans__HeadVar__1_1));
#line 716 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_27_27, 1) = MR_box_float(trans__HeadVar__2_2);
#line 716 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_27_27, 2) = MR_box_float(trans__IY_20);
#line 716 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_27_27, 3) = MR_box_float(trans__IZ_21);
#line 716 "trans.m"
                }
#line 716 "trans.m"
                trans__V_28_28 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 716 "trans.m"
                {
#line 716 "trans.m"
                  trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 716 "trans.m"
                  MR_hl_field(MR_mktag(1), trans__HeadVar__9_9, 0) = ((MR_Box) (trans__V_27_27));
#line 716 "trans.m"
                  MR_hl_field(MR_mktag(1), trans__HeadVar__9_9, 1) = ((MR_Box) (trans__V_28_28));
#line 716 "trans.m"
                }
              }
#line 717 "trans.m"
            else
#line 718 "trans.m"
              trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
          }
      }
#line 708 "trans.m"
    return trans__HeadVar__9_9;
#line 708 "trans.m"
  }
#line 702 "trans.m"
}

#line 679 "trans.m"
static MR_Word MR_CALL trans__z_face_intersection_9_f_0(
#line 679 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 679 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 679 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 679 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 679 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 679 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 679 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 679 "trans.m"
  MR_Float trans__HeadVar__8_8)
#line 679 "trans.m"
{
#line 685 "trans.m"
  {
#line 685 "trans.m"
    bool trans__succeeded = (trans__HeadVar__8_8 == ((MR_Float) 0.00000000000000));
#line 685 "trans.m"
    MR_Word trans__HeadVar__9_9;

#line 685 "trans.m"
    if (trans__succeeded)
#line 684 "trans.m"
      trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 685 "trans.m"
    else
      {
        MR_Float trans__K_19;
        MR_Float trans__V_31_31 = (trans__HeadVar__2_2 - trans__HeadVar__5_5);
        MR_Float trans__V_38_38;

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__z_face_intersection_9_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__8_8 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_35;
            MR_String trans__V_8_36 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_37;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_35 = (MR_Word) trans__V_8_36;
            trans__TypeInfo_9_37 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_37, ((MR_Box) (trans__V_7_35)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__K_19 = (trans__V_31_31 / trans__HeadVar__8_8);
#line 687 "trans.m"
        trans__V_38_38 = (MR_Float) 0.00000000000000;
#line 687 "trans.m"
        trans__succeeded = (trans__K_19 < trans__V_38_38);
#line 689 "trans.m"
        if (trans__succeeded)
#line 688 "trans.m"
          trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 689 "trans.m"
        else
          {
            MR_Float trans__IX_20;
            MR_Float trans__IY_21;
            MR_Float trans__V_29_29;
            MR_Float trans__V_30_30 = (trans__K_19 * trans__HeadVar__6_6);
            MR_Float trans__V_39_39;
            MR_Float trans__V_40_40;
            MR_Float trans__V_41_41;
            MR_Float trans__V_42_42;

#line 690 "trans.m"
            trans__IX_20 = (trans__HeadVar__3_3 + trans__V_30_30);
#line 691 "trans.m"
            trans__V_29_29 = (trans__K_19 * trans__HeadVar__7_7);
#line 691 "trans.m"
            trans__IY_21 = (trans__HeadVar__4_4 + trans__V_29_29);
#line 692 "trans.m"
            trans__V_42_42 = (MR_Float) 0.00000000000000;
#line 692 "trans.m"
            trans__succeeded = (trans__V_42_42 <= trans__IX_20);
            if (trans__succeeded)
              {
#line 692 "trans.m"
                trans__V_41_41 = (MR_Float) 1.00000000000000;
#line 692 "trans.m"
                trans__succeeded = (trans__IX_20 <= trans__V_41_41);
                if (trans__succeeded)
                  {
#line 692 "trans.m"
                    trans__V_40_40 = (MR_Float) 0.00000000000000;
#line 692 "trans.m"
                    trans__succeeded = (trans__V_40_40 <= trans__IY_21);
                    if (trans__succeeded)
                      {
#line 692 "trans.m"
                        trans__V_39_39 = (MR_Float) 1.00000000000000;
#line 692 "trans.m"
                        trans__succeeded = (trans__IY_21 <= trans__V_39_39);
                      }
                  }
              }
#line 694 "trans.m"
            if (trans__succeeded)
              {
                MR_Word trans__V_27_27;
                MR_Word trans__V_28_28;

#line 693 "trans.m"
                {
#line 693 "trans.m"
                  trans__V_27_27 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 4 * sizeof(MR_Word)), "fi");
#line 693 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_27_27, 0) = ((MR_Box) (trans__HeadVar__1_1));
#line 693 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_27_27, 1) = MR_box_float(trans__IX_20);
#line 693 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_27_27, 2) = MR_box_float(trans__IY_21);
#line 693 "trans.m"
                  MR_hl_field(MR_mktag(0), trans__V_27_27, 3) = MR_box_float(trans__HeadVar__2_2);
#line 693 "trans.m"
                }
#line 693 "trans.m"
                trans__V_28_28 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 693 "trans.m"
                {
#line 693 "trans.m"
                  trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 693 "trans.m"
                  MR_hl_field(MR_mktag(1), trans__HeadVar__9_9, 0) = ((MR_Box) (trans__V_27_27));
#line 693 "trans.m"
                  MR_hl_field(MR_mktag(1), trans__HeadVar__9_9, 1) = ((MR_Box) (trans__V_28_28));
#line 693 "trans.m"
                }
              }
#line 694 "trans.m"
            else
#line 695 "trans.m"
              trans__HeadVar__9_9 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
          }
      }
#line 685 "trans.m"
    return trans__HeadVar__9_9;
#line 685 "trans.m"
  }
#line 679 "trans.m"
}

#line 654 "trans.m"
static MR_Word MR_CALL trans__process_cube_intersections_5_f_0(
#line 654 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 654 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 654 "trans.m"
  MR_Word trans__HeadVar__3_3,
#line 654 "trans.m"
  MR_Word trans__HeadVar__4_4)
#line 654 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__5_5;
    MR_Integer trans__Face_9 = ((MR_Integer) (MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 0)));
    MR_Float trans__IX_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 1)));
    MR_Float trans__IY_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 2)));
    MR_Float trans__IZ_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 3)));
    MR_Float trans__U_14;
    MR_Float trans__V_15;
    MR_Float trans__NX_16;
    MR_Float trans__NY_17;
    MR_Float trans__NZ_18;
    MR_Word trans__POI_19;
    MR_Word trans__TC_20;
    MR_Word trans__N_21;
    MR_Word trans__V_22_22;
    MR_Word trans__V_23_23;
    MR_Word trans__M_27;
    MR_Float trans__M11_33;
    MR_Float trans__M12_34;
    MR_Float trans__M13_35;
    MR_Float trans__M14_36;
    MR_Float trans__M21_37;
    MR_Float trans__M22_38;
    MR_Float trans__M23_39;
    MR_Float trans__M24_40;
    MR_Float trans__M31_41;
    MR_Float trans__M32_42;
    MR_Float trans__M33_43;
    MR_Float trans__M34_44;
    MR_Float trans__V_48_48;
    MR_Float trans__V_49_49;
    MR_Float trans__V_50_50;
    MR_Float trans__V_51_51;
    MR_Float trans__V_52_52;
    MR_Float trans__V_53_53;
    MR_Float trans__V_54_54;
    MR_Float trans__V_55_55;
    MR_Float trans__V_56_56;
    MR_Float trans__V_57_57;
    MR_Float trans__V_58_58;
    MR_Float trans__V_59_59;
    MR_Float trans__V_60_60;
    MR_Float trans__V_61_61;
    MR_Float trans__V_62_62;
    MR_Float trans__V_63_63;
    MR_Float trans__V_64_64;
    MR_Float trans__V_65_65;
#line 292 "trans.m"
    MR_Word trans___W_28;

#line 659 "trans.m"
    trans__succeeded = (trans__Face_9 == (MR_Integer) 0);
#line 660 "trans.m"
    if (trans__succeeded)
      {
#line 659 "trans.m"
        trans__U_14 = trans__IX_10;
#line 659 "trans.m"
        trans__V_15 = trans__IY_11;
#line 659 "trans.m"
        trans__NX_16 = (MR_Float) 0.00000000000000;
#line 659 "trans.m"
        trans__NY_17 = (MR_Float) 0.00000000000000;
#line 659 "trans.m"
        trans__NZ_18 = (MR_Float) -1.00000000000000;
      }
#line 660 "trans.m"
    else
#line 661 "trans.m"
      {
#line 660 "trans.m"
        trans__succeeded = (trans__Face_9 == (MR_Integer) 1);
#line 661 "trans.m"
        if (trans__succeeded)
          {
#line 660 "trans.m"
            trans__U_14 = trans__IX_10;
#line 660 "trans.m"
            trans__V_15 = trans__IY_11;
#line 660 "trans.m"
            trans__NX_16 = (MR_Float) 0.00000000000000;
#line 660 "trans.m"
            trans__NY_17 = (MR_Float) 0.00000000000000;
#line 660 "trans.m"
            trans__NZ_18 = (MR_Float) 1.00000000000000;
          }
#line 661 "trans.m"
        else
#line 662 "trans.m"
          {
#line 661 "trans.m"
            trans__succeeded = (trans__Face_9 == (MR_Integer) 2);
#line 662 "trans.m"
            if (trans__succeeded)
              {
#line 661 "trans.m"
                trans__U_14 = trans__IZ_12;
#line 661 "trans.m"
                trans__V_15 = trans__IY_11;
#line 661 "trans.m"
                trans__NX_16 = (MR_Float) -1.00000000000000;
#line 661 "trans.m"
                trans__NY_17 = (MR_Float) 0.00000000000000;
#line 661 "trans.m"
                trans__NZ_18 = (MR_Float) 0.00000000000000;
              }
#line 662 "trans.m"
            else
#line 663 "trans.m"
              {
#line 662 "trans.m"
                trans__succeeded = (trans__Face_9 == (MR_Integer) 3);
#line 663 "trans.m"
                if (trans__succeeded)
                  {
#line 662 "trans.m"
                    trans__U_14 = trans__IZ_12;
#line 662 "trans.m"
                    trans__V_15 = trans__IY_11;
#line 662 "trans.m"
                    trans__NX_16 = (MR_Float) 1.00000000000000;
#line 662 "trans.m"
                    trans__NY_17 = (MR_Float) 0.00000000000000;
#line 662 "trans.m"
                    trans__NZ_18 = (MR_Float) 0.00000000000000;
                  }
#line 663 "trans.m"
                else
#line 664 "trans.m"
                  {
#line 663 "trans.m"
                    trans__succeeded = (trans__Face_9 == (MR_Integer) 4);
#line 664 "trans.m"
                    if (trans__succeeded)
                      {
#line 663 "trans.m"
                        trans__U_14 = trans__IX_10;
#line 663 "trans.m"
                        trans__V_15 = trans__IZ_12;
#line 663 "trans.m"
                        trans__NX_16 = (MR_Float) 0.00000000000000;
#line 663 "trans.m"
                        trans__NY_17 = (MR_Float) 1.00000000000000;
#line 663 "trans.m"
                        trans__NZ_18 = (MR_Float) 0.00000000000000;
                      }
#line 664 "trans.m"
                    else
#line 665 "trans.m"
                      {
#line 664 "trans.m"
                        trans__succeeded = (trans__Face_9 == (MR_Integer) 5);
#line 665 "trans.m"
                        if (trans__succeeded)
                          {
#line 664 "trans.m"
                            trans__U_14 = trans__IX_10;
#line 664 "trans.m"
                            trans__V_15 = trans__IZ_12;
#line 664 "trans.m"
                            trans__NX_16 = (MR_Float) 0.00000000000000;
#line 664 "trans.m"
                            trans__NY_17 = (MR_Float) -1.00000000000000;
#line 664 "trans.m"
                            trans__NZ_18 = (MR_Float) 0.00000000000000;
                          }
#line 665 "trans.m"
                        else
                          {
                            MR_String trans__V_25_25 = (MR_String) "trans: intersects_cube/6: not a face!";
                            MR_Word trans__TypeInfo_26_26 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 665 "trans.m"
                            {
#line 665 "trans.m"
                              mercury__exception__throw_1_p_0(trans__TypeInfo_26_26, ((MR_Box) (trans__V_25_25)));
                            }
                          }
#line 665 "trans.m"
                      }
#line 664 "trans.m"
                  }
#line 663 "trans.m"
              }
#line 662 "trans.m"
          }
#line 661 "trans.m"
      }
#line 292 "trans.m"
    trans__M_27 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
#line 292 "trans.m"
    trans___W_28 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
#line 244 "trans.m"
    trans__M11_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_27, (MR_Integer) 0)));
#line 244 "trans.m"
    trans__M12_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_27, (MR_Integer) 1)));
#line 244 "trans.m"
    trans__M13_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_27, (MR_Integer) 2)));
#line 244 "trans.m"
    trans__M14_36 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_27, (MR_Integer) 3)));
#line 244 "trans.m"
    trans__M21_37 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_27, (MR_Integer) 4)));
#line 244 "trans.m"
    trans__M22_38 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_27, (MR_Integer) 5)));
#line 244 "trans.m"
    trans__M23_39 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_27, (MR_Integer) 6)));
#line 244 "trans.m"
    trans__M24_40 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_27, (MR_Integer) 7)));
#line 244 "trans.m"
    trans__M31_41 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_27, (MR_Integer) 8)));
#line 244 "trans.m"
    trans__M32_42 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_27, (MR_Integer) 9)));
#line 244 "trans.m"
    trans__M33_43 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_27, (MR_Integer) 10)));
#line 244 "trans.m"
    trans__M34_44 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_27, (MR_Integer) 11)));
#line 250 "trans.m"
    trans__V_54_54 = (trans__M11_33 * trans__IX_10);
#line 250 "trans.m"
    trans__V_55_55 = (trans__M12_34 * trans__IY_11);
#line 250 "trans.m"
    trans__V_52_52 = (trans__V_54_54 + trans__V_55_55);
#line 250 "trans.m"
    trans__V_53_53 = (trans__M13_35 * trans__IZ_12);
#line 250 "trans.m"
    trans__V_51_51 = (trans__V_52_52 + trans__V_53_53);
#line 250 "trans.m"
    trans__V_48_48 = (trans__V_51_51 + trans__M14_36);
#line 251 "trans.m"
    trans__V_59_59 = (trans__M21_37 * trans__IX_10);
#line 251 "trans.m"
    trans__V_60_60 = (trans__M22_38 * trans__IY_11);
#line 251 "trans.m"
    trans__V_57_57 = (trans__V_59_59 + trans__V_60_60);
#line 251 "trans.m"
    trans__V_58_58 = (trans__M23_39 * trans__IZ_12);
#line 251 "trans.m"
    trans__V_56_56 = (trans__V_57_57 + trans__V_58_58);
#line 250 "trans.m"
    trans__V_49_49 = (trans__V_56_56 + trans__M24_40);
#line 252 "trans.m"
    trans__V_64_64 = (trans__M31_41 * trans__IX_10);
#line 252 "trans.m"
    trans__V_65_65 = (trans__M32_42 * trans__IY_11);
#line 252 "trans.m"
    trans__V_62_62 = (trans__V_64_64 + trans__V_65_65);
#line 252 "trans.m"
    trans__V_63_63 = (trans__M33_43 * trans__IZ_12);
#line 252 "trans.m"
    trans__V_61_61 = (trans__V_62_62 + trans__V_63_63);
#line 250 "trans.m"
    trans__V_50_50 = (trans__V_61_61 + trans__M34_44);
#line 250 "trans.m"
    {
#line 250 "trans.m"
      trans__POI_19 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__POI_19, 0) = MR_box_float(trans__V_48_48);
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__POI_19, 1) = MR_box_float(trans__V_49_49);
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__POI_19, 2) = MR_box_float(trans__V_50_50);
#line 250 "trans.m"
    }
#line 669 "trans.m"
    {
#line 669 "trans.m"
      trans__TC_20 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "surface_coordinates");
#line 669 "trans.m"
      MR_hl_field(MR_mktag(0), trans__TC_20, 0) = ((MR_Box) (trans__Face_9));
#line 669 "trans.m"
      MR_hl_field(MR_mktag(0), trans__TC_20, 1) = MR_box_float(trans__U_14);
#line 669 "trans.m"
      MR_hl_field(MR_mktag(0), trans__TC_20, 2) = MR_box_float(trans__V_15);
#line 669 "trans.m"
    }
#line 670 "trans.m"
    {
#line 670 "trans.m"
      trans__V_23_23 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 670 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_23_23, 0) = MR_box_float(trans__NX_16);
#line 670 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_23_23, 1) = MR_box_float(trans__NY_17);
#line 670 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_23_23, 2) = MR_box_float(trans__NZ_18);
#line 670 "trans.m"
    }
#line 670 "trans.m"
    {
#line 670 "trans.m"
      trans__V_22_22 = trans__normal_to_world_space_3_f_0(trans__HeadVar__2_2, trans__V_23_23);
    }
#line 670 "trans.m"
    {
#line 670 "trans.m"
      trans__N_21 = vector__unit_2_f_0(trans__V_22_22);
    }
#line 672 "trans.m"
    {
#line 672 "trans.m"
      trans__HeadVar__5_5 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 5 * sizeof(MR_Word)), "intersection");
#line 672 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 0) = ((MR_Box) (trans__HeadVar__1_1));
#line 672 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 1) = ((MR_Box) (trans__POI_19));
#line 672 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 2) = ((MR_Box) (trans__N_21));
#line 672 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 3) = ((MR_Box) (trans__TC_20));
#line 672 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 4) = ((MR_Box) (trans__HeadVar__3_3));
#line 672 "trans.m"
    }
    return trans__HeadVar__5_5;
  }
#line 654 "trans.m"
}

#line 574 "trans.m"
static void MR_CALL trans__intersects_sphere_2_11_p_0(
#line 574 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 574 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 574 "trans.m"
  MR_Word trans__HeadVar__3_3,
#line 574 "trans.m"
  MR_Float trans__HeadVar__4_4,
#line 574 "trans.m"
  MR_Float trans__HeadVar__5_5,
#line 574 "trans.m"
  MR_Float trans__HeadVar__6_6,
#line 574 "trans.m"
  MR_Float trans__HeadVar__7_7,
#line 574 "trans.m"
  MR_Float trans__HeadVar__8_8,
#line 574 "trans.m"
  MR_Float trans__HeadVar__9_9,
#line 574 "trans.m"
  MR_Word trans__HeadVar__10_10,
#line 574 "trans.m"
  MR_Word * trans__HeadVar__11_11)
#line 574 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Float trans__IX_23;
    MR_Float trans__IY_24;
    MR_Float trans__IZ_25;
    MR_Word trans__POI_26;
    MR_Float trans__V_27;
    MR_Float trans__U_28;
    MR_Word trans__TC_29;
    MR_Word trans__N_30;
    MR_Word trans__V_31_31;
    MR_Integer trans__V_33_33;
    MR_Float trans__V_34_34;
    MR_Float trans__V_35_35;
    MR_Float trans__V_36_36;
    MR_Word trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40 = (trans__HeadVar__2_2 * trans__HeadVar__7_7);
    MR_Word trans__M_41;
    MR_Float trans__M11_47;
    MR_Float trans__M12_48;
    MR_Float trans__M13_49;
    MR_Float trans__M14_50;
    MR_Float trans__M21_51;
    MR_Float trans__M22_52;
    MR_Float trans__M23_53;
    MR_Float trans__M24_54;
    MR_Float trans__M31_55;
    MR_Float trans__M32_56;
    MR_Float trans__M33_57;
    MR_Float trans__M34_58;
    MR_Float trans__V_62_62;
    MR_Float trans__V_63_63;
    MR_Float trans__V_64_64;
    MR_Float trans__V_65_65;
    MR_Float trans__V_66_66;
    MR_Float trans__V_67_67;
    MR_Float trans__V_68_68;
    MR_Float trans__V_69_69;
    MR_Float trans__V_70_70;
    MR_Float trans__V_71_71;
    MR_Float trans__V_72_72;
    MR_Float trans__V_73_73;
    MR_Float trans__V_74_74;
    MR_Float trans__V_75_75;
    MR_Float trans__V_76_76;
    MR_Float trans__V_77_77;
    MR_Float trans__V_78_78;
    MR_Float trans__V_79_79;
#line 292 "trans.m"
    MR_Word trans___W_42;

#line 578 "trans.m"
    trans__IX_23 = (trans__HeadVar__4_4 + trans__V_40_40);
#line 579 "trans.m"
    trans__V_39_39 = (trans__HeadVar__2_2 * trans__HeadVar__8_8);
#line 579 "trans.m"
    trans__IY_24 = (trans__HeadVar__5_5 + trans__V_39_39);
#line 580 "trans.m"
    trans__V_38_38 = (trans__HeadVar__2_2 * trans__HeadVar__9_9);
#line 580 "trans.m"
    trans__IZ_25 = (trans__HeadVar__6_6 + trans__V_38_38);
#line 582 "trans.m"
    {
#line 582 "trans.m"
      trans__V_37_37 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 582 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_37_37, 0) = MR_box_float(trans__IX_23);
#line 582 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_37_37, 1) = MR_box_float(trans__IY_24);
#line 582 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_37_37, 2) = MR_box_float(trans__IZ_25);
#line 582 "trans.m"
    }
#line 292 "trans.m"
    trans__M_41 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 0)));
#line 292 "trans.m"
    trans___W_42 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 1)));
#line 244 "trans.m"
    trans__M11_47 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_41, (MR_Integer) 0)));
#line 244 "trans.m"
    trans__M12_48 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_41, (MR_Integer) 1)));
#line 244 "trans.m"
    trans__M13_49 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_41, (MR_Integer) 2)));
#line 244 "trans.m"
    trans__M14_50 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_41, (MR_Integer) 3)));
#line 244 "trans.m"
    trans__M21_51 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_41, (MR_Integer) 4)));
#line 244 "trans.m"
    trans__M22_52 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_41, (MR_Integer) 5)));
#line 244 "trans.m"
    trans__M23_53 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_41, (MR_Integer) 6)));
#line 244 "trans.m"
    trans__M24_54 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_41, (MR_Integer) 7)));
#line 244 "trans.m"
    trans__M31_55 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_41, (MR_Integer) 8)));
#line 244 "trans.m"
    trans__M32_56 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_41, (MR_Integer) 9)));
#line 244 "trans.m"
    trans__M33_57 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_41, (MR_Integer) 10)));
#line 244 "trans.m"
    trans__M34_58 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_41, (MR_Integer) 11)));
#line 250 "trans.m"
    trans__V_68_68 = (trans__M11_47 * trans__IX_23);
#line 250 "trans.m"
    trans__V_69_69 = (trans__M12_48 * trans__IY_24);
#line 250 "trans.m"
    trans__V_66_66 = (trans__V_68_68 + trans__V_69_69);
#line 250 "trans.m"
    trans__V_67_67 = (trans__M13_49 * trans__IZ_25);
#line 250 "trans.m"
    trans__V_65_65 = (trans__V_66_66 + trans__V_67_67);
#line 250 "trans.m"
    trans__V_62_62 = (trans__V_65_65 + trans__M14_50);
#line 251 "trans.m"
    trans__V_73_73 = (trans__M21_51 * trans__IX_23);
#line 251 "trans.m"
    trans__V_74_74 = (trans__M22_52 * trans__IY_24);
#line 251 "trans.m"
    trans__V_71_71 = (trans__V_73_73 + trans__V_74_74);
#line 251 "trans.m"
    trans__V_72_72 = (trans__M23_53 * trans__IZ_25);
#line 251 "trans.m"
    trans__V_70_70 = (trans__V_71_71 + trans__V_72_72);
#line 250 "trans.m"
    trans__V_63_63 = (trans__V_70_70 + trans__M24_54);
#line 252 "trans.m"
    trans__V_78_78 = (trans__M31_55 * trans__IX_23);
#line 252 "trans.m"
    trans__V_79_79 = (trans__M32_56 * trans__IY_24);
#line 252 "trans.m"
    trans__V_76_76 = (trans__V_78_78 + trans__V_79_79);
#line 252 "trans.m"
    trans__V_77_77 = (trans__M33_57 * trans__IZ_25);
#line 252 "trans.m"
    trans__V_75_75 = (trans__V_76_76 + trans__V_77_77);
#line 250 "trans.m"
    trans__V_64_64 = (trans__V_75_75 + trans__M34_58);
#line 250 "trans.m"
    {
#line 250 "trans.m"
      trans__POI_26 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__POI_26, 0) = MR_box_float(trans__V_62_62);
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__POI_26, 1) = MR_box_float(trans__V_63_63);
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__POI_26, 2) = MR_box_float(trans__V_64_64);
#line 250 "trans.m"
    }
#line 584 "trans.m"
    trans__V_34_34 = (MR_Float) 0.500000000000000;
#line 584 "trans.m"
    trans__V_36_36 = (MR_Float) 1.00000000000000;
#line 584 "trans.m"
    trans__V_35_35 = (trans__IY_24 + trans__V_36_36);
#line 584 "trans.m"
    trans__V_27 = (trans__V_34_34 * trans__V_35_35);
#line 587 "trans.m"
    {
#line 587 "trans.m"
      trans__U_28 = trans__calc_u_3_f_0(trans__IX_23, trans__IZ_25);
    }
#line 589 "trans.m"
    trans__V_33_33 = (MR_Integer) 0;
#line 589 "trans.m"
    {
#line 589 "trans.m"
      trans__TC_29 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "surface_coordinates");
#line 589 "trans.m"
      MR_hl_field(MR_mktag(0), trans__TC_29, 0) = ((MR_Box) (trans__V_33_33));
#line 589 "trans.m"
      MR_hl_field(MR_mktag(0), trans__TC_29, 1) = MR_box_float(trans__U_28);
#line 589 "trans.m"
      MR_hl_field(MR_mktag(0), trans__TC_29, 2) = MR_box_float(trans__V_27);
#line 589 "trans.m"
    }
#line 595 "trans.m"
    {
#line 595 "trans.m"
      trans__V_31_31 = trans__normal_to_world_space_3_f_0(trans__HeadVar__3_3, trans__V_37_37);
    }
#line 595 "trans.m"
    {
#line 595 "trans.m"
      trans__N_30 = vector__unit_2_f_0(trans__V_31_31);
    }
#line 597 "trans.m"
    {
#line 597 "trans.m"
      *trans__HeadVar__11_11 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 5 * sizeof(MR_Word)), "intersection");
#line 597 "trans.m"
      MR_hl_field(MR_mktag(0), *trans__HeadVar__11_11, 0) = ((MR_Box) (trans__HeadVar__1_1));
#line 597 "trans.m"
      MR_hl_field(MR_mktag(0), *trans__HeadVar__11_11, 1) = ((MR_Box) (trans__POI_26));
#line 597 "trans.m"
      MR_hl_field(MR_mktag(0), *trans__HeadVar__11_11, 2) = ((MR_Box) (trans__N_30));
#line 597 "trans.m"
      MR_hl_field(MR_mktag(0), *trans__HeadVar__11_11, 3) = ((MR_Box) (trans__TC_29));
#line 597 "trans.m"
      MR_hl_field(MR_mktag(0), *trans__HeadVar__11_11, 4) = ((MR_Box) (trans__HeadVar__10_10));
#line 597 "trans.m"
    }
  }
#line 574 "trans.m"
}

#line 236 "trans.m"
MR_Word MR_CALL trans__transform_normal_3_f_0(
#line 236 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 236 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 236 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__3_3;
    MR_Float trans__M11_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__M12_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__M13_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float trans__M21_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 4)));
    MR_Float trans__M22_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 5)));
    MR_Float trans__M23_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 6)));
    MR_Float trans__M31_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 8)));
    MR_Float trans__M32_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 9)));
    MR_Float trans__M33_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 10)));
    MR_Float trans__X_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__Y_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__Z_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float trans__V_22_22;
    MR_Float trans__V_23_23;
    MR_Float trans__V_24_24;
    MR_Float trans__V_25_25;
    MR_Float trans__V_26_26;
    MR_Float trans__V_27_27 = (trans__M11_7 * trans__X_19);
    MR_Float trans__V_28_28 = (trans__M21_11 * trans__Y_20);
    MR_Float trans__V_29_29;
    MR_Float trans__V_30_30;
    MR_Float trans__V_31_31;
    MR_Float trans__V_32_32;
    MR_Float trans__V_33_33;
    MR_Float trans__V_34_34;
    MR_Float trans__V_35_35;
    MR_Float trans__V_36_36;
#line 274 "trans.m"
    MR_Float trans___M14_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 3)));
#line 274 "trans.m"
    MR_Float trans___M24_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 7)));
#line 274 "trans.m"
    MR_Float trans___M34_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 11)));

#line 280 "trans.m"
    trans__V_25_25 = (trans__V_27_27 + trans__V_28_28);
#line 280 "trans.m"
    trans__V_26_26 = (trans__M31_15 * trans__Z_21);
#line 280 "trans.m"
    trans__V_22_22 = (trans__V_25_25 + trans__V_26_26);
#line 281 "trans.m"
    trans__V_31_31 = (trans__M12_8 * trans__X_19);
#line 281 "trans.m"
    trans__V_32_32 = (trans__M22_12 * trans__Y_20);
#line 281 "trans.m"
    trans__V_29_29 = (trans__V_31_31 + trans__V_32_32);
#line 281 "trans.m"
    trans__V_30_30 = (trans__M32_16 * trans__Z_21);
#line 280 "trans.m"
    trans__V_23_23 = (trans__V_29_29 + trans__V_30_30);
#line 282 "trans.m"
    trans__V_35_35 = (trans__M13_9 * trans__X_19);
#line 282 "trans.m"
    trans__V_36_36 = (trans__M23_13 * trans__Y_20);
#line 282 "trans.m"
    trans__V_33_33 = (trans__V_35_35 + trans__V_36_36);
#line 282 "trans.m"
    trans__V_34_34 = (trans__M33_17 * trans__Z_21);
#line 280 "trans.m"
    trans__V_24_24 = (trans__V_33_33 + trans__V_34_34);
#line 280 "trans.m"
    {
#line 280 "trans.m"
      trans__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 0) = MR_box_float(trans__V_22_22);
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 1) = MR_box_float(trans__V_23_23);
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 2) = MR_box_float(trans__V_24_24);
#line 280 "trans.m"
    }
    return trans__HeadVar__3_3;
  }
#line 236 "trans.m"
}

#line 235 "trans.m"
MR_Word MR_CALL trans__transform_vector_3_f_0(
#line 235 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 235 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 235 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__3_3;
    MR_Float trans__M11_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__M12_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__M13_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float trans__M21_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 4)));
    MR_Float trans__M22_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 5)));
    MR_Float trans__M23_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 6)));
    MR_Float trans__M31_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 8)));
    MR_Float trans__M32_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 9)));
    MR_Float trans__M33_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 10)));
    MR_Float trans__X_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__Y_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__Z_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float trans__V_22_22;
    MR_Float trans__V_23_23;
    MR_Float trans__V_24_24;
    MR_Float trans__V_25_25;
    MR_Float trans__V_26_26;
    MR_Float trans__V_27_27 = (trans__M11_7 * trans__X_19);
    MR_Float trans__V_28_28 = (trans__M12_8 * trans__Y_20);
    MR_Float trans__V_29_29;
    MR_Float trans__V_30_30;
    MR_Float trans__V_31_31;
    MR_Float trans__V_32_32;
    MR_Float trans__V_33_33;
    MR_Float trans__V_34_34;
    MR_Float trans__V_35_35;
    MR_Float trans__V_36_36;
#line 258 "trans.m"
    MR_Float trans___M14_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 3)));
#line 258 "trans.m"
    MR_Float trans___M24_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 7)));
#line 258 "trans.m"
    MR_Float trans___M34_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 11)));

#line 264 "trans.m"
    trans__V_25_25 = (trans__V_27_27 + trans__V_28_28);
#line 264 "trans.m"
    trans__V_26_26 = (trans__M13_9 * trans__Z_21);
#line 264 "trans.m"
    trans__V_22_22 = (trans__V_25_25 + trans__V_26_26);
#line 265 "trans.m"
    trans__V_31_31 = (trans__M21_11 * trans__X_19);
#line 265 "trans.m"
    trans__V_32_32 = (trans__M22_12 * trans__Y_20);
#line 265 "trans.m"
    trans__V_29_29 = (trans__V_31_31 + trans__V_32_32);
#line 265 "trans.m"
    trans__V_30_30 = (trans__M23_13 * trans__Z_21);
#line 264 "trans.m"
    trans__V_23_23 = (trans__V_29_29 + trans__V_30_30);
#line 266 "trans.m"
    trans__V_35_35 = (trans__M31_15 * trans__X_19);
#line 266 "trans.m"
    trans__V_36_36 = (trans__M32_16 * trans__Y_20);
#line 266 "trans.m"
    trans__V_33_33 = (trans__V_35_35 + trans__V_36_36);
#line 266 "trans.m"
    trans__V_34_34 = (trans__M33_17 * trans__Z_21);
#line 264 "trans.m"
    trans__V_24_24 = (trans__V_33_33 + trans__V_34_34);
#line 264 "trans.m"
    {
#line 264 "trans.m"
      trans__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 264 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 0) = MR_box_float(trans__V_22_22);
#line 264 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 1) = MR_box_float(trans__V_23_23);
#line 264 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 2) = MR_box_float(trans__V_24_24);
#line 264 "trans.m"
    }
    return trans__HeadVar__3_3;
  }
#line 235 "trans.m"
}

#line 234 "trans.m"
MR_Word MR_CALL trans__transform_point_3_f_0(
#line 234 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 234 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 234 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__3_3;
    MR_Float trans__M11_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__M12_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__M13_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float trans__M14_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 3)));
    MR_Float trans__M21_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 4)));
    MR_Float trans__M22_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 5)));
    MR_Float trans__M23_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 6)));
    MR_Float trans__M24_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 7)));
    MR_Float trans__M31_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 8)));
    MR_Float trans__M32_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 9)));
    MR_Float trans__M33_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 10)));
    MR_Float trans__M34_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 11)));
    MR_Float trans__X_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__Y_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__Z_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float trans__V_22_22;
    MR_Float trans__V_23_23;
    MR_Float trans__V_24_24;
    MR_Float trans__V_25_25;
    MR_Float trans__V_26_26;
    MR_Float trans__V_27_27;
    MR_Float trans__V_28_28 = (trans__M11_7 * trans__X_19);
    MR_Float trans__V_29_29 = (trans__M12_8 * trans__Y_20);
    MR_Float trans__V_30_30;
    MR_Float trans__V_31_31;
    MR_Float trans__V_32_32;
    MR_Float trans__V_33_33;
    MR_Float trans__V_34_34;
    MR_Float trans__V_35_35;
    MR_Float trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;

#line 250 "trans.m"
    trans__V_26_26 = (trans__V_28_28 + trans__V_29_29);
#line 250 "trans.m"
    trans__V_27_27 = (trans__M13_9 * trans__Z_21);
#line 250 "trans.m"
    trans__V_25_25 = (trans__V_26_26 + trans__V_27_27);
#line 250 "trans.m"
    trans__V_22_22 = (trans__V_25_25 + trans__M14_10);
#line 251 "trans.m"
    trans__V_33_33 = (trans__M21_11 * trans__X_19);
#line 251 "trans.m"
    trans__V_34_34 = (trans__M22_12 * trans__Y_20);
#line 251 "trans.m"
    trans__V_31_31 = (trans__V_33_33 + trans__V_34_34);
#line 251 "trans.m"
    trans__V_32_32 = (trans__M23_13 * trans__Z_21);
#line 251 "trans.m"
    trans__V_30_30 = (trans__V_31_31 + trans__V_32_32);
#line 250 "trans.m"
    trans__V_23_23 = (trans__V_30_30 + trans__M24_14);
#line 252 "trans.m"
    trans__V_38_38 = (trans__M31_15 * trans__X_19);
#line 252 "trans.m"
    trans__V_39_39 = (trans__M32_16 * trans__Y_20);
#line 252 "trans.m"
    trans__V_36_36 = (trans__V_38_38 + trans__V_39_39);
#line 252 "trans.m"
    trans__V_37_37 = (trans__M33_17 * trans__Z_21);
#line 252 "trans.m"
    trans__V_35_35 = (trans__V_36_36 + trans__V_37_37);
#line 250 "trans.m"
    trans__V_24_24 = (trans__V_35_35 + trans__M34_18);
#line 250 "trans.m"
    {
#line 250 "trans.m"
      trans__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 0) = MR_box_float(trans__V_22_22);
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 1) = MR_box_float(trans__V_23_23);
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 2) = MR_box_float(trans__V_24_24);
#line 250 "trans.m"
    }
    return trans__HeadVar__3_3;
  }
#line 234 "trans.m"
}
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_1 = (MR_Float) 1.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_2 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_3 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_4 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_5 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_6 = (MR_Float) 1.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_7 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_8 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_9 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_10 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_11 = (MR_Float) 1.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_24_0_12 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Box trans__const_24_0_13_HeadVar__1_1[12] = {
		(MR_Box) &trans__float_24_0_1,
		(MR_Box) &trans__float_24_0_2,
		(MR_Box) &trans__float_24_0_3,
		(MR_Box) &trans__float_24_0_4,
		(MR_Box) &trans__float_24_0_5,
		(MR_Box) &trans__float_24_0_6,
		(MR_Box) &trans__float_24_0_7,
		(MR_Box) &trans__float_24_0_8,
		(MR_Box) &trans__float_24_0_9,
		(MR_Box) &trans__float_24_0_10,
		(MR_Box) &trans__float_24_0_11,
		(MR_Box) &trans__float_24_0_12};

#line 232 "trans.m"
MR_Word MR_CALL trans__unit_matrix_1_f_0(void)
#line 232 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__1_1 = (MR_Word) &trans__const_24_0_13_HeadVar__1_1;
    MR_Float trans__V_2_2 = (MR_Float) 1.00000000000000;
    MR_Float trans__V_3_3 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_4_4 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_5_5 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_6_6 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_7_7 = (MR_Float) 1.00000000000000;
    MR_Float trans__V_8_8 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_9_9 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_10_10 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_11_11 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_12_12 = (MR_Float) 1.00000000000000;
    MR_Float trans__V_13_13 = (MR_Float) 0.00000000000000;

    return trans__HeadVar__1_1;
  }
#line 232 "trans.m"
}

#line 194 "trans.m"
void MR_CALL trans__show_trans_3_p_0(
#line 194 "trans.m"
  MR_Word trans__HeadVar__1_1)
#line 194 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__M_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Word trans__W_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__M11_6 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 0)));
    MR_Float trans__M12_7 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 1)));
    MR_Float trans__M13_8 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 2)));
    MR_Float trans__M14_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 3)));
    MR_Float trans__M21_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 4)));
    MR_Float trans__M22_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 5)));
    MR_Float trans__M23_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 6)));
    MR_Float trans__M24_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 7)));
    MR_Float trans__M31_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 8)));
    MR_Float trans__M32_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 9)));
    MR_Float trans__M33_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 10)));
    MR_Float trans__M34_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 11)));
    MR_Float trans__W11_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 0)));
    MR_Float trans__W12_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 1)));
    MR_Float trans__W13_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 2)));
    MR_Float trans__W14_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 3)));
    MR_Float trans__W21_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 4)));
    MR_Float trans__W22_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 5)));
    MR_Float trans__W23_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 6)));
    MR_Float trans__W24_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 7)));
    MR_Float trans__W31_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 8)));
    MR_Float trans__W32_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 9)));
    MR_Float trans__W33_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 10)));
    MR_Float trans__W34_29 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 11)));
    MR_String trans__V_39_39;
    MR_Word trans__V_40_40;
    MR_String trans__V_41_41;
    MR_Word trans__V_42_42;
    MR_Word trans__V_43_43;
    MR_Word trans__V_44_44;
    MR_Word trans__V_45_45;
    MR_Word trans__V_46_46;
    MR_Word trans__V_47_47;
    MR_Word trans__V_48_48;
    MR_Word trans__V_49_49;
    MR_Word trans__V_50_50;
    MR_String trans__V_51_51;
    MR_Word trans__V_52_52;
    MR_Word trans__V_53_53;
    MR_Word trans__V_54_54;
    MR_Word trans__V_55_55;
    MR_Word trans__V_56_56;
    MR_Word trans__V_57_57;
    MR_Word trans__V_58_58;
    MR_Word trans__V_59_59;
    MR_Word trans__V_60_60;
    MR_String trans__V_61_61;
    MR_Word trans__V_62_62;
    MR_Word trans__V_63_63;
    MR_Word trans__V_64_64;
    MR_Word trans__V_65_65;
    MR_Word trans__V_66_66;
    MR_Word trans__V_67_67;
    MR_Word trans__V_68_68;
    MR_Word trans__V_69_69;
    MR_Word trans__V_70_70;
    MR_String trans__V_71_71;
    MR_Word trans__V_72_72;
    MR_Word trans__V_73_73;
    MR_Word trans__V_74_74;
    MR_Word trans__V_75_75;
    MR_Word trans__V_76_76;
    MR_Word trans__V_77_77;
    MR_Word trans__V_78_78;
    MR_Word trans__V_79_79;
    MR_Word trans__V_80_80;
    MR_String trans__V_81_81;
    MR_Word trans__V_82_82;
    MR_Word trans__V_83_83;
    MR_Word trans__V_84_84;
    MR_Word trans__V_85_85;
    MR_Word trans__V_86_86;
    MR_Word trans__V_87_87;
    MR_Word trans__V_88_88;
    MR_Word trans__V_89_89;
    MR_Word trans__V_90_90;
    MR_String trans__V_91_91;
    MR_Word trans__V_92_92;
    MR_Word trans__V_93_93;
    MR_Word trans__V_94_94;
    MR_Word trans__V_95_95;
    MR_Word trans__V_96_96;
    MR_Word trans__V_97_97;
    MR_Word trans__V_98_98;
    MR_Word trans__V_99_99;
    MR_Word trans__V_100_100;
    MR_String trans__V_101_101 = (MR_String) "object -> world space    world -> object space\n";
    MR_Word trans__V_102_102 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));

#line 448 "trans.m"
    {
#line 448 "trans.m"
      mercury__io__format_4_p_0(trans__V_101_101, trans__V_102_102);
    }
#line 449 "trans.m"
    trans__V_91_91 = (MR_String) "(%4.1f %4.1f %4.1f %4.1f)    ";
#line 449 "trans.m"
    {
#line 449 "trans.m"
      trans__V_93_93 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 449 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_93_93, 0) = MR_box_float(trans__M11_6);
#line 449 "trans.m"
    }
#line 449 "trans.m"
    {
#line 449 "trans.m"
      trans__V_95_95 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 449 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_95_95, 0) = MR_box_float(trans__M12_7);
#line 449 "trans.m"
    }
#line 449 "trans.m"
    {
#line 449 "trans.m"
      trans__V_97_97 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 449 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_97_97, 0) = MR_box_float(trans__M13_8);
#line 449 "trans.m"
    }
#line 449 "trans.m"
    {
#line 449 "trans.m"
      trans__V_99_99 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 449 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_99_99, 0) = MR_box_float(trans__M14_9);
#line 449 "trans.m"
    }
#line 449 "trans.m"
    trans__V_100_100 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 449 "trans.m"
    {
#line 449 "trans.m"
      trans__V_98_98 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 449 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_98_98, 0) = ((MR_Box) (trans__V_99_99));
#line 449 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_98_98, 1) = ((MR_Box) (trans__V_100_100));
#line 449 "trans.m"
    }
#line 449 "trans.m"
    {
#line 449 "trans.m"
      trans__V_96_96 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 449 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_96_96, 0) = ((MR_Box) (trans__V_97_97));
#line 449 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_96_96, 1) = ((MR_Box) (trans__V_98_98));
#line 449 "trans.m"
    }
#line 449 "trans.m"
    {
#line 449 "trans.m"
      trans__V_94_94 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 449 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_94_94, 0) = ((MR_Box) (trans__V_95_95));
#line 449 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_94_94, 1) = ((MR_Box) (trans__V_96_96));
#line 449 "trans.m"
    }
#line 449 "trans.m"
    {
#line 449 "trans.m"
      trans__V_92_92 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 449 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_92_92, 0) = ((MR_Box) (trans__V_93_93));
#line 449 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_92_92, 1) = ((MR_Box) (trans__V_94_94));
#line 449 "trans.m"
    }
#line 449 "trans.m"
    {
#line 449 "trans.m"
      mercury__io__format_4_p_0(trans__V_91_91, trans__V_92_92);
    }
#line 450 "trans.m"
    trans__V_81_81 = (MR_String) "(%4.1f %4.1f %4.1f %4.1f)\n";
#line 450 "trans.m"
    {
#line 450 "trans.m"
      trans__V_83_83 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 450 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_83_83, 0) = MR_box_float(trans__W11_18);
#line 450 "trans.m"
    }
#line 450 "trans.m"
    {
#line 450 "trans.m"
      trans__V_85_85 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 450 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_85_85, 0) = MR_box_float(trans__W12_19);
#line 450 "trans.m"
    }
#line 450 "trans.m"
    {
#line 450 "trans.m"
      trans__V_87_87 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 450 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_87_87, 0) = MR_box_float(trans__W13_20);
#line 450 "trans.m"
    }
#line 450 "trans.m"
    {
#line 450 "trans.m"
      trans__V_89_89 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 450 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_89_89, 0) = MR_box_float(trans__W14_21);
#line 450 "trans.m"
    }
#line 450 "trans.m"
    trans__V_90_90 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 450 "trans.m"
    {
#line 450 "trans.m"
      trans__V_88_88 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 450 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_88_88, 0) = ((MR_Box) (trans__V_89_89));
#line 450 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_88_88, 1) = ((MR_Box) (trans__V_90_90));
#line 450 "trans.m"
    }
#line 450 "trans.m"
    {
#line 450 "trans.m"
      trans__V_86_86 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 450 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_86_86, 0) = ((MR_Box) (trans__V_87_87));
#line 450 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_86_86, 1) = ((MR_Box) (trans__V_88_88));
#line 450 "trans.m"
    }
#line 450 "trans.m"
    {
#line 450 "trans.m"
      trans__V_84_84 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 450 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_84_84, 0) = ((MR_Box) (trans__V_85_85));
#line 450 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_84_84, 1) = ((MR_Box) (trans__V_86_86));
#line 450 "trans.m"
    }
#line 450 "trans.m"
    {
#line 450 "trans.m"
      trans__V_82_82 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 450 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_82_82, 0) = ((MR_Box) (trans__V_83_83));
#line 450 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_82_82, 1) = ((MR_Box) (trans__V_84_84));
#line 450 "trans.m"
    }
#line 450 "trans.m"
    {
#line 450 "trans.m"
      mercury__io__format_4_p_0(trans__V_81_81, trans__V_82_82);
    }
#line 451 "trans.m"
    trans__V_71_71 = (MR_String) "(%4.1f %4.1f %4.1f %4.1f)    ";
#line 451 "trans.m"
    {
#line 451 "trans.m"
      trans__V_73_73 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 451 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_73_73, 0) = MR_box_float(trans__M21_10);
#line 451 "trans.m"
    }
#line 451 "trans.m"
    {
#line 451 "trans.m"
      trans__V_75_75 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 451 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_75_75, 0) = MR_box_float(trans__M22_11);
#line 451 "trans.m"
    }
#line 451 "trans.m"
    {
#line 451 "trans.m"
      trans__V_77_77 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 451 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_77_77, 0) = MR_box_float(trans__M23_12);
#line 451 "trans.m"
    }
#line 451 "trans.m"
    {
#line 451 "trans.m"
      trans__V_79_79 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 451 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_79_79, 0) = MR_box_float(trans__M24_13);
#line 451 "trans.m"
    }
#line 451 "trans.m"
    trans__V_80_80 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 451 "trans.m"
    {
#line 451 "trans.m"
      trans__V_78_78 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 451 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_78_78, 0) = ((MR_Box) (trans__V_79_79));
#line 451 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_78_78, 1) = ((MR_Box) (trans__V_80_80));
#line 451 "trans.m"
    }
#line 451 "trans.m"
    {
#line 451 "trans.m"
      trans__V_76_76 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 451 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_76_76, 0) = ((MR_Box) (trans__V_77_77));
#line 451 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_76_76, 1) = ((MR_Box) (trans__V_78_78));
#line 451 "trans.m"
    }
#line 451 "trans.m"
    {
#line 451 "trans.m"
      trans__V_74_74 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 451 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_74_74, 0) = ((MR_Box) (trans__V_75_75));
#line 451 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_74_74, 1) = ((MR_Box) (trans__V_76_76));
#line 451 "trans.m"
    }
#line 451 "trans.m"
    {
#line 451 "trans.m"
      trans__V_72_72 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 451 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_72_72, 0) = ((MR_Box) (trans__V_73_73));
#line 451 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_72_72, 1) = ((MR_Box) (trans__V_74_74));
#line 451 "trans.m"
    }
#line 451 "trans.m"
    {
#line 451 "trans.m"
      mercury__io__format_4_p_0(trans__V_71_71, trans__V_72_72);
    }
#line 452 "trans.m"
    trans__V_61_61 = (MR_String) "(%4.1f %4.1f %4.1f %4.1f)\n";
#line 452 "trans.m"
    {
#line 452 "trans.m"
      trans__V_63_63 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 452 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_63_63, 0) = MR_box_float(trans__W21_22);
#line 452 "trans.m"
    }
#line 452 "trans.m"
    {
#line 452 "trans.m"
      trans__V_65_65 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 452 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_65_65, 0) = MR_box_float(trans__W22_23);
#line 452 "trans.m"
    }
#line 452 "trans.m"
    {
#line 452 "trans.m"
      trans__V_67_67 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 452 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_67_67, 0) = MR_box_float(trans__W23_24);
#line 452 "trans.m"
    }
#line 452 "trans.m"
    {
#line 452 "trans.m"
      trans__V_69_69 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 452 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_69_69, 0) = MR_box_float(trans__W24_25);
#line 452 "trans.m"
    }
#line 452 "trans.m"
    trans__V_70_70 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 452 "trans.m"
    {
#line 452 "trans.m"
      trans__V_68_68 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 452 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_68_68, 0) = ((MR_Box) (trans__V_69_69));
#line 452 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_68_68, 1) = ((MR_Box) (trans__V_70_70));
#line 452 "trans.m"
    }
#line 452 "trans.m"
    {
#line 452 "trans.m"
      trans__V_66_66 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 452 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_66_66, 0) = ((MR_Box) (trans__V_67_67));
#line 452 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_66_66, 1) = ((MR_Box) (trans__V_68_68));
#line 452 "trans.m"
    }
#line 452 "trans.m"
    {
#line 452 "trans.m"
      trans__V_64_64 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 452 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_64_64, 0) = ((MR_Box) (trans__V_65_65));
#line 452 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_64_64, 1) = ((MR_Box) (trans__V_66_66));
#line 452 "trans.m"
    }
#line 452 "trans.m"
    {
#line 452 "trans.m"
      trans__V_62_62 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 452 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_62_62, 0) = ((MR_Box) (trans__V_63_63));
#line 452 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_62_62, 1) = ((MR_Box) (trans__V_64_64));
#line 452 "trans.m"
    }
#line 452 "trans.m"
    {
#line 452 "trans.m"
      mercury__io__format_4_p_0(trans__V_61_61, trans__V_62_62);
    }
#line 453 "trans.m"
    trans__V_51_51 = (MR_String) "(%4.1f %4.1f %4.1f %4.1f)    ";
#line 453 "trans.m"
    {
#line 453 "trans.m"
      trans__V_53_53 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 453 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_53_53, 0) = MR_box_float(trans__M31_14);
#line 453 "trans.m"
    }
#line 453 "trans.m"
    {
#line 453 "trans.m"
      trans__V_55_55 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 453 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_55_55, 0) = MR_box_float(trans__M32_15);
#line 453 "trans.m"
    }
#line 453 "trans.m"
    {
#line 453 "trans.m"
      trans__V_57_57 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 453 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_57_57, 0) = MR_box_float(trans__M33_16);
#line 453 "trans.m"
    }
#line 453 "trans.m"
    {
#line 453 "trans.m"
      trans__V_59_59 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 453 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_59_59, 0) = MR_box_float(trans__M34_17);
#line 453 "trans.m"
    }
#line 453 "trans.m"
    trans__V_60_60 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 453 "trans.m"
    {
#line 453 "trans.m"
      trans__V_58_58 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 453 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_58_58, 0) = ((MR_Box) (trans__V_59_59));
#line 453 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_58_58, 1) = ((MR_Box) (trans__V_60_60));
#line 453 "trans.m"
    }
#line 453 "trans.m"
    {
#line 453 "trans.m"
      trans__V_56_56 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 453 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_56_56, 0) = ((MR_Box) (trans__V_57_57));
#line 453 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_56_56, 1) = ((MR_Box) (trans__V_58_58));
#line 453 "trans.m"
    }
#line 453 "trans.m"
    {
#line 453 "trans.m"
      trans__V_54_54 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 453 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_54_54, 0) = ((MR_Box) (trans__V_55_55));
#line 453 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_54_54, 1) = ((MR_Box) (trans__V_56_56));
#line 453 "trans.m"
    }
#line 453 "trans.m"
    {
#line 453 "trans.m"
      trans__V_52_52 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 453 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_52_52, 0) = ((MR_Box) (trans__V_53_53));
#line 453 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_52_52, 1) = ((MR_Box) (trans__V_54_54));
#line 453 "trans.m"
    }
#line 453 "trans.m"
    {
#line 453 "trans.m"
      mercury__io__format_4_p_0(trans__V_51_51, trans__V_52_52);
    }
#line 454 "trans.m"
    trans__V_41_41 = (MR_String) "(%4.1f %4.1f %4.1f %4.1f)\n";
#line 454 "trans.m"
    {
#line 454 "trans.m"
      trans__V_43_43 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 454 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_43_43, 0) = MR_box_float(trans__W31_26);
#line 454 "trans.m"
    }
#line 454 "trans.m"
    {
#line 454 "trans.m"
      trans__V_45_45 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 454 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_45_45, 0) = MR_box_float(trans__W32_27);
#line 454 "trans.m"
    }
#line 454 "trans.m"
    {
#line 454 "trans.m"
      trans__V_47_47 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 454 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_47_47, 0) = MR_box_float(trans__W33_28);
#line 454 "trans.m"
    }
#line 454 "trans.m"
    {
#line 454 "trans.m"
      trans__V_49_49 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 1 * sizeof(MR_Word)), "f");
#line 454 "trans.m"
      MR_hl_field(MR_mktag(0), trans__V_49_49, 0) = MR_box_float(trans__W34_29);
#line 454 "trans.m"
    }
#line 454 "trans.m"
    trans__V_50_50 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 454 "trans.m"
    {
#line 454 "trans.m"
      trans__V_48_48 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 454 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_48_48, 0) = ((MR_Box) (trans__V_49_49));
#line 454 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_48_48, 1) = ((MR_Box) (trans__V_50_50));
#line 454 "trans.m"
    }
#line 454 "trans.m"
    {
#line 454 "trans.m"
      trans__V_46_46 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 454 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_46_46, 0) = ((MR_Box) (trans__V_47_47));
#line 454 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_46_46, 1) = ((MR_Box) (trans__V_48_48));
#line 454 "trans.m"
    }
#line 454 "trans.m"
    {
#line 454 "trans.m"
      trans__V_44_44 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 454 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_44_44, 0) = ((MR_Box) (trans__V_45_45));
#line 454 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_44_44, 1) = ((MR_Box) (trans__V_46_46));
#line 454 "trans.m"
    }
#line 454 "trans.m"
    {
#line 454 "trans.m"
      trans__V_42_42 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 454 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_42_42, 0) = ((MR_Box) (trans__V_43_43));
#line 454 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_42_42, 1) = ((MR_Box) (trans__V_44_44));
#line 454 "trans.m"
    }
#line 454 "trans.m"
    {
#line 454 "trans.m"
      mercury__io__format_4_p_0(trans__V_41_41, trans__V_42_42);
    }
#line 455 "trans.m"
    trans__V_39_39 = (MR_String) "( 0.0  0.0  0.0  1.0)    ( 0.0  0.0  0.0  1.0)\n";
#line 455 "trans.m"
    trans__V_40_40 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 455 "trans.m"
    {
#line 455 "trans.m"
      mercury__io__format_4_p_0(trans__V_39_39, trans__V_40_40);
#line 455 "trans.m"
      return;
    }
  }
#line 194 "trans.m"
}

#line 187 "trans.m"
bool MR_CALL trans__inside_cone_2_p_0(
#line 187 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 187 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 187 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Float trans__V_8_8;
    MR_Float trans__V_10_10;
    MR_Float trans__V_11_11;
    MR_Float trans__V_12_12;
    MR_Float trans__V_13_13;
    MR_Word trans__W_21 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__M11_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_21, (MR_Integer) 0)));
    MR_Float trans__M12_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_21, (MR_Integer) 1)));
    MR_Float trans__M13_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_21, (MR_Integer) 2)));
    MR_Float trans__M14_29 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_21, (MR_Integer) 3)));
    MR_Float trans__M21_30 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_21, (MR_Integer) 4)));
    MR_Float trans__M22_31 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_21, (MR_Integer) 5)));
    MR_Float trans__M23_32 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_21, (MR_Integer) 6)));
    MR_Float trans__M24_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_21, (MR_Integer) 7)));
    MR_Float trans__M31_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_21, (MR_Integer) 8)));
    MR_Float trans__M32_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_21, (MR_Integer) 9)));
    MR_Float trans__M33_36 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_21, (MR_Integer) 10)));
    MR_Float trans__M34_37 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_21, (MR_Integer) 11)));
    MR_Float trans__X_38 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__Y_39 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__Z_40 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float trans__V_41_41;
    MR_Float trans__V_42_42;
    MR_Float trans__V_43_43;
    MR_Float trans__V_44_44;
    MR_Float trans__V_45_45;
    MR_Float trans__V_46_46;
    MR_Float trans__V_47_47 = (trans__M11_26 * trans__X_38);
    MR_Float trans__V_48_48 = (trans__M12_27 * trans__Y_39);
    MR_Float trans__V_49_49;
    MR_Float trans__V_50_50;
    MR_Float trans__V_51_51;
    MR_Float trans__V_52_52;
    MR_Float trans__V_53_53;
    MR_Float trans__V_54_54;
    MR_Float trans__V_55_55;
    MR_Float trans__V_56_56;
    MR_Float trans__V_57_57;
    MR_Float trans__V_58_58;
    MR_Float trans__V_59_59;
    MR_Float trans__V_60_60;
    MR_Float trans__V_61_61;
#line 286 "trans.m"
    MR_Word trans___M_20 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));

#line 250 "trans.m"
    trans__V_45_45 = (trans__V_47_47 + trans__V_48_48);
#line 250 "trans.m"
    trans__V_46_46 = (trans__M13_28 * trans__Z_40);
#line 250 "trans.m"
    trans__V_44_44 = (trans__V_45_45 + trans__V_46_46);
#line 250 "trans.m"
    trans__V_41_41 = (trans__V_44_44 + trans__M14_29);
#line 251 "trans.m"
    trans__V_52_52 = (trans__M21_30 * trans__X_38);
#line 251 "trans.m"
    trans__V_53_53 = (trans__M22_31 * trans__Y_39);
#line 251 "trans.m"
    trans__V_50_50 = (trans__V_52_52 + trans__V_53_53);
#line 251 "trans.m"
    trans__V_51_51 = (trans__M23_32 * trans__Z_40);
#line 251 "trans.m"
    trans__V_49_49 = (trans__V_50_50 + trans__V_51_51);
#line 250 "trans.m"
    trans__V_42_42 = (trans__V_49_49 + trans__M24_33);
#line 978 "trans.m"
    trans__V_61_61 = (MR_Float) 0.00000000000000;
#line 978 "trans.m"
    trans__succeeded = (trans__V_42_42 >= trans__V_61_61);
    if (trans__succeeded)
      {
#line 979 "trans.m"
        trans__V_60_60 = (MR_Float) 1.00000000000000;
#line 979 "trans.m"
        trans__succeeded = (trans__V_42_42 <= trans__V_60_60);
        if (trans__succeeded)
          {
#line 252 "trans.m"
            trans__V_57_57 = (trans__M31_34 * trans__X_38);
#line 252 "trans.m"
            trans__V_58_58 = (trans__M32_35 * trans__Y_39);
#line 252 "trans.m"
            trans__V_55_55 = (trans__V_57_57 + trans__V_58_58);
#line 252 "trans.m"
            trans__V_56_56 = (trans__M33_36 * trans__Z_40);
#line 252 "trans.m"
            trans__V_54_54 = (trans__V_55_55 + trans__V_56_56);
#line 250 "trans.m"
            trans__V_43_43 = (trans__V_54_54 + trans__M34_37);
#line 980 "trans.m"
            trans__V_12_12 = (trans__V_41_41 * trans__V_41_41);
#line 980 "trans.m"
            trans__V_13_13 = (trans__V_43_43 * trans__V_43_43);
#line 980 "trans.m"
            trans__V_10_10 = (trans__V_12_12 + trans__V_13_13);
#line 980 "trans.m"
            trans__V_11_11 = (trans__V_42_42 * trans__V_42_42);
#line 980 "trans.m"
            trans__V_8_8 = (trans__V_10_10 - trans__V_11_11);
#line 980 "trans.m"
            trans__V_59_59 = (MR_Float) 0.00000000000000;
#line 980 "trans.m"
            trans__succeeded = (trans__V_8_8 <= trans__V_59_59);
          }
      }
    return trans__succeeded;
  }
#line 187 "trans.m"
}

#line 184 "trans.m"
bool MR_CALL trans__inside_cylinder_2_p_0(
#line 184 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 184 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 184 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Float trans__V_8_8;
    MR_Float trans__V_10_10;
    MR_Float trans__V_11_11;
    MR_Word trans__W_18 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__M11_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_18, (MR_Integer) 0)));
    MR_Float trans__M12_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_18, (MR_Integer) 1)));
    MR_Float trans__M13_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_18, (MR_Integer) 2)));
    MR_Float trans__M14_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_18, (MR_Integer) 3)));
    MR_Float trans__M21_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_18, (MR_Integer) 4)));
    MR_Float trans__M22_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_18, (MR_Integer) 5)));
    MR_Float trans__M23_29 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_18, (MR_Integer) 6)));
    MR_Float trans__M24_30 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_18, (MR_Integer) 7)));
    MR_Float trans__M31_31 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_18, (MR_Integer) 8)));
    MR_Float trans__M32_32 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_18, (MR_Integer) 9)));
    MR_Float trans__M33_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_18, (MR_Integer) 10)));
    MR_Float trans__M34_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_18, (MR_Integer) 11)));
    MR_Float trans__X_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__Y_36 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__Z_37 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40;
    MR_Float trans__V_41_41;
    MR_Float trans__V_42_42;
    MR_Float trans__V_43_43;
    MR_Float trans__V_44_44 = (trans__M11_23 * trans__X_35);
    MR_Float trans__V_45_45 = (trans__M12_24 * trans__Y_36);
    MR_Float trans__V_46_46;
    MR_Float trans__V_47_47;
    MR_Float trans__V_48_48;
    MR_Float trans__V_49_49;
    MR_Float trans__V_50_50;
    MR_Float trans__V_51_51;
    MR_Float trans__V_52_52;
    MR_Float trans__V_53_53;
    MR_Float trans__V_54_54;
    MR_Float trans__V_55_55;
    MR_Float trans__V_56_56;
    MR_Float trans__V_57_57;
    MR_Float trans__V_58_58;
#line 286 "trans.m"
    MR_Word trans___M_17 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));

#line 250 "trans.m"
    trans__V_42_42 = (trans__V_44_44 + trans__V_45_45);
#line 250 "trans.m"
    trans__V_43_43 = (trans__M13_25 * trans__Z_37);
#line 250 "trans.m"
    trans__V_41_41 = (trans__V_42_42 + trans__V_43_43);
#line 250 "trans.m"
    trans__V_38_38 = (trans__V_41_41 + trans__M14_26);
#line 251 "trans.m"
    trans__V_49_49 = (trans__M21_27 * trans__X_35);
#line 251 "trans.m"
    trans__V_50_50 = (trans__M22_28 * trans__Y_36);
#line 251 "trans.m"
    trans__V_47_47 = (trans__V_49_49 + trans__V_50_50);
#line 251 "trans.m"
    trans__V_48_48 = (trans__M23_29 * trans__Z_37);
#line 251 "trans.m"
    trans__V_46_46 = (trans__V_47_47 + trans__V_48_48);
#line 250 "trans.m"
    trans__V_39_39 = (trans__V_46_46 + trans__M24_30);
#line 970 "trans.m"
    trans__V_58_58 = (MR_Float) 0.00000000000000;
#line 970 "trans.m"
    trans__succeeded = (trans__V_39_39 >= trans__V_58_58);
    if (trans__succeeded)
      {
#line 971 "trans.m"
        trans__V_57_57 = (MR_Float) 1.00000000000000;
#line 971 "trans.m"
        trans__succeeded = (trans__V_39_39 <= trans__V_57_57);
        if (trans__succeeded)
          {
#line 252 "trans.m"
            trans__V_54_54 = (trans__M31_31 * trans__X_35);
#line 252 "trans.m"
            trans__V_55_55 = (trans__M32_32 * trans__Y_36);
#line 252 "trans.m"
            trans__V_52_52 = (trans__V_54_54 + trans__V_55_55);
#line 252 "trans.m"
            trans__V_53_53 = (trans__M33_33 * trans__Z_37);
#line 252 "trans.m"
            trans__V_51_51 = (trans__V_52_52 + trans__V_53_53);
#line 250 "trans.m"
            trans__V_40_40 = (trans__V_51_51 + trans__M34_34);
#line 972 "trans.m"
            trans__V_10_10 = (trans__V_38_38 * trans__V_38_38);
#line 972 "trans.m"
            trans__V_11_11 = (trans__V_40_40 * trans__V_40_40);
#line 972 "trans.m"
            trans__V_8_8 = (trans__V_10_10 + trans__V_11_11);
#line 972 "trans.m"
            trans__V_56_56 = (MR_Float) 1.00000000000000;
#line 972 "trans.m"
            trans__succeeded = (trans__V_8_8 <= trans__V_56_56);
          }
      }
    return trans__succeeded;
  }
#line 184 "trans.m"
}

#line 181 "trans.m"
bool MR_CALL trans__inside_cube_2_p_0(
#line 181 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 181 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 181 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__W_16 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__M11_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_16, (MR_Integer) 0)));
    MR_Float trans__M12_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_16, (MR_Integer) 1)));
    MR_Float trans__M13_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_16, (MR_Integer) 2)));
    MR_Float trans__M14_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_16, (MR_Integer) 3)));
    MR_Float trans__M21_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_16, (MR_Integer) 4)));
    MR_Float trans__M22_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_16, (MR_Integer) 5)));
    MR_Float trans__M23_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_16, (MR_Integer) 6)));
    MR_Float trans__M24_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_16, (MR_Integer) 7)));
    MR_Float trans__M31_29 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_16, (MR_Integer) 8)));
    MR_Float trans__M32_30 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_16, (MR_Integer) 9)));
    MR_Float trans__M33_31 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_16, (MR_Integer) 10)));
    MR_Float trans__M34_32 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_16, (MR_Integer) 11)));
    MR_Float trans__X_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__Y_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__Z_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40;
    MR_Float trans__V_41_41;
    MR_Float trans__V_42_42 = (trans__M11_21 * trans__X_33);
    MR_Float trans__V_43_43 = (trans__M12_22 * trans__Y_34);
    MR_Float trans__V_44_44;
    MR_Float trans__V_45_45;
    MR_Float trans__V_46_46;
    MR_Float trans__V_47_47;
    MR_Float trans__V_48_48;
    MR_Float trans__V_49_49;
    MR_Float trans__V_50_50;
    MR_Float trans__V_51_51;
    MR_Float trans__V_52_52;
    MR_Float trans__V_53_53;
    MR_Float trans__V_54_54;
    MR_Float trans__V_55_55;
    MR_Float trans__V_56_56;
    MR_Float trans__V_57_57;
    MR_Float trans__V_58_58;
    MR_Float trans__V_59_59;
#line 286 "trans.m"
    MR_Word trans___M_15 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));

#line 250 "trans.m"
    trans__V_40_40 = (trans__V_42_42 + trans__V_43_43);
#line 250 "trans.m"
    trans__V_41_41 = (trans__M13_23 * trans__Z_35);
#line 250 "trans.m"
    trans__V_39_39 = (trans__V_40_40 + trans__V_41_41);
#line 250 "trans.m"
    trans__V_36_36 = (trans__V_39_39 + trans__M14_24);
#line 959 "trans.m"
    trans__V_59_59 = (MR_Float) 0.00000000000000;
#line 959 "trans.m"
    trans__succeeded = (trans__V_36_36 >= trans__V_59_59);
    if (trans__succeeded)
      {
#line 962 "trans.m"
        trans__V_56_56 = (MR_Float) 1.00000000000000;
#line 962 "trans.m"
        trans__succeeded = (trans__V_36_36 <= trans__V_56_56);
        if (trans__succeeded)
          {
#line 251 "trans.m"
            trans__V_47_47 = (trans__M21_25 * trans__X_33);
#line 251 "trans.m"
            trans__V_48_48 = (trans__M22_26 * trans__Y_34);
#line 251 "trans.m"
            trans__V_45_45 = (trans__V_47_47 + trans__V_48_48);
#line 251 "trans.m"
            trans__V_46_46 = (trans__M23_27 * trans__Z_35);
#line 251 "trans.m"
            trans__V_44_44 = (trans__V_45_45 + trans__V_46_46);
#line 250 "trans.m"
            trans__V_37_37 = (trans__V_44_44 + trans__M24_28);
#line 960 "trans.m"
            trans__V_58_58 = (MR_Float) 0.00000000000000;
#line 960 "trans.m"
            trans__succeeded = (trans__V_37_37 >= trans__V_58_58);
            if (trans__succeeded)
              {
#line 963 "trans.m"
                trans__V_55_55 = (MR_Float) 1.00000000000000;
#line 963 "trans.m"
                trans__succeeded = (trans__V_37_37 <= trans__V_55_55);
                if (trans__succeeded)
                  {
#line 252 "trans.m"
                    trans__V_52_52 = (trans__M31_29 * trans__X_33);
#line 252 "trans.m"
                    trans__V_53_53 = (trans__M32_30 * trans__Y_34);
#line 252 "trans.m"
                    trans__V_50_50 = (trans__V_52_52 + trans__V_53_53);
#line 252 "trans.m"
                    trans__V_51_51 = (trans__M33_31 * trans__Z_35);
#line 252 "trans.m"
                    trans__V_49_49 = (trans__V_50_50 + trans__V_51_51);
#line 250 "trans.m"
                    trans__V_38_38 = (trans__V_49_49 + trans__M34_32);
#line 961 "trans.m"
                    trans__V_57_57 = (MR_Float) 0.00000000000000;
#line 961 "trans.m"
                    trans__succeeded = (trans__V_38_38 >= trans__V_57_57);
                    if (trans__succeeded)
                      {
#line 964 "trans.m"
                        trans__V_54_54 = (MR_Float) 1.00000000000000;
#line 964 "trans.m"
                        trans__succeeded = (trans__V_38_38 <= trans__V_54_54);
                      }
                  }
              }
          }
      }
    return trans__succeeded;
  }
#line 181 "trans.m"
}

#line 178 "trans.m"
bool MR_CALL trans__inside_plane_2_p_0(
#line 178 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 178 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 178 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__W_11 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__M21_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_11, (MR_Integer) 4)));
    MR_Float trans__M22_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_11, (MR_Integer) 5)));
    MR_Float trans__M23_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_11, (MR_Integer) 6)));
    MR_Float trans__M24_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_11, (MR_Integer) 7)));
    MR_Float trans__X_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__Y_29 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__Z_30 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float trans__V_32_32;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40;
    MR_Float trans__V_41_41;
    MR_Float trans__V_42_42 = (trans__M21_20 * trans__X_28);
    MR_Float trans__V_43_43 = (trans__M22_21 * trans__Y_29);
    MR_Float trans__V_49_49;
#line 286 "trans.m"
    MR_Word trans___M_10 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
#line 244 "trans.m"
    MR_Float trans__M11_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_11, (MR_Integer) 0)));
#line 244 "trans.m"
    MR_Float trans__M12_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_11, (MR_Integer) 1)));
#line 244 "trans.m"
    MR_Float trans__M13_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_11, (MR_Integer) 2)));
#line 244 "trans.m"
    MR_Float trans__M14_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_11, (MR_Integer) 3)));
#line 244 "trans.m"
    MR_Float trans__M31_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_11, (MR_Integer) 8)));
#line 244 "trans.m"
    MR_Float trans__M32_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_11, (MR_Integer) 9)));
#line 244 "trans.m"
    MR_Float trans__M33_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_11, (MR_Integer) 10)));
#line 244 "trans.m"
    MR_Float trans__M34_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_11, (MR_Integer) 11)));

#line 251 "trans.m"
    trans__V_40_40 = (trans__V_42_42 + trans__V_43_43);
#line 251 "trans.m"
    trans__V_41_41 = (trans__M23_22 * trans__Z_30);
#line 251 "trans.m"
    trans__V_39_39 = (trans__V_40_40 + trans__V_41_41);
#line 250 "trans.m"
    trans__V_32_32 = (trans__V_39_39 + trans__M24_23);
#line 953 "trans.m"
    trans__V_49_49 = (MR_Float) 0.00000000000000;
#line 953 "trans.m"
    trans__succeeded = (trans__V_32_32 <= trans__V_49_49);
    return trans__succeeded;
  }
#line 178 "trans.m"
}

#line 175 "trans.m"
bool MR_CALL trans__inside_sphere_2_p_0(
#line 175 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 175 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 175 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Float trans__V_6_6;
    MR_Word trans__W_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__M11_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_9, (MR_Integer) 0)));
    MR_Float trans__M12_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_9, (MR_Integer) 1)));
    MR_Float trans__M13_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_9, (MR_Integer) 2)));
    MR_Float trans__M14_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_9, (MR_Integer) 3)));
    MR_Float trans__M21_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_9, (MR_Integer) 4)));
    MR_Float trans__M22_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_9, (MR_Integer) 5)));
    MR_Float trans__M23_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_9, (MR_Integer) 6)));
    MR_Float trans__M24_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_9, (MR_Integer) 7)));
    MR_Float trans__M31_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_9, (MR_Integer) 8)));
    MR_Float trans__M32_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_9, (MR_Integer) 9)));
    MR_Float trans__M33_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_9, (MR_Integer) 10)));
    MR_Float trans__M34_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_9, (MR_Integer) 11)));
    MR_Float trans__X_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__Y_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__Z_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 2)));
    MR_Float trans__V_29_29;
    MR_Float trans__V_30_30;
    MR_Float trans__V_31_31;
    MR_Float trans__V_32_32;
    MR_Float trans__V_33_33;
    MR_Float trans__V_34_34;
    MR_Float trans__V_35_35 = (trans__M11_14 * trans__X_26);
    MR_Float trans__V_36_36 = (trans__M12_15 * trans__Y_27);
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40;
    MR_Float trans__V_41_41;
    MR_Float trans__V_42_42;
    MR_Float trans__V_43_43;
    MR_Float trans__V_44_44;
    MR_Float trans__V_45_45;
    MR_Float trans__V_46_46;
    MR_Float trans__V_6_51;
    MR_Float trans__V_7_52;
    MR_Float trans__V_8_53;
    MR_Float trans__V_9_54;
    MR_Float trans__V_58_58;
#line 286 "trans.m"
    MR_Word trans___M_8 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));

#line 250 "trans.m"
    trans__V_33_33 = (trans__V_35_35 + trans__V_36_36);
#line 250 "trans.m"
    trans__V_34_34 = (trans__M13_16 * trans__Z_28);
#line 250 "trans.m"
    trans__V_32_32 = (trans__V_33_33 + trans__V_34_34);
#line 250 "trans.m"
    trans__V_29_29 = (trans__V_32_32 + trans__M14_17);
#line 251 "trans.m"
    trans__V_40_40 = (trans__M21_18 * trans__X_26);
#line 251 "trans.m"
    trans__V_41_41 = (trans__M22_19 * trans__Y_27);
#line 251 "trans.m"
    trans__V_38_38 = (trans__V_40_40 + trans__V_41_41);
#line 251 "trans.m"
    trans__V_39_39 = (trans__M23_20 * trans__Z_28);
#line 251 "trans.m"
    trans__V_37_37 = (trans__V_38_38 + trans__V_39_39);
#line 250 "trans.m"
    trans__V_30_30 = (trans__V_37_37 + trans__M24_21);
#line 252 "trans.m"
    trans__V_45_45 = (trans__M31_22 * trans__X_26);
#line 252 "trans.m"
    trans__V_46_46 = (trans__M32_23 * trans__Y_27);
#line 252 "trans.m"
    trans__V_43_43 = (trans__V_45_45 + trans__V_46_46);
#line 252 "trans.m"
    trans__V_44_44 = (trans__M33_24 * trans__Z_28);
#line 252 "trans.m"
    trans__V_42_42 = (trans__V_43_43 + trans__V_44_44);
#line 250 "trans.m"
    trans__V_31_31 = (trans__V_42_42 + trans__M34_25);
#line 28 "vector.opt"
    trans__V_8_53 = (trans__V_29_29 * trans__V_29_29);
#line 30 "vector.opt"
    trans__V_9_54 = (trans__V_30_30 * trans__V_30_30);
#line 27 "vector.opt"
    trans__V_6_51 = (trans__V_8_53 + trans__V_9_54);
#line 32 "vector.opt"
    trans__V_7_52 = (trans__V_31_31 * trans__V_31_31);
#line 26 "vector.opt"
    trans__V_6_6 = (trans__V_6_51 + trans__V_7_52);
#line 947 "trans.m"
    trans__V_58_58 = (MR_Float) 1.00000000000000;
#line 947 "trans.m"
    trans__succeeded = (trans__V_6_6 <= trans__V_58_58);
    return trans__succeeded;
  }
#line 175 "trans.m"
}

#line 169 "trans.m"
void MR_CALL trans__intersects_cone_6_p_0(
#line 169 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 169 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 169 "trans.m"
  MR_Word trans__HeadVar__3_3,
#line 169 "trans.m"
  MR_Word trans__HeadVar__4_4,
#line 169 "trans.m"
  MR_Word trans__HeadVar__5_5,
#line 169 "trans.m"
  MR_Word * trans__HeadVar__6_6)
#line 169 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Float trans__Dx_16;
    MR_Float trans__Dy_17;
    MR_Float trans__Dz_18;
    MR_Word trans__Face0Intersections_19;
    MR_Word trans__Face1Intersections_20;
    MR_Word trans__FaceIntersections_21;
    MR_Integer trans__V_23_23;
    MR_Float trans__V_24_24;
    MR_Integer trans__V_25_25;
    MR_Word trans__V_26_26;
    MR_Word trans__TypeInfo_28_28;
    MR_Word trans__W_34 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__M11_39 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_34, (MR_Integer) 0)));
    MR_Float trans__M12_40 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_34, (MR_Integer) 1)));
    MR_Float trans__M13_41 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_34, (MR_Integer) 2)));
    MR_Float trans__M14_42 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_34, (MR_Integer) 3)));
    MR_Float trans__M21_43 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_34, (MR_Integer) 4)));
    MR_Float trans__M22_44 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_34, (MR_Integer) 5)));
    MR_Float trans__M23_45 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_34, (MR_Integer) 6)));
    MR_Float trans__M24_46 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_34, (MR_Integer) 7)));
    MR_Float trans__M31_47 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_34, (MR_Integer) 8)));
    MR_Float trans__M32_48 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_34, (MR_Integer) 9)));
    MR_Float trans__M33_49 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_34, (MR_Integer) 10)));
    MR_Float trans__M34_50 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_34, (MR_Integer) 11)));
    MR_Float trans__X_51 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float trans__Y_52 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 1)));
    MR_Float trans__Z_53 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 2)));
    MR_Float trans__V_54_54;
    MR_Float trans__V_55_55;
    MR_Float trans__V_56_56;
    MR_Float trans__V_57_57;
    MR_Float trans__V_58_58;
    MR_Float trans__V_59_59;
    MR_Float trans__V_60_60 = (trans__M11_39 * trans__X_51);
    MR_Float trans__V_61_61 = (trans__M12_40 * trans__Y_52);
    MR_Float trans__V_62_62;
    MR_Float trans__V_63_63;
    MR_Float trans__V_64_64;
    MR_Float trans__V_65_65;
    MR_Float trans__V_66_66;
    MR_Float trans__V_67_67;
    MR_Float trans__V_68_68;
    MR_Float trans__V_69_69;
    MR_Float trans__V_70_70;
    MR_Float trans__V_71_71;
#line 286 "trans.m"
    MR_Word trans___M_33 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));

#line 250 "trans.m"
    trans__V_58_58 = (trans__V_60_60 + trans__V_61_61);
#line 250 "trans.m"
    trans__V_59_59 = (trans__M13_41 * trans__Z_53);
#line 250 "trans.m"
    trans__V_57_57 = (trans__V_58_58 + trans__V_59_59);
#line 250 "trans.m"
    trans__V_54_54 = (trans__V_57_57 + trans__M14_42);
#line 251 "trans.m"
    trans__V_65_65 = (trans__M21_43 * trans__X_51);
#line 251 "trans.m"
    trans__V_66_66 = (trans__M22_44 * trans__Y_52);
#line 251 "trans.m"
    trans__V_63_63 = (trans__V_65_65 + trans__V_66_66);
#line 251 "trans.m"
    trans__V_64_64 = (trans__M23_45 * trans__Z_53);
#line 251 "trans.m"
    trans__V_62_62 = (trans__V_63_63 + trans__V_64_64);
#line 250 "trans.m"
    trans__V_55_55 = (trans__V_62_62 + trans__M24_46);
#line 252 "trans.m"
    trans__V_70_70 = (trans__M31_47 * trans__X_51);
#line 252 "trans.m"
    trans__V_71_71 = (trans__M32_48 * trans__Y_52);
#line 252 "trans.m"
    trans__V_68_68 = (trans__V_70_70 + trans__V_71_71);
#line 252 "trans.m"
    trans__V_69_69 = (trans__M33_49 * trans__Z_53);
#line 252 "trans.m"
    trans__V_67_67 = (trans__V_68_68 + trans__V_69_69);
#line 250 "trans.m"
    trans__V_56_56 = (trans__V_67_67 + trans__M34_50);
#line 818 "trans.m"
    {
#line 818 "trans.m"
      trans__V_26_26 = trans__vector_to_object_space_3_f_0(trans__HeadVar__2_2, trans__HeadVar__4_4);
    }
#line 818 "trans.m"
    trans__Dx_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_26_26, (MR_Integer) 0)));
#line 818 "trans.m"
    trans__Dy_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_26_26, (MR_Integer) 1)));
#line 818 "trans.m"
    trans__Dz_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_26_26, (MR_Integer) 2)));
#line 824 "trans.m"
    trans__V_25_25 = (MR_Integer) 0;
#line 824 "trans.m"
    {
#line 824 "trans.m"
      trans__Face0Intersections_19 = trans__cone_intersection_8_f_0(trans__V_25_25, trans__V_54_54, trans__V_55_55, trans__V_56_56, trans__Dx_16, trans__Dy_17, trans__Dz_18);
    }
#line 825 "trans.m"
    trans__V_23_23 = (MR_Integer) 1;
#line 825 "trans.m"
    trans__V_24_24 = (MR_Float) 1.00000000000000;
#line 825 "trans.m"
    {
#line 825 "trans.m"
      trans__Face1Intersections_20 = trans__disc_intersection_9_f_0(trans__V_23_23, trans__V_24_24, trans__V_54_54, trans__V_55_55, trans__V_56_56, trans__Dx_16, trans__Dy_17, trans__Dz_18);
    }
    trans__TypeInfo_28_28 = (MR_Word) (&trans__trans__type_ctor_info_face_intersection_0);
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 27 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      mercury__list__append_3_p_1(trans__TypeInfo_28_28, trans__Face1Intersections_20, trans__Face0Intersections_19, &trans__FaceIntersections_21);
    }
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      trans__map__ho7__ua0_3_p_in__list_0(trans__HeadVar__1_1, trans__HeadVar__2_2, trans__HeadVar__5_5, trans__FaceIntersections_21, trans__HeadVar__6_6);
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      return;
    }
  }
#line 169 "trans.m"
}

#line 165 "trans.m"
void MR_CALL trans__intersects_cylinder_6_p_0(
#line 165 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 165 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 165 "trans.m"
  MR_Word trans__HeadVar__3_3,
#line 165 "trans.m"
  MR_Word trans__HeadVar__4_4,
#line 165 "trans.m"
  MR_Word trans__HeadVar__5_5,
#line 165 "trans.m"
  MR_Word * trans__HeadVar__6_6)
#line 165 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Float trans__Dx_16;
    MR_Float trans__Dy_17;
    MR_Float trans__Dz_18;
    MR_Word trans__Face0Intersections_19;
    MR_Word trans__Face1Intersections_20;
    MR_Word trans__Face2Intersections_21;
    MR_Word trans__FaceIntersections_22;
    MR_Word trans__V_24_24;
    MR_Word trans__V_25_25;
    MR_Word trans__V_26_26;
    MR_Word trans__V_27_27;
    MR_Integer trans__V_28_28;
    MR_Float trans__V_29_29;
    MR_Integer trans__V_30_30;
    MR_Float trans__V_31_31;
    MR_Integer trans__V_32_32;
    MR_Word trans__V_33_33;
    MR_Word trans__TypeInfo_35_35;
    MR_Word trans__W_41 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__M11_46 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_41, (MR_Integer) 0)));
    MR_Float trans__M12_47 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_41, (MR_Integer) 1)));
    MR_Float trans__M13_48 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_41, (MR_Integer) 2)));
    MR_Float trans__M14_49 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_41, (MR_Integer) 3)));
    MR_Float trans__M21_50 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_41, (MR_Integer) 4)));
    MR_Float trans__M22_51 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_41, (MR_Integer) 5)));
    MR_Float trans__M23_52 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_41, (MR_Integer) 6)));
    MR_Float trans__M24_53 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_41, (MR_Integer) 7)));
    MR_Float trans__M31_54 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_41, (MR_Integer) 8)));
    MR_Float trans__M32_55 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_41, (MR_Integer) 9)));
    MR_Float trans__M33_56 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_41, (MR_Integer) 10)));
    MR_Float trans__M34_57 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_41, (MR_Integer) 11)));
    MR_Float trans__X_58 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float trans__Y_59 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 1)));
    MR_Float trans__Z_60 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 2)));
    MR_Float trans__V_61_61;
    MR_Float trans__V_62_62;
    MR_Float trans__V_63_63;
    MR_Float trans__V_64_64;
    MR_Float trans__V_65_65;
    MR_Float trans__V_66_66;
    MR_Float trans__V_67_67 = (trans__M11_46 * trans__X_58);
    MR_Float trans__V_68_68 = (trans__M12_47 * trans__Y_59);
    MR_Float trans__V_69_69;
    MR_Float trans__V_70_70;
    MR_Float trans__V_71_71;
    MR_Float trans__V_72_72;
    MR_Float trans__V_73_73;
    MR_Float trans__V_74_74;
    MR_Float trans__V_75_75;
    MR_Float trans__V_76_76;
    MR_Float trans__V_77_77;
    MR_Float trans__V_78_78;
#line 286 "trans.m"
    MR_Word trans___M_40 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));

#line 250 "trans.m"
    trans__V_65_65 = (trans__V_67_67 + trans__V_68_68);
#line 250 "trans.m"
    trans__V_66_66 = (trans__M13_48 * trans__Z_60);
#line 250 "trans.m"
    trans__V_64_64 = (trans__V_65_65 + trans__V_66_66);
#line 250 "trans.m"
    trans__V_61_61 = (trans__V_64_64 + trans__M14_49);
#line 251 "trans.m"
    trans__V_72_72 = (trans__M21_50 * trans__X_58);
#line 251 "trans.m"
    trans__V_73_73 = (trans__M22_51 * trans__Y_59);
#line 251 "trans.m"
    trans__V_70_70 = (trans__V_72_72 + trans__V_73_73);
#line 251 "trans.m"
    trans__V_71_71 = (trans__M23_52 * trans__Z_60);
#line 251 "trans.m"
    trans__V_69_69 = (trans__V_70_70 + trans__V_71_71);
#line 250 "trans.m"
    trans__V_62_62 = (trans__V_69_69 + trans__M24_53);
#line 252 "trans.m"
    trans__V_77_77 = (trans__M31_54 * trans__X_58);
#line 252 "trans.m"
    trans__V_78_78 = (trans__M32_55 * trans__Y_59);
#line 252 "trans.m"
    trans__V_75_75 = (trans__V_77_77 + trans__V_78_78);
#line 252 "trans.m"
    trans__V_76_76 = (trans__M33_56 * trans__Z_60);
#line 252 "trans.m"
    trans__V_74_74 = (trans__V_75_75 + trans__V_76_76);
#line 250 "trans.m"
    trans__V_63_63 = (trans__V_74_74 + trans__M34_57);
#line 769 "trans.m"
    {
#line 769 "trans.m"
      trans__V_33_33 = trans__vector_to_object_space_3_f_0(trans__HeadVar__2_2, trans__HeadVar__4_4);
    }
#line 769 "trans.m"
    trans__Dx_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_33_33, (MR_Integer) 0)));
#line 769 "trans.m"
    trans__Dy_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_33_33, (MR_Integer) 1)));
#line 769 "trans.m"
    trans__Dz_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_33_33, (MR_Integer) 2)));
#line 776 "trans.m"
    trans__V_32_32 = (MR_Integer) 0;
#line 776 "trans.m"
    {
#line 776 "trans.m"
      trans__Face0Intersections_19 = trans__cylinder_intersection_8_f_0(trans__V_32_32, trans__V_61_61, trans__V_62_62, trans__V_63_63, trans__Dx_16, trans__Dy_17, trans__Dz_18);
    }
#line 777 "trans.m"
    trans__V_30_30 = (MR_Integer) 1;
#line 777 "trans.m"
    trans__V_31_31 = (MR_Float) 1.00000000000000;
#line 777 "trans.m"
    {
#line 777 "trans.m"
      trans__Face1Intersections_20 = trans__disc_intersection_9_f_0(trans__V_30_30, trans__V_31_31, trans__V_61_61, trans__V_62_62, trans__V_63_63, trans__Dx_16, trans__Dy_17, trans__Dz_18);
    }
#line 778 "trans.m"
    trans__V_28_28 = (MR_Integer) 2;
#line 778 "trans.m"
    trans__V_29_29 = (MR_Float) 0.00000000000000;
#line 778 "trans.m"
    {
#line 778 "trans.m"
      trans__Face2Intersections_21 = trans__disc_intersection_9_f_0(trans__V_28_28, trans__V_29_29, trans__V_61_61, trans__V_62_62, trans__V_63_63, trans__Dx_16, trans__Dy_17, trans__Dz_18);
    }
#line 781 "trans.m"
    trans__V_27_27 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 781 "trans.m"
    {
#line 781 "trans.m"
      trans__V_26_26 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 781 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_26_26, 0) = ((MR_Box) (trans__Face2Intersections_21));
#line 781 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_26_26, 1) = ((MR_Box) (trans__V_27_27));
#line 781 "trans.m"
    }
#line 780 "trans.m"
    {
#line 780 "trans.m"
      trans__V_25_25 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 780 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_25_25, 0) = ((MR_Box) (trans__Face1Intersections_20));
#line 780 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_25_25, 1) = ((MR_Box) (trans__V_26_26));
#line 780 "trans.m"
    }
#line 780 "trans.m"
    {
#line 780 "trans.m"
      trans__V_24_24 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 780 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_24_24, 0) = ((MR_Box) (trans__Face0Intersections_19));
#line 780 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_24_24, 1) = ((MR_Box) (trans__V_25_25));
#line 780 "trans.m"
    }
    trans__TypeInfo_35_35 = (MR_Word) (&trans__trans__type_ctor_info_face_intersection_0);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      mercury__list__condense_2_p_0(trans__TypeInfo_35_35, trans__V_24_24, &trans__FaceIntersections_22);
    }
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      trans__map__ho6__ua0_3_p_in__list_0(trans__HeadVar__1_1, trans__HeadVar__2_2, trans__HeadVar__5_5, trans__FaceIntersections_22, trans__HeadVar__6_6);
#line 140 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      return;
    }
  }
#line 165 "trans.m"
}

#line 161 "trans.m"
void MR_CALL trans__intersects_cube_6_p_0(
#line 161 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 161 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 161 "trans.m"
  MR_Word trans__HeadVar__3_3,
#line 161 "trans.m"
  MR_Word trans__HeadVar__4_4,
#line 161 "trans.m"
  MR_Word trans__HeadVar__5_5,
#line 161 "trans.m"
  MR_Word * trans__HeadVar__6_6)
#line 161 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Float trans__Dx_16;
    MR_Float trans__Dy_17;
    MR_Float trans__Dz_18;
    MR_Word trans__Face0Intersection_19;
    MR_Word trans__Face1Intersection_20;
    MR_Word trans__Face2Intersection_21;
    MR_Word trans__Face3Intersection_22;
    MR_Word trans__Face4Intersection_23;
    MR_Word trans__Face5Intersection_24;
    MR_Word trans__FaceIntersections_25;
    MR_Word trans__V_27_27;
    MR_Word trans__V_28_28;
    MR_Word trans__V_29_29;
    MR_Word trans__V_30_30;
    MR_Word trans__V_31_31;
    MR_Word trans__V_32_32;
    MR_Word trans__V_33_33;
    MR_Integer trans__V_34_34;
    MR_Float trans__V_35_35;
    MR_Integer trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Integer trans__V_38_38;
    MR_Float trans__V_39_39;
    MR_Integer trans__V_40_40;
    MR_Float trans__V_41_41;
    MR_Integer trans__V_42_42;
    MR_Float trans__V_43_43;
    MR_Integer trans__V_44_44;
    MR_Float trans__V_45_45;
    MR_Word trans__V_46_46;
    MR_Word trans__TypeInfo_48_48;
    MR_Word trans__W_54 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__M11_59 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 0)));
    MR_Float trans__M12_60 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 1)));
    MR_Float trans__M13_61 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 2)));
    MR_Float trans__M14_62 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 3)));
    MR_Float trans__M21_63 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 4)));
    MR_Float trans__M22_64 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 5)));
    MR_Float trans__M23_65 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 6)));
    MR_Float trans__M24_66 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 7)));
    MR_Float trans__M31_67 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 8)));
    MR_Float trans__M32_68 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 9)));
    MR_Float trans__M33_69 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 10)));
    MR_Float trans__M34_70 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 11)));
    MR_Float trans__X_71 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float trans__Y_72 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 1)));
    MR_Float trans__Z_73 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 2)));
    MR_Float trans__V_74_74;
    MR_Float trans__V_75_75;
    MR_Float trans__V_76_76;
    MR_Float trans__V_77_77;
    MR_Float trans__V_78_78;
    MR_Float trans__V_79_79;
    MR_Float trans__V_80_80 = (trans__M11_59 * trans__X_71);
    MR_Float trans__V_81_81 = (trans__M12_60 * trans__Y_72);
    MR_Float trans__V_82_82;
    MR_Float trans__V_83_83;
    MR_Float trans__V_84_84;
    MR_Float trans__V_85_85;
    MR_Float trans__V_86_86;
    MR_Float trans__V_87_87;
    MR_Float trans__V_88_88;
    MR_Float trans__V_89_89;
    MR_Float trans__V_90_90;
    MR_Float trans__V_91_91;
#line 286 "trans.m"
    MR_Word trans___M_53 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));

#line 250 "trans.m"
    trans__V_78_78 = (trans__V_80_80 + trans__V_81_81);
#line 250 "trans.m"
    trans__V_79_79 = (trans__M13_61 * trans__Z_73);
#line 250 "trans.m"
    trans__V_77_77 = (trans__V_78_78 + trans__V_79_79);
#line 250 "trans.m"
    trans__V_74_74 = (trans__V_77_77 + trans__M14_62);
#line 251 "trans.m"
    trans__V_85_85 = (trans__M21_63 * trans__X_71);
#line 251 "trans.m"
    trans__V_86_86 = (trans__M22_64 * trans__Y_72);
#line 251 "trans.m"
    trans__V_83_83 = (trans__V_85_85 + trans__V_86_86);
#line 251 "trans.m"
    trans__V_84_84 = (trans__M23_65 * trans__Z_73);
#line 251 "trans.m"
    trans__V_82_82 = (trans__V_83_83 + trans__V_84_84);
#line 250 "trans.m"
    trans__V_75_75 = (trans__V_82_82 + trans__M24_66);
#line 252 "trans.m"
    trans__V_90_90 = (trans__M31_67 * trans__X_71);
#line 252 "trans.m"
    trans__V_91_91 = (trans__M32_68 * trans__Y_72);
#line 252 "trans.m"
    trans__V_88_88 = (trans__V_90_90 + trans__V_91_91);
#line 252 "trans.m"
    trans__V_89_89 = (trans__M33_69 * trans__Z_73);
#line 252 "trans.m"
    trans__V_87_87 = (trans__V_88_88 + trans__V_89_89);
#line 250 "trans.m"
    trans__V_76_76 = (trans__V_87_87 + trans__M34_70);
#line 628 "trans.m"
    {
#line 628 "trans.m"
      trans__V_46_46 = trans__vector_to_object_space_3_f_0(trans__HeadVar__2_2, trans__HeadVar__4_4);
    }
#line 628 "trans.m"
    trans__Dx_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_46_46, (MR_Integer) 0)));
#line 628 "trans.m"
    trans__Dy_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_46_46, (MR_Integer) 1)));
#line 628 "trans.m"
    trans__Dz_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_46_46, (MR_Integer) 2)));
#line 641 "trans.m"
    trans__V_44_44 = (MR_Integer) 0;
#line 641 "trans.m"
    trans__V_45_45 = (MR_Float) 0.00000000000000;
#line 641 "trans.m"
    {
#line 641 "trans.m"
      trans__Face0Intersection_19 = trans__z_face_intersection_9_f_0(trans__V_44_44, trans__V_45_45, trans__V_74_74, trans__V_75_75, trans__V_76_76, trans__Dx_16, trans__Dy_17, trans__Dz_18);
    }
#line 642 "trans.m"
    trans__V_42_42 = (MR_Integer) 1;
#line 642 "trans.m"
    trans__V_43_43 = (MR_Float) 1.00000000000000;
#line 642 "trans.m"
    {
#line 642 "trans.m"
      trans__Face1Intersection_20 = trans__z_face_intersection_9_f_0(trans__V_42_42, trans__V_43_43, trans__V_74_74, trans__V_75_75, trans__V_76_76, trans__Dx_16, trans__Dy_17, trans__Dz_18);
    }
#line 643 "trans.m"
    trans__V_40_40 = (MR_Integer) 2;
#line 643 "trans.m"
    trans__V_41_41 = (MR_Float) 0.00000000000000;
#line 643 "trans.m"
    {
#line 643 "trans.m"
      trans__Face2Intersection_21 = trans__x_face_intersection_9_f_0(trans__V_40_40, trans__V_41_41, trans__V_74_74, trans__V_75_75, trans__V_76_76, trans__Dx_16, trans__Dy_17, trans__Dz_18);
    }
#line 644 "trans.m"
    trans__V_38_38 = (MR_Integer) 3;
#line 644 "trans.m"
    trans__V_39_39 = (MR_Float) 1.00000000000000;
#line 644 "trans.m"
    {
#line 644 "trans.m"
      trans__Face3Intersection_22 = trans__x_face_intersection_9_f_0(trans__V_38_38, trans__V_39_39, trans__V_74_74, trans__V_75_75, trans__V_76_76, trans__Dx_16, trans__Dy_17, trans__Dz_18);
    }
#line 645 "trans.m"
    trans__V_36_36 = (MR_Integer) 4;
#line 645 "trans.m"
    trans__V_37_37 = (MR_Float) 1.00000000000000;
#line 645 "trans.m"
    {
#line 645 "trans.m"
      trans__Face4Intersection_23 = trans__y_face_intersection_9_f_0(trans__V_36_36, trans__V_37_37, trans__V_74_74, trans__V_75_75, trans__V_76_76, trans__Dx_16, trans__Dy_17, trans__Dz_18);
    }
#line 646 "trans.m"
    trans__V_34_34 = (MR_Integer) 5;
#line 646 "trans.m"
    trans__V_35_35 = (MR_Float) 0.00000000000000;
#line 646 "trans.m"
    {
#line 646 "trans.m"
      trans__Face5Intersection_24 = trans__y_face_intersection_9_f_0(trans__V_34_34, trans__V_35_35, trans__V_74_74, trans__V_75_75, trans__V_76_76, trans__Dx_16, trans__Dy_17, trans__Dz_18);
    }
#line 650 "trans.m"
    trans__V_33_33 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 650 "trans.m"
    {
#line 650 "trans.m"
      trans__V_32_32 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 650 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_32_32, 0) = ((MR_Box) (trans__Face5Intersection_24));
#line 650 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_32_32, 1) = ((MR_Box) (trans__V_33_33));
#line 650 "trans.m"
    }
#line 649 "trans.m"
    {
#line 649 "trans.m"
      trans__V_31_31 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 649 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_31_31, 0) = ((MR_Box) (trans__Face4Intersection_23));
#line 649 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_31_31, 1) = ((MR_Box) (trans__V_32_32));
#line 649 "trans.m"
    }
#line 649 "trans.m"
    {
#line 649 "trans.m"
      trans__V_30_30 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 649 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_30_30, 0) = ((MR_Box) (trans__Face3Intersection_22));
#line 649 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_30_30, 1) = ((MR_Box) (trans__V_31_31));
#line 649 "trans.m"
    }
#line 649 "trans.m"
    {
#line 649 "trans.m"
      trans__V_29_29 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 649 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_29_29, 0) = ((MR_Box) (trans__Face2Intersection_21));
#line 649 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_29_29, 1) = ((MR_Box) (trans__V_30_30));
#line 649 "trans.m"
    }
#line 648 "trans.m"
    {
#line 648 "trans.m"
      trans__V_28_28 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 648 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_28_28, 0) = ((MR_Box) (trans__Face1Intersection_20));
#line 648 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_28_28, 1) = ((MR_Box) (trans__V_29_29));
#line 648 "trans.m"
    }
#line 648 "trans.m"
    {
#line 648 "trans.m"
      trans__V_27_27 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 648 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_27_27, 0) = ((MR_Box) (trans__Face0Intersection_19));
#line 648 "trans.m"
      MR_hl_field(MR_mktag(1), trans__V_27_27, 1) = ((MR_Box) (trans__V_28_28));
#line 648 "trans.m"
    }
    trans__TypeInfo_48_48 = (MR_Word) (&trans__trans__type_ctor_info_face_intersection_0);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
    {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/list.opt"
      mercury__list__condense_2_p_0(trans__TypeInfo_48_48, trans__V_27_27, &trans__FaceIntersections_25);
    }
#line 651 "trans.m"
    {
#line 651 "trans.m"
      *trans__HeadVar__6_6 = trans__map__ho4__ua0_3_f_in__list_0(trans__HeadVar__1_1, trans__HeadVar__2_2, trans__HeadVar__5_5, trans__FaceIntersections_25);
    }
  }
#line 161 "trans.m"
}

#line 157 "trans.m"
void MR_CALL trans__intersects_sphere_6_p_0(
#line 157 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 157 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 157 "trans.m"
  MR_Word trans__HeadVar__3_3,
#line 157 "trans.m"
  MR_Word trans__HeadVar__4_4,
#line 157 "trans.m"
  MR_Word trans__HeadVar__5_5,
#line 157 "trans.m"
  MR_Word * trans__HeadVar__6_6)
#line 157 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Float trans__Dx_16;
    MR_Float trans__Dy_17;
    MR_Float trans__Dz_18;
    MR_Float trans__SqrLoc_19;
    MR_Float trans__Tca_20;
    MR_Float trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40;
    MR_Float trans__V_41_41;
    MR_Float trans__V_42_42;
    MR_Float trans__V_43_43;
    MR_Float trans__V_44_44;
    MR_Float trans__V_45_45;
    MR_Float trans__V_46_46;
    MR_Word trans__V_50_50;
    MR_Word trans__V_51_51;
    MR_Word trans__W_54 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__M11_59 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 0)));
    MR_Float trans__M12_60 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 1)));
    MR_Float trans__M13_61 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 2)));
    MR_Float trans__M14_62 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 3)));
    MR_Float trans__M21_63 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 4)));
    MR_Float trans__M22_64 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 5)));
    MR_Float trans__M23_65 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 6)));
    MR_Float trans__M24_66 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 7)));
    MR_Float trans__M31_67 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 8)));
    MR_Float trans__M32_68 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 9)));
    MR_Float trans__M33_69 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 10)));
    MR_Float trans__M34_70 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_54, (MR_Integer) 11)));
    MR_Float trans__X_71 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float trans__Y_72 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 1)));
    MR_Float trans__Z_73 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 2)));
    MR_Float trans__V_74_74;
    MR_Float trans__V_75_75;
    MR_Float trans__V_76_76;
    MR_Float trans__V_77_77;
    MR_Float trans__V_78_78;
    MR_Float trans__V_79_79;
    MR_Float trans__V_80_80 = (trans__M11_59 * trans__X_71);
    MR_Float trans__V_81_81 = (trans__M12_60 * trans__Y_72);
    MR_Float trans__V_82_82;
    MR_Float trans__V_83_83;
    MR_Float trans__V_84_84;
    MR_Float trans__V_85_85;
    MR_Float trans__V_86_86;
    MR_Float trans__V_87_87;
    MR_Float trans__V_88_88;
    MR_Float trans__V_89_89;
    MR_Float trans__V_90_90;
    MR_Float trans__V_91_91;
#line 286 "trans.m"
    MR_Word trans___M_53 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__V_92_92;
    MR_Float trans__V_93_93;

#line 250 "trans.m"
    trans__V_78_78 = (trans__V_80_80 + trans__V_81_81);
#line 250 "trans.m"
    trans__V_79_79 = (trans__M13_61 * trans__Z_73);
#line 250 "trans.m"
    trans__V_77_77 = (trans__V_78_78 + trans__V_79_79);
#line 250 "trans.m"
    trans__V_74_74 = (trans__V_77_77 + trans__M14_62);
#line 251 "trans.m"
    trans__V_85_85 = (trans__M21_63 * trans__X_71);
#line 251 "trans.m"
    trans__V_86_86 = (trans__M22_64 * trans__Y_72);
#line 251 "trans.m"
    trans__V_83_83 = (trans__V_85_85 + trans__V_86_86);
#line 251 "trans.m"
    trans__V_84_84 = (trans__M23_65 * trans__Z_73);
#line 251 "trans.m"
    trans__V_82_82 = (trans__V_83_83 + trans__V_84_84);
#line 250 "trans.m"
    trans__V_75_75 = (trans__V_82_82 + trans__M24_66);
#line 252 "trans.m"
    trans__V_90_90 = (trans__M31_67 * trans__X_71);
#line 252 "trans.m"
    trans__V_91_91 = (trans__M32_68 * trans__Y_72);
#line 252 "trans.m"
    trans__V_88_88 = (trans__V_90_90 + trans__V_91_91);
#line 252 "trans.m"
    trans__V_89_89 = (trans__M33_69 * trans__Z_73);
#line 252 "trans.m"
    trans__V_87_87 = (trans__V_88_88 + trans__V_89_89);
#line 250 "trans.m"
    trans__V_76_76 = (trans__V_87_87 + trans__M34_70);
#line 529 "trans.m"
    {
#line 529 "trans.m"
      trans__V_51_51 = trans__vector_to_object_space_3_f_0(trans__HeadVar__2_2, trans__HeadVar__4_4);
    }
#line 529 "trans.m"
    {
#line 529 "trans.m"
      trans__V_50_50 = vector__unit_2_f_0(trans__V_51_51);
    }
#line 529 "trans.m"
    trans__Dx_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_50_50, (MR_Integer) 0)));
#line 529 "trans.m"
    trans__Dy_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_50_50, (MR_Integer) 1)));
#line 529 "trans.m"
    trans__Dz_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_50_50, (MR_Integer) 2)));
#line 533 "trans.m"
    trans__V_45_45 = (trans__V_74_74 * trans__V_74_74);
#line 533 "trans.m"
    trans__V_46_46 = (trans__V_75_75 * trans__V_75_75);
#line 533 "trans.m"
    trans__V_43_43 = (trans__V_45_45 + trans__V_46_46);
#line 533 "trans.m"
    trans__V_44_44 = (trans__V_76_76 * trans__V_76_76);
#line 533 "trans.m"
    trans__SqrLoc_19 = (trans__V_43_43 + trans__V_44_44);
#line 535 "trans.m"
    trans__V_40_40 = (((MR_Float) 0.00000000000000) - trans__V_74_74);
#line 535 "trans.m"
    trans__V_38_38 = (trans__V_40_40 * trans__Dx_16);
#line 535 "trans.m"
    trans__V_41_41 = (((MR_Float) 0.00000000000000) - trans__V_75_75);
#line 535 "trans.m"
    trans__V_39_39 = (trans__V_41_41 * trans__Dy_17);
#line 535 "trans.m"
    trans__V_36_36 = (trans__V_38_38 + trans__V_39_39);
#line 535 "trans.m"
    trans__V_42_42 = (((MR_Float) 0.00000000000000) - trans__V_76_76);
#line 535 "trans.m"
    trans__V_37_37 = (trans__V_42_42 * trans__Dz_18);
#line 535 "trans.m"
    trans__Tca_20 = (trans__V_36_36 + trans__V_37_37);
#line 540 "trans.m"
    trans__V_93_93 = (MR_Float) 1.00000000000000;
#line 540 "trans.m"
    trans__succeeded = (trans__SqrLoc_19 > trans__V_93_93);
    if (trans__succeeded)
      {
#line 540 "trans.m"
        trans__V_92_92 = (MR_Float) 0.00000000000000;
#line 540 "trans.m"
        trans__succeeded = (trans__Tca_20 < trans__V_92_92);
      }
#line 540 "trans.m"
    trans__succeeded = !(trans__succeeded);
#line 568 "trans.m"
    if (trans__succeeded)
      {
        MR_Float trans__SqrTca_21 = (trans__Tca_20 * trans__Tca_20);
        MR_Float trans__SqrD_22 = (trans__SqrLoc_19 - trans__SqrTca_21);
        MR_Float trans__SqrThc_23;
        MR_Float trans__V_34_34 = (MR_Float) 1.00000000000000;
        MR_Float trans__V_94_94;

#line 544 "trans.m"
        trans__SqrThc_23 = (trans__V_34_34 - trans__SqrD_22);
#line 549 "trans.m"
        trans__V_94_94 = (MR_Float) 0.00000000000000;
#line 549 "trans.m"
        trans__succeeded = (trans__SqrThc_23 >= trans__V_94_94);
#line 565 "trans.m"
        if (trans__succeeded)
          {
            MR_Float trans__Thc_24;
            MR_Float trans__DistToSurface1_25;
            MR_Float trans__DistToSurface2_26;
            MR_Word trans__IntersectionResult1_27;
            MR_Word trans__IntersectionResult2_28;
            MR_Word trans__V_32_32;
            MR_Word trans__V_33_33;

#line 555 "trans.m"
            {
#line 555 "trans.m"
              trans__Thc_24 = mercury__math__sqrt_2_f_0(trans__SqrThc_23);
            }
#line 556 "trans.m"
            trans__DistToSurface1_25 = (trans__Tca_20 - trans__Thc_24);
#line 557 "trans.m"
            trans__DistToSurface2_26 = (trans__Tca_20 + trans__Thc_24);
#line 559 "trans.m"
            {
#line 559 "trans.m"
              trans__intersects_sphere_2_11_p_0(trans__HeadVar__1_1, trans__DistToSurface1_25, trans__HeadVar__2_2, trans__V_74_74, trans__V_75_75, trans__V_76_76, trans__Dx_16, trans__Dy_17, trans__Dz_18, trans__HeadVar__5_5, &trans__IntersectionResult1_27);
            }
#line 561 "trans.m"
            {
#line 561 "trans.m"
              trans__intersects_sphere_2_11_p_0(trans__HeadVar__1_1, trans__DistToSurface2_26, trans__HeadVar__2_2, trans__V_74_74, trans__V_75_75, trans__V_76_76, trans__Dx_16, trans__Dy_17, trans__Dz_18, trans__HeadVar__5_5, &trans__IntersectionResult2_28);
            }
#line 563 "trans.m"
            trans__V_33_33 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 563 "trans.m"
            {
#line 563 "trans.m"
              trans__V_32_32 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 563 "trans.m"
              MR_hl_field(MR_mktag(1), trans__V_32_32, 0) = ((MR_Box) (trans__IntersectionResult2_28));
#line 563 "trans.m"
              MR_hl_field(MR_mktag(1), trans__V_32_32, 1) = ((MR_Box) (trans__V_33_33));
#line 563 "trans.m"
            }
#line 563 "trans.m"
            {
#line 563 "trans.m"
              *trans__HeadVar__6_6 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 563 "trans.m"
              MR_hl_field(MR_mktag(1), *trans__HeadVar__6_6, 0) = ((MR_Box) (trans__IntersectionResult1_27));
#line 563 "trans.m"
              MR_hl_field(MR_mktag(1), *trans__HeadVar__6_6, 1) = ((MR_Box) (trans__V_32_32));
#line 563 "trans.m"
            }
          }
#line 565 "trans.m"
        else
#line 566 "trans.m"
          *trans__HeadVar__6_6 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
      }
#line 568 "trans.m"
    else
#line 569 "trans.m"
      *trans__HeadVar__6_6 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
  }
#line 157 "trans.m"
}
#line 498 "trans.m"
static /* final */ const MR_Float trans__float_13_0_1 = (MR_Float) 0.00000000000000;
#line 498 "trans.m"
static /* final */ const MR_Float trans__float_13_0_2 = (MR_Float) 1.00000000000000;
#line 498 "trans.m"
static /* final */ const MR_Float trans__float_13_0_3 = (MR_Float) 0.00000000000000;
#line 498 "trans.m"
static /* final */ const MR_Box trans__const_13_0_4_V_28_28[3] = {
		(MR_Box) &trans__float_13_0_1,
		(MR_Box) &trans__float_13_0_2,
		(MR_Box) &trans__float_13_0_3};

#line 153 "trans.m"
void MR_CALL trans__intersects_plane_6_p_0(
#line 153 "trans.m"
  MR_Integer trans__HeadVar__1_1,
#line 153 "trans.m"
  MR_Word trans__HeadVar__2_2,
#line 153 "trans.m"
  MR_Word trans__HeadVar__3_3,
#line 153 "trans.m"
  MR_Word trans__HeadVar__4_4,
#line 153 "trans.m"
  MR_Word trans__HeadVar__5_5,
#line 153 "trans.m"
  MR_Word * trans__HeadVar__6_6)
#line 153 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Float trans__Dx_16;
    MR_Float trans__Dy_17;
    MR_Float trans__Dz_18;
    MR_Word trans__V_43_43;
    MR_Word trans__W_46 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__M11_51 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_46, (MR_Integer) 0)));
    MR_Float trans__M12_52 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_46, (MR_Integer) 1)));
    MR_Float trans__M13_53 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_46, (MR_Integer) 2)));
    MR_Float trans__M14_54 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_46, (MR_Integer) 3)));
    MR_Float trans__M21_55 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_46, (MR_Integer) 4)));
    MR_Float trans__M22_56 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_46, (MR_Integer) 5)));
    MR_Float trans__M23_57 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_46, (MR_Integer) 6)));
    MR_Float trans__M24_58 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_46, (MR_Integer) 7)));
    MR_Float trans__M31_59 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_46, (MR_Integer) 8)));
    MR_Float trans__M32_60 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_46, (MR_Integer) 9)));
    MR_Float trans__M33_61 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_46, (MR_Integer) 10)));
    MR_Float trans__M34_62 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_46, (MR_Integer) 11)));
    MR_Float trans__X_63 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 0)));
    MR_Float trans__Y_64 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 1)));
    MR_Float trans__Z_65 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, (MR_Integer) 2)));
    MR_Float trans__V_66_66;
    MR_Float trans__V_67_67;
    MR_Float trans__V_68_68;
    MR_Float trans__V_69_69;
    MR_Float trans__V_70_70;
    MR_Float trans__V_71_71;
    MR_Float trans__V_72_72 = (trans__M11_51 * trans__X_63);
    MR_Float trans__V_73_73 = (trans__M12_52 * trans__Y_64);
    MR_Float trans__V_74_74;
    MR_Float trans__V_75_75;
    MR_Float trans__V_76_76;
    MR_Float trans__V_77_77;
    MR_Float trans__V_78_78;
    MR_Float trans__V_79_79;
    MR_Float trans__V_80_80;
    MR_Float trans__V_81_81;
    MR_Float trans__V_82_82;
    MR_Float trans__V_83_83;
#line 286 "trans.m"
    MR_Word trans___M_45 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
#line 501 "trans.m"
    MR_Float trans__K_19;
    MR_Float trans__V_24_24;

#line 250 "trans.m"
    trans__V_70_70 = (trans__V_72_72 + trans__V_73_73);
#line 250 "trans.m"
    trans__V_71_71 = (trans__M13_53 * trans__Z_65);
#line 250 "trans.m"
    trans__V_69_69 = (trans__V_70_70 + trans__V_71_71);
#line 250 "trans.m"
    trans__V_66_66 = (trans__V_69_69 + trans__M14_54);
#line 251 "trans.m"
    trans__V_77_77 = (trans__M21_55 * trans__X_63);
#line 251 "trans.m"
    trans__V_78_78 = (trans__M22_56 * trans__Y_64);
#line 251 "trans.m"
    trans__V_75_75 = (trans__V_77_77 + trans__V_78_78);
#line 251 "trans.m"
    trans__V_76_76 = (trans__M23_57 * trans__Z_65);
#line 251 "trans.m"
    trans__V_74_74 = (trans__V_75_75 + trans__V_76_76);
#line 250 "trans.m"
    trans__V_67_67 = (trans__V_74_74 + trans__M24_58);
#line 252 "trans.m"
    trans__V_82_82 = (trans__M31_59 * trans__X_63);
#line 252 "trans.m"
    trans__V_83_83 = (trans__M32_60 * trans__Y_64);
#line 252 "trans.m"
    trans__V_80_80 = (trans__V_82_82 + trans__V_83_83);
#line 252 "trans.m"
    trans__V_81_81 = (trans__M33_61 * trans__Z_65);
#line 252 "trans.m"
    trans__V_79_79 = (trans__V_80_80 + trans__V_81_81);
#line 250 "trans.m"
    trans__V_68_68 = (trans__V_79_79 + trans__M34_62);
#line 480 "trans.m"
    {
#line 480 "trans.m"
      trans__V_43_43 = trans__vector_to_object_space_3_f_0(trans__HeadVar__2_2, trans__HeadVar__4_4);
    }
#line 480 "trans.m"
    trans__Dx_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_43_43, (MR_Integer) 0)));
#line 480 "trans.m"
    trans__Dy_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_43_43, (MR_Integer) 1)));
#line 480 "trans.m"
    trans__Dz_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__V_43_43, (MR_Integer) 2)));
#line 489 "trans.m"
    trans__succeeded = (trans__Dy_17 == ((MR_Float) 0.00000000000000));
#line 489 "trans.m"
    trans__succeeded = !(trans__succeeded);
    if (trans__succeeded)
      {
#line 490 "trans.m"
        trans__V_24_24 = (((MR_Float) 0.00000000000000) - trans__V_67_67);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__intersects_plane_6_p_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__Dy_17 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_87;
            MR_String trans__V_8_88 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_89;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_87 = (MR_Word) trans__V_8_88;
            trans__TypeInfo_9_89 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_89, ((MR_Box) (trans__V_7_87)));
            }
            trans__succeeded = TRUE;
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
          {
            MR_Float trans__V_90_90;

#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__K_19 = (trans__V_24_24 / trans__Dy_17);
#line 491 "trans.m"
            trans__V_90_90 = (MR_Float) 0.00000000000000;
#line 491 "trans.m"
            trans__succeeded = (trans__K_19 > trans__V_90_90);
          }
      }
#line 501 "trans.m"
    if (trans__succeeded)
      {
        MR_Word trans__POI_20;
        MR_Word trans__TC_21;
        MR_Word trans__N_22;
        MR_Word trans__V_25_25;
        MR_Word trans__V_26_26;
        MR_Word trans__V_27_27;
        MR_Word trans__V_28_28;
        MR_Float trans__V_29_29;
        MR_Float trans__V_30_30;
        MR_Float trans__V_31_31;
        MR_Integer trans__V_32_32;
        MR_Float trans__V_33_33;
        MR_Float trans__V_34_34;
        MR_Float trans__V_35_35;
        MR_Float trans__V_36_36;
        MR_Word trans__V_37_37;
        MR_Float trans__V_38_38;
        MR_Float trans__V_39_39;
        MR_Float trans__V_40_40;
        MR_Float trans__V_41_41 = (trans__K_19 * trans__Dx_16);
        MR_Float trans__V_42_42;

#line 493 "trans.m"
        trans__V_38_38 = (trans__V_66_66 + trans__V_41_41);
#line 493 "trans.m"
        trans__V_39_39 = (MR_Float) 0.00000000000000;
#line 493 "trans.m"
        trans__V_42_42 = (trans__K_19 * trans__Dz_18);
#line 493 "trans.m"
        trans__V_40_40 = (trans__V_68_68 + trans__V_42_42);
#line 493 "trans.m"
        {
#line 493 "trans.m"
          trans__V_37_37 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 493 "trans.m"
          MR_hl_field(MR_mktag(0), trans__V_37_37, 0) = MR_box_float(trans__V_38_38);
#line 493 "trans.m"
          MR_hl_field(MR_mktag(0), trans__V_37_37, 1) = MR_box_float(trans__V_39_39);
#line 493 "trans.m"
          MR_hl_field(MR_mktag(0), trans__V_37_37, 2) = MR_box_float(trans__V_40_40);
#line 493 "trans.m"
        }
#line 493 "trans.m"
        {
#line 493 "trans.m"
          trans__POI_20 = trans__point_to_world_space_3_f_0(trans__HeadVar__2_2, trans__V_37_37);
        }
#line 494 "trans.m"
        trans__V_32_32 = (MR_Integer) 0;
#line 494 "trans.m"
        trans__V_35_35 = (trans__K_19 * trans__Dx_16);
#line 494 "trans.m"
        trans__V_33_33 = (trans__V_66_66 + trans__V_35_35);
#line 494 "trans.m"
        trans__V_36_36 = (trans__K_19 * trans__Dz_18);
#line 494 "trans.m"
        trans__V_34_34 = (trans__V_68_68 + trans__V_36_36);
#line 494 "trans.m"
        {
#line 494 "trans.m"
          trans__TC_21 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "surface_coordinates");
#line 494 "trans.m"
          MR_hl_field(MR_mktag(0), trans__TC_21, 0) = ((MR_Box) (trans__V_32_32));
#line 494 "trans.m"
          MR_hl_field(MR_mktag(0), trans__TC_21, 1) = MR_box_float(trans__V_33_33);
#line 494 "trans.m"
          MR_hl_field(MR_mktag(0), trans__TC_21, 2) = MR_box_float(trans__V_34_34);
#line 494 "trans.m"
        }
#line 498 "trans.m"
        trans__V_29_29 = (MR_Float) 0.00000000000000;
#line 498 "trans.m"
        trans__V_30_30 = (MR_Float) 1.00000000000000;
#line 498 "trans.m"
        trans__V_31_31 = (MR_Float) 0.00000000000000;
#line 498 "trans.m"
        trans__V_28_28 = (MR_Word) &trans__const_13_0_4_V_28_28;
#line 498 "trans.m"
        {
#line 498 "trans.m"
          trans__V_27_27 = trans__vector_to_world_space_3_f_0(trans__HeadVar__2_2, trans__V_28_28);
        }
#line 498 "trans.m"
        {
#line 498 "trans.m"
          trans__N_22 = vector__unit_2_f_0(trans__V_27_27);
        }
#line 500 "trans.m"
        {
#line 500 "trans.m"
          trans__V_25_25 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 5 * sizeof(MR_Word)), "intersection");
#line 500 "trans.m"
          MR_hl_field(MR_mktag(0), trans__V_25_25, 0) = ((MR_Box) (trans__HeadVar__1_1));
#line 500 "trans.m"
          MR_hl_field(MR_mktag(0), trans__V_25_25, 1) = ((MR_Box) (trans__POI_20));
#line 500 "trans.m"
          MR_hl_field(MR_mktag(0), trans__V_25_25, 2) = ((MR_Box) (trans__N_22));
#line 500 "trans.m"
          MR_hl_field(MR_mktag(0), trans__V_25_25, 3) = ((MR_Box) (trans__TC_21));
#line 500 "trans.m"
          MR_hl_field(MR_mktag(0), trans__V_25_25, 4) = ((MR_Box) (trans__HeadVar__5_5));
#line 500 "trans.m"
        }
#line 500 "trans.m"
        trans__V_26_26 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
#line 500 "trans.m"
        {
#line 500 "trans.m"
          *trans__HeadVar__6_6 = (MR_Word) MR_mkword(MR_mktag(1), MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "[|]"));
#line 500 "trans.m"
          MR_hl_field(MR_mktag(1), *trans__HeadVar__6_6, 0) = ((MR_Box) (trans__V_25_25));
#line 500 "trans.m"
          MR_hl_field(MR_mktag(1), *trans__HeadVar__6_6, 1) = ((MR_Box) (trans__V_26_26));
#line 500 "trans.m"
        }
      }
#line 501 "trans.m"
    else
#line 502 "trans.m"
      *trans__HeadVar__6_6 = (MR_Word) MR_mkword(MR_mktag(0), MR_mkbody((MR_Integer) 0));
  }
#line 153 "trans.m"
}

#line 127 "trans.m"
MR_Word MR_CALL trans__compose_rotatez_3_f_0(
#line 127 "trans.m"
  MR_Float trans__HeadVar__1_1,
#line 127 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 127 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__3_3;
    MR_Word trans__M0_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word trans__W0_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word trans__M_7;
    MR_Word trans__W_8;
    MR_Float trans__RRz_9;
    MR_Float trans__C_10;
    MR_Float trans__S_11;
    MR_Float trans__M11_12;
    MR_Float trans__M12_13;
    MR_Float trans__M13_14;
    MR_Float trans__M14_15;
    MR_Float trans__M21_16;
    MR_Float trans__M22_17;
    MR_Float trans__M23_18;
    MR_Float trans__M24_19;
    MR_Float trans__M31_20;
    MR_Float trans__M32_21;
    MR_Float trans__M33_22;
    MR_Float trans__M34_23;
    MR_Float trans__W11_24;
    MR_Float trans__W12_25;
    MR_Float trans__W13_26;
    MR_Float trans__W14_27;
    MR_Float trans__W21_28;
    MR_Float trans__W22_29;
    MR_Float trans__W23_30;
    MR_Float trans__W24_31;
    MR_Float trans__W31_32;
    MR_Float trans__W32_33;
    MR_Float trans__W33_34;
    MR_Float trans__W34_35;
    MR_Float trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40;
    MR_Float trans__V_41_41;
    MR_Float trans__V_42_42;
    MR_Float trans__V_43_43;
    MR_Float trans__V_44_44;
    MR_Float trans__V_45_45;
    MR_Float trans__V_46_46;
    MR_Float trans__V_47_47;
    MR_Float trans__V_48_48;
    MR_Float trans__V_49_49;
    MR_Float trans__V_50_50;
    MR_Float trans__V_51_51;
    MR_Float trans__V_52_52;
    MR_Float trans__V_53_53;
    MR_Float trans__V_54_54;
    MR_Float trans__V_55_55;
    MR_Float trans__V_56_56;
    MR_Float trans__V_57_57;
    MR_Float trans__V_58_58;
    MR_Float trans__V_59_59;
    MR_Float trans__V_60_60;
    MR_Float trans__V_61_61;
    MR_Float trans__V_62_62;
    MR_Float trans__V_63_63;
    MR_Float trans__V_64_64;
    MR_Float trans__V_65_65;
    MR_Float trans__V_66_66;
    MR_Float trans__V_67_67;
    MR_Float trans__V_68_68;
    MR_Float trans__V_69_69;
    MR_Float trans__V_70_70;
    MR_Float trans__V_71_71;
    MR_Float trans__V_72_72;
    MR_Float trans__V_73_73;
    MR_Float trans__V_74_74;
    MR_Float trans__V_75_75;
    MR_Float trans__V_76_76;
    MR_Float trans__V_77_77;
    MR_Float trans__V_78_78;
    MR_Float trans__V_79_79;
    MR_Float trans__V_80_80;
    MR_Float trans__V_82_82;
    MR_Float trans__V_83_83;
    MR_Float trans__V_84_84;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__compose_rotatez_3_f_0
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__V_84_84
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 437 "trans.m"
    trans__V_82_82 = (trans__HeadVar__1_1 * trans__V_84_84);
#line 437 "trans.m"
    trans__V_83_83 = (MR_Float) 180.000000000000;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_rotatez_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      trans__succeeded = (trans__V_83_83 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (trans__succeeded)
      {
        MR_Word trans__V_7_89;
        MR_String trans__V_8_90 = (MR_String) "float:'/'";
        MR_Word trans__TypeInfo_9_91;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        trans__V_7_89 = (MR_Word) trans__V_8_90;
        trans__TypeInfo_9_91 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(trans__TypeInfo_9_91, ((MR_Box) (trans__V_7_89)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      trans__RRz_9 = (trans__V_82_82 / trans__V_83_83);
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__compose_rotatez_3_f_0
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Cos;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__RRz_9
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__C_10
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Cos;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__compose_rotatez_3_f_0
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Sin;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__RRz_9
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);

#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__S_11
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Sin;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 421 "trans.m"
    trans__M11_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 0)));
#line 421 "trans.m"
    trans__M12_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 1)));
#line 421 "trans.m"
    trans__M13_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 2)));
#line 421 "trans.m"
    trans__M14_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 3)));
#line 421 "trans.m"
    trans__M21_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 4)));
#line 421 "trans.m"
    trans__M22_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 5)));
#line 421 "trans.m"
    trans__M23_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 6)));
#line 421 "trans.m"
    trans__M24_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 7)));
#line 421 "trans.m"
    trans__M31_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 8)));
#line 421 "trans.m"
    trans__M32_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 9)));
#line 421 "trans.m"
    trans__M33_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 10)));
#line 421 "trans.m"
    trans__M34_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 11)));
#line 424 "trans.m"
    trans__V_65_65 = (trans__C_10 * trans__M11_12);
#line 424 "trans.m"
    trans__V_66_66 = (trans__S_11 * trans__M21_16);
#line 424 "trans.m"
    trans__V_57_57 = (trans__V_65_65 - trans__V_66_66);
#line 424 "trans.m"
    trans__V_67_67 = (trans__C_10 * trans__M12_13);
#line 424 "trans.m"
    trans__V_68_68 = (trans__S_11 * trans__M22_17);
#line 424 "trans.m"
    trans__V_58_58 = (trans__V_67_67 - trans__V_68_68);
#line 424 "trans.m"
    trans__V_69_69 = (trans__C_10 * trans__M13_14);
#line 424 "trans.m"
    trans__V_70_70 = (trans__S_11 * trans__M23_18);
#line 424 "trans.m"
    trans__V_59_59 = (trans__V_69_69 - trans__V_70_70);
#line 424 "trans.m"
    trans__V_71_71 = (trans__C_10 * trans__M14_15);
#line 424 "trans.m"
    trans__V_72_72 = (trans__S_11 * trans__M24_19);
#line 424 "trans.m"
    trans__V_60_60 = (trans__V_71_71 - trans__V_72_72);
#line 425 "trans.m"
    trans__V_73_73 = (trans__S_11 * trans__M11_12);
#line 425 "trans.m"
    trans__V_74_74 = (trans__C_10 * trans__M21_16);
#line 424 "trans.m"
    trans__V_61_61 = (trans__V_73_73 + trans__V_74_74);
#line 425 "trans.m"
    trans__V_75_75 = (trans__S_11 * trans__M12_13);
#line 425 "trans.m"
    trans__V_76_76 = (trans__C_10 * trans__M22_17);
#line 424 "trans.m"
    trans__V_62_62 = (trans__V_75_75 + trans__V_76_76);
#line 425 "trans.m"
    trans__V_77_77 = (trans__S_11 * trans__M13_14);
#line 425 "trans.m"
    trans__V_78_78 = (trans__C_10 * trans__M23_18);
#line 424 "trans.m"
    trans__V_63_63 = (trans__V_77_77 + trans__V_78_78);
#line 425 "trans.m"
    trans__V_79_79 = (trans__S_11 * trans__M14_15);
#line 425 "trans.m"
    trans__V_80_80 = (trans__C_10 * trans__M24_19);
#line 424 "trans.m"
    trans__V_64_64 = (trans__V_79_79 + trans__V_80_80);
#line 424 "trans.m"
    {
#line 424 "trans.m"
      trans__M_7 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 12 * sizeof(MR_Word)), "matrix");
#line 424 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 0) = MR_box_float(trans__V_57_57);
#line 424 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 1) = MR_box_float(trans__V_58_58);
#line 424 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 2) = MR_box_float(trans__V_59_59);
#line 424 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 3) = MR_box_float(trans__V_60_60);
#line 424 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 4) = MR_box_float(trans__V_61_61);
#line 424 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 5) = MR_box_float(trans__V_62_62);
#line 424 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 6) = MR_box_float(trans__V_63_63);
#line 424 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 7) = MR_box_float(trans__V_64_64);
#line 424 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 8) = MR_box_float(trans__M31_20);
#line 424 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 9) = MR_box_float(trans__M32_21);
#line 424 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 10) = MR_box_float(trans__M33_22);
#line 424 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 11) = MR_box_float(trans__M34_23);
#line 424 "trans.m"
    }
#line 428 "trans.m"
    trans__W11_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 0)));
#line 428 "trans.m"
    trans__W12_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 1)));
#line 428 "trans.m"
    trans__W13_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 2)));
#line 428 "trans.m"
    trans__W14_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 3)));
#line 428 "trans.m"
    trans__W21_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 4)));
#line 428 "trans.m"
    trans__W22_29 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 5)));
#line 428 "trans.m"
    trans__W23_30 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 6)));
#line 428 "trans.m"
    trans__W24_31 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 7)));
#line 428 "trans.m"
    trans__W31_32 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 8)));
#line 428 "trans.m"
    trans__W32_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 9)));
#line 428 "trans.m"
    trans__W33_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 10)));
#line 428 "trans.m"
    trans__W34_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 11)));
#line 431 "trans.m"
    trans__V_44_44 = (((MR_Float) 0.00000000000000) - trans__S_11);
#line 431 "trans.m"
    trans__V_42_42 = (trans__V_44_44 * trans__W12_25);
#line 431 "trans.m"
    trans__V_43_43 = (trans__C_10 * trans__W11_24);
#line 431 "trans.m"
    trans__V_36_36 = (trans__V_42_42 + trans__V_43_43);
#line 431 "trans.m"
    trans__V_45_45 = (trans__S_11 * trans__W11_24);
#line 431 "trans.m"
    trans__V_46_46 = (trans__C_10 * trans__W12_25);
#line 431 "trans.m"
    trans__V_37_37 = (trans__V_45_45 + trans__V_46_46);
#line 432 "trans.m"
    trans__V_49_49 = (((MR_Float) 0.00000000000000) - trans__S_11);
#line 432 "trans.m"
    trans__V_47_47 = (trans__V_49_49 * trans__W22_29);
#line 432 "trans.m"
    trans__V_48_48 = (trans__C_10 * trans__W21_28);
#line 431 "trans.m"
    trans__V_38_38 = (trans__V_47_47 + trans__V_48_48);
#line 432 "trans.m"
    trans__V_50_50 = (trans__S_11 * trans__W21_28);
#line 432 "trans.m"
    trans__V_51_51 = (trans__C_10 * trans__W22_29);
#line 431 "trans.m"
    trans__V_39_39 = (trans__V_50_50 + trans__V_51_51);
#line 433 "trans.m"
    trans__V_54_54 = (((MR_Float) 0.00000000000000) - trans__S_11);
#line 433 "trans.m"
    trans__V_52_52 = (trans__V_54_54 * trans__W32_33);
#line 433 "trans.m"
    trans__V_53_53 = (trans__C_10 * trans__W31_32);
#line 431 "trans.m"
    trans__V_40_40 = (trans__V_52_52 + trans__V_53_53);
#line 433 "trans.m"
    trans__V_55_55 = (trans__S_11 * trans__W31_32);
#line 433 "trans.m"
    trans__V_56_56 = (trans__C_10 * trans__W32_33);
#line 431 "trans.m"
    trans__V_41_41 = (trans__V_55_55 + trans__V_56_56);
#line 431 "trans.m"
    {
#line 431 "trans.m"
      trans__W_8 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 12 * sizeof(MR_Word)), "matrix");
#line 431 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 0) = MR_box_float(trans__V_36_36);
#line 431 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 1) = MR_box_float(trans__V_37_37);
#line 431 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 2) = MR_box_float(trans__W13_26);
#line 431 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 3) = MR_box_float(trans__W14_27);
#line 431 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 4) = MR_box_float(trans__V_38_38);
#line 431 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 5) = MR_box_float(trans__V_39_39);
#line 431 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 6) = MR_box_float(trans__W23_30);
#line 431 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 7) = MR_box_float(trans__W24_31);
#line 431 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 8) = MR_box_float(trans__V_40_40);
#line 431 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 9) = MR_box_float(trans__V_41_41);
#line 431 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 10) = MR_box_float(trans__W33_34);
#line 431 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 11) = MR_box_float(trans__W34_35);
#line 431 "trans.m"
    }
#line 415 "trans.m"
    {
#line 415 "trans.m"
      trans__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "trans");
#line 415 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 0) = ((MR_Box) (trans__M_7));
#line 415 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 1) = ((MR_Box) (trans__W_8));
#line 415 "trans.m"
    }
    return trans__HeadVar__3_3;
  }
#line 127 "trans.m"
}

#line 123 "trans.m"
MR_Word MR_CALL trans__compose_rotatey_3_f_0(
#line 123 "trans.m"
  MR_Float trans__HeadVar__1_1,
#line 123 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 123 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__3_3;
    MR_Word trans__M0_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word trans__W0_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word trans__M_7;
    MR_Word trans__W_8;
    MR_Float trans__RRy_9;
    MR_Float trans__C_10;
    MR_Float trans__S_11;
    MR_Float trans__M11_12;
    MR_Float trans__M12_13;
    MR_Float trans__M13_14;
    MR_Float trans__M14_15;
    MR_Float trans__M21_16;
    MR_Float trans__M22_17;
    MR_Float trans__M23_18;
    MR_Float trans__M24_19;
    MR_Float trans__M31_20;
    MR_Float trans__M32_21;
    MR_Float trans__M33_22;
    MR_Float trans__M34_23;
    MR_Float trans__W11_24;
    MR_Float trans__W12_25;
    MR_Float trans__W13_26;
    MR_Float trans__W14_27;
    MR_Float trans__W21_28;
    MR_Float trans__W22_29;
    MR_Float trans__W23_30;
    MR_Float trans__W24_31;
    MR_Float trans__W31_32;
    MR_Float trans__W32_33;
    MR_Float trans__W33_34;
    MR_Float trans__W34_35;
    MR_Float trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40;
    MR_Float trans__V_41_41;
    MR_Float trans__V_42_42;
    MR_Float trans__V_43_43;
    MR_Float trans__V_44_44;
    MR_Float trans__V_45_45;
    MR_Float trans__V_46_46;
    MR_Float trans__V_47_47;
    MR_Float trans__V_48_48;
    MR_Float trans__V_49_49;
    MR_Float trans__V_50_50;
    MR_Float trans__V_51_51;
    MR_Float trans__V_52_52;
    MR_Float trans__V_53_53;
    MR_Float trans__V_54_54;
    MR_Float trans__V_55_55;
    MR_Float trans__V_56_56;
    MR_Float trans__V_57_57;
    MR_Float trans__V_58_58;
    MR_Float trans__V_59_59;
    MR_Float trans__V_60_60;
    MR_Float trans__V_61_61;
    MR_Float trans__V_62_62;
    MR_Float trans__V_63_63;
    MR_Float trans__V_64_64;
    MR_Float trans__V_65_65;
    MR_Float trans__V_66_66;
    MR_Float trans__V_67_67;
    MR_Float trans__V_68_68;
    MR_Float trans__V_69_69;
    MR_Float trans__V_70_70;
    MR_Float trans__V_71_71;
    MR_Float trans__V_72_72;
    MR_Float trans__V_73_73;
    MR_Float trans__V_74_74;
    MR_Float trans__V_75_75;
    MR_Float trans__V_76_76;
    MR_Float trans__V_77_77;
    MR_Float trans__V_78_78;
    MR_Float trans__V_79_79;
    MR_Float trans__V_80_80;
    MR_Float trans__V_82_82;
    MR_Float trans__V_83_83;
    MR_Float trans__V_84_84;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__compose_rotatey_3_f_0
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__V_84_84
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 437 "trans.m"
    trans__V_82_82 = (trans__HeadVar__1_1 * trans__V_84_84);
#line 437 "trans.m"
    trans__V_83_83 = (MR_Float) 180.000000000000;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_rotatey_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      trans__succeeded = (trans__V_83_83 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (trans__succeeded)
      {
        MR_Word trans__V_7_89;
        MR_String trans__V_8_90 = (MR_String) "float:'/'";
        MR_Word trans__TypeInfo_9_91;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        trans__V_7_89 = (MR_Word) trans__V_8_90;
        trans__TypeInfo_9_91 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(trans__TypeInfo_9_91, ((MR_Box) (trans__V_7_89)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      trans__RRy_9 = (trans__V_82_82 / trans__V_83_83);
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__compose_rotatey_3_f_0
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Cos;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__RRy_9
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__C_10
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Cos;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__compose_rotatey_3_f_0
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Sin;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__RRy_9
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);

#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__S_11
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Sin;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 399 "trans.m"
    trans__M11_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 0)));
#line 399 "trans.m"
    trans__M12_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 1)));
#line 399 "trans.m"
    trans__M13_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 2)));
#line 399 "trans.m"
    trans__M14_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 3)));
#line 399 "trans.m"
    trans__M21_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 4)));
#line 399 "trans.m"
    trans__M22_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 5)));
#line 399 "trans.m"
    trans__M23_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 6)));
#line 399 "trans.m"
    trans__M24_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 7)));
#line 399 "trans.m"
    trans__M31_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 8)));
#line 399 "trans.m"
    trans__M32_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 9)));
#line 399 "trans.m"
    trans__M33_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 10)));
#line 399 "trans.m"
    trans__M34_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 11)));
#line 402 "trans.m"
    trans__V_65_65 = (trans__C_10 * trans__M11_12);
#line 402 "trans.m"
    trans__V_66_66 = (trans__S_11 * trans__M31_20);
#line 402 "trans.m"
    trans__V_57_57 = (trans__V_65_65 + trans__V_66_66);
#line 402 "trans.m"
    trans__V_67_67 = (trans__C_10 * trans__M12_13);
#line 402 "trans.m"
    trans__V_68_68 = (trans__S_11 * trans__M32_21);
#line 402 "trans.m"
    trans__V_58_58 = (trans__V_67_67 + trans__V_68_68);
#line 402 "trans.m"
    trans__V_69_69 = (trans__C_10 * trans__M13_14);
#line 402 "trans.m"
    trans__V_70_70 = (trans__S_11 * trans__M33_22);
#line 402 "trans.m"
    trans__V_59_59 = (trans__V_69_69 + trans__V_70_70);
#line 402 "trans.m"
    trans__V_71_71 = (trans__C_10 * trans__M14_15);
#line 402 "trans.m"
    trans__V_72_72 = (trans__S_11 * trans__M34_23);
#line 402 "trans.m"
    trans__V_60_60 = (trans__V_71_71 + trans__V_72_72);
#line 404 "trans.m"
    trans__V_73_73 = (trans__C_10 * trans__M31_20);
#line 404 "trans.m"
    trans__V_74_74 = (trans__S_11 * trans__M11_12);
#line 402 "trans.m"
    trans__V_61_61 = (trans__V_73_73 - trans__V_74_74);
#line 404 "trans.m"
    trans__V_75_75 = (trans__C_10 * trans__M32_21);
#line 404 "trans.m"
    trans__V_76_76 = (trans__S_11 * trans__M12_13);
#line 402 "trans.m"
    trans__V_62_62 = (trans__V_75_75 - trans__V_76_76);
#line 404 "trans.m"
    trans__V_77_77 = (trans__C_10 * trans__M33_22);
#line 404 "trans.m"
    trans__V_78_78 = (trans__S_11 * trans__M13_14);
#line 402 "trans.m"
    trans__V_63_63 = (trans__V_77_77 - trans__V_78_78);
#line 404 "trans.m"
    trans__V_79_79 = (trans__C_10 * trans__M34_23);
#line 404 "trans.m"
    trans__V_80_80 = (trans__S_11 * trans__M14_15);
#line 402 "trans.m"
    trans__V_64_64 = (trans__V_79_79 - trans__V_80_80);
#line 402 "trans.m"
    {
#line 402 "trans.m"
      trans__M_7 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 12 * sizeof(MR_Word)), "matrix");
#line 402 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 0) = MR_box_float(trans__V_57_57);
#line 402 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 1) = MR_box_float(trans__V_58_58);
#line 402 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 2) = MR_box_float(trans__V_59_59);
#line 402 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 3) = MR_box_float(trans__V_60_60);
#line 402 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 4) = MR_box_float(trans__M21_16);
#line 402 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 5) = MR_box_float(trans__M22_17);
#line 402 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 6) = MR_box_float(trans__M23_18);
#line 402 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 7) = MR_box_float(trans__M24_19);
#line 402 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 8) = MR_box_float(trans__V_61_61);
#line 402 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 9) = MR_box_float(trans__V_62_62);
#line 402 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 10) = MR_box_float(trans__V_63_63);
#line 402 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 11) = MR_box_float(trans__V_64_64);
#line 402 "trans.m"
    }
#line 406 "trans.m"
    trans__W11_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 0)));
#line 406 "trans.m"
    trans__W12_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 1)));
#line 406 "trans.m"
    trans__W13_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 2)));
#line 406 "trans.m"
    trans__W14_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 3)));
#line 406 "trans.m"
    trans__W21_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 4)));
#line 406 "trans.m"
    trans__W22_29 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 5)));
#line 406 "trans.m"
    trans__W23_30 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 6)));
#line 406 "trans.m"
    trans__W24_31 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 7)));
#line 406 "trans.m"
    trans__W31_32 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 8)));
#line 406 "trans.m"
    trans__W32_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 9)));
#line 406 "trans.m"
    trans__W33_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 10)));
#line 406 "trans.m"
    trans__W34_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 11)));
#line 409 "trans.m"
    trans__V_42_42 = (trans__C_10 * trans__W11_24);
#line 409 "trans.m"
    trans__V_43_43 = (trans__S_11 * trans__W13_26);
#line 409 "trans.m"
    trans__V_36_36 = (trans__V_42_42 + trans__V_43_43);
#line 409 "trans.m"
    trans__V_46_46 = (((MR_Float) 0.00000000000000) - trans__S_11);
#line 409 "trans.m"
    trans__V_44_44 = (trans__V_46_46 * trans__W11_24);
#line 409 "trans.m"
    trans__V_45_45 = (trans__C_10 * trans__W13_26);
#line 409 "trans.m"
    trans__V_37_37 = (trans__V_44_44 + trans__V_45_45);
#line 410 "trans.m"
    trans__V_47_47 = (trans__C_10 * trans__W21_28);
#line 410 "trans.m"
    trans__V_48_48 = (trans__S_11 * trans__W23_30);
#line 409 "trans.m"
    trans__V_38_38 = (trans__V_47_47 + trans__V_48_48);
#line 410 "trans.m"
    trans__V_51_51 = (((MR_Float) 0.00000000000000) - trans__S_11);
#line 410 "trans.m"
    trans__V_49_49 = (trans__V_51_51 * trans__W21_28);
#line 410 "trans.m"
    trans__V_50_50 = (trans__C_10 * trans__W23_30);
#line 409 "trans.m"
    trans__V_39_39 = (trans__V_49_49 + trans__V_50_50);
#line 411 "trans.m"
    trans__V_52_52 = (trans__C_10 * trans__W31_32);
#line 411 "trans.m"
    trans__V_53_53 = (trans__S_11 * trans__W33_34);
#line 409 "trans.m"
    trans__V_40_40 = (trans__V_52_52 + trans__V_53_53);
#line 411 "trans.m"
    trans__V_56_56 = (((MR_Float) 0.00000000000000) - trans__S_11);
#line 411 "trans.m"
    trans__V_54_54 = (trans__V_56_56 * trans__W31_32);
#line 411 "trans.m"
    trans__V_55_55 = (trans__C_10 * trans__W33_34);
#line 409 "trans.m"
    trans__V_41_41 = (trans__V_54_54 + trans__V_55_55);
#line 409 "trans.m"
    {
#line 409 "trans.m"
      trans__W_8 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 12 * sizeof(MR_Word)), "matrix");
#line 409 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 0) = MR_box_float(trans__V_36_36);
#line 409 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 1) = MR_box_float(trans__W12_25);
#line 409 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 2) = MR_box_float(trans__V_37_37);
#line 409 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 3) = MR_box_float(trans__W14_27);
#line 409 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 4) = MR_box_float(trans__V_38_38);
#line 409 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 5) = MR_box_float(trans__W22_29);
#line 409 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 6) = MR_box_float(trans__V_39_39);
#line 409 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 7) = MR_box_float(trans__W24_31);
#line 409 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 8) = MR_box_float(trans__V_40_40);
#line 409 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 9) = MR_box_float(trans__W32_33);
#line 409 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 10) = MR_box_float(trans__V_41_41);
#line 409 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 11) = MR_box_float(trans__W34_35);
#line 409 "trans.m"
    }
#line 393 "trans.m"
    {
#line 393 "trans.m"
      trans__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "trans");
#line 393 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 0) = ((MR_Box) (trans__M_7));
#line 393 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 1) = ((MR_Box) (trans__W_8));
#line 393 "trans.m"
    }
    return trans__HeadVar__3_3;
  }
#line 123 "trans.m"
}

#line 119 "trans.m"
MR_Word MR_CALL trans__compose_rotatex_3_f_0(
#line 119 "trans.m"
  MR_Float trans__HeadVar__1_1,
#line 119 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 119 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__3_3;
    MR_Word trans__M0_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word trans__W0_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word trans__M_7;
    MR_Word trans__W_8;
    MR_Float trans__RRx_9;
    MR_Float trans__C_10;
    MR_Float trans__S_11;
    MR_Float trans__M11_12;
    MR_Float trans__M12_13;
    MR_Float trans__M13_14;
    MR_Float trans__M14_15;
    MR_Float trans__M21_16;
    MR_Float trans__M22_17;
    MR_Float trans__M23_18;
    MR_Float trans__M24_19;
    MR_Float trans__M31_20;
    MR_Float trans__M32_21;
    MR_Float trans__M33_22;
    MR_Float trans__M34_23;
    MR_Float trans__W11_24;
    MR_Float trans__W12_25;
    MR_Float trans__W13_26;
    MR_Float trans__W14_27;
    MR_Float trans__W21_28;
    MR_Float trans__W22_29;
    MR_Float trans__W23_30;
    MR_Float trans__W24_31;
    MR_Float trans__W31_32;
    MR_Float trans__W32_33;
    MR_Float trans__W33_34;
    MR_Float trans__W34_35;
    MR_Float trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40;
    MR_Float trans__V_41_41;
    MR_Float trans__V_42_42;
    MR_Float trans__V_43_43;
    MR_Float trans__V_44_44;
    MR_Float trans__V_45_45;
    MR_Float trans__V_46_46;
    MR_Float trans__V_47_47;
    MR_Float trans__V_48_48;
    MR_Float trans__V_49_49;
    MR_Float trans__V_50_50;
    MR_Float trans__V_51_51;
    MR_Float trans__V_52_52;
    MR_Float trans__V_53_53;
    MR_Float trans__V_54_54;
    MR_Float trans__V_55_55;
    MR_Float trans__V_56_56;
    MR_Float trans__V_57_57;
    MR_Float trans__V_58_58;
    MR_Float trans__V_59_59;
    MR_Float trans__V_60_60;
    MR_Float trans__V_61_61;
    MR_Float trans__V_62_62;
    MR_Float trans__V_63_63;
    MR_Float trans__V_64_64;
    MR_Float trans__V_65_65;
    MR_Float trans__V_66_66;
    MR_Float trans__V_67_67;
    MR_Float trans__V_68_68;
    MR_Float trans__V_69_69;
    MR_Float trans__V_70_70;
    MR_Float trans__V_71_71;
    MR_Float trans__V_72_72;
    MR_Float trans__V_73_73;
    MR_Float trans__V_74_74;
    MR_Float trans__V_75_75;
    MR_Float trans__V_76_76;
    MR_Float trans__V_77_77;
    MR_Float trans__V_79_79;
    MR_Float trans__V_80_80;
    MR_Float trans__V_81_81;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__compose_rotatex_3_f_0
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Pi = ML_FLOAT_PI;

#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__V_81_81
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Pi;
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 21 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 437 "trans.m"
    trans__V_79_79 = (trans__HeadVar__1_1 * trans__V_81_81);
#line 437 "trans.m"
    trans__V_80_80 = (MR_Float) 180.000000000000;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_rotatex_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
    if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      trans__succeeded = (trans__V_80_80 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    if (trans__succeeded)
      {
        MR_Word trans__V_7_86;
        MR_String trans__V_8_87 = (MR_String) "float:'/'";
        MR_Word trans__TypeInfo_9_88;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        trans__V_7_86 = (MR_Word) trans__V_8_87;
        trans__TypeInfo_9_88 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          mercury__exception__throw_1_p_0(trans__TypeInfo_9_88, ((MR_Box) (trans__V_7_86)));
        }
      }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
    else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
      trans__RRx_9 = (trans__V_79_79 / trans__V_80_80);
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__compose_rotatex_3_f_0
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Cos;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__RRx_9
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Cos = cos(X);

#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__C_10
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Cos;
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 51 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#define MR_PROC_LABEL trans__compose_rotatex_3_f_0
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float X;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	MR_Float Sin;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	X = 
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__RRx_9
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
		{
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

	Sin = sin(X);

#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"

		;}
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#undef MR_PROC_LABEL
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
	
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
trans__S_11
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
 = Sin;
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
#line 48 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/math.opt"
}
#line 377 "trans.m"
    trans__M11_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 0)));
#line 377 "trans.m"
    trans__M12_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 1)));
#line 377 "trans.m"
    trans__M13_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 2)));
#line 377 "trans.m"
    trans__M14_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 3)));
#line 377 "trans.m"
    trans__M21_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 4)));
#line 377 "trans.m"
    trans__M22_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 5)));
#line 377 "trans.m"
    trans__M23_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 6)));
#line 377 "trans.m"
    trans__M24_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 7)));
#line 377 "trans.m"
    trans__M31_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 8)));
#line 377 "trans.m"
    trans__M32_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 9)));
#line 377 "trans.m"
    trans__M33_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 10)));
#line 377 "trans.m"
    trans__M34_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 11)));
#line 381 "trans.m"
    trans__V_62_62 = (trans__C_10 * trans__M21_16);
#line 381 "trans.m"
    trans__V_63_63 = (trans__S_11 * trans__M31_20);
#line 380 "trans.m"
    trans__V_54_54 = (trans__V_62_62 - trans__V_63_63);
#line 381 "trans.m"
    trans__V_64_64 = (trans__C_10 * trans__M22_17);
#line 381 "trans.m"
    trans__V_65_65 = (trans__S_11 * trans__M32_21);
#line 380 "trans.m"
    trans__V_55_55 = (trans__V_64_64 - trans__V_65_65);
#line 381 "trans.m"
    trans__V_66_66 = (trans__C_10 * trans__M23_18);
#line 381 "trans.m"
    trans__V_67_67 = (trans__S_11 * trans__M33_22);
#line 380 "trans.m"
    trans__V_56_56 = (trans__V_66_66 - trans__V_67_67);
#line 381 "trans.m"
    trans__V_68_68 = (trans__C_10 * trans__M24_19);
#line 381 "trans.m"
    trans__V_69_69 = (trans__S_11 * trans__M34_23);
#line 380 "trans.m"
    trans__V_57_57 = (trans__V_68_68 - trans__V_69_69);
#line 382 "trans.m"
    trans__V_70_70 = (trans__S_11 * trans__M21_16);
#line 382 "trans.m"
    trans__V_71_71 = (trans__C_10 * trans__M31_20);
#line 380 "trans.m"
    trans__V_58_58 = (trans__V_70_70 + trans__V_71_71);
#line 382 "trans.m"
    trans__V_72_72 = (trans__S_11 * trans__M22_17);
#line 382 "trans.m"
    trans__V_73_73 = (trans__C_10 * trans__M32_21);
#line 380 "trans.m"
    trans__V_59_59 = (trans__V_72_72 + trans__V_73_73);
#line 382 "trans.m"
    trans__V_74_74 = (trans__S_11 * trans__M23_18);
#line 382 "trans.m"
    trans__V_75_75 = (trans__C_10 * trans__M33_22);
#line 380 "trans.m"
    trans__V_60_60 = (trans__V_74_74 + trans__V_75_75);
#line 382 "trans.m"
    trans__V_76_76 = (trans__S_11 * trans__M24_19);
#line 382 "trans.m"
    trans__V_77_77 = (trans__C_10 * trans__M34_23);
#line 380 "trans.m"
    trans__V_61_61 = (trans__V_76_76 + trans__V_77_77);
#line 380 "trans.m"
    {
#line 380 "trans.m"
      trans__M_7 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 12 * sizeof(MR_Word)), "matrix");
#line 380 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 0) = MR_box_float(trans__M11_12);
#line 380 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 1) = MR_box_float(trans__M12_13);
#line 380 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 2) = MR_box_float(trans__M13_14);
#line 380 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 3) = MR_box_float(trans__M14_15);
#line 380 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 4) = MR_box_float(trans__V_54_54);
#line 380 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 5) = MR_box_float(trans__V_55_55);
#line 380 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 6) = MR_box_float(trans__V_56_56);
#line 380 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 7) = MR_box_float(trans__V_57_57);
#line 380 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 8) = MR_box_float(trans__V_58_58);
#line 380 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 9) = MR_box_float(trans__V_59_59);
#line 380 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 10) = MR_box_float(trans__V_60_60);
#line 380 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_7, 11) = MR_box_float(trans__V_61_61);
#line 380 "trans.m"
    }
#line 384 "trans.m"
    trans__W11_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 0)));
#line 384 "trans.m"
    trans__W12_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 1)));
#line 384 "trans.m"
    trans__W13_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 2)));
#line 384 "trans.m"
    trans__W14_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 3)));
#line 384 "trans.m"
    trans__W21_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 4)));
#line 384 "trans.m"
    trans__W22_29 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 5)));
#line 384 "trans.m"
    trans__W23_30 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 6)));
#line 384 "trans.m"
    trans__W24_31 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 7)));
#line 384 "trans.m"
    trans__W31_32 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 8)));
#line 384 "trans.m"
    trans__W32_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 9)));
#line 384 "trans.m"
    trans__W33_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 10)));
#line 384 "trans.m"
    trans__W34_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 11)));
#line 387 "trans.m"
    trans__V_42_42 = (trans__C_10 * trans__W12_25);
#line 387 "trans.m"
    trans__V_43_43 = (trans__S_11 * trans__W13_26);
#line 387 "trans.m"
    trans__V_36_36 = (trans__V_42_42 - trans__V_43_43);
#line 387 "trans.m"
    trans__V_44_44 = (trans__S_11 * trans__W12_25);
#line 387 "trans.m"
    trans__V_45_45 = (trans__C_10 * trans__W13_26);
#line 387 "trans.m"
    trans__V_37_37 = (trans__V_44_44 + trans__V_45_45);
#line 388 "trans.m"
    trans__V_46_46 = (trans__C_10 * trans__W22_29);
#line 388 "trans.m"
    trans__V_47_47 = (trans__S_11 * trans__W23_30);
#line 387 "trans.m"
    trans__V_38_38 = (trans__V_46_46 - trans__V_47_47);
#line 388 "trans.m"
    trans__V_48_48 = (trans__S_11 * trans__W22_29);
#line 388 "trans.m"
    trans__V_49_49 = (trans__C_10 * trans__W23_30);
#line 387 "trans.m"
    trans__V_39_39 = (trans__V_48_48 + trans__V_49_49);
#line 389 "trans.m"
    trans__V_50_50 = (trans__C_10 * trans__W32_33);
#line 389 "trans.m"
    trans__V_51_51 = (trans__S_11 * trans__W33_34);
#line 387 "trans.m"
    trans__V_40_40 = (trans__V_50_50 - trans__V_51_51);
#line 389 "trans.m"
    trans__V_52_52 = (trans__S_11 * trans__W32_33);
#line 389 "trans.m"
    trans__V_53_53 = (trans__C_10 * trans__W33_34);
#line 387 "trans.m"
    trans__V_41_41 = (trans__V_52_52 + trans__V_53_53);
#line 387 "trans.m"
    {
#line 387 "trans.m"
      trans__W_8 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 12 * sizeof(MR_Word)), "matrix");
#line 387 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 0) = MR_box_float(trans__W11_24);
#line 387 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 1) = MR_box_float(trans__V_36_36);
#line 387 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 2) = MR_box_float(trans__V_37_37);
#line 387 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 3) = MR_box_float(trans__W14_27);
#line 387 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 4) = MR_box_float(trans__W21_28);
#line 387 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 5) = MR_box_float(trans__V_38_38);
#line 387 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 6) = MR_box_float(trans__V_39_39);
#line 387 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 7) = MR_box_float(trans__W24_31);
#line 387 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 8) = MR_box_float(trans__W31_32);
#line 387 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 9) = MR_box_float(trans__V_40_40);
#line 387 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 10) = MR_box_float(trans__V_41_41);
#line 387 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_8, 11) = MR_box_float(trans__W34_35);
#line 387 "trans.m"
    }
#line 371 "trans.m"
    {
#line 371 "trans.m"
      trans__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "trans");
#line 371 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 0) = ((MR_Box) (trans__M_7));
#line 371 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 1) = ((MR_Box) (trans__W_8));
#line 371 "trans.m"
    }
    return trans__HeadVar__3_3;
  }
#line 119 "trans.m"
}

#line 115 "trans.m"
MR_Word MR_CALL trans__compose_uscale_3_f_0(
#line 115 "trans.m"
  MR_Float trans__HeadVar__1_1,
#line 115 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 115 "trans.m"
{
  {
    bool trans__succeeded = (trans__HeadVar__1_1 == ((MR_Float) 0.00000000000000));
    MR_Word trans__HeadVar__3_3;
    MR_Word trans__M0_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Word trans__W0_6 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Word trans__M_7;
    MR_Word trans__W_8;

#line 353 "trans.m"
    if (trans__succeeded)
      {
        MR_String trans__V_33_33 = (MR_String) "trans: compose_uscale/7: zero scaling factor";
        MR_Word trans__TypeInfo_55_55 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 352 "trans.m"
        {
#line 352 "trans.m"
          mercury__exception__throw_1_p_0(trans__TypeInfo_55_55, ((MR_Box) (trans__V_33_33)));
        }
      }
#line 353 "trans.m"
    else
      {
        MR_Float trans__M11_9 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 0)));
        MR_Float trans__M12_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 1)));
        MR_Float trans__M13_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 2)));
        MR_Float trans__M14_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 3)));
        MR_Float trans__M21_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 4)));
        MR_Float trans__M22_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 5)));
        MR_Float trans__M23_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 6)));
        MR_Float trans__M24_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 7)));
        MR_Float trans__M31_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 8)));
        MR_Float trans__M32_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 9)));
        MR_Float trans__M33_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 10)));
        MR_Float trans__M34_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_5, (MR_Integer) 11)));
        MR_Float trans__W11_21;
        MR_Float trans__W12_22;
        MR_Float trans__W13_23;
        MR_Float trans__W14_24;
        MR_Float trans__W21_25;
        MR_Float trans__W22_26;
        MR_Float trans__W23_27;
        MR_Float trans__W24_28;
        MR_Float trans__W31_29;
        MR_Float trans__W32_30;
        MR_Float trans__W33_31;
        MR_Float trans__W34_32;
        MR_Float trans__V_34_34;
        MR_Float trans__V_35_35;
        MR_Float trans__V_36_36;
        MR_Float trans__V_37_37;
        MR_Float trans__V_38_38;
        MR_Float trans__V_39_39;
        MR_Float trans__V_40_40;
        MR_Float trans__V_41_41;
        MR_Float trans__V_42_42;
        MR_Float trans__V_43_43 = (trans__HeadVar__1_1 * trans__M11_9);
        MR_Float trans__V_44_44 = (trans__HeadVar__1_1 * trans__M12_10);
        MR_Float trans__V_45_45 = (trans__HeadVar__1_1 * trans__M13_11);
        MR_Float trans__V_46_46 = (trans__HeadVar__1_1 * trans__M14_12);
        MR_Float trans__V_47_47 = (trans__HeadVar__1_1 * trans__M21_13);
        MR_Float trans__V_48_48 = (trans__HeadVar__1_1 * trans__M22_14);
        MR_Float trans__V_49_49 = (trans__HeadVar__1_1 * trans__M23_15);
        MR_Float trans__V_50_50 = (trans__HeadVar__1_1 * trans__M24_16);
        MR_Float trans__V_51_51 = (trans__HeadVar__1_1 * trans__M31_17);
        MR_Float trans__V_52_52 = (trans__HeadVar__1_1 * trans__M32_18);
        MR_Float trans__V_53_53 = (trans__HeadVar__1_1 * trans__M33_19);
        MR_Float trans__V_54_54 = (trans__HeadVar__1_1 * trans__M34_20);

#line 357 "trans.m"
        {
#line 357 "trans.m"
          trans__M_7 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 12 * sizeof(MR_Word)), "matrix");
#line 357 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_7, 0) = MR_box_float(trans__V_43_43);
#line 357 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_7, 1) = MR_box_float(trans__V_44_44);
#line 357 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_7, 2) = MR_box_float(trans__V_45_45);
#line 357 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_7, 3) = MR_box_float(trans__V_46_46);
#line 357 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_7, 4) = MR_box_float(trans__V_47_47);
#line 357 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_7, 5) = MR_box_float(trans__V_48_48);
#line 357 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_7, 6) = MR_box_float(trans__V_49_49);
#line 357 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_7, 7) = MR_box_float(trans__V_50_50);
#line 357 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_7, 8) = MR_box_float(trans__V_51_51);
#line 357 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_7, 9) = MR_box_float(trans__V_52_52);
#line 357 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_7, 10) = MR_box_float(trans__V_53_53);
#line 357 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_7, 11) = MR_box_float(trans__V_54_54);
#line 357 "trans.m"
        }
#line 361 "trans.m"
        trans__W11_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 0)));
#line 361 "trans.m"
        trans__W12_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 1)));
#line 361 "trans.m"
        trans__W13_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 2)));
#line 361 "trans.m"
        trans__W14_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 3)));
#line 361 "trans.m"
        trans__W21_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 4)));
#line 361 "trans.m"
        trans__W22_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 5)));
#line 361 "trans.m"
        trans__W23_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 6)));
#line 361 "trans.m"
        trans__W24_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 7)));
#line 361 "trans.m"
        trans__W31_29 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 8)));
#line 361 "trans.m"
        trans__W32_30 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 9)));
#line 361 "trans.m"
        trans__W33_31 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 10)));
#line 361 "trans.m"
        trans__W34_32 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_6, (MR_Integer) 11)));
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_uscale_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__1_1 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_59;
            MR_String trans__V_8_60 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_61;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_59 = (MR_Word) trans__V_8_60;
            trans__TypeInfo_9_61 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_61, ((MR_Box) (trans__V_7_59)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__V_34_34 = (trans__W11_21 / trans__HeadVar__1_1);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_uscale_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__1_1 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_65;
            MR_String trans__V_8_66 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_67;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_65 = (MR_Word) trans__V_8_66;
            trans__TypeInfo_9_67 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_67, ((MR_Box) (trans__V_7_65)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__V_35_35 = (trans__W12_22 / trans__HeadVar__1_1);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_uscale_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__1_1 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_71;
            MR_String trans__V_8_72 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_73;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_71 = (MR_Word) trans__V_8_72;
            trans__TypeInfo_9_73 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_73, ((MR_Box) (trans__V_7_71)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__V_36_36 = (trans__W13_23 / trans__HeadVar__1_1);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_uscale_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__1_1 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_77;
            MR_String trans__V_8_78 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_79;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_77 = (MR_Word) trans__V_8_78;
            trans__TypeInfo_9_79 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_79, ((MR_Box) (trans__V_7_77)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__V_37_37 = (trans__W21_25 / trans__HeadVar__1_1);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_uscale_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__1_1 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_83;
            MR_String trans__V_8_84 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_85;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_83 = (MR_Word) trans__V_8_84;
            trans__TypeInfo_9_85 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_85, ((MR_Box) (trans__V_7_83)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__V_38_38 = (trans__W22_26 / trans__HeadVar__1_1);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_uscale_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__1_1 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_89;
            MR_String trans__V_8_90 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_91;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_89 = (MR_Word) trans__V_8_90;
            trans__TypeInfo_9_91 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_91, ((MR_Box) (trans__V_7_89)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__V_39_39 = (trans__W23_27 / trans__HeadVar__1_1);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_uscale_3_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__1_1 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_95;
            MR_String trans__V_8_96 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_97;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_95 = (MR_Word) trans__V_8_96;
            trans__TypeInfo_9_97 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_97, ((MR_Box) (trans__V_7_95)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__V_40_40 = (trans__W31_29 / trans__HeadVar__1_1);
#line 364 "trans.m"
        {
#line 364 "trans.m"
          trans__V_41_41 = mercury__float__f_slash_3_f_0(trans__W32_30, trans__HeadVar__1_1);
        }
#line 364 "trans.m"
        {
#line 364 "trans.m"
          trans__V_42_42 = mercury__float__f_slash_3_f_0(trans__W33_31, trans__HeadVar__1_1);
        }
#line 364 "trans.m"
        {
#line 364 "trans.m"
          trans__W_8 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 12 * sizeof(MR_Word)), "matrix");
#line 364 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_8, 0) = MR_box_float(trans__V_34_34);
#line 364 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_8, 1) = MR_box_float(trans__V_35_35);
#line 364 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_8, 2) = MR_box_float(trans__V_36_36);
#line 364 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_8, 3) = MR_box_float(trans__W14_24);
#line 364 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_8, 4) = MR_box_float(trans__V_37_37);
#line 364 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_8, 5) = MR_box_float(trans__V_38_38);
#line 364 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_8, 6) = MR_box_float(trans__V_39_39);
#line 364 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_8, 7) = MR_box_float(trans__W24_28);
#line 364 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_8, 8) = MR_box_float(trans__V_40_40);
#line 364 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_8, 9) = MR_box_float(trans__V_41_41);
#line 364 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_8, 10) = MR_box_float(trans__V_42_42);
#line 364 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_8, 11) = MR_box_float(trans__W34_32);
#line 364 "trans.m"
        }
      }
#line 349 "trans.m"
    {
#line 349 "trans.m"
      trans__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "trans");
#line 349 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 0) = ((MR_Box) (trans__M_7));
#line 349 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 1) = ((MR_Box) (trans__W_8));
#line 349 "trans.m"
    }
    return trans__HeadVar__3_3;
  }
#line 115 "trans.m"
}

#line 111 "trans.m"
MR_Word MR_CALL trans__compose_scale_5_f_0(
#line 111 "trans.m"
  MR_Float trans__HeadVar__1_1,
#line 111 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 111 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 111 "trans.m"
  MR_Word trans__HeadVar__4_4)
#line 111 "trans.m"
{
  {
    bool trans__succeeded = (trans__HeadVar__1_1 == ((MR_Float) 0.00000000000000));
    MR_Word trans__HeadVar__5_5;
    MR_Word trans__M0_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 0)));
    MR_Word trans__W0_10 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 1)));
    MR_Word trans__M_11;
    MR_Word trans__W_12;

#line 329 "trans.m"
    if (!(trans__succeeded))
#line 329 "trans.m"
      {
#line 329 "trans.m"
        trans__succeeded = (trans__HeadVar__2_2 == ((MR_Float) 0.00000000000000));
#line 329 "trans.m"
        if (!(trans__succeeded))
#line 329 "trans.m"
          trans__succeeded = (trans__HeadVar__3_3 == ((MR_Float) 0.00000000000000));
#line 329 "trans.m"
      }
#line 331 "trans.m"
    if (trans__succeeded)
      {
        MR_String trans__V_37_37 = (MR_String) "trans: compose_scale/7: zero scaling factor";
        MR_Word trans__TypeInfo_59_59 = (MR_Word) (&mercury__builtin__builtin__type_ctor_info_string_0);

#line 330 "trans.m"
        {
#line 330 "trans.m"
          mercury__exception__throw_1_p_0(trans__TypeInfo_59_59, ((MR_Box) (trans__V_37_37)));
        }
      }
#line 331 "trans.m"
    else
      {
        MR_Float trans__M11_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 0)));
        MR_Float trans__M12_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 1)));
        MR_Float trans__M13_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 2)));
        MR_Float trans__M14_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 3)));
        MR_Float trans__M21_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 4)));
        MR_Float trans__M22_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 5)));
        MR_Float trans__M23_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 6)));
        MR_Float trans__M24_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 7)));
        MR_Float trans__M31_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 8)));
        MR_Float trans__M32_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 9)));
        MR_Float trans__M33_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 10)));
        MR_Float trans__M34_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 11)));
        MR_Float trans__W11_25;
        MR_Float trans__W12_26;
        MR_Float trans__W13_27;
        MR_Float trans__W14_28;
        MR_Float trans__W21_29;
        MR_Float trans__W22_30;
        MR_Float trans__W23_31;
        MR_Float trans__W24_32;
        MR_Float trans__W31_33;
        MR_Float trans__W32_34;
        MR_Float trans__W33_35;
        MR_Float trans__W34_36;
        MR_Float trans__V_38_38;
        MR_Float trans__V_39_39;
        MR_Float trans__V_40_40;
        MR_Float trans__V_41_41;
        MR_Float trans__V_42_42;
        MR_Float trans__V_43_43;
        MR_Float trans__V_44_44;
        MR_Float trans__V_45_45;
        MR_Float trans__V_46_46;
        MR_Float trans__V_47_47 = (trans__HeadVar__1_1 * trans__M11_13);
        MR_Float trans__V_48_48 = (trans__HeadVar__1_1 * trans__M12_14);
        MR_Float trans__V_49_49 = (trans__HeadVar__1_1 * trans__M13_15);
        MR_Float trans__V_50_50 = (trans__HeadVar__1_1 * trans__M14_16);
        MR_Float trans__V_51_51 = (trans__HeadVar__2_2 * trans__M21_17);
        MR_Float trans__V_52_52 = (trans__HeadVar__2_2 * trans__M22_18);
        MR_Float trans__V_53_53 = (trans__HeadVar__2_2 * trans__M23_19);
        MR_Float trans__V_54_54 = (trans__HeadVar__2_2 * trans__M24_20);
        MR_Float trans__V_55_55 = (trans__HeadVar__3_3 * trans__M31_21);
        MR_Float trans__V_56_56 = (trans__HeadVar__3_3 * trans__M32_22);
        MR_Float trans__V_57_57 = (trans__HeadVar__3_3 * trans__M33_23);
        MR_Float trans__V_58_58 = (trans__HeadVar__3_3 * trans__M34_24);

#line 335 "trans.m"
        {
#line 335 "trans.m"
          trans__M_11 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 12 * sizeof(MR_Word)), "matrix");
#line 335 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_11, 0) = MR_box_float(trans__V_47_47);
#line 335 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_11, 1) = MR_box_float(trans__V_48_48);
#line 335 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_11, 2) = MR_box_float(trans__V_49_49);
#line 335 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_11, 3) = MR_box_float(trans__V_50_50);
#line 335 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_11, 4) = MR_box_float(trans__V_51_51);
#line 335 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_11, 5) = MR_box_float(trans__V_52_52);
#line 335 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_11, 6) = MR_box_float(trans__V_53_53);
#line 335 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_11, 7) = MR_box_float(trans__V_54_54);
#line 335 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_11, 8) = MR_box_float(trans__V_55_55);
#line 335 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_11, 9) = MR_box_float(trans__V_56_56);
#line 335 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_11, 10) = MR_box_float(trans__V_57_57);
#line 335 "trans.m"
          MR_hl_field(MR_mktag(0), trans__M_11, 11) = MR_box_float(trans__V_58_58);
#line 335 "trans.m"
        }
#line 339 "trans.m"
        trans__W11_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 0)));
#line 339 "trans.m"
        trans__W12_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 1)));
#line 339 "trans.m"
        trans__W13_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 2)));
#line 339 "trans.m"
        trans__W14_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 3)));
#line 339 "trans.m"
        trans__W21_29 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 4)));
#line 339 "trans.m"
        trans__W22_30 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 5)));
#line 339 "trans.m"
        trans__W23_31 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 6)));
#line 339 "trans.m"
        trans__W24_32 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 7)));
#line 339 "trans.m"
        trans__W31_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 8)));
#line 339 "trans.m"
        trans__W32_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 9)));
#line 339 "trans.m"
        trans__W33_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 10)));
#line 339 "trans.m"
        trans__W34_36 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 11)));
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_scale_5_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__1_1 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_63;
            MR_String trans__V_8_64 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_65;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_63 = (MR_Word) trans__V_8_64;
            trans__TypeInfo_9_65 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_65, ((MR_Box) (trans__V_7_63)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__V_38_38 = (trans__W11_25 / trans__HeadVar__1_1);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_scale_5_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__2_2 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_69;
            MR_String trans__V_8_70 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_71;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_69 = (MR_Word) trans__V_8_70;
            trans__TypeInfo_9_71 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_71, ((MR_Box) (trans__V_7_69)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__V_39_39 = (trans__W12_26 / trans__HeadVar__2_2);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_scale_5_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__3_3 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_75;
            MR_String trans__V_8_76 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_77;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_75 = (MR_Word) trans__V_8_76;
            trans__TypeInfo_9_77 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_77, ((MR_Box) (trans__V_7_75)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__V_40_40 = (trans__W13_27 / trans__HeadVar__3_3);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_scale_5_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__1_1 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_81;
            MR_String trans__V_8_82 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_83;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_81 = (MR_Word) trans__V_8_82;
            trans__TypeInfo_9_83 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_83, ((MR_Box) (trans__V_7_81)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__V_41_41 = (trans__W21_29 / trans__HeadVar__1_1);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_scale_5_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__2_2 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_87;
            MR_String trans__V_8_88 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_89;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_87 = (MR_Word) trans__V_8_88;
            trans__TypeInfo_9_89 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_89, ((MR_Box) (trans__V_7_87)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__V_42_42 = (trans__W22_30 / trans__HeadVar__2_2);
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#define MR_PROC_LABEL trans__compose_scale_5_f_0
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	MR_Bool SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
		{
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

#ifdef ML_OMIT_MATH_DOMAIN_CHECKS
	SUCCESS_INDICATOR = FALSE;
#else
	SUCCESS_INDICATOR = TRUE;
#endif

#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"

		;}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#undef MR_PROC_LABEL
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	if (SUCCESS_INDICATOR) {
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
	}
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
trans__succeeded
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
 = SUCCESS_INDICATOR;
#line 118 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
}
        if (trans__succeeded)
#line 37 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__succeeded = (trans__HeadVar__3_3 == ((MR_Float) 0.00000000000000));
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        if (trans__succeeded)
          {
            MR_Word trans__V_7_93;
            MR_String trans__V_8_94 = (MR_String) "float:'/'";
            MR_Word trans__TypeInfo_9_95;

#line 39 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            trans__V_7_93 = (MR_Word) trans__V_8_94;
            trans__TypeInfo_9_95 = (MR_Word) (&mercury__math__math__type_ctor_info_domain_error_0);
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
            {
#line 41 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
              mercury__exception__throw_1_p_0(trans__TypeInfo_9_95, ((MR_Box) (trans__V_7_93)));
            }
          }
#line 42 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
        else
#line 43 "/usr/local/mercury-install-2001-10-04/lib/mercury/ints/float.opt"
          trans__V_43_43 = (trans__W23_31 / trans__HeadVar__3_3);
#line 342 "trans.m"
        {
#line 342 "trans.m"
          trans__V_44_44 = mercury__float__f_slash_3_f_0(trans__W31_33, trans__HeadVar__1_1);
        }
#line 342 "trans.m"
        {
#line 342 "trans.m"
          trans__V_45_45 = mercury__float__f_slash_3_f_0(trans__W32_34, trans__HeadVar__2_2);
        }
#line 342 "trans.m"
        {
#line 342 "trans.m"
          trans__V_46_46 = mercury__float__f_slash_3_f_0(trans__W33_35, trans__HeadVar__3_3);
        }
#line 342 "trans.m"
        {
#line 342 "trans.m"
          trans__W_12 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 12 * sizeof(MR_Word)), "matrix");
#line 342 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_12, 0) = MR_box_float(trans__V_38_38);
#line 342 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_12, 1) = MR_box_float(trans__V_39_39);
#line 342 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_12, 2) = MR_box_float(trans__V_40_40);
#line 342 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_12, 3) = MR_box_float(trans__W14_28);
#line 342 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_12, 4) = MR_box_float(trans__V_41_41);
#line 342 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_12, 5) = MR_box_float(trans__V_42_42);
#line 342 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_12, 6) = MR_box_float(trans__V_43_43);
#line 342 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_12, 7) = MR_box_float(trans__W24_32);
#line 342 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_12, 8) = MR_box_float(trans__V_44_44);
#line 342 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_12, 9) = MR_box_float(trans__V_45_45);
#line 342 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_12, 10) = MR_box_float(trans__V_46_46);
#line 342 "trans.m"
          MR_hl_field(MR_mktag(0), trans__W_12, 11) = MR_box_float(trans__W34_36);
#line 342 "trans.m"
        }
      }
#line 327 "trans.m"
    {
#line 327 "trans.m"
      trans__HeadVar__5_5 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "trans");
#line 327 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 0) = ((MR_Box) (trans__M_11));
#line 327 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 1) = ((MR_Box) (trans__W_12));
#line 327 "trans.m"
    }
    return trans__HeadVar__5_5;
  }
#line 111 "trans.m"
}

#line 107 "trans.m"
MR_Word MR_CALL trans__compose_translate_5_f_0(
#line 107 "trans.m"
  MR_Float trans__HeadVar__1_1,
#line 107 "trans.m"
  MR_Float trans__HeadVar__2_2,
#line 107 "trans.m"
  MR_Float trans__HeadVar__3_3,
#line 107 "trans.m"
  MR_Word trans__HeadVar__4_4)
#line 107 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__5_5;
    MR_Word trans__M0_9 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 0)));
    MR_Word trans__W0_10 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__4_4, (MR_Integer) 1)));
    MR_Word trans__M_11;
    MR_Word trans__W_12;
    MR_Float trans__M11_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 0)));
    MR_Float trans__M12_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 1)));
    MR_Float trans__M13_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 2)));
    MR_Float trans__M14_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 3)));
    MR_Float trans__M21_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 4)));
    MR_Float trans__M22_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 5)));
    MR_Float trans__M23_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 6)));
    MR_Float trans__M24_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 7)));
    MR_Float trans__M31_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 8)));
    MR_Float trans__M32_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 9)));
    MR_Float trans__M33_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 10)));
    MR_Float trans__M34_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M0_9, (MR_Integer) 11)));
    MR_Float trans__W11_25;
    MR_Float trans__W12_26;
    MR_Float trans__W13_27;
    MR_Float trans__W14_28;
    MR_Float trans__W21_29;
    MR_Float trans__W22_30;
    MR_Float trans__W23_31;
    MR_Float trans__W24_32;
    MR_Float trans__W31_33;
    MR_Float trans__W32_34;
    MR_Float trans__W33_35;
    MR_Float trans__W34_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40;
    MR_Float trans__V_41_41;
    MR_Float trans__V_42_42;
    MR_Float trans__V_43_43;
    MR_Float trans__V_44_44;
    MR_Float trans__V_45_45;
    MR_Float trans__V_46_46;
    MR_Float trans__V_47_47;
    MR_Float trans__V_48_48;
    MR_Float trans__V_49_49;
    MR_Float trans__V_50_50;
    MR_Float trans__V_51_51;
    MR_Float trans__V_52_52;
    MR_Float trans__V_53_53;
    MR_Float trans__V_54_54;
    MR_Float trans__V_55_55 = (trans__M14_16 + trans__HeadVar__1_1);
    MR_Float trans__V_56_56 = (trans__M24_20 + trans__HeadVar__2_2);
    MR_Float trans__V_57_57 = (trans__M34_24 + trans__HeadVar__3_3);

#line 314 "trans.m"
    {
#line 314 "trans.m"
      trans__M_11 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 12 * sizeof(MR_Word)), "matrix");
#line 314 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_11, 0) = MR_box_float(trans__M11_13);
#line 314 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_11, 1) = MR_box_float(trans__M12_14);
#line 314 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_11, 2) = MR_box_float(trans__M13_15);
#line 314 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_11, 3) = MR_box_float(trans__V_55_55);
#line 314 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_11, 4) = MR_box_float(trans__M21_17);
#line 314 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_11, 5) = MR_box_float(trans__M22_18);
#line 314 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_11, 6) = MR_box_float(trans__M23_19);
#line 314 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_11, 7) = MR_box_float(trans__V_56_56);
#line 314 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_11, 8) = MR_box_float(trans__M31_21);
#line 314 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_11, 9) = MR_box_float(trans__M32_22);
#line 314 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_11, 10) = MR_box_float(trans__M33_23);
#line 314 "trans.m"
      MR_hl_field(MR_mktag(0), trans__M_11, 11) = MR_box_float(trans__V_57_57);
#line 314 "trans.m"
    }
#line 318 "trans.m"
    trans__W11_25 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 0)));
#line 318 "trans.m"
    trans__W12_26 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 1)));
#line 318 "trans.m"
    trans__W13_27 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 2)));
#line 318 "trans.m"
    trans__W14_28 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 3)));
#line 318 "trans.m"
    trans__W21_29 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 4)));
#line 318 "trans.m"
    trans__W22_30 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 5)));
#line 318 "trans.m"
    trans__W23_31 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 6)));
#line 318 "trans.m"
    trans__W24_32 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 7)));
#line 318 "trans.m"
    trans__W31_33 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 8)));
#line 318 "trans.m"
    trans__W32_34 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 9)));
#line 318 "trans.m"
    trans__W33_35 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 10)));
#line 318 "trans.m"
    trans__W34_36 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W0_10, (MR_Integer) 11)));
#line 321 "trans.m"
    trans__V_44_44 = (trans__HeadVar__1_1 * trans__W11_25);
#line 321 "trans.m"
    trans__V_42_42 = (trans__W14_28 - trans__V_44_44);
#line 321 "trans.m"
    trans__V_43_43 = (trans__HeadVar__2_2 * trans__W12_26);
#line 321 "trans.m"
    trans__V_40_40 = (trans__V_42_42 - trans__V_43_43);
#line 321 "trans.m"
    trans__V_41_41 = (trans__HeadVar__3_3 * trans__W13_27);
#line 321 "trans.m"
    trans__V_37_37 = (trans__V_40_40 - trans__V_41_41);
#line 322 "trans.m"
    trans__V_49_49 = (trans__HeadVar__1_1 * trans__W21_29);
#line 322 "trans.m"
    trans__V_47_47 = (trans__W24_32 - trans__V_49_49);
#line 322 "trans.m"
    trans__V_48_48 = (trans__HeadVar__2_2 * trans__W22_30);
#line 322 "trans.m"
    trans__V_45_45 = (trans__V_47_47 - trans__V_48_48);
#line 322 "trans.m"
    trans__V_46_46 = (trans__HeadVar__3_3 * trans__W23_31);
#line 321 "trans.m"
    trans__V_38_38 = (trans__V_45_45 - trans__V_46_46);
#line 323 "trans.m"
    trans__V_54_54 = (trans__HeadVar__1_1 * trans__W31_33);
#line 323 "trans.m"
    trans__V_52_52 = (trans__W34_36 - trans__V_54_54);
#line 323 "trans.m"
    trans__V_53_53 = (trans__HeadVar__2_2 * trans__W32_34);
#line 323 "trans.m"
    trans__V_50_50 = (trans__V_52_52 - trans__V_53_53);
#line 323 "trans.m"
    trans__V_51_51 = (trans__HeadVar__3_3 * trans__W33_35);
#line 321 "trans.m"
    trans__V_39_39 = (trans__V_50_50 - trans__V_51_51);
#line 321 "trans.m"
    {
#line 321 "trans.m"
      trans__W_12 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 12 * sizeof(MR_Word)), "matrix");
#line 321 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_12, 0) = MR_box_float(trans__W11_25);
#line 321 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_12, 1) = MR_box_float(trans__W12_26);
#line 321 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_12, 2) = MR_box_float(trans__W13_27);
#line 321 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_12, 3) = MR_box_float(trans__V_37_37);
#line 321 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_12, 4) = MR_box_float(trans__W21_29);
#line 321 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_12, 5) = MR_box_float(trans__W22_30);
#line 321 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_12, 6) = MR_box_float(trans__W23_31);
#line 321 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_12, 7) = MR_box_float(trans__V_38_38);
#line 321 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_12, 8) = MR_box_float(trans__W31_33);
#line 321 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_12, 9) = MR_box_float(trans__W32_34);
#line 321 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_12, 10) = MR_box_float(trans__W33_35);
#line 321 "trans.m"
      MR_hl_field(MR_mktag(0), trans__W_12, 11) = MR_box_float(trans__V_39_39);
#line 321 "trans.m"
    }
#line 309 "trans.m"
    {
#line 309 "trans.m"
      trans__HeadVar__5_5 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 2 * sizeof(MR_Word)), "trans");
#line 309 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 0) = ((MR_Box) (trans__M_11));
#line 309 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__5_5, 1) = ((MR_Box) (trans__W_12));
#line 309 "trans.m"
    }
    return trans__HeadVar__5_5;
  }
#line 107 "trans.m"
}
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_1 = (MR_Float) 1.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_2 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_3 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_4 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_5 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_6 = (MR_Float) 1.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_7 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_8 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_9 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_10 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_11 = (MR_Float) 1.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Float trans__float_6_0_12 = (MR_Float) 0.00000000000000;
#line 303 "trans.m"
static /* final */ const MR_Box trans__const_6_0_13_I_2[12] = {
		(MR_Box) &trans__float_6_0_1,
		(MR_Box) &trans__float_6_0_2,
		(MR_Box) &trans__float_6_0_3,
		(MR_Box) &trans__float_6_0_4,
		(MR_Box) &trans__float_6_0_5,
		(MR_Box) &trans__float_6_0_6,
		(MR_Box) &trans__float_6_0_7,
		(MR_Box) &trans__float_6_0_8,
		(MR_Box) &trans__float_6_0_9,
		(MR_Box) &trans__float_6_0_10,
		(MR_Box) &trans__float_6_0_11,
		(MR_Box) &trans__float_6_0_12};
#line 298 "trans.m"
static /* final */ const MR_Box trans__const_6_0_14_HeadVar__1_1[2] = {
		((MR_Box) (&trans__const_6_0_13_I_2)),
		((MR_Box) (&trans__const_6_0_13_I_2))};

#line 99 "trans.m"
MR_Word MR_CALL trans__identity_1_f_0(void)
#line 99 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__1_1 = (MR_Word) &trans__const_6_0_14_HeadVar__1_1;
    MR_Word trans__I_2 = (MR_Word) &trans__const_6_0_13_I_2;
    MR_Float trans__V_4_4 = (MR_Float) 1.00000000000000;
    MR_Float trans__V_5_5 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_6_6 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_7_7 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_8_8 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_9_9 = (MR_Float) 1.00000000000000;
    MR_Float trans__V_10_10 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_11_11 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_12_12 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_13_13 = (MR_Float) 0.00000000000000;
    MR_Float trans__V_14_14 = (MR_Float) 1.00000000000000;
    MR_Float trans__V_15_15 = (MR_Float) 0.00000000000000;

    return trans__HeadVar__1_1;
  }
#line 99 "trans.m"
}

#line 93 "trans.m"
MR_Word MR_CALL trans__normal_to_world_space_3_f_0(
#line 93 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 93 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 93 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__3_3;
    MR_Word trans__W_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__M11_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 0)));
    MR_Float trans__M12_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 1)));
    MR_Float trans__M13_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 2)));
    MR_Float trans__M21_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 4)));
    MR_Float trans__M22_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 5)));
    MR_Float trans__M23_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 6)));
    MR_Float trans__M31_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 8)));
    MR_Float trans__M32_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 9)));
    MR_Float trans__M33_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 10)));
    MR_Float trans__X_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__Y_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__Z_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float trans__V_25_25;
    MR_Float trans__V_26_26;
    MR_Float trans__V_27_27;
    MR_Float trans__V_28_28;
    MR_Float trans__V_29_29;
    MR_Float trans__V_30_30 = (trans__M11_10 * trans__X_22);
    MR_Float trans__V_31_31 = (trans__M21_14 * trans__Y_23);
    MR_Float trans__V_32_32;
    MR_Float trans__V_33_33;
    MR_Float trans__V_34_34;
    MR_Float trans__V_35_35;
    MR_Float trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
#line 294 "trans.m"
    MR_Word trans___M_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
#line 274 "trans.m"
    MR_Float trans___M14_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 3)));
#line 274 "trans.m"
    MR_Float trans___M24_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 7)));
#line 274 "trans.m"
    MR_Float trans___M34_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 11)));

#line 280 "trans.m"
    trans__V_28_28 = (trans__V_30_30 + trans__V_31_31);
#line 280 "trans.m"
    trans__V_29_29 = (trans__M31_18 * trans__Z_24);
#line 280 "trans.m"
    trans__V_25_25 = (trans__V_28_28 + trans__V_29_29);
#line 281 "trans.m"
    trans__V_34_34 = (trans__M12_11 * trans__X_22);
#line 281 "trans.m"
    trans__V_35_35 = (trans__M22_15 * trans__Y_23);
#line 281 "trans.m"
    trans__V_32_32 = (trans__V_34_34 + trans__V_35_35);
#line 281 "trans.m"
    trans__V_33_33 = (trans__M32_19 * trans__Z_24);
#line 280 "trans.m"
    trans__V_26_26 = (trans__V_32_32 + trans__V_33_33);
#line 282 "trans.m"
    trans__V_38_38 = (trans__M13_12 * trans__X_22);
#line 282 "trans.m"
    trans__V_39_39 = (trans__M23_16 * trans__Y_23);
#line 282 "trans.m"
    trans__V_36_36 = (trans__V_38_38 + trans__V_39_39);
#line 282 "trans.m"
    trans__V_37_37 = (trans__M33_20 * trans__Z_24);
#line 280 "trans.m"
    trans__V_27_27 = (trans__V_36_36 + trans__V_37_37);
#line 280 "trans.m"
    {
#line 280 "trans.m"
      trans__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 0) = MR_box_float(trans__V_25_25);
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 1) = MR_box_float(trans__V_26_26);
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 2) = MR_box_float(trans__V_27_27);
#line 280 "trans.m"
    }
    return trans__HeadVar__3_3;
  }
#line 93 "trans.m"
}

#line 92 "trans.m"
MR_Word MR_CALL trans__vector_to_world_space_3_f_0(
#line 92 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 92 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 92 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__3_3;
    MR_Word trans__M_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__M11_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 0)));
    MR_Float trans__M12_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 1)));
    MR_Float trans__M13_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 2)));
    MR_Float trans__M21_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 4)));
    MR_Float trans__M22_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 5)));
    MR_Float trans__M23_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 6)));
    MR_Float trans__M31_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 8)));
    MR_Float trans__M32_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 9)));
    MR_Float trans__M33_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 10)));
    MR_Float trans__X_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__Y_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__Z_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float trans__V_25_25;
    MR_Float trans__V_26_26;
    MR_Float trans__V_27_27;
    MR_Float trans__V_28_28;
    MR_Float trans__V_29_29;
    MR_Float trans__V_30_30 = (trans__M11_10 * trans__X_22);
    MR_Float trans__V_31_31 = (trans__M12_11 * trans__Y_23);
    MR_Float trans__V_32_32;
    MR_Float trans__V_33_33;
    MR_Float trans__V_34_34;
    MR_Float trans__V_35_35;
    MR_Float trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
#line 293 "trans.m"
    MR_Word trans___W_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
#line 258 "trans.m"
    MR_Float trans___M14_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 3)));
#line 258 "trans.m"
    MR_Float trans___M24_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 7)));
#line 258 "trans.m"
    MR_Float trans___M34_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 11)));

#line 264 "trans.m"
    trans__V_28_28 = (trans__V_30_30 + trans__V_31_31);
#line 264 "trans.m"
    trans__V_29_29 = (trans__M13_12 * trans__Z_24);
#line 264 "trans.m"
    trans__V_25_25 = (trans__V_28_28 + trans__V_29_29);
#line 265 "trans.m"
    trans__V_34_34 = (trans__M21_14 * trans__X_22);
#line 265 "trans.m"
    trans__V_35_35 = (trans__M22_15 * trans__Y_23);
#line 265 "trans.m"
    trans__V_32_32 = (trans__V_34_34 + trans__V_35_35);
#line 265 "trans.m"
    trans__V_33_33 = (trans__M23_16 * trans__Z_24);
#line 264 "trans.m"
    trans__V_26_26 = (trans__V_32_32 + trans__V_33_33);
#line 266 "trans.m"
    trans__V_38_38 = (trans__M31_18 * trans__X_22);
#line 266 "trans.m"
    trans__V_39_39 = (trans__M32_19 * trans__Y_23);
#line 266 "trans.m"
    trans__V_36_36 = (trans__V_38_38 + trans__V_39_39);
#line 266 "trans.m"
    trans__V_37_37 = (trans__M33_20 * trans__Z_24);
#line 264 "trans.m"
    trans__V_27_27 = (trans__V_36_36 + trans__V_37_37);
#line 264 "trans.m"
    {
#line 264 "trans.m"
      trans__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 264 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 0) = MR_box_float(trans__V_25_25);
#line 264 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 1) = MR_box_float(trans__V_26_26);
#line 264 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 2) = MR_box_float(trans__V_27_27);
#line 264 "trans.m"
    }
    return trans__HeadVar__3_3;
  }
#line 92 "trans.m"
}

#line 91 "trans.m"
MR_Word MR_CALL trans__point_to_world_space_3_f_0(
#line 91 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 91 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 91 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__3_3;
    MR_Word trans__M_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__M11_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 0)));
    MR_Float trans__M12_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 1)));
    MR_Float trans__M13_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 2)));
    MR_Float trans__M14_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 3)));
    MR_Float trans__M21_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 4)));
    MR_Float trans__M22_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 5)));
    MR_Float trans__M23_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 6)));
    MR_Float trans__M24_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 7)));
    MR_Float trans__M31_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 8)));
    MR_Float trans__M32_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 9)));
    MR_Float trans__M33_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 10)));
    MR_Float trans__M34_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 11)));
    MR_Float trans__X_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__Y_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__Z_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float trans__V_25_25;
    MR_Float trans__V_26_26;
    MR_Float trans__V_27_27;
    MR_Float trans__V_28_28;
    MR_Float trans__V_29_29;
    MR_Float trans__V_30_30;
    MR_Float trans__V_31_31 = (trans__M11_10 * trans__X_22);
    MR_Float trans__V_32_32 = (trans__M12_11 * trans__Y_23);
    MR_Float trans__V_33_33;
    MR_Float trans__V_34_34;
    MR_Float trans__V_35_35;
    MR_Float trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40;
    MR_Float trans__V_41_41;
    MR_Float trans__V_42_42;
#line 292 "trans.m"
    MR_Word trans___W_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));

#line 250 "trans.m"
    trans__V_29_29 = (trans__V_31_31 + trans__V_32_32);
#line 250 "trans.m"
    trans__V_30_30 = (trans__M13_12 * trans__Z_24);
#line 250 "trans.m"
    trans__V_28_28 = (trans__V_29_29 + trans__V_30_30);
#line 250 "trans.m"
    trans__V_25_25 = (trans__V_28_28 + trans__M14_13);
#line 251 "trans.m"
    trans__V_36_36 = (trans__M21_14 * trans__X_22);
#line 251 "trans.m"
    trans__V_37_37 = (trans__M22_15 * trans__Y_23);
#line 251 "trans.m"
    trans__V_34_34 = (trans__V_36_36 + trans__V_37_37);
#line 251 "trans.m"
    trans__V_35_35 = (trans__M23_16 * trans__Z_24);
#line 251 "trans.m"
    trans__V_33_33 = (trans__V_34_34 + trans__V_35_35);
#line 250 "trans.m"
    trans__V_26_26 = (trans__V_33_33 + trans__M24_17);
#line 252 "trans.m"
    trans__V_41_41 = (trans__M31_18 * trans__X_22);
#line 252 "trans.m"
    trans__V_42_42 = (trans__M32_19 * trans__Y_23);
#line 252 "trans.m"
    trans__V_39_39 = (trans__V_41_41 + trans__V_42_42);
#line 252 "trans.m"
    trans__V_40_40 = (trans__M33_20 * trans__Z_24);
#line 252 "trans.m"
    trans__V_38_38 = (trans__V_39_39 + trans__V_40_40);
#line 250 "trans.m"
    trans__V_27_27 = (trans__V_38_38 + trans__M34_21);
#line 250 "trans.m"
    {
#line 250 "trans.m"
      trans__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 0) = MR_box_float(trans__V_25_25);
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 1) = MR_box_float(trans__V_26_26);
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 2) = MR_box_float(trans__V_27_27);
#line 250 "trans.m"
    }
    return trans__HeadVar__3_3;
  }
#line 91 "trans.m"
}

#line 89 "trans.m"
MR_Word MR_CALL trans__normal_to_object_space_3_f_0(
#line 89 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 89 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 89 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__3_3;
    MR_Word trans__M_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
    MR_Float trans__M11_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 0)));
    MR_Float trans__M12_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 1)));
    MR_Float trans__M13_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 2)));
    MR_Float trans__M21_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 4)));
    MR_Float trans__M22_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 5)));
    MR_Float trans__M23_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 6)));
    MR_Float trans__M31_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 8)));
    MR_Float trans__M32_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 9)));
    MR_Float trans__M33_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 10)));
    MR_Float trans__X_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__Y_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__Z_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float trans__V_25_25;
    MR_Float trans__V_26_26;
    MR_Float trans__V_27_27;
    MR_Float trans__V_28_28;
    MR_Float trans__V_29_29;
    MR_Float trans__V_30_30 = (trans__M11_10 * trans__X_22);
    MR_Float trans__V_31_31 = (trans__M21_14 * trans__Y_23);
    MR_Float trans__V_32_32;
    MR_Float trans__V_33_33;
    MR_Float trans__V_34_34;
    MR_Float trans__V_35_35;
    MR_Float trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
#line 288 "trans.m"
    MR_Word trans___W_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
#line 274 "trans.m"
    MR_Float trans___M14_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 3)));
#line 274 "trans.m"
    MR_Float trans___M24_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 7)));
#line 274 "trans.m"
    MR_Float trans___M34_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__M_4, (MR_Integer) 11)));

#line 280 "trans.m"
    trans__V_28_28 = (trans__V_30_30 + trans__V_31_31);
#line 280 "trans.m"
    trans__V_29_29 = (trans__M31_18 * trans__Z_24);
#line 280 "trans.m"
    trans__V_25_25 = (trans__V_28_28 + trans__V_29_29);
#line 281 "trans.m"
    trans__V_34_34 = (trans__M12_11 * trans__X_22);
#line 281 "trans.m"
    trans__V_35_35 = (trans__M22_15 * trans__Y_23);
#line 281 "trans.m"
    trans__V_32_32 = (trans__V_34_34 + trans__V_35_35);
#line 281 "trans.m"
    trans__V_33_33 = (trans__M32_19 * trans__Z_24);
#line 280 "trans.m"
    trans__V_26_26 = (trans__V_32_32 + trans__V_33_33);
#line 282 "trans.m"
    trans__V_38_38 = (trans__M13_12 * trans__X_22);
#line 282 "trans.m"
    trans__V_39_39 = (trans__M23_16 * trans__Y_23);
#line 282 "trans.m"
    trans__V_36_36 = (trans__V_38_38 + trans__V_39_39);
#line 282 "trans.m"
    trans__V_37_37 = (trans__M33_20 * trans__Z_24);
#line 280 "trans.m"
    trans__V_27_27 = (trans__V_36_36 + trans__V_37_37);
#line 280 "trans.m"
    {
#line 280 "trans.m"
      trans__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 0) = MR_box_float(trans__V_25_25);
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 1) = MR_box_float(trans__V_26_26);
#line 280 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 2) = MR_box_float(trans__V_27_27);
#line 280 "trans.m"
    }
    return trans__HeadVar__3_3;
  }
#line 89 "trans.m"
}

#line 88 "trans.m"
MR_Word MR_CALL trans__vector_to_object_space_3_f_0(
#line 88 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 88 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 88 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__3_3;
    MR_Word trans__W_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__M11_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 0)));
    MR_Float trans__M12_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 1)));
    MR_Float trans__M13_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 2)));
    MR_Float trans__M21_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 4)));
    MR_Float trans__M22_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 5)));
    MR_Float trans__M23_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 6)));
    MR_Float trans__M31_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 8)));
    MR_Float trans__M32_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 9)));
    MR_Float trans__M33_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 10)));
    MR_Float trans__X_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__Y_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__Z_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float trans__V_25_25;
    MR_Float trans__V_26_26;
    MR_Float trans__V_27_27;
    MR_Float trans__V_28_28;
    MR_Float trans__V_29_29;
    MR_Float trans__V_30_30 = (trans__M11_10 * trans__X_22);
    MR_Float trans__V_31_31 = (trans__M12_11 * trans__Y_23);
    MR_Float trans__V_32_32;
    MR_Float trans__V_33_33;
    MR_Float trans__V_34_34;
    MR_Float trans__V_35_35;
    MR_Float trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
#line 287 "trans.m"
    MR_Word trans___M_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));
#line 258 "trans.m"
    MR_Float trans___M14_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 3)));
#line 258 "trans.m"
    MR_Float trans___M24_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 7)));
#line 258 "trans.m"
    MR_Float trans___M34_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 11)));

#line 264 "trans.m"
    trans__V_28_28 = (trans__V_30_30 + trans__V_31_31);
#line 264 "trans.m"
    trans__V_29_29 = (trans__M13_12 * trans__Z_24);
#line 264 "trans.m"
    trans__V_25_25 = (trans__V_28_28 + trans__V_29_29);
#line 265 "trans.m"
    trans__V_34_34 = (trans__M21_14 * trans__X_22);
#line 265 "trans.m"
    trans__V_35_35 = (trans__M22_15 * trans__Y_23);
#line 265 "trans.m"
    trans__V_32_32 = (trans__V_34_34 + trans__V_35_35);
#line 265 "trans.m"
    trans__V_33_33 = (trans__M23_16 * trans__Z_24);
#line 264 "trans.m"
    trans__V_26_26 = (trans__V_32_32 + trans__V_33_33);
#line 266 "trans.m"
    trans__V_38_38 = (trans__M31_18 * trans__X_22);
#line 266 "trans.m"
    trans__V_39_39 = (trans__M32_19 * trans__Y_23);
#line 266 "trans.m"
    trans__V_36_36 = (trans__V_38_38 + trans__V_39_39);
#line 266 "trans.m"
    trans__V_37_37 = (trans__M33_20 * trans__Z_24);
#line 264 "trans.m"
    trans__V_27_27 = (trans__V_36_36 + trans__V_37_37);
#line 264 "trans.m"
    {
#line 264 "trans.m"
      trans__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 264 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 0) = MR_box_float(trans__V_25_25);
#line 264 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 1) = MR_box_float(trans__V_26_26);
#line 264 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 2) = MR_box_float(trans__V_27_27);
#line 264 "trans.m"
    }
    return trans__HeadVar__3_3;
  }
#line 88 "trans.m"
}

#line 87 "trans.m"
MR_Word MR_CALL trans__point_to_object_space_3_f_0(
#line 87 "trans.m"
  MR_Word trans__HeadVar__1_1,
#line 87 "trans.m"
  MR_Word trans__HeadVar__2_2)
#line 87 "trans.m"
{
  {
    bool trans__succeeded;
    MR_Word trans__HeadVar__3_3;
    MR_Word trans__W_5 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 1)));
    MR_Float trans__M11_10 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 0)));
    MR_Float trans__M12_11 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 1)));
    MR_Float trans__M13_12 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 2)));
    MR_Float trans__M14_13 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 3)));
    MR_Float trans__M21_14 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 4)));
    MR_Float trans__M22_15 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 5)));
    MR_Float trans__M23_16 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 6)));
    MR_Float trans__M24_17 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 7)));
    MR_Float trans__M31_18 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 8)));
    MR_Float trans__M32_19 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 9)));
    MR_Float trans__M33_20 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 10)));
    MR_Float trans__M34_21 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__W_5, (MR_Integer) 11)));
    MR_Float trans__X_22 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 0)));
    MR_Float trans__Y_23 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 1)));
    MR_Float trans__Z_24 = MR_unbox_float((MR_hl_field(MR_mktag(0), trans__HeadVar__2_2, (MR_Integer) 2)));
    MR_Float trans__V_25_25;
    MR_Float trans__V_26_26;
    MR_Float trans__V_27_27;
    MR_Float trans__V_28_28;
    MR_Float trans__V_29_29;
    MR_Float trans__V_30_30;
    MR_Float trans__V_31_31 = (trans__M11_10 * trans__X_22);
    MR_Float trans__V_32_32 = (trans__M12_11 * trans__Y_23);
    MR_Float trans__V_33_33;
    MR_Float trans__V_34_34;
    MR_Float trans__V_35_35;
    MR_Float trans__V_36_36;
    MR_Float trans__V_37_37;
    MR_Float trans__V_38_38;
    MR_Float trans__V_39_39;
    MR_Float trans__V_40_40;
    MR_Float trans__V_41_41;
    MR_Float trans__V_42_42;
#line 286 "trans.m"
    MR_Word trans___M_4 = ((MR_Word) (MR_hl_field(MR_mktag(0), trans__HeadVar__1_1, (MR_Integer) 0)));

#line 250 "trans.m"
    trans__V_29_29 = (trans__V_31_31 + trans__V_32_32);
#line 250 "trans.m"
    trans__V_30_30 = (trans__M13_12 * trans__Z_24);
#line 250 "trans.m"
    trans__V_28_28 = (trans__V_29_29 + trans__V_30_30);
#line 250 "trans.m"
    trans__V_25_25 = (trans__V_28_28 + trans__M14_13);
#line 251 "trans.m"
    trans__V_36_36 = (trans__M21_14 * trans__X_22);
#line 251 "trans.m"
    trans__V_37_37 = (trans__M22_15 * trans__Y_23);
#line 251 "trans.m"
    trans__V_34_34 = (trans__V_36_36 + trans__V_37_37);
#line 251 "trans.m"
    trans__V_35_35 = (trans__M23_16 * trans__Z_24);
#line 251 "trans.m"
    trans__V_33_33 = (trans__V_34_34 + trans__V_35_35);
#line 250 "trans.m"
    trans__V_26_26 = (trans__V_33_33 + trans__M24_17);
#line 252 "trans.m"
    trans__V_41_41 = (trans__M31_18 * trans__X_22);
#line 252 "trans.m"
    trans__V_42_42 = (trans__M32_19 * trans__Y_23);
#line 252 "trans.m"
    trans__V_39_39 = (trans__V_41_41 + trans__V_42_42);
#line 252 "trans.m"
    trans__V_40_40 = (trans__M33_20 * trans__Z_24);
#line 252 "trans.m"
    trans__V_38_38 = (trans__V_39_39 + trans__V_40_40);
#line 250 "trans.m"
    trans__V_27_27 = (trans__V_38_38 + trans__M34_21);
#line 250 "trans.m"
    {
#line 250 "trans.m"
      trans__HeadVar__3_3 = (MR_Word) MR_new_object(MR_Word, ((MR_Integer) 3 * sizeof(MR_Word)), "point");
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 0) = MR_box_float(trans__V_25_25);
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 1) = MR_box_float(trans__V_26_26);
#line 250 "trans.m"
      MR_hl_field(MR_mktag(0), trans__HeadVar__3_3, 2) = MR_box_float(trans__V_27_27);
#line 250 "trans.m"
    }
    return trans__HeadVar__3_3;
  }
#line 87 "trans.m"
}

void mercury__trans__init(void)
{
}

void mercury__trans__init_type_tables(void)
{
	static bool initialised = FALSE;
	if (initialised) return;
	initialised = TRUE;

	MR_register_type_ctor_info(&trans__trans__type_ctor_info_trans_0);
	MR_register_type_ctor_info(&trans__trans__type_ctor_info_surface_coordinates_0);
	MR_register_type_ctor_info(&trans__trans__type_ctor_info_matrix_0);
	MR_register_type_ctor_info(&trans__trans__type_ctor_info_intersections_0);
	MR_register_type_ctor_info(&trans__trans__type_ctor_info_intersection_0);
	MR_register_type_ctor_info(&trans__trans__type_ctor_info_face_intersections_0);
	MR_register_type_ctor_info(&trans__trans__type_ctor_info_face_intersection_0);
}

void mercury__trans__init_debugger(void)
{
	MR_fatal_error("debugger initialization in MLDS grade");
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;

/* :- end_module trans. */
